# Zynq

Always-on MCU subsystem

1. Hardware core:
- Triple + voters, ECC on RAM --> fault-tolerant
- ROM for fixed boot/sequencing code (must alwyas work), RAM for loadable, custom policy firmware (can be customized)
- Independent always-on clock
- Local registers for PMU only, global registers reachable by AXI/APB bus.
2. Power topology
- Domains (Battery, Low-Power, Full-Power, PL)
- Power masters (APU, RPU cores - can request power changes for anything, including themselves) vs. power slaves (GPU, USB, PL, memory,... - only acted upon)
3. API - req/ack protocol
Every state change - power up/down, isolate, reset, retention - follow the same pattern:
- TRIG register: any master write 1 + optionally masked with INT_MASK/INT_DIS register
- PMU interrupt ---> PMU ISR executes
- STATUS register clear to ack

Priority:
- Power down: island before domains
- Power up: domains before islands
- Slaves
- Masters

This is to prevents a slave from being left unpowered while its domain is down, or a domain collapsing while an island still depends on it

<details>
<summary>Why the ordering matters, what breaks if it's wrong, and how to guarantee it</summary>

## Why the ordering matters

Island's isolation/retention/power-switch control logic is fed from its own domain rail.

- Power-down island-before-domain: if domain rail drops while island still active, isolation cells lose power exactly when needed to clamp outputs -> floating/undefined signals -> both PMOS+NMOS conduct -> crowbar/shoot-through current. Also loses in-flight retention save -> corrupted TCM/OCM.
- Power-up domain-before-island: island needs domain's regulator/PLL/reset logic stable first. Release reset before voltage stable/clock locked -> metastability, SoA violation, garbage register state.
- Slaves after masters: slave has no agency to configure its own isolation/reset exit; needs a master to do it. Power it up with no master ready -> stuck isolated, or receives transactions it can't yet complete.

## What breaks if PMU gets it wrong

- Interconnect hang: transaction issued to a block mid-transition never completes (bus stalls forever). TRM calls this out for PMU RAM's own APB access.
- Crowbar current / IR-drop brownout -> can glitch *other* domains sharing the rail, not just the target.
- Retention data loss (rail collapses before save completes).
- Security state corruption (e.g. CSU reset released before scan-clear/BIST zeroization completes -> leaks uninitialized memory, breaks chain of trust).
- Race-dependent silent failures: simultaneous up/down requests for the same island without a hardware tiebreak = nondeterministic outcome.
- Since PMU is the single point of control for the whole chip, one bad sequence can hang/damage the entire SoC, needing full POR (not just SRST) to recover.

## How to guarantee correct sequencing

Don't rely on software discipline — make hardware incapable of doing it wrong, then prove it:

1. Hardware interlocks in the sequencer itself (checked atomically in the ISR), not left to the calling CPU to get right.
2. Handshake-gated transitions (power-good, PLL-lock, isolation-ack, retention-save-done), not fixed-delay timers.
3. Single atomic status register as source of truth — no window where two masters disagree on state.
4. UPF as golden model (this repository's power intent: [src/upf/README.md](src/upf/README.md)) — tools auto-insert isolation/retention/level-shifters with correct ordering from one spec, instead of hand-coded sequences.
5. Formal low-power verification (this repository's VC LP and VC Formal sign-off: [src/signoff/README.md](src/signoff/README.md)) — model-check: isolation never removed while power off, domain never collapses while a child island is active, no reachable state has conflicting simultaneous requests.
6. Power-aware sim with X-propagation — reading a domain before it's properly up/isolated produces X, testbench catches it.
7. Fault injection / stress testing — fire simultaneous/near-simultaneous requests and wake interrupts mid-transition deliberately.
8. Sequencer must be more reliable than what it sequences — hence TMR + ECC on the PMU processor itself (a corrupted controller state IS a sequencing bug, just undebuggable).
9. Post-silicon monitoring (SYSMON voltage/IR-drop sampling during transitions) to catch marginal sequencing that passes functional sim but fails under PVT corners.

</details>

4. The mechanisms

Isolation: clamp outputs at a domain boundary before power removal.

Using 3 bits register to control:
  - Low<->Full power: isolates Full-Power domain from both the Low-Power domain and PL. Used when powering down the FPD (APU, DDR, GPU, Display Port, PCIe, SATA,...) while the LPD (PMU, RPU, CSU, IOP) stays up.
  - PS<->PL: isolates the PS from PL. Used when power down/reconfigure/not use the PL while PS keeps running.
  - PS<->PL-except-PCAP: same as PS<->PL but leaves the PCAP (Processor Configuration Access Port) path open. PCAP is the interface used to configure PL so this variant lets PS isolate itself from a powered-down PL while still being able to load/reload new bitstream to it.

The reason these are independent bits rather than one global isolate signal: PL and FPD power down for different reasons on different schedules (PL is often power-gated when a design doesn't use the fabric at all; FPD is power-gated for CPU idle/sleep), so the PMU needs to isolate one boundary without necessarily isolating the other — and PCAP needs its own carve-out because "PS/PL isolated" and "PS/PL isolated but reconfigurable" are genuinely different states.

---

# Designing Your Own PMU on an Ibex RISC-V Core

Goal: instead of a bespoke sequencer or a TMR MicroBlaze (Zynq), use **lowRISC Ibex** as the dedicated always-on core that runs the PMU role. Ibex is a good fit — small (2-stage in-order, ~starting from ~a few kGE), silicon-proven, permissively licensed (Apache 2.0), and already used as exactly this kind of "small housekeeping core" in two real, open-source SoCs. Both are worth stealing from, for different reasons.

## Two real reference architectures (don't design from scratch — port from these)

### 1. PULP Fabric Controller — closest architectural match
In PULP/PULPissimo chips (Mr. Wolf, GAP8, Vega...), the SoC domain has its own small core (originally zero-riscy, merged into Ibex upstream) called the **Fabric Controller (FC)**. The FC is a dedicated core, separate from the compute **Cluster** domain (multiple RI5CY/CV32E40P cores), and its job is exactly the PMU role from the Zynq notes above: power/clock-gate the cluster, sequence its power-up/down, and run housekeeping — while the cluster does the actual compute work. This is architecturally the "one small core is the PMU for the rest of the chip" pattern, not "core manages only its own sleep."
- RTL / SoC integration: [pulp-platform/pulp_soc](https://github.com/pulp-platform/pulp_soc) (the SoC subsystem shared by PULPissimo/PULP), [pulp-platform/pulpissimo](https://github.com/pulp-platform/pulpissimo) (single-core, no cluster — simplest to study), [pulp-platform/pulp](https://github.com/pulp-platform/pulp) (full FC+Cluster system)
- Firmware baseline: [pulp-platform/pulp-runtime](https://github.com/pulp-platform/pulp-runtime) — bare-metal runtime with the actual power/clock-gate register driver: [`include/archi/chips/pulpissimo/apb_soc.h`](https://github.com/pulp-platform/pulp-runtime/blob/master/include/archi/chips/pulpissimo/apb_soc.h) (`APB_SOC_PWRREG_*` registers). This is a directly portable starting point for "how does firmware on the housekeeping core toggle power/clock domains via memory-mapped registers."

### 2. OpenTitan pwrmgr — best-documented register/firmware model
OpenTitan (also lowRISC, Ibex-based) doesn't use Ibex as a *separate* PMU core — Ibex is the main core and `pwrmgr` is a hardware FSM peripheral it talks to. But it's the most rigorously specified, formally-verified, silicon-taped-out open-source power-management **register interface + firmware driver** available, and the concepts map 1:1 onto everything in the Zynq notes above:
- Two-FSM split (always-on **slow FSM** for domains/root-clock-enables vs. switched-domain **fast FSM** for sequencing/reset) = same always-on-controller-vs-switched-domain split as the Zynq PMU/LPD split.
- Low-power entry = `CONTROL` register software hint + WFI, with a **fall-through check** (did an interrupt break the WFI?) and an **abort check** (is OTP/lifecycle/flash still busy?) before committing to power-down — a hardware-enforced version of the "hardware interlocks, not software discipline" rule already in this file.
- Wakeup aggregation and reset-reason capture is a register-modeled version of the Zynq GPI/wake-source list.
- RTL: [`hw/top_earlgrey/ip_autogen/pwrmgr/rtl/pwrmgr.sv`](https://github.com/lowRISC/opentitan/blob/master/hw/top_earlgrey/ip_autogen/pwrmgr/rtl/pwrmgr.sv), docs at [opentitan.org/book/hw/ip/pwrmgr](https://opentitan.org/book/hw/ip/pwrmgr/doc/theory_of_operation.html)
- **Firmware baseline (the actual DIF driver)**: `sw/device/lib/dif/dif_pwrmgr.h/.c` in [lowRISC/opentitan](https://github.com/lowRISC/opentitan). Key functions worth porting/adapting to a custom PMU peripheral:
  - `dif_pwrmgr_set_domain_config()` / `get_domain_config()` — which clocks/power domains stay on vs. off across low-power/active states (≈ Zynq's per-domain power-mode table)
  - `dif_pwrmgr_set_request_sources()` / `get_current_request_sources()` — enable/inspect which peripherals can request wakeup or reset (≈ Zynq's GPI wake aggregation)
  - `dif_pwrmgr_low_power_set_enabled()` — arms the WFI+hint low-power entry path
  - `dif_pwrmgr_wakeup_reason_get()` / `_clear()` — post-wake diagnosis of what caused the wake (≈ Zynq's CPUPWRDWNREQ check-on-boot pattern)
  - `dif_pwrmgr_request_sources_lock()` — locks config until hardware reset (a hardware-enforced guardrail, not a convention)

## Recommended path to a working, testable prototype

1. **Bring up Ibex in isolation first.** Use [lowRISC/ibex-demo-system](https://github.com/lowRISC/ibex-demo-system) (targets Arty A7-35T FPGA, has debug support + peripherals already wired) or, for pure simulation with no FPGA, [`ibex/examples/simple_system`](https://github.com/lowRISC/ibex/blob/master/examples/simple_system/README.md) in [lowRISC/ibex](https://github.com/lowRISC/ibex). This is your sandbox to get the toolchain (RV32IMC GCC + Verilator/FPGA flow) working before touching PMU logic at all.
2. **Design your PMU register block using the pwrmgr model as the spec**: TRIG/STATUS/MASK registers per service (power, isolation, retention, reset), a domain-config register, a request-sources register for wakeup/reset aggregation, and a wakeup-reason register — this is directly the register taxonomy already in this file's section 3, now backed by a real, formally-verified precedent instead of invented from scratch.
3. **Port the DIF driver style, not the literal code** (it's tied to OpenTitan's TL-UL fabric/autogen tooling) — write your own `pmu.h`/`pmu.c` on Ibex following the same function shapes (`pmu_set_domain_config`, `pmu_set_request_sources`, `pmu_low_power_enter`, `pmu_wakeup_reason_get`), talking to your own memory-mapped registers over whatever bus you attach Ibex to (APB if following the PULP pattern, TL-UL if following OpenTitan's).
4. **Borrow the PULP `apb_soc.h` pattern** for the actual bit-level power/clock-gate control if your domains are simple enable/disable rails rather than OpenTitan's full lifecycle/OTP-aware FSM — it's a much smaller, easier starting point to adapt.
5. **Test incrementally**: first prove Ibex can read/write your PMU registers in the demo-system sandbox (no real power domains, just registers + a testbench checking sequencing via the interlock rules above), then integrate against real (or simulated, via UPF-driven power-aware sim, as in [src/upf/README.md](src/upf/README.md)) power domains once the register/firmware interface is solid.

Sources: [OpenTitan pwrmgr docs](https://opentitan.org/book/hw/ip/pwrmgr/doc/theory_of_operation.html), [pwrmgr RTL](https://github.com/lowRISC/opentitan/blob/master/hw/top_earlgrey/ip_autogen/pwrmgr/rtl/pwrmgr.sv), [lowRISC/opentitan](https://github.com/lowRISC/opentitan), [lowRISC/ibex](https://github.com/lowRISC/ibex), [lowRISC/ibex-demo-system](https://github.com/lowRISC/ibex-demo-system), [pulp-platform/pulp_soc](https://github.com/pulp-platform/pulp_soc), [pulp-platform/pulpissimo](https://github.com/pulp-platform/pulpissimo), [pulp-platform/pulp](https://github.com/pulp-platform/pulp), [pulp-platform/pulp-runtime apb_soc.h](https://github.com/pulp-platform/pulp-runtime/blob/master/include/archi/chips/pulpissimo/apb_soc.h)