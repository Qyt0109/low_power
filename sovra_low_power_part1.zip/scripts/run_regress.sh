#!/bin/bash
# Regression runner (scripts/run_regress.sh).
#   scripts/run_regress.sh <src dir> <log dir> [make VAR=value ...]
# e.g. scripts/run_regress.sh src /sim/sovra/quyetdv/pmu/build/regress_x
# Runs every target in $TARGETS, one log per target (make's output; each
# target also keeps its simulator log in full under build/), and appends
# "<target> rc=<n> <seconds>s" to <log dir>/summary.txt. Every target fails
# (rc != 0) when its run fails; src/Makefile, "Pass/fail", says how.
# The targets in $XC_TARGETS run under SIM=xcelium (the Xcelium power-aware
# runs; $XCELIUM_BIN is put on PATH), the rest under SIM=vcs with -licqueue.
# A licence failure is retried after 180 s, at most three times.
SRCDIR=$1; LOGDIR=$2; shift 2
mkdir -p "$LOGDIR"
: > "$LOGDIR/summary.txt"
VF='VCSFLAGS=-full64 -sverilog -timescale=1ns/1ps -q -nc -licqueue'
XCELIUM_BIN=${XCELIUM_BIN:-/system/EDA/Cadence/xcelium/25.09.001/tools/bin}
export PATH="$XCELIUM_BIN:$PATH"
XC_TARGETS=${XC_TARGETS:-"pa ppupa ppubepa ppuregdocpa ppurstpa ppurstfpa ppucfgpa ppuratiopa ppuclkqpa ppuaxipa lpdpdpa acgpdpa ppudemopa"}
TARGETS=${TARGETS:-"ppu ppuneg ppurst ppuratio ppucfg ppurstf ppuirq ppupm ppuregdoc ppube ppudeny ppudevif ppuclkctrl ppuclkq ppuaxi ppudemo ppupcsmpg acg acgpd soc4 soc4bfm soc4stress soc4wdog soc4neg soc4pa soc4bfmpa soc4stresspa acgtluh readyadp ckrst soc4ckrst $XC_TARGETS"}
lic_fail() {
  grep -qiE "licensed number of users|unable to (check ?out|obtain).*licen|licen[cs]e.*(checkout failed|not available|denied|error)|failed to (check ?out|obtain).*licen" "$1"
}
for t in $TARGETS; do
  log="$LOGDIR/${t/:/_}.log"
  start=$(date +%s)
  for attempt in 1 2 3 4; do
    case " $XC_TARGETS " in
      *" $t "*) make -C "$SRCDIR" --no-print-directory SIM=xcelium "$@" \
                  $t > "$log" 2>&1 ;;
      *)        make -C "$SRCDIR" --no-print-directory SIM=vcs "$VF" "$@" \
                  $t > "$log" 2>&1 ;;
    esac
    rc=$?
    if [ $rc -ne 0 ] && lic_fail "$log" && [ $attempt -lt 4 ]; then
      echo "$t: licence unavailable (attempt $attempt), sleeping 180 s" >> "$LOGDIR/summary.txt"
      sleep 180
      continue
    fi
    break
  done
  echo "$t rc=$rc $(( $(date +%s) - start ))s" >> "$LOGDIR/summary.txt"
done
echo "DONE" >> "$LOGDIR/summary.txt"
