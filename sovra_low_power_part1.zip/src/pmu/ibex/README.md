# Vendored lowRISC Ibex

Third-party source, copied verbatim. **This is design RTL**, not testbench
stimulus: `rtl/scp_core.sv` in the directory above instantiates `ibex_top` from
here as the processor of the System Control Processor (SCP) described in
[`../README.md`](../README.md).

## What is here, and where it came from

| Path | Upstream | Revision |
|---|---|---|
| `rtl/`, `shared/`, `LICENSE` | [lowRISC/ibex](https://github.com/lowRISC/ibex) | `e1a6be2c1b32e2cbae6afef23fe8285577c00a68` (master, 2026-09-22, *"[rtl] Switch to ratified bitmanip extensions"*) |

Apache License 2.0. The `LICENSE` file is copied alongside and every source
file keeps its original header. **Nothing has been edited.** If a file here ever
needs a change, the change belongs upstream or in a wrapper next to it — which
is what `../rtl/scp_core.sv` is — not in the copy, otherwise the revision above
stops meaning anything.

The clone these came from was made with `git clone --depth 1` into
`build/ibex-upstream/` (git-ignored) on 2026-09-25. Ibex has no release tags
beyond the historical `pulpino-*`/`pulpissimo-*` ones, so master at a recorded
commit is the only citable revision.

## Files, and why each one is needed

### `rtl/` — all 33 files of upstream `rtl/`

Taken whole rather than trimmed, because Ibex's generate structure means the
same files are needed by every configuration; what a configuration changes is
which branches elaborate, not which files compile. Grouped by what they are:

| Files | Role |
|---|---|
| `ibex_pkg.sv`, `ibex_cheriot_pkg.sv` | packages. `ibex_cheriot_pkg` is imported by `ibex_top` unconditionally, so it is needed even with CHERIoT off |
| `ibex_top.sv`, `ibex_core.sv` | the core and its wrapper (clock gate, register file selection, optional ICache RAMs, optional lockstep) |
| `ibex_if_stage.sv`, `ibex_prefetch_buffer.sv`, `ibex_fetch_fifo.sv`, `ibex_compressed_decoder.sv`, `ibex_branch_predict.sv` | fetch |
| `ibex_id_stage.sv`, `ibex_decoder.sv`, `ibex_controller.sv` | decode and control |
| `ibex_ex_block.sv`, `ibex_alu.sv`, `ibex_multdiv_fast.sv`, `ibex_multdiv_slow.sv` | execute |
| `ibex_load_store_unit.sv`, `ibex_wb_stage.sv` | memory and writeback |
| `ibex_cs_registers.sv`, `ibex_csr.sv`, `ibex_counter.sv`, `ibex_pmp.sv` | CSRs, counters, PMP (PMP is elaborated only with `PMPEnable`) |
| `ibex_register_file_ff.sv`, `_fpga.sv`, `_latch.sv` | the three register-file implementations; `RegFile` selects one |
| `ibex_icache.sv`, `ibex_dummy_instr.sv`, `ibex_lockstep.sv`, `ibex_cheriot_ex.sv`, `ibex_trvk.sv` | optional features, **all off** in `scp_core`: instruction cache, SecureIbex dummy instructions, lockstep core, CHERIoT capability execution, CHERIoT tag revocation. Present so the configuration can change without re-vendoring |
| `ibex_top_tracing.sv`, `ibex_tracer.sv`, `ibex_tracer_pkg.sv` | simulation-only instruction tracer. Not in `IBEX_SRCS` (`src/Makefile`); a testbench that wants an instruction log instantiates `ibex_top_tracing` in place of `ibex_top` and defines `RVFI` |

### `shared/` — two of upstream `shared/rtl/`

| File | Lines | Why |
|---|---|---|
| `bus.sv` | 136 | the single-host, N-device, one-cycle-response bus Ibex's own `simple_system` uses. The SCP's private peripherals (RAM, timer, mailbox, wake aggregator) hang off it; see `../README.md` for what does *not* — an AXI4-Lite bridge cannot answer in one cycle, which is the assumption this bus makes |
| `timer.sv` | 154 | `mtime`/`mtimecmp`, the RISC-V machine timer as a memory-mapped device driving `irq_timer_i`. The SCP's hysteresis timers and transition deadlines are built on it |

Not taken from `shared/rtl/`: `ram_1p.sv`/`ram_2p.sv` (they wrap
`prim_ram_1p`/`prim_ram_2p`, which pull in the SRAM configuration packages and
`prim_util_memload.svh` for one `$readmemh`; the SCP writes its own 40-line RAM
model instead) and `fpga/`, `sim/` (Verilator glue).

## The lowRISC primitives live in `src/vendor/opentitan`, not here

Ibex ships its own copy of OpenTitan's primitives under `vendor/lowrisc_ip/`,
and `ibex_top` cannot elaborate without five of them plus four packages and two
`` `include `` headers. This repository already vendors OpenTitan primitives for
`rtl/acg/` under [`src/vendor/opentitan/`](../../vendor/opentitan/README.md), so
there was a choice: a second copy next to Ibex, or one shared copy.

**One shared copy**, for a reason that is not tidiness: any testbench that
instantiates both the SCP and the access-control gate — which is the whole
point of build stage F6 in `../README.md` — would otherwise compile two modules
named `prim_buf`, and Xcelium does not allow that.

It is safe because the two upstream sets were diffed at vendoring time. All 18
files present in both — every `prim_assert*`, `prim_flop_macros.sv`,
`prim_lc_sync.sv`, `prim_mubi_pkg.sv`, `prim_secded_pkg.sv`, `prim_util_pkg.sv`,
`prim_blanker.sv`, `prim_sparse_fsm_flop.sv`, `prim_sec_anchor_buf.sv`, both
`prim_secded_inv_*_enc.sv`, and the generic `prim_and2`/`prim_buf`/`prim_flop` —
are **byte-identical** between Ibex `e1a6be2c`'s `vendor/lowrisc_ip` (OpenTitan
`3424e7fb` per its `lowrisc_ip.lock.hjson`) and the repository's OpenTitan
`16e86c9e` copy. The three files Ibex needs that the ACG did not are added to
`src/vendor/opentitan/` and recorded there with this provenance:

| Added to `src/vendor/opentitan/` | Why Ibex needs it |
|---|---|
| `prim_generic/prim_clock_gating.sv` | the core clock gate in `ibex_top` (`core_clock_gate_i`) |
| `prim_generic/prim_clock_mux2.sv` | `ibex_top`'s scan-reset mux |
| `prim_generic/prim_ram_1p_pkg.sv` | `ram_1p_cfg_req_t`/`rsp_t` on `ibex_top`'s ICache configuration ports, present even with `ICache = 0` |
| `dv_utils/dv_fcov_macros.svh` | `` `include``d by `ibex_core`, `ibex_id_stage`, `ibex_controller` and others for functional-coverage points that expand to nothing here |

What `ibex_top` instantiates was established by elaboration, not by reading the
FuseSoC core files: with the packages, all of `rtl/` except the tracer, and only
`prim_and2`, `prim_buf`, `prim_flop`, `prim_clock_gating` and `prim_clock_mux2`,
Xcelium writes a snapshot. Everything else the `.core` files list —
`prim_ram_1p`, `prim_ram_1p_scr`, `prim_fifo_sync`, `prim_count`, `prim_lfsr`,
`prim_onehot_check`, the SECDED decoders, PULP `common_cells` — sits inside
generate branches that `scp_core`'s configuration does not elaborate. Enabling
the ICache, SecureIbex or CHERIoT would need those added.

## What was deliberately NOT taken

- **`vendor/lowrisc_ip/`** beyond the three files above — see the previous section.
- **`dv/`** — the UVM/co-simulation verification environment. Every testbench in
  this repository is plain SystemVerilog.
- **`examples/simple_system/`** — the Verilator demo SoC. Its shape (Ibex + `bus` +
  `ram_2p` + `timer` + a simulator-control device) is the shape the SCP takes,
  and `examples/sw/simple_system/common/{crt0.S,link.ld,common.mk}` are the
  reference for the SCP firmware's own startup file and linker script. They are
  consulted, not copied: the SCP memory map, vector table and toolchain flags
  differ (see `../README.md`).
- **`syn/`, `lint/`, `util/`, `doc/`, the `.core` files, `ibex_core.f`** — build
  plumbing for FuseSoC and Verilator. The file list for Xcelium lives in
  `src/Makefile` (`IBEX_SRCS`).

## Compiling

`make soc4elab` in `src/` elaborates `scp_core` with the rest of `soc4_top`
(VCS). Until 2026-10-06 `make ibexlint` elaborated `scp_core` alone under
Xcelium; it was removed with the build-flow cleanup. The three things it did
that a bare `xrun` on these files would miss, and which the soc4 build does
too (`SOC4_FLAGS` and `VCSFLAGS` in `src/Makefile`):

    -incdir src/vendor/opentitan/prim       prim_assert.sv, `include'd by bare name
    -incdir src/vendor/opentitan/dv_utils   dv_fcov_macros.svh, likewise
    -timescale 1ns/1ps                      no Ibex file carries a `timescale;
                                            this repository's RTL does, and
                                            Xcelium refuses to mix the two
                                            without a default

Order: `prim_util_pkg` → `prim_mubi_pkg` → `prim_secded_pkg` → `prim_ram_1p_pkg`
→ `ibex_pkg` → `ibex_cheriot_pkg` → the rest of `rtl/` → the five primitives.

### A known, understood warning

Every elaboration prints, three times:

    xmelab: *W,DPIEXP: DPI export function in  _sv_export.so not available.

`ibex_if_stage.sv` (lines 401-406) declares two `export "DPI-C"` functions,
`simutil_get_scramble_key` and `simutil_get_scramble_nonce`, so that Verilator
can read the ICache scrambling key out of a simulation. Xcelium notes that no
DPI library implements them. With `ICache = 0` nothing ever calls them. Not
suppressed, so that it stays visible if the ICache is ever turned on.

## Re-vendoring

    git clone --depth 1 https://github.com/lowRISC/ibex.git build/ibex-upstream
    cp build/ibex-upstream/rtl/*.sv          src/pmu/ibex/rtl/
    cp build/ibex-upstream/LICENSE           src/pmu/ibex/
    cp build/ibex-upstream/shared/rtl/{bus,timer}.sv  src/pmu/ibex/shared/

then re-run the diff of `build/ibex-upstream/vendor/lowrisc_ip/ip/prim*/rtl/`
against `src/vendor/opentitan/` **before** anything else, update the revision
here and in `src/vendor/opentitan/README.md`, and run `make soc4elab`. If the
diff is no longer empty, the shared-copy argument above no longer holds and the
two consumers need to be reconciled, not papered over with a second copy.
