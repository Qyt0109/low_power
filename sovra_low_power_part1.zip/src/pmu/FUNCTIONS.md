# SCP function checklist: what the specifications ask of an SCP, against this design

The functions the SCP firmware (and the SCP subsystem hardware it needs) must
implement, cross-checked item by item against the two Arm documents in
`references/standards/` that govern the SCP and its PPUs, and against the
RISC-V specifications of the interface the AP uses:

| Prefix | Document |
|---|---|
| `§` | Arm Power Control System Architecture, DEN 0050D (PCSA 2.1) |
| `PPU §` | Arm Power Policy Unit Architecture Specification v1.1, DEN 0051E |
| RPMI | RISC-V Platform Management Interface v1.0 (`riscv-non-isa/riscv-rpmi`, tag `v1.0`; not in `references/standards/`), cited by service-group, service and queue name |
| SBI | RISC-V Supervisor Binary Interface, cited by extension name (`HSM`, `SRST`, `SUSP`, `MPXY`) |

Organised by **where the requirement comes from**, so that every row has a
citation and every citation has a row. The build plan the stages refer to is
[`README.md`](README.md) §8; the design the "here" column assumes is
`Proposed_PMU/PCSA_FLAT_DOMAIN_SOC.md` (removed 2026-10-05, commit 2edfabe;
superseded by
[`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)).

Status: **M** must be built for this design · **O** optional, or a later stage ·
**—** not applicable here, with the reason · **✓** already exists in the
repository as hardware · **◐** partially applicable

**2026-10-02.** The rows are the full twelve-domain SoC's. What is built runs
on **soc4** (`src/soc4`; [`docs/SOC4_DESIGN.md`](../../docs/SOC4_DESIGN.md)): the SCP with four
PPUs, one RPMI transport (T0a: BASE and DEVICE_POWER) over a TL-UL mailbox with
a source firewall, and the AP as the agent. The 12-domain `pmu_top`, on which
F0–F4 were first built, was removed then, with its tests; where a row below
names firmware of that time, the current equivalent is given.

---

## 1. The minimum SCP software interface — §3.3.3

§3.3.3: *"The SCP software interface is expected to provide, at minimum,
commands to support the following"* — six groups.

| # | Command group (§3.3.3) | | Here | Firmware | Stage |
|---|---|:---:|---|---|---|
| 1.1 | **Power states**: *"Commands to request setting of core, cluster, device and SoC power states"* | **M** | core and device states only. No cluster level; the SoC has one state, `RUN` (design doc §5.3) | librpmi's DEVICE_POWER and HSM callbacks → the policy layer (`mod/policy.c`) → `pd_request_static`; the SCP reads `PPU_PWSR` for its own use, since `DPWR_GET_STATE` reports the vote (row 8.2.4). (On `pmu_top`, W4.1's policy went through `pd_set_state` and the design doc's state tuples, removed 2026-10-02) | F3, F4, F7 |
| 1.2 | **DVFS**: *"changing the operating point of a DVFS capable domain"* | **—** | one rail, one frequency (design doc §3) | none; Performance protocol not implemented | — |
| 1.3 | **Voltage supply**: *"changing the level of platform power supplies outside of DVFS domains"* | **—** | one rail. §6.4.1's *Voltage Regulator Control* reduces to rail enable and power-good, which is a board function | none | — |
| 1.4 | **Clock supply**: *"the enabling and source frequency of platform clocks outside of DVFS domains"* | **—** | one clock source, always on. Component clock *gating* is hardware-autonomous by §6.4.1 and not an SCP command | none | — |
| 1.5 | **Timer**: *"setting and cancelling of always-on wake-up timer events for a specific AP core. These commands are only required in a platform without AP core visible always-on timers"* | **—** | the per-CPU private timers are in `PD_AON` (design doc §2.3) | none | — |
| 1.6 | **Boot**: *"Commands for boot time initialization. The requirement for these commands is dependent on the boot process used"* | **O** | none needed while the SCP RAM is preloaded; a ROM-then-load flow (§6.4.1) would add a firmware-load command | `boot.c` | F5 |

**1 of 6 mandatory here, 1 optional, 4 removed by the single-rail, single-clock,
flat partition.** §3.3.3 also names the *"basic extensions"* — sensor
management, capability and resource-state queries — and points at SCMI for all
of it. This design uses RPMI instead: see §8.

## 2. The minimum system services — §3.3.3

*"A minimum set of system services that the SCP is expected to provide is as
follows"* — three.

| # | Service (§3.3.3) | | Here | Firmware | Stage |
|---|---|:---:|---|---|---|
| 2.1 | **System initialization**: *"power-on reset initialization tasks ... power-on sequencing of primary system and AP core power domains through to AP core boot"* | **M** | `PD_AON` is released by reset; the SCP defaults twelve PPUs, powers `PD_CPU0`–`PD_CPU3` and releases all four harts, leaves eight `OFF` (`README.md` §7.7; the design doc §10 powered `PD_CPU0` alone) | `boot.c`: `boot_init_ppus`, `boot_ap0` | F5 |
| 2.2 | **Events**: *"GIC wake requests, local timer events, implementation defined always-on domain wake requests, debug power requests and watchdog expiration"* | **M** | five listed; four apply: | | |
| | · GIC wake requests | **◐** | wired to `DEVQACTIVE`; the PPU restores the domain autonomously and the SCP is *notified* by `STA_POLICY_TRN` (design doc §5.1.1) | `pd_on_ppu_irq` bookkeeping only | F3 |
| | · local timer events | **M** | deadlines, hysteresis, periodic tasks | `timer.c`, `pd_on_timer` | F0, F3 |
| | · always-on domain wake requests | **M** | the CPUs' wake logic: interrupts and timers (W5.1). An access to an accelerator the AP voted `OFF` gets an error and an SCP log entry instead of §7.2.8's stall-and-wake (D21) | `scp_wake_aggr` + `pd_on_wake` | F6 |
| | · debug power requests | **—** | no debug power domain in this design | none | — |
| | · watchdog expiration | **M** | §6.4.1 *Watchdog*; 2026-10-05: a reset of the SCP subsystem, no NMI (platform plan H18) | `scp_wdog` + `CAUSE` read at boot | H18 |
| 2.3 | **Consistency**: *"no races between requests, for example, ensuring power domain dependencies are maintained despite the order and timing of the arrival of wake requests"* | **M** | single-threaded event loop, one FSM per domain, reference counts; dependencies are trivial by construction (design doc §1) and checked as an invariant (design doc §10) | `pd` FSM, `pd_check_invariants` | F3 |

## 3. Services — §3.2.1

The fuller description of the same duties. Rows that restate §1–§2 say so.

| # | Service (§3.2.1) | | Here | Stage |
|---|---|:---:|---|---|
| 3.1 | **OSPM directed operation** — *"voltage supply changes, power control actions, and clock source management under the direction of the OSPM"* | **◐** | power control actions only (rows 1.1–1.4) | F4 |
| 3.2 | **Response to system events** — timer, wake, debug access, watchdog | **M** | row 2.2 | F3–F6 |
| 3.3 | **System aware functions** — *"reconcile requests from OSPM and other agents for shared resources"* | **M** | one agent, the AP (§8), and twelve claimable units: per-domain reference counts (design doc §4, §9.3), with one requestor | F3 |
| 3.4 | · *"control the path to main memory or entry to, and exit from, SoC sleep modes without requiring AP core activity"* | **—** | memory is always-on; there is no SoC sleep mode (design doc §5.3) | — |
| 3.5 | · *"monitoring sensors and measurement functions ... process and temperature sensor data harvesting"* | **O** | no sensors in the design, and RPMI v1.0 defines no sensor service group | F7+ |
| 3.6 | · *"overriding the OSPM direction, as necessary, to ensure the electrical and thermal protection of the system"* | **◐** | with no DVFS the only actuator is how many domains are on: the concurrency cap in `pd_admission`, and a forced `OFF` on an alarm input (§5.3.1) | F3 |
| 3.7 | **System initialization** | **M** | row 2.1 | F5 |
| 3.8 | *"there can be several SCPs with distributed responsibility ... one lead SCP"* | **—** | one SCP | — |

## 4. SCP components — §6.4.1

What §6.4.1 says the SCP subsystem contains, and what the firmware therefore
has to drive. This is the hardware side of the checklist.

| # | Component (§6.4.1) | | Here | Block | Stage |
|---|---|:---:|---|---|---|
| 4.1 | **SCP Processor Core** — *"runs firmware that takes actions based upon requests, events and scheduled tasks"* | **✓** | Ibex `small`, argued against the six selection criteria in `rtl/scp_core.sv` | `scp_core` | F0 ✅ |
| 4.2 | **Processor Core Memory** — *"ROM for boot and RAM for storing firmware instructions and data. The ROM and RAM are private to the SCP"* | **M** / **O** | RAM in F0, preloaded; ROM optional (F5) | `scp_ram` | F0 |
| 4.3 | **System Counters and Generic Timers** — primary counter shared with APs; generic timers for interrupts and wake-ups | **M** / **O** | the SCP's own `mtime`/`mtimecmp` (M); a primary counter mapped into AP space (O, nothing in F0–F6 needs it) | `timer` | F0 |
| 4.4 | · *"secondary constantly running low speed counter ... preserved through SoC SLEEP states"* and the time hand-off between counters | **—** | no SoC sleep state | — | — |
| 4.5 | **Watchdog** — *"If the watchdog is not written to on a regular basis by the SCP then the watchdog will produce an interrupt, and this will ultimately lead to a reset of the system. A syndrome register must be available"* | **M** | kick from the event loop, once per completed pass; expiry resets the SCP subsystem alone (no pre-warning IRQ); syndrome (`CAUSE`) read at boot, the domains taken over, the event logged (2026-10-05, platform plan H18, F12) | `scp_wdog`, `hal/scp_wdog.h`, `mod/flog.c` | H18 |
| 4.6 | **Voltage Regulator Control** — PMIC interface | **—** | one rail, board-level enable | — | — |
| 4.7 | **Clock Control** — *"clock source enabling, selection, and division"*; explicitly **not** *"run time dynamic gating of clocks at component activity level"* | **—** | one source; gating is the clock controllers' (`ppu_clk_ctrl`) | — | — |
| 4.8 | **System Control** — *"register controlled outputs and interrupt inputs"*, the four-phase handshake example | **O** | the wake aggregator is one instance of this pattern (level request in, status register, interrupt) | `scp_wake_aggr` | F6 |
| 4.9 | **Messaging Interface** — *"shared memory mailboxes and doorbell interrupts"*; *"must be usable by any AP core"*; the three-step flow | **M** | two RPMI shared-memory transports, T0a and T0b, each with its queues in the queue SRAM and one AP-to-SCP doorbell; no SCP-to-AP doorbell, as OpenSBI polls (§8.5) | soc4: `soc4_mbx` (per agent a doorbell, a queue window and a firewall entry) on `scp_top`'s `ext_*` window, `hal/rpmi_db.c`, librpmi; one transport per agent, the AP and an RPU stand-in (platform plan H11, F6; README §7) | F4 |
| 4.10 | **Power Policy Units** — *"The SCP firmware makes only high-level power domain policy decisions and programs them into the PPU"*; *"A minimum of one PPU is located within the always-on domain"* | **✓** | twelve `ppu_top` instances, all in `PD_AON`, over AXI4-Lite | `src/rtl/ppu/` | F1 |
| 4.11 | **Sensor Control** | **—** / **O** | none in the design | — | F7+ |
| 4.12 | **Additional Peripherals** — *"always-on domain peripherals providing wake-up functionality"* | **M** | the wake aggregator | `scp_wake_aggr` | F6 |
| 4.13 | **Peripheral Access** — *"SCP peripherals are privately mapped for security reasons"*; two shared exceptions, the system counter and the messaging interface | **M** | the memory map of `README.md` §2.1: PPU windows and SCP peripherals on the SCP's bus only; the RPMI queue SRAM and the AP side of the doorbells are the shared windows, behind a firewall that admits only the CVA6 cores (W2.1) | `scp_top` | F0–F4 |
| 4.14 | **System Access** — the SCP reaching *"the wider SoC resources ... configuration of interconnect and memory controller components"* | **O** | nothing to save or restore: memory and interconnect never power down | — | — |

## 5. Coordination by the SCP — §5.3

| # | §5.3 | | Here |
|---|---|:---:|---|
| 5.1 | **SoC power states** (§5.3.1) — reconcile OSPM `SLEEP` requests with self-managed devices; select depth; manage *"voltage supply management, power control, clock supply, preservation of system time ... system configuration save and restore"* | **—** | the SoC has one state (design doc §5.3); the entire §5.3.1 task list is absent, which the design doc §5.6.9 calls *"a substantial and error-prone piece of SCP firmware"* removed |
| 5.2 | · *"The SCP might also autonomously place the system, or sub-components, into an OFF state as a protective measure in an alarm condition such as thermal runaway"* | **◐** | a forced device-domain `OFF` on an alarm input: row 3.6 |
| 5.3 | **Cluster power states** (§5.3.2) — track core constraints, hold new cores off during cluster power-off, control cache flush and coherency exit | **—** | no clusters; the DSP/NPU units are non-coherent (design doc §13 item 5) |

## 6. Reset and wake integration — §7.3.3, §7.2.1

| # | Requirement | | Here | Firmware | Stage |
|---|---|:---:|---|---|---|
| 6.1 | §7.3.3 *Power Mode Transitions*: quiescence before any non-functional mode — *"the PPU device low-power interface can be used to ensure components are quiescent"* | **✓** | the Q-Channel handshake in `ppu_seq`; for the `FULL_RET → OFF` case the mailbox agreement of PPU §3.3.2 (`README.md` §5.3) | `pd` AGREEING phase | F3 |
| 6.2 | §7.3.3 *Initiating Warm Resets*: *"The warm reset of a power domain can be initiated either by programming WARM_RST as the PPU policy or, with a P-Channel PPU, using a PACTIVE request"* | **M** | the recovery action of the event handler: `WARM_RST` then back to `ON`, static, `WARM_RST_DEVREQEN` per component | `ppu_warm_reset` | F5 |
| 6.3 | §7.3.3 *Warm resets without quiescence* — debugger and RAS-driven resets are *"without any guarantee of quiescence"* | **—** | no debug or RAS agents | — | — |
| 6.4 | §7.2.1 *Power Domain Wake Events*: *"Such signals should be level sensitive and stay asserted until the request is met"*; pulses *"cannot be used as wake-up signals or must be conditioned so they are level sensitive"* | **M** | every SCP interrupt source is level-sensitive and cleared at the peripheral (`scp_core.sv` header); the wake aggregator holds the gates' levels | `scp_wake_aggr` | F6 |

## 7. The PPU driver — DEN 0051E

The register-level operations the firmware needs, one row per PPU function
the specification defines for software. The register layout is
[`src/rtl/ppu/REGISTERS.md`](../rtl/ppu/REGISTERS.md); the sequences are its
§5 and the design doc §5.6.

| # | Operation (PPU spec) | | Registers | Firmware | Stage |
|---|---|:---:|---|---|---|
| 7.1 | Discover the build: supported static and dynamic modes, `LOCK_SPT`, `RET_RAM_REGS`, `SW_DEV_DEL_SPT`, `PWR_MODE_ENTRY_DEL_SPT`, channel count; identify the implementation | **M** | `PPU_IDR0`, `PPU_IDR1`, `PPU_IIDR`, `PPU_AIDR` | `ppu_probe` | F1 |
| 7.2 | Read the policy **after reset instead of assuming it** — `PCSMMODESTAT` can make the reset policy `MEM_RET` (PPU §4.1.6, Table 4-13; `REGISTERS.md` §2) | **M** | `PPU_PWPR` | `pd_init` | F1 |
| 7.3 | Static transition: write policy, wait for `PWR_STATUS`, confirm `STA_POLICY_TRN` (PPU §3.3.1, §4.1.1) | **M** | `PPU_PWPR`, `PPU_PWSR`, `PPU_ISR` | `ppu_set_policy`, `ppu_wait_mode` | F1 |
| 7.4 | Refused write: an unsupported policy leaves `PPU_PWPR` unchanged and raises `UNSPT_POLICY_IRQ` (PPU §4.1.1) — **read back every write** | **M** | `PPU_PWPR`, `PPU_AISR[0]` | `ppu_set_policy` return value | F2 |
| 7.5 | Dynamic transitions: policy as a floor, `PWR_DYN_STATUS` lags until in-flight transitions finish (PPU §3.4.3) — and **`PWR_DYN_EN` may not change again until `PWR_DYN_STATUS` shows the last change** (PPU §4.1.1 note: otherwise UNPREDICTABLE; README §6 rule 10) | **M** | `PPU_PWPR[8]`, `PPU_PWSR[8]` | `ppu_set_policy(dyn=1)` + poll; `ppu_dyn_settled` gates a second change (`PPU_E_STATE`), `pd` waits for it. Verified by `ppu_stress` `DYN.STATUS` on `pmu_top` (retired 2026-10-02); soc4's PPUs have no dynamic modes, so it is N/A there and the PPU unit testbenches cover it ([`PPU_FW_CONFORMANCE.md`](PPU_FW_CONFORMANCE.md)) | F2 |
| 7.6 | Denial handling: the policy is **reverted to the current mode** (PPU §4.1.1, §4.2.9); re-issue, with back-off; escalate past a deadline | **M** | `PPU_ISR[2]`, `PPU_AISR[2]`, `PPU_PWPR` | `pd_on_ppu_irq` | F2 |
| 7.7 | Lock a domain in `OFF`/`MEM_RET`; unlock by `PPU_UNLK` or by clearing `LOCK_EN`/`PWR_DYN_EN`; **the re-lock trap** (PPU §3.4.3, *Lock*; design doc §5.6.7) | **M** | `PPU_PWPR[12]`, `PPU_PWSR[12]`, `PPU_UNLK` | one-write unlock (a static policy clears `LOCK_EN`: `pd_request_static`, `pd_request_mode`); `ppu_unlock`. The lock itself was `pmu_top`'s `PD_OFF` state; soc4's PPUs have no lock | F2 |
| 7.8 | `PWR_DEVACTIVEEN`: disable the autonomous wake for `OFF`, **restore after power-up** (PPU §3.4.1, §4.1.3) | **M** | `PPU_PWCR[8]` | `ppu_set_devactive_en` | F2 |
| 7.9 | `DEVREQEN`: only in static mode with the target reached; re-enable only from `ON` (PPU §4.1.3) | **M** | `PPU_PWCR[0]` | `ppu_set_devreq_en` with the precondition asserted | F2 |
| 7.10 | `WARM_RST_DEVREQEN`: handshake or not on `ON ↔ WARM_RST` (PPU §4.2.5) | **M** | `PPU_PTCR[0]` | `ppu_set_warm_rst_devreq_en` | F5 |
| 7.11 | Interrupt service: masks suppress the status bit; W1C; set beats clear; `OTHER_IRQ` derived from `PPU_AISR`; level-sensitive output (PPU §4.1.2) | **M** | `PPU_IMR`, `PPU_AIMR`, `PPU_ISR`, `PPU_AISR` | `ppu_irq_status`, `ppu_irq_clear`, `ppu_irq_mask` | F1 |
| 7.12 | Input edge interrupt on `DEVQACTIVE` — how the SCP observes a wake attempt at a disarmed domain (PPU §4.1.3: enables have no effect on interrupt generation) | **M** | `PPU_IESR`, `PPU_ISR[8]` | `ppu_set_edge_irq` | F6 |
| 7.13 | Retention RAM configuration per mode → `PCSMPSTATE[15:8]` (PPU §5.2.16–18, Table 4-12; `REGISTERS.md` §4.5) | **M** | `PPU_FUNRR`, `PPU_FULRR`, `PPU_MEMRR` | `ppu_set_ret_ram` | F3 |
| 7.14 | Entry delay — the hysteresis before a dynamic transition to the floor (PPU §4.1.3, *Power Mode Entry Delay Timers*, and its examples; `REGISTERS.md` §4.6) | **M** | `PPU_EDTR0/1` | `ppu_set_entry_delay` | F3 |
| 7.15 | Device control delays, if `SW_DEV_DEL_SPT`; else read-only and the built-in values apply. **Required here**: with `PGOOD_EN = 0` and no switch acknowledge, they are what keeps clock and reset off a settling rail (README §6, rule 9) | **M** | `PPU_DCDR0/1` | `ppu_set_dev_delays`, programmed by `pd_init` | F2 ✅ |
| 7.16 | Live status for diagnosis: `DEVQACTIVE` raw, `DEVQDENY`/`DEVQACCEPTn`/`PCSMPACCEPT` | **M** | `PPU_DISR`, `PPU_MISR` | `ppu_dev_active`, `ppu_misc_status` | F2 |
| 7.17 | Timeout: the PPU waits for `PCSMPACCEPT` forever and has no power-good input (design doc §5.6.8) — **the firmware runs the deadline** | **M** | `PPU_PWSR` + `mtime` | `ppu_wait_mode(deadline)` | F2 |
| 7.18 | Intermediate transitions route through `ON`; `OFF → MEM_RET` is the one direct hop (PPU §3.3.2) — the manager must expect `PWR_STATUS = ON` mid-route | **M** | `PPU_PWSR` | `ppu_wait_mode` waits for the final value | F2 |
| 7.19 | `PPU_STSR` — which channel denied | **—** | reserved: single Q-Channel (PPU §5.2.6) | — | — |
| 7.20 | Operating modes (`PPU_OPSR`), emulation modes (`PPU_PMER`) | **—** | not built (`src/rtl/ppu/FUNCTIONS.md` §2, §1) | — | — |
| 7.21 | Bridge fault: `SLVERR` from `ppu_axi_lite_adapter` when the PPU clock does not arrive → load/store access fault | **M** | — | trap handler → `pd` FAULT | F1 |

**19 of 21 to build, 2 reserved by the configuration.**

## 8. RPMI v1.0 — the interface the AP uses

SCMI v3.0 was the earlier plan for this section and the next, superseded on
2026-09-30 by the decisions in
[`RPMI_STACK_DECISIONS.md`](../../Proposed_PMU/RPMI_STACK_DECISIONS.md), which
also records the alternatives not taken. The plan is [`README.md`](README.md)
§7. The AP is the only agent, OpenSBI speaks for it over two transports, T0a
and T0b, and librpmi v1.0.0 is the SCP's RPMI server. (soc4 builds one
transport, T0a, with BASE and DEVICE_POWER over its four domains; the
two-transport form ran on `pmu_top` until 2026-10-02. README §7.) Names are the RPMI v1.0
specification's; no message, service-group or state encoding is restated.
DEVICE_POWER, SYSTEM_RESET, SYSTEM_SUSPEND and HSM define no notification
events, so their `*_ENABLE_NOTIFICATION` services have nothing to enable.

### 8.1 Service groups

| Service group | | Transport | Here | Stage |
|---|:---:|---|---|---|
| BASE | **M** | T0a, T0b | discovery; built into every librpmi context | F4 |
| SYSTEM_RESET | **M** | T0a | cold reset and shutdown; no warm reset (§8.3) | F4 |
| DEVICE_POWER | **M** | T0b | the eight DSP and NPU domains; Linux reaches it through SBI MPXY (§8.2) | F4 |
| HSM | **O** | T0a | M2: one CPU domain per hart, no last-hart rule (§8.4) | F7 |
| SYSTEM_SUSPEND | **O** | T0a | M2: the CPU domains off, DDR powered (§8.4) | F7 |
| SYSTEM_MSI | **—** | | not used (decision record §2.3); there is no IMSIC | — |
| CPPC, PERFORMANCE | **—** | | no DVFS | — |
| CLOCK | **—** | | one clock; gating is not an SCP function (§6.4.1) | — |
| VOLTAGE | **—** | | one rail | — |
| MANAGEMENT_MODE, RAS_AGENT, REQUEST_FORWARD | **—** | | not in the plan | — |

### 8.2 DEVICE_POWER (T0b)

| # | Service or rule | | Here |
|---|---|:---:|---|
| 8.2.1 | `DPWR_GET_NUM_DOMAINS`, `DPWR_GET_ATTRIBUTES`; `DOMAIN_ID`s sequential from 0 | **M** | eight; the proposed IDs are 0–3 for DSP0–3 and 4–7 for NPU0–3, PPU `n − 4` |
| 8.2.2 | `DPWR_SET_STATE` to ON | **M** | powers the domain up and replies only once it is up, within a deadline; expiry is `FAULT` and an error reply. librpmi's DEVICE_POWER operations are synchronous, so the reply leaves when the operation returns |
| 8.2.3 | `DPWR_SET_STATE` to OFF | **M** | records the vote; the domain powers off after the hysteresis window. The request is static, so a busy device's adapter can refuse it (PPU Table 4-1, `STA_DENY`): back to ON, retried up to a cap, then forced. A negative test drives a busy device |
| 8.2.4 | `DPWR_GET_STATE`, described by the specification as *"the current power state"* | **M** | the agent's own last vote, never the physical state (decision record §2.2): librpmi v1.0.0 skips the platform call when `get_state` already equals the request, so a physical answer would lose an ON cast during an OFF's hysteresis window |
| 8.2.5 | Agreement before OFF: PPU §3.3.2's *"method other than the device interface Q-Channel"* | **M** | Linux's driver stops the accelerator, its cores held in reset, before voting OFF (`README.md` §5.3). The SCP only powers the domain; the accelerator's run control is Linux's |
| 8.2.6 | Vendor-specific power states (*Power State Format*) | **O** | none yet, and librpmi v1.0.0 reports only ON and OFF; the interior device rows of `README.md` §7.4 are the candidates |

### 8.3 SYSTEM_RESET (T0a)

Reset types are SBI SRST's; the specification supports cold reset and shutdown
by default.

| # | Service or reset | | Here |
|---|---|:---:|---|
| 8.3.1 | `SYSRST_GET_ATTRIBUTES` | **M** | cold reset and shutdown only |
| 8.3.2 | `SYSRST_RESET`, a posted request | **M** | no reply; librpmi's platform reset operation does not return |
| 8.3.3 | Cold reset | **M** | a cold-reset request from `scp_rstctl`, the SCP reset controller planned as W3.1 and not yet built ([`RPMI_STACK_DECISIONS.md`](../../Proposed_PMU/RPMI_STACK_DECISIONS.md) §2.4); a chip reset until the board hardware is defined (D10, A5). The SCP has no path to reset itself today |
| 8.3.4 | Shutdown | **M** | every domain to `OFF`, forced if needed, then `scp_rstctl`'s PMIC-off request |
| 8.3.5 | Warm reset | **O** | not offered (D20): every reboot is a cold reset. `WARM_RST` remains a per-domain recovery action (row 6.2) |

### 8.4 HSM and SYSTEM_SUSPEND (T0a, M2)

| # | Service | | Here |
|---|---|:---:|---|
| 8.4.1 | `HSM_HART_START` | **O** | `PD_CPUh` to `RUN`: the one-write unlock, then `PWR_DEVACTIVEEN` restored; the start address is OpenSBI's business |
| 8.4.2 | `HSM_HART_STOP` | **O** | `PD_CPUh` to `OFF`, wake disarmed, locked once reached. Answered once the policy is written and read back; the PPU completes the transition once the hart has set its READY bit and its bus has drained (`README.md` §5.3) |
| 8.4.3 | `HSM_HART_SUSPEND`, retentive | **O** | nothing, or the `FULL_RET` floor programmed once: `IDLE_STANDBY` is the clock controller, `IDLE_RETENTION` the PPU's dynamic policy (design doc §5.4.1, tiers 1–2) |
| 8.4.4 | `HSM_HART_SUSPEND`, non-retentive | **O** | `PD_CPUh` to `SLEEP`: `OFF`, wake armed. OpenSBI sets the hart's READY bit as its last store before WFI, after cleaning the cache, and hardware clears it on wake (D18) |
| 8.4.5 | `HSM_GET_HART_STATUS`, `HSM_GET_HART_LIST`, `HSM_GET_SUSPEND_TYPES`, `HSM_GET_SUSPEND_INFO` | **O** | a hart is SUSPENDED only while its READY bit is set |
| 8.4.6 | `SYSSUSP_GET_ATTRIBUTES`; `SYSSUSP_SUSPEND` to `SUSPEND_TO_RAM`, which presumes every other hart STOPPED | **O** | the CPU domains off; DDR stays powered, its controller and PHY always-on |

### 8.5 Transport

| # | Requirement | | Here |
|---|---|:---:|---|
| 8.5.1 | RPMI shared-memory queues: A2P REQ with P2A ACK, and P2A REQ with A2P ACK | **M** | at least A2P REQ and P2A ACK on each of T0a and T0b, in the queue SRAM (W2.1) |
| 8.5.2 | Slot size a power of 2, at least 64 bytes | **M** | 64 bytes |
| 8.5.3 | The shared memory mapped as I/O, coherent and non-cacheable, on both sides | **M** | the queue SRAM, always-on; that the CVA6 side maps it uncached is unverified |
| 8.5.4 | A2P doorbell: a 32-bit memory-mapped register the AP writes | **M** | one per transport, in `scp_mailbox` |
| 8.5.5 | P2A doorbell, optional: an implementation may poll instead | **—** | none; OpenSBI polls |
| 8.5.6 | Access control | **M** | a firewall that admits only the CVA6 cores (W2.1); M-mode versus S-mode separation from the AP's PMP (A14) |
| 8.5.7 | *"The messaging interface must be usable by any AP core"* (§6.4.1) | **M** | every hart reaches both transports through OpenSBI |
| 8.5.8 | Service order | **M** | T0a before T0b on every pass of the event loop (`README.md` §5.1) |

## 9. The SBI front end — OpenSBI

The AP's firmware interface is SBI, served by OpenSBI v1.9: there is no PSCI,
and no SCMI. The SCP never sees an SBI call. OpenSBI turns the ones that need
the SCP into RPMI requests on T0a, and serves DEVICE_POWER to Linux as an SBI
MPXY channel over T0b; this table says which SBI calls therefore land on the
SCP, and as what.

| SBI extension and function | Lands on the SCP as | | Here |
|---|---|:---:|---|
| BASE, TIME, IPI, RFENCE and the others not listed | nothing — AP-side. OpenSBI serves the timer from the always-on ACLINT MTIMER and M-mode IPIs through ACLINT MSWI | **—** | |
| SRST `sbi_system_reset`, shutdown or cold reboot | `SYSRST_RESET` on T0a (§8.3) | **M** | F4 |
| SRST `sbi_system_reset`, warm reboot | nothing: warm reset is not offered (D20), and Linux reboots cold by default | **O** | — |
| MPXY, on the DEVICE_POWER channel | `DPWR_*` on T0b (§8.2) | **M** | F4 |
| HSM `sbi_hart_start` | M1: nothing, as the SCP powered all four CPU domains at boot and OpenSBI starts the secondary harts by IPI. M2: `HSM_HART_START` | **M** / **O** | F5, F7 |
| HSM `sbi_hart_stop` | M1: nothing; the CPU domain stays ON. M2: `HSM_HART_STOP` | **O** | F7 |
| HSM `sbi_hart_suspend` | M1: nothing. M2: `HSM_HART_SUSPEND` (§8.4) | **O** | F7 |
| SUSP `sbi_system_suspend` | M2: `SYSSUSP_SUSPEND` | **O** | F7 |

---

## Summary

| Source | Items | M | O | — | ✓ / ◐ |
|---|---|:---:|:---:|:---:|:---:|
| PCSA §3.3.3 software interface | 6 | 1 | 1 | 4 | — |
| PCSA §3.3.3 system services | 3 (+5 event kinds) | 3 (+3) | — | (+1) | (+1) |
| PCSA §3.2.1 services | 8 | 3 | 1 | 2 | 2 |
| PCSA §6.4.1 SCP components | 14 | 7 | 4 | 4 | 2 |
| PCSA §5.3 coordination | 3 | — | — | 2 | 1 |
| PCSA §7.3.3, §7.2.1 reset and wake | 4 | 2 | — | 1 | 1 |
| PPU driver operations | 21 | 19 | — | 2 | — |
| RPMI service groups | 13 | 3 | 2 | 8 | — |
| RPMI DEVICE_POWER | 6 | 5 | 1 | — | — |
| RPMI SYSTEM_RESET | 5 | 4 | 1 | — | — |
| RPMI HSM and SYSTEM_SUSPEND | 6 | — | 6 | — | — |
| RPMI transport | 8 | 7 | — | 1 | — |
| SBI calls | 8 | 3 | 5 | 1 | — |

Three things the table makes visible:

1. **The PPU driver and the power domain manager are the bulk of the work**
   (rows 7.x and 2.3/3.3), and they are the part no specification writes for
   you: PCSA says *what* the SCP owns, the PPU specification says *how the
   registers behave*, and the design doc's §5.5–§5.6 is the only place the
   two are joined. The firmware checklist there (§5.6.9) is the driver's test
   plan.
2. **Most of what PCSA lists for an SCP is absent by design, not deferred.**
   DVFS, voltage, clock sources, SoC sleep, cluster coordination, the
   secondary counter, debug power — each row says why, and the reason is
   always one of: one rail, one clock, flat partition, always-on system logic.
   If any of those constraints is relaxed the corresponding rows come back.
3. **One agent means one vote per domain, and one RPMI detail decides whether
   a vote can be lost.** `DPWR_GET_STATE` reports the vote, not the physical
   state (row 8.2.4), because librpmi v1.0.0 skips the platform call when the
   two agree. The arbitration the retired SCMI plan needed for four
   requestors is gone.
