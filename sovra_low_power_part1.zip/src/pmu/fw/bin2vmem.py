#!/usr/bin/env python3
"""Flat binary -> $readmemh image of 32-bit little-endian words.

    bin2vmem.py <image.bin> <image.vmem>

scp_ram's array is `logic [31:0] mem [16384]` loaded with $readmemh, so every
line is one word, and word i holds bytes 4i..4i+3 with byte 4i in bits [7:0].

Written rather than borrowed, for two reasons recorded in src/pmu/README.md
Section 4: Ibex's own flow uses srec_cat, which is not installed here, and
`objcopy -O verilog` has changed both its addressing and its byte order across
binutils releases -- a ten-line script has neither problem. Python 3.6 is what
this machine has, so nothing newer is used.
"""
import sys

RAM_BYTES = 64 * 1024


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    with open(sys.argv[1], "rb") as f:
        data = f.read()
    if len(data) > RAM_BYTES:
        sys.exit("bin2vmem: image is %d bytes; the SCP RAM holds %d"
                 % (len(data), RAM_BYTES))
    data += b"\0" * (-len(data) % 4)
    with open(sys.argv[2], "w") as f:
        f.write("@00000000\n")
        for i in range(0, len(data), 4):
            f.write("%08x\n" % int.from_bytes(data[i:i + 4], "little"))
    print("bin2vmem: %s, %d words (%d bytes of %d)"
          % (sys.argv[2], len(data) // 4, len(data), RAM_BYTES))


if __name__ == "__main__":
    main()
