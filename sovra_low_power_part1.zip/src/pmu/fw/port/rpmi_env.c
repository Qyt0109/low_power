/* librpmi's environment on the SCP. See rpmi_env.h. */
#include <stdarg.h>
#include "rpmi_env.h"
#include "console.h"
#include "scp_regs.h"
#include "lib.h"

struct scp_env_stats scp_env_stats;

static uint8_t arena[SCP_ENV_ARENA_SIZE] __attribute__((aligned(SCP_ENV_ALIGN)));
static bool    sealed;

void scp_env_seal(void)
{
  sealed = true;
}

void *rpmi_env_zalloc(rpmi_size_t size)
{
  if (sealed) {
    scp_env_stats.late++;
    return NULL;
  }
  /* The arena and every block in it are multiples of SCP_ENV_ALIGN. So if the
     size fits what is left, the rounded-up size fits too, and the test comes
     before the rounding, which therefore cannot overflow. */
  if (size > SCP_ENV_ARENA_SIZE - scp_env_stats.used) {
    scp_env_stats.fails++;
    return NULL;
  }
  uint8_t *p = &arena[scp_env_stats.used];
  scp_env_stats.used += (size + SCP_ENV_ALIGN - 1u) & ~(SCP_ENV_ALIGN - 1u);
  scp_env_stats.allocs++;
  return memset(p, 0, size);
}

void rpmi_env_free(void *ptr)
{
  (void)ptr;
  scp_env_stats.frees++;
}

void rpmi_env_writel(rpmi_uint64_t addr, rpmi_uint32_t val)
{
  if (addr >> 32) {                 /* beyond the SCP's 32-bit address space */
    scp_env_stats.bad_addr++;
    return;
  }
  mmio_write32((uint32_t)addr, val);
}

int rpmi_env_printf(const char *format, ...)
{
  va_list ap;
  va_start(ap, format);
  con_vprintf(format, ap);
  va_end(ap);
  return 0;
}
