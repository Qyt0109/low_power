/* librpmi's environment on the SCP: the port.
 *
 * librpmi v1.0.0 (vendor/librpmi) asks its platform for four functions,
 * declared in include/librpmi_env.h:
 *
 *   rpmi_env_zalloc  :218  a bump arena, below. librpmi calls it only from
 *                          its *_create functions (and MM's registration,
 *                          not linked), never while a message is handled, so
 *                          the arena is filled once at boot and then sealed
 *                          (scp_env_seal)
 *   rpmi_env_free    :225  a counted no-op: the SCP destroys nothing. Only
 *                          librpmi's create-time failure paths call it
 *   rpmi_env_writel  :429  a 32-bit store. Its one caller is SYSTEM_MSI
 *                          (rpmi_service_group_sysmsi.c:296), linked only
 *                          because rpmi_context.c:412-414 names it. No
 *                          SYSTEM_MSI group is registered (the decisions,
 *                          Section 2.3), so nothing reaches this
 *   rpmi_env_printf  :449  the console (lib/console.h). Only LIBRPMI_DEBUG
 *                          builds call it; this build does not define that
 *
 * Everything else in that header is a static inline that the library carries
 * itself, so it cannot be replaced from here without editing the header:
 * memcpy, memset, strncpy and the rest (:70-168), the cache hooks (:187-199),
 * div32 and mod32 (:303-320), and the endian helpers. The locks are among
 * them and stay no-ops (:245-283): the SCP has one thread, and librpmi runs
 * only in it (rpmi/scp_loop.h).
 *
 * SHARED MEMORY uses librpmi's own simple ops (rpmi_shmem.c:54-58): plain
 * loads and stores through rpmi_env_memcpy and rpmi_env_memset. This is the
 * cache-coherent set, which is right because Ibex as scp_core.sv builds it
 * has no data cache (src/pmu/README.md Section 3). It has two consequences
 * for the queue memory that W2.1 builds:
 *
 *   - The memory must take byte writes. rpmi_env_memcpy copies one byte at a
 *     time (librpmi_env.h:96-107).
 *   - The 32-bit head and tail indices are also written one byte at a time.
 *     An AP that reads an index as one word still sees either the old value
 *     or the new one, but only while no index exceeds 255, because only the
 *     low byte then changes. A queue of N slots uses indices 0 to N - 3
 *     (rpmi_transport_shmem.c:248). SCP_RPMI_QUEUE_SLOTS is far below that.
 */
#ifndef RPMI_ENV_H
#define RPMI_ENV_H

#include <stdint.h>
#include <stdbool.h>
#include <librpmi.h>

#define SCP_ENV_SHMEM_OPS  (&rpmi_shmem_simple_ops)

/* THE ARENA. Every block is rounded up to SCP_ENV_ALIGN, the alignment rv32
 * gives a 64-bit member (struct rpmi_shmem's base is one). With 32-bit
 * pointers, and each size taken from the structs in vendor/librpmi/lib, the
 * allocations for rpmi/scp_rpmi.c's configuration are:
 *
 *   per transport  rpmi_shmem 32, rpmi_transport_shmem 52 -> 56,
 *                  its queue table 2 x 16 = 32                        120
 *   per context    rpmi_context 44 -> 48, its group table 3 x 4 -> 16,
 *                  request and ACK buffers 2 x SCP_RPMI_SLOT_SIZE,
 *                  the BASE group 44 -> 48                            240
 *   DEVICE_POWER   the group 48, plus 12 per domain, 4 domains         96
 *
 *   one agent, with DEVICE_POWER: 120 + 240 + 96 = 456 bytes in 10 blocks.
 *
 * The arena is SCP_ENV_PER_AGENT bytes per agent of the platform's agent table
 * (mod/agents.h), so adding an agent grows it with no edit here: soc4's two
 * agents use 912 of 1024 bytes. HSM and SYSTEM_SUSPEND, should they join a
 * context, allocate here too, and the arena may have to grow then. A full
 * arena makes scp_rpmi_init() fail, and the refusal is counted below. */
#include "agents.h"
#define SCP_ENV_ALIGN       8u
#define SCP_ENV_PER_AGENT   512u
#define SCP_ENV_ARENA_SIZE  (SCP_ENV_PER_AGENT * SCP_NUM_AGENTS)

struct scp_env_stats {
  uint32_t used;       /* arena bytes handed out                          */
  uint32_t allocs;     /* rpmi_env_zalloc calls that were served          */
  uint32_t fails;      /* ...that found the arena too full                */
  uint32_t late;       /* ...made after scp_env_seal(): each one means a
                          librpmi that allocates at run time               */
  uint32_t frees;      /* rpmi_env_free calls: create-time failures only  */
  uint32_t bad_addr;   /* rpmi_env_writel calls above 4 GiB, dropped      */
};
extern struct scp_env_stats scp_env_stats;

/* Creation is over: from now on rpmi_env_zalloc refuses, and counts. */
void scp_env_seal(void);

#endif
