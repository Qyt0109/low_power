# pmu/fw/port: librpmi's environment on the SCP

librpmi v1.0.0 asks its platform for four functions, declared in
`../vendor/librpmi/include/librpmi_env.h`. This folder implements them for the
SCP, so that librpmi itself stays unmodified. Part of the shared SCP firmware;
see [`../README.md`](../README.md).

## Files

| File | What it is |
|---|---|
| `rpmi_env.h` | The port's contract: what each function does here and why, the arena size, `SCP_ENV_SHMEM_OPS`, `scp_env_seal()` and `struct scp_env_stats` |
| `rpmi_env.c` | The four functions and the arena |

## The four functions

| Function (`librpmi_env.h` line) | On the SCP |
|---|---|
| `rpmi_env_zalloc` (:218) | A bump allocator over a static arena, zeroing each block and rounding it up to 8 bytes (`SCP_ENV_ALIGN`). librpmi calls it only from its `*_create` functions, so the arena is filled once at boot. After `scp_env_seal()` every call is refused and counted in `scp_env_stats.late` |
| `rpmi_env_free` (:225) | A counted no-op. Only librpmi's create-time failure paths call it |
| `rpmi_env_writel` (:429) | A 32-bit store; an address above 4 GiB is dropped and counted. Its one caller is SYSTEM_MSI, which is linked but not registered, so nothing reaches it |
| `rpmi_env_printf` (:449) | The console (`../lib/console.h`). Only `LIBRPMI_DEBUG` builds call it, and this build does not define that |

Everything else in `librpmi_env.h` is a static inline that librpmi carries
itself (`memcpy`, `memset`, the locks, the cache hooks, `div32`, the endian
helpers), and cannot be replaced from here without editing the header. The
locks stay no-ops: the SCP has one thread, and librpmi runs only in it.

## Rules and sizes

- **The arena is `SCP_ENV_PER_AGENT` = 512 bytes per agent** of the platform's
  agent table (`SCP_ENV_ARENA_SIZE = 512 * SCP_NUM_AGENTS`), so adding an agent
  grows it with no edit here. One agent with DEVICE_POWER over four domains
  takes 456 bytes in 10 blocks (the breakdown is in `rpmi_env.h`); soc4's two
  agents use 912 of 1024. Adding HSM or SYSTEM_SUSPEND to a context allocates
  here too and may need a larger arena. A full arena makes `scp_rpmi_init()`
  fail, and `scp_env_stats.fails` counts the refusal.
- **Seal after creation.** `rpmi/scp_rpmi.c` calls `scp_env_seal()` once every
  transport, context and group exists. A non-zero `scp_env_stats.late` means a
  librpmi version that allocates at run time.
- **Shared memory uses librpmi's simple ops** (`SCP_ENV_SHMEM_OPS` =
  `&rpmi_shmem_simple_ops`): plain loads and stores, which is correct because
  the SCP's Ibex has no data cache. The queue memory must therefore accept
  byte writes. The 32-bit head and tail indices are also written one byte at a
  time, which an agent reading a whole word sees atomically only while no index
  exceeds 255. With `SCP_RPMI_QUEUE_SLOTS` = 8 the largest index is 5.

## Build and use

Linked into `soc4_scp` and `soc4_scp_m6` only, with `-I` for this folder and
for `vendor/librpmi/include` ([`src/soc4/fw/Makefile`](../../../soc4/fw/Makefile)).
The AP image has its own environment (`src/soc4/fw/ap/ap_env.c`).

## References

- librpmi v1.0.0: `include/librpmi_env.h` (the environment functions),
  `lib/rpmi_shmem.c:54-58` (the simple shared-memory ops), and
  `lib/rpmi_transport_shmem.c:248` (the index range).
- [`../rpmi/README.md`](../rpmi/README.md): the server that creates the
  transports and contexts.
