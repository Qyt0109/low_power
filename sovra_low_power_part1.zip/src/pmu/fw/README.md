# pmu/fw: the shared SCP firmware

The bare-metal firmware of the System Control Processor. It runs on the Ibex
core of [`../rtl/scp_top.sv`](../rtl/README.md), from the SCP's private 64 KB
RAM, in machine mode, on one thread with no RTOS. It drives the PPUs over
AXI4-Lite, takes every interrupt through the `scp_irq` block, serves RPMI
(BASE and DEVICE_POWER) to each agent through librpmi v1.0.0, and kicks the
SCP watchdog once per pass of its main loop.

These sources are platform-independent in shape. The platform comes from
**one header that every compile force-includes** (`-include`). For soc4 that
header is [`src/soc4/fw/soc4_plat.h`](../../soc4/fw/soc4_plat.h). This folder
has no Makefile: [`src/soc4/fw/Makefile`](../../soc4/fw/Makefile) is the only
firmware build in the repository, and it also supplies the boot code
(`soc4/fw/scp/main.c`) and the test programs.

The design rationale (the event loop, the PPU driver's rules, the toolchain
constraints) is in [`../README.md`](../README.md) §4–6. The record of what the
firmware does against DEN 0051E is [`../PPU_FW_CONFORMANCE.md`](../PPU_FW_CONFORMANCE.md).

## Layers

```
 soc4/fw/scp/main.c         boot (watchdog, interrupt block, PPUs, mailbox, RPMI), then scp_loop_run()
 rpmi/   scp_loop           the main loop: doorbells, librpmi, policy work, sleep, watchdog kick
         scp_rpmi           the RPMI server: one librpmi transport and context per agent, votes
 port/   rpmi_env           librpmi's environment functions (allocator, console)
 vendor/ librpmi            librpmi v1.0.0, unmodified
 mod/    policy             the DEVICE_POWER policy: power-up, hysteresis, deny/retry/force, faults
         pd                 the power domain manager: one domain per PPU, non-blocking requests
         flog               the fault log and the votes, kept across a watchdog reset
         agents.h           the agent indices
 hal/    ppu_v1 scp_irq rpmi_db timer trap scp_wdog sim csr scp_regs
 lib/    console string     printf to the console, memcpy and friends
 crt0.S  link.ld            vectors, reset, memory layout
```

## Files

| File or folder | What it is |
|---|---|
| `crt0.S` | The vector table (32 four-byte jumps at 0: exceptions at `0x00`, timer at `0x1C`, external at `0x2C`, NMI at `0x7C`, every other line to `trap_unexpected`) and the reset code at `0x80`: set `sp`, copy `.data` from its load copy, clear `.bss`, call `main`. If `main` returns (only test programs do), its value is written to the testbench's HALT register (`0x0002_0008`) |
| `link.ld` | The memory layout, below. Asserts the vector table's size and position, a stack of at least 4 KB, the persistent block's size, and that no relocation survives |
| `bin2vmem.py` | Flat binary to a `$readmemh` image of 32-bit little-endian words from `@00000000`, for `scp_ram`. Refuses an image larger than 64 KB. Python 3.6 compatible |
| [`hal/`](hal/README.md) | Register drivers: the PPU, the interrupt block, the RPMI doorbells, the timer, traps, the watchdog, the testbench's simulation control |
| [`lib/`](lib/README.md) | The C library subset the firmware needs (no libc is linked) and the console |
| [`mod/`](mod/README.md) | The power domain manager, the DEVICE_POWER policy, the fault log, the agent indices |
| [`port/`](port/README.md) | librpmi's environment on the SCP |
| [`rpmi/`](rpmi/README.md) | The RPMI server and the main loop |
| [`vendor/`](vendor/README.md) | librpmi v1.0.0, vendored verbatim |

## Memory layout (`link.ld`)

| Address | Contents |
|---|---|
| `0x0000_0000` | `.vectors`, exactly `0x84` bytes: 32 jumps, then the reset jump at `0x80` |
| after it | `.text`, `.rodata`, `.data` (its run-time address) and then `.data`'s load copy |
| after the load copy | `.bss` (not in the image; `crt0.S` clears it) |
| up to `0xFC00` | the stack, growing down from `_stack_top = 0xFC00` |
| `0xFC00`–`0xFFFF` | `.persist`, 1 KB: `struct scp_keep` (`mod/flog.h`). `crt0.S` neither loads nor clears it, so it outlives a watchdog reset |

`.data` has a load copy because a watchdog reset restarts the core without
reloading the RAM. `crt0.S` restores the initial values at every reset.

## Rules that hold across the firmware

1. **Interrupt handlers only record.** The timer handler acknowledges (a
   write to `mtimecmp`) and counts. The external handler (line 11, the
   `scp_irq` block) clears `mie.MEIE`, sets `trap_ext_pending` and touches no
   device. `scp_irq_collect()`, called from `pd_poll()` in thread context,
   reads the block (`hal/trap.h`, `hal/scp_irq.h`).
2. **librpmi is called only from the main loop**, and a pass runs with
   `mstatus.MIE` clear. Interrupts are taken only in the window just after the
   WFI, so no handler ever runs inside librpmi (`rpmi/scp_loop.h`).
3. **The watchdog is kicked only at the end of a completed pass**, never from
   an interrupt (`hal/scp_wdog.h`, `rpmi/scp_loop.c`).
4. **No pass waits on an agent.** The queue guard in `rpmi/scp_rpmi.c` stops
   librpmi's two unbounded loops, and a drain takes at most
   `SCP_RPMI_DRAIN_BUDGET` requests.
5. **Freestanding.** No libc, no libgcc, no 64-bit division and no variable
   64-bit shift: this toolchain has no rv32 soft-float multilib
   ([`../README.md`](../README.md) §4). Deadlines are `now + ticks`, compared
   with `>=`.
6. **The platform header has no defaults here.** A shared file that needs a
   platform macro stops the build with `#error` if it is missing.

## The platform header

| Macro | Used by | What it gives |
|---|---|---|
| `SCP_NUM_PPU` | `hal/scp_regs.h`, `mod/pd.h` | the number of PPU slots the firmware drives (soc4: 4). `PD_COUNT` is this |
| `SCP_PLAT_DOMAINS(D)` | `mod/pd.c`, `rpmi/scp_rpmi.c` | the domain table: one `D(name, latency, fields)` per domain in DOMAIN_ID order, with `struct pd_cfg` fields (`mod/pd.h`) |
| `SCP_PLAT_INPUTS(I)` | `hal/scp_irq.c`, `soc4/fw/scp/main.c` | the input table: one `I(id, name, mode, en, act, arg)` per input of `scp_irq`, in input order |
| `SCP_PLAT_AGENTS(A)` | `mod/agents.h`, `rpmi/scp_rpmi.c` | the agent table: one `A(id, name, window, db_in, src, mask, groups)` per RPMI agent, in transport order |
| `SCP_PLAT_WDOG_TIMEOUT` | `rpmi/scp_loop.h` | the watchdog timeout in SCP cycles (soc4: `0x0020_0000`, about 21 ms at 100 MHz) |
| `SCP_PLAT_CKRST_STAT(d)` | `mod/policy.c` | optional: the address of the clock/reset bridge status word holding domain `d`'s byte. Without it, a `SCP_ACT_CKRST` input only prints a line |

Two shared files still name soc4 directly. `hal/rpmi_db.c` uses the mailbox
registers of `soc4/fw/hal/soc4_regs.h`, and `mod/policy.c` uses the CPU cold-boot
loader of `soc4/fw/mod/soc4_cpu.h`. A second platform would supply its own
versions of those two headers, or its own doorbell backend.

## Build

From `src/`:

```
make soc4fw            # runs make -C soc4/fw OUT=build/fw/soc4
```

Each image produces `<name>.elf`, `.bin`, `.vmem` (the RAM image), `.dis` and
`.map` in `build/fw/soc4/`, and the build prints each image's size and stack
headroom. The compile uses
`-march=rv32imc_zicsr_zifencei -mabi=ilp32 -Os -ffreestanding -nostdlib
-fno-tree-loop-distribute-patterns -ffunction-sections -fdata-sections`, and the
link uses `link.ld`, `--gc-sections` and `--orphan-handling=error`. The
Makefile header explains each flag.

Which images use what (every source list in the Makefile is explicit):

| Image | Uses from here | Run by |
|---|---|---|
| `soc4_scp` | everything: `crt0.S`, `lib/`, `hal/` (all `.c`), `mod/pd.c`, `mod/policy.c`, `mod/flog.c`, `port/`, `rpmi/`, six librpmi files | `make soc4`, `soc4bfm`, `soc4ckrst`, `soc4pa`, `soc4bfmpa`, `soc4neg` |
| `soc4_scp_m6` | as `soc4_scp`, built with `-DSCP_MUT_PERM_OPEN` (the per-domain permission check bypassed). A planted mutant, never a product image | `make soc4neg` (M6) |
| `soc4_stress` | `crt0.S`, `lib/`, `hal/ppu_v1.c`, `timer.c`, `trap.c`, `scp_irq.c`, `mod/pd.c`, with `soc4/fw/test/soc4_stress.c`. No RPMI | `make soc4stress`, `soc4stresspa` |
| `soc4_wdog` | `crt0.S`, `lib/`, `hal/timer.c`, `trap.c`, `mod/flog.c`, with `soc4/fw/test/soc4_wdog.c` | `make soc4wdog` |
| `soc4_ap` | `crt0.S`, `link.ld`, `lib/`, `hal/trap.c`, `timer.c`, and librpmi's transport layer (three files), with `soc4/fw/ap/`. The AP is an RPMI agent, not a server | the AP of `make soc4` |

## Extending

All of these are edits to the platform header, plus the matching hardware.
`soc4_plat.h`'s header and `SOVRA_PCSA_ARCHITECTURE.md` §15.3 list the hardware
side.

- **A domain:** one `D(...)` entry in `SCP_PLAT_DOMAINS`, its PPU's
  `I(..., SCP_ACT_PPU, n)` entry in `SCP_PLAT_INPUTS`, and `SCP_NUM_PPU`.
- **An interrupt or wake input:** one `I(...)` entry, at the index of the
  wire in the top level's `irq_i` (see [`../rtl/README.md`](../rtl/README.md)).
- **An agent:** one `A(...)` entry in `SCP_PLAT_AGENTS`, its doorbell's
  `I(..., SCP_ACT_DOORBELL, k)` entry, and its bit in the `.agents` of each
  domain it may vote for.

Limits to check when growing: at most 32 inputs (`scp_irq`'s registers), 16
PPU slots (the demux), 8 agents (`mod/agents.h`; a domain's `.agents` is a
byte), and 4 doorbell inputs (`SCP_IRQ_MAX_DB` in `hal/scp_irq.c`; a doorbell
entry with a larger `arg` is not recorded, and the boot check in
`soc4/fw/scp/main.c` fails). The RPMI arena is 512 bytes per agent
(`port/rpmi_env.h`), and the persistent block must stay within 1 KB:
`struct scp_keep` grows by one byte per agent per domain (`mod/flog.h`).
A larger watchdog timeout may be needed as well: `soc4/fw/scp/main.c` checks
at compile time that `SCP_PLAT_WDOG_TIMEOUT` covers the longest pass.

## References

- Arm PCSA, DEN 0050D, §3.2 and §6.4.1 (the SCP, its private memory, timers,
  watchdog and messaging interface).
- Arm PPU Architecture v1.1, DEN 0051E (the driver; see [`hal/`](hal/README.md)).
- RPMI v1.0 (`riscv-non-isa/riscv-rpmi`, tag `v1.0`), and librpmi v1.0.0 in
  [`vendor/librpmi/`](vendor/librpmi/README.md).
- [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)
  §14–15 (the platform plan: H7–H9, F10 inputs; H11–H13, F6 agents; H18, F12
  watchdog and fault log; F5 the domain table) and
  [`Proposed_PMU/RPMI_STACK_DECISIONS.md`](../../../Proposed_PMU/RPMI_STACK_DECISIONS.md).
- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../../docs/PMU_SOFTWARE_CONTRACT.md): what
  the agents see.
- [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md) §9: the soc4 firmware design.
