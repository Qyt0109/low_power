/* The SCP's main loop: the one thread librpmi runs in.
 *
 * Proposed_PMU/RPMI_STACK_DECISIONS.md Section 2.5, "Runtime", sets four
 * rules: librpmi is called only from here; interrupt handlers only set flags;
 * rpmi_context_process_all_events() runs on every pass; and transports are
 * serviced in order (one per agent of the platform's agent table; soc4: the
 * AP's, then the RPU's). One pass does five things, in
 * this order:
 *
 *   1. The doorbells, in transport order. For each one that rang, the pass
 *      clears its status bit and then drains that transport's A2P queue with
 *      scp_rpmi_drain(): rpmi_context_process_a2p_request() under the queue
 *      guard (scp_rpmi.h). The drain goes on until the queue is empty or the
 *      guard stops it, and each request is answered before the next is read.
 *      A transport the guard stopped is pending, and the next pass drains it
 *      again whether it rings or not.
 *   2. rpmi_context_process_all_events() on every context, transport 0 first. No group
 *      linked today has events. HSM and SYSTEM_SUSPEND will
 *      (rpmi_service_group_hsm.c:339, rpmi_service_group_syssusp.c:251).
 *   3. The hooks: power-domain and policy work, and then deadlines. mod/pd's
 *      non-blocking form and the policy (mod/policy.c) go here.
 *   4. WFI, unless a doorbell rang, an interrupt input's action became due
 *      or a drain stopped at its budget (SCP_RPMI_BUDGET) during the pass.
 *      The sleep lasts until an interrupt, until the next deadline, or, with a
 *      polled doorbell backend (rpmi_db.h), a transport pending or a level
 *      input waiting to be re-armed (hal/scp_irq.h), until
 *      SCP_LOOP_POLL_TICKS have passed; and never longer than
 *      SCP_LOOP_KICK_TICKS.
 *   5. The watchdog's kick (hal/scp_wdog.h). Only here: a pass that never
 *      completes -- a wait with no end, a loop with no exit -- stops the kicks
 *      and the watchdog resets the SCP. No interrupt handler kicks.
 *
 * THE WATCHDOG'S TIMEOUT (the platform header's SCP_PLAT_WDOG_TIMEOUT) must
 * cover the longest time between two kicks that is not a hang: the sleep at
 * the end of one pass (at most SCP_LOOP_KICK_TICKS, an eighth of it) plus the
 * work of the next. scp/main.c checks it at compile time against the drain
 * budget (SCP_RPMI_DRAIN_BUDGET requests per transport), the input table's
 * power-ups, and the policy's power-up deadline, each of which bounds a
 * synchronous ON.
 *
 * A pass runs with mstatus.MIE clear. Interrupts are taken only just after the
 * WFI, which is the pattern mod/pd.c's pd_idle uses. So no handler ever runs
 * in the middle of librpmi.
 *
 * NOTHING IN A PASS WAITS ON AN AGENT. Left alone, librpmi would: it retries an
 * ACK for as long as the P2A queue is full (rpmi_context.c:403-405), and it
 * drains until the A2P head reaches whatever tail the agent wrote
 * (rpmi_context.c:327). The queue guard (scp_rpmi.h) ends both. The pass
 * counts each drain the guard ends, in held[] when the agent left no room for an
 * ACK and in faults[] when an index is out of range, and the transport stays
 * pending until the agent reads its ACKs or puts the index right. The agent rings
 * nothing when it does either, so while a transport is pending the sleep is
 * bounded, as it is with a polled doorbell.
 */
#ifndef SCP_LOOP_H
#define SCP_LOOP_H

#include <stdint.h>
#include "scp_rpmi.h"

/* The longest a pass sleeps with a polled doorbell backend, in mtime ticks.
 * The same bound, for the same reason, as mod/pd.c's PD_POLL_TICKS. */
#define SCP_LOOP_POLL_TICKS  512u
#define SCP_LOOP_NEVER       UINT64_MAX

#ifndef SCP_PLAT_WDOG_TIMEOUT
#error "the platform header must define SCP_PLAT_WDOG_TIMEOUT (the watchdog's timeout)"
#endif
#define SCP_LOOP_KICK_TICKS  (SCP_PLAT_WDOG_TIMEOUT / 8u)

struct scp_loop_hooks {
  void     (*work)(void);       /* power-domain and policy work              */
  uint64_t (*deadline)(void);   /* expire what is due, and return the next
                                   deadline in mtime ticks or SCP_LOOP_NEVER */
};

struct scp_loop_stats {
  uint32_t passes;
  uint32_t rang[SCP_NUM_XPORT];     /* doorbells serviced, per transport       */
  uint32_t held[SCP_NUM_XPORT];     /* drains the guard ended for want of room
                                       for an ACK (SCP_RPMI_ACK_FULL)          */
  uint32_t faults[SCP_NUM_XPORT];   /* ...and on a bad index (_BAD_INDEX)      */
  uint32_t budget[SCP_NUM_XPORT];   /* ...and at the drain budget (_BUDGET)    */
  uint32_t sleeps;                  /* passes that ended in WFI                */
  uint32_t pending;                 /* bit t: transport t is drained next pass,
                                       rung or not                             */
};
extern struct scp_loop_stats scp_loop_stats;

void scp_loop_init(const struct scp_loop_hooks *hooks);   /* after scp_rpmi_init() */
void scp_loop_pass(void);
void scp_loop_run(void) __attribute__((noreturn));

#endif
