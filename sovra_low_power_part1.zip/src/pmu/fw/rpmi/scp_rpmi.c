/* The RPMI server. See scp_rpmi.h. */
#include "scp_rpmi.h"
#include "rpmi_env.h"
#include "pd.h"
#include "scp_irq.h"
#include "flog.h"
#include "lib.h"

struct scp_rpmi_stats scp_rpmi_stats;

/* THE AGENT TABLE, from the platform header (mod/agents.h). */
#define SCP_AGENT_CFG(id, nm, win, db, sv, mk, gr) \
  { .name = nm, .window = (win), .db_in = (db), .src = (sv), .mask = (mk), .groups = (gr) },
const struct scp_agent scp_agent[] = { SCP_PLAT_AGENTS(SCP_AGENT_CFG) };
#undef SCP_AGENT_CFG
_Static_assert(ARRAY_SIZE(scp_agent) == SCP_NUM_AGENTS, "one entry per agent");

static struct rpmi_context         *ctx[SCP_NUM_XPORT];
static const struct scp_rpmi_hooks *hooks;

/* ===========================================================================
 * DEVICE_POWER, see scp_rpmi.h
 * ========================================================================= */
/* One DEVICE_POWER domain per entry of the domain table (mod/pd.h), with its
 * name and transition latency. struct rpmi_dpwr_data holds the name as an array
 * (LR include/librpmi.h:1634-1639), so it is filled from the table's own
 * entries at compile time rather than from pd_cfg[]. */
#ifndef SCP_PLAT_DOMAINS
#error "the platform header must define SCP_PLAT_DOMAINS"
#endif
#define SCP_DPWR_COUNT PD_COUNT
#define DPWR_DATA(nm, latency, ...) { .trans_latency = (latency), .name = nm },
static const struct rpmi_dpwr_data dpwr_data[] = { SCP_PLAT_DOMAINS(DPWR_DATA) };
#undef DPWR_DATA
_Static_assert(ARRAY_SIZE(dpwr_data) == SCP_DPWR_COUNT, "one DEVICE_POWER domain per PPU");

/* One vote per agent per domain (scp_rpmi.h, VOTES AND PERMISSIONS), kept in
   the block that survives a watchdog reset (mod/flog.h): 1 = ON, 0 = OFF.
   Every change is followed by flog_commit(). */
#define VOTE(k, id) scp_keep.votes[(k) * SCP_DPWR_COUNT + (id)]

static void vote_set(unsigned k, rpmi_uint32_t id, bool on)
{
  VOTE(k, id) = on ? 1u : 0u;
  flog_commit();
}

/* May agent k vote for domain id? soc4neg M6 (SCP_MUT_PERM_OPEN, the
   soc4_scp_m6 image) bypasses the check. */
static bool permitted(unsigned k, rpmi_uint32_t id)
{
#ifdef SCP_MUT_PERM_OPEN
  (void)k; (void)id;
  return true;
#else
  return (pd_cfg[id].agents >> k) & 1u;
#endif
}

/* Does an agent other than k vote ON for domain id? */
static bool others_on(unsigned k, rpmi_uint32_t id)
{
  for (unsigned j = 0; j < SCP_NUM_AGENTS; j++)
    if (j != k && VOTE(j, id)) return true;
  return false;
}

/* ops_priv is the asking agent's index (scp_rpmi_init). */
static enum rpmi_error dpwr_get(void *priv, rpmi_uint32_t id, rpmi_uint32_t *state)
{
  const unsigned k = (unsigned)(uintptr_t)priv;
  if (id >= SCP_DPWR_COUNT || k >= SCP_NUM_AGENTS) return RPMI_ERR_INVALID_PARAM;
  if (!permitted(k, id)) {
    scp_rpmi_stats.dpwr_denied++;
    return RPMI_ERR_DENIED;
  }
  *state = VOTE(k, id) ? RPMI_DPWR_STATE_ON : RPMI_DPWR_STATE_OFF;
  return RPMI_SUCCESS;
}

static enum rpmi_error dpwr_set(void *priv, rpmi_uint32_t id, rpmi_uint32_t state)
{
  const unsigned k = (unsigned)(uintptr_t)priv;
  scp_rpmi_stats.dpwr_set++;
  /* librpmi passes the requested state through without checking it
     (rpmi_service_group_device_power.c:297-306). The only states are ON and
     OFF (librpmi.h:1620-1625). */
  if (id >= SCP_DPWR_COUNT || k >= SCP_NUM_AGENTS ||
      (state != RPMI_DPWR_STATE_ON && state != RPMI_DPWR_STATE_OFF))
    return RPMI_ERR_INVALID_PARAM;
  /* librpmi asked dpwr_get first, which refused an agent without permission;
     this is the set path's own guard. */
  if (!permitted(k, id)) {
    scp_rpmi_stats.dpwr_denied++;
    return RPMI_ERR_DENIED;
  }
  /* librpmi calls set_state only when the request differs from this agent's
     vote (rpmi_service_group_device_power.c:128-131). With no other agent ON,
     the combined vote therefore changes with this one: tell the policy. */
  if (!others_on(k, id) && hooks && hooks->dpwr_vote) {
    int rc = hooks->dpwr_vote(id, state);
    if (rc) return (enum rpmi_error)rc;
  }
  vote_set(k, id, state == RPMI_DPWR_STATE_ON);
  return RPMI_SUCCESS;
}

void scp_rpmi_dpwr_wake_vote(uint32_t id)
{
  if (id >= SCP_DPWR_COUNT) return;
  for (unsigned k = 0; k < SCP_NUM_AGENTS; k++)
    if ((pd_cfg[id].agents >> k) & 1u) {      /* the wake owner: the lowest */
      vote_set(k, id, true);
      return;
    }
}

bool scp_rpmi_dpwr_voted(uint32_t id)
{
  if (id >= SCP_DPWR_COUNT) return false;
  for (unsigned k = 0; k < SCP_NUM_AGENTS; k++)
    if (VOTE(k, id)) return true;
  return false;
}

void scp_rpmi_dpwr_drop(uint32_t id)
{
  if (id >= SCP_DPWR_COUNT) return;
  for (unsigned k = 0; k < SCP_NUM_AGENTS; k++) VOTE(k, id) = 0u;
  flog_commit();
}

static const struct rpmi_dpwr_platform_ops dpwr_ops = {
  .get_state = dpwr_get,
  .set_state = dpwr_set,
};

/* ===========================================================================
 * The queue guard: see scp_rpmi.h
 * ========================================================================= */
/* librpmi's layout: the A2P request queue from offset 0 and the P2A ACK queue
   after it (rpmi_transport_shmem.c:236-247), each with its head index in slot 0
   and its tail in slot 1, as little-endian words (:38-53). */
#define A2P_BASE  0u
#define P2A_BASE  SCP_RPMI_QUEUE_SIZE

struct guard {
  struct rpmi_transport *tr;
  struct rpmi_shmem     *sh;
  /* librpmi's own callbacks, which the wrappers call */
  rpmi_bool_t     (*is_empty)(struct rpmi_transport *, enum rpmi_queue_type);
  rpmi_bool_t     (*is_full)(struct rpmi_transport *, enum rpmi_queue_type);
  enum rpmi_error (*enqueue)(struct rpmi_transport *, enum rpmi_queue_type,
                             const struct rpmi_message *);
  enum scp_rpmi_hold hold;    /* is_empty's latest verdict on the A2P queue */
  unsigned taken;             /* requests this drain has let through        */
};

static struct guard guards[SCP_NUM_XPORT];

static struct guard *guard_of(const struct rpmi_transport *tr)
{
  for (unsigned t = 0; t < SCP_NUM_XPORT; t++)
    if (guards[t].tr == tr) return &guards[t];
  return NULL;
}

static bool index_ok(const struct guard *g, uint32_t off)
{
  rpmi_uint32_t v;
  return rpmi_shmem_read(g->sh, off, &v, sizeof v) == RPMI_SUCCESS &&
         rpmi_to_le32(v) < SCP_RPMI_QUEUE_DATA;
}

static bool queue_ok(const struct guard *g, uint32_t base)   /* head and tail */
{
  return index_ok(g, base) && index_ok(g, base + SCP_RPMI_SLOT_SIZE);
}

static rpmi_bool_t guard_is_empty(struct rpmi_transport *tr, enum rpmi_queue_type q)
{
  struct guard *g = guard_of(tr);
  if (!g) return true;
  if (q != RPMI_QUEUE_A2P_REQ) return g->is_empty(tr, q);

  if (!queue_ok(g, A2P_BASE) || !queue_ok(g, P2A_BASE)) g->hold = SCP_RPMI_BAD_INDEX;
  else if (g->is_empty(tr, q))                           g->hold = SCP_RPMI_DRAINED;
  else if (g->is_full(tr, RPMI_QUEUE_P2A_ACK))           g->hold = SCP_RPMI_ACK_FULL;
  else if (g->taken >= SCP_RPMI_DRAIN_BUDGET)            g->hold = SCP_RPMI_BUDGET;
  else {
    g->taken++;
    /* A request is read next. Should that read fail, the drain ends without
       asking here again, so until it asks the verdict is a fault. */
    g->hold = SCP_RPMI_BAD_INDEX;
    return false;
  }
  return true;
}

static rpmi_bool_t guard_is_full(struct rpmi_transport *tr, enum rpmi_queue_type q)
{
  if (q == RPMI_QUEUE_P2A_ACK) return false;     /* guard_enqueue decides */
  struct guard *g = guard_of(tr);
  return g ? g->is_full(tr, q) : true;
}

static enum rpmi_error guard_enqueue(struct rpmi_transport *tr, enum rpmi_queue_type q,
                                     const struct rpmi_message *msg)
{
  struct guard *g = guard_of(tr);
  if (!g) return RPMI_ERR_FAILED;
  if (q == RPMI_QUEUE_P2A_ACK && (!queue_ok(g, P2A_BASE) || g->is_full(tr, q))) {
    scp_rpmi_stats.ack_dropped[g - guards]++;
    return RPMI_ERR_FAILED;
  }
  return g->enqueue(tr, q, msg);
}

static bool guard_install(struct guard *g, struct rpmi_transport *tr, struct rpmi_shmem *sh)
{
  if (!tr->is_empty || !tr->is_full || !tr->enqueue) return false;
  g->tr        = tr;
  g->sh        = sh;
  g->is_empty  = tr->is_empty;
  g->is_full   = tr->is_full;
  g->enqueue   = tr->enqueue;
  tr->is_empty = guard_is_empty;
  tr->is_full  = guard_is_full;
  tr->enqueue  = guard_enqueue;
  return true;
}

enum scp_rpmi_hold scp_rpmi_drain(unsigned t)
{
  if (t >= SCP_NUM_XPORT || !ctx[t]) return SCP_RPMI_DRAINED;
  guards[t].hold  = SCP_RPMI_DRAINED;
  guards[t].taken = 0;
  rpmi_context_process_a2p_request(ctx[t]);
  return guards[t].hold;
}

/* ===========================================================================
 * Creation
 * ========================================================================= */
struct rpmi_context *scp_rpmi_ctx(unsigned t)
{
  return (t < SCP_NUM_XPORT) ? ctx[t] : NULL;
}

int scp_rpmi_init(const struct scp_rpmi_hooks *h)
{
  hooks = h;
  /* The votes are not reset here: they are what flog_boot() kept across a
     watchdog reset, or all OFF in a new block. */

  for (unsigned t = 0; t < SCP_NUM_XPORT; t++) {
    const struct scp_agent *a = &scp_agent[t];
    struct rpmi_shmem *sh = rpmi_shmem_create(a->name, a->window, SCP_RPMI_SHMEM_SIZE,
                                              SCP_ENV_SHMEM_OPS, NULL);
    if (!sh) return SCP_RPMI_E_SHMEM;
    /* p2a_req_queue_size 0: A2P requests and P2A acknowledgements only. */
    struct rpmi_transport *tr = rpmi_transport_shmem_create(a->name, SCP_RPMI_SLOT_SIZE,
                                                            SCP_RPMI_QUEUE_SIZE, 0, sh);
    if (!tr || !guard_install(&guards[t], tr, sh)) return SCP_RPMI_E_TRANSPORT;
    /* There is no platform information string, so GET_PLATFORM_INFO answers
       with length 0. */
    ctx[t] = rpmi_context_create(a->name, tr, SCP_CTX_GROUPS, RPMI_PRIVILEGE_M_MODE, 0, NULL);
    if (!ctx[t]) return SCP_RPMI_E_CONTEXT;

    /* DEVICE_POWER beside BASE: this agent's own instance, whose ops_priv
       tells the callbacks who asks. */
    if (a->groups & SCP_GRP_DPWR) {
      struct rpmi_service_group *g =
        rpmi_service_group_dpwr_create(SCP_DPWR_COUNT, dpwr_data, &dpwr_ops, (void *)(uintptr_t)t);
      if (!g || rpmi_context_add_group(ctx[t], g) != RPMI_SUCCESS) return SCP_RPMI_E_GROUP;
    }
  }

  scp_env_seal();
  return SCP_RPMI_OK;
}
