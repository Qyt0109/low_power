/* The RPMI server: librpmi v1.0.0, one shared-memory transport per agent.
 *
 * Proposed_PMU/RPMI_STACK_DECISIONS.md Section 2.2, as soc4 narrows it
 * (docs/SOC4_DESIGN.md Sections 9.1 and 9.7), with the platform
 * plan's PD6 and F6 (SOVRA_PCSA_ARCHITECTURE.md Sections 14.1 and 14.7), which
 * supersede D3's single agent. THE AGENT TABLE (the platform header's
 * SCP_PLAT_AGENTS, mod/agents.h) gives each agent k its own transport, on its
 * own queue window, and its own M-mode context:
 *
 *   agent k  BASE, and DEVICE_POWER if its groups have SCP_GRP_DPWR
 *
 * soc4: agent 0 the AP, agent 1 the RPU, both with DEVICE_POWER.
 *
 * A transport is one block of queue memory. It holds the A2P request queue and
 * then the P2A acknowledgement queue, end to end
 * (rpmi_transport_shmem.c:236-247). There is no P2A request channel, because
 * the decisions drop the SCP-to-agent path. SYSTEM_RESET is not registered, so
 * rpmi_service_group_sysreset.c need not link; a request to it is consumed and
 * gets no answer (rpmi_context.c:328-333).
 *
 *   DEVICE_POWER  one domain per entry of the domain table (mod/pd.h,
 *                 SCP_PLAT_DOMAINS: its names and transition latencies), with
 *                 DOMAIN_ID = PPU index = mod/pd's domain, the same in every
 *                 agent's group. Each agent's group is its own instance, whose
 *                 ops_priv is the agent's index, so the callbacks know who
 *                 asks (LR include/librpmi.h:1678-1681).
 *
 * VOTES AND PERMISSIONS (F6). One vote per agent per domain. A domain is ON
 * while ANY agent votes ON, and goes to its low-power mode only when ALL vote
 * OFF: the policy (hooks->dpwr_vote, mod/policy.h) sees only that combined
 * vote, when it changes. This file touches no PPU.
 *
 *   get_state  the CALLER's own vote, never the physical state or the
 *              combined vote. That is the decisions' rule (Section 2.2,
 *              "Votes"), and librpmi's: it skips set_state when get_state
 *              already equals the request
 *              (rpmi_service_group_device_power.c:128-131), so an agent's ON
 *              while another holds the domain ON still reaches set_state.
 *   set_state  ON and OFF only. An agent's ON while every other agent votes
 *              OFF is passed to the hook as ON; its OFF when no other agent
 *              votes ON is passed as OFF; otherwise the combined vote does not
 *              change and the hook is not called. The vote is recorded if the
 *              hook agrees (an ON the policy fails is not).
 *   permission A domain's .agents bitmap (the domain table) says which agents
 *              may vote for it. For any other agent, get_state and set_state
 *              answer RPMI_ERR_DENIED, "Denied to insufficient permissions"
 *              (LR include/librpmi.h:122-126), before any PPU access. librpmi
 *              asks get_state first in SET_DPWR_STATE and returns its error as
 *              the status (rpmi_service_group_device_power.c:124-126,
 *              306-309), so the agent's ON and its OFF are both refused, not
 *              just the ON; GET_DPWR_STATE answers the error alone (:93-95,
 *              265-268).
 *              GET_NUM_DOMAINS and GET_ATTRIBUTES list every domain to every
 *              agent: DOMAIN_ID means the same everywhere.
 *   wake       The one other writer of a vote: scp_rpmi_dpwr_wake_vote()
 *              records ON for the domain's WAKE OWNER, the lowest-numbered
 *              agent in its .agents (soc4: the AP, for all four), when the
 *              policy has powered the domain up from an interrupt input
 *              (mod/policy.h, WAKE INPUTS). Its get_state then answers ON and
 *              librpmi forwards its next OFF, which ends the wake vote. A
 *              domain no agent may vote for has no owner: a wake records no
 *              vote, and nothing can vote it OFF again.
 *
 * THE QUEUE GUARD. librpmi trusts the four queue indices, and two of its loops
 * wait on the agent with no bound (each transport has its own guard):
 *
 *   - It retries an ACK for as long as the P2A queue is full
 *     (rpmi_context.c:403-405). An agent that stops reading its ACKs while
 *     requests are queued holds it there.
 *   - It drains the A2P queue until the head equals the tail
 *     (rpmi_context.c:327). The head only takes the values 0 to
 *     SCP_RPMI_QUEUE_DATA - 1 (rpmi_transport_shmem.c:155), so a tail the agent
 *     writes outside that range is never reached. The head goes round the
 *     ring for ever and every request left in a slot runs again: posted ones
 *     are executed again, and normal ones fill the P2A queue until the first
 *     loop takes over.
 *
 * A P2A head out of range does the opposite harm. librpmi never finds that
 * queue full (rpmi_transport_shmem.c:85), and writes over ACKs the agent has not
 * read.
 *
 * So scp_rpmi_init() wraps three of each transport's callbacks
 * (librpmi.h:537-555, set at rpmi_transport_shmem.c:256-258), and librpmi
 * itself is unchanged. librpmi calls them with the transport lock held
 * (rpmi_transport.c:107-113, 153-161), so the wrappers call librpmi's own
 * callbacks, never the rpmi_transport_* functions, which take the lock.
 *
 *   is_empty  For the A2P queue, before each request is read. All four
 *             indices must be readable and below SCP_RPMI_QUEUE_DATA, and, if
 *             a request is waiting, the P2A queue must have a free slot for
 *             its ACK. Otherwise the answer is "empty", which ends the drain,
 *             and scp_rpmi_drain() says why.
 *   is_full   Never "full" for the P2A queue. That answer is the only
 *             RPMI_ERR_IO an enqueue returns (rpmi_transport.c:108-111), so
 *             librpmi's ACK loop never goes round a second time.
 *   enqueue   Makes the check instead. An ACK that finds the P2A queue full,
 *             or either of its indices out of range, is dropped and counted
 *             in ack_dropped[], and librpmi moves on (rpmi_context.c:407-410).
 *
 * The SCP is the only producer on the P2A queue, and is_empty found a free
 * slot there before the request was read. So an ACK is dropped only if the agent
 * moves its P2A head backwards, or out of range, while the request is handled.
 *
 * The guard cannot see an index that is in range but wrong. An A2P tail
 * written past the agent's last request makes the old requests in between run
 * again. Each request is still read, handled and answered once: that is work,
 * not a wait. An agent that keeps its A2P queue topped up no longer keeps one
 * drain going: is_empty also answers "empty" once SCP_RPMI_DRAIN_BUDGET
 * requests have been let through (SCP_RPMI_BUDGET), so a pass of the main loop
 * stays bounded, which the watchdog relies on, and the transports take turns.
 */
#ifndef SCP_RPMI_H
#define SCP_RPMI_H

#include <stdint.h>
#include <stdbool.h>
#include <librpmi.h>

#include "agents.h"

/* Transport t = agent t (the agent table). */
enum { SCP_NUM_XPORT = SCP_NUM_AGENTS };

/* An agent's service groups beside BASE (the agent table's groups field). */
enum { SCP_GRP_DPWR = 1u << 0 };

/* The agent table, from the platform header (mod/agents.h). */
struct scp_agent {
  const char *name;
  uintptr_t   window;    /* its queue window on the SCP's map               */
  uint8_t     db_in;     /* its doorbell's input of the interrupt block     */
  uint8_t     src;       /* its firewall entry: FW_VAL, FW_MASK             */
  uint8_t     mask;
  uint8_t     groups;    /* SCP_GRP_*                                       */
};
extern const struct scp_agent scp_agent[SCP_NUM_AGENTS];

/* The queues. Slot 0 of each holds the head index, slot 1 the tail index, and
 * the rest hold messages, so every index is below SCP_RPMI_QUEUE_DATA
 * (rpmi_transport_shmem.c:248). The ring is full one short of that (:85): 8
 * slots carry at most 5 requests in flight, and 5 acknowledgements. */
#define SCP_RPMI_SLOT_SIZE    64u     /* RPMI_SLOT_SIZE_MIN, librpmi.h:83 */
#define SCP_RPMI_QUEUE_SLOTS  8u
#define SCP_RPMI_QUEUE_DATA   (SCP_RPMI_QUEUE_SLOTS - 2u)
#define SCP_RPMI_QUEUE_SIZE   (SCP_RPMI_SLOT_SIZE * SCP_RPMI_QUEUE_SLOTS)
#define SCP_RPMI_SHMEM_SIZE   (2u * SCP_RPMI_QUEUE_SIZE)   /* A2P req + P2A ACK */

/* Service groups per context: BASE, DEVICE_POWER, and one free slot for a
 * platform-defined group. */
#define SCP_CTX_GROUPS  3u

/* DEVICE_POWER domains: SCP_DPWR_COUNT (scp_rpmi.c) = PD_COUNT, one per entry
 * of the domain table (mod/pd.h). */

struct scp_rpmi_hooks {
  int  (*dpwr_vote)(uint32_t id, uint32_t state);   /* the policy: 0, or an
                                                       RPMI error, which
                                                       refuses                 */
};

struct scp_rpmi_stats {
  uint32_t dpwr_set;        /* DEVICE_POWER set_state calls from librpmi   */
  uint32_t dpwr_denied;     /* ...get_state and set_state refused for want
                               of permission (RPMI_ERR_DENIED)             */
  uint32_t ack_dropped[SCP_NUM_XPORT];   /* ACKs the queue guard refused   */
};
extern struct scp_rpmi_stats scp_rpmi_stats;

enum scp_rpmi_err {
  SCP_RPMI_OK          =  0,
  SCP_RPMI_E_SHMEM     = -1,
  SCP_RPMI_E_TRANSPORT = -2,
  SCP_RPMI_E_CONTEXT   = -3,
  SCP_RPMI_E_GROUP     = -4,
};

/* Create every agent's transport, with the queue guard over it, its context
 * and its groups, then seal the arena. Agent t's queue memory is its window
 * (the agent table), SCP_RPMI_SHMEM_SIZE bytes, and librpmi zeroes it
 * (rpmi_transport_shmem.c:218-220). The votes are left as mod/flog.h's
 * flog_boot() found them, which must run first.
 *
 * AFTER A WATCHDOG RESET this runs again on queues an agent may be using. What
 * an agent sees: every queue index reads 0 once the SCP is back (librpmi's
 * zeroing); a request it had queued, or that the SCP had taken but not
 * answered, gets no acknowledgement, so its call times out; one written while
 * the SCP was in reset or booting may be wiped by the zeroing, with the same
 * result. An agent must read the queue indices from the shared memory for each
 * call (a librpmi agent does: rpmi_transport_shmem.c reads them on every
 * enqueue and dequeue), not keep its own copies. Its votes, and so every
 * domain's power, are kept (mod/flog.h). */
int scp_rpmi_init(const struct scp_rpmi_hooks *hooks);

struct rpmi_context *scp_rpmi_ctx(unsigned t);   /* NULL until created */

/* A wake input powered DEVICE_POWER domain `id` up: record ON as the vote of
 * its wake owner, the lowest-numbered agent that may vote for it (VOTES AND
 * PERMISSIONS, above). Main loop only, never inside librpmi; it calls no
 * librpmi function. */
void scp_rpmi_dpwr_wake_vote(uint32_t id);

/* Does any agent vote ON for domain id? And drop every agent's vote for it
 * (mod/policy.c's adoption of a domain whose state contradicts its votes). */
bool scp_rpmi_dpwr_voted(uint32_t id);
void scp_rpmi_dpwr_drop(uint32_t id);

/* Why a drain stopped: see THE QUEUE GUARD, above. */
enum scp_rpmi_hold {
  SCP_RPMI_DRAINED   = 0,   /* the A2P queue is empty                         */
  SCP_RPMI_ACK_FULL  = 1,   /* requests wait: the P2A queue has no free slot  */
  SCP_RPMI_BAD_INDEX = 2,   /* an index is out of range or unreadable, or a
                               request could not be read                      */
  SCP_RPMI_BUDGET    = 3,   /* SCP_RPMI_DRAIN_BUDGET requests taken: the rest
                               wait for the next pass                         */
};

/* At most this many requests per drain, so that one pass of the main loop is
 * bounded however fast an agent refills its queue, and the watchdog's timeout
 * can be derived (scp/main.c): a full queue, no more. */
#define SCP_RPMI_DRAIN_BUDGET (SCP_RPMI_QUEUE_DATA - 1u)

/* Drain transport t's A2P queue: rpmi_context_process_a2p_request() under the
 * guard. Only the main loop calls it (rpmi/scp_loop.h). */
enum scp_rpmi_hold scp_rpmi_drain(unsigned t);

#endif
