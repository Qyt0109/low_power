# pmu/fw/rpmi: the RPMI server and the main loop

The SCP's protocol layer. `scp_rpmi` builds one librpmi v1.0.0 transport and
context per agent, serves BASE and DEVICE_POWER, keeps one vote per agent per
domain, and guards librpmi against an agent that leaves its queues in a bad
state. `scp_loop` is the one thread librpmi runs in. Part of the shared SCP
firmware; see [`../README.md`](../README.md).

## Files

| File | What it is |
|---|---|
| `scp_rpmi.h`, `scp_rpmi.c` | The RPMI server: the agent table (`scp_agent[]`), the queue geometry, DEVICE_POWER votes and permissions, the queue guard, `scp_rpmi_init()` and `scp_rpmi_drain()` |
| `scp_loop.h`, `scp_loop.c` | The main loop: `scp_loop_init()`, `scp_loop_pass()`, `scp_loop_run()`, its hooks and statistics |

## The RPMI server (`scp_rpmi`)

**One transport per agent.** The platform header's agent table
(`SCP_PLAT_AGENTS`, fields in `../mod/agents.h`) gives agent `k` transport `k`:
its queue window on the SCP's map, its doorbell's `scp_irq` input, its
firewall entry (TL-UL source value and mask) and its service groups. Each
transport is one block of `SCP_RPMI_SHMEM_SIZE` = 1024 bytes: the A2P request
queue, then the P2A acknowledgement queue (`lib/rpmi_transport_shmem.c:236-247`).
Each queue has 8 slots of 64 bytes. Slot 0 holds the head index and slot 1 the
tail, so at most 5 requests and 5 acknowledgements are in flight. There is no
P2A request queue and no SCP-to-agent doorbell: agents poll for their
acknowledgements. Each context is M-mode.

soc4: agent 0 is the AP (window `0x0002_4000`), agent 1 the RPU (window
`0x0002_4400`); both get BASE and DEVICE_POWER.

**Service groups.** BASE (built into every librpmi context) and, for agents
with `SCP_GRP_DPWR`, DEVICE_POWER with one domain per entry of the domain table
(DOMAIN_ID = PPU index, the same for every agent). Each agent's DEVICE_POWER
group is its own instance, whose `ops_priv` is the agent's index. SYSTEM_RESET
is not registered; a request to it is consumed and gets no answer
(`lib/rpmi_context.c:328-333`). `SCP_CTX_GROUPS` = 3 leaves one slot for a
platform-defined group.

**Votes and permissions.**

| Call | Behaviour |
|---|---|
| `get_state` | The **caller's own vote**, never the physical state or the combined vote. librpmi skips `set_state` when `get_state` already equals the request (`lib/rpmi_service_group_device_power.c:128-131`), so this is what lets each agent's ON and OFF through |
| `set_state` | ON and OFF only. The policy hook (`dpwr_vote`) is called only when the combined vote changes: an agent's ON while no other agent votes ON, or its OFF while no other agent votes ON. The vote is recorded unless the hook refuses (a failed ON leaves it OFF) |
| permission | A domain's `.agents` bitmap says who may vote for it. Anyone else gets `RPMI_ERR_DENIED` from `get_state` and `set_state`, before any PPU access. `GET_NUM_DOMAINS` and `GET_ATTRIBUTES` list every domain to every agent |
| wake | `scp_rpmi_dpwr_wake_vote(id)`, called by the policy after a wake input powered domain `id` up, records ON for the lowest agent in `.agents` (soc4: the AP). That agent's next OFF then reaches the policy |

The votes live in `scp_keep.votes` (`../mod/flog.h`) and survive a watchdog
reset. Every change ends in `flog_commit()`. `scp_rpmi_init()` does not reset
them, so `flog_boot()` must run first.

**The queue guard.** librpmi trusts the four queue indices, and two of its
loops wait on the agent with no bound: it retries an acknowledgement for as long
as the P2A queue is full (`lib/rpmi_context.c:403-405`), and it drains the A2P
queue until the head equals a tail the agent may have written out of range
(`lib/rpmi_context.c:327`). `scp_rpmi_init()` wraps three of each transport's
callbacks, leaving librpmi unchanged:

| Callback | Wrapper |
|---|---|
| `is_empty` (A2P) | answers "empty", which ends the drain, if any index is out of range, if a request waits but the P2A queue has no free slot, or once `SCP_RPMI_DRAIN_BUDGET` (5) requests have been let through |
| `is_full` (P2A) | never "full", so librpmi's acknowledgement loop never goes round twice |
| `enqueue` (P2A) | drops an acknowledgement that finds the queue full or an index out of range, counted in `scp_rpmi_stats.ack_dropped[]` |

`scp_rpmi_drain(t)` returns why it stopped: `SCP_RPMI_DRAINED`,
`SCP_RPMI_ACK_FULL`, `SCP_RPMI_BAD_INDEX` or `SCP_RPMI_BUDGET`.

**After a watchdog reset** `scp_rpmi_init()` runs again on queues an agent may
be using. librpmi zeroes each window, so every index reads 0. A request that
was in flight gets no acknowledgement and the agent's call times out. The
votes, and so every domain's power, are kept. An agent must read the queue
indices from shared memory on every call, as a librpmi agent does.

## The main loop (`scp_loop`)

Rules, from `Proposed_PMU/RPMI_STACK_DECISIONS.md` §2.5 and the platform plan:

1. librpmi is called only from here.
2. Interrupt handlers only set flags.
3. `rpmi_context_process_all_events()` runs on every pass.
4. Transports are serviced in order, transport 0 first.
5. A pass runs with `mstatus.MIE` clear; interrupts are taken only in the
   window after the WFI, so no handler runs inside librpmi.
6. The watchdog is kicked at the end of a completed pass, and only there.

One pass (`scp_loop_pass()`):

| Step | What |
|---|---|
| 1 | Read the doorbells, clear them, then drain each transport that rang or is pending, in transport order. A drain the guard stopped leaves its transport pending for the next pass |
| 2 | `rpmi_context_process_all_events()` on every context. No group linked today has events |
| 3 | `hooks->work()` (soc4: `policy_work()`, which calls `pd_poll()`, then the firewall-denial check), then `hooks->deadline()` (soc4: `policy_deadline()`) |
| 4 | WFI, unless a doorbell rang, an input action is due, or a drain hit its budget. The sleep ends at an interrupt or the next deadline. It is also bounded by `SCP_LOOP_POLL_TICKS` (512) while a transport is pending or a level input waits to be seen LOW, and always by `SCP_LOOP_KICK_TICKS` = `SCP_PLAT_WDOG_TIMEOUT / 8` |
| 5 | `scp_wdog_kick()` |

`scp_loop_init()` (after `scp_rpmi_init()`) initialises the timer, clears and
then unmasks every doorbell. `scp_loop_run()` never returns. Per-transport
statistics are in `scp_loop_stats` (`rang`, `held`, `faults`, `budget`).

**The watchdog timeout** (`SCP_PLAT_WDOG_TIMEOUT`) must cover a sleep plus the
longest pass. What makes a pass long is a synchronous ON, each bounded by the
policy's `on_ticks`: up to `SCP_RPMI_DRAIN_BUDGET` from each transport, plus
one per `SCP_ACT_POWER_UP` input. `soc4/fw/scp/main.c` checks this at compile
time (soc4: 16 ms of work against 18.4 ms).

## Build and use

Both files link into `soc4_scp` and `soc4_scp_m6` only, with
`-I vendor/librpmi/include -I port -I rpmi`
([`src/soc4/fw/Makefile`](../../../soc4/fw/Makefile)). `soc4_scp_m6` defines
`SCP_MUT_PERM_OPEN`, which makes the permission check pass for every agent: it
is soc4neg's mutant M6, never a product image. Exercised by `make soc4` (the AP
program as agent), `make soc4bfm` (the TL-UL BFM: the firewall, discovery,
ON/OFF, cancel, deny/force, deadline faults, bad IDs, the second agent, and
the watchdog takeover) and `make soc4neg`.

## Extending

- **An agent:** one `A(...)` entry in the platform header, its doorbell's
  `I(...)` entry (`SCP_ACT_DOORBELL`, `arg` = the agent's index), its bit in
  each domain's `.agents`, and the mailbox's agent count and port in the
  hardware. The boot checks the mailbox's agent count and each doorbell input.
  The RPMI arena grows by 512 bytes per agent (`../port/rpmi_env.h`).
- **A service group** (HSM, SYSTEM_SUSPEND): a new `SCP_GRP_*` bit, its
  creation in `scp_rpmi_init()`, its librpmi file in the Makefile's source
  list, and a check of the arena size. Both of those groups have events, which
  step 2 of the pass already services.

## References

- RPMI v1.0 specification (`riscv-non-isa/riscv-rpmi`, tag `v1.0`): the
  shared-memory transport, BASE and DEVICE_POWER.
- librpmi v1.0.0 ([`../vendor/librpmi/`](../vendor/README.md)): `include/librpmi.h`
  (`struct rpmi_dpwr_data` :1634-1639, the DEVICE_POWER platform operations
  :1652-1665), `lib/rpmi_context.c`, `lib/rpmi_transport_shmem.c`,
  `lib/rpmi_service_group_device_power.c`.
- [`Proposed_PMU/RPMI_STACK_DECISIONS.md`](../../../../Proposed_PMU/RPMI_STACK_DECISIONS.md)
  §2.2 (votes) and §2.5 (runtime), as amended by the platform plan PD6 and F6
  ([`SOVRA_PCSA_ARCHITECTURE.md`](../../../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)
  §14.1 and §14.7).
- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../../../docs/PMU_SOFTWARE_CONTRACT.md)
  §1–3: the agents' side of the same queues, domains and services.
