/* The SCP's main loop. See scp_loop.h. */
#include "scp_loop.h"
#include "rpmi_db.h"
#include "scp_irq.h"
#include "scp_wdog.h"
#include "csr.h"
#include "timer.h"

_Static_assert((int)RPMI_DB_COUNT == (int)SCP_NUM_XPORT, "doorbell t must be transport t");

struct scp_loop_stats scp_loop_stats;

static const struct scp_loop_hooks *loop_hooks;

void scp_loop_init(const struct scp_loop_hooks *hooks)
{
  loop_hooks = hooks;
  timer_init();
  rpmi_db_init();
  rpmi_db_set_mask(0);      /* every doorbell may interrupt, once one can */
}

/* Sleep, unless a doorbell rang during the pass. The caller has MIE clear.
 * An interrupt that arrived during the pass is pending rather than taken, so
 * the WFI returns at once instead of sleeping past it. The window opened after
 * the WFI is where the handler runs (the pd_idle pattern in mod/pd.c). A
 * polled doorbell raises nothing, so its status is looked at here, and the
 * sleep is bounded so that the loop comes back to look again. A pending
 * transport waits on an agent that rings nothing, so it bounds the sleep too.
 * So does a level input of the interrupt block waiting to be seen LOW before
 * it is re-armed (hal/scp_irq.h): going LOW raises nothing. An input action
 * collected after the policy ran (a wait inside a power-up collects too) is
 * due now, so it skips the sleep, like a ring, and so does a transport whose
 * drain the budget ended (more requests are waiting). The watchdog bounds every
 * sleep to SCP_LOOP_KICK_TICKS, so that an idle loop still comes round to kick
 * it. */
static void idle(uint64_t until, bool again)
{
  if (again || rpmi_db_status() || scp_irq_act_pending()) return;
  if (scp_loop_stats.pending || rpmi_db_polled() || scp_irq_held()) {
    uint64_t t = timer_after(SCP_LOOP_POLL_TICKS);
    if (t < until) until = t;
  }
  const uint64_t kick = timer_after(SCP_LOOP_KICK_TICKS);
  if (kick < until) until = kick;
  timer_arm(until);
  wfi();
  irq_enable();
  irq_disable();
  timer_disarm();
  scp_loop_stats.sleeps++;
}

void scp_loop_pass(void)
{
  uint32_t was = irq_save();

  /* 1. Doorbells, in transport order. Clear first and then drain: a ring that
        lands after the clear is still there next pass. Clearing after the
        drain could lose the ring for a request that arrived just after the
        queue was found empty. A transport the guard stopped last pass had its
        bit cleared then, so it is drained again as pending, rung or not. */
  uint32_t rang = rpmi_db_status();
  rpmi_db_clear(rang);
  const uint32_t todo = rang | scp_loop_stats.pending;
  bool again = false;
  scp_loop_stats.pending = 0;
  for (unsigned t = 0; t < SCP_NUM_XPORT; t++) {
    const uint32_t bit = 1u << t;
    if (!(todo & bit)) continue;
    if (rang & bit) scp_loop_stats.rang[t]++;
    switch (scp_rpmi_drain(t)) {
    case SCP_RPMI_DRAINED:
      break;
    case SCP_RPMI_ACK_FULL:
      scp_loop_stats.held[t]++;
      scp_loop_stats.pending |= bit;
      break;
    case SCP_RPMI_BAD_INDEX:
      scp_loop_stats.faults[t]++;
      scp_loop_stats.pending |= bit;
      break;
    case SCP_RPMI_BUDGET:
      scp_loop_stats.budget[t]++;
      scp_loop_stats.pending |= bit;
      again = true;
      break;
    }
  }

  /* 2. Events, every context, every pass. */
  for (unsigned t = 0; t < SCP_NUM_XPORT; t++)
    rpmi_context_process_all_events(scp_rpmi_ctx(t));

  /* 3. Power-domain and policy work, then deadlines. */
  uint64_t next = SCP_LOOP_NEVER;
  if (loop_hooks && loop_hooks->work)     loop_hooks->work();
  if (loop_hooks && loop_hooks->deadline) next = loop_hooks->deadline();

  /* 4. Sleep. */
  idle(next, again);
  scp_loop_stats.passes++;

  /* 5. The pass is complete: kick the watchdog. Here and nowhere else -- never
        from an interrupt -- so a pass that never ends stops the kicks. */
  scp_wdog_kick();
  irq_restore(was);
}

void scp_loop_run(void)
{
  for (;;) scp_loop_pass();
}
