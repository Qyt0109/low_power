/* RISC-V machine-mode CSR access and interrupt control, for Ibex.
 *
 * Ibex runs in M-mode only here, uses vectored interrupts (mtvec's mode bits
 * are fixed at 01), and takes the 15 fast interrupts on mie/mip bits 16..30.
 */
#ifndef CSR_H
#define CSR_H

#include <stdint.h>

#define MSTATUS_MIE        (1u << 3)
#define MIE_MTIE           (1u << 7)
#define MIE_MEIE           (1u << 11)
#define MIE_FAST(line)     (1u << (line))       /* line = 16..30 */
#define MCAUSE_INTERRUPT   0x80000000u

/* mcause of the synchronous exceptions the firmware tells apart */
#define MCAUSE_INSN_ACCESS 1u
#define MCAUSE_ILLEGAL     2u
#define MCAUSE_LOAD_ACCESS 5u
#define MCAUSE_STORE_ACCESS 7u

#define csr_read(csr) ({                                            \
    uint32_t v_;                                                    \
    __asm__ volatile ("csrr %0, " #csr : "=r"(v_) :: "memory");    \
    v_; })

#define csr_write(csr, val) \
    __asm__ volatile ("csrw " #csr ", %0" :: "rK"((uint32_t)(val)) : "memory")

#define csr_set(csr, val) \
    __asm__ volatile ("csrs " #csr ", %0" :: "rK"((uint32_t)(val)) : "memory")

#define csr_clear(csr, val) \
    __asm__ volatile ("csrc " #csr ", %0" :: "rK"((uint32_t)(val)) : "memory")

static inline void irq_enable(void)  { csr_set(mstatus, MSTATUS_MIE); }
static inline void irq_disable(void) { csr_clear(mstatus, MSTATUS_MIE); }

/* Disable, returning whether interrupts were enabled; pair with irq_restore. */
static inline uint32_t irq_save(void)
{
  uint32_t prev;
  __asm__ volatile ("csrrci %0, mstatus, 8" : "=r"(prev) :: "memory");
  return prev & MSTATUS_MIE;
}

static inline void irq_restore(uint32_t was)
{
  if (was) csr_set(mstatus, MSTATUS_MIE);
}

/* Sleep until an interrupt that mie enables is pending. With mstatus.MIE clear
 * it still wakes -- the RISC-V rule for WFI -- and the interrupt is taken when
 * MIE is next set, which is what closes the check-then-sleep race (see
 * mod/pd.c, pd_idle). */
static inline void wfi(void) { __asm__ volatile ("wfi" ::: "memory"); }

#endif
