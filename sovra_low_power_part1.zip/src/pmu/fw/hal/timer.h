/* The SCP's machine timer: Ibex's timer.sv, mtime/mtimecmp, one tick per clock.
 *
 * Two behaviours of that block shape this driver:
 *   - mtimecmp resets to 0, so the interrupt is pending from the first cycle
 *     out of reset. timer_init() moves it out of the way before MTIE is set.
 *   - the interrupt is sticky: it stays asserted until mtimecmp is written, even
 *     once mtime is back below it. Every write to either half clears it, which
 *     is how the handler acknowledges it (hal/trap.c).
 *
 * Deadlines are 64-bit mtime values compared with >=; nothing here divides a
 * 64-bit number (README Section 4).
 */
#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>
#include <stdbool.h>

#define TIMER_MTIME     0x0u
#define TIMER_MTIMEH    0x4u
#define TIMER_MTIMECMP  0x8u
#define TIMER_MTIMECMPH 0xCu

void     timer_init(void);           /* disarmed, MTIE enabled */
uint64_t timer_now(void);
void     timer_arm(uint64_t when);   /* interrupt once mtime >= when */
void     timer_disarm(void);

static inline uint64_t timer_after(uint32_t ticks) { return timer_now() + ticks; }
static inline bool     timer_passed(uint64_t when) { return timer_now() >= when; }

/* Busy-wait: for testbench pacing only. The manager sleeps instead (pd_idle). */
void     timer_delay(uint32_t ticks);

#endif
