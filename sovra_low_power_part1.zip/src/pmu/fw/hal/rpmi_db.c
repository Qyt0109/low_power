/* The RPMI doorbells: the TL-UL mailbox's RING vector (soc4_mbx.sv;
 * docs/SOC4_DESIGN.md Sections 4.5 and 9.3). Implements
 * hal/rpmi_db.h for every agent of the platform's agent table.
 *
 * Any accepted write by agent t to its doorbell (soc4: the AP's at
 * 0x2000_1000, the RPU's at 0x2000_3000) sets RING[t], which is sticky and
 * drives its own input of the SCP's interrupt block (soc4: inputs 4 and 14,
 * level; hal/scp_irq.h) until the SCP writes bit t of DB_CLEAR (a ring in
 * the same cycle wins). The doorbells have no enable register of their own,
 * so the SCP masks each with its input's ENABLE bit, and no agent can clear
 * or mask one (decision 10).
 *
 * THE INTERRUPT: trap_external() (pmu/fw/hal/trap.c) masks mie.MEIE and sets a
 * flag, and touches no device; handlers only set flags. scp_irq_collect()
 * masks the doorbell's input, a level whose source only this file clears. The
 * main loop reads the status, clears it, and calls rpmi_db_clear(), which
 * unmasks the input (PENDING cleared, ENABLE set) after the clear and before
 * the drain, so a ring during the drain interrupts again.
 *
 * Linked into soc4_scp only (src/soc4/fw/Makefile), the one image with the
 * RPMI server. */
#include "rpmi_db.h"
#include "scp_regs.h"
#include "soc4_regs.h"
#include "scp_irq.h"

static uint32_t db_mask = RPMI_DB_ALL;   /* bit t = 1: t raises no interrupt */

/* The doorbells' inputs: each open while its transport may interrupt. The
   caller runs with mstatus.MIE clear (rpmi/scp_loop.h), so opening one takes
   nothing yet. */
static uint32_t db_inputs(uint32_t bits)
{
  uint32_t in = 0;
  for (unsigned t = 0; t < RPMI_DB_COUNT; t++)
    if (bits & (1u << t)) in |= scp_irq_db_bit(t);
  return in;
}

static void db_arm(void)
{
  scp_irq_mask(db_inputs(db_mask));
  scp_irq_unmask(db_inputs(~db_mask & RPMI_DB_ALL));
}

void rpmi_db_init(void)
{
  db_mask = RPMI_DB_ALL;
  scp_irq_mask(db_inputs(RPMI_DB_ALL));
  mmio_write32(SOC4_MBX_DB_CLEAR, RPMI_DB_ALL);
}

uint32_t rpmi_db_status(void)
{
  return mmio_read32(SOC4_MBX_DB_STATUS) & RPMI_DB_ALL;
}

void rpmi_db_clear(uint32_t bits)
{
  if (bits & RPMI_DB_ALL) mmio_write32(SOC4_MBX_DB_CLEAR, bits & RPMI_DB_ALL);
  db_arm();
}

void rpmi_db_set_mask(uint32_t mask)
{
  db_mask = mask & RPMI_DB_ALL;
  db_arm();
}

bool rpmi_db_polled(void) { return false; }
