/* Trap handlers. See trap.h for what each one is allowed to do. */
#include "trap.h"
#include "csr.h"
#include "scp_regs.h"
#include "timer.h"
#include "sim.h"
#include "console.h"

volatile uint32_t trap_timer_count;
volatile uint32_t trap_ext_pending;
volatile uint32_t trap_ext_count;

static volatile bool              fault_armed;
static volatile bool              fault_taken;
static volatile struct trap_fault fault_rec;

void trap_expect_fault(void)
{
  fault_taken = false;
  fault_armed = true;
}

bool trap_take_fault(struct trap_fault *f)
{
  bool t = fault_taken;
  if (t) {
    f->mcause = fault_rec.mcause;
    f->mepc   = fault_rec.mepc;
    f->mtval  = fault_rec.mtval;
  }
  fault_taken = false;
  fault_armed = false;
  return t;
}

static void __attribute__((noreturn)) die(const char *what, uint32_t mcause,
                                           uint32_t mepc, uint32_t mtval)
{
  con_printf("\nFATAL: %s  mcause=0x%08x mepc=0x%08x mtval=0x%08x\n",
             what, mcause, mepc, mtval);
  sim_halt(0xDEAD0000u | (mcause & 0xFFu));
  for (;;) wfi();
}

void __attribute__((interrupt("machine"))) trap_exception(void)
{
  uint32_t mcause = csr_read(mcause);
  uint32_t mepc   = csr_read(mepc);
  uint32_t mtval  = csr_read(mtval);

  if (!fault_armed) die("unexpected exception", mcause, mepc, mtval);

  fault_rec.mcause = mcause;
  fault_rec.mepc   = mepc;
  fault_rec.mtval  = mtval;
  fault_taken = true;
  fault_armed = false;

  /* Resume after the faulting load or store. Its length is in its own low two
     bits: 0b11 is a 32-bit instruction, anything else a 16-bit compressed one.
     A halfword read is always aligned, whichever it is. */
  uint16_t lo = *(volatile uint16_t *)(uintptr_t)mepc;
  csr_write(mepc, mepc + (((lo & 3u) == 3u) ? 4u : 2u));
}

void __attribute__((interrupt("machine"))) trap_timer(void)
{
  timer_disarm();                 /* the write is the acknowledge */
  trap_timer_count++;
}

void __attribute__((interrupt("machine"))) trap_external(void)
{
  csr_clear(mie, MIE_MEIE);                     /* silence until serviced */
  trap_ext_pending = 1;
  trap_ext_count++;
}

void __attribute__((interrupt("machine"))) trap_unexpected(void)
{
  die("interrupt from a line with no source", csr_read(mcause), csr_read(mepc),
      csr_read(mtval));
}

void __attribute__((interrupt("machine"))) trap_nmi(void)
{
  die("NMI", csr_read(mcause), csr_read(mepc), csr_read(mtval));
}
