/* Arm Power Policy Unit, architecture v1.1 (ARM DEN 0051E): register driver.
 *
 * The register layout and every behaviour relied on here is written down in
 * src/rtl/ppu/REGISTERS.md, which was checked against the specification's own
 * tables (make ppuspec, retired with src/lint on 2026-10-05; make ppuregdoc
 * still checks its behavioural claims). The rules this driver enforces so that its callers do
 * not have to are src/pmu/README.md Section 6; they are repeated at each
 * function that enforces one.
 *
 * One struct ppu per PPU. It holds the base address and what ppu_probe() read
 * out of the identification registers -- the driver never assumes a feature
 * the build does not report (REGISTERS.md Section 4.7: "a driver that assumes
 * a feature exists will silently do nothing").
 *
 * The driver does not service interrupts and does not wait. Both belong to the
 * power domain manager (mod/pd.c), which owns the event loop.
 */
#ifndef PPU_V1_H
#define PPU_V1_H

#include <stdint.h>
#include <stdbool.h>

/* ---- Registers (Table 5-1) ---- */
#define PPU_PWPR   0x000u   /* power policy                     RW  */
#define PPU_PMER   0x004u   /* power mode emulation             --  reserved here */
#define PPU_PWSR   0x008u   /* power status                     RO  */
#define PPU_DISR   0x010u   /* device interface input status    RO  */
#define PPU_MISR   0x014u   /* miscellaneous input status       RO  */
#define PPU_STSR   0x018u   /* stored status                    --  reserved here */
#define PPU_UNLK   0x01Cu   /* unlock                           WO  */
#define PPU_PWCR   0x020u   /* power configuration              RW  */
#define PPU_PTCR   0x024u   /* transition configuration         RW  */
#define PPU_IMR    0x030u   /* interrupt mask                   RW  */
#define PPU_AIMR   0x034u   /* additional interrupt mask        RW  */
#define PPU_ISR    0x038u   /* interrupt status                 W1C */
#define PPU_AISR   0x03Cu   /* additional interrupt status      W1C */
#define PPU_IESR   0x040u   /* input edge sensitivity           RW  */
#define PPU_OPSR   0x044u   /* operating mode active edge       --  reserved here */
#define PPU_FUNRR  0x050u   /* FUNC_RET RAM configuration       RW  */
#define PPU_FULRR  0x054u   /* FULL_RET RAM configuration       RW  */
#define PPU_MEMRR  0x058u   /* MEM_RET RAM configuration        RW  */
#define PPU_EDTR0  0x160u   /* entry delay: OFF, MEM_RET, FULL_RET */
#define PPU_EDTR1  0x164u   /* entry delay: MEM_OFF, FUNC_RET   */
#define PPU_DCDR0  0x170u   /* device control delays 0          */
#define PPU_DCDR1  0x174u   /* device control delays 1          */
#define PPU_IDR0   0xFB0u   /* identification: modes            RO  */
#define PPU_IDR1   0xFB4u   /* identification: features         RO  */
#define PPU_IIDR   0xFC8u   /* implementation identification    RO  */
#define PPU_AIDR   0xFCCu   /* architecture identification      RO  */

/* ---- Power modes (Table 3-2). The encoding is monotonic in priority, so
 *      "no deeper than X" is "encoding >= X" (design doc Section 5.5.2a). */
enum ppu_mode {
  PPU_MODE_OFF         = 0x0,
  PPU_MODE_OFF_EMU     = 0x1,
  PPU_MODE_MEM_RET     = 0x2,
  PPU_MODE_MEM_RET_EMU = 0x3,
  PPU_MODE_LOGIC_RET   = 0x4,
  PPU_MODE_FULL_RET    = 0x5,
  PPU_MODE_MEM_OFF     = 0x6,
  PPU_MODE_FUNC_RET    = 0x7,
  PPU_MODE_ON          = 0x8,
  PPU_MODE_WARM_RST    = 0x9,
  PPU_MODE_DBG_RECOV   = 0xA,
};

/* ---- Fields ---- */
#define PPU_PWPR_POLICY          0x0000000Fu
#define PPU_PWPR_DYN_EN          0x00000100u
#define PPU_PWPR_LOCK_EN         0x00001000u
#define PPU_PWSR_STATUS          0x0000000Fu
#define PPU_PWSR_DYN_STATUS      0x00000100u
#define PPU_PWSR_LOCK_STATUS     0x00001000u
#define PPU_DISR_DEVACTIVE0      0x00000001u
#define PPU_PWCR_DEVREQEN0       0x00000001u
#define PPU_PWCR_PWR_DEVACTIVEEN0 0x00000100u
#define PPU_PTCR_WARM_RST_DEVREQEN 0x00000001u
#define PPU_UNLK_UNLOCK          0x00000001u

#define PPU_ISR_STA_POLICY_TRN   0x00000001u
#define PPU_ISR_STA_ACCEPT       0x00000002u
#define PPU_ISR_STA_DENY         0x00000004u
#define PPU_ISR_LOCKED           0x00000020u
#define PPU_ISR_OTHER            0x00000080u   /* derived from PPU_AISR: not W1C */
#define PPU_ISR_PWR_ACTIVE_EDGE0 0x00000100u
#define PPU_ISR_W1C              (PPU_ISR_STA_POLICY_TRN | PPU_ISR_STA_ACCEPT | \
                                  PPU_ISR_STA_DENY | PPU_ISR_LOCKED |           \
                                  PPU_ISR_PWR_ACTIVE_EDGE0)
#define PPU_AISR_UNSPT_POLICY    0x00000001u
#define PPU_AISR_DYN_ACCEPT      0x00000002u
#define PPU_AISR_DYN_DENY        0x00000004u
#define PPU_AISR_W1C             0x00000007u

/* Which retention RAM registers a build has (struct ppu.ret_ram_regs). Each has
 * its own presence bit in PPU_IDR1 (Table 5-27): b6 FUNC_RET_RAM_REG, b5
 * FULL_RET_RAM_REG, b4 MEM_RET_RAM_REG; an absent one is reserved. */
#define PPU_RR_FUNRR             0x4u   /* PPU_FUNRR, IDR1 b6 */
#define PPU_RR_FULRR             0x2u   /* PPU_FULRR, IDR1 b5 */
#define PPU_RR_MEMRR             0x1u   /* PPU_MEMRR, IDR1 b4 */

enum ppu_edge { PPU_EDGE_NONE = 0, PPU_EDGE_RISE = 1, PPU_EDGE_FALL = 2, PPU_EDGE_BOTH = 3 };

#define PPU_AIDR_V1_1            0x00000011u

enum ppu_status {
  PPU_OK            =  0,
  PPU_E_NOT_PPU     = -1,   /* PPU_AIDR is not architecture v1.1           */
  PPU_E_UNSUPPORTED = -2,   /* the build does not have the mode or feature */
  PPU_E_REFUSED     = -3,   /* PPU_PWPR write discarded: unsupported policy */
  PPU_E_REVERTED    = -4,   /* PPU_PWPR changed under us: a denial         */
  PPU_E_STATE       = -5,   /* a Section 4.1.1 / 4.1.3 precondition does not
                               hold (DEVREQEN rules; PWR_DYN_EN changed again
                               before PWR_DYN_STATUS caught up)           */
};

struct ppu {
  uint32_t base;
  uint32_t idr0, idr1, iidr, aidr;
  uint16_t sta_modes;       /* bit m: mode m is a supported STATIC policy   */
  uint16_t dyn_modes;       /* bit m: mode m is a supported DYNAMIC policy  */
  uint8_t  channels;        /* device interface channels (IDR0.DEVCHAN)     */
  bool     lock;            /* IDR1.LOCK_SPT                                */
  bool     off_mem_ret;     /* IDR1.OFF_MEM_RET_TRANS                       */
  uint8_t  ret_ram_regs;    /* PPU_RR_*: which retention RAM registers exist */
  bool     entry_delay;     /* IDR1.PWR_MODE_ENTRY_DEL_SPT                  */
  bool     sw_dev_delay;    /* IDR1.SW_DEV_DEL_SPT                          */
};

/* ---- Raw access ---- */
uint32_t ppu_rd(const struct ppu *p, uint32_t off);
void     ppu_wr(const struct ppu *p, uint32_t off, uint32_t val);

/* ---- Discovery ---- */
int  ppu_probe(struct ppu *p, uint32_t base);
bool ppu_policy_supported(const struct ppu *p, enum ppu_mode m, bool dyn);

/* ---- Policy and status ----
 * ppu_set_policy(m, dyn, lock) writes PPU_PWPR once, {m, PWR_DYN_EN = dyn,
 * LOCK_EN = lock}, and reads it back (README Section 6 rules 1, 2 and 10):
 *
 *   PPU_OK             written, and still there at the read-back
 *   PPU_E_UNSUPPORTED  NOTHING WRITTEN: lock on a build without LOCK_SPT
 *                      (PPU_IDR1 b2), or dyn on a build with no dynamic mode
 *                      (PPU_IDR0 [29:20] all 0). There LOCK_EN or PWR_DYN_EN
 *                      is reserved (Table 5-2: "If dynamic modes are not
 *                      supported this bit is reserved"), and reserved bits are
 *                      WI/RAZ (Section 5.2), so the PPU would take the write as
 *                      the STATIC policy m -- which was not asked for, and would
 *                      take effect with nothing on the bus to say so
 *   PPU_E_STATE        nothing written: PWR_DYN_EN would change before
 *                      PWR_DYN_STATUS shows the last change (4.1.1)
 *   PPU_E_REFUSED      written and discarded whole: {m, dyn} is not a
 *                      supported policy (4.1.1; UNSPT_POLICY is raised)
 *   PPU_E_REVERTED     written, then reverted by a denial (Table 4-1)
 */
int           ppu_set_policy(const struct ppu *p, enum ppu_mode m, bool dyn, bool lock);
uint32_t      ppu_policy(const struct ppu *p);            /* raw PPU_PWPR */
uint32_t      ppu_status(const struct ppu *p);            /* raw PPU_PWSR */
enum ppu_mode ppu_mode(const struct ppu *p);              /* PWSR.PWR_STATUS */
bool          ppu_locked(const struct ppu *p);
bool          ppu_dyn_settled(const struct ppu *p);       /* PWR_DYN_STATUS == PWR_DYN_EN */
void          ppu_unlock(const struct ppu *p);
bool          ppu_dev_active(const struct ppu *p);        /* DISR: raw DEVQACTIVE */

/* ---- Interface configuration (Section 4.1.3) ---- */
void ppu_set_devactive_en(const struct ppu *p, bool en);
bool ppu_devactive_en(const struct ppu *p);
int  ppu_set_devreq_en(const struct ppu *p, bool en);
void ppu_set_warm_rst_devreq_en(const struct ppu *p, bool en);

/* ---- Interrupts (Section 4.1.2) ---- */
void ppu_irq_mask(const struct ppu *p, uint32_t imr, uint32_t aimr);
void ppu_irq_status(const struct ppu *p, uint32_t *isr, uint32_t *aisr);
void ppu_irq_clear(const struct ppu *p, uint32_t isr, uint32_t aisr);
void ppu_set_edge_irq(const struct ppu *p, enum ppu_edge e);

/* ---- Retention RAM and timing ----
 * ppu_set_ret_ram writes each of PPU_FUNRR, PPU_FULRR and PPU_MEMRR that
 * PPU_IDR1 reports present (PPU_RR_*), and never a reserved one; the value for
 * an absent register is ignored. PPU_E_UNSUPPORTED if the build has none.
 * Program it before the domain enters the mode, with the PPU idle. */
int  ppu_set_ret_ram(const struct ppu *p, uint8_t funrr, uint8_t fulrr, uint8_t memrr);
int  ppu_set_entry_delay(const struct ppu *p, uint8_t cycles);

/* Device control delays (PPU_DCDR0/1, Table 4-5): the spacing, in PPU cycles,
 * between the five device controls as a transition moves them. Each field is a
 * minimum of value + 1 cycles. */
struct ppu_dev_delays {
  uint8_t rst_hwstat;   /* reset release     -> PPUHWSTAT update   DCDR0[23:16] */
  uint8_t iso_clken;    /* isolation release -> clock enable       DCDR0[15:8]  */
  uint8_t clken_rst;    /* clock enable      -> reset release      DCDR0[7:0]   */
  uint8_t clken_iso;    /* clock disable     -> isolation assert   DCDR1[15:8]  */
  uint8_t iso_rst;      /* isolation assert  -> reset assert       DCDR1[7:0]   */
};
int  ppu_set_dev_delays(const struct ppu *p, const struct ppu_dev_delays *d);
void ppu_get_dev_delays(const struct ppu *p, struct ppu_dev_delays *d);

#endif
