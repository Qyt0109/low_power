/* Arm PPU v1.1 register driver. See ppu_v1.h. */
#include "ppu_v1.h"
#include "scp_regs.h"

/* PPU_IDR0 is not in mode-encoding order: its support bits run OFF, OFF_EMU,
 * MEM_RET, MEM_RET_EMU, LOGIC_RET, MEM_OFF, FULL_RET, FUNC_RET, ON, WARM_RST,
 * DBG_RECOV -- MEM_OFF (6) before FULL_RET (5). Table 5-26, and REGISTERS.md
 * Section 4.7. Hence a table, not "8 + mode". -1: no such bit. */
static const int8_t idr0_sta_bit[11] = {
  [PPU_MODE_OFF]         =  8,
  [PPU_MODE_OFF_EMU]     =  9,
  [PPU_MODE_MEM_RET]     = 10,
  [PPU_MODE_MEM_RET_EMU] = 11,
  [PPU_MODE_LOGIC_RET]   = 12,
  [PPU_MODE_FULL_RET]    = 14,
  [PPU_MODE_MEM_OFF]     = 13,
  [PPU_MODE_FUNC_RET]    = 15,
  [PPU_MODE_ON]          = 16,
  [PPU_MODE_WARM_RST]    = 17,
  [PPU_MODE_DBG_RECOV]   = 18,
};
static const int8_t idr0_dyn_bit[11] = {
  [PPU_MODE_OFF]         = 20,
  [PPU_MODE_OFF_EMU]     = 21,
  [PPU_MODE_MEM_RET]     = 22,
  [PPU_MODE_MEM_RET_EMU] = 23,
  [PPU_MODE_LOGIC_RET]   = 24,
  [PPU_MODE_FULL_RET]    = 26,
  [PPU_MODE_MEM_OFF]     = 25,
  [PPU_MODE_FUNC_RET]    = 27,
  [PPU_MODE_ON]          = 28,
  [PPU_MODE_WARM_RST]    = 29,
  [PPU_MODE_DBG_RECOV]   = -1,
};

#define IDR0_DEVCHAN            0x0000000Fu
#define IDR1_OFF_MEM_RET_TRANS  (1u << 12)
#define IDR1_RET_RAM_SHIFT      4u      /* b6 FUNC_RET, b5 FULL_RET, b4 MEM_RET _RAM_REG */
#define IDR1_LOCK_SPT           (1u << 2)
#define IDR1_SW_DEV_DEL_SPT     (1u << 1)
#define IDR1_ENTRY_DEL_SPT      (1u << 0)

uint32_t ppu_rd(const struct ppu *p, uint32_t off)
{
  return mmio_read32(p->base + off);
}

void ppu_wr(const struct ppu *p, uint32_t off, uint32_t val)
{
  mmio_write32(p->base + off, val);
}

int ppu_probe(struct ppu *p, uint32_t base)
{
  p->base = base;
  p->aidr = ppu_rd(p, PPU_AIDR);
  if (p->aidr != PPU_AIDR_V1_1) return PPU_E_NOT_PPU;
  p->idr0 = ppu_rd(p, PPU_IDR0);
  p->idr1 = ppu_rd(p, PPU_IDR1);
  p->iidr = ppu_rd(p, PPU_IIDR);

  p->sta_modes = 0;
  p->dyn_modes = 0;
  for (unsigned m = 0; m <= PPU_MODE_DBG_RECOV; m++) {
    if (p->idr0 & (1u << idr0_sta_bit[m])) p->sta_modes |= (uint16_t)(1u << m);
    if (idr0_dyn_bit[m] >= 0 && (p->idr0 & (1u << idr0_dyn_bit[m])))
      p->dyn_modes |= (uint16_t)(1u << m);
  }
  p->channels     = (uint8_t)(p->idr0 & IDR0_DEVCHAN);
  p->lock         = (p->idr1 & IDR1_LOCK_SPT) != 0;
  p->off_mem_ret  = (p->idr1 & IDR1_OFF_MEM_RET_TRANS) != 0;
  p->ret_ram_regs = (uint8_t)((p->idr1 >> IDR1_RET_RAM_SHIFT) &
                              (PPU_RR_FUNRR | PPU_RR_FULRR | PPU_RR_MEMRR));
  p->entry_delay  = (p->idr1 & IDR1_ENTRY_DEL_SPT) != 0;
  p->sw_dev_delay = (p->idr1 & IDR1_SW_DEV_DEL_SPT) != 0;
  return PPU_OK;
}

bool ppu_policy_supported(const struct ppu *p, enum ppu_mode m, bool dyn)
{
  if ((unsigned)m > PPU_MODE_DBG_RECOV) return false;
  return ((dyn ? p->dyn_modes : p->sta_modes) >> m) & 1u;
}

/* README Section 6, rules 1 and 2. Every write is read back, because the PPU
 * can make it not have happened in two ways, and neither says so on the bus:
 *
 *   refused   PPU 4.1.1: an unsupported policy leaves PPU_PWPR unchanged --
 *             and REGISTERS.md 4.1 sharpens that: the WHOLE write is
 *             discarded, LOCK_EN and PWR_DYN_EN with it.
 *   reverted  PPU 4.1.1, Table 4-1: a denied transition puts the policy back
 *             to the current mode. By the time of the read-back the PPU may
 *             already have tried and been refused by the device.
 *
 * They are told apart without reading PPU_AISR, which belongs to the manager's
 * event path: whether a policy is supported is decided by the same table
 * PPU_IDR0 reports, so the build itself says which one this was.
 *
 * README Section 6, rule 10 -- PPU 4.1.1 "Power Policy Programming": after
 * software changes PWR_DYN_EN it "must wait until the value is reflected in
 * ... PPU_PWSR.PWR_DYN_STATUS ... before making further modifications to the
 * dynamic transition enables. Otherwise the PPU behavior is UNPREDICTABLE."
 * The status catches up only once a transition in flight has finished, so a
 * write that would change the enable again before then is refused here with
 * PPU_E_STATE, like the other Section 4.1.3 preconditions; the caller waits and
 * retries (mod/pd.c does).
 *
 * LOCK_EN and PWR_DYN_EN on a build without the feature: refused before any
 * write (PPU_E_UNSUPPORTED). Table 5-2 makes each reserved there, and Section 5.2
 * makes reserved bits WI/RAZ: the PPU would admit {m, dyn} as the static
 * policy m (ppu_regs.sv:325-326 masks both), m would take effect, and the
 * read-back could only report a mismatch. Asking for a dynamic policy with no
 * dynamic mode built is the caller's error, not the PPU's refusal. */
int ppu_set_policy(const struct ppu *p, enum ppu_mode m, bool dyn, bool lock)
{
  if (lock && !p->lock) return PPU_E_UNSUPPORTED;
  if (dyn && !p->dyn_modes) return PPU_E_UNSUPPORTED;
  const uint32_t fields = PPU_PWPR_POLICY | PPU_PWPR_DYN_EN | PPU_PWPR_LOCK_EN;
  uint32_t want = ((uint32_t)m & PPU_PWPR_POLICY)
                | (dyn  ? PPU_PWPR_DYN_EN  : 0u)
                | (lock ? PPU_PWPR_LOCK_EN : 0u);
  uint32_t cur = ppu_rd(p, PPU_PWPR);
  if (((cur ^ want) & PPU_PWPR_DYN_EN) && !ppu_dyn_settled(p)) return PPU_E_STATE;
  ppu_wr(p, PPU_PWPR, want);
  uint32_t got = ppu_rd(p, PPU_PWPR) & fields;
  if (got == want) return PPU_OK;
  return ppu_policy_supported(p, m, dyn) ? PPU_E_REVERTED : PPU_E_REFUSED;
}

uint32_t ppu_policy(const struct ppu *p) { return ppu_rd(p, PPU_PWPR); }
uint32_t ppu_status(const struct ppu *p) { return ppu_rd(p, PPU_PWSR); }

/* Has the last PWR_DYN_EN change taken effect (PPU_PWSR.PWR_DYN_STATUS equal to
 * PPU_PWPR.PWR_DYN_EN)? Only then may the enable be changed again. */
bool ppu_dyn_settled(const struct ppu *p)
{
  bool en = (ppu_policy(p) & PPU_PWPR_DYN_EN) != 0;
  bool st = (ppu_status(p) & PPU_PWSR_DYN_STATUS) != 0;
  return en == st;
}

enum ppu_mode ppu_mode(const struct ppu *p)
{
  return (enum ppu_mode)(ppu_status(p) & PPU_PWSR_STATUS);
}

bool ppu_locked(const struct ppu *p)
{
  return (ppu_status(p) & PPU_PWSR_LOCK_STATUS) != 0;
}

/* Releases the lock ONCE; the PPU locks again on its next entry to a lockable
 * mode. And nothing may write PPU_PWPR with LOCK_EN set until the domain has
 * actually left that mode, or it re-locks at once (PPU 3.4.3, design doc
 * 5.6.7). Leaving a locked mode for good is one PPU_PWPR write with LOCK_EN
 * clear -- which is what mod/pd.c does, and why it never calls this. */
void ppu_unlock(const struct ppu *p)
{
  ppu_wr(p, PPU_UNLK, PPU_UNLK_UNLOCK);
}

bool ppu_dev_active(const struct ppu *p)
{
  return (ppu_rd(p, PPU_DISR) & PPU_DISR_DEVACTIVE0) != 0;
}

/* PPU 3.4.1: "Disabled power mode DEVACTIVE inputs are always assumed to be
 * LOW for the purposes of transition control." It does not stop the input
 * edge interrupt, which is how the SCP still sees a wake it has disarmed. */
void ppu_set_devactive_en(const struct ppu *p, bool en)
{
  uint32_t v = ppu_rd(p, PPU_PWCR);
  v = en ? (v | PPU_PWCR_PWR_DEVACTIVEEN0) : (v & ~PPU_PWCR_PWR_DEVACTIVEEN0);
  ppu_wr(p, PPU_PWCR, v);
}

bool ppu_devactive_en(const struct ppu *p)
{
  return (ppu_rd(p, PPU_PWCR) & PPU_PWCR_PWR_DEVACTIVEEN0) != 0;
}

/* README Section 6, rule 6 -- PPU 4.1.3: DEVREQEN changes only with the PPU in
 * static mode and its policy reached, and a disabled channel is re-enabled only
 * from ON. Either violation is UNPREDICTABLE, so it is refused here. */
int ppu_set_devreq_en(const struct ppu *p, bool en)
{
  uint32_t pwcr = ppu_rd(p, PPU_PWCR);
  bool     cur  = (pwcr & PPU_PWCR_DEVREQEN0) != 0;
  if (cur == en) return PPU_OK;
  uint32_t pwsr = ppu_status(p), pwpr = ppu_policy(p);
  if ((pwsr & PPU_PWSR_DYN_STATUS) || (pwpr & PPU_PWPR_DYN_EN)) return PPU_E_STATE;
  if ((pwsr & PPU_PWSR_STATUS) != (pwpr & PPU_PWPR_POLICY))     return PPU_E_STATE;
  if (en && (pwsr & PPU_PWSR_STATUS) != PPU_MODE_ON)            return PPU_E_STATE;
  ppu_wr(p, PPU_PWCR, en ? (pwcr | PPU_PWCR_DEVREQEN0) : (pwcr & ~PPU_PWCR_DEVREQEN0));
  return PPU_OK;
}

void ppu_set_warm_rst_devreq_en(const struct ppu *p, bool en)
{
  ppu_wr(p, PPU_PTCR, en ? PPU_PTCR_WARM_RST_DEVREQEN : 0u);
}

/* A 1 MASKS the event, and masking suppresses the status bit itself, not just
 * the line (REGISTERS.md 4.4): a masked event cannot be polled for later. */
void ppu_irq_mask(const struct ppu *p, uint32_t imr, uint32_t aimr)
{
  ppu_wr(p, PPU_IMR, imr);
  ppu_wr(p, PPU_AIMR, aimr);
}

void ppu_irq_status(const struct ppu *p, uint32_t *isr, uint32_t *aisr)
{
  *isr  = ppu_rd(p, PPU_ISR);
  *aisr = ppu_rd(p, PPU_AISR);
}

/* Write-1-to-clear, and only the bits given: an event that arrived after the
 * status was read stays set, keeps the line HIGH, and is taken next time. */
void ppu_irq_clear(const struct ppu *p, uint32_t isr, uint32_t aisr)
{
  if (isr  & PPU_ISR_W1C)  ppu_wr(p, PPU_ISR,  isr  & PPU_ISR_W1C);
  if (aisr & PPU_AISR_W1C) ppu_wr(p, PPU_AISR, aisr & PPU_AISR_W1C);
}

void ppu_set_edge_irq(const struct ppu *p, enum ppu_edge e)
{
  ppu_wr(p, PPU_IESR, (uint32_t)e & 3u);      /* channel 0: [1:0] */
}

/* The byte's meaning is the PCSM's (REGISTERS.md 4.5); for ppu_pcsm it is one
 * retention enable per SRAM bank. Program it before entering the mode: a
 * change made while already in it is not re-sent.
 *
 * Each register on its own presence bit (Table 5-27, PPU_IDR1 b6/b5/b4;
 * ppu_regs.sv:213-215, REGISTERS.md 4.7): a build may have any subset -- soc4's
 * CPU0 has PPU_FULRR alone, its ACC0 PPU_MEMRR alone. An absent register is
 * reserved, so it is not written at all. */
int ppu_set_ret_ram(const struct ppu *p, uint8_t funrr, uint8_t fulrr, uint8_t memrr)
{
  if (!p->ret_ram_regs) return PPU_E_UNSUPPORTED;
  if (p->ret_ram_regs & PPU_RR_FUNRR) ppu_wr(p, PPU_FUNRR, funrr);
  if (p->ret_ram_regs & PPU_RR_FULRR) ppu_wr(p, PPU_FULRR, fulrr);
  if (p->ret_ram_regs & PPU_RR_MEMRR) ppu_wr(p, PPU_MEMRR, memrr);
  return PPU_OK;
}

void ppu_get_dev_delays(const struct ppu *p, struct ppu_dev_delays *d)
{
  uint32_t r0 = ppu_rd(p, PPU_DCDR0), r1 = ppu_rd(p, PPU_DCDR1);
  d->rst_hwstat = (uint8_t)(r0 >> 16);
  d->iso_clken  = (uint8_t)(r0 >> 8);
  d->clken_rst  = (uint8_t)r0;
  d->clken_iso  = (uint8_t)(r1 >> 8);
  d->iso_rst    = (uint8_t)r1;
}

/* Writable only when the build has SW_DEV_DEL_SPT; otherwise the registers are
 * read-only and the built-in values apply (REGISTERS.md 4.6), which the caller
 * can still read with ppu_get_dev_delays. Program them with the PPU idle: they
 * pace a transition, and one under way would be paced by a mix. Read back like
 * every other configuration write. */
int ppu_set_dev_delays(const struct ppu *p, const struct ppu_dev_delays *d)
{
  if (!p->sw_dev_delay) return PPU_E_UNSUPPORTED;
  ppu_wr(p, PPU_DCDR0, ((uint32_t)d->rst_hwstat << 16) | ((uint32_t)d->iso_clken << 8)
                       | d->clken_rst);
  ppu_wr(p, PPU_DCDR1, ((uint32_t)d->clken_iso << 8) | d->iso_rst);
  struct ppu_dev_delays rb;
  ppu_get_dev_delays(p, &rb);
  return (rb.rst_hwstat == d->rst_hwstat && rb.iso_clken == d->iso_clken &&
          rb.clken_rst == d->clken_rst && rb.clken_iso == d->clken_iso &&
          rb.iso_rst == d->iso_rst) ? PPU_OK : PPU_E_REFUSED;
}

/* The same delay, in PPU cycles, before entering each lower-priority mode:
 * the hysteresis on the autonomous path (design doc 9.3). LOGIC_RET's field is
 * reserved on a Q-Channel PPU and is left zero. */
int ppu_set_entry_delay(const struct ppu *p, uint8_t cycles)
{
  if (!p->entry_delay) return PPU_E_UNSUPPORTED;
  uint32_t c = cycles;
  ppu_wr(p, PPU_EDTR0, (c << 24) | (c << 8) | c);   /* FULL_RET, MEM_RET, OFF */
  ppu_wr(p, PPU_EDTR1, (c << 8) | c);               /* FUNC_RET, MEM_OFF      */
  return PPU_OK;
}
