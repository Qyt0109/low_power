/* The SCP's interrupt inputs: the status/enable block (scp_irq.sv) and the
 * platform's input table.
 *
 * Platform plan H7-H9 and F10 (Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md
 * Sections 14.7 and 15.2 phase 2). Every interrupt source of the SCP but its
 * timer is one input of one generic bank: each PPU's interrupt, the RPMI
 * doorbell, the SoC PLIC's output and per-hart pending, and the raw wake lines.
 * The bank drives the core's machine external interrupt, line 11; Ibex's fast
 * lines are not used. The hardware knows nothing of what an input is FOR: the
 * platform header says it, one entry per input, in input order:
 *
 *   #define SCP_PLAT_INPUTS(I)  I(id, name, mode, en, act, arg) ...
 *
 *   id    an identifier: SCP_IN_<id> is the input's index
 *   name  for the console
 *   mode  SCP_IN_LEVEL or SCP_IN_EDGE, programmed into EDGE
 *   en    1: enabled once its owner is up (see OWNERS); 0: masked for good
 *   act   enum scp_in_act, below
 *   arg   the domain (PPU, POWER_UP), the transport (DOORBELL) or the reason
 *         code (REASON); 0 otherwise
 *
 * THE HANDLER ONLY SETS A FLAG. The line raises trap_external() (hal/trap.c),
 * which masks mie.MEIE, sets trap_ext_pending and touches no device.
 * scp_irq_collect(), in thread context (pd_poll() calls it), turns the
 * block's ACTIVE bits into flags and sets MEIE again:
 *
 *   level input  masked in ENABLE, then its PENDING bit cleared: its source is
 *                still HIGH, and only its owner can clear it (a PPU's status
 *                registers, the mailbox's RING, the SoC's line). The owner
 *                unmasks it with scp_irq_unmask() once it has: that clears
 *                PENDING and sets ENABLE, so a source still HIGH interrupts
 *                again at once, as a level must
 *   edge input   its PENDING bit cleared (W1C); it stays enabled
 *
 * and then, by the table's action:
 *
 *   SCP_ACT_PPU       bit `arg` of scp_irq_take_ppu(): pd_poll() reads and
 *                     clears that PPU's status, then unmasks the input
 *   SCP_ACT_DOORBELL  nothing more: the main loop reads the mailbox's RING
 *                     itself, and hal/rpmi_db.c unmasks the input after its
 *                     clear (rpmi_db_clear)
 *   SCP_ACT_POWER_UP, SCP_ACT_NOTIFY, SCP_ACT_REASON, SCP_ACT_IGNORE
 *                     bit i of scp_irq_take_act(): the main loop's policy
 *                     (mod/policy.c, policy_work) runs the action. A level
 *                     input stays masked until the policy re-arms it:
 *                     POWER_UP's at the owning agent's next OFF vote (the
 *                     wake vote's end, mod/policy.h), the others with
 *                     scp_irq_rearm_low(): the first collect that sees the
 *                     input LOW unmasks it
 *
 * OWNERS. scp_irq_init() programs EDGE from the table and leaves every input
 * masked except the four policy actions with en = 1. PPU inputs are unmasked
 * by pd_init(), the doorbell by rpmi_db_set_mask(), a clock/reset bridge
 * input (SCP_ACT_CKRST, en = 1) by policy_init(). An image with no policy
 * (soc4_stress) collects their flags and never acts on them, and never opens
 * the bridge input.
 *
 * Every function is for thread context. The block's registers are written
 * only from there, so the ENABLE shadow needs no lock.
 */
#ifndef SCP_IRQ_H
#define SCP_IRQ_H

#include <stdint.h>
#include <stdbool.h>
#include "scp_regs.h"

enum scp_in_mode { SCP_IN_LEVEL = 0, SCP_IN_EDGE = 1 };

enum scp_in_act {
  SCP_ACT_IGNORE = 0,   /* cleared and counted; nothing else                  */
  SCP_ACT_PPU,          /* PPU `arg`'s interrupt line                         */
  SCP_ACT_DOORBELL,     /* RPMI transport `arg`'s doorbell                    */
  SCP_ACT_POWER_UP,     /* power domain `arg` up: a wake vote (mod/policy.h)  */
  SCP_ACT_NOTIFY,       /* tell the policy                                    */
  SCP_ACT_REASON,       /* record wake reason `arg`                           */
  SCP_ACT_CKRST,        /* a clock/reset bridge fault: the policy reads the
                           platform's bridge status (SCP_PLAT_CKRST_STAT),
                           logs and FAULTs each flagged domain (mod/policy.h,
                           CLOCK/RESET BRIDGE FAULTS). Owned by the policy:
                           masked until policy_init() opens it              */
};

struct scp_in_cfg {
  const char *name;
  uint8_t mode;         /* enum scp_in_mode */
  uint8_t en;
  uint8_t act;          /* enum scp_in_act  */
  uint8_t arg;
};

#ifndef SCP_PLAT_INPUTS
#error "the platform header must define SCP_PLAT_INPUTS (the input table)"
#endif
#define SCP_IN_ENUM(id, ...) SCP_IN_##id,
enum { SCP_PLAT_INPUTS(SCP_IN_ENUM) SCP_NUM_IN };
#undef SCP_IN_ENUM
#define SCP_IN_BIT(i) (1u << (i))

extern const struct scp_in_cfg scp_in_cfg[SCP_NUM_IN];

struct scp_irq_stats {
  uint32_t collects;              /* times the line was taken and collected  */
  uint32_t taken[SCP_NUM_IN];     /* per input: events collected             */
};
extern struct scp_irq_stats scp_irq_stats;

int      scp_irq_init(void);            /* 0, or -1 if INFO disagrees with the table */
void     scp_irq_collect(void);
uint32_t scp_irq_take_ppu(void);        /* bit d: PPU d's input fired; it is masked  */
uint32_t scp_irq_take_act(void);        /* bit i: input i's policy action is due     */
bool     scp_irq_act_pending(void);     /* ...without taking them                    */
bool     scp_irq_held(void);            /* a level input waits to be seen LOW        */
void     scp_irq_mask(uint32_t bits);
void     scp_irq_unmask(uint32_t bits); /* clear PENDING, then set ENABLE            */
void     scp_irq_rearm_low(uint32_t bits);
uint32_t scp_irq_ppu_bit(unsigned d);   /* PPU d's input, as a bit; 0 if none        */
uint32_t scp_irq_db_bit(unsigned t);    /* doorbell t's input, as a bit; 0 if none   */
uint32_t scp_irq_act_bits(unsigned act);/* the inputs with action act and en = 1     */

static inline uint32_t scp_irq_raw(void) { return mmio_read32(SCP_IRQ_RAW); }

#endif
