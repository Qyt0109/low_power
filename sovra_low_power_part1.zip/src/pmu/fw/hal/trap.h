/* Trap handling: what crt0.S's vector table jumps to.
 *
 * The handlers only RECORD. Everything that talks to a device happens in
 * thread context -- README Section 5.1 -- so that no bus access is ever made
 * from an interrupt and no driver state is shared with one.
 *
 *   timer         the handler acknowledges it (a write to mtimecmp) and counts.
 *   external      line 11, the SCP's interrupt block (scp_irq.sv): every PPU,
 *                 the RPMI doorbell, the SoC PLIC's outputs and the wake lines.
 *                 Level-sensitive. The handler clears mie.MEIE, sets
 *                 trap_ext_pending and counts, and touches no device;
 *                 scp_irq_collect() (hal/scp_irq.c), called from pd_poll() in
 *                 thread context, reads the block, turns its inputs into flags
 *                 and sets MEIE again. Returning without masking would re-enter
 *                 the handler forever.
 *   fast lines    16-30: tied LOW (scp_top.sv), so taking one is a wiring bug.
 *   exception     fatal, unless trap_expect_fault() armed it: then it is
 *                 recorded, the faulting instruction is skipped, and execution
 *                 continues. That is how a test proves a bus error reaches the
 *                 firmware as an access fault.
 *   anything else fatal: an interrupt from a line with no source is a wiring
 *                 bug, and returning from it would only hide one.
 */
#ifndef TRAP_H
#define TRAP_H

#include <stdint.h>
#include <stdbool.h>

struct trap_fault {
  uint32_t mcause;
  uint32_t mepc;
  uint32_t mtval;
};

extern volatile uint32_t trap_timer_count;
extern volatile uint32_t trap_ext_pending;   /* line 11 was taken, and masked */
extern volatile uint32_t trap_ext_count;

void trap_expect_fault(void);                 /* the next exception is wanted */
bool trap_take_fault(struct trap_fault *f);   /* one was taken since; clears it */

#endif
