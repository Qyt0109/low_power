/* Simulation control: the testbench's device, tb/pmu/scp_sim_ctrl.sv.
 *
 * TESTBENCH ONLY. It does not exist in silicon. One part of it is used outside
 * the test programs: the console (lib/console.c needs a backend, and this is
 * the only one there is). HALT, CHECK and the device stimulus registers are
 * for test programs (soc4/fw/test/), which play the part of the software
 * running in the domains (see scp_sim_ctrl.sv's header).
 */
#ifndef SIM_H
#define SIM_H

#include "scp_regs.h"

#define SIM_OUT        (SCP_SIM_BASE + 0x000u)  /* W   console byte              */
#define SIM_CYCLE      (SCP_SIM_BASE + 0x004u)  /* R   cycles since reset        */
#define SIM_HALT       (SCP_SIM_BASE + 0x008u)  /* W   end of test: 0 = pass     */
#define SIM_CHECK      (SCP_SIM_BASE + 0x00Cu)  /* W   {[15:8] dom, [3:0] mode}  */
#define SIM_WAKE       (SCP_SIM_BASE + 0x010u)  /* RW  bit n: domain n's wake    */
#define SIM_DENY       (SCP_SIM_BASE + 0x014u)  /* RW  bit n: deny while busy    */
#define SIM_WORK_LEN   (SCP_SIM_BASE + 0x018u)  /* RW  burst length for START, as
                                                       many bits as the device has
                                                       (soc4 DEV_CNT_W = 12)     */
#define SIM_START      (SCP_SIM_BASE + 0x01Cu)  /* W   bit n: start a burst      */
#define SIM_LIGHT      (SCP_SIM_BASE + 0x020u)  /* RW  bit n: bursts never busy  */
#define SIM_TB_CHECKS  (SCP_SIM_BASE + 0x024u)  /* R   testbench checks so far   */
#define SIM_TB_ERRORS  (SCP_SIM_BASE + 0x028u)  /* R   ...and how many failed, plus
                                                       every monitor, power-model,
                                                       AXI and settle violation  */
#define SIM_OBS_DOM    (SCP_SIM_BASE + 0x02Cu)  /* RW  domain the OBS window shows */
#define SIM_IP_CMD     (SCP_SIM_BASE + 0x030u)  /* RW  [2n+1:2n] domain n's IP command */
#define SIM_IP_SEED    (SCP_SIM_BASE + 0x034u)  /* RW  [7:0] RAM pattern seed    */
#define SIM_AP_CMD     (SCP_SIM_BASE + 0x038u)  /* RW  a command to the testbench  */
#define SIM_AP_STAT    (SCP_SIM_BASE + 0x03Cu)  /* R   the command, echoed once
                                                       applied (soc4_tb)         */
#define SIM_OBS(k)     (SCP_SIM_BASE + 0x040u + 4u * (uint32_t)(k))   /* R, k < 32 */

/* The observation window: what the selected domain did AT ITS PINS, counted
 * and timed by the testbench (soc4_tb.sv, "Observation window"). Counts run
 * from reset; take differences. Cycles are PPU clock cycles. */
enum sim_obs {
  OBS_QREQ_FALLS = 0,   /* DEVQREQn falls: device handshakes requested        */
  OBS_PREQ_RISES = 1,   /* PCSMPREQ rises: PCSM handshakes                     */
  OBS_HOPS       = 2,   /* committed PWR_STATUS changes                        */
  OBS_LIVE       = 3,   /* live pins, OBS_LIVE_* below                         */
  OBS_EV_TRN     = 4,   /* event pulses, before masking: STA_POLICY_TRN        */
  OBS_EV_SACC    = 5,   /*   STA_ACCEPT                                        */
  OBS_EV_SDENY   = 6,   /*   STA_DENY                                          */
  OBS_EV_DACC    = 7,   /*   DYN_ACCEPT                                        */
  OBS_EV_DDENY   = 8,   /*   DYN_DENY                                          */
  OBS_EV_LOCKED  = 9,   /*   LOCKED                                            */
  OBS_UP_LAST    = 10,  /* last spacings up: [7:0] iso>clken [15:8] clken>rst
                           [23:16] rst>hwstat                                   */
  OBS_DN_LAST    = 11,  /* last spacings down: [7:0] clken>iso [15:8] iso>rst  */
  OBS_LAT_WR     = 12,  /* PWPR write -> next DEVQREQn fall                    */
  OBS_LAT_ACT    = 13,  /* DEVQACTIVE fall -> next DEVQREQn fall               */
  OBS_DC_EDGES   = 14,  /* changes of any of the five device controls          */
  OBS_CLK_GATES  = 15,  /* times the PPU's own clock was gated                 */
  OBS_EV_UNSPT   = 16,  /*   UNSPT_POLICY                                      */
  OBS_PCSM_REQ   = 17,  /* PCSMPSTATE at the last PCSMPREQ rise                */
  OBS_UP_MIN     = 18,  /* shortest spacings up, as OBS_UP_LAST (255: none)    */
  OBS_DN_MIN     = 19,  /* shortest spacings down, as OBS_DN_LAST              */
  OBS_SPACINGS   = 20,  /* spacings measured and checked                       */
  OBS_HWSTAT     = 21,  /* PPUHWSTAT                                           */
  OBS_QREQ_RISES = 22,  /* DEVQREQn rises                                      */
  OBS_RAM        = 23,  /* [7:0] per-bank RAM verify result, [8] done (domain ON only) */
  OBS_EV_EDGE    = 24,  /*   input edge (PWR_ACTIVE_EDGE), as IESR selects     */
  OBS_ACT_EDGES  = 25,  /* DEVQACTIVE edges at the pin                         */
  OBS_ERRS       = 26,  /* testbench errors attributed to this domain          */
};
#define OBS_LIVE_STATUS(v)   ((v) & 0xFu)
#define OBS_LIVE_DC(v)       (((v) >> 4) & 0x1Fu)  /* {POR,WARM,RET,CLKEN,ISOn} */
#define OBS_LIVE_QREQN       (1u << 9)
#define OBS_LIVE_QACCEPTN    (1u << 10)
#define OBS_LIVE_QDENY       (1u << 11)
#define OBS_LIVE_QACTIVE     (1u << 12)
#define OBS_LIVE_PREQ        (1u << 13)
#define OBS_LIVE_PACCEPT     (1u << 14)
#define OBS_LIVE_IRQ         (1u << 15)
#define OBS_LIVE_PSTATE(v)   ((v) >> 16)

static inline uint32_t sim_cycle(void)            { return mmio_read32(SIM_CYCLE); }
static inline void     sim_halt(uint32_t code)    { mmio_write32(SIM_HALT, code); }
static inline void     sim_wake(uint32_t mask)    { mmio_write32(SIM_WAKE, mask); }
static inline void     sim_deny(uint32_t mask)    { mmio_write32(SIM_DENY, mask); }
static inline void     sim_light(uint32_t mask)   { mmio_write32(SIM_LIGHT, mask); }
static inline void     sim_work_len(uint32_t n)   { mmio_write32(SIM_WORK_LEN, n); }
static inline void     sim_start(uint32_t mask)   { mmio_write32(SIM_START, mask); }
static inline uint32_t sim_tb_checks(void)        { return mmio_read32(SIM_TB_CHECKS); }
static inline uint32_t sim_tb_errors(void)        { return mmio_read32(SIM_TB_ERRORS); }
static inline void     sim_ip_cmd(uint32_t v)     { mmio_write32(SIM_IP_CMD, v); }
static inline void     sim_ip_seed(uint32_t s)    { mmio_write32(SIM_IP_SEED, s); }

static inline uint32_t sim_obs(unsigned dom, unsigned k)
{
  mmio_write32(SIM_OBS_DOM, dom);
  return mmio_read32(SIM_OBS(k));
}
/* The same, in two halves, for reading many words of one domain. */
static inline void     sim_obs_sel(unsigned dom) { mmio_write32(SIM_OBS_DOM, dom); }
static inline uint32_t sim_obs_rd(unsigned k)    { return mmio_read32(SIM_OBS(k)); }

/* Ask the testbench to confirm, from the hardware, that domain dom is in the
 * given PPU mode. The firmware must already believe it is. */
static inline void sim_check(unsigned dom, unsigned mode)
{
  mmio_write32(SIM_CHECK, ((uint32_t)dom << 8) | (mode & 0xFu));
}

#endif
