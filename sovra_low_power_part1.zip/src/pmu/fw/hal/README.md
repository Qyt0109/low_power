# pmu/fw/hal: register drivers

The SCP firmware's hardware layer: one driver per device the SCP core can
address, the memory map, CSR access and the trap handlers. Nothing here keeps
policy. The power domain manager (`../mod/pd.c`) owns the event loop and is the
only code that services PPU interrupts. Part of the shared SCP firmware; see
[`../README.md`](../README.md).

## Files

| File | What it is |
|---|---|
| `scp_regs.h` | The SCP's memory map and interrupt lines, `mmio_read32` / `mmio_write32`. One of three copies of the map that must agree, with `scp_top.sv`'s localparams and [`../../README.md`](../../README.md) §2.1 |
| `csr.h` | Machine-mode CSR macros (`csr_read`, `csr_write`, `csr_set`, `csr_clear`), `irq_enable` / `irq_disable` / `irq_save` / `irq_restore`, `wfi()`, the `mcause` values the firmware tells apart |
| `trap.h`, `trap.c` | The handlers `crt0.S`'s vector table jumps to, and the expected-fault mechanism tests use |
| `timer.h`, `timer.c` | Ibex's `mtime` / `mtimecmp` timer: read, arm, disarm, deadlines |
| `scp_irq.h`, `scp_irq.c` | The interrupt status/enable block (`scp_irq.sv`) and the platform's input table |
| `ppu_v1.h`, `ppu_v1.c` | The PPU register driver, DEN 0051E as `src/rtl/ppu/REGISTERS.md` documents it |
| `rpmi_db.h` | The RPMI doorbell interface the main loop is written against |
| `rpmi_db.c` | Its one backend: the doorbells of soc4's TL-UL mailbox (`soc4_mbx.sv`). Uses `soc4/fw/hal/soc4_regs.h`, so it is soc4-specific. Linked into `soc4_scp` only |
| `scp_wdog.h` | The watchdog (`scp_wdog.sv`): arm, kick, `CAUSE`. Header only |
| `sim.h` | The testbench's simulation-control device (`src/tb/pmu/scp_sim_ctrl.sv`). **Testbench only**; it does not exist in silicon |

## The memory map (`scp_regs.h`)

| Base | Block | Registers |
|---|---|---|
| `0x0000_0000` | RAM, 64 KB (`SCP_RAM_SIZE`) | code, data, stack |
| `0x0001_0000` | timer | `MTIME` `+0x0`, `MTIMEH` `+0x4`, `MTIMECMP` `+0x8`, `MTIMECMPH` `+0xC` |
| `0x0001_1000` | `scp_irq` | `PENDING` `+0x00` R/W1C, `ENABLE` `+0x04`, `EDGE` `+0x08` (1 = rising edge), `RAW` `+0x0C` RO, `ACTIVE` `+0x10` RO (`PENDING & ENABLE`), `INFO` `+0x14` RO (`[7:0]` input count) |
| `0x0001_2000` | `scp_wdog` | `CTRL` `+0x00` (`[0]` EN, `[1]` LOCK), `TIMEOUT` `+0x04`, `KICK` `+0x08` WO, `COUNT` `+0x0C` RO, `CAUSE` `+0x10` R/W1C |
| `0x0002_0000` | the `ext_*` window | the top level's devices. In soc4: simulation control at `+0x0000`, and the rest in `soc4/fw/hal/soc4_regs.h` |
| `0x4000_0000` | PPU `n` at `+ n * 0x1000` (`SCP_PPU_ADDR(n)`) | DEN 0051E offsets. 16 slots are decoded; slots from `SCP_NUM_PPU` up answer DECERR |

Interrupt lines (`mcause` = `0x8000_0000 | line`): `SCP_IRQ_TIMER` = 7 and
`SCP_IRQ_EXTERNAL` = 11. Ibex's fast lines 16–30 and the NMI are tied LOW.

## Key interfaces and their rules

### `trap` (the handlers)

| Handler | What it does |
|---|---|
| `trap_timer` | `timer_disarm()` (the write acknowledges the sticky interrupt), `trap_timer_count++` |
| `trap_external` | clears `mie.MEIE`, sets `trap_ext_pending`, `trap_ext_count++`. Touches no device. Returning without masking would re-enter for ever, because every input is level until its owner clears it |
| `trap_exception` | fatal (a console message, then HALT with `0xDEAD00xx`, `xx` the low byte of `mcause`), unless `trap_expect_fault()` armed it. Then the fault is recorded, `mepc` is advanced past the faulting instruction (2 or 4 bytes), and `trap_take_fault()` returns it |
| `trap_unexpected`, `trap_nmi` | fatal: a line with no source is a wiring bug |

### `scp_irq` (the interrupt inputs)

Every interrupt source except the timer is one input of `scp_irq`, on line 11.
The hardware does not know what an input is for. The platform header says it,
one entry per input in input order:

```c
#define SCP_PLAT_INPUTS(I)  I(id, name, mode, en, act, arg) ...
```

`mode` is `SCP_IN_LEVEL` or `SCP_IN_EDGE` (programmed into `EDGE`). `act` is
one of the actions below. `arg` is the PPU, the transport or the reason code.
`SCP_IN_<id>` is the input's index.

| Action | What happens after `scp_irq_collect()` | Who unmasks it |
|---|---|---|
| `SCP_ACT_PPU` | bit `arg` of `scp_irq_take_ppu()`; `pd_poll()` reads and clears the PPU's status | `pd_init()` opens it; `pd_poll()` re-opens it after the clear |
| `SCP_ACT_DOORBELL` | nothing more: the main loop reads the mailbox's `RING` itself | `rpmi_db_set_mask()`, and `rpmi_db_clear()` after each clear |
| `SCP_ACT_POWER_UP`, `SCP_ACT_NOTIFY`, `SCP_ACT_REASON`, `SCP_ACT_IGNORE` | bit `i` of `scp_irq_take_act()`; `policy_work()` runs it | `scp_irq_init()` opens it if `en = 1`; a level input is re-armed by the policy (`scp_irq_rearm_low()`, or at the next OFF vote for a power-up) |
| `SCP_ACT_CKRST` | as above; the policy reads the bridge status and FAULTs each flagged domain | `policy_init()` |

Rules:

- `scp_irq_init()` must run before `pd_init()`. It programs `EDGE`, clears
  `PENDING`, enables only the policy's inputs with `en = 1`, and returns -1 if
  `INFO` disagrees with the table's length.
- A level input that fired is masked in `ENABLE`, then its `PENDING` bit is
  cleared, because its source is still HIGH. Only its owner can clear the
  source, and the owner then calls `scp_irq_unmask()`, which clears `PENDING`
  and sets `ENABLE`. An edge input is only cleared and stays enabled.
- Every function is for thread context. The block's registers are written
  only from there, so the `ENABLE` shadow needs no lock.
- At most 4 doorbell inputs are recognised (`SCP_IRQ_MAX_DB`).

### `ppu_v1` (the PPU driver)

One `struct ppu` per PPU, filled by `ppu_probe()` from `PPU_IDR0`, `PPU_IDR1`,
`PPU_IIDR` and `PPU_AIDR`. The driver never assumes a feature the build does
not report, and it neither waits nor services interrupts. The rules it
enforces, so that callers do not have to ([`../../README.md`](../../README.md) §6):

| Rule | Where |
|---|---|
| Every `PPU_PWPR` write is read back. A refused write (unsupported policy, discarded whole: DEN 0051E §4.1.1) returns `PPU_E_REFUSED`; a write the PPU reverted after a denial (Table 4-1) returns `PPU_E_REVERTED` | `ppu_set_policy` |
| `LOCK_EN` on a build without `LOCK_SPT`, or `PWR_DYN_EN` on a build with no dynamic mode, is refused **before** any write (`PPU_E_UNSUPPORTED`). Those bits are reserved there (Table 5-2), so the PPU would take the write as a static policy | `ppu_set_policy` |
| `PWR_DYN_EN` changes one at a time: a write that would change it before `PPU_PWSR.PWR_DYN_STATUS` shows the last change returns `PPU_E_STATE` (§4.1.1). `ppu_dyn_settled()` says whether it would | `ppu_set_policy` |
| `DEVREQEN` changes only in static mode with the policy reached, and is re-enabled only from `ON` (§4.1.3); otherwise `PPU_E_STATE` | `ppu_set_devreq_en` |
| Only the retention RAM registers `PPU_IDR1` reports (b6 `PPU_FUNRR`, b5 `PPU_FULRR`, b4 `PPU_MEMRR`) are written; `PPU_E_UNSUPPORTED` if there are none. Program them before the mode is entered | `ppu_set_ret_ram` |
| The device control delays (`PPU_DCDR0/1`, Table 4-5) are written only with `SW_DEV_DEL_SPT`, and read back. Each field is a minimum of value + 1 PPU cycles. Program them with the PPU idle | `ppu_set_dev_delays` |
| `ppu_unlock()` releases the lock once only; the PPU re-locks on its next entry to a lockable mode. Leaving a locked mode for good is one `PPU_PWPR` write with `LOCK_EN` clear | `ppu_unlock` |
| A 1 in `PPU_IMR` / `PPU_AIMR` masks the event and suppresses the status bit itself, so a masked event cannot be polled later. `ppu_irq_clear()` clears only the bits given | `ppu_irq_mask`, `ppu_irq_clear` |

Return codes: `PPU_OK` 0, `PPU_E_NOT_PPU` -1 (`PPU_AIDR` is not `0x11`, v1.1),
`PPU_E_UNSUPPORTED` -2, `PPU_E_REFUSED` -3, `PPU_E_REVERTED` -4, `PPU_E_STATE`
-5. The register offsets (`PPU_PWPR` `0x000` to `PPU_AIDR` `0xFCC`) and fields
are in `ppu_v1.h`. The mode encoding (`enum ppu_mode`, Table 3-2) is monotonic
in priority, so "no deeper than X" is "encoding >= X". `PPU_IDR0`'s support
bits are not in that order (`MEM_OFF` before `FULL_RET`), which is why
`ppu_v1.c` maps them with a table.

### `rpmi_db` (the doorbells)

For transport `t` (= agent `t`, `0` to `RPMI_DB_COUNT - 1`): `rpmi_db_status()`
returns the sticky ring bits, `rpmi_db_clear(bits)` is write-1-to-clear, and
`rpmi_db_set_mask(mask)` stops bit `t` from interrupting. There is no
SCP-to-agent doorbell: agents poll their acknowledgement queue. Clear first
and then drain: a ring that lands after the clear is still there on the next
look. In soc4 the status is `SOC4_MBX_DB_STATUS` (`0x0002_2000`), the clear is
`SOC4_MBX_DB_CLEAR` (`0x0002_2004`), and each doorbell's mask is the `ENABLE`
bit of its own `scp_irq` input (inputs 4 and 14), since the mailbox has no
enable register. `rpmi_db_polled()` is false for this backend; a backend
without an interrupt would return true, and the main loop would bound its
sleep.

### `timer`

`mtimecmp` resets to 0, so the interrupt is pending from the first cycle:
`timer_init()` disarms it before setting `mie.MTIE`. The interrupt is sticky
until `mtimecmp` is written. `timer_arm()` writes the high half to all-ones
first, so no intermediate value can match. `timer_now()` re-reads the high half
until it is stable. `timer_delay()` busy-waits and is for testbench pacing
only.

### `scp_wdog`

`scp_wdog_arm(timeout)` writes `TIMEOUT`, then `CTRL = EN | LOCK` in one write:
after that, nothing can stop the watchdog or change its timeout until the next
reset. `scp_wdog_kick()` writes the key `0x4B49434B` ("KICK"); any other value
written to `KICK` while armed resets the SCP at once (`CAUSE.BADKICK`). At boot
the firmware reads `scp_wdog_cause()` (`[0]` POR, `[1]` WDOG, `[2]` BADKICK,
`[3]` DRAINTO, `[15:8]` resets since power-on) and clears it with
`scp_wdog_clear()`. Kick only from the main loop (`../rpmi/scp_loop.c`).

### `sim` (testbench only)

`SIM_OUT` `+0x000` (console byte), `SIM_CYCLE` `+0x004`, `SIM_HALT` `+0x008`
(0 = pass), `SIM_CHECK` `+0x00C`, device stimulus registers, testbench counters,
and an observation window (`SIM_OBS(k)`, `+0x040`) of what a selected domain
did at its pins. Outside the test programs only the console uses it: it is
`lib/console.c`'s one backend.

## Build and use

Not built here: [`src/soc4/fw/Makefile`](../../../soc4/fw/Makefile) compiles
these files into the images listed in [`../README.md`](../README.md#build).
`soc4_scp` uses every `.c` file. `soc4_stress` uses all but `rpmi_db.c`.
`soc4_wdog` and the AP image use `timer.c` and `trap.c` only.

## Extending

- A new private peripheral: its base in `scp_regs.h`, the same in
  `scp_top.sv` (`NrDevices`, `cfg_base`, `cfg_mask`), and the table in
  [`../../README.md`](../../README.md) §2.1.
- A new interrupt input needs no code here: one `I(...)` entry in the platform
  header and one wire in the top level (see [`../README.md`](../README.md#extending)).
- A different mailbox: a new `rpmi_db.c` implementing `rpmi_db.h`.

## References

- Arm PPU Architecture v1.1 (DEN 0051E): §3.4 (transitions, locking), §4.1.1
  (policy programming), §4.1.2 (interrupts), §4.1.3 (device interface
  configuration), §4.1.5 and Table 4-5 (device control delays), Table 5-1
  (register summary), Tables 5-26 and 5-27 (`PPU_IDR0`, `PPU_IDR1`).
- [`src/rtl/ppu/REGISTERS.md`](../../../rtl/ppu/REGISTERS.md): the register
  behaviour this driver relies on.
- Ibex `doc/03_reference/exception_interrupts.rst`: the vector layout.
- [`../../rtl/README.md`](../../rtl/README.md): `scp_irq` and `scp_wdog` on
  the hardware side.
