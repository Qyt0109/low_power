/* The RPMI doorbells: agent to SCP, one per transport (one per agent).
 *
 * The interface the main loop (rpmi/scp_loop.c) is written against. The one
 * backend is hal/rpmi_db.c, the TL-UL mailbox's doorbells (soc4_mbx.sv): the
 * status is the mailbox's RING vector, the clear is DB_CLEAR (W1C), and the
 * mask of doorbell t is the ENABLE bit of its own input of the SCP's
 * interrupt block (hal/scp_irq.h; the platform's agent table names the
 * input), since the doorbells have no enable register of their own. Each
 * doorbell is a separate input, so the firmware knows which agent rang. A
 * ring raises the block's line, the machine external interrupt, line 11
 * (SCP_IRQ_EXTERNAL), whose handler only masks mie.MEIE and sets a flag
 * (hal/trap.c); scp_irq_collect() masks the input, and rpmi_db_clear() and
 * rpmi_db_set_mask() unmask it. It interrupts, so rpmi_db_polled() is false. A backend without an interrupt would answer true, and the main
 * loop would then bound every sleep so that it comes back and looks.
 *
 * For transport t (0 to RPMI_DB_COUNT - 1, the agent table's order):
 *
 *   status  Bit t is set when agent t writes its doorbell, after it has
 *           enqueued a request. It stays set until the SCP clears it.
 *   clear   Writing 1 to bit t clears it.
 *   mask    Bit t = 1 stops bit t from raising the SCP's interrupt.
 *
 * There is no P2A (SCP-to-AP) doorbell, and so no "P2A set". The decisions of
 * 2026-09-30 drop that path (Section 2.2, and the W2.1 row of Section 6):
 * the AP polls its acknowledgement queue. Should the path come back, librpmi
 * rings it through a SYSTEM_MSI group after the acknowledgement
 * (rpmi_context.c:412-414), not through this interface.
 *
 * The status is sticky and the clear is write-1-to-clear. So a caller that
 * clears first and then drains the queue misses no ring: a ring that lands
 * after the clear is still there on the next look.
 */
#ifndef RPMI_DB_H
#define RPMI_DB_H

#include <stdint.h>
#include <stdbool.h>
#include "agents.h"

enum { RPMI_DB_COUNT = SCP_NUM_AGENTS };
#define RPMI_DB_ALL ((1u << RPMI_DB_COUNT) - 1u)

void     rpmi_db_init(void);               /* status clear, every doorbell masked */
uint32_t rpmi_db_status(void);             /* bit t: transport t has rung         */
void     rpmi_db_clear(uint32_t bits);     /* write-1-to-clear                    */
void     rpmi_db_set_mask(uint32_t mask);  /* bit t = 1: t raises no interrupt    */
bool     rpmi_db_polled(void);             /* no interrupt: the caller must poll  */

#endif
