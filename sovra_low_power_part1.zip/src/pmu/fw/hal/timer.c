#include "timer.h"
#include "scp_regs.h"
#include "csr.h"

uint64_t timer_now(void)
{
  /* The two halves are separate reads; re-read the high half until it did not
     move, so a carry between them is never seen. */
  uint32_t hi, lo, hi2;
  do {
    hi  = mmio_read32(SCP_TIMER_BASE + TIMER_MTIMEH);
    lo  = mmio_read32(SCP_TIMER_BASE + TIMER_MTIME);
    hi2 = mmio_read32(SCP_TIMER_BASE + TIMER_MTIMEH);
  } while (hi != hi2);
  return ((uint64_t)hi << 32) | lo;
}

void timer_arm(uint64_t when)
{
  /* High half to all-ones first, so no intermediate value of the pair can
     match mtime while the low half is being written. */
  mmio_write32(SCP_TIMER_BASE + TIMER_MTIMECMPH, 0xFFFFFFFFu);
  mmio_write32(SCP_TIMER_BASE + TIMER_MTIMECMP,  (uint32_t)when);
  mmio_write32(SCP_TIMER_BASE + TIMER_MTIMECMPH, (uint32_t)(when >> 32));
}

void timer_disarm(void)
{
  mmio_write32(SCP_TIMER_BASE + TIMER_MTIMECMPH, 0xFFFFFFFFu);
  mmio_write32(SCP_TIMER_BASE + TIMER_MTIMECMP,  0xFFFFFFFFu);
}

void timer_init(void)
{
  timer_disarm();
  csr_set(mie, MIE_MTIE);
}

void timer_delay(uint32_t ticks)
{
  uint64_t until = timer_after(ticks);
  while (!timer_passed(until)) { }
}
