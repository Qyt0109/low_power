/* The SCP's watchdog (scp_wdog.sv): a counter, a kick register, and a reset of
 * the SCP subsystem alone.
 *
 * Platform plan H18 and F12 (Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Sections
 * 14.7 and 15.2 phase 4). scp_wdog.sv has the register map; hal/scp_regs.h
 * the addresses.
 *
 *   arm      TIMEOUT, then CTRL = EN | LOCK in one write: from then on nothing
 *            can stop it or change its timeout until the next reset
 *   kick     the key, from the main loop once per completed pass
 *            (rpmi/scp_loop.c), never from an interrupt: a handler that kicks
 *            would keep a stuck loop alive
 *   expiry   the SCP subsystem is reset (core, RAM ports, timer, interrupt
 *            block, bus, AXI bridge), after any AXI transaction in flight has
 *            ended. The PPUs, PCSMs and power domains are always-on and keep
 *            their state; the RAM keeps its contents (not reloaded)
 *   CAUSE    survives every reset but power-on: the firmware that boots reads
 *            why, then clears it (W1C), so the next reset shows only its own
 *
 * A wrong value written to KICK while armed is itself a fault: the reset
 * follows at once, with CAUSE.BADKICK.
 */
#ifndef SCP_WDOG_H
#define SCP_WDOG_H

#include <stdint.h>
#include "scp_regs.h"

#define SCP_WDOG_KEY          0x4B49434Bu    /* "KICK", scp_wdog.sv KEY      */

#define SCP_WDOG_CTRL_EN      0x1u
#define SCP_WDOG_CTRL_LOCK    0x2u

#define SCP_WDOG_CAUSE_POR     0x1u          /* power-on reset              */
#define SCP_WDOG_CAUSE_WDOG    0x2u          /* the watchdog reset the SCP  */
#define SCP_WDOG_CAUSE_BADKICK 0x4u          /* ...for a wrong kick         */
#define SCP_WDOG_CAUSE_DRAINTO 0x8u          /* ...with AXI still in flight */
#define SCP_WDOG_CAUSE_BITS    0xFu          /* W1C                         */
#define SCP_WDOG_RESETS(c)     (((c) >> 8) & 0xFFu)   /* since power-on      */

static inline uint32_t scp_wdog_cause(void)        { return mmio_read32(SCP_WDOG_CAUSE); }
static inline void     scp_wdog_clear(uint32_t b)  { mmio_write32(SCP_WDOG_CAUSE, b & SCP_WDOG_CAUSE_BITS); }
static inline uint32_t scp_wdog_count(void)        { return mmio_read32(SCP_WDOG_COUNT); }
static inline uint32_t scp_wdog_ctrl(void)         { return mmio_read32(SCP_WDOG_CTRL); }
static inline void     scp_wdog_kick(void)         { mmio_write32(SCP_WDOG_KICK, SCP_WDOG_KEY); }

/* TIMEOUT first, then enable and lock in the same write. */
static inline void scp_wdog_arm(uint32_t timeout)
{
  mmio_write32(SCP_WDOG_TIMEOUT, timeout);
  mmio_write32(SCP_WDOG_CTRL, SCP_WDOG_CTRL_EN | SCP_WDOG_CTRL_LOCK);
}

#endif
