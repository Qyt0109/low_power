/* The SCP's memory map and interrupt lines.
 *
 * Three copies of this map exist and must agree: this file, scp_top.sv's
 * localparams, and src/pmu/README.md Section 2.1. The interrupt lines are
 * scp_core.sv's map; the interrupt block's registers are scp_irq.sv's. What the top level hangs on the ext window (soc4: the
 * RPMI mailbox, soc4_ctrl, the CPU load ports) is in the platform's own
 * header (src/soc4/fw/hal/soc4_regs.h).
 */
#ifndef SCP_REGS_H
#define SCP_REGS_H

#include <stdint.h>

/* ---- Private: reachable from this core only (PCSA 3.2.2) ---- */
#define SCP_RAM_BASE     0x00000000u   /* 64 KB: code, data, stack       */
#define SCP_RAM_SIZE     0x00010000u
#define SCP_TIMER_BASE   0x00010000u   /* mtime / mtimecmp               */
#define SCP_IRQ_BASE     0x00011000u   /* interrupt status/enable block  */
#define SCP_WDOG_BASE    0x00012000u   /* watchdog (hal/scp_wdog.h)      */
#define SCP_SIM_BASE     0x00020000u   /* testbench only: see sim.h      */

/* ---- The PPUs, over AXI4-Lite: PPU n at SCP_PPU_BASE + n * 0x1000 ---- */
#define SCP_PPU_BASE     0x40000000u
#define SCP_PPU_STRIDE   0x00001000u
#define SCP_PPU_SLOTS    16u           /* decoded; slots SCP_NUM_PPU.. answer DECERR */
/* PPU slots the firmware drives: SCP_NUM_PPU, set by the platform header
 * (soc4: src/soc4/fw/soc4_plat.h, force-included into every SCP image). */
#define SCP_PPU_ADDR(n)  (SCP_PPU_BASE + (uint32_t)(n) * SCP_PPU_STRIDE)

/* ---- The interrupt status/enable block (scp_irq.sv; hal/scp_irq.h) ----
 * Bit i of each register is input i, scp_top's irq_i[i]. */
#define SCP_IRQ_PENDING  (SCP_IRQ_BASE + 0x00u)  /* R/W1C  sticky event, while enabled */
#define SCP_IRQ_ENABLE   (SCP_IRQ_BASE + 0x04u)  /* RW     1 = may set PENDING; 0 at reset */
#define SCP_IRQ_EDGE     (SCP_IRQ_BASE + 0x08u)  /* RW     1 = rising edge, 0 = level */
#define SCP_IRQ_RAW      (SCP_IRQ_BASE + 0x0Cu)  /* RO     the synchronised inputs    */
#define SCP_IRQ_ACTIVE   (SCP_IRQ_BASE + 0x10u)  /* RO     PENDING & ENABLE: the line */
#define SCP_IRQ_INFO     (SCP_IRQ_BASE + 0x14u)  /* RO     [7:0] number of inputs     */

/* ---- The watchdog (scp_wdog.sv; hal/scp_wdog.h) ---- */
#define SCP_WDOG_CTRL    (SCP_WDOG_BASE + 0x00u)  /* RW     [0] EN, [1] LOCK (sticky)   */
#define SCP_WDOG_TIMEOUT (SCP_WDOG_BASE + 0x04u)  /* RW     COUNT's load value         */
#define SCP_WDOG_KICK    (SCP_WDOG_BASE + 0x08u)  /* WO     the key reloads; else reset */
#define SCP_WDOG_COUNT   (SCP_WDOG_BASE + 0x0Cu)  /* RO     cycles left                */
#define SCP_WDOG_CAUSE   (SCP_WDOG_BASE + 0x10u)  /* R/W1C  why the SCP last reset      */

/* ---- Interrupt lines: the mcause of an interrupt is (1 << 31) | line ----
 * Two sources reach the core: the timer and the interrupt block. Ibex's fast
 * lines (16-30) are tied LOW (scp_top.sv). */
#define SCP_IRQ_TIMER     7u
#define SCP_IRQ_EXTERNAL 11u           /* the interrupt block's line      */

static inline uint32_t mmio_read32(uint32_t addr)
{
  return *(volatile uint32_t *)(uintptr_t)addr;
}

static inline void mmio_write32(uint32_t addr, uint32_t val)
{
  *(volatile uint32_t *)(uintptr_t)addr = val;
}

#endif
