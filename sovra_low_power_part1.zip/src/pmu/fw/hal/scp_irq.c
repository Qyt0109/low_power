/* The SCP's interrupt inputs. See scp_irq.h. */
#include "scp_irq.h"
#include "csr.h"
#include "trap.h"
#include "lib.h"

/* THE INPUT TABLE, from the platform header (soc4: src/soc4/fw/soc4_plat.h,
   force-included), one entry per input of the block. */
#define SCP_IN_CFG(id, nm, md, e, ac, ag) \
  { .name = nm, .mode = (md), .en = (e), .act = (ac), .arg = (ag) },
const struct scp_in_cfg scp_in_cfg[] = { SCP_PLAT_INPUTS(SCP_IN_CFG) };
#undef SCP_IN_CFG
_Static_assert(ARRAY_SIZE(scp_in_cfg) == SCP_NUM_IN, "one entry per input");
_Static_assert(SCP_NUM_IN >= 1 && SCP_NUM_IN <= 32, "the block's registers are 32 bits");

#define SCP_IRQ_MAX_DB 4u

struct scp_irq_stats scp_irq_stats;

static uint32_t en_hw;       /* ENABLE as last written                         */
static uint32_t m_level;     /* inputs set to level                            */
static uint32_t m_ppu;       /* inputs that are a PPU's line                   */
static uint32_t m_act;       /* inputs whose action is the policy's            */
static uint32_t held;        /* level inputs to unmask once seen LOW           */
static uint32_t ppu_flags;   /* bit d: PPU d's input fired                     */
static uint32_t act_flags;   /* bit i: input i's action is due                 */
static uint8_t  ppu_in[SCP_NUM_PPU];       /* PPU d -> input index + 1 (0: none) */
static uint8_t  db_in[SCP_IRQ_MAX_DB];     /* doorbell t -> input index + 1      */

static void write_en(uint32_t v)
{
  en_hw = v;
  mmio_write32(SCP_IRQ_ENABLE, v);
}

int scp_irq_init(void)
{
  uint32_t edge = 0, en = 0;
  m_level = m_ppu = m_act = held = ppu_flags = act_flags = 0;
  memset(ppu_in, 0, sizeof ppu_in);
  memset(db_in, 0, sizeof db_in);
  memset(&scp_irq_stats, 0, sizeof scp_irq_stats);

  for (unsigned i = 0; i < SCP_NUM_IN; i++) {
    const struct scp_in_cfg *c = &scp_in_cfg[i];
    const uint32_t b = SCP_IN_BIT(i);
    if (c->mode == SCP_IN_EDGE) edge |= b;
    else                        m_level |= b;
    switch (c->act) {
    case SCP_ACT_PPU:
      m_ppu |= b;
      if (c->arg < SCP_NUM_PPU) ppu_in[c->arg] = (uint8_t)(i + 1u);
      break;
    case SCP_ACT_DOORBELL:
      if (c->arg < SCP_IRQ_MAX_DB) db_in[c->arg] = (uint8_t)(i + 1u);
      break;
    case SCP_ACT_CKRST:
      m_act |= b;                     /* opened by its owner, policy_init() */
      break;
    default:
      m_act |= b;
      if (c->en) en |= b;
      break;
    }
  }

  /* Masked, then configured, then cleared, then enabled: an input never sets
     PENDING under a configuration it is not meant to have. */
  write_en(0);
  mmio_write32(SCP_IRQ_EDGE, edge);
  mmio_write32(SCP_IRQ_PENDING, 0xFFFFFFFFu);
  write_en(en);
  trap_ext_pending = 0;
  csr_set(mie, MIE_MEIE);
  return ((mmio_read32(SCP_IRQ_INFO) & 0xFFu) == SCP_NUM_IN) ? 0 : -1;
}

void scp_irq_collect(void)
{
  uint32_t was = irq_save();
  const bool taken = trap_ext_pending;
  trap_ext_pending = 0;
  irq_restore(was);

  if (taken) {
    const uint32_t act = mmio_read32(SCP_IRQ_ACTIVE);
    const uint32_t lvl = act & m_level;
    /* A level source is still HIGH: mask it first, so that the clear below
       is not undone in the next cycle. */
    if (lvl) write_en(en_hw & ~lvl);
    if (act) mmio_write32(SCP_IRQ_PENDING, act);
    scp_irq_stats.collects++;
    for (uint32_t a = act, i = 0; a; a >>= 1, i++)
      if (a & 1u) scp_irq_stats.taken[i]++;
    if (act & m_ppu)
      for (unsigned d = 0; d < SCP_NUM_PPU; d++)
        if (ppu_in[d] && (act & SCP_IN_BIT(ppu_in[d] - 1u))) ppu_flags |= 1u << d;
    act_flags |= act & m_act;
  }

  if (held) {
    const uint32_t low = held & ~mmio_read32(SCP_IRQ_RAW);
    if (low) {
      held &= ~low;
      scp_irq_unmask(low);
    }
  }

  csr_set(mie, MIE_MEIE);
}

uint32_t scp_irq_take_ppu(void)
{
  uint32_t f = ppu_flags;
  ppu_flags = 0;
  return f;
}

uint32_t scp_irq_take_act(void)
{
  uint32_t f = act_flags;
  act_flags = 0;
  return f;
}

bool scp_irq_act_pending(void) { return act_flags != 0; }
bool scp_irq_held(void)        { return held != 0; }

void scp_irq_mask(uint32_t bits)
{
  if (en_hw & bits) write_en(en_hw & ~bits);
}

void scp_irq_unmask(uint32_t bits)
{
  if (!bits) return;
  mmio_write32(SCP_IRQ_PENDING, bits);
  if ((en_hw & bits) != bits) write_en(en_hw | bits);
}

void scp_irq_rearm_low(uint32_t bits)
{
  held |= bits & m_level;
}

uint32_t scp_irq_ppu_bit(unsigned d)
{
  return (d < SCP_NUM_PPU && ppu_in[d]) ? SCP_IN_BIT(ppu_in[d] - 1u) : 0u;
}

uint32_t scp_irq_act_bits(unsigned act)
{
  uint32_t m = 0;
  for (unsigned i = 0; i < SCP_NUM_IN; i++)
    if (scp_in_cfg[i].act == act && scp_in_cfg[i].en) m |= SCP_IN_BIT(i);
  return m;
}

uint32_t scp_irq_db_bit(unsigned t)
{
  return (t < SCP_IRQ_MAX_DB && db_in[t]) ? SCP_IN_BIT(db_in[t] - 1u) : 0u;
}
