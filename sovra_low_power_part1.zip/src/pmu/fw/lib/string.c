/* memcpy and friends, byte at a time.
 *
 * Deliberately simple: the firmware copies structs of a few words, and a
 * word-at-a-time version would have alignment cases to get right for no gain
 * a PPU driver could measure. Built with -fno-tree-loop-distribute-patterns
 * (src/soc4/fw/Makefile), without which GCC turns the memset loop into a
 * call to memset.
 */
#include "lib.h"

void *memcpy(void *dst, const void *src, size_t n)
{
  uint8_t *d = dst;
  const uint8_t *s = src;
  while (n--) *d++ = *s++;
  return dst;
}

void *memmove(void *dst, const void *src, size_t n)
{
  uint8_t *d = dst;
  const uint8_t *s = src;
  if (d < s) {
    while (n--) *d++ = *s++;
  } else {
    d += n;
    s += n;
    while (n--) *--d = *--s;
  }
  return dst;
}

void *memset(void *dst, int c, size_t n)
{
  uint8_t *d = dst;
  while (n--) *d++ = (uint8_t)c;
  return dst;
}

int memcmp(const void *a, const void *b, size_t n)
{
  const uint8_t *x = a, *y = b;
  for (; n; n--, x++, y++)
    if (*x != *y) return (int)*x - (int)*y;
  return 0;
}

size_t strlen(const char *s)
{
  const char *p = s;
  while (*p) p++;
  return (size_t)(p - s);
}
