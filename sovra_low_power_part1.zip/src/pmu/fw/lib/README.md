# pmu/fw/lib: the C library subset and the console

The SCP firmware links no C library. This toolchain has no rv32 soft-float
multilib, so neither newlib nor libgcc links for `-mabi=ilp32`
([`../../README.md`](../../README.md) §4). This folder supplies the few functions
the firmware and GCC need. Part of the shared SCP firmware; see
[`../README.md`](../README.md).

## Files

| File | What it is |
|---|---|
| `lib.h` | Declarations of `memcpy`, `memmove`, `memset`, `memcmp`, `strlen`, and the `ARRAY_SIZE` macro |
| `string.c` | Those five functions, one byte at a time |
| `console.h`, `console.c` | `con_putc`, `con_puts`, `con_printf`, `con_vprintf` |

## Rules

- **`memcpy` and `memset` must exist even if nothing calls them.** GCC emits
  calls to them for a struct copy or a struct initialiser.
- **Build with `-fno-tree-loop-distribute-patterns`.** Without it GCC
  recognises `memset`'s own loop as a `memset` and compiles it into a call to
  itself. `src/soc4/fw/Makefile` sets the flag.
- **The console's format subset:** `%c %s %d %i %u %x %X %p %%`, an optional
  `0` flag and a field width. `-` is accepted and ignored, except that `%s`
  pads on the right. `l`, `h` and `z` are skipped, and every integer is read as
  32 bits. There is no `%llu`: print a 64-bit value as two `%08x` halves,
  because a decimal conversion would need the 64-bit division this toolchain
  cannot link.
- **The backend is the testbench's simulation-control device** (`SIM_OUT`,
  `0x0002_0000`; `../hal/sim.h`), one byte per store. On silicon it would be a
  UART, and only `con_putc` would change.

## Build and use

Every image of [`src/soc4/fw/Makefile`](../../../soc4/fw/Makefile) links
`console.c` and `string.c`: `soc4_scp`, `soc4_scp_m6`, `soc4_stress`,
`soc4_wdog` and the AP image `soc4_ap`. librpmi's own string helpers are static
inlines in its header and do not use these (`../port/rpmi_env.h`).
