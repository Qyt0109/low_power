/* The few C library functions the firmware needs, since it links no libc.
 *
 * GCC emits calls to memcpy and memset on its own (a struct copy or a struct
 * initialiser is enough), so those two must exist whether or not the firmware
 * calls them. See src/soc4/fw/Makefile (the firmware build) for why no libc
 * or libgcc can be linked.
 */
#ifndef LIB_H
#define LIB_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

void  *memcpy(void *dst, const void *src, size_t n);
void  *memmove(void *dst, const void *src, size_t n);
void  *memset(void *dst, int c, size_t n);
int    memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

#endif
