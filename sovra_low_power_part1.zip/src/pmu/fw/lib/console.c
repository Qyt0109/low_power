/* The console: a printf small enough to trust. See console.h for the subset. */
#include "console.h"
#include "sim.h"

void con_putc(char c)
{
  mmio_write32(SIM_OUT, (uint32_t)(uint8_t)c);
}

void con_puts(const char *s)
{
  while (*s) con_putc(*s++);
}

static void put_field(const char *digits, int len, int width, char pad, int neg)
{
  int total = len + (neg ? 1 : 0);
  if (neg && pad == '0') con_putc('-');
  for (; width > total; width--) con_putc(pad);
  if (neg && pad != '0') con_putc('-');
  while (len--) con_putc(digits[len]);      /* digits are stored reversed */
}

static void put_uint(uint32_t v, unsigned base, int upper, int width, char pad, int neg)
{
  const char *xd = upper ? "0123456789ABCDEF" : "0123456789abcdef";
  char buf[12];
  int n = 0;
  do {
    buf[n++] = xd[v % base];        /* 32-bit divu: the M extension, inline */
    v /= base;
  } while (v);
  put_field(buf, n, width, pad, neg);
}

void con_vprintf(const char *fmt, va_list ap)
{
  for (; *fmt; fmt++) {
    if (*fmt != '%') {
      con_putc(*fmt);
      continue;
    }
    fmt++;
    char pad = ' ';
    int width = 0;
    if (*fmt == '-') fmt++;                 /* left-justify: accepted, ignored */
    if (*fmt == '0') { pad = '0'; fmt++; }
    while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
    while (*fmt == 'l' || *fmt == 'h' || *fmt == 'z') fmt++;

    switch (*fmt) {
      case 'c':
        con_putc((char)va_arg(ap, int));
        break;
      case 's': {
        const char *s = va_arg(ap, const char *);
        if (!s) s = "(null)";
        int len = 0;
        while (s[len]) len++;
        con_puts(s);
        for (; width > len; width--) con_putc(' ');   /* pad right: tables */
        break;
      }
      case 'd':
      case 'i': {
        int32_t v = va_arg(ap, int32_t);
        uint32_t u = (v < 0) ? (uint32_t)0 - (uint32_t)v : (uint32_t)v;
        put_uint(u, 10, 0, width, pad, v < 0);
        break;
      }
      case 'u':
        put_uint(va_arg(ap, uint32_t), 10, 0, width, pad, 0);
        break;
      case 'x':
      case 'X':
        put_uint(va_arg(ap, uint32_t), 16, *fmt == 'X', width, pad, 0);
        break;
      case 'p':
        con_puts("0x");
        put_uint((uint32_t)(uintptr_t)va_arg(ap, void *), 16, 0, 8, '0', 0);
        break;
      case '%':
        con_putc('%');
        break;
      case '\0':
        return;
      default:
        con_putc('%');
        con_putc(*fmt);
        break;
    }
  }
}

void con_printf(const char *fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  con_vprintf(fmt, ap);
  va_end(ap);
}
