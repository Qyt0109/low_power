/* A console for the SCP firmware.
 *
 * The backend is the testbench's simulation-control device (hal/sim.h), one
 * byte per store. On silicon it would be a UART; nothing above con_putc knows.
 *
 * con_printf understands %c %s %d %i %u %x %X %p %%, an optional '0' flag and
 * a field width, and ignores 'l' and 'h' length modifiers: on rv32 ilp32 int
 * and long are both 32 bits, so every integer argument is read as 32 bits.
 * There is no %llu -- 64-bit values are printed as two %08x halves, because
 * converting them to decimal would need the 64-bit division this toolchain
 * cannot link (README Section 4).
 */
#ifndef CONSOLE_H
#define CONSOLE_H

#include <stdarg.h>
#include <stdint.h>

void con_putc(char c);
void con_puts(const char *s);
void con_printf(const char *fmt, ...);
void con_vprintf(const char *fmt, va_list ap);

#endif
