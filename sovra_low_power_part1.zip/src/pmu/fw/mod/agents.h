/* The RPMI agents' indices, from the platform's agent table.
 *
 * Platform plan PD6, H11-H13 and F6 (Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md
 * Sections 14.1 and 14.7). The platform header writes the agent table by hand,
 * one A(...) per agent, in transport order: agent k = RPMI transport k = the
 * mailbox's queue window k and doorbell RING[k] (soc4: soc4_mbx.sv):
 *
 *   #define SCP_PLAT_AGENTS(A)  A(id, name, window, db_in, src, mask, groups) ...
 *
 *   id      an identifier: SCP_AG_<id> is the agent's index, SCP_AG(id) its
 *           bit in a domain's permission bitmap (mod/pd.h, .agents)
 *   name    the agent's RPMI transport and context name
 *   window  its queue window on the SCP's map, SCP_RPMI_SHMEM_SIZE bytes: the
 *           A2P request queue, then the P2A acknowledgement queue
 *           (librpmi lib/rpmi_transport_shmem.c:236-247)
 *   db_in   its doorbell's input of the SCP's interrupt block: SCP_IN_<name>
 *           of the input table (hal/scp_irq.h), whose entry must be
 *           SCP_ACT_DOORBELL with arg = the agent's index (checked at boot)
 *   src, mask  its firewall entry: the mailbox admits a request to window k
 *           only if (a_source & mask) == src (soc4_mbx.sv FW_VAL, FW_MASK)
 *   groups  the service groups it gets beside BASE, which every librpmi
 *           context has: SCP_GRP_* (rpmi/scp_rpmi.h)
 *
 * Only the indices are here: the domain table names agents (its permission
 * bitmap) and is compiled into images that have no RPMI server.
 * rpmi/scp_rpmi.h gives the rest of each entry its meaning.
 */
#ifndef AGENTS_H
#define AGENTS_H

#ifndef SCP_PLAT_AGENTS
#error "the platform header must define SCP_PLAT_AGENTS (the agent table)"
#endif
#define SCP_AG_ENUM(id, ...) SCP_AG_##id,
enum { SCP_PLAT_AGENTS(SCP_AG_ENUM) SCP_NUM_AGENTS };
#undef SCP_AG_ENUM
#define SCP_AG(id) (1u << SCP_AG_##id)

/* A domain's permission bitmap is a byte (struct pd_cfg .agents). */
_Static_assert(SCP_NUM_AGENTS >= 1 && SCP_NUM_AGENTS <= 8, "1 to 8 agents");

#endif
