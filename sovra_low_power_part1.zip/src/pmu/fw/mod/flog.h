/* The fault log, and what else the SCP keeps across a watchdog reset.
 *
 * Platform plan F12 (Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Sections 14.7
 * and 15.2 phase 4). One block, struct scp_keep, at a fixed address at the top
 * of the RAM (link.ld .persist, 0xFC00): crt0.S neither loads nor clears it,
 * and the watchdog does not reload the RAM (scp_top.sv), so it outlives a
 * watchdog reset. It holds:
 *
 *   the fault log  a ring of FLOG_N entries, oldest overwritten first
 *   the votes      each agent's DEVICE_POWER vote per domain (rpmi/scp_rpmi.c):
 *                  after a watchdog reset the policy rebuilds its state from
 *                  them and from the PPUs (mod/policy.h, policy_adopt)
 *   deny_seen      each mailbox transport's firewall DENY_CNT as last logged
 *
 * VALID OR GARBAGE. After power-on the RAM holds anything. flog_boot() keeps
 * the block only if the reset was NOT a power-on (the watchdog's CAUSE.POR is
 * 0), and the magic, the size (another build's block is garbage) and both
 * checksums hold; otherwise it starts a new, empty one: no entries, every vote
 * OFF. Two checksums, so that a vote, which changes at every DEVICE_POWER
 * SET, costs a fold of four words and not of the whole log: log_csum covers
 * the header and the entries, rewritten by flog_add(); state_csum covers
 * deny_seen and the votes, rewritten by flog_commit(), which every change to
 * them must end in. A reset in the middle of a change leaves a block the next
 * boot discards.
 *
 * AN ENTRY, 16 bytes, at 0xFC00 + 16 + 16 * slot (soc4_tb's W1 reads them):
 *
 *   word 0  mtime [31:0]    the SCP timer, which a watchdog reset restarts:
 *   word 1  mtime [63:32]   compare entries by seq, not by time
 *   word 2  [7:0] code, [15:8] domain (0xFF: none), [31:16] seq [15:0]
 *   word 3  detail, by code (below)
 *
 *   code            domain          detail
 *   1 FAULT         DOMAIN_ID       a policy FAULT (mod/policy.h): [7:0] the
 *                                   mod/pd error (PD_E_TIMEOUT -15 is a
 *                                   deadline missed), [8] in a retry of the
 *                                   power-off after a fault, [9] the retries
 *                                   are used up (gave up)
 *   2 FORCED        DOMAIN_ID       a forced power-down (DEVREQEN = 0 after
 *                                   the retries): [7:0] the denials taken
 *   3 FW_DENY       agent k         firewall denials on transport k since the
 *                                   last entry: [19:0] the mailbox's FW_LAST,
 *                                   [31:20] how many (saturating at 4095)
 *   4 CLKRST        DOMAIN_ID       a clock/reset bridge fault (platform plan
 *                                   H16, F11; mod/policy.h): [7:0] the
 *                                   bridge's status byte as read (ckrst_bridge
 *                                   .sv: [0] LATE, [1] MISSING, [2] SPURIOUS,
 *                                   [4] clock, [5] reset 0, [6] reset 1). A
 *                                   FAULT entry (code 1, PD_E_CLKRST -17)
 *                                   follows it
 *   5 WDOG          0xFF            a watchdog reset: the watchdog's CAUSE
 *                                   register as the rebooted firmware read it
 *
 * Every entry is also printed on the console as it is added ("scp: log #seq
 * ..."), and flog_dump() prints the whole ring (the boot does). Agents cannot
 * read the log over RPMI: that belongs to the software contract (platform plan
 * phase 5).
 */
#ifndef FLOG_H
#define FLOG_H

#include <stdint.h>
#include <stdbool.h>
#include "pd.h"

#define FLOG_N        32u
#define SCP_KEEP_MAGIC 0x504B4353u        /* "SCKP" */

enum flog_code {
  FLOG_FAULT   = 1,
  FLOG_FORCED  = 2,
  FLOG_FW_DENY = 3,
  FLOG_CLKRST  = 4,
  FLOG_WDOG    = 5,
};
#define FLOG_DOM_NONE 0xFFu
#define FLOG_FAULT_RETRY  0x100u
#define FLOG_FAULT_GAVEUP 0x200u

struct flog_entry {
  uint32_t t_lo, t_hi;
  uint8_t  code, dom;
  uint16_t seq;
  uint32_t detail;
};

/* Votes: byte [k * PD_COUNT + d], 1 = agent k votes ON for domain d, 0 = OFF,
   so a new (zeroed) block holds every vote OFF. Padded to whole words. */
#define SCP_KEEP_VOTES  ((SCP_NUM_AGENTS * PD_COUNT + 3u) & ~3u)

struct scp_keep {
  uint32_t magic;
  uint16_t size;                         /* sizeof(struct scp_keep)          */
  uint8_t  head;                         /* the next entry's slot            */
  uint8_t  count;                        /* entries held, at most FLOG_N     */
  uint32_t seq;                          /* entries ever added               */
  uint32_t wdog;                         /* watchdog resets survived         */
  struct flog_entry e[FLOG_N];
  uint32_t log_csum;                     /* over every word before it        */
  uint32_t deny_seen[SCP_NUM_AGENTS];
  uint8_t  votes[SCP_KEEP_VOTES];
  uint32_t state_csum;                   /* over deny_seen and votes         */
};
_Static_assert(sizeof(struct flog_entry) == 16u, "a log entry is four words");
_Static_assert(sizeof(struct scp_keep) % 4u == 0u, "the block is whole words");
_Static_assert(sizeof(struct scp_keep) <= 0x400u, "link.ld's PERSIST_SIZE");

extern struct scp_keep scp_keep;

/* At boot, with the watchdog's CAUSE: true if the block was kept, false if a
   new one was started. */
bool flog_boot(uint32_t cause);
void flog_add(unsigned code, unsigned dom, uint32_t detail);
void flog_commit(void);                  /* after changing votes or deny_seen */
void flog_dump(void);
const char *flog_code_name(unsigned code);

#endif
