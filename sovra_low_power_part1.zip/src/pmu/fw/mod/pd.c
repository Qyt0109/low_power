/* The power domain manager. See pd.h, and README Sections 5.2 and 6. */
#include "pd.h"
#include "csr.h"
#include "timer.h"
#include "scp_irq.h"
#include "lib.h"

/* How long a waiter sleeps before looking again even if nothing woke it. The
 * wake-up is normally a PPU interrupt; this bound is what keeps a wait correct
 * for a completion that raises no interrupt at all -- a dynamic transition
 * reaching an intermediate mode, say -- at the cost of a few AXI reads. */
#define PD_POLL_TICKS   512u

/* Entry delay before every lower-priority mode, in PPU cycles: the hysteresis
 * on the autonomous path (design doc 9.3). Small here; it is a measured value
 * in a real system. */
#define PD_ENTRY_DELAY  16u

/* SWITCH SETTLING IS THE PPU'S DEVICE CONTROL DELAYS, NOT AN ACKNOWLEDGE.
 *
 * The power switches acknowledge nothing: src/upf/ppu_pd_top.upf has no
 * -ack_port and the domains are built with PGOOD_EN = 0, so no hardware waits
 * for a rail to settle. What stands in for it is the spacing the PPU puts
 * between the device controls on the way up (PPU 4.1.5):
 *
 *   PCSM accept -> isolation release -> ISO_CLKEN_DLY -> clock enable
 *               -> CLKEN_RST_DLY -> reset release -> RST_HWSTAT_DLY -> PPUHWSTAT
 *
 * ISO_CLKEN_DLY carries the settling time, so the device clock does not start
 * into a rail still coming up and reset is not released into one. CLKEN_RST_DLY
 * then covers DEVCLKEN's two-stage resynchronization into the device clock
 * (ppu_pd_top's u_clken_sync) plus a couple of clock edges under reset, which
 * PPU 4.1.5 warns a resynchronized enable needs. The power-down side keeps the
 * build's defaults. Each field is value + 1 cycles minimum (Table 4-5).
 *
 * PD_SWITCH_SETTLE is 20 PPU cycles: 200 ns at this system's 100 MHz, the
 * settling time the switch acknowledge used to model. The testbench (soc4_tb)
 * holds every power-up to the same budget, rail on to reset release.
 *
 * What this cannot cover: isolation release follows PCSMPACCEPT with no
 * programmable gap, so a switch slower than a cycle or two still needs its
 * PCSM to hold off PCSMPACCEPT until it has settled. */
const struct ppu_dev_delays pd_dev_delays = {
  .rst_hwstat = 2,
  .iso_clken  = PD_SWITCH_SETTLE,
  .clken_rst  = 4,
  .clken_iso  = 2,
  .iso_rst    = 2,
};

/* Which interrupt events the manager takes. A 1 MASKS (REGISTERS.md 4.4).
 * STA_ACCEPT fires per hop and adds nothing to STA_POLICY_TRN for a manager
 * that waits for the policy; everything else is unmasked and counted. */
#define PD_IMR   PPU_ISR_STA_ACCEPT
#define PD_AIMR  0u

/* THE DOMAIN TABLE (pd.h), from the platform header (soc4: src/soc4/fw/
   soc4_plat.h, force-included), one entry per PPU. */
#ifndef SCP_PLAT_DOMAINS
#error "the platform header must define SCP_PLAT_DOMAINS and SCP_NUM_PPU"
#endif
#define PD_CFG(nm, latency, ...) { .name = nm, __VA_ARGS__ },
const struct pd_cfg pd_cfg[] = { SCP_PLAT_DOMAINS(PD_CFG) };
#undef PD_CFG
_Static_assert(ARRAY_SIZE(pd_cfg) == PD_COUNT, "one domain table entry per PPU (SCP_NUM_PPU)");

struct pd pd_tab[PD_COUNT];

/* ===========================================================================
 * Names
 * ========================================================================= */
const char *pd_mode_name(enum ppu_mode m)
{
  switch (m) {
    case PPU_MODE_OFF:       return "OFF";
    case PPU_MODE_MEM_RET:   return "MEM_RET";
    case PPU_MODE_FULL_RET:  return "FULL_RET";
    case PPU_MODE_MEM_OFF:   return "MEM_OFF";
    case PPU_MODE_FUNC_RET:  return "FUNC_RET";
    case PPU_MODE_ON:        return "ON";
    case PPU_MODE_WARM_RST:  return "WARM_RST";
    case PPU_MODE_LOGIC_RET: return "LOGIC_RET";
    default:                 return "?";
  }
}

const char *pd_err_name(int rc)
{
  switch (rc) {
    case PD_OK:            return "OK";
    case PD_E_ABSENT:      return "ABSENT";
    case PD_E_UNSUPPORTED: return "UNSUPPORTED";
    case PD_E_REFUSED:     return "REFUSED";
    case PD_E_DENIED:      return "DENIED";
    case PD_E_TIMEOUT:     return "TIMEOUT";
    case PD_E_BUSY:        return "BUSY";
    case PD_E_CLKRST:      return "CLKRST";
    case PD_PENDING:       return "PENDING";
    default:               return "?";
  }
}

static int from_ppu(int rc)
{
  switch (rc) {
    case PPU_OK:            return PD_OK;
    case PPU_E_UNSUPPORTED: return PD_E_UNSUPPORTED;
    case PPU_E_REFUSED:     return PD_E_REFUSED;
    case PPU_E_REVERTED:    return PD_E_DENIED;
    case PPU_E_STATE:       return PD_E_BUSY;
    default:                return PD_E_ABSENT;
  }
}

/* PPU 4.1.1, "Power Policy Programming": a PWR_DYN_EN change may only follow the
 * previous one once PPU_PWSR.PWR_DYN_STATUS shows it, which happens when any
 * transition in flight has finished. The driver refuses a write that would
 * break this (PPU_E_STATE); this is the wait that makes the refusal rare. */
#define PD_DYN_SETTLE 20000u
static int dyn_settle(const struct ppu *p, uint64_t until)
{
  while (!ppu_dyn_settled(p))
    if (timer_passed(until)) return PD_E_TIMEOUT;
  return PD_OK;
}

/* ===========================================================================
 * Bring-up
 * ========================================================================= */
uint32_t pd_adopt_rewrites;

/* Does the PPU already hold every setting bring-up programs? After a watchdog
   reset of the SCP alone it does: the PPU kept the last boot's. */
static bool settings_held(const struct pd *pd, unsigned d)
{
  const struct ppu *p = &pd->ppu;
  const struct pd_cfg *c = &pd_cfg[d];
  const uint32_t e = PD_ENTRY_DELAY;
  if (ppu_rd(p, PPU_IMR) != PD_IMR || ppu_rd(p, PPU_AIMR) != PD_AIMR) return false;
  if ((p->ret_ram_regs & PPU_RR_FUNRR) && ppu_rd(p, PPU_FUNRR) != c->funrr) return false;
  if ((p->ret_ram_regs & PPU_RR_FULRR) && ppu_rd(p, PPU_FULRR) != c->fulrr) return false;
  if ((p->ret_ram_regs & PPU_RR_MEMRR) && ppu_rd(p, PPU_MEMRR) != c->memrr) return false;
  if (p->entry_delay && (ppu_rd(p, PPU_EDTR0) != ((e << 24) | (e << 8) | e) ||
                         ppu_rd(p, PPU_EDTR1) != ((e << 8) | e)))
    return false;
  return !p->sw_dev_delay || pd_dev_delays_ok(d);
}

static int init_all(bool adopt)
{
  int found = 0;
  for (unsigned d = 0; d < PD_COUNT; d++) {
    struct pd *pd = &pd_tab[d];
    memset(&pd->ev, 0, sizeof pd->ev);
    pd->present  = (ppu_probe(&pd->ppu, SCP_PPU_ADDR(d)) == PPU_OK);
    if (!pd->present) continue;
    found++;

    /* Where the domain actually is. REGISTERS.md Section 2: PPU_PWPR's reset
       value is sampled from PCSMMODESTAT, so the same build can come up in
       OFF or MEM_RET -- read it, do not assume it. After a watchdog reset the
       domain may be anywhere: in ON, in retention, or between the two. */
    pd->reset_pwpr = ppu_policy(&pd->ppu);
    pd->reset_mode = ppu_mode(&pd->ppu);

    /* TAKING OVER (pd_adopt): no write to a PPU that already holds its
       settings, which is every PPU after a watchdog reset -- the retention
       RAM and delay registers pace and shape a transition that may be under
       way -- except the clear of its interrupt status: events from before
       the reset are stale, nobody waits for them now. Only a PPU that does
       not hold its settings is programmed, and counted. PPU_PWPR and PPU_PWCR
       are never written here, in either case. */
    if (adopt) {
      if (settings_held(pd, d)) {
        ppu_irq_clear(&pd->ppu, PPU_ISR_W1C, PPU_AISR_W1C);
        scp_irq_unmask(scp_irq_ppu_bit(d));
        continue;
      }
      pd_adopt_rewrites++;
    }

    ppu_irq_mask(&pd->ppu, PD_IMR, PD_AIMR);
    ppu_irq_clear(&pd->ppu, PPU_ISR_W1C, PPU_AISR_W1C);

    /* The retention RAM configuration from the domain table: ppu_pcsm reads
       each byte as one retain enable per SRAM bank (REGISTERS.md 4.5). The
       driver writes the registers this PPU has (PPU_IDR1) and no other. */
    ppu_set_ret_ram(&pd->ppu, pd_cfg[d].funrr, pd_cfg[d].fulrr, pd_cfg[d].memrr);
    ppu_set_entry_delay(&pd->ppu, PD_ENTRY_DELAY);

    /* Before the first power-up, with the PPU idle: see PD_SWITCH_SETTLE. On a
       build without SW_DEV_DEL_SPT the registers are read-only and the built-in
       values stand; pd_dev_delays_ok() is how a caller finds out. The
       domain's own values: the build's, raised to cover the SoC's clkgate
       and tilereset (pd_dev_delays_of; platform plan F11). */
    struct ppu_dev_delays dly;
    pd_dev_delays_of(d, &dly);
    ppu_set_dev_delays(&pd->ppu, &dly);

    /* The PPU's input of the interrupt block (hal/scp_irq.h): scp_irq_init()
       has configured it, and left it masked for this owner to open. */
    scp_irq_unmask(scp_irq_ppu_bit(d));
  }
  return found;
}

int pd_init(void)  { return init_all(false); }
int pd_adopt(void) { return init_all(true); }

/* THE CLOCK/RESET BRIDGE (platform plan H16, F11; rtl/ckrst/ckrst_bridge.sv).
 * The PPU's device controls are requests to the SoC's clkgate / tilereset,
 * which acknowledge after up to pd_cfg[d].ckrst_lat PPU cycles. The PPU has no
 * acknowledgement input; the bridge flags a step taken before the
 * acknowledgement as LATE. So each delay that separates a bridged control from
 * the PPU's next step covers the latency (DEN 0051E Table 4-5, "minimum ...
 * is <field> + 1"; field >= latency leaves a cycle to spare):
 *
 *   CLKEN_RST_DLY   DEVCLKEN on    -> resets released     (clock running)
 *   CLKEN_ISO_DLY   DEVCLKEN off   -> isolation applied   (clock stopped)
 *   RST_HWSTAT_DLY  resets released -> PPUHWSTAT updated  (tile out of reset
 *                                                          when ON is reported)
 *
 * ISO_CLKEN_DLY (the switch settling, PD_SWITCH_SETTLE) and ISO_RST_DLY pace
 * nothing the bridge forwards and keep the build's values. */
static uint8_t at_least(uint8_t v, uint8_t lat) { return (lat > v) ? lat : v; }

void pd_dev_delays_of(unsigned d, struct ppu_dev_delays *out)
{
  const uint8_t lat = pd_cfg[d].ckrst_lat;
  *out = pd_dev_delays;
  out->clken_rst  = at_least(out->clken_rst, lat);
  out->clken_iso  = at_least(out->clken_iso, lat);
  out->rst_hwstat = at_least(out->rst_hwstat, lat);
}

bool pd_dev_delays_ok(unsigned d)
{
  struct ppu_dev_delays now, want;
  ppu_get_dev_delays(&pd_tab[d].ppu, &now);
  pd_dev_delays_of(d, &want);
  return now.rst_hwstat == want.rst_hwstat &&
         now.iso_clken  == want.iso_clken  &&
         now.clken_rst  == want.clken_rst  &&
         now.clken_iso  == want.clken_iso  &&
         now.iso_rst    == want.iso_rst;
}

/* ===========================================================================
 * The event path
 * ========================================================================= */
void pd_poll(void)
{
  /* The interrupt block's inputs into flags (hal/scp_irq.h): this is where a
     taken line is looked at, in thread context. Each PPU input that fired is
     masked until its PPU has been serviced below. */
  scp_irq_collect();
  uint32_t pend = scp_irq_take_ppu();

  for (unsigned d = 0; d < PD_COUNT && pend; d++) {
    if (!(pend & (1u << d))) continue;
    pend &= ~(1u << d);
    struct pd *pd = &pd_tab[d];

    uint32_t isr, aisr;
    ppu_irq_status(&pd->ppu, &isr, &aisr);
    ppu_irq_clear(&pd->ppu, isr, aisr);

    pd->ev.lines++;
    if (!(isr & PPU_ISR_W1C) && !(aisr & PPU_AISR_W1C)) pd->ev.spurious++;
    if (isr  & PPU_ISR_STA_POLICY_TRN)   pd->ev.policy_trn++;
    if (isr  & PPU_ISR_STA_ACCEPT)       pd->ev.sta_accept++;
    if (isr  & PPU_ISR_STA_DENY)         pd->ev.sta_deny++;
    if (isr  & PPU_ISR_LOCKED)           pd->ev.locked++;
    if (isr  & PPU_ISR_PWR_ACTIVE_EDGE0) pd->ev.edge++;
    if (aisr & PPU_AISR_DYN_ACCEPT)      pd->ev.dyn_accept++;
    if (aisr & PPU_AISR_DYN_DENY)        pd->ev.dyn_deny++;
    if (aisr & PPU_AISR_UNSPT_POLICY)    pd->ev.unspt++;

    /* The event may be the one a request in flight is waiting for. */
    pd_on_ppu_irq(d);

    /* The PPU's IRQ is a combinational OR of its status registers, and it
       reaches the block on the same clock with no synchroniser, so the clears
       above have already dropped it: unmasking now (PENDING cleared, ENABLE
       set) cannot re-enter for the same events. Anything new since the read
       keeps it HIGH, and is taken next time. */
    scp_irq_unmask(scp_irq_ppu_bit(d));
  }
}

/* Sleep until an interrupt or until `until`, but never longer than
 * PD_POLL_TICKS. Called with mstatus.MIE CLEAR, and that is what makes it
 * correct: the caller has just checked its condition, and an interrupt that
 * arrives between that check and the WFI stays pending instead of being taken
 * -- so the WFI returns at once rather than sleeping past it. MIE is opened
 * only after the WFI, which is where the handler runs. */
static void pd_idle(uint64_t until)
{
  uint64_t t = timer_after(PD_POLL_TICKS);
  if (t > until) t = until;
  timer_arm(t);
  wfi();
  irq_enable();
  irq_disable();
  timer_disarm();
}

void pd_sleep(uint32_t ticks)
{
  uint64_t until = timer_after(ticks);
  uint32_t was = irq_save();
  while (!timer_passed(until)) {
    pd_poll();
    pd_idle(until);
  }
  pd_poll();
  irq_restore(was);
}

/* ===========================================================================
 * Waiting
 * ========================================================================= */
int pd_wait_modes(uint32_t doms, const enum ppu_mode modes[PD_COUNT], uint32_t timeout)
{
  uint64_t until = timer_after(timeout);
  uint32_t left  = doms;
  int      rc    = PD_OK;
  uint32_t was   = irq_save();

  for (;;) {
    pd_poll();
    for (unsigned d = 0; d < PD_COUNT; d++) {
      if (!(left & (1u << d))) continue;
      const struct ppu *p = &pd_tab[d].ppu;
      if ((ppu_status(p) & PPU_PWSR_STATUS) == (uint32_t)modes[d]) {
        left &= ~(1u << d);
        continue;
      }
      /* A static policy that no longer says what we asked for was reverted
         by a denial (PPU 4.1.1): it will never arrive, so stop waiting for it
         (design doc 5.6.4b: "denial is not just later, it is erasure"). */
      uint32_t pwpr = ppu_policy(p);
      if (!(pwpr & PPU_PWPR_DYN_EN) && (pwpr & PPU_PWPR_POLICY) != (uint32_t)modes[d]) {
        left &= ~(1u << d);
        rc = PD_E_DENIED;
      }
    }
    if (!left) break;
    if (timer_passed(until)) { rc = PD_E_TIMEOUT; break; }
    pd_idle(until);
  }

  irq_restore(was);
  return rc;
}

int pd_wait_mode(unsigned d, enum ppu_mode m, uint32_t timeout)
{
  enum ppu_mode modes[PD_COUNT] = { PPU_MODE_OFF };
  modes[d] = m;
  return pd_wait_modes(1u << d, modes, timeout);
}

/* ===========================================================================
 * Raw static control
 * ========================================================================= */
int pd_request_mode(unsigned d, enum ppu_mode m)
{
  struct pd *pd = &pd_tab[d];
  if (d >= PD_COUNT || !pd->present) return PD_E_ABSENT;
  int rc = dyn_settle(&pd->ppu, timer_after(PD_DYN_SETTLE));
  if (rc) return rc;
  /* A static policy has PWR_DYN_EN and LOCK_EN clear, and clearing either is
     an unlock condition (PPU 3.4.3): this write also releases a locked OFF. */
  return from_ppu(ppu_set_policy(&pd->ppu, m, false, false));
}

int pd_set_mode(unsigned d, enum ppu_mode m, uint32_t timeout)
{
  int rc = pd_request_mode(d, m);
  if (rc) return rc;
  return pd_wait_mode(d, m, timeout);
}

/* ===========================================================================
 * Non-blocking static requests (pd.h, NON-BLOCKING REQUESTS)
 * ========================================================================= */
static int finish(struct pd *pd, int rc)
{
  pd->phase  = PD_PH_IDLE;
  pd->result = (int8_t)rc;
  return rc;
}

/* PPU_PWSR shows the mode asked for. */
static bool reached(const struct ppu *p, enum ppu_mode m)
{
  return (enum ppu_mode)(ppu_status(p) & PPU_PWSR_STATUS) == m;
}

/* A static policy that no longer says what was asked for was reverted by a
   denial (PPU 4.1.1): it will never arrive (design doc 5.6.4b: "denial is not
   just later, it is erasure"). The same test as pd_wait_modes. */
static bool reverted(const struct ppu *p, enum ppu_mode m)
{
  uint32_t pwpr = ppu_policy(p);
  return !(pwpr & PPU_PWPR_DYN_EN) && (pwpr & PPU_PWPR_POLICY) != (uint32_t)m;
}

int pd_request_static(unsigned d, enum ppu_mode m, uint32_t timeout)
{
  if (d >= PD_COUNT || !pd_tab[d].present) return PD_E_ABSENT;
  struct pd *pd = &pd_tab[d];
  const struct ppu *p = &pd->ppu;
  /* The programming in force now, read from the PPU rather than remembered:
     the hardware is the only record that cannot be stale. */
  const uint32_t pwpr   = ppu_policy(p);
  const bool     devact = ppu_devactive_en(p);
  const enum ppu_mode from = (enum ppu_mode)(pwpr & PPU_PWPR_POLICY);
  const bool programmed = from == m && !(pwpr & PPU_PWPR_DYN_EN) && !devact &&
                          !(pwpr & PPU_PWPR_LOCK_EN);
  /* Programmed AND in that mode: then there is nothing to do. Programmed but
     NOT there is a PPU on its way; re-driving the policy is harmless and
     waits for it like any other request. */
  const bool same = programmed && reached(p, m);

  pd->mode        = (uint8_t)m;
  pd->from_devact = devact;
  /* Does the request LOOSEN what the PPU may do on its own? A lower policy
     does; so, at the same policy, does disarming the wake input. */
  pd->deeper      = !same && (programmed || (from != m ? m < from : devact));
  pd->deadline    = timer_after(timeout);
  pd->result      = PD_PENDING;
  /* The policy write may change PWR_DYN_EN: not before the last change has
     taken effect (PPU 4.1.1). The first look is now, so an idle PPU is
     written before this returns. */
  pd->phase = same ? PD_PH_SETTLE : PD_PH_DYN;
  return pd_advance(d);
}

int pd_advance(unsigned d)
{
  struct pd *pd = &pd_tab[d];
  const struct ppu *p = &pd->ppu;
  const enum ppu_mode m = (enum ppu_mode)pd->mode;
  int rc;

  switch (pd->phase) {
  case PD_PH_DYN:
    if (!ppu_dyn_settled(p)) return PD_PENDING;
    if (pd->deeper) {
      /* COMPONENT FIRST, POLICY LAST (design doc 5.6.1, 5.6.6 steps 4-7). The
         freedom to descend must arrive after the context is safe, never
         before: the moment the floor drops, DEVQACTIVE is likely already LOW.
         The wake input is disarmed first, so that a busy device is asked
         rather than waited for (pd.h, pd_request_static). */
      const bool disarm = pd->from_devact;
      if (disarm) ppu_set_devactive_en(p, false);
      rc = from_ppu(ppu_set_policy(p, m, false, false));
      if (rc) {
        if (disarm) ppu_set_devactive_en(p, true);
        return finish(pd, rc);
      }
    } else {
      /* POLICY FIRST (design doc 5.6.7). One write, with LOCK_EN clear:
         clearing LOCK_EN is itself an unlock condition (PPU 3.4.3). */
      rc = from_ppu(ppu_set_policy(p, m, false, false));
      if (rc) return finish(pd, rc);
    }
    pd->phase = PD_PH_SETTLE;
    /* fall through */

  case PD_PH_SETTLE:
    if (!reached(p, m)) {
      if (reverted(p, m)) return finish(pd, PD_E_DENIED);
      return PD_PENDING;
    }
    /* A static mode is reached once PWR_DYN_STATUS has caught up too: that
       is "static mode" for PPU 4.1.3, and the next thing a caller may do is
       change DEVREQEN (ppu_set_devreq_en checks it) or PWR_DYN_EN (4.1.1). */
    if (!ppu_dyn_settled(p)) return PD_PENDING;
    return finish(pd, PD_OK);

  default:
    return pd->result;
  }
}

void pd_on_ppu_irq(unsigned d)
{
  if (pd_busy(d)) pd_advance(d);
}

/* One last look, and then the deadline. */
static int expire(unsigned d)
{
  struct pd *pd = &pd_tab[d];
  int rc = pd_advance(d);
  if (rc != PD_PENDING || !timer_passed(pd->deadline)) return rc;
  pd->phase    = PD_PH_FAULT;
  pd->result   = PD_E_TIMEOUT;
  return PD_E_TIMEOUT;
}

uint64_t pd_tick(void)
{
  uint64_t next = UINT64_MAX;
  for (unsigned d = 0; d < PD_COUNT; d++) {
    if (!pd_busy(d)) continue;
    if (expire(d) == PD_PENDING && pd_tab[d].deadline < next) next = pd_tab[d].deadline;
  }
  return next;
}

/* Run a request to completion: look, then check the deadline, then sleep.
   While PWR_DYN_STATUS is catching up nothing is certain to interrupt, so that
   phase is polled without sleeping, as dyn_settle() does. */
int pd_complete(unsigned d)
{
  struct pd *pd = &pd_tab[d];
  int rc;
  uint32_t was = irq_save();
  for (;;) {
    pd_poll();
    rc = expire(d);
    if (rc != PD_PENDING) break;
    if (pd->phase != PD_PH_DYN) pd_idle(pd->deadline);
  }
  irq_restore(was);
  return rc;
}
