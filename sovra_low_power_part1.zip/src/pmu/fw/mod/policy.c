/* The DEVICE_POWER policy for soc4's static-only PPUs. See policy.h.
 *
 * Links only into soc4_scp (src/soc4/fw/Makefile): it needs librpmi's
 * definitions. */
#include <librpmi.h>
#include "policy.h"
#include "soc4_cpu.h"
#include "scp_rpmi.h"
#include "scp_loop.h"
#include "scp_irq.h"
#include "timer.h"
#include "console.h"
#include "flog.h"
#include "lib.h"

_Static_assert(RPMI_DPWR_STATE_ON <= 0xFF && RPMI_DPWR_STATE_OFF <= 0xFF, "vote fits a byte");

const struct policy_cfg policy_cfg_default = {
  .on_ticks      = S4_TICKS_PER_MS,
  .step_ticks    = S4_TICKS_PER_MS,
  .hyst_ticks    = S4_TICKS_PER_MS,
  .backoff_ticks = S4_TICKS_PER_MS / 10u,
  .retry_cap     = 3,
  .recover_tries = 3,
};

/* One policy domain per DEVICE_POWER domain and per PPU: DOMAIN_ID = PPU
   index. Each domain's kind and low-power mode are in the domain table,
   pd_cfg[] (mod/pd.h). */
struct s4_dom s4_dom[PD_COUNT];
struct policy_wake policy_wake;

static struct policy_cfg cfg;

enum ppu_mode policy_lp(unsigned id) { return (enum ppu_mode)pd_cfg[id].lp; }

const char *policy_state_name(unsigned s)
{
  static const char *const n[] = {
    "LP", "ON", "HYST", "PREP", "LPREQ", "BACKOFF", "FORCE", "FAULT",
  };
  return (s < ARRAY_SIZE(n)) ? n[s] : "?";
}

const struct policy_cfg *policy_get_cfg(void) { return &cfg; }

/* Every domain in S4_LP with the vote OFF; no PPU access: all four are in
   PPU OFF from reset and stay there until the AP votes ON. */
void policy_init(const struct policy_cfg *c)
{
  cfg = c ? *c : policy_cfg_default;
  if (cfg.on_ticks > S4_ON_MAX_TICKS)  cfg.on_ticks = S4_ON_MAX_TICKS;
  if (cfg.on_ticks == 0)               cfg.on_ticks = 1;
  if (cfg.step_ticks == 0)             cfg.step_ticks = 1;
  if (cfg.retry_cap > S4_MAX_RETRIES)  cfg.retry_cap = S4_MAX_RETRIES;
  memset(s4_dom, 0, sizeof s4_dom);
  memset(&policy_wake, 0, sizeof policy_wake);
  for (unsigned id = 0; id < PD_COUNT; id++) {
    s4_dom[id].vote  = RPMI_DPWR_STATE_OFF;
    s4_dom[id].state = S4_LP;
  }
  /* The clock/reset bridge inputs are the policy's (hal/scp_irq.h, OWNERS).
     A bridge status already set -- kept across a watchdog reset -- interrupts
     at once. */
  scp_irq_unmask(scp_irq_act_bits(SCP_ACT_CKRST));
}

/* ===========================================================================
 * Taking over after a watchdog reset (policy.h, ADOPTION)
 * ========================================================================= */
static bool at_lp(unsigned id);
static void fault(unsigned id, int rc);

uint32_t policy_adopted;

void policy_adopt(bool kept)
{
  for (unsigned id = 0; id < PD_COUNT; id++) {
    struct s4_dom *s = &s4_dom[id];
    if (!pd_tab[id].present) continue;
    const struct ppu *p = &pd_tab[id].ppu;
    const enum ppu_mode mode = ppu_mode(p);
    /* Static ON, reached and settled: PPU_PWPR {ON, static, unlocked}. */
    const bool on = ppu_policy(p) == PPU_MODE_ON && mode == PPU_MODE_ON && ppu_dyn_settled(p);
    bool voted = scp_rpmi_dpwr_voted(id);
    const char *how;

    if (!kept && on) {                       /* no record: hold it for its owner */
      scp_rpmi_dpwr_wake_vote(id);
      voted = scp_rpmi_dpwr_voted(id);
    }
    if (voted && !on) {                      /* the votes contradict the PPU */
      scp_rpmi_dpwr_drop(id);
      voted = false;
    }
    if (voted) {
      s->state = S4_ON;
      s->vote  = RPMI_DPWR_STATE_ON;
      s->up    = true;
      how = "ON, voted";
    } else if (at_lp(id)) {
      how = "low-power";                     /* S4_LP, as policy_init left it */
    } else if (on) {
      s->state = S4_HYST;                    /* a power-off the reset cut short */
      s->up    = true;
      s->at    = timer_after(cfg.hyst_ticks);
      how = "ON, no vote: power-off resumed";
    } else {
      fault(id, PD_E_BUSY);                  /* between modes: recover it */
      how = "neither: FAULT";
    }
    if (s->state != S4_LP) policy_adopted++;
    con_printf("scp: adopt DOMAIN_ID %u (%s): PPU %s, %s\n", id, pd_cfg[id].name,
               pd_mode_name(mode), how);
  }
}

/* ===========================================================================
 * Helpers
 * ========================================================================= */
static uint32_t left(uint64_t until)
{
  const uint64_t now = timer_now();
  return (now >= until) ? 1u : (uint32_t)(until - now);
}

static int run(unsigned d, int rc)
{
  return (rc == PD_PENDING) ? pd_complete(d) : rc;
}

/* Is the PPU on its way to a mode below the one it is in? Static only here: a
   policy below PPU_PWSR's mode. That is a power-off step (S4_LPREQ, S4_FORCE)
   or one whose deadline expired (S4_FAULT): the PPU has no deadline of its
   own, and once the device has been asked only its accept or its denial ends
   the hop (PPU 4.1.1; W4.1's policy had the same going_down). A static ON while in
   WARM_RST also counts (8 < 9); waiting for it is harmless. */
static bool going_down(const struct ppu *p, enum ppu_mode *to)
{
  *to = (enum ppu_mode)(ppu_policy(p) & PPU_PWPR_POLICY);
  return *to < ppu_mode(p);
}

/* Already where the power-off leads, statically: PPU_PWPR == {lp, static} and
   PPU_PWSR == lp. Nothing to write. */
static bool at_lp(unsigned id)
{
  const struct ppu *p = &pd_tab[id].ppu;
  return ppu_policy(p) == pd_cfg[id].lp && ppu_mode(p) == policy_lp(id);
}

/* The one entry into S4_FAULT. A failure outside a retry arms cfg.recover_tries
   retries of the power-off; a failed retry has already used one. */
static void fault(unsigned id, int rc)
{
  struct s4_dom *s = &s4_dom[id];
  const bool retry = s->recovering;
  s->state   = S4_FAULT;
  s->err     = (int8_t)rc;
  s->faulted = true;
  s->faults++;
  /* The fault log (mod/flog.h): the error, and whether this was a retry of
     the power-off and the last one. */
  flog_add(FLOG_FAULT, id, (uint8_t)rc | (retry ? FLOG_FAULT_RETRY : 0u) |
                           ((retry && s->recover == 0) ? FLOG_FAULT_GAVEUP : 0u));
  if (!s->recovering) {
    s->recover = cfg.recover_tries;
    con_printf("scp: FAULT: DOMAIN_ID %u (%s), %s; will retry power-off %u times\n", id,
               pd_cfg[id].name, pd_err_name(rc), s->recover);
  } else if (s->recover == 0) {
    s->gaveup++;
    s->recovering = false;
    con_printf("scp: FAULT: DOMAIN_ID %u gave up after %u power-off retries (err %s)\n", id,
               cfg.recover_tries, pd_err_name(rc));
  }
  s->at = timer_after(cfg.hyst_ticks);
}

/* ===========================================================================
 * ON: synchronous, bounded
 * ========================================================================= */
static int vote_on(unsigned id)
{
  const unsigned d = id;                       /* DOMAIN_ID = PPU index      */
  const struct ppu *p = &pd_tab[d].ppu;
  const bool cpu = pd_cfg[id].kind == PD_KIND_CPU;
  struct s4_dom *s = &s4_dom[id];

  /* 1. Inside the hysteresis window: nothing was asked of the PPU yet. `up` is
     set only once static ON was reached, so a HYST that follows a fault never
     cancels. */
  if (s->state == S4_HYST && s->up && !pd_busy(d)) {
    s->state = S4_ON;
    s->vote  = RPMI_DPWR_STATE_ON;
    s->cancels++;
    return RPMI_SUCCESS;
  }
  s->recovering = false;

  /* 2. THIS WAIT STALLS THE MAIN LOOP (policy.h, ON). */
  const uint64_t until = timer_after(cfg.on_ticks);
  int rc = PD_OK;
  enum ppu_mode to;
  if (going_down(p, &to)) {
    s->waits++;
    rc = pd_wait_mode(d, to, left(until));
    if (rc == PD_E_DENIED) rc = PD_OK;         /* reverted to ON: it never left */
  }

  /* 3. Classify before any write (SOC4_DESIGN.md 9.4, review fix 7). FULL_RET
     is the mode, not a domain's setting: the one LP mode that keeps a CPU's
     logic (DEN 0051E Table 3-2), so only from there is ON a resume. */
  const enum ppu_mode now = ppu_mode(p);
  const bool warm = cpu && !s->faulted &&
                    (now == PPU_MODE_FULL_RET || (now == PPU_MODE_ON && s->up));
  if (cpu && !warm) cpu_fetch(id, false);      /* cold: never fetch a lost RAM */

  /* 4. A forced power-down left the device channel off. It comes back only
     from ON reached under a static policy (PPU 4.1.3); for a warm CPU0 this
     static ON is the resume itself. */
  if (rc == PD_OK && !(ppu_rd(p, PPU_PWCR) & PPU_PWCR_DEVREQEN0)) {
    rc = run(d, pd_request_static(d, PPU_MODE_ON, left(until)));
    if (rc == PD_OK && ppu_set_devreq_en(p, true) != PPU_OK) rc = PD_E_BUSY;
  }

  /* 5. The sequence for the class, all inside the one deadline. */
  if (rc == PD_OK) {
    if (cpu && !warm) {
      rc = soc4_cpu_cold(id, until);
    } else {
      rc = run(d, pd_request_static(d, PPU_MODE_ON, left(until)));
      if (rc == PD_OK && !cpu && s->faulted) {
        /* Decision 9: WARM_RST recovery. No handshake: PTCR.WARM_RST_DEVREQEN
           resets to 0 on these PPUs (DEN 0051E Table 4-4). */
        rc = run(d, pd_request_static(d, PPU_MODE_WARM_RST, left(until)));
        if (rc == PD_OK) rc = run(d, pd_request_static(d, PPU_MODE_ON, left(until)));
      }
    }
  }

  /* 7. The vote stays OFF, so the policy must take the domain down itself. */
  if (rc != PD_OK) {
    fault(id, rc);
    return RPMI_ERR_HW_FAULT;
  }

  /* 6. */
  s->state   = S4_ON;
  s->vote    = RPMI_DPWR_STATE_ON;
  s->up      = true;
  s->faulted = false;
  s->recover = 0;
  s->ons++;
  return RPMI_SUCCESS;
}

/* ===========================================================================
 * OFF: the vote now, the power later
 * ========================================================================= */
static void vote_off(unsigned id)
{
  struct s4_dom *s = &s4_dom[id];
  s->vote = RPMI_DPWR_STATE_OFF;
  if (s->state == S4_ON) {
    s->state = S4_HYST;
    s->at    = timer_after(cfg.hyst_ticks);
  }
  /* The OFF ends any wake vote: re-arm the level inputs that held one. One
     still HIGH interrupts at once, and the main loop powers the domain back
     up (policy.h, WAKE INPUTS). A device write, not a librpmi call. */
  if (s->wake_in) {
    scp_irq_unmask(s->wake_in);
    s->wake_in = 0;
  }
}

int policy_vote(uint32_t id, uint32_t state)
{
  /* librpmi has already answered INVALID_PARAM for id >= the group's count
     (LR rpmi_service_group_device_power.c:300-303), and rpmi/scp_rpmi.c's
     dpwr_set for a state other than ON or OFF (LR include/librpmi.h:1620-1625);
     these are the policy's own guards. */
  if (id >= PD_COUNT) return RPMI_ERR_INVALID_PARAM;
  if (state == RPMI_DPWR_STATE_ON)  return vote_on(id);
  if (state == RPMI_DPWR_STATE_OFF) { vote_off(id); return RPMI_SUCCESS; }
  return RPMI_ERR_INVALID_PARAM;
}

/* ===========================================================================
 * The power-off, one step at a time
 * ========================================================================= */
static int result(unsigned d)
{
  return pd_busy(d) ? PD_PENDING : pd_tab[d].result;
}

/* Start a step. A denial may come at once, when the device refuses before the
   driver's read-back (ppu_set_policy returns PPU_E_REVERTED): pd->result holds
   it, and the next step reads it from there. */
static bool begin(unsigned id, int rc, enum s4_state next)
{
  if (rc != PD_PENDING && rc != PD_OK && rc != PD_E_DENIED) {
    fault(id, rc);
    return false;
  }
  s4_dom[id].state = (uint8_t)next;
  return true;
}

static void reached_lp(unsigned id)
{
  struct s4_dom *s = &s4_dom[id];
  s->state = S4_LP;
  s->up    = false;
  s->offs++;
  if (s->recovering) {
    s->recovering = false;
    s->recoveries++;
    con_printf("scp: DOMAIN_ID %u recovered to %s\n", id,
               pd_mode_name(policy_lp(id)));
  }
}

static void step(unsigned id)
{
  const unsigned d = id;
  const struct ppu *p = &pd_tab[d].ppu;
  const enum ppu_mode lp = policy_lp(id);
  struct s4_dom *s = &s4_dom[id];
  enum ppu_mode to;
  int rc;

  switch (s->state) {
  case S4_HYST:
    if (!timer_passed(s->at)) return;
    s->retries = 0;
    if (at_lp(id)) { reached_lp(id); return; }
    begin(id, pd_request_static(d, PPU_MODE_ON, cfg.step_ticks), S4_PREP);
    return;

  case S4_PREP:
  case S4_BACKOFF:
    if (s->state == S4_PREP) {
      if ((rc = result(d)) == PD_PENDING) return;
      if (rc != PD_OK) break;
    } else if (!timer_passed(s->at)) {
      return;
    }
    begin(id, pd_request_static(d, lp, cfg.step_ticks), S4_LPREQ);
    return;

  case S4_LPREQ:
    if ((rc = result(d)) == PD_PENDING) return;
    if (rc == PD_E_DENIED) {
      /* The PPU put the policy back to ON, where the domain still is
         (PPU 4.1.1, Table 4-1). */
      s->denials++;
      if (s->retries < cfg.retry_cap) {
        s->at = timer_after(cfg.backoff_ticks << s->retries);
        s->retries++;
        s->state = S4_BACKOFF;
        return;
      }
      /* Force it: static ON reached, so DEVREQEN may go to 0 (PPU 4.1.3). */
      if (ppu_set_devreq_en(p, false) != PPU_OK) { rc = PD_E_BUSY; break; }
      s->forced++;
      flog_add(FLOG_FORCED, id, s->retries + 1u);
      begin(id, pd_request_static(d, lp, cfg.step_ticks), S4_FORCE);
      return;
    }
    if (rc != PD_OK) break;
    reached_lp(id);
    return;

  case S4_FORCE:
    if ((rc = result(d)) == PD_PENDING) return;
    if (rc != PD_OK) break;
    reached_lp(id);
    return;

  case S4_FAULT:
    if (!s->recover || !timer_passed(s->at)) return;
    s->recover--;
    s->recovering = true;
    if (going_down(p, &to)) {
      /* A hop still stuck (a device that never quiesces): this retry fails
         at once, and fault() spaces the next one. */
      fault(id, PD_E_TIMEOUT);
      return;
    }
    if (at_lp(id)) { reached_lp(id); return; }
    s->retries = 0;
    begin(id, pd_request_static(d, PPU_MODE_ON, cfg.step_ticks), S4_PREP);
    return;

  default:
    return;
  }
  fault(id, rc);
}

static void step_all(void)
{
  for (unsigned id = 0; id < PD_COUNT; id++) {
    uint8_t was;
    do {
      was = s4_dom[id].state;
      step(id);
    } while (s4_dom[id].state != was);
  }
}

/* ===========================================================================
 * Clock/reset bridge faults (policy.h, CLOCK/RESET BRIDGE FAULTS)
 * ========================================================================= */
/* A fault the hardware found while the domain may be voted ON: the votes are
   dropped, so GET_STATE answers OFF and the agent's next ON reaches the policy
   (librpmi forwards only a change, LR rpmi_service_group_device_power.c:
   128-131), then the FAULT path takes the domain down as for a failed ON. */
static void hw_fault(unsigned id, int rc)
{
  struct s4_dom *s = &s4_dom[id];
  if (scp_rpmi_dpwr_voted(id)) scp_rpmi_dpwr_drop(id);
  s->vote = RPMI_DPWR_STATE_OFF;
  if (s->wake_in) {
    scp_irq_unmask(s->wake_in);
    s->wake_in = 0;
  }
  s->recovering = false;
  fault(id, rc);
}

#ifdef SCP_PLAT_CKRST_STAT
static void in_ckrst(unsigned i)
{
  const struct scp_in_cfg *c = &scp_in_cfg[i];
  unsigned n = 0;
  for (unsigned d = 0; d < PD_COUNT; d++) {
    const uint32_t reg = SCP_PLAT_CKRST_STAT(d);
    const unsigned sh  = 8u * (d & 3u);
    const uint32_t st  = (mmio_read32(reg) >> sh) & 0xFFu;
    if (!st) continue;
    mmio_write32(reg, st << sh);               /* W1C what was read */
    n++;
    con_printf("scp: in %u %s: clock/reset bridge DOMAIN_ID %u status 0x%02x\n", i, c->name, d, st);
    flog_add(FLOG_CLKRST, d, st);
    hw_fault(d, PD_E_CLKRST);
  }
  if (!n) con_printf("scp: in %u %s: no bridge status set\n", i, c->name);
}
#else
static void in_ckrst(unsigned i)
{
  con_printf("scp: in %u %s: no bridge status register on this platform\n", i, scp_in_cfg[i].name);
}
#endif

/* ===========================================================================
 * Wake inputs (policy.h, WAKE INPUTS)
 * ========================================================================= */
static void in_power_up(unsigned i, unsigned id)
{
  const struct scp_in_cfg *c = &scp_in_cfg[i];
  const uint32_t bit = SCP_IN_BIT(i);
  const bool level = c->mode == SCP_IN_LEVEL;
  struct s4_dom *s = &s4_dom[id];

  if (id >= PD_COUNT) {
    con_printf("scp: in %u %s: no DOMAIN_ID %u\n", i, c->name, id);
    if (level) scp_irq_rearm_low(bit);
    return;
  }
  if (s->vote == RPMI_DPWR_STATE_ON) {
    /* Already voted ON (by the agent, or by an earlier wake): the input
       joins the wake vote, so a level one is re-armed at the next OFF. */
    if (level) s->wake_in |= bit;
    con_printf("scp: in %u %s: DOMAIN_ID %u already ON\n", i, c->name, id);
    return;
  }
  const int rc = vote_on(id);
  if (rc == RPMI_SUCCESS) {
    s->wakes++;
    scp_rpmi_dpwr_wake_vote(id);
    if (level) s->wake_in |= bit;
  } else if (level) {
    scp_irq_rearm_low(bit);
  }
  con_printf("scp: in %u %s: power up DOMAIN_ID %u: %s\n", i, c->name, id,
             (rc == RPMI_SUCCESS) ? "SUCCESS" : "FAILED");
}

static void policy_inputs(void)
{
  uint32_t act = scp_irq_take_act();
  for (unsigned i = 0; act; i++, act >>= 1) {
    if (!(act & 1u)) continue;
    const struct scp_in_cfg *c = &scp_in_cfg[i];
    const uint32_t bit = SCP_IN_BIT(i);
    switch (c->act) {
    case SCP_ACT_POWER_UP:
      in_power_up(i, c->arg);
      continue;                              /* re-armed by its own rule     */
    case SCP_ACT_NOTIFY:
      policy_wake.notify++;
      con_printf("scp: in %u %s: policy notified (%u)\n", i, c->name, policy_wake.notify);
      break;
    case SCP_ACT_CKRST:
      in_ckrst(i);
      break;
    case SCP_ACT_REASON:
      policy_wake.last     = c->arg;
      policy_wake.reasons |= 1u << (c->arg & 31u);
      policy_wake.count++;
      con_printf("scp: in %u %s: wake reason %u recorded (%u)\n", i, c->name, c->arg,
                 policy_wake.count);
      break;
    default:
      policy_wake.ignored++;
      con_printf("scp: in %u %s: ignored\n", i, c->name);
      break;
    }
    scp_irq_rearm_low(bit);                  /* a level input; edge: no-op   */
  }
}

/* ===========================================================================
 * The main loop's hooks
 * ========================================================================= */
void policy_work(void)
{
  pd_poll();                                 /* PPU lines: pd_on_ppu_irq(),
                                                and every input collected    */
  for (unsigned d = 0; d < PD_COUNT; d++)
    if (pd_busy(d)) pd_advance(d);           /* completions with no interrupt */
  step_all();
  policy_inputs();                           /* wake inputs: may power up    */
}

uint64_t policy_deadline(void)
{
  uint64_t next = pd_tick();                 /* expired: PD_PH_FAULT         */
  step_all();                                /* ...and so S4_FAULT, now      */
  bool busy = false;
  for (unsigned id = 0; id < PD_COUNT; id++) {
    const struct s4_dom *s = &s4_dom[id];
    const bool waits = s->state == S4_HYST || s->state == S4_BACKOFF ||
                       (s->state == S4_FAULT && s->recover);
    if (waits && s->at < next) next = s->at;
    busy |= pd_busy(id);
  }
  if (busy) {
    const uint64_t poll = timer_after(SCP_LOOP_POLL_TICKS);
    if (poll < next) next = poll;
  }
  return (next == UINT64_MAX) ? SCP_LOOP_NEVER : next;
}
