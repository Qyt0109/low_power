/* The power domain manager: one domain per PPU, the table from the platform.
 *
 * README Section 5.2. The driver (hal/ppu_v1) knows registers; this module
 * knows what the registers are FOR:
 *
 *   - which domains exist and how each is set up: pd_cfg[], THE DOMAIN TABLE
 *     (below), from the platform header (soc4: src/soc4/fw/soc4_plat.h,
 *     force-included), with SCP_NUM_PPU entries
 *   - the order the fields must be written in when the mode changes
 *     (design doc 5.6.1: component first when deepening, register first when
 *     shallowing)
 *   - waiting, with a deadline, because the PPU has none (design doc 5.6.8)
 *   - the PPU interrupts: pd_poll() is the only code that reads or clears a
 *     PPU's PPU_ISR/PPU_AISR, and it counts every event per domain
 *
 * NON-BLOCKING REQUESTS. pd_request_static() starts a change to a static
 * mode and returns. One request per domain is in flight at a time: a new one
 * replaces the old (REPLACING A REQUEST, below). It then moves through
 * phases:
 *
 *   PD_PH_DYN     waiting for PWR_DYN_STATUS to catch up (README 6, rule 10)
 *                 before the PPU_PWPR write
 *   PD_PH_SETTLE  waiting for the mode to be reached
 *
 * and ends in PD_PH_IDLE with pd->result set, or in PD_PH_FAULT. Three things
 * advance it: pd_on_ppu_irq(), which pd_poll() calls for every line it
 * services; pd_advance(), for completions that raise no interrupt; and
 * pd_tick(), which expires deadlines. An expired deadline is PD_PH_FAULT and
 * PD_E_TIMEOUT: the PPU waits for PCSMPACCEPT for ever and has no watchdog of
 * its own (design doc 5.6.8), so the request's deadline is the only one there
 * is. FAULT lasts until the next request for the domain.
 *
 * REPLACING A REQUEST. The new request starts from what the PPU's registers
 * say, not from what the old one had got to, and it does NOT stop a
 * transition the old one started. The PPU finishes a transition before it
 * acts on a new policy (PPU 4.1.1: "Software writes to the Power Policy
 * Register (PPU_PWPR) do not interrupt mode transitions"), and PPU_PWSR shows
 * the mode being left until the new one is reached. So a request for ON that
 * replaces one still taking the domain down finds ON "reached" at once, and
 * the domain then goes down and comes back up after the request has ended.
 * The same holds after a deadline has expired: the PPU carries on regardless.
 * A caller that may replace a power-down waits for it to end first, reached
 * or denied (pd_wait_mode); mod/policy.c's ON does.
 *
 * pd_complete() runs a request to completion, sleeping in WFI between looks.
 *
 * Domain n is PPU n. Its interrupt is the input of the SCP's interrupt block
 * that the platform's input table gives it (SCP_ACT_PPU with arg n;
 * hal/scp_irq.h), and scp_irq_init() must run before pd_init(). DEVICE_POWER's
 * DOMAIN_ID i is domain i (mod/policy.h).
 *
 * Until 2026-10-02 this module also had the twelve-domain table of the retired
 * pmu_top, the software power states of the design doc (pd_request,
 * pd_set_state) with their dynamic and locked programming, and pd_boot. No
 * remaining platform uses them; SOC4_DESIGN.md Section 12.
 */
#ifndef PD_H
#define PD_H

#include <stdint.h>
#include <stdbool.h>
#include "ppu_v1.h"
#include "scp_regs.h"
#include "agents.h"

#define PD_COUNT SCP_NUM_PPU

/* ===========================================================================
 * THE DOMAIN TABLE (platform plan F5, Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md
 * Section 14.7). Every per-domain setting of the firmware is here, and only
 * here. The platform header writes it by hand, one D(...) per domain in
 * DOMAIN_ID order (= PPU index):
 *
 *   #define SCP_PLAT_DOMAINS(D)  D(name, latency, fields) ...
 *
 *   name     the domain's name, here and in DEVICE_POWER: at most 15
 *            characters (struct rpmi_dpwr_data's name[16], LR
 *            include/librpmi.h:1634-1639)
 *   latency  DEVICE_POWER's trans_latency for the domain (the same struct)
 *   fields   designated initializers of struct pd_cfg
 *
 * pd.c expands it into pd_cfg[]; rpmi/scp_rpmi.c into its DEVICE_POWER data.
 * ========================================================================= */
enum pd_kind { PD_KIND_DEV = 0, PD_KIND_CPU = 1 };

/* A CPU domain: how the SCP cold-boots it (soc4: mod/soc4_cpu.h). */
struct pd_cpu {
  const uint32_t *image;   /* the CPU's program, copied word by word           */
  uint32_t words;          /* its length, in words                             */
  uint32_t load;           /* the load window: the CPU's RAM on the SCP's map  */
  uint32_t open_reg;       /* the window is open while open_reg & open_mask    */
  uint32_t open_mask;
  uint32_t boot_reg;       /* the boot-address register, and the address       */
  uint32_t boot_addr;
  uint32_t fetch_reg;      /* the fetch-enable register, and this CPU's bit    */
  uint32_t fetch_mask;
};

struct pd_cfg {
  const char *name;
  uint8_t  kind;           /* enum pd_kind                                     */
  uint8_t  lp;             /* enum ppu_mode: where RPMI OFF takes the domain   */
  uint8_t  funrr;          /* PPU_FUNRR, PPU_FULRR, PPU_MEMRR: the retention   */
  uint8_t  fulrr;          /*   RAM configuration of FUNC_RET, FULL_RET and    */
  uint8_t  memrr;          /*   MEM_RET; pd_init writes the ones the PPU has   */
  uint32_t idr0, idr1;     /* PPU_IDR0, PPU_IDR1: what the PPU must report     */
  const struct pd_cpu *cpu;   /* PD_KIND_CPU: its boot details; else NULL      */
  uint8_t  agents;         /* bit k = SCP_AG(id): agent k may vote for the
                              domain (platform plan F6; mod/agents.h). The
                              lowest such agent owns its wake vote
                              (rpmi/scp_rpmi.h)                                */
  uint8_t  ckrst_lat;      /* the SoC clkgate / tilereset's worst-case
                              acknowledgement latency for this domain, in PPU
                              cycles, synchronisers included (platform plan
                              H16, F11; rtl/ckrst/ckrst_bridge.sv). pd_init
                              programs each device control delay that paces a
                              bridged step to at least it: CLKEN_RST_DLY (clock
                              acknowledged before reset release), CLKEN_ISO_DLY
                              (clock acknowledged stopped before isolation) and
                              RST_HWSTAT_DLY (reset acknowledged before
                              PPUHWSTAT reports the mode). DEN 0051E Table
                              4-5: each delay is at least value + 1 cycles.
                              0: the build's defaults (pd_dev_delays)          */
};

extern const struct pd_cfg pd_cfg[PD_COUNT];

struct pd_events {
  uint32_t policy_trn;   /* PPU_ISR  STA_POLICY_TRN   static policy reached   */
  uint32_t sta_accept;   /* PPU_ISR  STA_ACCEPT       static hop completed (masked
                                                      by PD_IMR; counted if a caller
                                                      unmasks it)              */
  uint32_t sta_deny;     /* PPU_ISR  STA_DENY         static transition denied */
  uint32_t locked;       /* PPU_ISR  LOCKED                                    */
  uint32_t edge;         /* PPU_ISR  PWR_ACTIVE_EDGE  DEVQACTIVE edge          */
  uint32_t dyn_accept;   /* PPU_AISR DYN_ACCEPT       autonomous transition    */
  uint32_t dyn_deny;     /* PPU_AISR DYN_DENY                                  */
  uint32_t unspt;        /* PPU_AISR UNSPT_POLICY     a write was refused      */
  uint32_t lines;        /* times the interrupt line was serviced              */
  uint32_t spurious;     /* ...and both status registers were empty           */
};

enum pd_err {
  PD_PENDING       =   1,   /* a request is still in flight (not an error)    */
  PD_OK            =   0,
  PD_E_ABSENT      = -10,   /* no PPU answered at this domain's address        */
  PD_E_UNSUPPORTED = -12,   /* the PPU build lacks the mode or the lock        */
  PD_E_REFUSED     = -13,   /* PPU_PWPR discarded the write                    */
  PD_E_DENIED      = -14,   /* the device refused; the policy was reverted     */
  PD_E_TIMEOUT     = -15,   /* no completion by the deadline                   */
  PD_E_BUSY        = -16,   /* a previous PWR_DYN_EN change has not yet taken
                               effect (PPU 4.1.1): retry once it has           */
  PD_E_CLKRST      = -17,   /* the domain's clock/reset bridge flagged a late,
                               missing or spurious acknowledgement from the
                               SoC's clkgate / tilereset (mod/policy.h)        */
};

enum pd_phase {
  PD_PH_IDLE = 0,   /* nothing in flight; pd->result is how the last one ended */
  PD_PH_DYN,        /* waiting for PWR_DYN_STATUS before the write              */
  PD_PH_SETTLE,     /* waiting for the mode to be reached                      */
  PD_PH_FAULT,      /* the deadline expired first                              */
};

/* A domain's run-time state. Its settings are pd_cfg[d]. */
struct pd {
  bool             present;
  struct ppu       ppu;
  uint32_t         reset_pwpr;   /* PPU_PWPR as found by pd_init: read, not assumed */
  enum ppu_mode    reset_mode;
  struct pd_events ev;
  /* The request in flight, or the last one. Bytes, not enums: pd_tab is in
     .bss, which the SCP's 64 KB RAM shares with the code. */
  uint8_t          phase;        /* enum pd_phase                             */
  int8_t           result;       /* PD_PENDING while in flight, then PD_OK or
                                    a PD_E_*                                  */
  uint8_t          mode;         /* enum ppu_mode: the static mode asked for  */
  bool             deeper;       /* component first, policy last (5.6.1)      */
  bool             from_devact;  /* PWR_DEVACTIVEEN when the request began     */
  uint64_t         deadline;     /* mtime                                     */
};

extern struct pd pd_tab[PD_COUNT];

/* Power-switch settling, in PPU cycles, and the device control delays pd_init
 * programs to cover it -- the switches acknowledge nothing (PGOOD_EN = 0), so
 * these are what stand between a rail coming on and the device's clock and
 * reset. See pd.c for the derivation. */
#define PD_SWITCH_SETTLE 20u
extern const struct ppu_dev_delays pd_dev_delays;
/* Domain d's delays: pd_dev_delays, with CLKEN_RST_DLY, CLKEN_ISO_DLY and
 * RST_HWSTAT_DLY raised to the domain table's ckrst_lat where it is larger
 * (platform plan F11). What pd_init programs. */
void pd_dev_delays_of(unsigned d, struct ppu_dev_delays *out);
bool pd_dev_delays_ok(unsigned d);        /* are those the values in force? */

/* ---- Bring-up ----
 * pd_init: probe every PPU, clear its interrupt status and program its
 * settings (interrupt masks, retention RAM, entry delay, device control
 * delays). It never writes PPU_PWPR or PPU_PWCR: each domain stays in the mode
 * it is in, which it reads into reset_pwpr and reset_mode.
 *
 * pd_adopt: the same after a reset of the SCP alone (a watchdog reset), when
 * the PPUs, always-on, kept their state and may be in any mode, or in a
 * transition: a PPU whose settings already hold is not written at all (its
 * interrupt status is cleared, nothing else); one whose settings differ is
 * programmed as by pd_init and counted in pd_adopt_rewrites. The policy then
 * takes the domains over as they are (mod/policy.h, policy_adopt). */
int  pd_init(void);                         /* probe all; returns how many answered */
int  pd_adopt(void);
extern uint32_t pd_adopt_rewrites;

/* ---- The event path: the only reader of PPU_ISR / PPU_AISR ---- */
void pd_poll(void);

/* ---- Non-blocking requests (see NON-BLOCKING REQUESTS above). Each returns
 *      PD_PENDING while in flight, or how it ended: PD_OK or a PD_E_* ---- */
/* A static policy {m, PWR_DYN_EN = 0, LOCK_EN = 0} with PWR_DEVACTIVEEN
 * cleared first, so that a busy device is ASKED rather than waited for (PPU
 * 3.4.2: from ON, a transition begins only once every DEVQACTIVE input that
 * counts is LOW). A denial ends it with PD_E_DENIED: the PPU has reverted the
 * policy (PPU 4.1.1, Table 4-1), which it does only if PWR_DYN_STATUS was 0
 * when the transition began, so ask for a static mode from a static one. */
int      pd_request_static(unsigned d, enum ppu_mode m, uint32_t timeout);
int      pd_advance(unsigned d);
void     pd_on_ppu_irq(unsigned d);
uint64_t pd_tick(void);                     /* expire; the next deadline, or
                                               UINT64_MAX with none in flight */
int      pd_complete(unsigned d);           /* run one to completion, asleep  */
static inline bool pd_busy(unsigned d)
{
  return pd_tab[d].phase >= PD_PH_DYN && pd_tab[d].phase <= PD_PH_SETTLE;
}

/* ---- Raw static control: PPU_PWPR only, PWR_DYN_EN and LOCK_EN clear ---- */
int  pd_request_mode(unsigned d, enum ppu_mode m);          /* write, read back  */
int  pd_set_mode(unsigned d, enum ppu_mode m, uint32_t timeout);

/* ---- Waiting: asleep in WFI, woken by a PPU line or the timer ---- */
int  pd_wait_mode(unsigned d, enum ppu_mode m, uint32_t timeout);
int  pd_wait_modes(uint32_t doms, const enum ppu_mode modes[PD_COUNT], uint32_t timeout);
void pd_sleep(uint32_t ticks);

/* ---- Names ---- */
const char *pd_mode_name(enum ppu_mode m);
const char *pd_err_name(int rc);

#endif
