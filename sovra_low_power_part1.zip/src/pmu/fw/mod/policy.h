/* The DEVICE_POWER policy for soc4's four static-only PPUs.
 *
 * docs/SOC4_DESIGN.md Section 9.4 (decisions 8 and 9). It keeps
 * the hooks and loop contract of W4.1's dynamic eight-domain policy, which it
 * replaced in this file on 2026-10-02 (SOC4_DESIGN.md Section 12):
 *
 *   scp_rpmi_hooks.dpwr_vote = policy_vote      (rpmi/scp_rpmi.h)
 *   scp_loop_hooks.work      = policy_work      (rpmi/scp_loop.h)
 *   scp_loop_hooks.deadline  = policy_deadline
 *
 * after pd_init() and scp_rpmi_init(). The policy sees one vote per domain:
 * the agents' votes combined by rpmi/scp_rpmi.c (platform plan F6: ON while
 * any agent votes ON, OFF once all vote OFF), passed to policy_vote only when
 * the combined vote changes. A domain is up if and only if that vote is ON,
 * and a power-off waits out a hysteresis window. librpmi is called only from the main loop; the vote
 * hook runs inside librpmi's synchronous set_state (LR include/librpmi.h:
 * 1652-1665), so an ON STALLS THE WHOLE MAIN LOOP until it ends, bounded by
 * cfg.on_ticks.
 *
 * DOMAINS. DOMAIN_ID = PPU index (Section 3.1). The domain table (mod/pd.h,
 * pd_cfg[], written in the platform header) gives each its kind, CPU or
 * device, and its one low-power mode, which is where OFF takes it
 * (pd_cfg[id].lp). The policy holds no per-domain setting of its own.
 *
 * Every domain boots in PPU OFF (DEF_PWR_POLICY = OFF) and stays there until
 * the AP votes ON: policy_init() touches no PPU.
 *
 * STATIC ONLY. The soc4 PPUs have no dynamic modes and no lock (Section 3.3):
 * PPU_PWPR.PWR_DYN_EN and LOCK_EN are reserved there. So the steady states
 * are static ON and static LP, and the policy never writes either enable;
 * pd_request_static() still waits for PWR_DYN_STATUS (mod/pd.c, dyn_settle)
 * and keeps README Section 6 rule 10 for free.
 *
 * ON (policy_vote, synchronous, one deadline for all of it):
 *
 *   1  Inside the hysteresis window of a domain that was up: cancel, with no
 *      PPU access at all (decision 8.2).
 *   2  A power-off step still under way is let end first: reached, or denied,
 *      which reverts the policy to ON (PPU 4.1.1, Table 4-1). "Software writes
 *      to the Power Policy Register (PPU_PWPR) do not interrupt mode
 *      transitions" (PPU 4.1.1), and PPU_PWSR shows the mode being left until
 *      the hop commits.
 *   3  Classify, before any write: WARM if a CPU that has not faulted is in
 *      FULL_RET, or is still in ON from its last power-up (a power-off that
 *      was denied or cancelled never took it down). Classifying after step 4
 *      would take a CPU0 left in a forced FULL_RET to ON first, and the cold
 *      path would then throw its retained state away.
 *   4  After a forced power-down (PPU_PWCR.DEVREQEN = 0): static ON, then
 *      DEVREQEN = 1. A disabled channel comes back only from ON reached under a
 *      static policy (PPU 4.1.3; README Section 6 rule 6). For a cold CPU the
 *      fetch enable is cleared first, so the core never fetches from a RAM
 *      that OFF has lost.
 *   5  WARM: static ON (the adapter's wake pulse ends CPU0's WFI; after a
 *      forced entry the core resumes where it was frozen). COLD CPU: the cold
 *      sequence (mod/soc4_cpu.h). ACC: static ON, or after a fault static ON,
 *      WARM_RST, ON (decision 9: the WARM_RST recovery, with no handshake).
 *   6  Success: RPMI_SUCCESS once PPU_PWSR shows ON.
 *   7  Failure, the deadline included: S4_FAULT, RPMI_ERR_HW_FAULT (LR
 *      include/librpmi.h:141). The vote is not recorded (rpmi/scp_rpmi.c,
 *      dpwr_set), so GET_DPWR_STATE still answers OFF.
 *
 * OFF records the vote and returns at once (decision 8.1). After cfg.hyst_ticks,
 * from policy_work(), without blocking, each step bounded by
 * cfg.step_ticks:
 *
 *   PREP    static ON, which clears PWR_DEVACTIVEEN on the way (pd's deeper
 *           path), so that a busy device is asked rather than waited for: from
 *           ON a static transition begins only once every enabled DEVQACTIVE is
 *           LOW, and a disabled input counts as LOW (PPU 3.4.2, 3.4.1)
 *   LPREQ   static LP. A busy device may deny it (PPU Table 4-1, STA_DENY): the
 *           PPU puts the policy back to ON. Back off cfg.backoff_ticks, doubled
 *           at each retry, up to cfg.retry_cap retries
 *   FORCE   after the cap: DEVREQEN = 0 (static ON reached: PPU 4.1.3), and
 *           static LP sequences with no device handshake at all
 *
 * PWR_DEVACTIVEEN stays cleared in static ON afterwards. That departs from
 * README Section 6 rule 5 on purpose (Section 15.2-13): it only matters at the
 * next static request, which PREP makes with it cleared anyway.
 *
 * A FAULT always leaves the AP's vote at OFF, so the policy itself must take
 * the domain down: librpmi will not deliver another OFF
 * (LR rpmi_service_group_device_power.c:128-131). It retries the power-off up
 * to cfg.recover_tries times, cfg.hyst_ticks apart, and then gives up until the
 * AP's next ON, which runs the WARM_RST recovery (ACC) or the cold reload (CPU).
 *
 * WAKE INPUTS (platform plan F10; hal/scp_irq.h). policy_work() runs the
 * action of every interrupt input the platform's input table gives to the
 * policy, in the main loop, after pd_poll() has collected them:
 *
 *   POWER_UP d  A WAKE VOTE. The PPUs are static-only (PD5), so a wake is an
 *               SCP static request: exactly the ON above (vote_on), from the
 *               main loop rather than from librpmi, with the same deadline,
 *               classification and failure handling. On success the wake votes
 *               ON on behalf of the domain's wake owner, the lowest-numbered
 *               agent that may vote for it (rpmi/scp_rpmi.h): s4_dom.vote (the
 *               combined vote) becomes ON and scp_rpmi_dpwr_wake_vote()
 *               records ON as the owner's DEVICE_POWER vote. So:
 *                 - GET_DPWR_STATE answers ON, which is what the domain is;
 *                 - the agent's next OFF differs from the recorded state, so
 *                   librpmi forwards it (its rule calls set_state only when
 *                   get_state differs, LR rpmi_service_group_device_power.c:
 *                   128-131), and that OFF ends the wake vote: the domain goes
 *                   down after the hysteresis as for any OFF;
 *                 - the agent's ON while the wake vote holds is answered
 *                   SUCCESS by librpmi without reaching the policy, and leaves
 *                   the domain ON, as the ON asks.
 *               A domain already voted ON is left alone. A failure is a FAULT
 *               as for the agent's ON, with the vote still OFF. A LEVEL input
 *               (a PLIC per-hart pending) stays masked while its wake vote
 *               holds and is re-armed when the combined vote goes OFF
 *               (vote_off; with several agents, the last one's OFF): if
 *               the line is still HIGH then, the domain is powered straight
 *               back up -- a hart with an interrupt pending must not stay off.
 *               An EDGE input (a wake line) needs a new edge. After a failure
 *               a level input is re-armed once seen LOW.
 *   NOTIFY      counted in policy_wake.notify; the hook where a policy that
 *               reacts to the SoC PLIC will go. The SCP keeps no SoC modes
 *               (PD9), so today that is all.
 *   REASON r    recorded: policy_wake.last = r, and bit r of .reasons; counted.
 *   IGNORE      counted, nothing else.
 *
 * A level input of the last three is re-armed once seen LOW. Each action
 * prints one console line, "scp: in <i> <name>: ...", which soc4bfm's B12
 * reads as evidence.
 *
 * CLOCK/RESET BRIDGE FAULTS (platform plan H16, F11; rtl/ckrst/ckrst_bridge.sv).
 * Each domain's bridge forwards its PPU's clock enable and resets to the SoC's
 * clkgate / tilereset and flags an acknowledgement that came late (after the
 * PPU's next step), never, or on its own. Its status is sticky; any set raises
 * the input whose action is SCP_ACT_CKRST (a level). policy_work() then, for
 * each domain whose status byte (SCP_PLAT_CKRST_STAT) is not 0:
 *
 *   1  clears the status bits it read (W1C), and prints "scp: in <i> <name>:
 *      clock/reset bridge DOMAIN_ID <d> status 0x<s>";
 *   2  logs FLOG_CLKRST with the status byte (mod/flog.h);
 *   3  drops every agent's vote for the domain and any wake vote: GET_STATE
 *      answers OFF, and the agent's next ON reaches the policy;
 *   4  enters S4_FAULT with PD_E_CLKRST (logged as FLOG_FAULT): the power-off
 *      retries take the domain down, and the next ON recovers it (WARM_RST
 *      for an accelerator, the cold reload for a CPU).
 *
 * and re-arms the input once it reads LOW. The delays that keep a healthy SoC
 * from ever being flagged are pd_init's (mod/pd.h, ckrst_lat).
 *
 * THE FAULT LOG (platform plan F12; mod/flog.h). Every entry into S4_FAULT is
 * logged (FLOG_FAULT: the error, a deadline missed being PD_E_TIMEOUT), and so
 * is every forced power-down (FLOG_FORCED).
 *
 * ADOPTION (platform plan H18). After a watchdog reset of the SCP alone the
 * PPUs, always-on, kept every domain where it was, and the block mod/flog.h
 * keeps across the reset still holds each agent's votes. policy_adopt(), after
 * policy_init(), pd_adopt() and scp_rpmi_init(), rebuilds each domain's
 * state from those two, and writes NO PPU register:
 *
 *   voted ON, static ON reached          S4_ON, up: as before the reset; the
 *                                        next OFF is a normal one, and a CPU's
 *                                        next ON from FULL_RET a warm resume
 *   voted OFF, at its low-power mode     S4_LP
 *   voted OFF, static ON reached         S4_HYST: a power-off the reset cut
 *                                        short resumes after the hysteresis
 *   anything else (mid-transition, or    the votes for it are dropped, and it
 *   voted ON but not in ON)              is a FAULT (PD_E_BUSY): the power-off
 *                                        retries, and the next ON recovers it
 *
 * Without a kept block (a power-on, or a block found invalid), every vote is
 * OFF; a domain found in static ON is then given a wake vote of its owner
 * (scp_rpmi_dpwr_wake_vote), so it stays ON until the owner votes OFF rather
 * than being powered down unasked. On a cold boot every PPU is in OFF and the
 * table is all S4_LP, so adoption changes nothing. One console line per
 * domain, "scp: adopt DOMAIN_ID <d> ...".
 */
#ifndef POLICY_H
#define POLICY_H

#include <stdint.h>
#include <stdbool.h>
#include "pd.h"

/* One mtime tick per SCP clock, 100 MHz (as W4.1's policy had it). */
#define S4_TICKS_PER_MS   100000u
#define S4_ON_MAX_TICKS   (10u * S4_TICKS_PER_MS)
#define S4_MAX_RETRIES    8u

struct policy_cfg {
  uint32_t on_ticks;       /* ON: the whole power-up, <= S4_ON_MAX_TICKS     */
  uint32_t step_ticks;     /* OFF: each step's deadline                      */
  uint32_t hyst_ticks;     /* OFF vote to the first power-off request; also
                              the spacing of the power-off retries after a
                              fault                                          */
  uint32_t backoff_ticks;  /* after the first denial; doubled at each retry  */
  uint8_t  retry_cap;      /* retries after the first denial, then force     */
  uint8_t  recover_tries;  /* power-off retries after a fault (decision 9)   */
};
/* W4.1's placeholders, not measurements: 1 ms, 1 ms, 1 ms, 100 us, 3; and
   N = 3 (SOC4_DESIGN.md Section 15.2-19). */
extern const struct policy_cfg policy_cfg_default;

enum s4_state {
  S4_LP = 0,     /* voted OFF; static LP reached (or OFF since boot)         */
  S4_ON,         /* voted ON; static ON                                       */
  S4_HYST,       /* voted OFF, still static ON: the hysteresis window         */
  S4_PREP,       /* static ON requested, PWR_DEVACTIVEEN cleared              */
  S4_LPREQ,      /* static LP requested                                       */
  S4_BACKOFF,    /* denied; static ON, waiting to ask again                   */
  S4_FORCE,      /* DEVREQEN = 0, static LP requested                         */
  S4_FAULT,      /* a deadline expired, or a step failed                      */
};

struct s4_dom {
  uint8_t state;         /* enum s4_state                                     */
  uint8_t vote;          /* RPMI_DPWR_STATE_ON or _OFF, as last accepted      */
  uint8_t retries;       /* denials retried in the power-off under way        */
  uint8_t recover;       /* power-off retries left after a fault              */
  int8_t  err;           /* the error that caused the last S4_FAULT           */
  bool    up;            /* static ON reached since the last LP              */
  bool    faulted;       /* a fault since the last successful ON              */
  bool    recovering;    /* the power-off under way is a retry after a fault  */
  uint64_t at;           /* HYST, BACKOFF, FAULT with recover: when, mtime    */
  uint32_t wake_in;      /* level POWER_UP inputs holding a wake vote: re-armed
                            at the next OFF vote (WAKE INPUTS)                */
  uint32_t ons, offs, cancels, denials, forced, faults, gaveup, recoveries, waits;
  uint32_t wakes;        /* power-ups by a wake input                         */
};

extern struct s4_dom s4_dom[PD_COUNT];

struct policy_wake {
  uint32_t notify;       /* NOTIFY actions                                    */
  uint32_t reasons;      /* bit r: wake reason r recorded since boot          */
  uint32_t count;        /* REASON actions                                    */
  uint32_t ignored;      /* IGNORE actions                                    */
  uint8_t  last;         /* the last wake reason recorded                     */
};
extern struct policy_wake policy_wake;

void        policy_init(const struct policy_cfg *cfg);   /* NULL: defaults */
void        policy_adopt(bool kept);                     /* see ADOPTION   */
extern uint32_t policy_adopted;                          /* domains not S4_LP */
const struct policy_cfg *policy_get_cfg(void);

int         policy_vote(uint32_t id, uint32_t state);   /* dpwr_vote hook */
void        policy_work(void);                          /* loop hooks     */
uint64_t    policy_deadline(void);

enum ppu_mode policy_lp(unsigned id);                   /* pd_cfg[id].lp  */
const char *policy_state_name(unsigned s);

#endif
