# pmu/fw/mod: the power domain manager, the policy and the fault log

The SCP firmware's middle layer. `pd` knows what the PPU registers are for: one
domain per PPU, its settings from the platform's domain table, and
non-blocking requests with deadlines. `policy` turns the agents' DEVICE_POWER
votes and the wake inputs into `pd` requests. `flog` keeps a fault log and the
votes in RAM that survives a watchdog reset. Part of the shared SCP firmware;
see [`../README.md`](../README.md).

## Files

| File | What it is |
|---|---|
| `pd.h`, `pd.c` | The power domain manager: the domain table (`pd_cfg[]`), bring-up and takeover, the PPU interrupt path, non-blocking static requests, waits |
| `policy.h`, `policy.c` | The DEVICE_POWER policy for static-only PPUs: ON, OFF after hysteresis, deny/retry/force, fault recovery, wake inputs, clock/reset bridge faults, takeover after a watchdog reset. Uses `soc4/fw/mod/soc4_cpu.h` for the CPU cold boot, so it is soc4-specific. Linked into `soc4_scp` only |
| `flog.h`, `flog.c` | The fault log and the block kept across a watchdog reset (`struct scp_keep`, in `.persist` at `0xFC00`) |
| `agents.h` | The RPMI agents' indices from the platform's agent table: `SCP_AG_<id>`, `SCP_AG(id)` (its bit), `SCP_NUM_AGENTS` (1 to 8) |

## `pd`: the power domain manager

**The domain table.** The platform header writes one entry per domain, in
DOMAIN_ID order (= PPU index = `scp_irq` input of that PPU's `SCP_ACT_PPU`
entry):

```c
#define SCP_PLAT_DOMAINS(D)  D(name, latency, fields) ...
```

`name` is at most 15 characters (it is also the DEVICE_POWER name). `latency`
is DEVICE_POWER's `trans_latency`. `fields` are designated initializers of
`struct pd_cfg`:

| Field | Meaning |
|---|---|
| `.kind` | `PD_KIND_CPU` or `PD_KIND_DEV` |
| `.lp` | the `enum ppu_mode` that RPMI OFF takes the domain to (soc4: CPU0 `FULL_RET`, ACC0 `MEM_RET`, CPU1 and ACC1 `OFF`) |
| `.funrr`, `.fulrr`, `.memrr` | the retention RAM bytes; `pd_init` writes only the registers the PPU has |
| `.idr0`, `.idr1` | what the PPU must report in `PPU_IDR0` / `PPU_IDR1`; the boot checks it |
| `.cpu` | a CPU's cold-boot details (`struct pd_cpu`: image, load window, boot-address and fetch-enable registers), or NULL |
| `.agents` | bit `k` set: agent `k` may vote for the domain. The lowest such agent owns its wake vote |
| `.ckrst_lat` | the SoC clkgate / tilereset's worst-case acknowledgement latency, in PPU cycles; 0 keeps the build's delays |

**Functions.**

| Function | Does |
|---|---|
| `pd_init()` | Probe every PPU, clear its interrupt status, program `PPU_IMR`/`PPU_AIMR`, the retention RAM registers, the entry delay (16 cycles) and the device control delays, then unmask its `scp_irq` input. Returns how many PPUs answered. **Never writes `PPU_PWPR` or `PPU_PWCR`**: each domain stays in the mode it is in, recorded in `reset_pwpr` / `reset_mode` |
| `pd_adopt()` | The same after a watchdog reset, when the PPUs kept their state: a PPU whose settings already hold is not written (only its interrupt status is cleared); one that differs is programmed and counted in `pd_adopt_rewrites` |
| `pd_poll()` | The only reader of `PPU_ISR` / `PPU_AISR`: calls `scp_irq_collect()`, then for each PPU that fired reads and clears its status, counts each event in `pd_tab[d].ev`, calls `pd_on_ppu_irq()`, and unmasks the input |
| `pd_request_static(d, m, timeout)` | Start a change to static mode `m` (`PWR_DYN_EN = 0`, `LOCK_EN = 0`), with `PWR_DEVACTIVEEN` cleared first so a busy device is asked rather than waited for. Returns at once |
| `pd_advance(d)`, `pd_on_ppu_irq(d)`, `pd_tick()` | Move a request on: after a completion with no interrupt, after an interrupt, and on deadline expiry (`pd_tick()` returns the next deadline) |
| `pd_complete(d)` | Run one request to completion, asleep in WFI between looks. The policy's synchronous ON and the CPU loader use it |
| `pd_request_mode`, `pd_set_mode`, `pd_wait_mode`, `pd_wait_modes`, `pd_sleep` | Raw static control and blocking waits. The policy's ON uses `pd_wait_mode` to let a power-down end; test programs use the rest |
| `pd_dev_delays_of(d, out)`, `pd_dev_delays_ok(d)` | The delays `pd_init` programs for domain `d`, and whether they are in force |

**Rules.**

- **A request goes through phases:** `PD_PH_DYN` (wait for
  `PWR_DYN_STATUS` before the write), then `PD_PH_SETTLE` (wait for the mode).
  It ends in `PD_PH_IDLE` with `pd_tab[d].result` set, or in `PD_PH_FAULT`
  with `PD_E_TIMEOUT`. The PPU has no watchdog of its own (it waits for
  `PCSMPACCEPT` for ever), so the request's deadline is the only one.
- **One request per domain.** A new one replaces the old, starts from what the
  registers say, and does **not** stop a transition in flight: DEN 0051E
  §4.1.1, "Software writes to the Power Policy Register (PPU_PWPR) do not
  interrupt mode transitions". A caller that may replace a power-down waits
  for it to end first; `policy.c`'s ON does.
- **`scp_irq_init()` must run before `pd_init()`.**
- **Waits sleep with `mstatus.MIE` clear** (`pd_idle`): an interrupt that
  arrives between the check and the WFI stays pending, so the WFI returns at
  once. A wait never sleeps longer than `PD_POLL_TICKS` (512), so a completion
  with no interrupt is still seen.
- **Switch settling is the PPU's device control delays.** The power switches
  acknowledge nothing (`PGOOD_EN = 0`), so `ISO_CLKEN_DLY` = `PD_SWITCH_SETTLE`
  = 20 PPU cycles (200 ns at 100 MHz) and `CLKEN_RST_DLY` = 4. For a domain
  with a clock/reset bridge, `CLKEN_RST_DLY`, `CLKEN_ISO_DLY` and
  `RST_HWSTAT_DLY` are raised to `.ckrst_lat` where that is larger (soc4: 6 on
  ACC1).

Errors (`enum pd_err`): `PD_PENDING` 1, `PD_OK` 0, `PD_E_ABSENT` -10,
`PD_E_UNSUPPORTED` -12, `PD_E_REFUSED` -13, `PD_E_DENIED` -14,
`PD_E_TIMEOUT` -15, `PD_E_BUSY` -16, `PD_E_CLKRST` -17.

## `policy`: the DEVICE_POWER policy

Installed as three hooks after `pd_init()` and `scp_rpmi_init()`:
`scp_rpmi_hooks.dpwr_vote = policy_vote`, `scp_loop_hooks.work =
policy_work`, `scp_loop_hooks.deadline = policy_deadline`. It sees one vote per
domain: the agents' votes combined by `../rpmi/scp_rpmi.c` (ON while any agent
votes ON), passed only when the combined vote changes. It holds no per-domain
setting of its own; the kind and the low-power mode come from `pd_cfg[]`.

| Event | What the policy does |
|---|---|
| ON (`policy_vote`, synchronous) | Cancel a hysteresis window if one is running (no PPU access). Otherwise let a power-off step in flight end, then power up: static ON for an accelerator (static ON, `WARM_RST`, ON after a fault); a warm resume or the cold reload for a CPU. Re-enables `DEVREQEN` after a forced power-down. Returns success once `PPU_PWSR` shows ON, else `RPMI_ERR_HW_FAULT` and the vote is not recorded. **An ON stalls the whole main loop** until it ends, bounded by `on_ticks` |
| OFF | Records the vote and returns at once. After `hyst_ticks`, from `policy_work()` without blocking: PREP (static ON, `PWR_DEVACTIVEEN` cleared), LPREQ (static low-power mode; a busy device may deny, then back off from `backoff_ticks`, doubling, up to `retry_cap` retries), FORCE (`DEVREQEN = 0`, then the static low-power mode with no device handshake) |
| FAULT | Logged (`FLOG_FAULT`). The vote stays OFF, so the policy itself retries the power-off up to `recover_tries` times, `hyst_ticks` apart, then gives up until the next ON |
| Wake input (`SCP_ACT_POWER_UP d`) | The same power-up as ON, from the main loop. On success it records ON as the vote of the domain's wake owner, so that owner's next OFF reaches the policy and ends the wake. A level input stays masked while its wake vote holds |
| `SCP_ACT_NOTIFY`, `_REASON`, `_IGNORE` | Counted in `policy_wake` (a reason is also recorded); a level input is re-armed once seen LOW |
| `SCP_ACT_CKRST` | For each domain whose bridge status byte is set: clear it (W1C), log `FLOG_CLKRST`, drop every vote for the domain, and FAULT it with `PD_E_CLKRST` |
| Watchdog takeover (`policy_adopt`) | Rebuild each domain's state from the kept votes and the PPUs, writing no PPU register. A domain whose state contradicts its votes is FAULTed (`PD_E_BUSY`) and recovered by the retries |

Defaults (`policy_cfg_default`, placeholders, not measurements): `on_ticks`,
`step_ticks` and `hyst_ticks` 1 ms (`S4_TICKS_PER_MS` = 100000 ticks),
`backoff_ticks` 100 µs, `retry_cap` 3, `recover_tries` 3. The states are
`enum s4_state` (`S4_LP`, `S4_ON`, `S4_HYST`, `S4_PREP`, `S4_LPREQ`,
`S4_BACKOFF`, `S4_FORCE`, `S4_FAULT`), kept per domain in `s4_dom[]`.

`PWR_DEVACTIVEEN` stays cleared in static ON after a power-up. That departs on
purpose from [`../../README.md`](../../README.md) §6 rule 5: it matters only at
the next static request, which PREP makes with it cleared anyway.

## `flog`: the fault log and the kept block

`struct scp_keep` sits at `0xFC00` (`link.ld` `.persist`). `crt0.S` neither
loads nor clears it, and a watchdog reset does not reload the RAM. It holds a
ring of `FLOG_N` = 32 entries (16 bytes each, at `0xFC00 + 16 + 16 * slot`),
the agents' DEVICE_POWER votes (one byte per agent per domain), and the
mailbox firewall's `DENY_CNT` per agent as last logged.

| Code | Domain field | Detail word |
|---|---|---|
| 1 `FLOG_FAULT` | DOMAIN_ID | `[7:0]` the `pd` error, `[8]` in a retry after a fault, `[9]` retries used up |
| 2 `FLOG_FORCED` | DOMAIN_ID | `[7:0]` the denials taken |
| 3 `FLOG_FW_DENY` | agent `k` | `[19:0]` the mailbox's `FW_LAST`, `[31:20]` how many denials (saturating at 4095) |
| 4 `FLOG_CLKRST` | DOMAIN_ID | `[7:0]` the bridge status byte |
| 5 `FLOG_WDOG` | `0xFF` | the watchdog's `CAUSE` as the rebooted firmware read it |

Rules: call `flog_boot(cause)` first at boot. It keeps the block only if the
reset was not a power-on (`CAUSE.POR` = 0) and the magic `0x504B4353`, the
size and both checksums hold; otherwise it starts an empty block with every
vote OFF. Every change to the votes or to `deny_seen` must end in
`flog_commit()`. `flog_add()` also prints the entry on the console, and
`flog_dump()` prints the ring. Agents cannot read the log over RPMI.

## Build and use

| Image | `pd.c` | `policy.c` | `flog.c` |
|---|---|---|---|
| `soc4_scp`, `soc4_scp_m6` | yes | yes | yes |
| `soc4_stress` | yes | no | no |
| `soc4_wdog` | no | no | yes |

`agents.h` is included wherever the domain table is compiled, because
`.agents` names agents even in images with no RPMI server.

## Extending

- **A domain:** one `D(...)` entry in the platform header's
  `SCP_PLAT_DOMAINS`, its PPU's `I(...)` entry and `SCP_NUM_PPU`. The policy
  and the RPMI server pick it up with no edit. The kept block grows by one
  byte per agent; it must stay within 1 KB (`_Static_assert` in `flog.h`).
- **An agent:** one `A(...)` entry and its bit in each domain's `.agents`;
  `SCP_NUM_AGENTS` must stay at 8 or below.
- **A domain kind or low-power mode the policy does not handle** (dynamic
  modes, lock): the policy assumes static-only PPUs with no lock. That is
  soc4's build, and the reason for the `S4_` prefix.

## References

- Arm PPU Architecture v1.1 (DEN 0051E): §3.4.1–3.4.2 (`DEVACTIVE` and
  transition start), §4.1.1 and Table 4-1 (policy programming, denial), §4.1.3
  (`DEVREQEN`), §4.1.5 and Table 4-5 (device control delays).
- [`../../README.md`](../../README.md) §5.2 and §6: the manager and the driver
  rules.
- [`docs/SOC4_DESIGN.md`](../../../../docs/SOC4_DESIGN.md) §9.4 (decisions 8 and 9: the policy) and
  §12.
- [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../../../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)
  §14.7 (F5 the domain table, F6 votes and permissions, F10 wake inputs, F11
  clock/reset bridges, F12 the fault log, H18 the watchdog).
- librpmi v1.0.0 `lib/rpmi_service_group_device_power.c:128-131`: librpmi calls
  `set_state` only when `get_state` differs, which is why the wake vote is
  recorded.
