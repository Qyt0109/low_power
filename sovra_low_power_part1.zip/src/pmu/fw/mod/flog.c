/* The fault log and the block kept across a watchdog reset. See flog.h. */
#include "flog.h"
#include "scp_wdog.h"
#include "timer.h"
#include "console.h"
#include "lib.h"

/* link.ld places .persist at a fixed address and crt0.S leaves it alone. */
struct scp_keep scp_keep __attribute__((section(".persist")));

const char *flog_code_name(unsigned code)
{
  switch (code) {
    case FLOG_FAULT:   return "FAULT";
    case FLOG_FORCED:  return "FORCED";
    case FLOG_FW_DENY: return "FW_DENY";
    case FLOG_CLKRST:  return "CLKRST";
    case FLOG_WDOG:    return "WDOG";
    default:           return "?";
  }
}

/* Words [from, to) of the block, folded with a rotate so that a zeroed block
   (what the testbench's RAM starts as) and an all-ones one never check. */
#define WORD(f) ((unsigned)(offsetof(struct scp_keep, f) / 4u))
static uint32_t fold(unsigned from, unsigned to)
{
  const uint32_t *w = (const uint32_t *)&scp_keep;
  uint32_t c = 0x5CA1AB1Eu;
  for (unsigned i = from; i < to; i++) c = ((c << 1) | (c >> 31)) ^ w[i] ^ i;
  return c;
}
static uint32_t log_sum(void)   { return fold(0, WORD(log_csum)); }
static uint32_t state_sum(void) { return fold(WORD(deny_seen), WORD(state_csum)); }

void flog_commit(void)
{
  scp_keep.state_csum = state_sum();
}

static void log_commit(void)
{
  scp_keep.log_csum = log_sum();
}

static bool valid(void)
{
  const struct scp_keep *k = &scp_keep;
  return k->magic == SCP_KEEP_MAGIC && k->size == sizeof *k && k->head < FLOG_N &&
         k->count <= FLOG_N && k->log_csum == log_sum() && k->state_csum == state_sum();
}

bool flog_boot(uint32_t cause)
{
  if (!(cause & SCP_WDOG_CAUSE_POR) && valid()) {
    if (cause & SCP_WDOG_CAUSE_WDOG) {
      scp_keep.wdog++;
      log_commit();
    }
    return true;
  }
  memset(&scp_keep, 0, sizeof scp_keep);
  scp_keep.magic = SCP_KEEP_MAGIC;
  scp_keep.size  = sizeof scp_keep;
  log_commit();
  flog_commit();
  return false;
}

static void print(const struct flog_entry *e)
{
  con_printf("scp: log #%u t=%08x:%08x %s dom %u detail 0x%08x\n", e->seq, e->t_hi, e->t_lo,
             flog_code_name(e->code), e->dom, e->detail);
}

void flog_add(unsigned code, unsigned dom, uint32_t detail)
{
  struct flog_entry *e = &scp_keep.e[scp_keep.head];
  const uint64_t t = timer_now();
  e->t_lo   = (uint32_t)t;
  e->t_hi   = (uint32_t)(t >> 32);
  e->code   = (uint8_t)code;
  e->dom    = (uint8_t)dom;
  e->seq    = (uint16_t)scp_keep.seq;
  e->detail = detail;
  scp_keep.seq++;
  scp_keep.head = (uint8_t)((scp_keep.head + 1u) % FLOG_N);
  if (scp_keep.count < FLOG_N) scp_keep.count++;
  log_commit();
  print(e);
}

void flog_dump(void)
{
  con_printf("scp: fault log: %u of %u entries, %u added, %u watchdog reset(s) survived\n",
             scp_keep.count, FLOG_N, scp_keep.seq, scp_keep.wdog);
  unsigned slot = (scp_keep.head + FLOG_N - scp_keep.count) % FLOG_N;
  for (unsigned i = 0; i < scp_keep.count; i++, slot = (slot + 1u) % FLOG_N)
    print(&scp_keep.e[slot]);
}
