`timescale 1ns/1ps
// Formal properties for scp_wdog (src/pmu/rtl/scp_wdog.sv), bound into every
// scp_wdog instance. Run: src/signoff/formal/scp_wdog.tcl (VC Formal FPV).
//
// Every rule is quoted from scp_wdog.sv's header (THE REGISTERS, TWO RESETS,
// WHY THE DRAIN). Two resets, as in the RTL:
//   por_ni  the power-on reset: create_reset in the TCL, so the tool applies it
//           for the reset state and holds it inactive afterwards;
//   rst_ni  the SCP subsystem's reset: asserted for the reset state, then a
//           FREE input -- it may fall and rise at any cycle, which is how the
//           "CAUSE survives rst_ni" rules are exercised.
// Properties on the rst_ni half are disabled while rst_ni is LOW; properties on
// the por_ni half only on por_ni. No assumptions: every input is free.

module scp_wdog_props #(
  parameter logic [31:0] KEY        = 32'h4B49_434B,
  parameter int unsigned RST_CYCLES = 16,
  parameter int unsigned DRAIN_MAX  = 1024
) (
  input logic        clk_i,
  input logic        por_ni,
  input logic        rst_ni,
  input logic        req_i,
  input logic        we_i,
  input logic [3:0]  be_i,
  input logic [31:0] addr_i,
  input logic [31:0] wdata_i,
  input logic        rvalid_o,
  input logic [31:0] rdata_o,
  input logic        err_o,
  input logic        axi_idle_i,
  input logic        hold_o,
  input logic        rst_req_o,
  // internal state = the documented register fields
  input logic        en_q,       // CTRL.EN
  input logic        lock_q,     // CTRL.LOCK
  input logic [31:0] tmo_q,      // TIMEOUT
  input logic [31:0] cnt_q,      // COUNT
  input logic [3:0]  cause_q,    // CAUSE[3:0]
  input logic [7:0]  resets_q    // CAUSE.RESETS
);

  default clocking cb @(posedge clk_i); endclocking

  // ---- Bus decode, from THE REGISTERS ----
  logic [11:0] off;
  logic [31:0] bm;
  assign off = {addr_i[11:2], 2'b00};
  assign bm  = {{8{be_i[3]}}, {8{be_i[2]}}, {8{be_i[1]}}, {8{be_i[0]}}};
  logic wr_ctrl, wr_tmo, kick_wr, kick_good, kick_bad, rd_cause;
  assign wr_ctrl   = req_i && we_i && off == 12'h000;
  assign wr_tmo    = req_i && we_i && off == 12'h004;
  assign kick_wr   = req_i && we_i && off == 12'h008;
  // "KICK: KEY (a full-word write) loads COUNT with TIMEOUT. Any other value or
  //  a partial write, while EN, is a fault"
  assign kick_good = kick_wr && be_i == 4'hF && wdata_i == KEY;
  assign kick_bad  = kick_wr && !(be_i == 4'hF && wdata_i == KEY);
  assign rd_cause  = req_i && !we_i && off == 12'h010;
  logic [3:0] w1c;                 // "CAUSE R/W1C: writing 1 clears a bit of [3:0]"
  assign w1c = (req_i && we_i && off == 12'h010 && be_i[0]) ? wdata_i[3:0] : 4'd0;
  logic en_wr_on;                  // "Enabling (EN 0 -> 1) loads COUNT, as a kick does"
  assign en_wr_on = wr_ctrl && be_i[0] && !lock_q && wdata_i[0] && !en_q;

  // The sequencer is idle exactly when hold_o is LOW (a_hold_iff_busy below
  // ties this to the drain/reset phases): a trigger is "EN and COUNT = 0, or a
  // KICK write != KEY while EN", taken while idle.
  logic idle, trig;
  assign idle = !hold_o;
  assign trig = idle && en_q && (cnt_q == '0 || kick_bad);
  logic draining;                  // DRAIN: hold_o = 1, reset not yet requested
  assign draining = hold_o && !rst_req_o;

  // ---- Independent model of the count: what was loaded, and when ----
  // COUNT must equal (TIMEOUT at the last load) - (cycles since), floored at 0.
  logic [31:0] ld;
  logic [32:0] age;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ld  <= '0;
      age <= '0;
    end else if ((en_q && kick_good) || en_wr_on) begin
      ld  <= tmo_q;
      age <= '0;
    end else if (age != '1) begin
      age <= age + 33'd1;
    end
  end
  logic due;                       // TIMEOUT cycles have passed since the last load
  assign due = age >= {1'b0, ld};

  // ===========================================================================
  // The count and the expiry ("EN: count, and expire at 0"; KICK)
  // ===========================================================================
  // COUNT: "loaded with TIMEOUT on enable and on a good kick, then down by one a
  // cycle" (helper invariant for the expiry properties too).
  a_cnt_track:   assert property (disable iff (!rst_ni)
                   en_q |-> cnt_q == (due ? 32'd0 : ld - age[31:0]));
  // A good kick restarts the count from TIMEOUT.
  a_kick_reload: assert property (disable iff (!rst_ni)
                   en_q && kick_good |=> cnt_q == $past(tmo_q));
  a_en_load:     assert property (disable iff (!rst_ni)
                   en_wr_on |=> en_q && cnt_q == $past(tmo_q));
  // "Clearing EN (unlocked) stops COUNT where it is."
  a_cnt_stopped: assert property (disable iff (!rst_ni)
                   !en_q && !en_wr_on |=> cnt_q == $past(cnt_q));
  // Expiry ONLY after TIMEOUT cycles without a good kick (or a bad kick).
  a_no_early_expiry: assert property (disable iff (!por_ni)
                   idle && !(en_q && kick_bad) && !(en_q && due) |=> !hold_o);
  // ...and exactly then: TIMEOUT cycles after the last load, the trigger fires.
  a_expiry_at_timeout: assert property (disable iff (!por_ni)
                   idle && en_q && due |=> hold_o && cause_q[1]);
  // "While EN = 0, writes [to KICK] do nothing."
  a_kick_off_noop: assert property (disable iff (!por_ni)
                   idle && !en_q |=> !hold_o);
  // "Any other value or a partial write, while EN, is a fault: an immediate
  // reset, CAUSE.BADKICK."
  a_badkick_resets: assert property (disable iff (!por_ni)
                   idle && en_q && kick_bad |=> hold_o && cause_q[1] && cause_q[2]);

  // ===========================================================================
  // The sequencer: DRAIN then RESET (the diagram, WHY THE DRAIN)
  // ===========================================================================
  a_rst_implies_hold: assert property (disable iff (!por_ni) rst_req_o |-> hold_o);
  a_trig_holds:   assert property (disable iff (!por_ni) $rose(hold_o) |-> !rst_req_o && cause_q[1]);
  // "until axi_idle_i or DRAIN_MAX cycles"
  a_drain_idle:   assert property (disable iff (!por_ni) draining && axi_idle_i |=> rst_req_o);
  a_drain_max:    assert property (disable iff (!por_ni) $rose(hold_o) |-> ##[1:DRAIN_MAX] rst_req_o);
  a_drainto_cause: assert property (disable iff (!por_ni)
                   ($rose(hold_o) ##0 (!axi_idle_i) [*DRAIN_MAX]) |=> rst_req_o && cause_q[3]);
  a_drainto_only: assert property (disable iff (!por_ni)
                   !cause_q[3] && !(draining && !axi_idle_i) |=> !cause_q[3]);
  // "RESET: rst_req_o = 1 for RST_CYCLES cycles"
  a_rst_len:      assert property (disable iff (!por_ni)
                   $rose(rst_req_o) |-> rst_req_o [*RST_CYCLES] ##1 !rst_req_o && !hold_o);
  // No second trigger while the sequencer is busy (hold_o is not released
  // before the reset has been requested).
  a_hold_until_rst: assert property (disable iff (!por_ni) draining |=> hold_o);

  // ===========================================================================
  // LOCK: "write 1 to set; cleared only by a reset. While LOCK is 1, writes to
  // CTRL and TIMEOUT are ignored, so EN cannot be cleared"
  // ===========================================================================
  a_lock_sticky:  assert property (disable iff (!rst_ni) lock_q |=> lock_q);
  a_lock_en_held: assert property (disable iff (!rst_ni) lock_q && en_q |=> en_q);
  a_lock_en_off:  assert property (disable iff (!rst_ni) lock_q && !en_q |=> !en_q);
  a_lock_tmo:     assert property (disable iff (!rst_ni) lock_q |=> tmo_q == $past(tmo_q));
  a_lock_set:     assert property (disable iff (!rst_ni)
                   !lock_q && wr_ctrl && be_i[0] && wdata_i[1] |=> lock_q);
  a_lock_only_by_write: assert property (disable iff (!rst_ni)
                   !lock_q && !(wr_ctrl && be_i[0] && wdata_i[1]) |=> !lock_q);
  a_en_write:     assert property (disable iff (!rst_ni)
                   !lock_q && wr_ctrl && be_i[0] |=> en_q == $past(wdata_i[0]));
  a_tmo_write:    assert property (disable iff (!rst_ni)
                   !lock_q && wr_tmo |=> tmo_q == $past((tmo_q & ~bm) | (wdata_i & bm)));
  // TWO RESETS: "rst_ni ... clears CTRL, TIMEOUT and COUNT"
  a_rst_clears:   assert property (disable iff (!por_ni)
                   !rst_ni |-> !en_q && !lock_q && tmo_q == '1 && cnt_q == '0);

  // ===========================================================================
  // CAUSE (por_ni): "clears what must outlive a watchdog reset: CAUSE, the
  // reset count and the reset sequencer"
  // ===========================================================================
  // No CAUSE bit is lost without a W1C -- whatever rst_ni does.
  a_cause_survives: assert property (disable iff (!por_ni)
                   w1c == '0 |=> (cause_q & $past(cause_q)) == $past(cause_q));
  a_resets_survive: assert property (disable iff (!por_ni)
                   1'b1 |=> resets_q == $past(resets_q) || resets_q == $past(resets_q) + 8'd1);
  // "RESETS (RO): watchdog resets since power-on, saturating at 255"
  a_resets_inc:   assert property (disable iff (!por_ni)
                   trig && resets_q != 8'hFF |=> resets_q == $past(resets_q) + 8'd1);
  a_resets_hold:  assert property (disable iff (!por_ni) !trig |=> resets_q == $past(resets_q));
  a_resets_sat:   assert property (disable iff (!por_ni) resets_q == 8'hFF |=> resets_q == 8'hFF);
  // "Writing 1 clears a bit of [3:0]; a trigger in the same cycle wins"
  a_cause_w1c_por:  assert property (disable iff (!por_ni) w1c[0] |=> !cause_q[0]);
  a_cause_w1c_wdog: assert property (disable iff (!por_ni) w1c[1] && !trig |=> !cause_q[1]);
  a_cause_w1c_bad:  assert property (disable iff (!por_ni) w1c[2] && !(trig && kick_bad) |=> !cause_q[2]);
  a_cause_w1c_dto:  assert property (disable iff (!por_ni) w1c[3] && !(draining && !axi_idle_i) |=> !cause_q[3]);
  a_cause_set_wins: assert property (disable iff (!por_ni) trig && w1c[1] |=> cause_q[1]);
  // POR is set only by the power-on reset; WDOG and BADKICK only by a trigger.
  a_cause_por_only: assert property (disable iff (!por_ni) !cause_q[0] |=> !cause_q[0]);
  a_cause_wdog_only: assert property (disable iff (!por_ni) !cause_q[1] && !trig |=> !cause_q[1]);
  a_cause_bad_only: assert property (disable iff (!por_ni) !cause_q[2] && !(trig && kick_bad) |=> !cause_q[2]);
  // CAUSE reads back as documented (the read port is on rst_ni).
  a_rd_cause:     assert property (disable iff (!rst_ni)
                   rd_cause |=> rdata_o == {16'd0, $past(resets_q), 4'd0, $past(cause_q)});

  // ===========================================================================
  // Covers: every key behaviour is reachable
  // ===========================================================================
  c_expire:        cover property (disable iff (!por_ni) idle && en_q && !kick_bad && cnt_q == '0 ##1 hold_o);
  c_expire_kicked: cover property (disable iff (!rst_ni)
                     en_q && kick_good && tmo_q == 32'd3 ##1 !kick_good [*4] ##1 hold_o);
  c_kick_restart:  cover property (disable iff (!rst_ni) en_q && kick_good && cnt_q != '0 && cnt_q < tmo_q);
  c_badkick:       cover property (disable iff (!por_ni) idle && en_q && kick_bad && cnt_q != '0 ##1 hold_o && cause_q[2]);
  c_lock_en_held:  cover property (disable iff (!rst_ni) lock_q && en_q && wr_ctrl && be_i[0] && !wdata_i[0] ##1 en_q);
  c_lock_tmo:      cover property (disable iff (!rst_ni) lock_q && wr_tmo && be_i == 4'hF && wdata_i != tmo_q);
  c_cause_survives_rst: cover property (disable iff (!por_ni) cause_q[1] && !rst_ni);
  c_drainto:       cover property (disable iff (!por_ni) !cause_q[3] ##1 cause_q[3]);
  c_drain_idle:    cover property (disable iff (!por_ni) $rose(hold_o) ##1 draining && axi_idle_i ##1 rst_req_o);
  c_trig_and_clear: cover property (disable iff (!por_ni) trig && w1c[1] && cause_q[1]);
  c_full_sequence: cover property (disable iff (!por_ni) $rose(hold_o) ##[1:$] $fell(rst_req_o));
  c_second_reset:  cover property (disable iff (!por_ni) resets_q == 8'd2);

endmodule

bind scp_wdog scp_wdog_props #(.KEY(KEY), .RST_CYCLES(RST_CYCLES), .DRAIN_MAX(DRAIN_MAX)) u_scp_wdog_props (.*);
