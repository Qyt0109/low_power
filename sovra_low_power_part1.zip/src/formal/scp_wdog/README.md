# scp_wdog formal properties

Properties for [`src/pmu/rtl/scp_wdog.sv`](../../pmu/rtl/scp_wdog.sv), the
SCP watchdog: a down-counter loaded with TIMEOUT on enable and on a good kick,
expiry (or a wrong kick) starting a sequence that drains the SCP's AXI4-Lite
manager and then resets the SCP subsystem for RST_CYCLES, with CAUSE and the
reset count kept across that reset. Every rule is quoted from the RTL header
(THE REGISTERS, TWO RESETS, WHY THE DRAIN).

## Files

| File | Contents |
|---|---|
| `scp_wdog_props.sv` | `scp_wdog_props` and `bind scp_wdog scp_wdog_props u_scp_wdog_props (.*)`: the bus decode (good/bad kick, W1C, enable), an independent model of the count (the value loaded and the cycles since: `ld`, `age`, `due`), and the properties below. It reads the documented fields `en_q`, `lock_q`, `tmo_q`, `cnt_q`, `cause_q`, `resets_q` |
| `src/signoff/formal/scp_wdog.tcl` | Top `scp_wdog`, `DRAIN_MAX = 8` (default 1024, reduced so the DRAIN_MAX-cycle sequences stay shallow); `KEY` and `RST_CYCLES = 16` are the defaults |

Two resets, as in the RTL: `por_ni` (power-on) is the tool's reset, applied
for the reset state and then held inactive; `rst_ni` (the SCP subsystem) is
asserted for the reset state and then released as a free input, so it may
fall at any cycle. Properties on the `rst_ni` half are disabled while `rst_ni`
is LOW; properties on the `por_ni` half only by `por_ni`. No assumptions.

## Properties

| Intent | Properties |
|---|---|
| The count | `a_cnt_track` (COUNT = TIMEOUT at the last load minus the cycles since, floored at 0), `a_kick_reload`, `a_en_load` (enabling loads TIMEOUT), `a_cnt_stopped` (EN 0 stops COUNT) |
| Expiry exactly at TIMEOUT | `a_no_early_expiry` (no trigger before TIMEOUT cycles without a good kick, or a bad kick), `a_expiry_at_timeout` (then the sequencer starts, CAUSE.WDOG set), `a_kick_off_noop` (EN 0: kicks do nothing) |
| A wrong kick resets at once | `a_badkick_resets` (any other value or a partial write while EN: immediate trigger, CAUSE.WDOG and BADKICK) |
| Drain, then reset | `a_rst_implies_hold`, `a_trig_holds`, `a_drain_idle` (reset requested once the AXI manager is idle), `a_drain_max` (or within DRAIN_MAX cycles), `a_drainto_cause` / `a_drainto_only` (CAUSE.DRAINTO exactly when the drain timed out), `a_rst_len` (`rst_req_o` for RST_CYCLES, then released), `a_hold_until_rst` |
| LOCK | `a_lock_sticky`, `a_lock_en_held`, `a_lock_en_off` (EN cannot change while locked), `a_lock_tmo` (TIMEOUT frozen), `a_lock_set`, `a_lock_only_by_write`, `a_en_write`, `a_tmo_write` (byte enables) |
| `rst_ni` clears CTRL, TIMEOUT and COUNT | `a_rst_clears` |
| CAUSE survives `rst_ni` | `a_cause_survives` (no CAUSE bit lost without a W1C, whatever `rst_ni` does), `a_resets_survive`, `a_resets_inc`, `a_resets_hold`, `a_resets_sat` (RESETS counts triggers, saturates at 255) |
| CAUSE W1C and its set rules | `a_cause_w1c_por`, `a_cause_w1c_wdog`, `a_cause_w1c_bad`, `a_cause_w1c_dto`, `a_cause_set_wins` (a trigger in the cycle of the clear wins), `a_cause_por_only`, `a_cause_wdog_only`, `a_cause_bad_only` |
| Read-back | `a_rd_cause` (`{RESETS, CAUSE[3:0]}`) |

Covers (12): an expiry, an expiry after a kick with TIMEOUT 3, a kick
restarting the count, a bad kick, LOCK holding EN and TIMEOUT against writes,
CAUSE surviving `rst_ni`, a drain timeout, a drain ending on idle, a trigger
with a clear, the full sequence, a second watchdog reset.

## Status

39 of 39 assertions proven, 12 of 12 covers covered, none bounded (latest
run, `build/signoff/formal/scp_wdog/`). The AXI drain proofs (`a_drain_idle`,
`a_drain_max`) are what the VC RDC waiver RDC-W1 rests on.

## Mutant

`SOC4_MUT_WDOG_CAUSE_SUB` (`pmu/rtl/scp_wdog.sv`): CAUSE on the SCP
subsystem's reset, so the watchdog's own reset clears it. It falsifies 12
assertions: `a_cause_survives`, `a_cause_por_only`, `a_cause_set_wins`,
`a_cause_w1c_por`, `a_drainto_cause`, `a_expiry_at_timeout`,
`a_badkick_resets`, `a_trig_holds`, and the four `a_resets_*`. The same define
is soc4neg's M8 (`[chk:WDOG_CAUSE]` in simulation).

## Finding

F-WDOG-1 (open, SIGNOFF_REPORT.md Section 6): a wrong kick during DRAIN or
RESET is not recorded in BADKICK.

## Running

`make -C src vcformal` / `vcformalneg`, with
`VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`. By hand:
`PMU_SRC=<repo>/src [FV_DEFINES=+define+SOC4_MUT_WDOG_CAUSE_SUB]
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/scp_wdog.tcl`.

## Adding a property

Choose its reset domain first: `disable iff (!rst_ni)` for CTRL, TIMEOUT,
COUNT and the read port; `disable iff (!por_ni)` for CAUSE, RESETS and the
sequencer. Use the count model (`due`, `ld`, `age`) for timing rather than the
RTL counter.

## References

- `src/pmu/rtl/scp_wdog.sv` header; `src/pmu/fw/hal/scp_wdog.h`.
- [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md) Sections
  4 (RDC-W1) and 6.
- Simulation: `make soc4wdog` and W1 of [`soc4_tb`](../../tb/soc4/README.md).
