# hart_ready_adp formal properties

Properties for [`src/rtl/adp/hart_ready_adp.sv`](../../rtl/adp/hart_ready_adp.sv),
the READY-bit Q-Channel adapter: a hart's software sets READY, and the adapter
lets the PPU's power-down request be accepted only while READY is set, no wake
is pending and every TileLink port of the hart is drained. The rules are the
RTL header's (READY[h], idle[p], THE DECISION, OUTSTANDING TRANSACTIONS) and,
on the Q-Channel, AMBA LPI (ARM IHI 0068C) Section 2.1.2 and Table 2-1.

## Files

| File | Contents |
|---|---|
| `hart_ready_adp_props.sv` | Three parts. `hart_ready_adp_props`, bound into `hart_ready_adp`: a reference model of each port (beats left in the A, C, D message in progress; requests owed, Grants unacknowledged, Probes unanswered; wide counters, no wrap), READY's clear term, and the properties. `hart_ready_adp_fv`, the formal top: the adapter and one `qchannel_device` (SYNC_STAGES 2, `dev_wake` 0) per hart, fed by `dev_busy_o`/`dev_deny_o` as inside `ppu_axi_dom_top`, with its own Q-Channel properties |
| `src/signoff/formal/hart_ready_adp.tcl` | Top `hart_ready_adp_fv`; the unit test's configuration: `NUM_HARTS = 2`, `NUM_PORTS = 3` (port 0 hart 0 TL-C, port 1 hart 0 TL-UH, port 2 hart 1 TL-UH), `SZW = 4`, `LOG2_BYTES = 3`, `CNT_W = 6` |

## Assumptions (inputs only)

| Assumption | Rule |
|---|---|
| `asm_d_answers` | A D message answers a request already made (TileLink) |
| `asm_e_acks`, `asm_pack_ans` (TL-C ports) | An E beat acknowledges a Grant received; a ProbeAck answers a Probe received |
| `asm_owed_max`, `asm_grant_max`, `asm_probe_max` | The documented limit: at most 2^CNT_W - 1 outstanding per port |
| `asm_a_size`, `asm_d_size`, `asm_c_size` | A message is at most 4 KiB (size ≤ 12, TileLink maxTransfer) |
| `asm_qreqn_fall`, `asm_qreqn_rise` (formal top) | The PPU obeys LPI 2.1.2's rules for QREQn |

## Properties

| Intent | Properties |
|---|---|
| The drain tracking is exact | per port: `a_idle_ref` (`port_idle_o` equals "nothing in flight" by the model), `a_owed_not_idle`, `a_burst_not_idle` |
| READY | per hart: `a_clr_wins` (any clear term — wake, rising `dom_on`, hart reset, software, SCP — leaves READY clear, a set in the same cycle notwithstanding), `a_set`, `a_hold`, `a_rst_clears` |
| The decision | per hart: `a_decision` (accept exactly when READY, no wake and drained), `a_accept_needs_ready`, `a_accept_needs_drain`, `a_wake_denies` (combinational: a wake in the request's cycle denies), `a_busy_zero` (the adapter never makes the PPU wait) |
| LPI on the Q-Channel the decision produces | per hart (formal top): `a_q_no_illegal` (Table 2-1), `a_q_accept_fall`, `a_q_accept_rise`, `a_q_deny_fall`, `a_q_deny_rise` (2.1.2 handshake rules), `a_q_accept_holds`, `a_q_deny_holds` (held until QREQn rises) |
| The decision, seen on the pins | `a_q_accept_only_ready_drained`, `a_q_deny_only_denied` |
| Helper invariants | per port: `h_a_left`, `h_d_left`, `h_owed`, `h_grant`, `h_probe`, and `h_c_left` (TL-C) or `h_c_none` (TL-UH): the RTL's counters (`tl_beat_cnt` `left_q`, the narrow owed/grant/probe) equal the model's |

Covers (27): per port an idle port after a 4-beat burst and two requests
owed, on the TL-C port a Grant pending, a Probe pending, a Release owed; per
hart an accept, a clear and a set together, a denial for in-flight traffic, a
denial for a wake, `dom_on` clearing READY; on each Q-Channel an accept, a
deny, an accept then exit, a deny then continue.

## Status

63 of 63 assertions proven, 27 of 27 covers covered, none bounded (latest run,
`build/signoff/formal/hart_ready_adp/`).

## Mutants

| Define | Fault | Falsified |
|---|---|---|
| `HART_READY_MUT_NODRAIN` | the ports' outstanding transactions not looked at | 6: per hart `a_decision`, `a_accept_needs_drain`, `a_q_accept_only_ready_drained` |
| `HART_READY_MUT_SETWINS` | a set wins over a clear | 4: per hart `a_clr_wins`, `a_rst_clears` |

Both are also the `make readyadp` negative controls.

## Findings (open, SIGNOFF_REPORT.md Section 6)

- F-ADP-1: on an 8-byte link, a size ≥ 13 is counted as one beat (the beat
  counter's limit; not reached by SOVRA's 64-byte transfers, but undocumented).
- F-ADP-2: a D Grant opcode on a TL-UH port increments `grant_q`, which nothing
  decrements (illegal TileLink, but the port would stay busy for ever).
- F-ADP-3: on a TL-C port, a Probe offered on B but not yet taken does not make
  the port busy (only fired B beats are counted), so the core could be powered
  off with a Probe pending.

## Running

`make -C src vcformal` / `vcformalneg`, with
`VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`. By hand:
`PMU_SRC=<repo>/src [FV_DEFINES=+define+HART_READY_MUT_NODRAIN]
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/hart_ready_adp.tcl`.

## Adding a property

Port-level properties go in the `g_p` generate of `hart_ready_adp_props`,
hart-level ones in `g_h`, Q-Channel ones in `g_lpi` of the formal top. A new
TileLink constraint is an `asm_` assumption on the observed port, with its
rule cited.

## References

- `src/rtl/adp/hart_ready_adp.sv` header; [`src/rtl/adp/README.md`](../../rtl/adp/README.md);
  `src/rtl/tluh/tluh_pkg.sv` (the burst rule, `beats()`).
- AMBA LPI, ARM IHI 0068C, Section 2.1.2 and Table 2-1.
- [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md) Section 6.
- Simulation: [`src/tb/adp/`](../../tb/adp/README.md).
