`timescale 1ns/1ps
// Formal properties for hart_ready_adp (src/rtl/adp/hart_ready_adp.sv).
// Run: src/signoff/formal/hart_ready_adp.tcl (VC Formal FPV).
//
// Two modules and a bind:
//   hart_ready_adp_props  bound into hart_ready_adp: READY (set / clears /
//                         clear wins), the drain tracking against a reference
//                         model of each port, and the decision (accept only
//                         with READY set, no wake and every port drained).
//   hart_ready_adp_fv     the formal top: one hart_ready_adp and, per hart, a
//                         qchannel_device fed by dev_busy_o / dev_deny_o -- the
//                         adapter's consumer inside ppu_axi_dom_top (as in
//                         src/tb/adp/hart_ready_adp_tb.sv) -- so the Q-Channel
//                         outputs QACCEPTn / QDENY the adapter's decision
//                         produces are checked against AMBA LPI (ARM IHI 0068C,
//                         build/spec_txt/arm-amba-low-power-interface-spec.txt)
//                         Section 2.1.2, Table 2-1 and "Handshake rules".
//
// The rules for the adapter are hart_ready_adp.sv's own header ("READY[h]",
// "idle[p]", "THE DECISION", "OUTSTANDING TRANSACTIONS"). READY's set and
// clear inputs (hart_ready_regs' sw_set/sw_clr, scp_clr, wake, dom_on,
// hart_rst_n) are free inputs.

module hart_ready_adp_props
  import tl_pkg::*;
  import tluh_pkg::*;
#(
  parameter int unsigned NUM_HARTS = 1,
  parameter int unsigned NUM_PORTS = 1,
  parameter logic [NUM_PORTS-1:0][7:0] PORT_HART = '0,
  parameter logic [NUM_PORTS-1:0]      PORT_TLC  = '0,
  parameter int unsigned SZW       = 4,
  parameter int unsigned LOG2_BYTES = 3,
  parameter int unsigned CNT_W     = 6
) (
  input logic                           clk_i,
  input logic                           rst_ni,
  input logic [NUM_HARTS-1:0]           sw_set_i,
  input logic [NUM_HARTS-1:0]           sw_clr_i,
  input logic [NUM_HARTS-1:0]           scp_clr_i,
  input logic [NUM_HARTS-1:0]           wake_i,
  input logic [NUM_HARTS-1:0]           dom_on_i,
  input logic [NUM_HARTS-1:0]           hart_rst_ni,
  input logic [NUM_HARTS-1:0]           ready_o,
  input logic [NUM_PORTS-1:0]           a_valid_i,
  input logic [NUM_PORTS-1:0]           a_ready_i,
  input logic [NUM_PORTS-1:0][2:0]      a_opcode_i,
  input logic [NUM_PORTS-1:0][SZW-1:0]  a_size_i,
  input logic [NUM_PORTS-1:0]           d_valid_i,
  input logic [NUM_PORTS-1:0]           d_ready_i,
  input logic [NUM_PORTS-1:0][2:0]      d_opcode_i,
  input logic [NUM_PORTS-1:0][SZW-1:0]  d_size_i,
  input logic [NUM_PORTS-1:0]           b_valid_i,
  input logic [NUM_PORTS-1:0]           b_ready_i,
  input logic [NUM_PORTS-1:0]           c_valid_i,
  input logic [NUM_PORTS-1:0]           c_ready_i,
  input logic [NUM_PORTS-1:0][2:0]      c_opcode_i,
  input logic [NUM_PORTS-1:0][SZW-1:0]  c_size_i,
  input logic [NUM_PORTS-1:0]           e_valid_i,
  input logic [NUM_PORTS-1:0]           e_ready_i,
  input logic [NUM_PORTS-1:0]           port_idle_o,
  input logic [NUM_HARTS-1:0]           dev_busy_o,
  input logic [NUM_HARTS-1:0]           dev_deny_o
);

  default clocking cb @(posedge clk_i); endclocking
  default disable iff (!rst_ni);

  localparam int unsigned MAXO = (1 << CNT_W) - 1;   // "at most 2^CNT_W - 1" outstanding

  // ===========================================================================
  // Reference model of each port: beats left in the message in progress on A,
  // C and D, and the messages owed (wide counters, no wrap). "idle[p]: no
  // request on its A (or C) wires this cycle, no message part-way through its
  // beats on any channel, and no response owed".
  // ===========================================================================
  logic [NUM_PORTS-1:0] ref_idle;

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_p
    logic a_fire, d_fire, c_fire, b_fire, e_fire;
    assign a_fire = a_valid_i[p] && a_ready_i[p];
    assign d_fire = d_valid_i[p] && d_ready_i[p];
    assign c_fire = PORT_TLC[p] && c_valid_i[p] && c_ready_i[p];
    assign b_fire = PORT_TLC[p] && b_valid_i[p] && b_ready_i[p];
    assign e_fire = PORT_TLC[p] && e_valid_i[p] && e_ready_i[p];

    // Message length (tluh_pkg::beats, the TileLink burst rule) of the beat on the wires.
    logic [15:0] a_n, d_n, c_n;
    assign a_n = 16'(beats(int'(a_size_i[p]), a_has_data(a_opcode_i[p]), LOG2_BYTES));
    assign d_n = 16'(beats(int'(d_size_i[p]), d_has_data(d_opcode_i[p]), LOG2_BYTES));
    assign c_n = 16'(beats(int'(c_size_i[p]), c_has_data(c_opcode_i[p]), LOG2_BYTES));

    logic [15:0] a_rem, d_rem, c_rem;   // beats still to come in the message in progress
    logic a_start, a_end, d_start, d_end, c_start, c_end;
    assign a_start = a_fire && a_rem == '0;
    assign a_end   = a_fire && (a_rem == '0 ? a_n <= 16'd1 : a_rem == 16'd1);
    assign d_start = d_fire && d_rem == '0;
    assign d_end   = d_fire && (d_rem == '0 ? d_n <= 16'd1 : d_rem == 16'd1);
    assign c_start = c_fire && c_rem == '0;
    assign c_end   = c_fire && (c_rem == '0 ? c_n <= 16'd1 : c_rem == 16'd1);

    logic c_rel, c_pack, d_grant;
    assign c_rel   = c_opcode_i[p] == TL_C_RELEASE   || c_opcode_i[p] == TL_C_RELEASE_DATA;
    assign c_pack  = c_opcode_i[p] == TL_C_PROBE_ACK || c_opcode_i[p] == TL_C_PROBE_ACKDATA;
    assign d_grant = d_opcode_i[p] == TL_D_GRANT     || d_opcode_i[p] == TL_D_GRANT_DATA;

    // owed: requests (A messages, C Releases) not yet answered on D;
    // grant: Grants not yet acknowledged on E; probe: Probes not yet answered.
    logic [9:0] owed, grant, probe, owed_in, grant_in, probe_in, owed_n, grant_n, probe_n;
    assign owed_in  = owed  + 10'(a_start) + 10'(c_start && c_rel);
    assign grant_in = grant + 10'(d_end && d_grant);
    assign probe_in = probe + 10'(b_fire);
    assign owed_n   = owed_in  - 10'(d_end);
    assign grant_n  = grant_in - 10'(e_fire);
    assign probe_n  = probe_in - 10'(c_end && c_pack);

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        a_rem <= '0; d_rem <= '0; c_rem <= '0;
        owed  <= '0; grant <= '0; probe <= '0;
      end else begin
        if (a_fire) a_rem <= (a_rem == '0) ? ((a_n > 16'd1) ? a_n - 16'd1 : '0) : a_rem - 16'd1;
        if (d_fire) d_rem <= (d_rem == '0) ? ((d_n > 16'd1) ? d_n - 16'd1 : '0) : d_rem - 16'd1;
        if (c_fire) c_rem <= (c_rem == '0) ? ((c_n > 16'd1) ? c_n - 16'd1 : '0) : c_rem - 16'd1;
        owed  <= owed_n;
        grant <= grant_n;
        probe <= probe_n;
      end
    end

    assign ref_idle[p] = owed == '0 && grant == '0 && probe == '0 &&
                         a_rem == '0 && d_rem == '0 && c_rem == '0 &&
                         !a_valid_i[p] && !(PORT_TLC[p] && c_valid_i[p]);

    // ---- Environment: the TileLink protocol on the observed port ----
    // TileLink: every D message answers one request already made (a response
    // in the same cycle as its request's first beat is allowed here).
    asm_d_answers:  assume property (d_end |-> owed_in != '0);
    // TL-C: an E beat acknowledges a Grant already received; a ProbeAck
    // answers a Probe already received.
    if (PORT_TLC[p]) begin : g_tlc_asm
      asm_e_acks:   assume property (e_fire |-> grant_in != '0);
      asm_pack_ans: assume property (c_end && c_pack |-> probe_in != '0);
    end
    // The adapter's documented limit: "outstanding messages per port, at most
    // 2^CNT_W - 1" (CNT_W).
    asm_owed_max:   assume property (owed_in  <= 10'(MAXO));
    asm_grant_max:  assume property (grant_in <= 10'(MAXO));
    asm_probe_max:  assume property (probe_in <= 10'(MAXO));
    // TileLink maxTransfer: a message is at most 4 KiB (2^12 bytes; SOVRA's
    // links carry at most a 64-byte cache block). The adapter's beat counter
    // (BC_W = 10) holds up to 1023 beats, i.e. sizes <= LOG2_BYTES + 9.
    asm_a_size:     assume property (a_valid_i[p] |-> a_size_i[p] <= SZW'(12));
    asm_d_size:     assume property (d_valid_i[p] |-> d_size_i[p] <= SZW'(12));
    asm_c_size:     assume property (c_valid_i[p] |-> c_size_i[p] <= SZW'(12));

    // ---- Helper invariants (lemmas for the induction; they relate the RTL's
    // counters -- tl_beat_cnt's left_q, the narrow owed/grant/probe -- to the
    // model's wide ones, so a_idle_ref is provable at any depth) ----
    h_a_left:  assert property (g_port[p].u_a.left_q == 10'(a_rem) && a_rem < 16'd1024);
    h_d_left:  assert property (g_port[p].u_d.left_q == 10'(d_rem) && d_rem < 16'd1024);
    h_owed:    assert property (g_port[p].owed_q  == CNT_W'(owed)  && owed  <= 10'(MAXO));
    h_grant:   assert property (g_port[p].grant_q == CNT_W'(grant) && grant <= 10'(MAXO));
    h_probe:   assert property (g_port[p].probe_q == CNT_W'(probe) && probe <= 10'(MAXO));
    if (PORT_TLC[p]) begin : g_tlc_h
      h_c_left: assert property (g_port[p].g_tlc.u_c.left_q == 10'(c_rem) && c_rem < 16'd1024);
    end else begin : g_tluh_h
      h_c_none: assert property (c_rem == '0 && probe == '0);
    end

    // ---- The drain tracking ----
    // port_idle_o is exactly "nothing in flight" by the reference model.
    a_idle_ref:       assert property (port_idle_o[p] == ref_idle[p]);
    a_owed_not_idle:  assert property (owed != '0 |-> !port_idle_o[p]);
    a_burst_not_idle: assert property ((a_rem | d_rem | c_rem) != '0 |-> !port_idle_o[p]);

    c_idle_after_burst: cover property (a_start && a_n == 16'd4 ##1 !port_idle_o[p] [*3] ##[1:$] port_idle_o[p]);
    c_owed_two:         cover property (owed == 10'd2);
    if (PORT_TLC[p]) begin : g_tlc_cov
      c_grant_pending: cover property (grant != '0 && owed == '0 && a_rem == '0 && d_rem == '0 &&
                                       !a_valid_i[p] && !port_idle_o[p]);
      c_probe_pending: cover property (probe != '0 && !port_idle_o[p]);
      c_release_owed:  cover property (c_start && c_rel ##1 owed != '0);
    end
  end

  // ===========================================================================
  // READY, per hart: "Cleared by hardware on any enabled wake (wake_i, a
  // level); the rising edge of dom_on_i; hart_rst_ni LOW; software (sw_clr_i)
  // and the SCP (scp_clr_i). A clear and a set in the same cycle: the clear
  // wins."
  // ===========================================================================
  logic [NUM_HARTS-1:0] on_p, clr;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) on_p <= '0;
    else         on_p <= dom_on_i;
  end
  assign clr = wake_i | (dom_on_i & ~on_p) | ~hart_rst_ni | sw_clr_i | scp_clr_i;

  // Per hart: every port of hart h idle (by the model).
  logic [NUM_HARTS-1:0] drained;
  always_comb begin
    drained = '1;
    for (int p = 0; p < NUM_PORTS; p++)
      if (PORT_HART[p] < NUM_HARTS && !ref_idle[p]) drained[PORT_HART[p]] = 1'b0;
  end

  for (genvar h = 0; h < NUM_HARTS; h++) begin : g_h
    a_clr_wins:   assert property (clr[h] |=> !ready_o[h]);
    a_set:        assert property (sw_set_i[h] && !clr[h] |=> ready_o[h]);
    a_hold:       assert property (!sw_set_i[h] && !clr[h] |=> ready_o[h] == $past(ready_o[h]));
    a_rst_clears: assert property (!hart_rst_ni[h] |=> !ready_o[h]);

    // THE DECISION: "ACCEPTED only while READY[h] is set, no wake is pending,
    // and every port of hart h is idle; it is DENIED otherwise"; "The wake
    // term is combinational, so a wake in the very cycle of the request denies it".
    a_decision:          assert property (!dev_deny_o[h] == (ready_o[h] && !wake_i[h] && drained[h]));
    a_accept_needs_ready: assert property (!dev_deny_o[h] |-> ready_o[h]);
    a_accept_needs_drain: assert property (!dev_deny_o[h] |-> drained[h]);
    a_wake_denies:       assert property (wake_i[h] |-> dev_deny_o[h]);
    // "dev_busy_o is 0: the adapter never makes the PPU wait"
    a_busy_zero:         assert property (!dev_busy_o[h]);

    c_accept:        cover property (!dev_deny_o[h]);
    c_clear_and_set: cover property (sw_set_i[h] && clr[h] && !ready_o[h] ##1 !ready_o[h]);
    c_deny_inflight: cover property (ready_o[h] && !wake_i[h] && !drained[h] && dev_deny_o[h]);
    c_wake_deny:     cover property (ready_o[h] && wake_i[h] && drained[h] && dev_deny_o[h]);
    c_dom_on_clears: cover property (ready_o[h] && dom_on_i[h] && !on_p[h] ##1 !ready_o[h]);
  end

endmodule

bind hart_ready_adp hart_ready_adp_props #(
  .NUM_HARTS(NUM_HARTS), .NUM_PORTS(NUM_PORTS), .PORT_HART(PORT_HART), .PORT_TLC(PORT_TLC),
  .SZW(SZW), .LOG2_BYTES(LOG2_BYTES), .CNT_W(CNT_W)
) u_hart_ready_adp_props (.*);

// =============================================================================
// The formal top: the adapter on the Q-Channel device side of each hart's PPU,
// as in ppu_axi_dom_top (qchannel_device, SYNC_STAGES = 2, dev_wake = 0: PD5).
// Configuration = the unit test's: two harts, three ports -- port 0 hart 0
// TL-C (a CVA6 core), port 1 hart 0 TL-UH (its Ara port), port 2 hart 1 TL-UH.
// =============================================================================
module hart_ready_adp_fv
  import tl_pkg::*;
#(
  parameter int unsigned NH = 2,
  parameter int unsigned NP = 3,
  parameter int unsigned SZW = 4
) (
  input  logic                    clk_i,
  input  logic                    rst_ni,
  input  logic [NH-1:0]           sw_set_i, sw_clr_i, scp_clr_i, wake_i, dom_on_i, hart_rst_ni,
  input  logic [NP-1:0]           a_valid_i, a_ready_i, d_valid_i, d_ready_i,
  input  logic [NP-1:0]           b_valid_i, b_ready_i, c_valid_i, c_ready_i, e_valid_i, e_ready_i,
  input  logic [NP-1:0][2:0]      a_opcode_i, d_opcode_i, c_opcode_i,
  input  logic [NP-1:0][SZW-1:0]  a_size_i, d_size_i, c_size_i,
  input  logic [NH-1:0]           qreqn,          // from each hart's PPU (the controller)
  output logic [NH-1:0]           qacceptn,
  output logic [NH-1:0]           qdeny,
  output logic [NH-1:0]           qactive,
  output logic [NH-1:0]           ready_o,
  output logic [NP-1:0]           port_idle_o
);
  localparam logic [NP-1:0][7:0] PORT_HART = {8'd1, 8'd0, 8'd0};
  localparam logic [NP-1:0]      PORT_TLC  = 3'b001;

  logic [NH-1:0] busy, deny, qok;

  hart_ready_adp #(
    .NUM_HARTS(NH), .NUM_PORTS(NP), .PORT_HART(PORT_HART), .PORT_TLC(PORT_TLC),
    .SZW(SZW), .LOG2_BYTES(3)
  ) u_dut (
    .clk_i, .rst_ni, .sw_set_i, .sw_clr_i, .scp_clr_i, .wake_i, .dom_on_i, .hart_rst_ni, .ready_o,
    .a_valid_i, .a_ready_i, .a_opcode_i, .a_size_i, .d_valid_i, .d_ready_i, .d_opcode_i, .d_size_i,
    .b_valid_i, .b_ready_i, .c_valid_i, .c_ready_i, .c_opcode_i, .c_size_i, .e_valid_i, .e_ready_i,
    .port_idle_o, .dev_busy_o(busy), .dev_deny_o(deny));

  for (genvar h = 0; h < NH; h++) begin : g_q
    qchannel_device #(.SYNC_STAGES(2)) u_q (
      .clk(clk_i), .rst_n(rst_ni), .qreqn(qreqn[h]), .qacceptn(qacceptn[h]), .qdeny(qdeny[h]),
      .qactive(qactive[h]), .dev_quiescent_busy(busy[h]), .dev_quiescent_deny(deny[h]),
      .dev_wake(1'b0), .dev_quiescent_ok(qok[h]));
  end

  default clocking cb @(posedge clk_i); endclocking
  default disable iff (!rst_ni);

  for (genvar h = 0; h < NH; h++) begin : g_lpi
    // ---- Environment: the controller (the PPU) obeys LPI 2.1.2 "Handshake
    // rules" for QREQn (an input to the device, so a legitimate assumption):
    //   "QREQn can only transition from HIGH to LOW when QACCEPTn is HIGH and
    //    QDENY is LOW."
    asm_qreqn_fall: assume property (qreqn[h] && !(qacceptn[h] && !qdeny[h]) |=> qreqn[h]);
    //   "QREQn can only transition from LOW to HIGH when either: QACCEPTn and
    //    QDENY are both LOW; QACCEPTn and QDENY are both HIGH."
    asm_qreqn_rise: assume property (!qreqn[h] && !((!qacceptn[h] && !qdeny[h]) || (qacceptn[h] && qdeny[h]))
                                     |=> !qreqn[h]);

    // ---- Device side, LPI 2.1.2 ----
    // Table 2-1: QACCEPTn = 0 with QDENY = 1 is "Unused (illegal)".
    a_q_no_illegal:  assert property (!(!qacceptn[h] && qdeny[h]));
    // "QACCEPTn can only transition from HIGH to LOW when QREQn is LOW and QDENY is LOW."
    a_q_accept_fall: assert property ($fell(qacceptn[h]) |-> !qreqn[h] && !qdeny[h] && $past(!qreqn[h] && !qdeny[h]));
    // "QACCEPTn can only transition from LOW to HIGH when QREQn is HIGH and QDENY is LOW."
    a_q_accept_rise: assert property ($rose(qacceptn[h]) |-> qreqn[h] && !qdeny[h] && $past(qreqn[h] && !qdeny[h]));
    // "QDENY can only transition from HIGH to LOW when QREQn is HIGH and QACCEPTn is HIGH."
    a_q_deny_fall:   assert property ($fell(qdeny[h]) |-> qreqn[h] && qacceptn[h] && $past(qreqn[h] && qacceptn[h]));
    // "QDENY can only transition from LOW to HIGH when QREQn is LOW and QACCEPTn is HIGH."
    a_q_deny_rise:   assert property ($rose(qdeny[h]) |-> !qreqn[h] && qacceptn[h] && $past(!qreqn[h] && qacceptn[h]));
    // Figure 2-2 / Table 2-1: Q_STOPPED is left only by the controller driving
    // QREQn HIGH -- an accept, once given, holds while QREQn is LOW; likewise
    // a denial (Figure 2-3, Q_DENIED until QREQn HIGH).
    a_q_accept_holds: assert property (!qacceptn[h] && !qreqn[h] |=> !qacceptn[h]);
    a_q_deny_holds:   assert property (qdeny[h] && !qreqn[h] |=> qdeny[h]);

    // ---- The adapter's decision, seen on the Q-Channel ----
    // An accept (QACCEPTn falling) only when, in the cycle the device decided,
    // READY was set, no wake was pending and every port of the hart was idle.
    a_q_accept_only_ready_drained: assert property ($fell(qacceptn[h]) |->
        $past(ready_o[h] && !wake_i[h] && u_dut.u_hart_ready_adp_props.drained[h]));
    // A denial (QDENY rising) only when the adapter denied.
    a_q_deny_only_denied: assert property ($rose(qdeny[h]) |->
        $past(!(ready_o[h] && !wake_i[h] && u_dut.u_hart_ready_adp_props.drained[h])));

    c_q_accept:      cover property ($fell(qacceptn[h]));
    c_q_deny:        cover property ($rose(qdeny[h]));
    c_q_accept_exit: cover property ($fell(qacceptn[h]) ##[1:$] $rose(qacceptn[h]));
    c_q_deny_cont:   cover property ($rose(qdeny[h]) ##[1:$] $fell(qdeny[h]));
  end
endmodule
