`timescale 1ns/1ps
// Formal properties for scp_irq (src/pmu/rtl/scp_irq.sv), bound into every
// scp_irq instance. Run: src/signoff/formal/scp_irq.tcl (VC Formal FPV).
//
// Every rule below is quoted from scp_irq.sv's own header (THE INPUT BANK and
// THE REGISTERS); the section is named in the comment above each property.
//
// The input path is modelled here independently of the RTL (a SYNC_STAGES-deep
// shift register per ASYNC input, a pass-through otherwise), so the RAW /
// event / PENDING properties check the synchroniser as well as the bank.
// No assumptions: every input is free. The reset is held inactive after the
// reset state by the tool (create_reset).

module scp_irq_props #(
  parameter int unsigned NUM_IN      = 1,
  parameter logic [31:0] ASYNC       = '0,
  parameter int unsigned SYNC_STAGES = 2
) (
  input logic              clk_i,
  input logic              rst_ni,
  input logic              req_i,
  input logic              we_i,
  input logic [3:0]        be_i,
  input logic [31:0]       addr_i,
  input logic [31:0]       wdata_i,
  input logic              rvalid_o,
  input logic [31:0]       rdata_o,
  input logic              err_o,
  input logic [NUM_IN-1:0] in_i,
  input logic              irq_o,
  // internal state = the documented register fields
  input logic [NUM_IN-1:0] pend_q,   // PENDING
  input logic [NUM_IN-1:0] en_q,     // ENABLE
  input logic [NUM_IN-1:0] edge_q    // EDGE
);

  default clocking cb @(posedge clk_i); endclocking
  default disable iff (!rst_ni);

  // ---- Independent model of the input path ("THE INPUT BANK: synchroniser") ----
  logic [NUM_IN-1:0] raw;        // the input after its synchroniser: what RAW must show
  logic [NUM_IN-1:0] raw_prev;   // ...one cycle earlier
  logic [SYNC_STAGES-1:0][NUM_IN-1:0] sh;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sh       <= '0;
      raw_prev <= '0;
    end else begin
      sh[0] <= in_i;
      for (int s = 1; s < SYNC_STAGES; s++) sh[s] <= sh[s-1];
      raw_prev <= raw;
    end
  end
  for (genvar i = 0; i < NUM_IN; i++) begin : g_raw
    if (ASYNC[i] && SYNC_STAGES > 0) begin : g_a
      assign raw[i] = sh[SYNC_STAGES-1][i];
    end else begin : g_s
      assign raw[i] = in_i[i];
    end
  end

  // "EDGE[i] 1: a rising edge of the synchronised input is the event. 0: the
  // input HIGH is the event (level)."
  logic [NUM_IN-1:0] ev, ev_edge;
  assign ev_edge = raw & ~raw_prev;
  assign ev      = (edge_q & ev_edge) | (~edge_q & raw);

  // Bus decode, from THE REGISTERS (offset = addr[11:2], byte enables honoured).
  logic [11:0] off;
  logic [31:0] bm;
  assign off = {addr_i[11:2], 2'b00};
  assign bm  = {{8{be_i[3]}}, {8{be_i[2]}}, {8{be_i[1]}}, {8{be_i[0]}}};
  logic wr_pend, wr_en, wr_edge;
  assign wr_pend = req_i && we_i && off == 12'h000;
  assign wr_en   = req_i && we_i && off == 12'h004;
  assign wr_edge = req_i && we_i && off == 12'h008;
  logic [NUM_IN-1:0] w1c;        // "PENDING R/W1C: cleared by writing 1"
  assign w1c = wr_pend ? NUM_IN'(wdata_i & bm) : '0;
  logic known_off;
  assign known_off = off inside {12'h000, 12'h004, 12'h008, 12'h00C, 12'h010, 12'h014};

  // ===========================================================================
  // Synchroniser: "ASYNC[i] = 1: two flops ... ASYNC[i] = 0: taken as it is"
  // (RAW = "input i after its synchroniser").
  // ===========================================================================
  a_raw_read: assert property (req_i && !we_i && off == 12'h00C |=> rdata_o == 32'($past(raw)));
  for (genvar i = 0; i < NUM_IN; i++) begin : g_bit
    // PENDING set rules ("PENDING[i] sticky. Set at the clock edge after the
    // event while ENABLE[i] = 1").
    a_pend_set_level:  assert property (en_q[i] && !edge_q[i] && raw[i] |=> pend_q[i]);
    a_pend_set_edge:   assert property (en_q[i] && edge_q[i] && ev_edge[i] |=> pend_q[i]);
    // "ENABLE[i] the mask. 0: the input does NOTHING -- it sets no pending bit"
    a_pend_no_set_masked: assert property (!pend_q[i] && !en_q[i] |=> !pend_q[i]);
    // Level mode: no event while the input is LOW.
    a_pend_no_set_low:    assert property (!pend_q[i] && !raw[i] |=> !pend_q[i]);
    // Edge mode: a HIGH input that was already HIGH is no event ("unmasking an
    // edge input that is already HIGH does not invent an edge").
    a_pend_no_set_noedge: assert property (!pend_q[i] && edge_q[i] && !ev_edge[i] |=> !pend_q[i]);
    // Sticky: only a W1C clears it.
    a_pend_sticky:    assert property (pend_q[i] && !w1c[i] |=> pend_q[i]);
    // "cleared by writing 1 (W1C)" (byte enables honoured)
    a_pend_w1c:       assert property (w1c[i] && !(en_q[i] && ev[i]) |=> !pend_q[i]);
    // "a new event in the cycle of the clear wins": an edge that arrives in the
    // cycle of its clear is NOT lost.
    a_pend_set_wins:  assert property (w1c[i] && en_q[i] && ev[i] |=> pend_q[i]);
    // Writes elsewhere or with the byte lane off do not clear.
    a_pend_be_off:    assert property (pend_q[i] && wr_pend && !be_i[i/8] |=> pend_q[i]);

    c_set_level:      cover property (!pend_q[i] && en_q[i] && !edge_q[i] ##1 pend_q[i]);
    c_set_edge:       cover property (!pend_q[i] && en_q[i] && edge_q[i] && ev_edge[i] ##1 pend_q[i]);
    c_w1c:            cover property (pend_q[i] && w1c[i] ##1 !pend_q[i]);
    c_clear_and_set:  cover property (pend_q[i] && w1c[i] && en_q[i] && edge_q[i] && ev_edge[i] ##1 pend_q[i]);
    c_masked_high:    cover property (!en_q[i] && raw[i] && !pend_q[i] ##1 !pend_q[i]);
    c_irq_from_input: cover property (!irq_o && in_i[i] ##1 1 [*0:3] ##1 irq_o && pend_q[i]);
  end

  // ===========================================================================
  // The line: "irq_o = |(PENDING & ENABLE)"; ACTIVE reads the same.
  // ===========================================================================
  a_irq_def:     assert property (irq_o == |(pend_q & en_q));
  a_irq_masked:  assert property (en_q == '0 |-> !irq_o);
  c_irq_masked_pending: cover property (pend_q != '0 && !irq_o);

  // ===========================================================================
  // THE REGISTERS
  // ===========================================================================
  // "it answers exactly one cycle after the request and cannot stall"
  a_rvalid:      assert property (req_i |=> rvalid_o);
  a_no_rvalid:   assert property (!req_i |=> !rvalid_o);
  // "Any other offset answers err."
  a_err:         assert property (req_i && !known_off |=> err_o);
  a_no_err:      assert property (!(req_i && !known_off) |=> !err_o);
  a_rd_pending:  assert property (req_i && !we_i && off == 12'h000 |=> rdata_o == 32'($past(pend_q)));
  a_rd_enable:   assert property (req_i && !we_i && off == 12'h004 |=> rdata_o == 32'($past(en_q)));
  a_rd_edge:     assert property (req_i && !we_i && off == 12'h008 |=> rdata_o == 32'($past(edge_q)));
  a_rd_active:   assert property (req_i && !we_i && off == 12'h010 |=> rdata_o == 32'($past(pend_q & en_q)));
  a_rd_info:     assert property (req_i && !we_i && off == 12'h014 |=> rdata_o == 32'(NUM_IN));
  // ENABLE / EDGE RW with byte enables; unchanged without a write.
  a_wr_enable:   assert property (wr_en |=> en_q == $past((en_q & ~NUM_IN'(bm)) | NUM_IN'(wdata_i & bm)));
  a_wr_edge:     assert property (wr_edge |=> edge_q == $past((edge_q & ~NUM_IN'(bm)) | NUM_IN'(wdata_i & bm)));
  a_en_stable:   assert property (!wr_en |=> en_q == $past(en_q));
  a_edge_stable: assert property (!wr_edge |=> edge_q == $past(edge_q));

endmodule

bind scp_irq scp_irq_props #(.NUM_IN(NUM_IN), .ASYNC(ASYNC), .SYNC_STAGES(SYNC_STAGES)) u_scp_irq_props (.*);
