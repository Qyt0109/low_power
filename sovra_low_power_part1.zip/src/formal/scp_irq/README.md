# scp_irq formal properties

Properties for [`src/pmu/rtl/scp_irq.sv`](../../pmu/rtl/scp_irq.sv), the SCP's
interrupt status/enable block: NUM_IN inputs, each optionally synchronised,
level or edge, masked, sticky with W1C, onto one line into Ibex. Every rule is
quoted from the RTL header (THE INPUT BANK, THE REGISTERS).

## Files

| File | Contents |
|---|---|
| `scp_irq_props.sv` | `scp_irq_props` and `bind scp_irq scp_irq_props u_scp_irq_props (.*)`: an independent model of the input path (a SYNC_STAGES-deep shift register per ASYNC input, a pass-through otherwise), the bus decode, and the properties below. It reads the RTL's `pend_q`, `en_q`, `edge_q` (the documented PENDING, ENABLE, EDGE fields) |
| `src/signoff/formal/scp_irq.tcl` | The run script: top `scp_irq`, `NUM_IN = 4`, `ASYNC = 4'b0011` (inputs 0 and 1 through the two-flop synchroniser, 2 and 3 synchronous), `SYNC_STAGES = 2`; clock `clk_i`, reset `rst_ni` |

No assumptions: every input is free.

## Properties

Per input bit `i` (`g_bit[i]`, 9 assertions × 4 inputs):

| Intent | Properties |
|---|---|
| PENDING is set by an enabled event | `a_pend_set_level` (level mode, synchronised input HIGH), `a_pend_set_edge` (edge mode, rising edge of the synchronised input) |
| ...and by nothing else | `a_pend_no_set_masked` (ENABLE 0 sets nothing), `a_pend_no_set_low` (no event while the input is LOW), `a_pend_no_set_noedge` (an input already HIGH is no edge) |
| Sticky until W1C | `a_pend_sticky`, `a_pend_w1c`, `a_pend_be_off` (a write with the byte lane off clears nothing) |
| An event in the cycle of its clear is kept | `a_pend_set_wins` |

Whole block:

| Intent | Properties |
|---|---|
| The synchroniser | `a_raw_read`: RAW reads the input after its synchroniser (two cycles late for ASYNC inputs, as is for the others) |
| The line | `a_irq_def`: `irq_o == \|(PENDING & ENABLE)`; `a_irq_masked` |
| Bus protocol | `a_rvalid`, `a_no_rvalid` (answer exactly one cycle after the request), `a_err`, `a_no_err` (an unknown offset, and only that, answers `err`) |
| Register map | `a_rd_pending`, `a_rd_enable`, `a_rd_edge`, `a_rd_active` (PENDING & ENABLE), `a_rd_info` (NUM_IN); `a_wr_enable`, `a_wr_edge` (byte enables honoured); `a_en_stable`, `a_edge_stable` (unchanged without a write) |

Covers (6 per input + 1): a level set, an edge set, a W1C, a clear and an edge
in the same cycle, a masked HIGH input, the line raised from an input; and a
pending bit with the line masked.

## Status

52 of 52 assertions proven (all with an antecedent non-vacuous), 25 of 25
covers covered, none bounded (latest run, `build/signoff/formal/scp_irq/`).

## Mutant

`SOC4_MUT_IRQ_SYNC0` (`pmu/rtl/scp_irq.sv`): the synchroniser's output tied
LOW. It falsifies 7 assertions: `a_raw_read` and, for the two ASYNC inputs,
`a_pend_set_level`, `a_pend_set_edge` and `a_pend_set_wins`. The same define
is soc4neg's M4, which must fail at `[chk:WAKE_PLIC]` in simulation
([`src/tb/soc4/README.md`](../../tb/soc4/README.md)).

## Running

```
make -C src vcformal       # all blocks
make -C src vcformalneg    # all mutants
```

`VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`. By hand, from a
run directory: `PMU_SRC=<repo>/src [FV_DEFINES=+define+SOC4_MUT_IRQ_SYNC0]
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/scp_irq.tcl`.
The verdict is `fv_summary.py`'s ([`../README.md`](../README.md)).

## Adding a property

Write it against the RTL header's text, using the model signals (`raw`,
`raw_prev`, `ev`, `ev_edge`, `w1c`, `wr_*`) rather than RTL internals. A new
register needs its offset added to `known_off`, or `a_err` fails.

## References

- `src/pmu/rtl/scp_irq.sv` header; `src/pmu/fw/hal/scp_irq.h`.
- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` Sections 14.1 (PD1, PD5, PD7)
  and 14.7 (H7-H9, F10).
- [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md) Section 6.
