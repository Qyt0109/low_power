`timescale 1ns/1ps
// Formal properties of the Q-Channel controller and device FSMs
// (src/rtl/qchannel/qchannel_controller.sv, qchannel_device.sv) against the
// AMBA Low Power Interface Specification, ARM IHI 0068C (text:
// build/spec_txt/arm-amba-low-power-interface-spec.txt), Section 2.1.
// Phase 6 sign-off, VC Formal FPV; script src/signoff/formal/qchannel.tcl,
// top src/formal/qchannel/qchannel_fv_top.sv.
//
// WHERE THE PROPERTIES SIT: AT THE PINS. Each FSM samples the far side's
// wires through cdc_sync (2 flops), so its own view lags the wires. The
// protocol is defined on the wires ("All signals are assumed to be
// asynchronous", Section 2.1.1; the handshake rules of Section 2.1.2 are
// about transitions of QREQn/QACCEPTn/QDENY themselves), and a hazard the
// synchroniser introduces -- an FSM acting on a stale synchronised value --
// is visible only there; a check on the synchronised side would take the
// FSM's own (possibly stale) view as the truth. So every rule is checked on
// the module's ports, the "from" state of a transition being the wire values
// one clock earlier ($past). In this single-clock model the far side's wires
// are free inputs that may change at any clock edge, so every relative
// timing of the two asynchronous domains, as seen at this module's sampling
// clock, is covered.
//
// Cross-check: qchannel_monitor.sv (the simulation checker) lists the same
// six rules R1-R6 and the illegal state R7; the names below reuse its R-numbers.
//
// Naming: a_* assertion, m_* assumption, c_* cover.

// =============================================================================
// Device side: qchannel_device, the controller's QREQn a constrained input
// =============================================================================
module qchannel_device_props (
  input logic clk,
  input logic rst_n,
  input logic qreqn,
  input logic qacceptn,
  input logic qdeny,
  input logic qactive,
  input logic dev_quiescent_busy,
  input logic dev_quiescent_deny,
  input logic dev_wake,
  input logic dev_quiescent_ok
);
  logic init_q;                        // HIGH in the first cycle after reset only
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) init_q <= 1'b1; else init_q <= 1'b0;

  // ---- Environment: a controller that obeys Section 2.1.2 ----
  // R1: "QREQn can only transition from HIGH to LOW when QACCEPTn is HIGH and QDENY is LOW."
  m_ctl_R1: assume property (@(posedge clk) disable iff (!rst_n)
    $fell(qreqn) |-> $past(qacceptn && !qdeny));
  // R2: "QREQn can only transition from LOW to HIGH when either QACCEPTn and
  // QDENY are both LOW [or] both HIGH."
  m_ctl_R2: assume property (@(posedge clk) disable iff (!rst_n)
    $rose(qreqn) |-> $past((!qacceptn && !qdeny) || (qacceptn && qdeny)));
  // (Reset: "A controller can release a device from reset with either QREQn
  // LOW ... or QREQn HIGH" -- the initial QREQn is left free.)

  // ---- Section 2.1.2 handshake rules, device outputs ----
  // R3: "QACCEPTn can only transition from HIGH to LOW when QREQn is LOW and QDENY is LOW."
  a_dev_R3_acc_fall: assert property (@(posedge clk) disable iff (!rst_n)
    $fell(qacceptn) |-> $past(!qreqn && !qdeny));
  // R4: "QACCEPTn can only transition from LOW to HIGH when QREQn is HIGH and QDENY is LOW."
  a_dev_R4_acc_rise: assert property (@(posedge clk) disable iff (!rst_n)
    $rose(qacceptn) |-> $past(qreqn && !qdeny));
  // R5: "QDENY can only transition from HIGH to LOW when QREQn is HIGH and QACCEPTn is HIGH."
  a_dev_R5_deny_fall: assert property (@(posedge clk) disable iff (!rst_n)
    $fell(qdeny) |-> $past(qreqn && qacceptn));
  // R6: "QDENY can only transition from LOW to HIGH when QREQn is LOW and QACCEPTn is HIGH."
  a_dev_R6_deny_rise: assert property (@(posedge clk) disable iff (!rst_n)
    $rose(qdeny) |-> $past(!qreqn && qacceptn));
  // R7: Table 2-1 "x 0 1 Unused (illegal)": never QACCEPTn LOW with QDENY HIGH.
  a_dev_R7_legal: assert property (@(posedge clk) disable iff (!rst_n)
    !(!qacceptn && qdeny));
  // Section 2.1.1: "only one of them changes per handshake transition".
  a_dev_one_ack_change: assert property (@(posedge clk) disable iff (!rst_n)
    !($changed(qacceptn) && $changed(qdeny)));
  // Section 2.1.2 "Device reset": "At reset assertion a device must drive both
  // QACCEPTn and QDENY LOW" -- the state reset leaves.
  a_dev_reset_low: assert property (@(posedge clk) disable iff (!rst_n)
    init_q |-> !qacceptn && !qdeny);
  // Table 2-1: the device is quiescent only once it has accepted (Q_STOPPED,
  // or Q_EXIT before its acknowledge): dev_quiescent_ok implies QACCEPTn LOW
  // and QDENY LOW on the wires.
  a_dev_quiescent_ok_acc: assert property (@(posedge clk) disable iff (!rst_n)
    dev_quiescent_ok |-> !qacceptn && !qdeny);
  // Figure 2-2 T5 / Table 2-1 Q_EXIT "When the device acknowledges, by
  // deasserting QACCEPTn HIGH, the state moves to Q_RUN": in Q_EXIT the device
  // does acknowledge.
  a_dev_live_exit: assert property (@(posedge clk) disable iff (!rst_n)
    qreqn && !qacceptn && !qdeny |-> s_eventually qacceptn);
  // Figure 2-3 T5: in Q_CONTINUE the device does drive QDENY LOW.
  a_dev_live_continue: assert property (@(posedge clk) disable iff (!rst_n)
    qreqn && qacceptn && qdeny |-> s_eventually !qdeny);
  // Q_REQUEST is answered (accept or deny) once the device is idle or wants
  // to deny ("requested to become quiescent when idle", Table 2-1), under the
  // fairness assumption below on the device's own inputs.
  m_fair_idle: assume property (@(posedge clk) disable iff (!rst_n)
    s_eventually (!dev_quiescent_busy || dev_quiescent_deny));
  a_dev_live_request: assert property (@(posedge clk) disable iff (!rst_n)
    !qreqn && qacceptn && !qdeny |-> s_eventually (!qacceptn || qdeny));

  // ---- Covers: every Table 2-1 state and every Figure 2-6 transition ----
  c_dev_run_to_request:     cover property (@(posedge clk) disable iff (!rst_n)
    $past(qreqn && qacceptn && !qdeny) && !qreqn && qacceptn && !qdeny);
  c_dev_request_to_stopped: cover property (@(posedge clk) disable iff (!rst_n)
    $past(!qreqn && qacceptn && !qdeny) && !qreqn && !qacceptn && !qdeny);
  c_dev_stopped_to_exit:    cover property (@(posedge clk) disable iff (!rst_n)
    $past(!qreqn && !qacceptn && !qdeny) && qreqn && !qacceptn && !qdeny);
  c_dev_exit_to_run:        cover property (@(posedge clk) disable iff (!rst_n)
    $past(qreqn && !qacceptn && !qdeny) && qreqn && qacceptn && !qdeny);
  c_dev_request_to_denied:  cover property (@(posedge clk) disable iff (!rst_n)
    $past(!qreqn && qacceptn && !qdeny) && !qreqn && qacceptn && qdeny);
  c_dev_denied_to_continue: cover property (@(posedge clk) disable iff (!rst_n)
    $past(!qreqn && qacceptn && qdeny) && qreqn && qacceptn && qdeny);
  c_dev_continue_to_run:    cover property (@(posedge clk) disable iff (!rst_n)
    $past(qreqn && qacceptn && qdeny) && qreqn && qacceptn && !qdeny);
  // a whole accepted cycle Q_RUN -> ... -> Q_RUN (Figure 2-2), a whole denied
  // one (Figure 2-3)
  c_dev_fig2_2: cover property (@(posedge clk) disable iff (!rst_n)
    (qreqn && qacceptn && !qdeny) ##[1:$] (!qreqn && !qacceptn) ##[1:$] (qreqn && !qacceptn)
    ##[1:$] (qreqn && qacceptn && !qdeny));
  c_dev_fig2_3: cover property (@(posedge clk) disable iff (!rst_n)
    (qreqn && qacceptn && !qdeny) ##[1:$] (!qreqn && qdeny) ##[1:$] (qreqn && qdeny)
    ##[1:$] (qreqn && qacceptn && !qdeny));
  c_dev_qactive: cover property (@(posedge clk) disable iff (!rst_n)
    qactive && !qreqn && !qacceptn);
endmodule

// =============================================================================
// Controller side: qchannel_controller, the device's QACCEPTn/QDENY/QACTIVE
// constrained inputs
// =============================================================================
module qchannel_controller_props (
  input logic clk,
  input logic rst_n,
  input logic qreqn,
  input logic qacceptn,
  input logic qdeny,
  input logic qactive,
  input logic req_dev_quiescence,
  input logic enb_qactive_led_quiescence_enter,
  input logic enb_qactive_led_quiescence_exit,
  input logic dev_stopped
);
  logic init_q;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) init_q <= 1'b1; else init_q <= 1'b0;

  // ---- Environment: a device that obeys Section 2.1.2 ----
  // Device reset: "At reset assertion a device must drive both QACCEPTn and
  // QDENY LOW" (the device leaves reset with the controller).
  m_dev_reset_low: assume property (@(posedge clk) disable iff (!rst_n)
    init_q |-> !qacceptn && !qdeny);
  // R3-R6 (Section 2.1.2 handshake rules), and R7 (Table 2-1 illegal state).
  m_dev_R3: assume property (@(posedge clk) disable iff (!rst_n)
    $fell(qacceptn) |-> $past(!qreqn && !qdeny));
  m_dev_R4: assume property (@(posedge clk) disable iff (!rst_n)
    $rose(qacceptn) |-> $past(qreqn && !qdeny));
  m_dev_R5: assume property (@(posedge clk) disable iff (!rst_n)
    $fell(qdeny) |-> $past(qreqn && qacceptn));
  m_dev_R6: assume property (@(posedge clk) disable iff (!rst_n)
    $rose(qdeny) |-> $past(!qreqn && qacceptn));
  m_dev_R7: assume property (@(posedge clk) disable iff (!rst_n)
    !(!qacceptn && qdeny));
  // (QACTIVE: "transitions on QACTIVE are not restricted", Section 2.1.1 --
  // left free.)

  // ---- Section 2.1.2 handshake rules, controller output ----
  // R1: "QREQn can only transition from HIGH to LOW when QACCEPTn is HIGH and QDENY is LOW."
  a_ctl_R1_req_fall: assert property (@(posedge clk) disable iff (!rst_n)
    $fell(qreqn) |-> $past(qacceptn && !qdeny));
  // R2: "QREQn can only transition from LOW to HIGH when either QACCEPTn and
  // QDENY are both LOW [or] both HIGH." (Section 2.1.3: "QREQn cannot be
  // driven HIGH until the handshake is completed by the device with either an
  // acceptance or denial response.")
  a_ctl_R2_req_rise: assert property (@(posedge clk) disable iff (!rst_n)
    $rose(qreqn) |-> $past((!qacceptn && !qdeny) || (qacceptn && qdeny)));
  // Table 2-1 Q_STOPPED: "the only state where the controller does not
  // guarantee the availability of any resource": dev_stopped (safe to gate)
  // only while the wires are in Q_STOPPED.
  a_ctl_stopped_is_q_stopped: assert property (@(posedge clk) disable iff (!rst_n)
    dev_stopped |-> !qreqn && !qacceptn && !qdeny);
  // Table 2-1 Q_DENIED: "Controller must deassert QREQn."
  a_ctl_live_denied: assert property (@(posedge clk) disable iff (!rst_n)
    !qreqn && qacceptn && qdeny |-> s_eventually qreqn);
  // Section 2.1.3 (QACTIVE HIGH as the exit stimulus; "Failure to implement
  // the policy might lead to a system deadlock"), with the policy the RTL
  // documents (enb_qactive_led_quiescence_exit): in Q_STOPPED with QACTIVE
  // HIGH and the policy enabled, QREQn does rise unless either is withdrawn.
  a_ctl_live_wake: assert property (@(posedge clk) disable iff (!rst_n)
    !qreqn && !qacceptn && !qdeny && qactive && enb_qactive_led_quiescence_exit
      |-> s_eventually (qreqn || !qactive || !enb_qactive_led_quiescence_exit));

  // ---- Covers ----
  c_ctl_req_fall:  cover property (@(posedge clk) disable iff (!rst_n) $fell(qreqn));
  c_ctl_exit:      cover property (@(posedge clk) disable iff (!rst_n)
    $rose(qreqn) && $past(!qacceptn && !qdeny));
  c_ctl_continue:  cover property (@(posedge clk) disable iff (!rst_n)
    $rose(qreqn) && $past(qacceptn && qdeny));
  c_ctl_stopped:   cover property (@(posedge clk) disable iff (!rst_n) dev_stopped && !init_q);
  c_ctl_fig2_7_enter: cover property (@(posedge clk) disable iff (!rst_n)
    $fell(qreqn) && !req_dev_quiescence && enb_qactive_led_quiescence_enter);
  c_ctl_fig2_8_exit:  cover property (@(posedge clk) disable iff (!rst_n)
    $rose(qreqn) && req_dev_quiescence && $past(!qacceptn && !qdeny));
endmodule

// =============================================================================
// The pair, connected (qchannel_pair in qchannel_fv_top.sv): no handshake
// assumption at all; the wires must obey every rule, and the handshake must
// complete.
// =============================================================================
module qchannel_pair_props (
  input logic clk,
  input logic rst_n,
  input logic qreqn,
  input logic qacceptn,
  input logic qdeny,
  input logic req_dev_quiescence,
  input logic dev_quiescent_busy,
  input logic dev_quiescent_deny
);
  logic init_q;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) init_q <= 1'b1; else init_q <= 1'b0;

  // R1-R7 on the connected wires (Section 2.1.2, Table 2-1).
  a_pair_R1: assert property (@(posedge clk) disable iff (!rst_n) $fell(qreqn)    |-> $past(qacceptn && !qdeny));
  a_pair_R2: assert property (@(posedge clk) disable iff (!rst_n) $rose(qreqn)    |-> $past(qacceptn == qdeny));
  a_pair_R3: assert property (@(posedge clk) disable iff (!rst_n) $fell(qacceptn) |-> $past(!qreqn && !qdeny));
  a_pair_R4: assert property (@(posedge clk) disable iff (!rst_n) $rose(qacceptn) |-> $past(qreqn && !qdeny));
  a_pair_R5: assert property (@(posedge clk) disable iff (!rst_n) $fell(qdeny)    |-> $past(qreqn && qacceptn));
  a_pair_R6: assert property (@(posedge clk) disable iff (!rst_n) $rose(qdeny)    |-> $past(!qreqn && qacceptn));
  a_pair_R7: assert property (@(posedge clk) disable iff (!rst_n) !(!qacceptn && qdeny));
  // One wire per transition (Section 2.1.1 and the interlocked handshake).
  a_pair_one_change: assert property (@(posedge clk) disable iff (!rst_n)
    $countones({$changed(qreqn), $changed(qacceptn), $changed(qdeny)}) <= 1);

  // End to end: a request that is held, to an idle device that does not
  // deny, reaches Q_STOPPED (Figure 2-2 T1-T3). Fairness on the device's own
  // inputs: it is eventually idle (m_fair_idle), as in qchannel_device_props.
  m_fair_idle_pair: assume property (@(posedge clk) disable iff (!rst_n)
    s_eventually (!dev_quiescent_busy || dev_quiescent_deny));
  a_pair_live_request: assert property (@(posedge clk) disable iff (!rst_n)
    req_dev_quiescence |-> s_eventually (!req_dev_quiescence || (!qreqn && (!qacceptn || qdeny))));

  c_pair_stopped: cover property (@(posedge clk) disable iff (!rst_n)
    !qreqn && !qacceptn && !qdeny && !init_q && $past(qacceptn));
  c_pair_denied_cycle: cover property (@(posedge clk) disable iff (!rst_n)
    (!qreqn && qdeny) ##[1:$] (qreqn && qacceptn && !qdeny));
endmodule

// Instance-specific binds: the standalone instances of qchannel_fv_top only,
// so that the environment assumptions never constrain the connected pair.
bind qchannel_device     : qchannel_fv_top.u_dev  qchannel_device_props     u_props (.*);
bind qchannel_controller : qchannel_fv_top.u_ctl  qchannel_controller_props u_props (.*);
bind qchannel_pair       : qchannel_fv_top.u_pair qchannel_pair_props       u_props (.*);
