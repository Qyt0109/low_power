`timescale 1ns/1ps
// FPV top for the Q-Channel FSMs (src/formal/qchannel/qchannel_props.sv):
//   u_dev  qchannel_device alone, the controller side free inputs
//   u_ctl  qchannel_controller alone, the device side free inputs
//   u_pair the two connected (qchannel_pair below), system inputs free
// Default parameters (SYNC_STAGES = 2). One clock: the pair shares it, the
// standalone instances see the far side as free per-cycle inputs. Glue only.
module qchannel_pair (
  input  logic clk,
  input  logic rst_n,
  input  logic req_dev_quiescence,
  input  logic enb_qactive_led_quiescence_enter,
  input  logic enb_qactive_led_quiescence_exit,
  input  logic dev_quiescent_busy,
  input  logic dev_quiescent_deny,
  input  logic dev_wake,
  output logic dev_stopped,
  output logic dev_quiescent_ok
);
  logic qreqn, qacceptn, qdeny, qactive;
  qchannel_controller u_c (
    .clk, .rst_n, .qreqn, .qacceptn, .qdeny, .qactive,
    .req_dev_quiescence, .enb_qactive_led_quiescence_enter,
    .enb_qactive_led_quiescence_exit, .dev_stopped);
  qchannel_device u_d (
    .clk, .rst_n, .qreqn, .qacceptn, .qdeny, .qactive,
    .dev_quiescent_busy, .dev_quiescent_deny, .dev_wake, .dev_quiescent_ok);
endmodule

module qchannel_fv_top (
  input  logic clk,
  input  logic rst_n,
  // u_dev
  input  logic d_qreqn,
  output logic d_qacceptn, d_qdeny, d_qactive,
  input  logic d_busy, d_deny, d_wake,
  output logic d_ok,
  // u_ctl
  output logic c_qreqn,
  input  logic c_qacceptn, c_qdeny, c_qactive,
  input  logic c_req, c_enter, c_exit,
  output logic c_stopped,
  // u_pair
  input  logic p_req, p_enter, p_exit, p_busy, p_deny, p_wake,
  output logic p_stopped, p_ok
);
  qchannel_device u_dev (
    .clk, .rst_n, .qreqn(d_qreqn), .qacceptn(d_qacceptn), .qdeny(d_qdeny), .qactive(d_qactive),
    .dev_quiescent_busy(d_busy), .dev_quiescent_deny(d_deny), .dev_wake(d_wake),
    .dev_quiescent_ok(d_ok));
  qchannel_controller u_ctl (
    .clk, .rst_n, .qreqn(c_qreqn), .qacceptn(c_qacceptn), .qdeny(c_qdeny), .qactive(c_qactive),
    .req_dev_quiescence(c_req), .enb_qactive_led_quiescence_enter(c_enter),
    .enb_qactive_led_quiescence_exit(c_exit), .dev_stopped(c_stopped));
  qchannel_pair u_pair (
    .clk, .rst_n, .req_dev_quiescence(p_req), .enb_qactive_led_quiescence_enter(p_enter),
    .enb_qactive_led_quiescence_exit(p_exit), .dev_quiescent_busy(p_busy),
    .dev_quiescent_deny(p_deny), .dev_wake(p_wake), .dev_stopped(p_stopped),
    .dev_quiescent_ok(p_ok));
endmodule
