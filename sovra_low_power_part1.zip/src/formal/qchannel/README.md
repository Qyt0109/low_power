# Q-Channel formal properties

Properties for the Q-Channel FSMs
[`src/rtl/qchannel/qchannel_controller.sv`](../../rtl/qchannel/qchannel_controller.sv)
and [`qchannel_device.sv`](../../rtl/qchannel/qchannel_device.sv) (with
`rtl/common/cdc_sync.sv`) against the AMBA Low Power Interface Specification,
ARM IHI 0068C, Section 2.1. Every PPU domain, the LPD-Q, the clock controller
and the adapters reuse these two FSMs.

## Files

| File | Contents |
|---|---|
| `qchannel_fv_top.sv` | `qchannel_fv_top`: three instances side by side on one clock: `u_dev` (the device alone, the controller's QREQn a free input), `u_ctl` (the controller alone, the device's QACCEPTn/QDENY/QACTIVE free inputs), `u_pair` (`qchannel_pair`: the two connected, only the system inputs free). Default parameters (SYNC_STAGES 2). Glue only |
| `qchannel_props.sv` | `qchannel_device_props`, `qchannel_controller_props`, `qchannel_pair_props`, and instance-specific binds (`bind qchannel_device : qchannel_fv_top.u_dev ...`), so the environment assumptions of the standalone instances never constrain the pair |
| `src/signoff/formal/qchannel.tcl` | Top `qchannel_fv_top`; clock `clk`, reset `rst_n`; vacuity on; `check_fv` capped at 60 minutes; `FV_POST` hook |

**Where the properties sit: at the pins.** Each FSM samples the far side
through a two-flop synchroniser, so its own view lags the wires. The protocol
is defined on the wires, and a hazard the synchroniser introduces (an FSM
acting on a stale value) is only visible there, so every rule is checked on the
module's ports, the "from" state of a transition being the wire values one
clock earlier (`$past`). The far side's wires are free inputs that may change
at any clock edge, which covers every relative timing of the two asynchronous
sides as seen at the sampling clock. The R-numbers are those of
`qchannel_monitor.sv`, the simulation checker of the same rules.

## Assumptions

| Instance | Assumptions |
|---|---|
| `u_dev` | `m_ctl_R1`, `m_ctl_R2`: the controller obeys the QREQn rules of 2.1.2 (the initial QREQn is free); `m_fair_idle`: the device is eventually idle or wants to deny (fairness, for the liveness property) |
| `u_ctl` | `m_dev_reset_low` (the device drives QACCEPTn and QDENY LOW at reset), `m_dev_R3`-`m_dev_R6` (the device-side rules), `m_dev_R7` (no illegal state); QACTIVE is unconstrained ("transitions on QACTIVE are not restricted", 2.1.1) |
| `u_pair` | No handshake assumption at all; `m_fair_idle_pair` for its liveness property |

## Properties

| Intent | Properties |
|---|---|
| Device handshake rules (2.1.2) | `a_dev_R3_acc_fall`, `a_dev_R4_acc_rise`, `a_dev_R5_deny_fall`, `a_dev_R6_deny_rise` |
| Device legality | `a_dev_R7_legal` (Table 2-1: never QACCEPTn LOW with QDENY HIGH), `a_dev_one_ack_change` (only one of them changes per transition), `a_dev_reset_low` (device reset), `a_dev_quiescent_ok_acc` (quiescent only once accepted) |
| Device liveness | `a_dev_live_exit` (Q_EXIT is acknowledged), `a_dev_live_continue` (QDENY falls in Q_CONTINUE), `a_dev_live_request` (Q_REQUEST is answered, under fairness) |
| Controller handshake rules | `a_ctl_R1_req_fall`, `a_ctl_R2_req_rise` |
| Controller safety | `a_ctl_stopped_is_q_stopped` (`dev_stopped`, i.e. safe to gate, only in Q_STOPPED on the wires) |
| Controller liveness | `a_ctl_live_denied` (Q_DENIED: the controller deasserts QREQn), `a_ctl_live_wake` (Q_STOPPED with QACTIVE HIGH and the exit policy enabled: QREQn rises unless either is withdrawn) |
| The connected pair | `a_pair_R1`-`a_pair_R7` on the shared wires, `a_pair_one_change` (one wire per transition), `a_pair_live_request` (a held request to an idle, non-denying device reaches Q_STOPPED) |

6 of the 25 are liveness properties (`s_eventually`). Covers (18): on the
device every Table 2-1 transition (RUN → REQUEST → STOPPED → EXIT → RUN,
REQUEST → DENIED → CONTINUE → RUN), a whole Figure 2-2 and Figure 2-3 cycle,
QACTIVE in Q_STOPPED; on the controller a QREQn fall, an exit, a continue,
`dev_stopped`, the Figure 2-7 QACTIVE-led entry and Figure 2-8 exit; on the
pair Q_STOPPED and a whole denied cycle.

## Status

25 of 25 assertions proven (6 liveness), 18 of 18 covers covered, none bounded
(latest run, `build/signoff/formal/qchannel/`).

## Mutants

None in the repository: these FSMs have no planted-fault define, so
`vcformalneg` does not run this block. SIGNOFF_REPORT.md records two scratch
mutants that falsified 15 assertions (run `qchannel_sanity` in the build tree,
15 falsified: device R3-R6, controller R1, R2, `stopped_is_q_stopped`,
`live_denied`, and the pair's R1-R6 and `one_change`); they are not kept as
defines.

## Running

`make -C src vcformal`, with
`VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`. By hand:
`PMU_SRC=<repo>/src [FV_DEFINES="+define+..."]
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/qchannel.tcl`.

## Adding a property

Put it in the props module of the instance it is about, on the pins, with
`$past` for the "from" state. An environment assumption belongs only in the
standalone instances' modules; the pair must stay unconstrained. A liveness
property needs a fairness assumption on the inputs it waits for.

## References

- AMBA Low Power Interface Specification, ARM IHI 0068C, Sections 2.1.1-2.1.3,
  Table 2-1, Figures 2-2, 2-3, 2-6, 2-7, 2-8 (text:
  `build/spec_txt/arm-amba-low-power-interface-spec.txt`, outside git).
- `src/rtl/qchannel/qchannel_monitor.sv` (R1-R7 in simulation);
  [`src/rtl/qchannel/README.md`](../../rtl/qchannel/README.md).
- [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md) Section 6.
- Simulation: [`src/tb/qchannel/`](../../tb/qchannel/README.md).
