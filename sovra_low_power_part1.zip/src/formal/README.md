# Formal properties

SystemVerilog assertion (SVA) properties for the platform blocks whose
correctness is a small set of rules that simulation can only sample: the
SCP's interrupt block and watchdog, the clock/reset bridge, the READY-bit
adapter, the mailbox firewall, the TL-UH gate's data path, and the Q-Channel
FSMs. They are proven with Synopsys VC Formal (FPV) as part of the platform
sign-off (platform plan phase 6, V7). Results and findings:
[`src/signoff/SIGNOFF_REPORT.md`](../signoff/SIGNOFF_REPORT.md) Section 6;
run scripts: [`src/signoff/formal/`](../signoff/formal/README.md).

## Folders

One folder per block. Each holds a bind file (`<block>_props.sv`: a
`<block>_props` module and a `bind` into every instance of the block) and, for
three blocks, a formal top.

| Folder | Block under proof | Files | Assertions | Covers | Mutants (assertions falsified) |
|---|---|---|---:|---:|---|
| [`scp_irq/`](scp_irq/README.md) | `pmu/rtl/scp_irq.sv` | `scp_irq_props.sv` | 52 | 25 | `SOC4_MUT_IRQ_SYNC0` (7) |
| [`scp_wdog/`](scp_wdog/README.md) | `pmu/rtl/scp_wdog.sv` | `scp_wdog_props.sv` | 39 | 12 | `SOC4_MUT_WDOG_CAUSE_SUB` (12) |
| [`ckrst_bridge/`](ckrst_bridge/README.md) | `rtl/ckrst/ckrst_bridge.sv` | `ckrst_bridge_props.sv` | 47 | 17 | `CKRST_MUT_NOLATE` (7) |
| [`hart_ready_adp/`](hart_ready_adp/README.md) | `rtl/adp/hart_ready_adp.sv` | `hart_ready_adp_props.sv` (props, bind and the formal top `hart_ready_adp_fv`) | 63 | 27 | `HART_READY_MUT_NODRAIN` (6), `HART_READY_MUT_SETWINS` (4) |
| [`soc4_mbx/`](soc4_mbx/README.md) | `soc4/rtl/soc4_mbx.sv` | `soc4_mbx_props.sv`, `soc4_mbx_fv_top.sv` | 26 | 18 | `SOC4_MUT_FW_OPEN` (16), `SOC4_MUT_FW_NOMASK` (12) |
| [`tluh_gate/`](tluh_gate/README.md) | `rtl/acg/tluh_gate.sv` | `tluh_gate_props.sv` | 19 | 10 | `ACG_TLUH_MUT_SPLIT` (2), `ACG_TLUH_MUT_ONEBEAT` (4), `ACG_TLUH_MUT_ATOM` (10) |
| [`qchannel/`](qchannel/README.md) | `rtl/qchannel/qchannel_controller.sv`, `qchannel_device.sv` | `qchannel_props.sv`, `qchannel_fv_top.sv` | 25 | 18 | none in the repository |
| | | **Total** | **271** | **127** | **10** |

Status (latest run, `build/signoff/formal/`, 2026-10-06): every assertion
fully proven, every one with an antecedent non-vacuous, every cover covered,
none bounded (`signoff/formal/bounded.txt` is empty). Each mutant falsifies at
least one assertion.

## How the proofs are set up

- **Properties are written against the block's documented rules, not its
  code.** Each props file quotes the header of the RTL file (or the AMBA LPI
  text, for the Q-Channel) above each property, and builds an independent
  reference model from the ports (a synchroniser copy, a count model, a
  message model, a register-map shadow) to compare the RTL against.
- **Naming.** `a_*` assertion, `m_*` / `asm_*` assumption, `c_*` cover,
  `h_*` (and some `a_h_*`) helper invariants: lemmas relating the model to RTL
  internals, proven like any other assertion, there so that induction
  converges at full depth.
- **Assumptions constrain inputs only**, each citing the interface rule it
  comes from (TileLink ready/valid and burst rules, LPI handshake rules,
  documented limits). `scp_irq`, `scp_wdog` and `ckrst_bridge` have none.
- **Reset.** Each script applies the reset for the reset state
  (`sim_run -stable`, `sim_save_reset`) and holds it inactive afterwards,
  except `scp_wdog`, whose subsystem reset `rst_ni` is released as a free
  input.
- **Covers** make each key behaviour reachable, so an assertion cannot pass
  because its antecedent never happens.

## Running

```
make -C src vcformal       # every block, then the summary
make -C src vcformalneg    # the same properties against each planted mutant
```

- `VC_STATIC_HOME` must be `/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`
  (the Makefile default; `vccheck` fails without `bin/vc_static_shell`). The
  Makefile exports it and `PMU_SRC` and calls
  `$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f signoff/formal/<block>.tcl`.
  `vcf -batch` does not work in this install (missing `libQt5Charts.so.5`).
- No simulator is involved; `SIM` is ignored.
- Each run goes to `build/signoff/formal/<block>/` (mutants:
  `<block>_mut_<DEFINE>/`): `run.log`, `vcf.log`, and `fv_list.rpt`
  (`report_fv -list`).
- There is no per-block make target. One block by hand:

  ```
  mkdir -p build/signoff/formal/scp_irq && cd build/signoff/formal/scp_irq
  export VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca PMU_SRC=<repo>/src
  $VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/scp_irq.tcl
  ```

  `FV_DEFINES=+define+<MUTANT>` builds a mutant; some scripts take more
  (`FV_MAX_WAIT`, `FV_TOP`, `FV_POST`; see each folder).

### The verdict

`signoff/common/fv_summary.py` reads every `fv_list.rpt`:

- **vcformal** passes only if every assertion is `proven` and not vacuous and
  every cover is `covered`. An `inconclusive` assertion passes only if
  `signoff/formal/bounded.txt` lists it (`block property depth reason`), and
  it is then reported as a bounded proof with its depth. Anything falsified,
  vacuous, uncoverable or unlisted fails.
- **vcformalneg** passes only if each mutant run falsifies at least one
  assertion. The mutants are the RTL defines of the simulation negative
  controls (`FV_MUTANTS` in `src/Makefile`): the same faults are caught by
  both methods.

`fvtrace` crashes in this install ("DFGSIM cannot execute"), so
counterexamples have been debugged with helper assertions instead.

## Adding a property or a block

- **A property.** Add it to the block's props module, quoting the rule it
  checks above it, with the `a_` / `c_` prefix, and a cover for its
  antecedent. If it needs a new environment constraint, make it an `m_`
  assumption on an input and cite the interface rule. Re-run `vcformal`; if it
  cannot be fully proven, either add a helper invariant or list it in
  `bounded.txt` with the depth reached and the reason (and say so in the
  report).
- **A mutant.** Add the `` `ifdef `` to the RTL (ideally shared with a
  simulation negative control) and `<block>:<DEFINE>` to `FV_MUTANTS`.
- **A block.** Create `src/formal/<block>/<block>_props.sv` with the props
  module and the `bind`; a formal top beside it if the block needs
  surroundings or fixed parameters; a script `signoff/formal/<block>.tcl`
  modelled on an existing one (it must write `fv_list.rpt` in the current
  directory); add `<block>` to `FV_BLOCKS` in `src/Makefile`; and a README
  here.

## References

- [`src/signoff/SIGNOFF_REPORT.md`](../signoff/SIGNOFF_REPORT.md) Section 6:
  per-block results, mutants, and the findings F-TLUH-1/2, F-ADP-1..3,
  F-WDOG-1, F-CKRST-1.
- [`src/signoff/formal/README.md`](../signoff/formal/README.md): the run
  scripts and their environment variables.
- `src/signoff/common/fv_summary.py`; `src/Makefile` (`vcformal`,
  `vcformalneg`, `FV_BLOCKS`, `FV_MUTANTS`).
- The simulation side of the same blocks: [`src/tb/`](../tb/README.md).
