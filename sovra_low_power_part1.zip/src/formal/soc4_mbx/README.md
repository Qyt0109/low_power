# soc4_mbx formal properties

Properties for [`src/soc4/rtl/soc4_mbx.sv`](../../soc4/rtl/soc4_mbx.sv), the
soc4 RPMI mailbox: per agent a 1 KB queue window and a doorbell page on the
agent's own TL-UL port, behind a firewall entry (FW_EN, FW_VAL, FW_MASK on
`a_source`) that the SCP programs; the doorbell rings RING[k] into the SCP.
The properties are the security claims of its header (the register map, "AN
AGENT'S VIEW", "THE SCP'S VIEW"): no agent reaches another agent's window, and
nothing reaches any window before the SCP allows it.

## Files

| File | Contents |
|---|---|
| `soc4_mbx_props.sv` | `soc4_mbx_props` and its `bind` into every `soc4_mbx`: a shadow of the firewall registers re-modelled from the SCP register pins, the windows from `TL_BASE + k * 0x2000`, admission judged at the TL-UL port pins at the A handshake, per-agent pending counts, and the properties below |
| `soc4_mbx_fv_top.sv` | `soc4_mbx_fv_top`: the mailbox with soc4_top's parameters (2 agents, 2 ports, `AGENT_PORT = {1, 0}`, `PORT_HAS_A_USER = 2'b01`, `TL_BASE` 0x2000_0000). `soc4_mbx_fv_top_shared`: both agents on one port, so the `a_source` check is the only thing separating them |
| `src/signoff/formal/soc4_mbx.tcl` | Reads the vendored OpenTitan TL-UL files, `tc_sram`, `soc4_tl_bound`, `soc4_mbx`; black-boxes `tc_sram` (its read data becomes a free input); vacuity checks on. `FV_TOP=soc4_mbx_fv_top_shared` selects the shared top |

## Assumptions

Only on the black-boxed memory's read data, to make data leaks observable:
`m_rdata_tag` (window k's read port returns a free constant `tag[k]`),
`m_tag_legal` (no tag byte is 0x00 or 0xFF, the only constants the response
path makes itself: zeroed lanes, doorbell reads, error data), `m_tag_distinct`
(tag bytes differ per window). Then any byte lane of a port's `d_data` equal to
the same lane of `tag[k]` means window k's data reached that port.

## Properties

Per agent k (`g_adm[k]`):

| Intent | Properties |
|---|---|
| Only admitted requests reach agent k's devices | `a_win_admitted` (the queue window), `a_db_admitted` (the doorbell page): every request at agent k's adapter was admitted on port AGENT_PORT[k] with FW_EN[k] and `(a_source & FW_MASK[k]) == FW_VAL[k]` in the cycle it was accepted |
| Deny-all from reset | `a_deny_all_from_reset`: nothing reaches agent k before the SCP has written FW_EN[k] = 1 |
| The queue memory port stays in window k | `a_qmem_in_window` (port 1 + k only addresses words k*256..k*256+255), `a_qmem_admitted` (and only for an admitted request) |
| The doorbell | `a_ring_set_by_admitted_db` (RING[k] rises only after an admitted write to doorbell offset 0), `a_ring_set` (and does rise for every one), `a_ring_clear_only_w1c`, `a_ring_clear` (DB_CLEAR, byte lanes honoured; a ring in the same cycle wins) |
| Helpers (also spec checks) | `a_fw_regs_match` (the firewall registers equal the register-map model, reset values included), `a_pend_q_bound`, `a_pend_db_bound` |

Across agents: `a_no_cross_read` (for each window and each port that does not
carry its agent, no byte of that window's data ever appears in `d_data`).

Covers (8 per agent + 2): a window write and read, a ring rise and fall, a
ring and a clear together, a request denied with FW_EN set, an admission with
a mask that is not all ones, a pass-through in one cycle; and each window's
data seen on its own port.

## Status

26 of 26 assertions proven, 18 of 18 covers covered, none bounded (latest run,
`build/signoff/formal/soc4_mbx/`). With both agents on one port
(`soc4_mbx_fv_top_shared`, run `soc4_mbx_shared`): 24 of 24 proven (no
cross-port assertion there).

## Mutants

| Define | Fault | Falsified |
|---|---|---|
| `SOC4_MUT_FW_OPEN` | FW_EN resets to 1 | 16: for both agents `a_win_admitted`, `a_db_admitted`, `a_deny_all_from_reset`, `a_fw_regs_match`, `a_qmem_admitted`, `a_ring_set_by_admitted_db`, `a_pend_q_bound`, `a_pend_db_bound` |
| `SOC4_MUT_FW_NOMASK` | the firewall ignores FW_MASK | 12: for both agents `a_win_admitted`, `a_db_admitted`, `a_qmem_admitted`, `a_ring_set_by_admitted_db`, `a_pend_q_bound`, `a_pend_db_bound` |

They are soc4neg's M2 and M5 in simulation (`[chk:FW_RESET_DENY]`,
`[chk:FW_MASK]`).

## Running

`make -C src vcformal` / `vcformalneg`, with
`VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`. By hand:
`PMU_SRC=<repo>/src [FV_DEFINES=+define+SOC4_MUT_FW_OPEN] [FV_TOP=soc4_mbx_fv_top_shared]
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/soc4_mbx.tcl`
(`FV_POST=<tcl>` sources a debug script after the proof). The shared-port run
is not part of `make vcformal`.

## Adding a property

State it against the header's register map and agent view (the `sh_*`
shadow, `win_q`/`win_db`, `adm_*`), not the RTL decode. The memory is a black
box: properties on it must be on its request pins (`q_req`, `q_we`, `q_addr`)
or on the data path out of it.

## References

- `src/soc4/rtl/soc4_mbx.sv` header; `src/soc4/rtl/soc4_tl_bound.sv`;
  `vendor/opentitan/tlul/tlul_socket_1n.sv`, `tlul_adapter_sram.sv`.
- Platform plan H11-H13; [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md).
- [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md) Section 6.
- Simulation: R0, R1, B0, B2, B10 of [`soc4_tb`](../../tb/soc4/README.md).
