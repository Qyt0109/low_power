`timescale 1ns/1ps
// Formal properties of soc4_mbx (Phase 6 sign-off, VC Formal FPV), bound into
// every soc4_mbx instance by the bind at the end of this file. Script:
// src/signoff/formal/soc4_mbx.tcl.
//
// Every property is stated against the register map and the agent view that
// soc4_mbx.sv documents in its header (the "spec" here), not against the RTL's
// own decode: the firewall entries are re-modelled from the SCP register
// interface pins (sh_en/sh_val/sh_mask), the windows from TL_BASE + k * 0x2000,
// and admission is judged at the TL-UL port pins, where the request is
// accepted (a_valid && a_ready). The decision the socket uses (dev_select_i)
// is captured with the request at that handshake (tlul_socket_1n.sv: the
// select travels in the host FIFO's spare bits), so that is the moment the
// firewall state must allow it.
//
// The shared queue memory (tc_sram) is blackboxed by the script: its read data
// q_rdata[] becomes a free input, and every memory property is proved on the
// request path into it (req/we/addr of port 1 + k) and on the data path out of
// it (the read data that reaches a port).
//
// Naming: a_* assertion, m_* assumption, c_* cover.

module soc4_mbx_props #(
  parameter int unsigned                NUM_AGENTS = 2,
  parameter int unsigned                NUM_PORTS  = 2,
  parameter logic [NUM_AGENTS-1:0][3:0] AGENT_PORT = {4'd1, 4'd0},
  parameter logic [31:0]                TL_BASE    = 32'h2000_0000,
  parameter int unsigned                QW         = 9
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,
  input  tlul_pkg::tl_h2d_t            tl_h_i [NUM_PORTS],
  input  tlul_pkg::tl_d2h_t            tl_h_o [NUM_PORTS],
  input  logic                         reg_req_i,
  input  logic                         reg_we_i,
  input  logic [3:0]                   reg_be_i,
  input  logic [31:0]                  reg_addr_i,
  input  logic [31:0]                  reg_wdata_i,
  input  logic [NUM_AGENTS-1:0]        db_irq_o,
  // internals: each agent's two devices as its port's socket presents them,
  // the queue-memory ports, the firewall registers and the doorbell strobe
  input  tlul_pkg::tl_h2d_t            ag_mem_h [NUM_AGENTS],
  input  tlul_pkg::tl_d2h_t            ag_mem_d [NUM_AGENTS],
  input  tlul_pkg::tl_h2d_t            ag_db_h  [NUM_AGENTS],
  input  tlul_pkg::tl_d2h_t            ag_db_d  [NUM_AGENTS],
  input  logic [NUM_AGENTS:0]          q_req,
  input  logic [NUM_AGENTS:0]          q_we,
  input  logic [NUM_AGENTS:0][QW-1:0]  q_addr,
  input  logic [NUM_AGENTS:0][31:0]    q_rdata,
  input  logic [NUM_AGENTS-1:0]        fw_en_q,
  input  logic [7:0]                   fw_val_q  [NUM_AGENTS],
  input  logic [7:0]                   fw_mask_q [NUM_AGENTS],
  input  logic [NUM_AGENTS-1:0]        db_we_ok
);
  import tlul_pkg::*;

  localparam logic [31:0] WIN_STRIDE = 32'h2000;      // soc4_mbx.sv header: W = TL_BASE + k * 0x2000

  // ---------------------------------------------------------------------------
  // Spec model of the SCP register interface (soc4_mbx.sv header register map)
  // ---------------------------------------------------------------------------
  logic [11:0] off;
  logic        reg_wr;
  assign off    = {reg_addr_i[11:2], 2'b00};
  assign reg_wr = reg_req_i && reg_we_i;

  // FW_EN[k] 0x100+0x20k RW reset 0, [0]; FW_VAL[k] 0x104+0x20k RW reset 0x00
  // [7:0]; FW_MASK[k] 0x108+0x20k RW reset 0xFF [7:0]; byte fields take lane 0.
  logic [NUM_AGENTS-1:0] sh_en, en_ever;
  logic [7:0]            sh_val  [NUM_AGENTS];
  logic [7:0]            sh_mask [NUM_AGENTS];

  for (genvar k = 0; k < NUM_AGENTS; k++) begin : g_shadow
    localparam logic [11:0] OEN  = 12'h100 + 12'(k) * 12'h20;
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        sh_en[k]   <= 1'b0;
        en_ever[k] <= 1'b0;
        sh_val[k]  <= 8'h00;
        sh_mask[k] <= 8'hFF;
      end else if (reg_wr && reg_be_i[0]) begin
        if (off == OEN) begin
          sh_en[k] <= reg_wdata_i[0];
          if (reg_wdata_i[0]) en_ever[k] <= 1'b1;
        end
        if (off == OEN + 12'h4) sh_val[k]  <= reg_wdata_i[7:0];
        if (off == OEN + 12'h8) sh_mask[k] <= reg_wdata_i[7:0];
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Spec model of admission at the TL-UL port pins (soc4_mbx.sv header, "AN
  // AGENT'S VIEW"): window k is W+0x000-0x3FF, doorbell page W+0x1000-0x1FFF;
  // admitted only on port AGENT_PORT[k], only if FW_EN[k] and
  // (a_source & FW_MASK[k]) == FW_VAL[k].
  // ---------------------------------------------------------------------------
  function automatic logic win_q(input logic [31:0] a, input int unsigned k);
    logic [31:0] w;
    w = TL_BASE + 32'(k) * WIN_STRIDE;
    return a[31:10] == w[31:10];
  endfunction
  function automatic logic win_db(input logic [31:0] a, input int unsigned k);
    logic [31:0] w;
    w = TL_BASE + 32'(k) * WIN_STRIDE + 32'h1000;
    return a[31:12] == w[31:12];
  endfunction

  logic [NUM_PORTS-1:0]  hs;                  // A handshake at port p's pins
  logic [NUM_AGENTS-1:0] adm_q, adm_db;       // admitted to agent k's window / doorbell page
  logic [NUM_AGENTS-1:0] hs_q, hs_db;         // A handshake at agent k's window / doorbell device
  logic [NUM_AGENTS-1:0] ok_now;

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_hs
    assign hs[p] = tl_h_i[p].a_valid && tl_h_o[p].a_ready;
  end

  for (genvar k = 0; k < NUM_AGENTS; k++) begin : g_adm
    localparam int unsigned P = AGENT_PORT[k];
    assign ok_now[k] = sh_en[k] && ((tl_h_i[P].a_source & sh_mask[k]) == sh_val[k]);
    assign adm_q[k]  = hs[P] && win_q (tl_h_i[P].a_address, k) && ok_now[k];
    assign adm_db[k] = hs[P] && win_db(tl_h_i[P].a_address, k) && ok_now[k];
    assign hs_q[k]   = ag_mem_h[k].a_valid && ag_mem_d[k].a_ready;
    assign hs_db[k]  = ag_db_h[k].a_valid  && ag_db_d[k].a_ready;

    // Admitted requests not yet handed to agent k's device. The socket holds
    // at most one request in its host FIFO and one in each device FIFO
    // (tlul_socket_1n defaults, depth 1), so a 3-bit count never wraps
    // (a_pend_*_bound below proves it).
    logic [2:0] pend_q, pend_db;
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        pend_q  <= '0;
        pend_db <= '0;
      end else begin
        pend_q  <= pend_q  + 3'(adm_q[k])  - 3'(hs_q[k]);
        pend_db <= pend_db + 3'(adm_db[k]) - 3'(hs_db[k]);
      end
    end

    // ---- Firewall: only admitted requests reach agent k's devices ----

    // H12 / header "window k while !FW_EN[k] or (a_source & FW_MASK[k]) !=
    // FW_VAL[k]: d_error, no effect", and "a port decodes only the windows of
    // its own agents": every request that reaches agent k's queue-window
    // adapter was admitted at port AGENT_PORT[k] by the firewall state of the
    // cycle it was accepted.
    a_win_admitted: assert property (@(posedge clk_i) disable iff (!rst_ni)
      hs_q[k] |-> (pend_q != 0) || adm_q[k]);
    // The same for the doorbell page.
    a_db_admitted: assert property (@(posedge clk_i) disable iff (!rst_ni)
      hs_db[k] |-> (pend_db != 0) || adm_db[k]);

    // Deny-all from reset (header: "every FW_EN is 0 from reset (deny-all)
    // whatever the SCP does"): nothing reaches agent k's devices before the
    // SCP has written FW_EN[k] = 1.
    a_deny_all_from_reset: assert property (@(posedge clk_i) disable iff (!rst_ni)
      (hs_q[k] || hs_db[k]) |-> en_ever[k]);

    // ---- Memory request path (tc_sram blackboxed) ----

    // "No write by A lands in B's window": memory port 1 + k only ever
    // addresses window k (words k*256 .. k*256+255, header "THE SCP'S VIEW":
    // window k at + k * 0x400) ...
    a_qmem_in_window: assert property (@(posedge clk_i) disable iff (!rst_ni)
      q_req[1 + k] |-> q_addr[1 + k][QW-1:8] == (QW-8)'(k));
    // ... and only for a request admitted to window k (the port is driven by
    // agent k's adapter alone, in the cycle it accepts the request).
    a_qmem_admitted: assert property (@(posedge clk_i) disable iff (!rst_ni)
      q_req[1 + k] |-> hs_q[k] && ((pend_q != 0) || adm_q[k]));

    // ---- Doorbell RING[k] = db_irq_o[k] ----

    // DB_STATUS: "bit k sticky; set by an accepted write to doorbell k": RING[k]
    // rises only after a write accepted by agent k's doorbell device at page
    // offset 0 (W + 0x1000; "W + 0x1004-1FFF d_error, no effect") that the
    // firewall admitted.
    a_ring_set_by_admitted_db: assert property (@(posedge clk_i) disable iff (!rst_ni)
      $rose(db_irq_o[k]) |->
        $past(hs_db[k] && ((pend_db != 0) || adm_db[k])
              && (ag_db_h[k].a_opcode inside {PutFullData, PutPartialData})
              && (ag_db_h[k].a_address[11:2] == 10'd0)));
    // ... and does rise for every accepted doorbell write, a DB_CLEAR in the
    // same cycle notwithstanding (DB_CLEAR: "A ring in the same cycle wins").
    a_ring_set: assert property (@(posedge clk_i) disable iff (!rst_ni)
      db_we_ok[k] |=> db_irq_o[k]);
    // DB_CLEAR (0x004, WO, W1C, "DB_CLEAR honours every lane"): RING[k] falls
    // only by a DB_CLEAR write with bit k set in an enabled lane ...
    a_ring_clear_only_w1c: assert property (@(posedge clk_i) disable iff (!rst_ni)
      $fell(db_irq_o[k]) |->
        $past(reg_wr && off == 12'h004 && reg_wdata_i[k] && reg_be_i[k / 8]));
    // ... and such a write clears it unless a ring arrives in the same cycle.
    a_ring_clear: assert property (@(posedge clk_i) disable iff (!rst_ni)
      reg_wr && off == 12'h004 && reg_wdata_i[k] && reg_be_i[k / 8] && !db_we_ok[k]
        |=> !db_irq_o[k]);

    // Helpers (make the induction easy; each is also a spec check): the
    // firewall registers equal the register-map model, and the pending counts
    // stay small.
    a_fw_regs_match: assert property (@(posedge clk_i) disable iff (!rst_ni)
      fw_en_q[k] == sh_en[k] && fw_val_q[k] == sh_val[k] && fw_mask_q[k] == sh_mask[k]);
    a_pend_q_bound:  assert property (@(posedge clk_i) disable iff (!rst_ni) pend_q  <= 3'd2);
    a_pend_db_bound: assert property (@(posedge clk_i) disable iff (!rst_ni) pend_db <= 3'd2);

    // ---- Covers (anti-vacuity) ----
    c_win_write:  cover property (@(posedge clk_i) disable iff (!rst_ni) q_req[1 + k] && q_we[1 + k]);
    c_win_read:   cover property (@(posedge clk_i) disable iff (!rst_ni) q_req[1 + k] && !q_we[1 + k]);
    c_ring_rise:  cover property (@(posedge clk_i) disable iff (!rst_ni) $rose(db_irq_o[k]));
    c_ring_fall:  cover property (@(posedge clk_i) disable iff (!rst_ni) $fell(db_irq_o[k]));
    c_ring_wins:  cover property (@(posedge clk_i) disable iff (!rst_ni)
      db_we_ok[k] && reg_wr && off == 12'h004 && reg_wdata_i[k] && reg_be_i[k / 8]);
    // a request to window k that the entry denies, with FW_EN[k] set
    c_denied_src: cover property (@(posedge clk_i) disable iff (!rst_ni)
      hs[P] && win_q(tl_h_i[P].a_address, k) && sh_en[k] && !ok_now[k]);
    // admitted with a mask that is not all ones (the mask matters)
    c_masked_adm: cover property (@(posedge clk_i) disable iff (!rst_ni)
      adm_q[k] && sh_mask[k] != 8'hFF && (tl_h_i[P].a_source != sh_val[k]));
    // the pass-through case: admitted and handed to the device in one cycle
    c_pass:       cover property (@(posedge clk_i) disable iff (!rst_ni) adm_q[k] && hs_q[k]);
  end

  // ---------------------------------------------------------------------------
  // No read data of B's window reaches a port that does not carry B. The
  // memory is blackboxed, so q_rdata[1 + k] (window k's read port) is free: a
  // free constant tag tag[k] is driven onto it (m_rdata_tag). The response
  // path moves data and at most zeroes byte lanes (tlul_adapter_sram.sv:542,
  // rdata & rmask for a partial read; DataXorAddr = 0, no other transform),
  // and the only constants it makes itself are 0 (doorbell read data,
  // tlul_adapter_reg rdata_i; masked lanes) and all ones (tlul_pkg
  // DataWhenError: write and error responses). So each byte of each tag is
  // assumed to be neither 0x00 nor 0xFF and to differ from the same byte of
  // every other tag: then any byte lane of port p's d_data equal to the same
  // lane of tag[k] means some of window k's data reached port p -- the
  // assertion checks every lane, so even a one-byte leak is caught.
  // ---------------------------------------------------------------------------
  // tag[k]: a flop with no reset that holds its value, so its initial value
  // (X after the reset simulation) is a free symbolic constant for the formal
  // engines (an undriven net would be a free value at every use).
  logic [31:0] tag [NUM_AGENTS];

  for (genvar k = 0; k < NUM_AGENTS; k++) begin : g_tag
    always_ff @(posedge clk_i) tag[k] <= tag[k];
    // the blackboxed memory returns tag[k] on window k's read port
    m_rdata_tag:  assume property (@(posedge clk_i) q_rdata[1 + k] == tag[k]);
    for (genvar b = 0; b < 4; b++) begin : g_lane
      // no tag byte is one of the constants the response path makes itself
      m_tag_legal: assume property (@(posedge clk_i)
        tag[k][8*b +: 8] != 8'h00 && tag[k][8*b +: 8] != 8'hFF);
      for (genvar k2 = 0; k2 < NUM_AGENTS; k2++) begin : g_tag2
        if (k2 != k) begin : g_ne
          // tag bytes differ per window, so each byte identifies its window
          m_tag_distinct: assume property (@(posedge clk_i) tag[k][8*b +: 8] != tag[k2][8*b +: 8]);
        end
      end
    end
    for (genvar p = 0; p < NUM_PORTS; p++) begin : g_port
      if (AGENT_PORT[k] != p) begin : g_other
        // no byte of window k's data ever appears on a port that does not
        // carry agent k ("agent A can never reach agent B's window")
        a_no_cross_read: assert property (@(posedge clk_i) disable iff (!rst_ni)
          tl_h_o[p].d_valid |->
            tl_h_o[p].d_data[7:0]   != tag[k][7:0]   && tl_h_o[p].d_data[15:8]  != tag[k][15:8] &&
            tl_h_o[p].d_data[23:16] != tag[k][23:16] && tl_h_o[p].d_data[31:24] != tag[k][31:24]);
      end else begin : g_own
        // anti-vacuity: it does appear on its own port
        c_own_read: cover property (@(posedge clk_i) disable iff (!rst_ni)
          tl_h_o[p].d_valid && !tl_h_o[p].d_error && tl_h_o[p].d_data == tag[k]);
      end
    end
  end

endmodule

bind soc4_mbx soc4_mbx_props #(
  .NUM_AGENTS(NUM_AGENTS),
  .NUM_PORTS (NUM_PORTS),
  .AGENT_PORT(AGENT_PORT),
  .TL_BASE   (TL_BASE),
  .QW        (QW)
) u_soc4_mbx_props (
  .clk_i      (clk_i),
  .rst_ni     (rst_ni),
  .tl_h_i     (tl_h_i),
  .tl_h_o     (tl_h_o),
  .reg_req_i  (reg_req_i),
  .reg_we_i   (reg_we_i),
  .reg_be_i   (reg_be_i),
  .reg_addr_i (reg_addr_i),
  .reg_wdata_i(reg_wdata_i),
  .db_irq_o   (db_irq_o),
  .ag_mem_h   (ag_mem_h),
  .ag_mem_d   (ag_mem_d),
  .ag_db_h    (ag_db_h),
  .ag_db_d    (ag_db_d),
  .q_req      (q_req),
  .q_we       (q_we),
  .q_addr     (q_addr),
  .q_rdata    (q_rdata),
  .fw_en_q    (fw_en_q),
  .fw_val_q   (fw_val_q),
  .fw_mask_q  (fw_mask_q),
  .db_we_ok   (db_we_ok)
);
