`timescale 1ns/1ps
// FPV top for soc4_mbx: the mailbox with soc4_top's parameters (soc4_top.sv
// MBX_AGENTS = 2, MBX_PORTS = 2, MBX_AGENT_PORT = {1, 0}, MBX_HAS_A_USER =
// 2'b01, TL_BASE default 0x2000_0000), every port a primary input/output.
// Glue only. Script: src/signoff/formal/soc4_mbx.tcl.
module soc4_mbx_fv_top (
  input  logic              clk_i,
  input  logic              rst_ni,
  input  tlul_pkg::tl_h2d_t tl_h_i [2],
  output tlul_pkg::tl_d2h_t tl_h_o [2],
  input  logic              reg_req_i,
  input  logic              reg_we_i,
  input  logic [3:0]        reg_be_i,
  input  logic [31:0]       reg_addr_i,
  input  logic [31:0]       reg_wdata_i,
  output logic              reg_rvalid_o,
  output logic [31:0]       reg_rdata_o,
  output logic              reg_err_o,
  input  logic              mem_req_i,
  input  logic              mem_we_i,
  input  logic [3:0]        mem_be_i,
  input  logic [31:0]       mem_addr_i,
  input  logic [31:0]       mem_wdata_i,
  output logic              mem_rvalid_o,
  output logic [31:0]       mem_rdata_o,
  output logic              mem_err_o,
  output logic [1:0]        db_irq_o
);
  soc4_mbx #(
    .NUM_AGENTS     (2),
    .NUM_PORTS      (2),
    .AGENT_PORT     ({4'd1, 4'd0}),
    .PORT_HAS_A_USER(2'b01)
  ) u_mbx (.*);
endmodule

// Stated override (FV_TOP=soc4_mbx_fv_top_shared): both agents on ONE port
// (NUM_PORTS = 1, AGENT_PORT = {0, 0}), so the firewall's a_source check is
// the only thing keeping agent 0 out of window 1 and agent 1 out of window 0.
module soc4_mbx_fv_top_shared (
  input  logic              clk_i,
  input  logic              rst_ni,
  input  tlul_pkg::tl_h2d_t tl_h_i [1],
  output tlul_pkg::tl_d2h_t tl_h_o [1],
  input  logic              reg_req_i,
  input  logic              reg_we_i,
  input  logic [3:0]        reg_be_i,
  input  logic [31:0]       reg_addr_i,
  input  logic [31:0]       reg_wdata_i,
  output logic              reg_rvalid_o,
  output logic [31:0]       reg_rdata_o,
  output logic              reg_err_o,
  input  logic              mem_req_i,
  input  logic              mem_we_i,
  input  logic [3:0]        mem_be_i,
  input  logic [31:0]       mem_addr_i,
  input  logic [31:0]       mem_wdata_i,
  output logic              mem_rvalid_o,
  output logic [31:0]       mem_rdata_o,
  output logic              mem_err_o,
  output logic [1:0]        db_irq_o
);
  soc4_mbx #(
    .NUM_AGENTS     (2),
    .NUM_PORTS      (1),
    .AGENT_PORT     ({4'd0, 4'd0}),
    .PORT_HAS_A_USER(1'b1)
  ) u_mbx (.*);
endmodule
