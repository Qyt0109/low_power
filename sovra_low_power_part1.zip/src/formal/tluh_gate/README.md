# tluh_gate formal properties

Properties for [`src/rtl/acg/tluh_gate.sv`](../../rtl/acg/tluh_gate.sv), the
TL-UH data path of the access control gate `acg_tluh`: it routes each message
to the device or, while gated on the error path, to an error responder, and
must never cut a burst. The rules are the RTL header's rules 1-3 (a burst in
progress completes; every beat of a denied message is answered; the device
never sees part of a message), with the burst rule of `tluh_pkg.sv` and the
encodings of `vendor/sovra_tl/tl_pkg.sv`. The TileLink specification is not in
the repository, so it is not cited.

## Files

| File | Contents |
|---|---|
| `tluh_gate_props.sv` | `tluh_gate_props` and its `bind`: reference encodings written out again from `tl_pkg.sv` (so a mutant of `tluh_pkg` changes the design and not the model), the host and device environment, a reference model of message boundaries and routes (`h_left`, `h_route_dev`, `d_out`, `dd_left`, the owed error response `e_*`), and the properties below. The bind also connects six RTL internals for the helper invariants |
| `src/signoff/formal/tluh_gate.tcl` | Top `tluh_gate` with its defaults (AW 32, DW 64, SRCW 8, SINKW 1, SZW 4, OUTSTANDING 16), `+define+SYNTHESIS`; `flush_req_i` and `err_en_i` free (so the proof holds for any controller, `acg_ctrl` included); vacuity on; `check_fv` capped at 60 minutes |

## Assumptions (a legal TL-UH host and device)

| Assumption | Rule |
|---|---|
| `m_host_a_hold` | An A beat once offered is held unchanged until accepted |
| `m_host_tluh_op` | TL-UH opcodes only (no AcquireBlock/AcquirePerm) |
| `m_host_size` | No message larger than MAX_SIZE = 12 (4 KiB, the largest `tl_beat_cnt` counts) |
| `m_host_burst_const` | Opcode and size constant across a message's beats |
| `m_dev_d_hold` | A D beat once offered is held unchanged until accepted |
| `m_dev_d_legal` | TL-UH D opcodes only, size within MAX_SIZE |
| `m_dev_d_answers` | A D message only answers an outstanding A message |
| `m_dev_d_burst_const` | Opcode and size constant across a D message's beats |

## Properties

| Intent | Properties |
|---|---|
| Rule 1: the device sees whole messages, exactly as sent | `a_dev_only_host_beats` (a device beat is the host's beat, unchanged), `a_dev_fire_is_host_fire` (no beat lost or duplicated), `a_dev_burst_completes` (a burst that started at the device continues there whatever flush/err do), `a_denied_burst_not_dev`, `a_denied_burst_absorbed` |
| Gating | `a_no_new_dev_when_gated` (no new message to the device while a flush or error is requested), `a_denied_only_err_drained` (a message is denied only on the error path and only once the device owes nothing), `a_flush_ack_drained`, `a_resp_pending_exact`, `a_dev_out_bound` (at most OUTSTANDING in flight) |
| Rule 2: every beat of a denied message is answered, with no extras | `a_err_exclusive`, `a_err_after_last_a`, `a_err_beats_offered`, `a_err_beat_shape` (the request's response opcode, size and source; denied; corrupt iff AccessAckData; param and sink 0), `a_d_is_dev_otherwise` (outside an error response the host's D channel is the device's), `a_d_hold` |
| Helper invariants | `a_h_model_a`, `a_h_model_d`, `a_h_model_err`: the model equals the RTL's route, beat counters, outstanding count and error-responder state |

Covers (10): an 8-beat burst at the device, a flush and an error request each
in the middle of a device burst, a new message held while the device drains, a
denied 8-beat Get, a denied 4-beat Put, a denied 2-beat atomic, `flush_ack_o`,
a device D burst's last beat, and `c_dev_a_withdrawn` (see F-TLUH-1).

## Status

19 of 19 assertions proven, 10 of 10 covers covered, none bounded (latest run,
`build/signoff/formal/tluh_gate/`).

## Mutants

| Define | Fault | Falsified |
|---|---|---|
| `ACG_TLUH_MUT_SPLIT` | the route decided again at every beat | 2: `a_denied_burst_absorbed`, `a_dev_burst_completes` |
| `ACG_TLUH_MUT_ONEBEAT` | one error beat whatever the request | 4: `a_err_beat_shape`, `a_err_beats_offered`, `a_err_exclusive`, `a_h_model_err` |
| `ACG_TLUH_MUT_ATOM` | the atomics counted as messages without A data | 10: `a_d_is_dev_otherwise`, `a_denied_burst_absorbed`, `a_denied_burst_not_dev`, `a_dev_burst_completes`, `a_err_after_last_a`, `a_flush_ack_drained`, `a_h_model_a`, `a_h_model_d`, `a_h_model_err`, `a_resp_pending_exact` |

They are three of the four `make acgtluh` negative controls; the fourth,
`ACG_TLUH_MUT_NOWAKE`, is in `acg_tluh`, outside this block.

## Findings (open, SIGNOFF_REPORT.md Section 6)

- F-TLUH-1: `dev_a_valid_o` can be withdrawn before the device accepts a first
  beat, when `flush_req_i`/`err_en_i` rises (cover `c_dev_a_withdrawn`, depth
  2). If TileLink requires valid to stay up until ready, as is assumed of the
  host, this is a protocol violation; it needs the TileLink text and a design
  decision.
- F-TLUH-2: no message-size guard: `a_size` ≥ LOG2_BYTES + 10 is truncated by
  `tl_beat_cnt` (CNT_W 10).

## Running

`make -C src vcformal` / `vcformalneg`, with
`VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`. By hand:
`PMU_SRC=<repo>/src [FV_DEFINES=+define+ACG_TLUH_MUT_SPLIT]
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/tluh_gate.tcl`.

## Adding a property

Use the reference model (`h_*`, `dd_*`, `d_out`, `e_*`) and the `r_*`
encoding functions, never `tluh_pkg`'s functions: the model must stay
independent of the code under test. If the RTL's state encodings change, the
three helper invariants must follow.

## References

- `src/rtl/acg/tluh_gate.sv` header (rules 1-3); `src/rtl/tluh/tluh_pkg.sv`,
  `tl_beat_cnt.sv`; `vendor/sovra_tl/tl_pkg.sv`.
- PCSA DEN 0050D Section 7.2.8 (drain, then block).
- [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md) Section 6.
- Simulation: [`src/tb/acg/`](../../tb/acg/README.md) (`acgtluh`).
