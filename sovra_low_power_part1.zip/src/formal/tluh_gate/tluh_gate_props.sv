`timescale 1ns/1ps
// Formal properties of tluh_gate (src/rtl/acg/tluh_gate.sv), the TL-UH data
// path of acg_tluh (Phase 6 sign-off, VC Formal FPV), bound into every
// tluh_gate by the bind at the end of this file. Script:
// src/signoff/formal/tluh_gate.tcl (tluh_gate as the top).
//
// The control inputs flush_req_i and err_en_i are FREE: the properties hold
// for any controller, so for the unmodified acg_ctrl that drives them in
// acg_tluh as well.
//
// CITATIONS. The TileLink specification text is not in the repository, so
// no section of it is cited. The burst and response rules are cited from the
// repository's own statements of them: tluh_pkg.sv header (which A/D messages
// carry data; "a message with data whose size (2^size bytes) exceeds one beat
// (2^LOG2_BYTES bytes) is 2^(size - LOG2_BYTES) beats; every other message is
// one beat"), tl_beat_cnt.sv header ("TileLink keeps a message's beats
// contiguous on its channel and its size field constant across them"), the
// encodings of vendor/sovra_tl/tl_pkg.sv:36-43 and 62-64 (A opcodes and the D
// message each is answered with; D opcodes), and tluh_gate.sv header rules
// 1-3. Every encoding below is written out again here from tl_pkg.sv (not
// taken from tluh_pkg's functions, so a mutant of tluh_pkg -- e.g.
// ACG_TLUH_MUT_ATOM -- changes the design and not the reference model).
//
// Naming: a_* assertion, m_* assumption, c_* cover.

module tluh_gate_props
  import tl_pkg::*;
#(
  parameter int unsigned AW          = 32,
  parameter int unsigned DW          = 64,
  parameter int unsigned SRCW        = 8,
  parameter int unsigned SINKW       = 1,
  parameter int unsigned SZW         = 4,
  parameter int unsigned OUTSTANDING = 16,
  // The largest message the link carries, log2 bytes. 12 = 4 KiB = 512 beats
  // of 8 bytes: the largest power-of-two message tl_beat_cnt's CNT_W = 10
  // counts ("beats per message up to 2^CNT_W - 1", tl_beat_cnt.sv:18).
  parameter int unsigned MAX_SIZE    = 12,
  localparam int unsigned BW         = DW / 8
) (
  input logic             clk_i,
  input logic             rst_ni,
  input logic             a_valid_i,
  input logic             a_ready_o,
  input logic [2:0]       a_opcode_i,
  input logic [2:0]       a_param_i,
  input logic [SZW-1:0]   a_size_i,
  input logic [SRCW-1:0]  a_source_i,
  input logic [AW-1:0]    a_address_i,
  input logic [BW-1:0]    a_mask_i,
  input logic [DW-1:0]    a_data_i,
  input logic             a_corrupt_i,
  input logic             d_valid_o,
  input logic             d_ready_i,
  input logic [2:0]       d_opcode_o,
  input logic [1:0]       d_param_o,
  input logic [SZW-1:0]   d_size_o,
  input logic [SRCW-1:0]  d_source_o,
  input logic [SINKW-1:0] d_sink_o,
  input logic             d_denied_o,
  input logic [DW-1:0]    d_data_o,
  input logic             d_corrupt_o,
  input logic             dev_a_valid_o,
  input logic             dev_a_ready_i,
  input logic [2:0]       dev_a_opcode_o,
  input logic [2:0]       dev_a_param_o,
  input logic [SZW-1:0]   dev_a_size_o,
  input logic [SRCW-1:0]  dev_a_source_o,
  input logic [AW-1:0]    dev_a_address_o,
  input logic [BW-1:0]    dev_a_mask_o,
  input logic [DW-1:0]    dev_a_data_o,
  input logic             dev_a_corrupt_o,
  input logic             dev_d_valid_i,
  input logic             dev_d_ready_o,
  input logic [2:0]       dev_d_opcode_i,
  input logic [1:0]       dev_d_param_i,
  input logic [SZW-1:0]   dev_d_size_i,
  input logic [SRCW-1:0]  dev_d_source_i,
  input logic [SINKW-1:0] dev_d_sink_i,
  input logic             dev_d_denied_i,
  input logic [DW-1:0]    dev_d_data_i,
  input logic             dev_d_corrupt_i,
  input logic             flush_req_i,
  input logic             err_en_i,
  input logic             flush_ack_o,
  input logic             resp_pending_o,
  // internals, for the helper invariants only (the bind connects them)
  input logic [1:0]       rtl_route_q,
  input logic [1:0]       rtl_er_q,
  input logic [9:0]       rtl_er_left_q,
  input logic [9:0]       rtl_a_left_q,
  input logic [9:0]       rtl_dd_left_q,
  input logic [$clog2(OUTSTANDING + 1)-1:0] rtl_dev_out_q
);

  localparam int unsigned LOG2B = $clog2(BW);
  localparam int unsigned CW    = 10;
  localparam int unsigned OW    = $clog2(OUTSTANDING + 1) + 1;

  // ---- Reference encodings, from vendor/sovra_tl/tl_pkg.sv ----
  // A messages that carry data: PutFullData 0, PutPartialData 1,
  // ArithmeticData 2, LogicalData 3 (tl_pkg.sv:36-39).
  function automatic bit r_a_data(input logic [2:0] op);
    return op inside {TL_A_PUT_FULL, TL_A_PUT_PARTIAL, TL_A_ARITH, TL_A_LOGICAL};
  endfunction
  // The D message each A message is answered with (tl_pkg.sv:36-41 comments):
  // Put* -> AccessAck, Arithmetic/Logical/Get -> AccessAckData, Hint -> HintAck.
  function automatic logic [2:0] r_resp(input logic [2:0] op);
    if (op inside {TL_A_PUT_FULL, TL_A_PUT_PARTIAL})       return TL_D_ACCESS_ACK;
    if (op inside {TL_A_ARITH, TL_A_LOGICAL, TL_A_GET})    return TL_D_ACCESS_ACKDATA;
    return TL_D_HINT_ACK;
  endfunction
  // D messages that carry data in TL-UH: AccessAckData (tl_pkg.sv:63).
  function automatic bit r_d_data(input logic [2:0] op);
    return op == TL_D_ACCESS_ACKDATA;
  endfunction
  // Beats of a message (tluh_pkg.sv header burst rule).
  function automatic logic [CW-1:0] r_beats(input logic [SZW-1:0] size, input bit has_data);
    if (!has_data || size <= LOG2B) return CW'(1);
    return CW'(1) << (size - LOG2B);
  endfunction

  // ===========================================================================
  // Environment: a legal TL-UH host and a legal TL-UH device
  // ===========================================================================
  // Host: an A beat once offered is held, unchanged, until accepted (the
  // ready/valid rule the task states for a legal host; tl_beat_cnt.sv header).
  m_host_a_hold: assume property (@(posedge clk_i) disable iff (!rst_ni)
    a_valid_i && !a_ready_o |=> a_valid_i &&
      $stable({a_opcode_i, a_param_i, a_size_i, a_source_i, a_address_i, a_mask_i, a_data_i, a_corrupt_i}));
  // Host: TL-UH opcodes only -- 6/7 are AcquireBlock/AcquirePerm, TL-C
  // (tl_pkg.sv:42-43; tluh_gate.sv header).
  m_host_tluh_op: assume property (@(posedge clk_i) disable iff (!rst_ni)
    a_valid_i |-> a_opcode_i inside {[3'd0 : 3'd5]});
  // Host: no message larger than the link's largest (MAX_SIZE, above).
  m_host_size: assume property (@(posedge clk_i) disable iff (!rst_ni)
    a_valid_i |-> a_size_i <= SZW'(MAX_SIZE));
  // Host: opcode and size constant across the beats of a message
  // (tl_beat_cnt.sv header: "its size field constant across them"; a burst
  // is one message, so one opcode).
  logic [CW-1:0]  h_left;            // host A beats still to come in this message; 0: none
  logic [2:0]     h_op_q;
  logic [SZW-1:0] h_size_q;
  m_host_burst_const: assume property (@(posedge clk_i) disable iff (!rst_ni)
    a_valid_i && h_left != '0 |-> a_opcode_i == h_op_q && a_size_i == h_size_q);

  // Device: a D beat once offered is held, unchanged, until accepted (the
  // same ready/valid rule, D channel).
  m_dev_d_hold: assume property (@(posedge clk_i) disable iff (!rst_ni)
    dev_d_valid_i && !dev_d_ready_o |=> dev_d_valid_i &&
      $stable({dev_d_opcode_i, dev_d_param_i, dev_d_size_i, dev_d_source_i, dev_d_sink_i,
               dev_d_denied_i, dev_d_data_i, dev_d_corrupt_i}));
  // Device: TL-UH D opcodes only (AccessAck 0, AccessAckData 1, HintAck 2;
  // tl_pkg.sv:62-64), sizes within the link's largest.
  m_dev_d_legal: assume property (@(posedge clk_i) disable iff (!rst_ni)
    dev_d_valid_i |-> dev_d_opcode_i inside {TL_D_ACCESS_ACK, TL_D_ACCESS_ACKDATA, TL_D_HINT_ACK}
                      && dev_d_size_i <= SZW'(MAX_SIZE));
  // Device: a D message only answers an outstanding A message ("each D
  // message answers exactly one A message on a TL-UH link", tluh_gate.sv
  // header), with the same constancy of size/opcode across its beats.
  logic [OW-1:0]  d_out;             // device messages from first A beat to last D beat
  logic [CW-1:0]  dd_left;
  logic [2:0]     dd_op_q;
  logic [SZW-1:0] dd_size_q;
  logic           dev_first_fire;
  m_dev_d_answers: assume property (@(posedge clk_i) disable iff (!rst_ni)
    dev_d_valid_i && dd_left == '0 |-> d_out != '0 || dev_first_fire);
  m_dev_d_burst_const: assume property (@(posedge clk_i) disable iff (!rst_ni)
    dev_d_valid_i && dd_left != '0 |-> dev_d_opcode_i == dd_op_q && dev_d_size_i == dd_size_q);

  // ===========================================================================
  // Reference model: message boundaries and routes
  // ===========================================================================
  logic h_fire, h_first, h_last, h_route_dev, dev_fire;
  logic [CW-1:0] h_nb;
  assign h_fire   = a_valid_i && a_ready_o;
  assign dev_fire = dev_a_valid_o && dev_a_ready_i;
  assign h_nb     = r_beats(a_size_i, r_a_data(a_opcode_i));
  assign h_first  = h_fire && (h_left == '0);
  assign h_last   = h_fire && ((h_left == '0) ? (h_nb <= CW'(1)) : (h_left == CW'(1)));
  assign dev_first_fire = h_first && dev_a_valid_o;      // a device message starts

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      h_left <= '0; h_route_dev <= 1'b0; h_op_q <= '0; h_size_q <= '0;
    end else if (h_fire) begin
      if (h_left == '0) begin
        h_left      <= (h_nb > CW'(1)) ? h_nb - CW'(1) : '0;
        h_route_dev <= dev_a_valid_o;                    // where its first beat went
        h_op_q      <= a_opcode_i;
        h_size_q    <= a_size_i;
      end else begin
        h_left <= h_left - CW'(1);
      end
    end
  end

  logic dd_fire, dd_last;
  logic [CW-1:0] dd_nb;
  assign dd_fire = dev_d_valid_i && dev_d_ready_o;
  assign dd_nb   = r_beats(dev_d_size_i, r_d_data(dev_d_opcode_i));
  assign dd_last = dd_fire && ((dd_left == '0) ? (dd_nb <= CW'(1)) : (dd_left == CW'(1)));

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      dd_left <= '0; dd_op_q <= '0; dd_size_q <= '0; d_out <= '0;
    end else begin
      d_out <= d_out + OW'(dev_first_fire) - OW'(dd_last);
      if (dd_fire) begin
        if (dd_left == '0) begin
          dd_left   <= (dd_nb > CW'(1)) ? dd_nb - CW'(1) : '0;
          dd_op_q   <= dev_d_opcode_i;
          dd_size_q <= dev_d_size_i;
        end else begin
          dd_left <= dd_left - CW'(1);
        end
      end
    end
  end

  // The denied message the gate owes a response to (rule 2)
  logic           e_owed, e_a_done;
  logic [CW-1:0]  e_left;            // D beats still owed
  logic [2:0]     e_op;
  logic [SZW-1:0] e_size;
  logic [SRCW-1:0] e_src;
  logic           e_start;
  assign e_start = h_first && !dev_a_valid_o;            // a message's first beat is denied

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      e_owed <= 1'b0; e_a_done <= 1'b0; e_left <= '0; e_op <= '0; e_size <= '0; e_src <= '0;
    end else begin
      if (e_start) begin
        e_owed   <= 1'b1;
        e_a_done <= h_last;
        e_op     <= r_resp(a_opcode_i);
        e_size   <= a_size_i;
        e_src    <= a_source_i;
        e_left   <= r_beats(a_size_i, r_d_data(r_resp(a_opcode_i)));
      end else begin
        if (e_owed && h_last) e_a_done <= 1'b1;
        if (e_owed && d_valid_o && d_ready_i) begin
          e_left <= e_left - CW'(1);
          if (e_left == CW'(1)) begin e_owed <= 1'b0; e_a_done <= 1'b0; end
        end
      end
    end
  end

  logic dev_mid;                     // a device message is part-way through its A beats
  assign dev_mid = (h_left != '0) && h_route_dev;

  // ===========================================================================
  // Rule 1: a burst in progress completes; the device never sees part of a
  // message (tluh_gate.sv header rule 1; PCSA DEN 0050D 7.2.8 drain-then-block)
  // ===========================================================================
  // The device sees a beat only while the host offers it, and sees it as offered.
  a_dev_only_host_beats: assert property (@(posedge clk_i) disable iff (!rst_ni)
    dev_a_valid_o |-> a_valid_i &&
      {dev_a_opcode_o, dev_a_param_o, dev_a_size_o, dev_a_source_o, dev_a_address_o,
       dev_a_mask_o, dev_a_data_o, dev_a_corrupt_o} ==
      {a_opcode_i, a_param_i, a_size_i, a_source_i, a_address_i, a_mask_i, a_data_i, a_corrupt_i});
  // A beat offered to the device is accepted from the host exactly when the
  // device accepts it (no beat is lost or duplicated at the gate).
  a_dev_fire_is_host_fire: assert property (@(posedge clk_i) disable iff (!rst_ni)
    dev_a_valid_o |-> (dev_fire == h_fire));
  // A burst that started at the device continues there, beat for beat,
  // whatever flush_req_i / err_en_i do: the gate neither diverts nor stalls it.
  a_dev_burst_completes: assert property (@(posedge clk_i) disable iff (!rst_ni)
    dev_mid && a_valid_i |-> dev_a_valid_o && (a_ready_o == dev_a_ready_i));
  // No beat of a denied burst (first beat to the error responder) reaches the device.
  a_denied_burst_not_dev: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (h_left != '0) && !h_route_dev |-> !dev_a_valid_o);
  // ... and the error responder takes all its beats (rule 2: "accepts all the
  // A beats of a message").
  a_denied_burst_absorbed: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (h_left != '0) && !h_route_dev && a_valid_i |-> a_ready_o);
  // Gating: no NEW message reaches the device while a flush or an error is
  // requested (tluh_gate.sv header "routed to the device only while there is
  // no flush or error request").
  a_no_new_dev_when_gated: assert property (@(posedge clk_i) disable iff (!rst_ni)
    a_valid_i && (h_left == '0) && (flush_req_i || err_en_i) |-> !dev_a_valid_o);
  // A message is denied only on the error path (err_en_i, tlul_lc_gate's
  // lc_en_i Off), and only once the device owes nothing (header: "routed to
  // the error responder only once err_en_i is HIGH and the device owes
  // nothing").
  a_denied_only_err_drained: assert property (@(posedge clk_i) disable iff (!rst_ni)
    e_start |-> err_en_i && d_out == '0);
  // flush_ack_o only once drained: no device message part-way or outstanding.
  a_flush_ack_drained: assert property (@(posedge clk_i) disable iff (!rst_ni)
    flush_ack_o |-> flush_req_i && !err_en_i && d_out == '0 && !dev_mid);
  // resp_pending_o is exactly "the device still owes something".
  a_resp_pending_exact: assert property (@(posedge clk_i) disable iff (!rst_ni)
    resp_pending_o == ((d_out != '0) || dev_mid));
  // At most OUTSTANDING device messages in flight (OUTSTANDING parameter).
  a_dev_out_bound: assert property (@(posedge clk_i) disable iff (!rst_ni)
    d_out <= OW'(OUTSTANDING));

  // ===========================================================================
  // Rule 2: every beat of a denied message is answered (tluh_gate.sv header
  // rule 2; beat count by the tluh_pkg.sv burst rule)
  // ===========================================================================
  // An error response and device traffic never overlap.
  a_err_exclusive: assert property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed |-> d_out == '0 && !dev_mid && !dev_a_valid_o);
  // The response follows the request's last A beat (rule 2: "accepts all the
  // A beats ..., then sends the D message").
  a_err_after_last_a: assert property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed && !e_a_done |-> !d_valid_o);
  // Every owed beat is offered: D valid from the last A beat until the last
  // owed D beat is taken.
  a_err_beats_offered: assert property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed && e_a_done |-> d_valid_o);
  // Each owed beat is the right one: the request's response opcode, its size
  // and source, denied, corrupt iff it is AccessAckData, param 0, sink 0.
  a_err_beat_shape: assert property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed && d_valid_o |-> d_denied_o && d_opcode_o == e_op && d_size_o == e_size &&
      d_source_o == e_src && d_corrupt_o == r_d_data(e_op) && d_param_o == 2'b00 && d_sink_o == '0);
  // No extra error beat: outside an owed error response, the host's D channel
  // is the device's, unchanged (with a_err_beats_offered: exactly the owed
  // number of beats).
  a_d_is_dev_otherwise: assert property (@(posedge clk_i) disable iff (!rst_ni)
    !e_owed |-> d_valid_o == dev_d_valid_i && dev_d_ready_o == d_ready_i &&
      {d_opcode_o, d_param_o, d_size_o, d_source_o, d_sink_o, d_denied_o, d_data_o, d_corrupt_o} ==
      {dev_d_opcode_i, dev_d_param_i, dev_d_size_i, dev_d_source_i, dev_d_sink_i,
       dev_d_denied_i, dev_d_data_i, dev_d_corrupt_i});
  // The host's D beat, once offered, is held unchanged until taken (the
  // ready/valid rule the host side relies on).
  a_d_hold: assert property (@(posedge clk_i) disable iff (!rst_ni)
    d_valid_o && !d_ready_i |=> d_valid_o &&
      $stable({d_opcode_o, d_param_o, d_size_o, d_source_o, d_sink_o, d_denied_o, d_data_o, d_corrupt_o}));

  // ===========================================================================
  // Helper invariants: the reference model agrees with the gate's own state
  // (tluh_gate.sv encodings: route_e R_NONE 0 / R_DEV 1 / R_ERR 2, er_e
  // E_IDLE 0 / E_ABSORB 1 / E_RESP 2). They make the induction converge and
  // are proved like every other assertion; they constrain nothing.
  // ===========================================================================
  a_h_model_a: assert property (@(posedge clk_i) disable iff (!rst_ni)
    h_left == rtl_a_left_q && (h_left == '0 || rtl_route_q == (h_route_dev ? 2'd1 : 2'd2)));
  a_h_model_d: assert property (@(posedge clk_i) disable iff (!rst_ni)
    dd_left == rtl_dd_left_q && d_out == OW'(rtl_dev_out_q));
  a_h_model_err: assert property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed == (rtl_er_q != 2'd0) && rtl_er_q != 2'd3 &&
    (!e_owed || (e_left == rtl_er_left_q && e_left != '0 && e_a_done == (rtl_er_q == 2'd2))));

  // ===========================================================================
  // Covers (anti-vacuity and key behaviours)
  // ===========================================================================
  // a whole 8-beat burst at the device
  c_dev_burst8: cover property (@(posedge clk_i) disable iff (!rst_ni)
    dev_fire && h_left == CW'(1) && h_route_dev && h_size_q == SZW'(LOG2B + 3));
  // a flush (or error request) arrives in the middle of a device burst, which
  // still goes on
  c_flush_mid_burst: cover property (@(posedge clk_i) disable iff (!rst_ni)
    dev_mid && flush_req_i && dev_fire);
  c_err_mid_burst: cover property (@(posedge clk_i) disable iff (!rst_ni)
    dev_mid && err_en_i && dev_fire);
  // a new message held back by the gate while the device still owes responses
  c_err_waits_drain: cover property (@(posedge clk_i) disable iff (!rst_ni)
    err_en_i && a_valid_i && h_left == '0 && d_out != '0 && !a_ready_o);
  // a denied Get answered with its full 8-beat AccessAckData burst
  c_denied_get8: cover property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed && e_op == TL_D_ACCESS_ACKDATA && e_size == SZW'(LOG2B + 3) && e_left == CW'(1)
    && d_valid_o && d_ready_i);
  // a denied 4-beat PutFullData burst: its last A beat absorbed
  c_denied_put4: cover property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed && h_last && h_op_q == TL_A_PUT_FULL && h_size_q == SZW'(LOG2B + 2));
  // a denied 2-beat atomic answered by 2 beats
  c_denied_atomic2: cover property (@(posedge clk_i) disable iff (!rst_ni)
    e_owed && e_op == TL_D_ACCESS_ACKDATA && e_size == SZW'(LOG2B + 1) && e_left == CW'(1)
    && d_valid_o && d_ready_i && h_op_q inside {TL_A_ARITH, TL_A_LOGICAL});
  c_flush_ack: cover property (@(posedge clk_i) disable iff (!rst_ni) flush_ack_o);
  c_dev_d_last: cover property (@(posedge clk_i) disable iff (!rst_ni) dd_last && dd_left == CW'(1));
  // The gate withdraws a first beat it had offered to the device, unaccepted,
  // when a flush or error request arrives (see the report: legal TileLink or
  // not depends on the spec's ready/valid rule, not in the repository).
  c_dev_a_withdrawn: cover property (@(posedge clk_i) disable iff (!rst_ni)
    dev_a_valid_o && !dev_a_ready_i ##1 !dev_a_valid_o);

endmodule

bind tluh_gate tluh_gate_props #(
  .AW(AW), .DW(DW), .SRCW(SRCW), .SINKW(SINKW), .SZW(SZW), .OUTSTANDING(OUTSTANDING)
) u_tluh_gate_props (
  .*,
  .rtl_route_q  (route_q),
  .rtl_er_q     (er_q),
  .rtl_er_left_q(er_left_q),
  .rtl_a_left_q (u_a.left_q),
  .rtl_dd_left_q(u_dd.left_q),
  .rtl_dev_out_q(dev_out_q)
);
