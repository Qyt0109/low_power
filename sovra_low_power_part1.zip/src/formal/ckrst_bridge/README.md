# ckrst_bridge formal properties

Properties for [`src/rtl/ckrst/ckrst_bridge.sv`](../../rtl/ckrst/ckrst_bridge.sv),
the clock/reset request bridge: it forwards the PPU's clock enable and device
resets to the SoC's clkgate/tilereset unchanged, and flags an acknowledgement
that is LATE (the PPU moved on before it arrived), MISSING (not within
MAX_WAIT cycles) or SPURIOUS (it changed with no request change), per cause
and per channel, sticky with W1C. The rules are the RTL header's (WHAT IS A
FAULT, THE CHANNELS AND THE PROTOCOL).

## Files

| File | Contents |
|---|---|
| `ckrst_bridge_props.sv` | `ckrst_bridge_props` and its `bind` into every `ckrst_bridge`: a reference model built from the ports only (its own copies of the ACK_SYNC and STEP_SYNC synchronisers and of the previous-cycle values; per channel `pend`, `held`, `moved`, a run counter and the once-per-edge flag), and the properties below |
| `src/signoff/formal/ckrst_bridge.tcl` | Top `ckrst_bridge` with the soc4 instances' parameters (`NUM_RST = 2`, `STEP_W = 1`, `STEP_SYNC = 2`, `ACK_SYNC = 0`) and `MAX_WAIT = 12` for formal (default 300), so the MAX_WAIT-cycle sequences stay shallow; `FV_MAX_WAIT` overrides it |

No assumptions: every input is free. Channels: 0 the clock, 1-2 the resets.

The model's reading of the header: a channel is pending when its
(synchronised) acknowledgement differs from its request. LATE: pending, own
request unchanged this cycle, and another channel's request or a step input
changed. MISSING: pending with the request unchanged for MAX_WAIT consecutive
cycles. LATE and MISSING are flagged once per request edge. SPURIOUS: the
acknowledgement changed, the request did not, and the channel is now pending.

## Properties

| Intent | Properties |
|---|---|
| Forwarding, combinationally and unchanged | `a_fwd_clk`, `a_fwd_rst` |
| Each event flagged, with its cause and channel | per channel: `a_late_flag`, `a_miss_flag`, `a_spur_flag`, `a_miss_seq` (MISSING as a sequence from the request edge) |
| ...and nothing else flagged | per channel `a_ch_only`; `a_late_only`, `a_miss_only`, `a_spur_only`; `a_reserved` (bit 3 and bits above the last channel are 0) |
| Sticky, W1C, a new event wins over its clear | per implemented status bit (0, 1, 2, 4, 5, 6): `a_sticky`, `a_clear`, `a_set_wins` |
| The fault line | `a_fault_def`: `fault_o == \|stat_o[2:0]` |
| Helper invariants (induction lemmas) | `h_hist` (history flops equal the model's), per channel `h_wait` (the wait counter) and `h_flag` (the flagged bit) |

Covers (5 per channel + 2): LATE, LATE caused by a step input alone, MISSING,
SPURIOUS, a clean handshake with no fault; a clear and a set in the same
cycle; `fault_o` rising.

## Status

47 of 47 assertions proven, 17 of 17 covers covered, none bounded (latest run,
`build/signoff/formal/ckrst_bridge/`). Also proven at the SoC value
`MAX_WAIT = 300` (`FV_MAX_WAIT=300`, run `ckrst_bridge_mw300`: 47 of 47); the
helper invariants make that depth reachable.

## Mutant

`CKRST_MUT_NOLATE` (`rtl/ckrst/ckrst_bridge.sv`): the LATE check removed. It
falsifies 7 assertions: `a_late_flag` on all three channels, and `a_set_wins`
on bits 0, 4, 5 and 6. The same define is the `make ckrst` negative control
(`[chk:LATE]`).

## Finding

F-CKRST-1 (open): LATE and MISSING share one "flagged" bit, so a MISSING after
a LATE on the same request edge is not reported separately.

## Running

`make -C src vcformal` / `vcformalneg`, with
`VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`. By hand:
`PMU_SRC=<repo>/src [FV_DEFINES=+define+CKRST_MUT_NOLATE] [FV_MAX_WAIT=300]
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/ckrst_bridge.tcl`.

## Adding a property

State it on the model signals (`pend`, `held`, `moved`, `late_s`, `miss_s`,
`spur_s`, `ev`); the helper invariants reach into `ckrst_bridge.req_q`,
`wait_q`, `flagged_q` and must be updated if those RTL names change.

## References

- `src/rtl/ckrst/ckrst_bridge.sv` header; [`src/rtl/ckrst/README.md`](../../rtl/ckrst/README.md).
- [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md) Section 6.
- Simulation: [`src/tb/ckrst/`](../../tb/ckrst/README.md), and K1 of `soc4_tb`.
