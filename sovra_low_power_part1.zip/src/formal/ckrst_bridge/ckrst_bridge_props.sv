`timescale 1ns/1ps
// Formal properties for ckrst_bridge (src/rtl/ckrst/ckrst_bridge.sv), bound
// into every ckrst_bridge instance. Run: src/signoff/formal/ckrst_bridge.tcl.
//
// The rules are ckrst_bridge.sv's header, "WHAT IS A FAULT" and "THE CHANNELS
// AND THE PROTOCOL". Below, a reference model of those rules is built from the
// PORTS only (its own copies of the ACK_SYNC / STEP_SYNC synchronisers and of
// the previous-cycle values; no RTL internal is read), and stat_o is checked
// against it in both directions: every event is flagged (a_*_flag) and nothing
// else is (a_*_only). No assumptions: every input is free.
//
// The model's reading of the header:
//   pending[c]  acknowledgement != request (after ACK_SYNC flops)
//   LATE[c]     channel c pending, its own request unchanged this cycle, and
//               "the PPU moved on": another channel's request changed or a
//               step input (after STEP_SYNC flops) changed
//   MISSING[c]  channel c pending, with its own request unchanged, for
//               MAX_WAIT consecutive cycles
//   "LATE and MISSING are flagged once per request edge": after one of them
//               for channel c, neither again until c's request changes or c
//               stops being pending
//   SPURIOUS[c] channel c's acknowledgement changed, its request did not, and
//               it is now pending ("an acknowledgement changed with no request
//               change": moved away from the request)

module ckrst_bridge_props #(
  parameter int unsigned NUM_RST   = 2,
  parameter int unsigned STEP_W    = 1,
  parameter int unsigned STEP_SYNC = 2,
  parameter int unsigned ACK_SYNC  = 0,
  parameter int unsigned MAX_WAIT  = 300
) (
  input logic               clk_i,
  input logic               rst_ni,
  input logic               clken_i,
  input logic [NUM_RST-1:0] rst_n_i,
  input logic [STEP_W-1:0]  step_i,
  input logic               clk_req_o,
  input logic               clk_ack_i,
  input logic [NUM_RST-1:0] rst_req_no,
  input logic [NUM_RST-1:0] rst_ack_ni,
  input logic [7:0]         stat_o,
  input logic [7:0]         stat_clr_i,
  input logic               fault_o
);

  localparam int unsigned NCH = NUM_RST + 1;
  localparam int unsigned RW  = $clog2(MAX_WAIT + 2);

  default clocking cb @(posedge clk_i); endclocking
  default disable iff (!rst_ni);

  // ---- The reference model, from the ports ----
  logic [NCH-1:0]    req, ack, ack_s, req_p, ack_p;
  logic [STEP_W-1:0] step_s, step_p;
  assign req = {rst_n_i, clken_i};
  assign ack = {rst_ack_ni, clk_ack_i};

  logic [ACK_SYNC:0][NCH-1:0]     ack_pipe;    // [0] = the port; [ACK_SYNC] = synchronised
  logic [STEP_SYNC:0][STEP_W-1:0] step_pipe;
  assign ack_pipe[0]  = ack;
  assign step_pipe[0] = step_i;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int s = 1; s <= ACK_SYNC; s++)  ack_pipe[s]  <= '0;
      for (int s = 1; s <= STEP_SYNC; s++) step_pipe[s] <= '0;
      req_p  <= '0;
      ack_p  <= '0;
      step_p <= '0;
    end else begin
      for (int s = 1; s <= ACK_SYNC; s++)  ack_pipe[s]  <= ack_pipe[s-1];
      for (int s = 1; s <= STEP_SYNC; s++) step_pipe[s] <= step_pipe[s-1];
      req_p  <= req;
      ack_p  <= ack_s;
      step_p <= step_s;
    end
  end
  assign ack_s  = ack_pipe[ACK_SYNC];
  assign step_s = step_pipe[STEP_SYNC];

  logic [NCH-1:0] pend, req_chg, ack_chg, held, moved, late_s, miss_s, spur_s, flg_q;
  logic           step_chg;
  assign pend     = req ^ ack_s;
  assign req_chg  = req ^ req_p;
  assign ack_chg  = ack_s ^ ack_p;
  assign step_chg = (step_s != step_p);
  assign held     = pend & ~req_chg;     // pending, own request unchanged

  logic [NCH-1:0][RW-1:0] run_q, run;    // consecutive 'held' cycles before / including this one
  for (genvar c = 0; c < NCH; c++) begin : g_m
    assign moved[c]  = step_chg || ((req_chg & ~(NCH'(1) << c)) != '0);
    assign run[c]    = held[c] ? ((run_q[c] == RW'(MAX_WAIT + 1)) ? run_q[c] : run_q[c] + RW'(1)) : '0;
    assign late_s[c] = held[c] && moved[c] && !flg_q[c];
    assign miss_s[c] = held[c] && run[c] == RW'(MAX_WAIT) && !flg_q[c];
    assign spur_s[c] = ack_chg[c] && !req_chg[c] && pend[c];
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        run_q[c] <= '0;
        flg_q[c] <= 1'b0;
      end else begin
        run_q[c] <= run[c];
        flg_q[c] <= held[c] && (flg_q[c] || late_s[c] || miss_s[c]);
      end
    end
  end

  // ---- Helper invariants (lemmas for the induction at large MAX_WAIT): the
  // RTL's history flops, wait counter and flag equal the model's. Upward
  // references by module name into the bound ckrst_bridge instance. ----
  h_hist: assert property (ckrst_bridge.req_q == req_p && ckrst_bridge.ack_q == ack_p &&
                           ckrst_bridge.step_q == step_p && ckrst_bridge.ack_s == ack_s &&
                           ckrst_bridge.step_s == step_s);
  for (genvar c = 0; c < NCH; c++) begin : g_h
    h_wait: assert property (32'(ckrst_bridge.wait_q[c]) == ((32'(run_q[c]) > MAX_WAIT) ? MAX_WAIT : 32'(run_q[c])));
    h_flag: assert property (ckrst_bridge.flagged_q[c] == flg_q[c]);
  end

  logic [7:0] ev;                        // the status byte's events this cycle
  always_comb begin
    ev    = '0;
    ev[0] = |late_s;
    ev[1] = |miss_s;
    ev[2] = |spur_s;
    for (int c = 0; c < NCH; c++) ev[4 + c] = late_s[c] || miss_s[c] || spur_s[c];
  end

  // ===========================================================================
  // Forwarding: "the bridge forwards every request unchanged, combinationally"
  // ===========================================================================
  a_fwd_clk: assert property (clk_req_o == clken_i);
  a_fwd_rst: assert property (rst_req_no == rst_n_i);

  // ===========================================================================
  // LATE / MISSING / SPURIOUS: flagged when they occur (cause and channel)...
  // ===========================================================================
  for (genvar c = 0; c < NCH; c++) begin : g_ch
    a_late_flag: assert property (late_s[c] |=> stat_o[0] && stat_o[4 + c]);
    a_miss_flag: assert property (miss_s[c] |=> stat_o[1] && stat_o[4 + c]);
    a_spur_flag: assert property (spur_s[c] |=> stat_o[2] && stat_o[4 + c]);
    // MISSING, as a sequence from the request edge: pending for MAX_WAIT
    // cycles with nothing else moving -> flagged.
    a_miss_seq:  assert property ((req_chg[c] && pend[c]) ##1 (held[c] && !moved[c]) [*MAX_WAIT]
                                  |=> stat_o[1] && stat_o[4 + c]);
    // ...and never before: a channel answered within MAX_WAIT cycles, with
    // nothing else moving, raises no fault for that channel.
    a_ch_only:   assert property (!stat_o[4 + c] && !ev[4 + c] |=> !stat_o[4 + c]);

    c_late:      cover property (late_s[c] ##1 stat_o[0]);
    c_late_step: cover property (held[c] && step_chg && req_chg == '0 ##1 stat_o[0]);
    c_miss:      cover property (miss_s[c] ##1 stat_o[1]);
    c_spur:      cover property (spur_s[c] ##1 stat_o[2]);
    c_ok_handshake: cover property (stat_o == '0 && req_chg[c] && pend[c] ##1 held[c] [*2] ##1
                                    !pend[c] ##1 stat_o == '0);
  end

  // ...and nothing else sets a cause bit.
  a_late_only: assert property (!stat_o[0] && !ev[0] |=> !stat_o[0]);
  a_miss_only: assert property (!stat_o[1] && !ev[1] |=> !stat_o[1]);
  a_spur_only: assert property (!stat_o[2] && !ev[2] |=> !stat_o[2]);
  // [3] reserved, 0; channel bits above the last channel are 0.
  a_reserved:  assert property (!stat_o[3] && (stat_o[7:4] >> NCH) == '0);

  // ===========================================================================
  // "Bits [7:0] are sticky until written 1 in stat_clr_i (W1C); a new event in
  // the cycle of the clear wins. fault_o = |stat_o[2:0]."
  // ===========================================================================
  // (Only the implemented bits: [3] and the bits above the last channel are
  // never set -- a_reserved -- so sticky / set-wins would be vacuous there.)
  for (genvar b = 0; b < 8; b++) begin : g_b
    if (b != 3 && b < 4 + NCH) begin : g_impl
      a_sticky:   assert property (stat_o[b] && !stat_clr_i[b] |=> stat_o[b]);
      a_clear:    assert property (stat_clr_i[b] && !ev[b] |=> !stat_o[b]);
      a_set_wins: assert property (stat_clr_i[b] && ev[b] |=> stat_o[b]);
    end
  end
  a_fault_def: assert property (fault_o == |stat_o[2:0]);
  c_clear_and_set: cover property (stat_o[0] && stat_clr_i[0] && ev[0] ##1 stat_o[0]);
  c_fault:         cover property (!fault_o ##1 fault_o);

endmodule

bind ckrst_bridge ckrst_bridge_props #(.NUM_RST(NUM_RST), .STEP_W(STEP_W), .STEP_SYNC(STEP_SYNC),
  .ACK_SYNC(ACK_SYNC), .MAX_WAIT(MAX_WAIT)) u_ckrst_bridge_props (.*);
