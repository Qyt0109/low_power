# RISC-V Power-Management Stack — Decisions of 2026-09-30

**Status.** These decisions were taken on 2026-09-30, in two rounds: D1–D15
before the first work items, and D16–D21 after them. Nothing below is built
unless it is marked *done* or *next*.

**Superseded in part (2026-10-02).** What was built of this record ran on the
12-domain `pmu_top`. On 2026-10-02 `pmu_top` was replaced by **soc4**
(`src/soc4`; [`docs/SOC4_DESIGN.md`](../docs/SOC4_DESIGN.md), decisions of 2026-10-01) and
removed. The record below is kept as written; these parts of it no longer
describe the repository:

- **Two transports (§2.2).** soc4 has one, T0a, carrying BASE and
  DEVICE_POWER over four domains (CPU0, CPU1, ACC0, ACC1; `DOMAIN_ID` = PPU
  index). T0b and SYSTEM_RESET are not built (`src/pmu/fw/rpmi/scp_rpmi.h`).
- **The AXI4-Lite AP port and the doorbell block (W2.1).** `pmu_top`'s mailbox
  (`scp_rpmi_mbox`, on PULP `mailbox_unit`, with its own AXI4-Lite port into
  `scp_top`) is gone. soc4's mailbox is TL-UL (`soc4_mbx`, on vendored
  OpenTitan), on `scp_top`'s `ext_*` window, with one AP-to-SCP doorbell.
- **The firewall (W2.1, A14).** The IOPMP-style "only the CVA6 cores" firewall
  is replaced by `soc4_mbx`'s TL-UL source firewall: deny-all at reset, then the
  AP's `a_source` only, set by the SCP at boot (SOC4_DESIGN.md decision 10).
- **The tests named here** — `make scprpmi`, `scprpmihw`, `scpdpwr`, `scppd` —
  were removed with `pmu_top`. Their functions run as `make soc4`, `soc4bfm`
  and `soc4neg` (SOC4_DESIGN.md Section 11).
- **W4.1's policy** (eight domain IDs, dynamic RUN, locked OFF) was replaced in
  `src/pmu/fw/mod/policy.c` by soc4's static policy, with the same hooks and
  the same one-voter rule.

**Superseded in part (2026-10-04).** The power-control platform decisions in
[`SOVRA_PCSA_ARCHITECTURE.md`](SOVRA_PCSA_ARCHITECTURE.md) §14.1 change:

- **D3 (the AP is the only agent).** There are **two agents, the AP and the
  RPU** (PD6). The mailbox becomes an N-agent mailbox with one transport,
  firewall entry (`a_source` value + mask) and librpmi context per agent. The
  policy keeps one vote per agent per domain (ON while any agent votes ON) and a
  per-domain permission table (§14.7 H11, H12, F6). Agents still poll.
- **D4/D18's hardware deep-idle wake.** The PPUs are static-only (PD5). The
  READY bit is kept as the CVA6 and Rocket adapters' idle condition, but a wake
  reaches the SCP as an input (the SoC PLIC's per-hart pending) and the SCP
  powers the CPU up (PD7, §14.7 H8/H9).

This record replaces the SCMI host-protocol plan in
[`src/pmu/README.md`](../src/pmu/README.md) §7–8 and
[`src/pmu/FUNCTIONS.md`](../src/pmu/FUNCTIONS.md) §8–9. It keeps the domain
partition of `PCSA_FLAT_DOMAIN_SOC.md` (removed 2026-10-05; the partition is
now [`SOVRA_PCSA_ARCHITECTURE.md`](SOVRA_PCSA_ARCHITECTURE.md) §3 and §13).

**The stack being built.**

| Layer | Component |
|---|---|
| SCP | The Ibex SCP in [`src/pmu/`](../src/pmu/), bare-metal. librpmi v1.0.0 is the RPMI server, running over the in-house `ppu_v1` driver, the `pd` manager and a new policy layer |
| Protocol and transport | RPMI v1.0 over shared-memory queues (`riscv,rpmi-shmem-mbox`) |
| AP firmware | U-Boot SPL → OpenSBI v1.9 `fw_dynamic` (RPMI drivers, SBI MPXY) → U-Boot → Linux |
| AP cores | CVA6, from the Culsans coherent multi-core fork (D5, D16) |

**Milestone 1.**

1. OFF→ON→OFF on one domain.
2. The SCP powers the AP, OpenSBI completes RPMI BASE discovery, and Linux boots.
3. Reboot and power-off work through SBI SRST and RPMI SYSTEM_RESET.
4. Linux powers a DSP on and off through RPMI DEVICE_POWER over SBI MPXY.

**Citation convention.** This follows the flat-design document. A bare `§x.y`
is PCSA (DEN 0050D). `PPU §x.y` is the PPU Architecture v1.1 (DEN 0051E).
Work-item IDs (W0.2, W1.1, …) are listed in [section 6](#6-work-items).

---

## 1. Decisions

### 1.1 First round

| # | Topic | Decided | Alternatives not taken |
|---|---|---|---|
| D1 | AP partition | One power domain per CPU (PD_CPU0–3), as in the flat design | One domain for all four CPUs, with a last-hart rule in the SCP; per-CPU domains under a cluster domain |
| D2 | DSP and NPU partition | One domain per instance: PD_DSP0–3 and PD_NPU0–3 | One domain per subsystem |
| D3 | RPMI agents | The AP is the only agent. Linux decides all DSP and NPU power, and their firmware never talks to the SCP. There is no LPU and no second Linux AP | DSP/NPU firmware as agents; an LPU; a second AP running Linux |
| D4 | Race-free deep idle | A per-hart bit in always-on logic that says a hart may count as idle. **Amended by D18**: the bit is now set by the hart itself and replaces the WFI term | Retentive idle only; no deep idle while running; a power-down signal provided by the core |
| D5 | AP core | CVA6 (OpenHW Group) | Rocket or BOOM; a licensed core |
| D6 | Required of the AP core | Per-core isolation and gating; a per-hart WFI output, reset and boot address. **Not** required: a hardware cache clean on quiesce, or Sstc. CVA6 has no WFI output, and D17–D18 settle that | — |
| D7 | Interrupts and timer | APLIC (wired) and ACLINT (MTIMER, MSWI), both always-on. No IMSIC | APLIC + IMSIC + ACLINT; PLIC + CLINT |
| D8 | Main memory | DDR, powered throughout M1 and M2, with its controller and PHY always-on | DDR self-refresh in system suspend; on-chip SRAM only |
| D9 | SCP boot | An always-on boot ROM loads the SCP image from SPI flash and checks its integrity (CRC or hash). No SCP secure boot in M1 | Mask ROM, execute in place; load over JTAG or from a test host only; a signed image |
| D10 | Reset and power-off hardware | Not defined yet; simulation only | A PMIC off pin; a chip POR request; a board power cycle |
| D11 | Power-switch settling | PCSM settle counters (`PCSM_*_SETTLE`), set per domain from the switch datasheet. `PGOOD_EN` stays 0 and no switch acknowledge ports are added. The PPU DCDR delays keep the isolation, clock and reset gaps | DCDR delays only; `PGOOD_EN = 1` with acknowledge ports |
| D12 | Simulators | The VCS, VCS-NLP and Verdi licences are being renewed past 2026-10-31 | Restore Xcelium; do the RTL work first, then move to Verilator |
| D13 | PPU EMU modes | Waived for M1 ([section 4](#4-emu-waiver)) | Add OFF_EMU and MEM_RET_EMU to the PPU; a firmware debug keep-alive |
| D14 | SCP runtime | A bare-metal event loop with librpmi v1.0.0. Zephyr is re-evaluated at M2 against a measured image | Zephyr with librpmi now; a port of Arm SCP-firmware |
| D15 | First work | W0.2, W1.1 and W2.2–W2.3, in parallel | AP software on QEMU first |

The first round also approved retiring the SCMI plan in the two documents named
above, and correcting the citation and fact errors found in the design review.
Both are done.

### 1.2 Second round

| # | Topic | Decided | Alternatives not taken |
|---|---|---|---|
| D16 | Cache coherence between the four cores | Culsans: PULP's coherent multi-core CVA6, a snooping unit plus a CVA6 fork with a write-back D-cache, for 2 to 4 cores | Stock CVA6 with our own invalidation broadcast; the OpenPiton fabric; reopening D5 |
| D17 | Changes to the core | None. CVA6, and the Culsans fork, are used as delivered | A local six-line patch adding a WFI output, with or without offering it upstream |
| D18 | Idle signal for deep idle (amends D4) | A per-hart software READY bit in always-on logic. OpenSBI sets it as the hart's last store before WFI, after cleaning the cache; hardware clears it on any enabled wake for that hart ([section 2.5](#25-firmware-d4-d14-d18)) | Wait for an upstream WFI output; no runtime deep idle |
| D19 | The time CSR | CVA6 has none, so each `rdtime` traps to OpenSBI, which answers from the always-on ACLINT. Accepted for M1 and M2 | Add a time CSR (a core change) |
| D20 | Warm reboot | Not offered. Every reboot is a cold reset, and SYSTEM_RESET lists only shutdown and cold reboot | A warm reset of the whole AP side; of the CPU domains only |
| D21 | An access to a DSP or NPU the AP voted OFF | The always-on access gate answers at once with an error, and the SCP logs the master and address. An access that arrives while a power-up the AP requested is in progress is held until ON | Hold the access and power the domain on |

The second round also deferred the reviews' minor findings
([section 7](#7-deferred-minor-findings)), and decided to commit the work one
commit per stream.

## 2. What changes

### 2.1 Domains (D1, D2)

- **PPUs.** Twelve PPUs, as today, in `pd_tab` order
  ([`pd.c:57-64`](../src/pmu/fw/mod/pd.c)): CPU0–3, DSP0–3, NPU0–3.
  `SCP_NUM_PPU` stays 12, which is also the most `scp_top` accepts.
- **Shared AP logic** stays always-on. That covers the interconnect ports, the
  APLIC, the ACLINT, the DDR controller and PHY, and the Culsans snooping unit.
- **Per-CPU split.**
  - §4.2.5 strongly recommends per-core domains for leakage-sensitive designs,
    and this split follows it.
  - It also removes the last-hart rule from the SCP. Each hart's HSM request
    maps to its own CPU's PPU.
- **DEVICE_POWER.** Linux sees eight domains. Proposed IDs: 0–3 for DSP0–3, and
  4–7 for NPU0–3.
- **Adapters (W1.2).** Every domain gets a Q-Channel device adapter: four for
  the CVA6 cores and eight for the accelerators.

### 2.2 Agents and transports (D3, D21)

- **One agent, two transports.** *(soc4 builds one, T0a: see Status.)* The
  AP is the only agent. OpenSBI owns both transports, and both are M-mode
  contexts:
  - **T0a** carries BASE and SYSTEM_RESET in M1, plus HSM and SYSTEM_SUSPEND
    from M2.
  - **T0b** carries BASE and DEVICE_POWER. OpenSBI exposes DEVICE_POWER to
    Linux as an MPXY channel.
- **Dropped from the plan.**
  - DSP and NPU transports.
  - The vendor subsystem service group.
  - A subsystem RPMI client.
  - The SCP-to-agent doorbell path. OpenSBI polls, so the doorbell block needs
    only the two AP-to-SCP doorbells.
- **Votes.** DEVICE_POWER still keeps a vote per transport. librpmi v1.0.0
  skips the platform call when `get_state` already equals the requested state
  (`rpmi_service_group_device_power.c:128-131`), so `get_state` must return the
  agent's own last vote, never the physical state. With one voter the policy
  reduces to two rules:
  - A domain is ON if and only if the AP voted ON.
  - Power-off waits out a hysteresis window.
- **Agreeing a power-off.** PPU §3.3.2 lets a Q-Channel device's readiness for a
  lossy mode be settled by "a method other than the device interface
  Q-Channel". Here that method is Linux's driver: it stops the accelerator,
  with its cores held in reset, before voting OFF.
- **A busy accelerator can still refuse.** The SCP requests OFF with a static
  policy, so the accelerator's adapter can deny it (PPU Table 4-1,
  `STA_DENY`).
  - On a denial the SCP returns the domain to ON and retries, up to a cap.
  - Only after that does it force the power-down.
  - A negative test drives a busy device.
- **Accelerator run control is Linux's.** Linux releases each accelerator's
  core reset and sets its boot address, through a per-instance control block
  in the AP's address space. The SCP only powers the domain. A newly powered
  accelerator's cores stay in reset until Linux releases them.
- **An access to an OFF accelerator (D21).** In Linux's flow a driver holds a
  runtime-PM reference, and so a DEVICE_POWER ON vote, before it touches a
  device, so an access that reaches an OFF domain is a software bug.
  - The always-on access gate answers it at once with an error, and the SCP
    logs the master and address. Linux sees the bug.
  - An access that arrives while a power-up the AP requested is in progress is
    held until the domain is ON, not errored.
  - The SCP never powers a domain on for an access. This departs from §7.2.8's
    stall-and-wake, which suits blocks the hardware manages by activity, not
    devices Linux manages.

### 2.3 AP platform (D5–D8, D16, D17, D19)

- **CVA6 check (W0.2), done.** CVA6 v5.3.0 (`2ef1c1b1`, 2025-02-03, the newest
  release) was read, and every finding was verified a second time.
  - **One core can be gated while the others run.** Each core has its own
    clock, reset, boot address and bus port, and its caches clear themselves
    after reset.
  - **No WFI output.** Hence D17 and D18.
  - **No drain handshake.** WFI commits while bus transactions can still be in
    flight. So each CPU's adapter drains and isolates the core's bus port with
    PULP's `axi_isolate` (vendored with CVA6) before it accepts. With a
    write-back cache, a fence doesn't prove the last device write was
    acknowledged, so this drain is mandatory.
  - **No privilege on the bus.** AxPROT is tied to 0 on every cache option
    (A14).
  - **No coherence on AXI.** Hence D16.
- **Coherence (D16).** The Culsans snooping unit keeps the four write-back
  D-caches coherent.
  - Before a CPU domain turns off, the core flushes its D-cache (flush on
    fence) in OpenSBI's last steps.
  - While it is off, an always-on responder answers snoops for it.
  - W0.2b checks the fork, its 4-core configuration and the snoop responder.
- **Cache cleaning.** There is no hardware clean. An OpenSBI platform override
  cleans the departing core's D-cache before a non-retentive OFF, then sets the
  hart's READY bit (D18). That covers an HSM stop, a non-retentive suspend and
  system suspend. OpenSBI's generic platform has no hook for this, so it is new
  code.
- **Timer, confirmed in W0.2.** CVA6 has no Sstc.
  - OpenSBI v1.9 probes for `stimecmp`. Without it, OpenSBI serves the SBI
    timer from the always-on ACLINT MTIMER, whose compare output is a wake
    source for a gated core.
  - So no broadcast clock-event device is needed, and the device tree must not
    mark the timer `riscv,timer-cannot-wake-cpu`.
  - CVA6 also has no time CSR, so `rdtime` traps and OpenSBI emulates it (D19).
- **Interrupts.**
  - The APLIC runs in direct mode. The wake logic uses each hart's
    pending-and-enabled indication.
  - ACLINT MSWI carries M-mode IPIs, and OpenSBI emulates S-mode IPIs.
  - No APLIC is vendored in this repository, so one must be sourced.
  - RPMI SYSTEM_MSI is not used.
- **Memory.**
  - U-Boot SPL initialises DDR. So the AP needs on-chip SRAM for SPL, and a
    boot ROM that loads it.
  - A DDR controller and PHY must be sourced.
  - M2 system suspend keeps DDR fully powered and powers down only the CPU
    domains.
- **PMP.** CVA6 has 8 PMP entries at 8-byte granularity, and no Smepmp. They
  are the only M-mode versus S-mode protection of the RPMI queues (A14), so the
  M-only regions must be laid out to fit, or the entry count raised.

### 2.4 SCP and power hardware (D9–D11, D20)

- **SCP boot (W2.5).**
  - A new `scp_rom`, with an SPI flash controller in always-on logic. W2.5
    looks for one in the vendored OpenTitan subset first.
  - The flash image is a header (the length, plus a CRC or hash) followed by
    the RAM image.
  - The ROM copies the image into `scp_ram` and jumps to the reset vector.
  - The testbench's `$readmemh` preload stays as a simulation shortcut.
- **Reset (W3.1).** `scp_rstctl` brings out a cold-reset request and a
  PMIC-off request as ports, which the testbench watches.
  - M1.3 passes on the bus-functional model. The board side comes later.
  - Until then, cold reset means a chip reset (A5).
  - There is no warm reset (D20).
- **Switch settling (W1.1, done).**
  - The new wrapper forwards `PCSM_*_SETTLE` per domain. It does not forward
    `PGOOD_EN` and adds no acknowledge ports, as decided on 2026-09-29.
  - `scppdpa` passes with settle pairs 1/1, 20/20, 30/20 and 100/100. The
    shortest rail-on to reset-release gap is 30 + `LOGIC_SETTLE` cycles.
  - `scpstresspa` and `scppd` pass at 30/20.
  - With the counters covering the switch, the firmware's 20-cycle DCDR settle
    covers it a second time. Rebalancing the two is a later decision.

### 2.5 Firmware (D4, D14, D18)

- **Boot in M1.** Without `riscv,rpmi-hsm`, OpenSBI v1.9 starts the secondary
  harts by IPI, so all four harts must enter at cold boot.
  - The SCP therefore powers PD_CPU0–3 ON at boot and releases all four harts
    at the AP ROM vector. Today `pd_boot` powers only CPU0.
  - U-Boot SPL is built with `SPL_SMP`.
  - From M2, `riscv,rpmi-hsm` lets OpenSBI start and stop single harts through
    the SCP, which powers each CPU domain on and off.
- **Deep idle (W5.1, M2).** Each CPU's Q-Channel activity comes from always-on
  logic, with D18's READY bit:

  ```
  idle_h          = STOPPED_h | PARKED_h | in_reset_h | READY_h
  DEVQACTIVE_CPUh = WAKE_h | ~idle_h
  ```

  - **Setting READY_h.** Hart h sets it, through OpenSBI's platform code, as its
    last store before WFI, after cleaning its cache. The SCP has already
    written CPU h's policy and read it back before it answered the HSM request.
  - **Clearing READY_h.** Hardware clears it on any of these, and a clear wins
    over a set:
    - an enabled wake for hart h;
    - PD_CPUh powering back up to ON;
    - a reset of hart h.

    The SCP can also clear it.
  - **Accepting.** The CPU's Q-Channel adapter accepts only while `idle_h`
    holds and after the core's bus port has drained and been isolated
    (`axi_isolate`). A wake before that makes it deny.
  - **The last instructions.** The core may still be executing its final fence
    and WFI when power-down starts. That is harmless for OFF, whose state is
    already saved, and for FULL_RET: the frozen pipeline resumes, and its WFI
    returns at once because the wake is still pending.
  - **STOPPED_h.** For an accepted HSM stop, the SCP sets it only after READY_h
    has been seen and the bus has drained, and then holds the hart in reset.
  - **Reported state.** HSM reports hart h as SUSPENDED only while READY_h is
    set.
- **Runtime (W2.2–W2.3, done).**
  - librpmi is called only from the main loop, and interrupt handlers only set
    flags.
  - On every pass the loop drains each transport's A2P queue with
    `rpmi_context_process_a2p_request()`, T0a before T0b, then runs
    `rpmi_context_process_all_events()` for every context.
  - A guard in `rpmi/scp_rpmi.c` stops a bad AP queue index from hanging the
    loop.
  - `make scprpmi SIM=vcs` passes with 339 checks. (Removed with `pmu_top` on
    2026-10-02; the loop runs in `make soc4` and `soc4bfm`.)

## 3. Assumptions kept

| ID | Assumption | Holds until |
|---|---|---|
| A2 | Retention: each CPU domain uses FULL_RET, and its non-retentive state is OFF; the accelerators use MEM_RET. By default the PPU keeps supporting every mode; per-domain limits through `*_SPT_CFG` arrive with the policy table | The switch and retention library is known |
| A5 | Cold reset is a chip reset | D10 is settled |
| A6 | SCP RAM stays at 64 KiB. Measured in W2.2: the RPMI server is about 4.7 KB of code, 0.35 KB of data and 1.1 KB of bss, of which 1 KiB is the allocation arena. The loopback test image uses 17 KB of the 60 KB left after the stack | Holds |
| A12 | No DVFS through M2: one rail, one clock | — |
| A13 | Replaced by D16 | — |
| A14 | Holds, more strictly than written: CVA6 drives no privilege bit at all (AxPROT = 0). So M-mode versus S-mode separation on the RPMI queues comes only from each core's PMP, and the firewall separates the CVA6 cores from DMA by manager port | — |
| — | Linux loads the DSP and NPU images at fixed addresses published in the device tree | M2 |

## 4. EMU waiver

- **What the brief asks.** M1 step 1 is "OFF→ON→OFF, EMU first".
- **What this PPU build lacks.** It implements no emulated modes. OFF_EMU and
  MEM_RET_EMU are absent from `src/rtl/ppu/ppu_pkg.sv:35-37`, and programming
  either returns `UNSPT_POLICY`.
- **What stands in for M1.1.** Plain OFF→ON→OFF on the new wrapper. `make
  scppd SIM=vcs` passed it, before and after W1.1; since 2026-10-02 `make soc4`
  does (A3–A6, A13).
- **When EMU comes back.** Once there is debug infrastructure that needs a
  domain's debug logic kept alive across power-down, meaning the CVA6 debug
  module and an external debugger.

## 5. Open items

- **Culsans (W0.2b).** The fork's maturity, its 4-core configuration, flush on
  fence in the fork, and the always-on snoop responder an OFF core needs.
- **DEVICE_POWER is synchronous in librpmi.** An ON that waits for power-up
  stalls every transport, T0a included, for the length of the wait. W4.1
  chooses between a bounded wait and a deferred reply.
- **librpmi behaviours to design around.**
  - A message for an unregistered service group gets no reply at all.
  - A normal SYSTEM_RESET request whose hook returns gets an empty reply, so
    W3.1's hook must not return.
  - SYSTEM_SUSPEND calls the platform's ready callback unconditionally, so the
    platform must supply it.
- **IP still to be sourced.**
  - An APLIC.
  - A DDR controller and PHY.
  - The SCP's SPI flash controller.
  - The AP boot ROM, with on-chip SRAM for SPL.
  - The AP boot media.
  - The Culsans snooping unit and CVA6 fork, integrated.
- **Board hardware** for reset and power-off (D10).
- **The Vivado trial** ends 2026-11-03. FPGA bring-up (W2.9) needs it, and D12
  does not cover it.
- **OpenSBI and two transports.** It is unverified whether OpenSBI v1.9 accepts
  two `riscv,rpmi-shmem-mbox` nodes, one each for T0a and T0b. (Moot for soc4,
  which has one transport.)
- **PMP sizing** (section 2.3).

## 6. Work items

The IDs and dependencies are those of the 2026-09-30 design plan. This table
lists what the decisions change, and each item's state.

| ID | Item | Change and state |
|---|---|---|
| W0.2 | AP core interface check | CVA6 checked; per-core gating is feasible. *Done* |
| W0.2b | Culsans check | New (D16). *Next* |
| W1.1 | PPU domain wrapper without the stand-in device, forwarding `*_SPT_CFG` and `PCSM_*_SETTLE` | Still 12 domains; `PGOOD_EN` is not forwarded. All 28 regression targets match the baseline, and the merged tree passes 29 of 29. *Done* |
| W1.2 | Q-Channel device adapters | Four CVA6 adapters with the READY bit and an `axi_isolate` drain, and eight accelerator adapters |
| W1.3 | EMU modes | Replaced by the waiver in [section 4](#4-emu-waiver) |
| W2.1 | Doorbells, queue SRAM, basic firewall | Only the two AP-to-SCP doorbells. The T0 pages are reachable only from the CVA6 cores. Also the access gate's error mode (D21). *Done* on `pmu_top` (AXI4-Lite); superseded 2026-10-02 by soc4's TL-UL mailbox and source firewall (see Status) |
| W2.2–W2.3 | librpmi, environment port, main loop | librpmi v1.0.0 vendored, the port, the loop and a loopback test. *Done* |
| W2.5 | SCP boot ROM, reset vectors, boot sequence | SPI flash loader; all four CPU domains ON at boot |
| W2.6–W2.7 | Device tree and configurations; AP software on QEMU | *Next* |
| W3.1 | Reset controller | Request ports only, for now; no warm reset (D20) |
| W4.1 | Policy and DEVICE_POWER | Eight domain IDs, one voter; the SCP's log of access errors (D21); the non-blocking `pd` rewrite. *Done* on `pmu_top`; the policy was replaced 2026-10-02 by soc4's static four-domain one, the non-blocking `pd` kept (see Status) |
| W5.1 | Wake logic and READY bits | Per-CPU READY and wake terms; no cluster term |
| W5.2 | HSM and cpuidle | Each hart's HSM request drives its own CPU's PPU; no last-hart rule |
| W5.4 | Subsystem agents | Dropped. Replaced by Linux-owned accelerator run control (M2) |

## 7. Deferred minor findings

The reviews of the first work items found no blockers. These minor findings
were deferred on 2026-09-30. (2026-10-02: those that name `pmu_top`,
`pmu_top.upf`, `scppdpa` or `scprpmi` lapsed with them.)

**W1.1, the domain wrapper.**

*Superseded in part (2026-10-06).* Several items below name files that no
longer exist: `pmu_top.sv`, `pmu_top.upf` and the `scppdpa` target were
retired with `pmu_top` on 2026-10-02; `lint/ppu_comb_check.py` was removed
with `src/lint` on 2026-10-05 (static checks are now the Synopsys VC suite,
`make signoff`, in [`src/signoff/`](../src/signoff/README.md));
`PCSA_FLAT_DOMAIN_SOC.md` was removed on 2026-10-05 (its successor is
[`SOVRA_PCSA_ARCHITECTURE.md`](SOVRA_PCSA_ARCHITECTURE.md)). Those items
lapsed; the list is kept as written.

- `ppu_dom_top` doesn't forward `ppu_top`'s `IIDR_*` identity parameters, so an
  integration can't set its own.
- Nothing lints or runs `upf/ppu_axi_pd_top.upf` under VCS.
- The per-domain power intent now exists as three literal copies
  (`ppu_pd_top.upf`, `ppu_axi_pd_top.upf`, `pmu_top.upf`) with no check that
  they agree.
- `lint/ppu_comb_check.py` doesn't list the two new wrapper files.
- When Xcelium is back, run `make scppdpa SIM=xcelium` first: its power intent
  now puts the SCP in a power domain.
- `upf/ppu_pd_top.upf:422` still cites Table 4-11 where Table 4-9 is meant.
- `pmu_top.sv:97` declares the mode-support parameters `logic`; the levels
  below use `bit`.
- The docs owed by W1.1: `src/pmu/README.md`, `FUNCTIONS.md`,
  `PPU_FW_CONFORMANCE.md`, `src/rtl/ppu/FIX_PLAN.md`, `README.md` and
  `CONFORMANCE.md`, `src/upf/README.md`, `src/tb/ppu/TEST_MATRIX.md` and
  `PCSA_FLAT_DOMAIN_SOC.md`.

**W2.2–W2.3, the librpmi port.**
- The arena's allocation offset lives in a writable exported global
  (`rpmi_env.c`).
- `scp_loop.h` should state the sleep rule for pending librpmi events once the
  doorbells are interrupt-driven.
- The doorbell HAL uses librpmi's `rpmi_` prefix; rename it to `scp_db_*`.
- The 660-cycle idle-pass figure includes the test harness.
- `pd.h:16` still says "SCMI domain_id n".
- The guard can't catch an in-range but wrong AP index, and there is no
  per-pass request budget.
- The docs owed by W2.2–W2.3: `make scprpmi` and the firmware layout in
  `src/pmu/README.md`, and a README for `src/pmu/fw`.

**Docs.**
- `FUNCTIONS.md` rows 7.3, 7.17 and 7.18 name `ppu_wait_mode`, which doesn't
  exist.
- Citation leftovers:
  - PCSA §7.2.3 cited for the §7.2.2 placement rule: `src/rtl/ppu/README.md:351`,
    `docs/PPU_REPORT.md:400`, `src/upf/README.md:106, 266`, and the RTL sites
    the citation agent listed.
  - `ppu_monitor.sv:323` cites Table 3-1 where Table 3-2 is meant.
  - The unqualified "cannot be denied" lead-ins in `ppu_seq.sv:70`,
    `src/rtl/ppu/README.md:300`, `docs/PPU_REPORT.md:326` and
    `ppu_deny_tb.sv:50` need "other than ON → WARM_RST".
- `src/pmu/README.md`:
  - the `ibexlint` exception to the simulator rule, and the `src/Makefile:79`
    header;
  - a bare `§` used for the file's own sections;
  - the 64-byte slot size should be labelled as proposed (W2.1);
  - §9 items 1 and 8 and F5 still treat the boot ROM as optional (D9);
  - F4 has no negative-path checks;
  - "GIC wake" rows (README §1, `FUNCTIONS.md` 2.2) predate D7;
  - wording at line 553.
- `pd.c:400` still says "PSCI CPU_OFF / SCMI message".
