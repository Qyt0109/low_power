# Task: minimal PPU + SCP power-control platform (4 domains)

## Who I am and what I own
I'm the hardware engineer for the power-control platform of a RISC-V SoC. I own:
- the PPU that controls one power domain (DEN 0051E Q-Channel PPU, already in the repo);
- the SCP, an Ibex core with bare-metal firmware, which performs all power control
  for the system;
- the interface between the AP and the SCP: mailbox, doorbells, queue memory and
  firewall, plus the SCP as the RPMI host.

Out of scope, and not to be built: AP software, OpenSBI, Linux, U-Boot, QEMU, AP-core
selection, cache coherence, and any OS or driver work. That belongs to the embedded team.
My deliverable is the hardware, the interfaces and the SCP firmware they will build on.

Wherever `Proposed_PMU/RPMI_STACK_DECISIONS.md` goes beyond this scope (Culsans, OpenSBI,
the QEMU boot, the READY bit), this prompt wins.

## Starting point (read before planning)
- Branch `scp-ibex-firmware`. Run `git log --oneline -10` first: W2.1 (mailbox RTL) and
  W4.1 (DEVICE_POWER policy, non-blocking `pd`) may already be merged on top of `af2c217`.
  Reuse them.
- PPU: `src/rtl/ppu/`.
  - `ppu_dom_top` / `ppu_axi_dom_top` are the domain wrappers without a built-in device;
    they forward `*_SPT_CFG` and `PCSM_*_SETTLE`.
  - `ppu_pcsm` is the PCSM model. `PGOOD_EN` stays 0, and there are no switch ack ports.
  - `ppu_device_ip` is the stand-in device.
- SCP: `src/pmu/rtl/` (`scp_top`, `scp_core`: Ibex "small"; `pmu_top` is the existing
  12-domain system).
- Firmware: `src/pmu/fw/`.
  - `hal/ppu_v1` is the PPU driver; `mod/pd` is the domain manager.
  - `vendor/librpmi` is librpmi v1.0.0; `port/` holds its environment hooks.
  - `rpmi/` holds the server config and main loop.
  - `test/rpmi_loopback.c` is the loopback test.
- Tests: `bash build/regress/run_regress.sh <src> <logdir>` runs the 28-target
  regression; `make scprpmi SIM=vcs` runs the RPMI loopback test. Everything passes
  today. Keep it passing.
- Specs as text: `build/spec_txt/` (DEN 0051E PPU, DEN 0050D PCSA, AMBA LPI).
  RPMI v1.0: librpmi's headers, or raw.githubusercontent.com/riscv-non-isa/riscv-rpmi/v1.0/src/*.adoc.

## What to build
A new, minimal 4-domain system top next to `pmu_top`. Leave `pmu_top` and its tests alone.

1. **System top** (for example `src/soc4/rtl/soc4_top.sv`), containing:
   - **SCP**: reuse `scp_top`, with 4 PPU slots.
   - **Four power domains**, each a `ppu_axi_dom_top` (PPU + PCSM, always-on) around its
     IP (switched):

     | Domain | IP | Low-power mode (the domain's "OFF") |
     |---|---|---|
     | PD_CPU0 | a real Ibex ("small" config), running a tiny program from its own RAM | FULL_RET |
     | PD_CPU1 | a real Ibex | OFF |
     | PD_ACC0 | a stand-in accelerator (`ppu_device_ip`) | MEM_RET |
     | PD_ACC1 | a stand-in accelerator | OFF |

   - **Per-domain mode set.** Each PPU supports exactly ON, WARM_RST, OFF (mandatory,
     DEN 0051E §3.1.1) plus that domain's one low-power mode, set through `*_SPT_CFG`
     so IDR0 reports only those. The low-power mode is a per-domain parameter.
     LOGIC_RET and DBG_RECOV are not available on a Q-Channel PPU.
   - **A Q-Channel device adapter per domain.**
     - For a CPU domain, it accepts a low-power request only when the core is in WFI
       (Ibex `core_sleep_o`) and its bus port has drained, and it denies otherwise.
     - For an accelerator, it follows the device's busy/deny.
   - **The mailbox** (reuse W2.1 if merged): one RPMI shared-memory transport. That means
     queue SRAM, an AP-to-SCP doorbell on the SCP's `irq_external`, and a firewall that
     denies everything at reset and admits only the AP's requester ID. The AP reaches it
     over an AXI4-Lite port.
   - **An always-on AP**: a third Ibex, not power-managed, running a bare-metal test
     program that sends RPMI requests. The testbench also has an AP BFM on the same port
     for directed and negative tests, selectable per test.
   - **Power intent**: a UPF for the new top. The IPs are switched; the PPUs, PCSMs,
     adapters, SCP, mailbox and AP are always-on. RAM banks stay on the always-on rail,
     with their sleep/shutdown pins driven by the PCSM, as in `ppu_device_ip`.

2. **SCP firmware**, bare metal, with RPMI v1.0 through librpmi:
   - BASE and DEVICE_POWER on one M-mode context. Four domains, DOMAIN_ID 0–3 =
     CPU0, CPU1, ACC0, ACC1.
   - DEVICE_POWER ON puts the domain in ON and replies once it is ON, within a deadline.
     DEVICE_POWER OFF puts the domain in its configured low-power mode.
     - Use a static policy, so a busy IP can deny. On a denial, back off and retry up to
       a cap, then force it.
     - An expired deadline puts the domain in FAULT and returns an error reply.
     - `DPWR_GET_STATE` returns the AP's last vote (librpmi skips `set_state` when
       `get_state` already equals the request).
   - WARM_RST is used by the SCP only:
     - after power-up, to hold a CPU domain's core in reset until its boot address and RAM
       are ready;
     - as the recovery action for an IP that faulted.
     The AP does not request it.
   - Boot: all four domains OFF (in their low-power mode) and the AP released. The CPU IPs
     come up only when the AP asks.
   - Keep the existing rules: interrupt handlers only set flags; librpmi is called only
     from the main loop; the PPU driver rules in `hal/ppu_v1.h`.

3. **Tests** (VCS: always `SIM=vcs`; add `-licqueue` through VCSFLAGS), each a make target:
   - From the AP Ibex: discover BASE and DEVICE_POWER, then turn every domain ON and OFF.
     Check the PPU mode (PWSR) and the IP's state:
     - FULL_RET keeps the core's registers;
     - MEM_RET keeps the RAM;
     - OFF loses both.
   - A CPU IP running code is powered OFF and back ON, and restarts from its boot address.
   - From the BFM:
     - ON/OFF on each domain;
     - ON inside the OFF hysteresis window cancels the power-off;
     - a busy accelerator refuses, is retried and then forced;
     - a deadline miss gives FAULT;
     - an out-of-range DOMAIN_ID is rejected;
     - firewall deny-all before programming, and an unlisted requester denied;
     - a request for a group that isn't registered gets no reply, and the BFM times out
       cleanly.
   - Power-aware variants of the system tests under the new UPF, with zero low-power
     checker errors.
   - The existing 28-target regression plus `scprpmi` still pass.

## Working rules
- **First, before writing code:** give me the plan, meaning the file list, the memory map,
  the DOMAIN_ID and mode table, and the test list. Ask me any open question as a short
  multiple-choice question. Wait for my go.
- Make file changes with Bash, not Edit/Write, so I get plain yes/no approvals:
  - a quoted heredoc for a new file;
  - a python3 script asserting each old string occurs exactly once, for edits.
- Group related changes into one call.
- Don't invent PPU register encodings, RPMI message or state encodings, or version
  numbers: cite the spec section, or librpmi's `path:line`.
- A testbench probe must never read a register inside a switched domain (use `!== 1'b1`
  style X-tolerant compares). Keep a negative-control run that must fail, so the checks
  are proven live.
- Known traps:
  - Firmware:
    - the rv32 toolchain has no libgcc multilib, so the firmware is `-nostdlib` and must
      build with `-fno-tree-loop-distribute-patterns`;
    - RAM is tight, so link new code only into the images that use it;
    - write `LOCK_EN` only once, in the mode to be held;
    - change `PWR_DYN_EN` only after `PWR_DYN_STATUS` shows the last change.
  - VCS:
    - an `always_ff` array with a second writer is Error-[ICPD];
    - in UPF, `set_design_top` takes an instance path.
  - Xcelium's licence has expired, so VCS is the only simulator.
- Don't commit or push unless I ask. When done, report every test result with its check
  count, the files changed, deviations from this brief, and open issues.
