# SOVRA — PCSA-Conformant Power Architecture

**Status:** design, v0.1
**Supersedes:** `PCSA_FLAT_DOMAIN_SOC.md` (12 flat domains, memory always-on; removed 2026-10-05)
**Device inventory from:** `SOVRA_POWER_GATING.md` v0.5 (draft; removed 2026-10-05); the full SoC component
list with SovraV2 status (2026-10-02) is in §1
**Architecture from:** Arm PCSA (DEN 0050 D), PPU Arch Spec v1.1 (DEN 0051E),
AMBA LPI (IHI 0068C), CoreLink PCK-600 TRM (101150 r0p5)

---

## 0. What this document is

`SOVRA_POWER_GATING.md` v0.5 (removed 2026-10-05; it is in the git history)
specifies a **device inventory** and a **custom power protocol**
(`pwr_req`/`pwr_ack` plus a TileLink NoC fence, coordinated by one central
bitmap PMU).

This document keeps the devices and **replaces the protocol and the controller
topology with PCSA's**. Where the two disagree, this document wins.

| | SOVRA v0.5 | This document |
|---|---|---|
| Device LPI | `pwr_req` / `pwr_ack` | **Q-Channel** (AMBA LPI) |
| Drain protocol | NI Shell fence + outstanding counter | **Q-Channel quiescence** + §7.2.8 access control |
| Controller | one central PMU, 13-bit bitmap | **one PPU per domain** (DEN 0051E) |
| Actuation | `switch_en` / `save` / `restore` / `isolate_en` direct from PMU | **PCSM** over P-Channel (§4.1.6) |
| Clock gating | `clk_en` from PMU | **CLK-CTRL**, hardware-autonomous (§6.4.1) |
| Coordination | PMU firmware | **SCP** (§6.4) |
| Memory | island 9, gated, dependency-enforced | **split**, gated, **access-control-enforced** |
| Interrupts | PLIC | **PLIC** — unchanged, see §6 |

What is retained from SOVRA verbatim: the device list, the single `VCC_MAIN`
rail with no DVFS, the 4×4 mesh, and every Open Item that is about silicon
rather than architecture (retention library style, inrush budget, PHY vendor
capability).

---

## 1. Devices

### 1.1 SoC component list (2026-10-02)

The full SOVRA component list, with each block's code, parent cluster, design
directory, instance count and whether it is in **SovraV2** (yes / partial / no).
Block codes and directory names are as given; the Vietnamese group and parent
names are translated.

| Code | Block | Parent | Design dir | Count | In SovraV2 |
|---|---|---|---|---:|---|
| `sovra_top` | SOVRA SoC (SovraTop) | | | 1 | partial |
| | **Compute** | | | | |
| `vtcpu` | VtCPU (CVA6) | CPU cluster | `cpu` | 4 | yes |
| `vtdsp` | VtDSP (CVA6 + Ara RVV) | DSP cluster | `dsp` | 4 | yes |
| `dsp-sram` | DSP SRAM | DSP cluster | | 4 | yes |
| `rpu` | RPU | RPU cluster | | 2 | no |
| `rpu-tcm` | RPU TCM | RPU cluster | | 2 | no |
| `npu-host` | NPU host (Rocket) | NPU cluster | | 2 | yes |
| `rerocc-d` | Gemmini 8×8 via ReRoCC | NPU cluster | | 4 | yes |
| `npu-dma` | NPU DMA | NPU cluster | | 1 | yes |
| | **Interconnect** | | | | |
| `noc` | NoC 2D mesh 4×4 (Constellation) | `sovra_top` | `noc` | 1 | yes |
| `switch` | Cluster switch (CPU A, CPU B, RPU, DSP, peripherals) | `sovra_top` | | 5 | no |
| | **Memory** | | | | |
| `l2` | L2 (SiFive InclusiveCache) | `sovra_top` | | 4 | yes |
| `ocm` | Shared OCM 256 KiB | RPU cluster | | 1 | no |
| `ocmpu` | OCM protection unit | RPU cluster | | 1 | no |
| `dram` | DRAM LPDDR4 controller + PHY | `sovra_top` | | 1 | partial |
| `mscratch` | mscratch | `sovra_top` | | 1 | yes |
| | **Hardware acceleration (baseband)** | | | | |
| `fft` | FFT / IFFT | DSP cluster | | 1 | no |
| `turbo` | Turbo encoder / decoder | DSP cluster | | 1 | no |
| `polar` | Polar encoder / decoder | DSP cluster | | 1 | no |
| `ldpc` | LDPC encoder / decoder | DSP cluster | | 1 | no |
| `bbtx` | BBTX | DSP cluster | `tl_bbtx` | 1 | no |
| `bbrx` | BBRX | DSP cluster | `tl_bbrx` | 1 | no |
| | **Security** | | | | |
| `secdma` | Security DMA | security | | 1 | no |
| `aes` | AES-256 | security | | 1 | no |
| `sha` | SHA-256 | security | | 1 | no |
| `rsaecc` | RSA / ECC | security | | 1 | no |
| `trng` | TRNG | security | | 1 | no |
| `otp` | OTP | security | | 1 | no |
| | **Peripherals** | | | | |
| `eth` | Ethernet MAC 1 Gbps | high-speed peripherals | `tl_ethmac1g` | 1 | no |
| `usb3` | USB 3 | high-speed peripherals | | 1 | no |
| `sdmmc` | SD / eMMC | memory peripherals | | 1 | no |
| `qspi` | Quad-SPI | memory peripherals | | 1 | no |
| `pdma` | Peripheral DMA | low-speed peripherals | | 1 | no |
| `uart` | UART | low-speed peripherals | | 4 | partial |
| `i2c` | I²C | low-speed peripherals | | 1 | no |
| `spi` | SPI | low-speed peripherals | | 1 | no |
| `gpio` | GPIO | low-speed peripherals | | 1 | no |
| `rtc` | RTC | low-speed peripherals | | 1 | no |
| | **System** | | | | |
| `bootrom` | Boot ROM | system | | 1 | yes |
| `clint` | CLINT | system | | 1 | yes |
| `plic` | PLIC | system | | 1 | yes |
| `dm` | Debug module | system | | 1 | yes |
| `jtag` | JTAG | system | | 1 | yes |
| `errdev` | Error device | system | | 1 | yes |
| `clkgate` | Clock gater | system | | 1 | partial |
| `tilereset` | Tile reset | system | | 1 | partial |
| `perfmon` | Performance monitor | system | | 1 | no |
| `pmu` | PMU / power controller (**this IP**: SCP + PPUs) | system | | 1 | no |
| `pll` | PLL and clock generation | system | | 1 | no |
| | **Other** | | | | |
| `isp` | ISP | | | | |
| `lpu` | LPU | | | | |
| `tl-dmac` | TileLink DMAC | | `tl_dmac` | | |
| `rot` | RoT core (Ibex) | | `rot` | 1 | no |
| `sysctl` | sovra-sysctl | system | | 1 | yes |

### 1.2 What changed from the v0.5 inventory

The domain partition in §3 was derived from `SOVRA_POWER_GATING.md` v0.5, which
listed only the compute tiles, L2, DDR and the mesh. Against the list above:

- **NPU:** v0.5 had 4 Gemmini tiles. The list has 2 NPU hosts (Rocket), 4
  Gemmini 8×8 instances attached through ReRoCC, and 1 NPU DMA.
- **Added compute and memory:** DSP SRAM (4), RPU (2) with TCM (2), shared OCM
  256 KiB with its protection unit, mscratch.
- **Interconnect:** the mesh is one Constellation NoC (4×4); 5 cluster switches
  are added.
- **Added groups:** baseband accelerators (6), security (6), peripherals
  (10 kinds, 13 instances), system blocks (bootrom, CLINT, PLIC, debug, JTAG,
  error device, clock gater, tile reset, performance monitor, PLL), ISP, LPU,
  TileLink DMAC, the Ibex RoT and sovra-sysctl.
- **`pmu`** (this IP, the SCP that §6.4 makes the coordination point) is
  **not in SovraV2**; `clkgate` and `tilereset`, whose outputs overlap the PPUs'
  device clock-enable and reset controls, are **partial**.

Which of these blocks get their own power domain and PPU is not decided here:
see §3.1 and open items P6–P7.

### 1.3 Devices the current partition covers

| Count | Device | Notes from SOVRA |
|---:|---|---|
| 4 | CPU tile — CVA6 | non-coherent, TL-UH; D-cache flush mandatory before power-down |
| 4 | DSP tile — CVA6 + Ara | VRF 32×4096-bit = 16 KiB, **not** retained; `NrVInsn == 0` before power-down |
| 4 | NPU tile — Gemmini | 8 arrays of 32×32 mapped onto 4 tiles; 2 MB scratchpad + 512 KB accumulator total, **not** retained. *Superseded by §1.1: 2 Rocket hosts + 4 Gemmini 8×8 via ReRoCC + NPU DMA* |
| 4 | L2 bank | InclusiveCache, terminal on the mesh |
| 1 | LPDDR4 controller + PHY | off-mesh behind an MBus bridge; retention IO partition for self-refresh |
| 16 | Mesh router + NI Shell | 4×4 |
| 1 | SCP | replaces SOVRA's PMU as the coordination point |
| — | PLIC, wake sources (GPIO, RTC) | §6 |

---

## 2. Voltage domains

One rail, `VCC_MAIN`, no DVFS — carried over from SOVRA §1.

**Consequence, stated once:** no signal crosses two voltages, so `set_level_shifter`
appears nowhere in the UPF. Isolation cells are still required, and PCSA §7.2.9
says why in terms that have nothing to do with voltage:

> *"Isolation cells provide constant values on the outputs of powered-off or
> retained power domains to prevent unknown values propagating to operating
> domains. The isolation control is applied asynchronously to remove timing
> constraints on the control signal propagation."*

Same conclusion `PCSA_FLAT_DOMAIN_SOC.md` §3 reached (that document was removed
on 2026-10-05); it survives unchanged.

---

## 3. Power domains

### 3.1 The partition

**16 domains: 1 always-on, 15 gated.**

| # | Domain | Contents | PPU |
|---:|---|---|---|
| — | **`PD_AON`** | SCP + its ROM/RAM, wake detect, always-on wake-up timer, system counter, reset/clock generation, **all 15 PPUs, all 15 PCSMs, all 15 CLK-CTRLs**, the wake logic of every access-control gate, and the **LPDDR4 retention IO partition** | — |
| 1 | **`PD_SYSTOP`** | PLIC, 16 routers, 16 NI Shells, the access path to system memory, the SYSTOP→L2 access-control gate | `PPU_SYSTOP` |
| 2–5 | `PD_CPU0..3` | CVA6, L1 I/D, NoC port logic | `PPU_CPU0..3` |
| 6–9 | `PD_DSP0..3` | CVA6 + Ara, VRF, private scratchpad, NoC port logic | `PPU_DSP0..3` |
| 10–13 | `PD_NPU0..3` | Gemmini arrays, scratchpad, accumulator, local DMA, NoC port logic | `PPU_NPU0..3` |
| 14 | **`PD_L2`** | 4 L2 banks, MBus bridge inner side, the L2→DDR access-control gate | `PPU_L2` |
| 15 | **`PD_DDR`** | LPDDR4 controller, PHY logic | `PPU_DDR` |

> This partition predates the 2026-10-02 component list (§1.1). The NPU cluster
> now differs (§1.2), and the RPU cluster, OCM, DSP SRAM, baseband accelerators,
> security blocks, peripherals, ISP, LPU, TL-DMAC and RoT are not yet assigned to
> a domain: open item P6.

### 3.2 Three departures from SOVRA, and why

**(a) `PD_SYSTOP` exists, and the mesh is in it.**

SOVRA keeps all 16 routers and 16 NI Shells always-on, and flags their leakage
as the S3 power floor (Open Item #8). PCSA Figure 4.8 instead puts *"shared
system logic functions including the access path to system memory"* in a
**gated** SYSTOP domain, and §4.2.10 is explicit that the domain holding the
interrupt controller *"is not required to be always-on and can be powered-off in
SoC sleep states."*

The mesh **is** the access path. Putting it in SYSTOP removes 32 always-on
blocks from the S3 floor. SOVRA's objection — *"router chuyển tiếp
through-traffic của các tile khác"* — only holds while some tile is on, and
SYSTOP is relatively always-on to every compute tile (§4), so it is never gated
while a tile needs it.

**(b) `PD_L2` and `PD_DDR` are separate domains.**

They have genuinely different obligations. `PD_DDR` carries an always-on
retention IO partition that must hold `CKE` and `RESET_n` for JEDEC self-refresh
for as long as DRAM holds data; `PD_L2` has no such constraint. Gating them
together forces the L2 banks to stay powered whenever DRAM must be preserved.

The split has a direct structural consequence: **the MBus bridge now sits
between two gated domains**, which is precisely PCSA §6.5.4's LPC-Q case. See
§5.3.

**(c) Memory availability is enforced by access control, not by a dependency
rule.**

This is the most consequential change and it is treated separately in §4.2.

### 3.3 The retention IO partition

`PD_DDR`'s retention IO stays in `PD_AON` — it is a small always-on partition
inside the physical DDR block, powered from `VCC_MAIN`, holding the self-refresh
pins and the saved calibration state (ZQ, read/write levelling, DLL/delay
configuration).

Its pins **do not** pass through standard isolation cells. SOVRA §3.2(c) and
§5.4 specify this correctly and it carries over unchanged, including invariant 9
and assertion #11.

---

## 4. Power domain hierarchy and ordering

### 4.1 The relatively-always-on chain

PCSA §4.2.10 defines the requirement: *"A relatively always-on relationship is
typically preserved by powering on the domain lower in the hierarchy before its
dependent domains and powering off the domain only after dependent domains have
been powered-off."*

```
  PD_AON                         always available whenever the SoC is powered
    |
  PD_SYSTOP                      relatively always-on to every compute tile
    |
    +-- PD_CPU0..3               each depends on SYSTOP
    +-- PD_DSP0..3               each depends on SYSTOP + >=1 CPU tile
    +-- PD_NPU0..3               each depends on SYSTOP + >=1 CPU tile

  PD_L2  --> PD_DDR              L2 depends on DDR
                                 NEITHER is a strict parent of SYSTOP -- see 4.2
```

DSP and NPU tiles depend on a CPU tile because dispatch originates there. That
is a *system* dependency, not a PCSA one, and it is enforced by
`PPU_*.PWR_DEP_MASK` equivalent policy in SCP firmware rather than by hardware
ordering.

### 4.2 Why memory is NOT a strict parent — the access-control argument

SOVRA invariant 2 states *"L2/DDR không power-down khi bất kỳ compute island nào
còn ON hoặc đang transition."* That is stricter than PCSA requires, and it costs
real power: a core that is on but idle pins the entire DRAM subsystem on.

PCSA §4.2.10 permits better:

> *"The definition of available in this case is that the memory will respond to
> requests without requiring intervention from software running on AP cores.
> Therefore, it is possible for the memory system to be powered-off when agents
> that require its availability are active, **provided those requests trigger a
> mechanism that allows the transaction to be completed transparently**."*

With a **stall-and-wake** access control gate (§7.2.8), `PD_L2` and `PD_DDR` can
be gated while compute tiles remain powered. A transaction to gated memory is
stalled, a wake request is raised, the SCP powers the domain up, the gate opens,
and the transaction proceeds. The initiating core never knows.

**This replaces invariant 2.** The new invariant is weaker and more useful:

> Memory domains may be gated at any time, provided every path to them passes
> through an access-control gate in stall-and-wake mode, and provided no
> transaction is outstanding at the moment of gating.

The cost is the gate itself and the wake latency (which becomes a real
contributor to the timing budget — see §9). The benefit is that S1/S2 idle
states can gate DRAM, which SOVRA's rule forbids.

---

## 5. Low-power interface map

### 5.1 Which protocol on which interface (§6.2)

| Interface | Protocol | Why |
|---|---|---|
| PPU → device (all 15 domains) | **Q-Channel** | single request/accept; the PPU carries the mode policy, the device only reports quiescence. Matches the built `ppu_top` at `DEVCHAN_CFG = 1` |
| PPU → PCSM | **P-Channel** | mandated. §4.1.6: the PCSM channel *"has no PDENY or PACTIVE signals"* |
| CLK-CTRL → device | **Q-Channel** | §6.4.1: run-time clock gating is *"managed by clock controllers with hardware autonomous Q-Channel management"*, not by the SCP |
| SCP → PPU | register writes | DEN 0051E §6.2.1: *"The type of bus interface used is IMPLEMENTATION DEFINED."* **AXI4-Lite** is built; the spec's own example is APB |

**Q-Channel, not P-Channel, for the device interface.** The trade was analysed
in `PCSA_FLAT_DOMAIN_SOC.md` §6.2 (removed 2026-10-05) and the conclusion holds: with no DVFS there
are no operating modes to negotiate, so P-Channel's per-mode `PACTIVE` buys
nothing that policy plus `DEVQACTIVE` does not. The P-Channel upgrade path stays
open — `src/rtl/pchannel/` is built and verified — if measurement later shows
the single programmed depth is wrong often enough to matter.

### 5.2 Endpoints per domain, and the LPD-Q requirement

> **Note (2026-10-04).** This table is for the 16-domain partition of §3.1. The proposed partition is §13 (27 domains); size the LPD-Qs again once the SoC team fixes the partition (§14.6).

Every gated domain contains more than one thing that must reach quiescence. The
PPU has one `DEVQREQn`. **An LPD-Q closes that gap without touching `ppu_seq`.**

| Domain | Q-Channel endpoints | `NUM_QCHL` | Mode | Order |
|---|---|---:|---|---|
| `PD_CPU`n | CVA6, NoC port | 2 | sequencer | core → NoC port |
| `PD_DSP`n | **Ara**, CVA6, NoC port | 3 | **sequencer** | **Ara → CVA6 → NoC port** |
| `PD_NPU`n | Gemmini, local DMA, NoC port | 3 | **sequencer** | Gemmini → DMA → NoC port |
| `PD_L2` | 4 L2 banks, MBus bridge inner | 5 | sequencer | banks → bridge |
| `PD_DDR` | controller, PHY logic | 2 | sequencer | controller → PHY |
| `PD_SYSTOP` | PLIC, 16 NI Shells, access gate | 18 | expander | — |

**Ordering is not cosmetic.** In `PD_DSP`n, Ara is a master that issues through
CVA6's memory interface and out the NoC port; SOVRA §3.3.3 already requires
`NrVInsn == 0` before power-down. Quiescing in parallel lets the NoC port stop
while vector loads are still in flight — the load cannot complete, so Ara either
denies or hangs. Sequencer mode makes that unreachable. The same argument holds
for the NPU's DMA.

`PD_SYSTOP` uses expander mode because its 18 endpoints have no ordering
relationship — the NI Shells are peers.

### 5.3 LPC-Q on the MBus bridge

The `PD_L2` / `PD_DDR` split makes this real. PCSA §6.5.4:

> *"Some components, such as protocol bridges between power domains, are
> required to be controlled from the controllers of multiple power domains. To
> achieve this a Low Power Combiner (LPC) can be used… The LPC requests
> component Q-Channel quiescence when **any** controller Q-Channel becomes
> quiescent. It requests exit of component Q-Channel quiescence when **all**
> controller Q-Channels are non-quiescent."*

The MBus bridge is only useful while both `PD_L2` and `PD_DDR` are powered, so
"quiescent when either side leaves" is exactly right. **One LPC-Q, two control
channels (`PPU_L2`, `PPU_DDR`), one device channel (the bridge).**

Note this also settles the interpretation flagged in
[`ppu_clk_ctrl.sv`](../src/rtl/ppu/ppu_clk_ctrl.sv) — INTERPRETATION 2 borrowed
LPC-Q's combining rule without having built it. Building LPC-Q makes that
borrowing testable.

### 5.4 Components that remain unnecessary

| | Verdict | Reason |
|---|---|---|
| **P2Q** | not needed | Q-Channel on every device interface; the only P-Channel is PPU↔PCSM, where the PPU is the controller |
| **LPD-P** | not needed | one PCSM per domain, so no P-Channel to fan out |

---

## 6. Interrupts and wake — PLIC, not GIC

### 6.1 The decision

**PLIC is retained. No GIC is built.** PCSA §4.2.10 names two wake-up methods:

> *"Semantics for two wake-up methods: — Interrupts from the Generic Interrupt
> Controller (GIC) — **Always-on domain wake events**"*

and then makes the second one primary in exactly the states that matter:

> *"When the GIC distributor is powered-off an AP core can only be woken by
> always-on domain wake events… Other always-on domain wake events are
> **implementation defined**."*

Since `PD_SYSTOP` holds the PLIC and is gated in S3, the always-on wake path is
required regardless of interrupt controller choice. Building a GIC would add a
~900-page conformant implementation, a CPU-interface shim for every CVA6 (which
has none), and a non-mainline software stack — to duplicate a wake path PCSA
already sanctions.

### 6.2 The wake architecture

> **Superseded in part (2026-10-04, §14.1 PD5, PD7).** The PPUs are **static-only**, so the wake detect does not drive a PPU's `DEVACTIVE`. Wake lines and the SoC PLIC's output (including per-hart pending) enter the SCP through its generic input bank (§14.7 H8/H9). The SCP powers the domain up with a static request. The diagram below is the original design.

```
 interrupt source ---> PLIC (PD_SYSTOP) ---> hart n IRQ  [tile ON]
                         |
                         +--> irq_pending[n] ---> WAKE DETECT (PD_AON)
                                                        |
                                                        +--> PPU_CPUn DEVACTIVE
                                                        +--> SCP notification
 GPIO / RTC / AON wake-up timer -----------------------> WAKE DETECT (PD_AON)
```

| Block | Domain | Role |
|---|---|---|
| PLIC | `PD_SYSTOP` | normal routing while the target tile is on |
| **Wake detect** | `PD_AON` | latches `irq_pending[n]`, GPIO and timer events; drives `DEVACTIVE` on the target PPU and notifies the SCP |
| **AON wake-up timer** | `PD_AON` | PCSA §4.2.10 hard requirement, independent of interrupt controller |
| System counter | `PD_AON` | §4.2.10: *"consistent incrementing view of time for the entire time the SoC is powered-on"* |

**No `ChildrenAsleep` equivalent is needed.** GICv3 requires that handshake
because it *distributes* interrupt state into per-core redistributors. PLIC is
monolithic and sits in `PD_SYSTOP`, so a powered-down tile holds no interrupt
state to lose. Quiescence is the core masking interrupts, executing WFI, and the
PPU's Q-Channel handshake — nothing more.

**In S3**, `PD_SYSTOP` is off and the PLIC with it. Only GPIO, RTC and the AON
wake-up timer can wake the SoC, which is precisely what PCSA describes.

### 6.3 Where PCSA's ARM assumptions do not transfer

Every core is RISC-V. These are noted rather than silently mapped:

| PCSA / SBSA term | RISC-V equivalent | Transfers? |
|---|---|---|
| AP core | hart | yes — per-core power state semantics unchanged |
| GICv3 CPU interface in the core domain (§4.2.10) | — | **no equivalent.** PLIC contexts live in the PLIC, not the core. Requirement does not apply |
| GIC redistributor / `WakeRequest` | wake-detect block (§6.2) | in intent, not in form |
| PSCI `CPU_ON` / `CPU_OFF` / `CPU_SUSPEND` (DEN 0022F) | **SBI HSM** extension | state model maps closely; ABI does not |
| Generic Timer | `mtime` / `mtimecmp` | yes — always-on counter requirement unchanged |
| SBSA (DEN 0029J) | — | mostly ARM-specific; only its power-domain-hierarchy requirements apply, and PCSA §4.2.10 restates those architecture-neutrally |

**If MSI, virtualization or a very large interrupt count are needed later**, the
upgrade is
**RISC-V AIA (APLIC + IMSIC)**, not a GIC. Note that IMSIC is per-hart, which
reintroduces the per-core state problem and would bring a redistributor-style
quiescence handshake back with it.

> *Unverified here:* the PLIC and AIA claims in this section are from the RISC-V
> specifications, which are **not** in `references/standards/`. Everything
> attributed to PCSA, DEN 0051E, PCK-600 or the GIC spec below has been checked
> against the PDFs in this repository (§12); the RISC-V side has not.

---

## 7. Access control (§7.2.8)

Mandatory here, because memory is gated.

> **Note (2026-10-04, §14.1 PD5; §14.7 H15).** With static-only PPUs, a stall-and-wake gate raises a **wake line into the SCP**, and the SCP powers the domain up; there is no hardware wake through the PPU. The mesh gates are a TL-UH SystemVerilog gate built on `acg_ctrl` (planned); `rtl/acg` is built for TL-UL.

### 7.1 Placement

| Gate | Between | Response model | Wake logic |
|---|---|---|---|
| `ACG_L2` | `PD_SYSTOP` → `PD_L2` | **stall and wake** | `PD_AON` |
| `ACG_DDR` | `PD_L2` → `PD_DDR` | **stall and wake** | `PD_AON` |
| per-tile | `PD_SYSTOP` → `PD_CPU/DSP/NPU`n | **error** | — |

PCSA §7.2.8 gives three models. **Stall and wake** on the memory path — *"used
to preserve the availability of a resource while allowing it to opportunistically
enter a low-power mode"* — is what makes §4.2 work. **Error** on the tile path:
a dispatch to a powered-off accelerator is a software bug, not something to
wake for, and SOVRA §3.5 already specifies an error response there.

**Wake logic placement.** §7.2.8: *"any wake-up logic must always be implemented
in the upstream power domain."* Upstream of `PD_DDR` is `PD_L2`, which is itself
gated — so the wake logic of both gates lives in `PD_AON`, which is upstream of
everything and already holds the PPUs and the SCP. This is a deliberate reading
of the rule's intent (wake logic must survive the gated domain), not of its
letter.

### 7.2 What the gate must do

Per §7.2.8, two capabilities:

1. **Enter/exit the gated state safely** — outstanding transactions complete
   before gating. This is the Q-Channel quiescence handshake on the gate itself,
   driven by the downstream PPU.
2. **Respond during the gated state** — stall the transaction, raise the wake
   request, un-gate when the domain is available, then be transparent.

This replaces SOVRA's NI Shell fence protocol entirely: the outstanding-counter
drain becomes Q-Channel quiescence, and the `d_denied` error response becomes
the gate's error model.

---

## 8. System power states

> **Note (2026-10-04).** The SoC-level modes are now §13 (Turbo, Active, RX-Only, Eco, Sleep), managed by the AP side; the SCP executes requests and does not track modes (§14.1 PD9). The S0–S3 table below is the original analysis.

| State | CPU | DSP/NPU | `PD_SYSTOP` | `PD_L2` | `PD_DDR` | Wake by |
|---|---|---|---|---|---|---|
| **S0** Active | ≥1 ON | per workload | ON | ON | ON | — |
| **S1** Partial | 1 ON | OFF | ON | ON | ON | interrupt via PLIC |
| **S2** Idle | 1 ON, clock-gated | OFF | ON | **gateable** | **gateable, DRAM self-refresh** | interrupt via PLIC; memory access stalls and wakes |
| **S3** Deep sleep | OFF | OFF | **OFF** | OFF | OFF (logic; retention IO ON) | **GPIO / RTC / AON timer only** |

**S2 is where this architecture pays.** SOVRA's invariant 2 forces `L2/DDR` on
whenever any tile is on; access control removes that, so an idle-but-powered
core can sit with DRAM in self-refresh and the controller gated. Waking costs
one stall-and-wake round trip plus PHY resume (§9).

**S3 gains the mesh.** `PD_SYSTOP` off removes 16 routers, 16 NI Shells and the
PLIC from the always-on floor — the single largest change to SOVRA's Open Item
#8 leakage estimate.

---

## 9. Sequences

### 9.1 Domain power-down

The PPU's own sequence covers steps 3–7; steps 1–2 are system-level. Per
DEN 0051E §4.1.3 (Device Interface), §4.1.5 (Device Controls) and §4.1.6 (PPU to
PCSM Interface). The per-mode *signal levels* are Table 4-9 (reset) and Table
4-11 (isolation) — those tables give levels, not ordering.

```
 (1) SW QUIESCE      SBI HSM / firmware: flush D-cache, drain Ara (NrVInsn == 0),
                     await Gemmini completion flag, stop local DMA
      v
 (2) ACCESS CONTROL  upstream gate enters gated state; outstanding transactions
                     complete           [timeout -> abort, PPU_ERR]
      v
 (3) DEVQREQn LOW    PPU -> LPD-Q -> endpoints IN ORDER (5.2)
                                       [any DEVQDENY -> abort]
      v
 (4) DEVCLKEN LOW    CLK-CTRL stops the domain clock
      v
 (5) DEVISOLATEn     isolation asserted
      v
 (6) DEVRSTn         domain held in reset  (retention flops NOT in scope)
      v
 (7) PCSMPREQ        P-Channel to the PCSM: retention rail up, SAVE, then
                     remove the logic supply    [power_good on the way back]
```

Two orderings are load-bearing and both are already checked by the built
`ppu_power_model`: the retention rail leads the save (**PU9**), and the supply
is removed only after isolation, clock-off and reset (**PU1–PU3**).

**SOVRA §3.3's conditional survives.** Its retention assumption — balloon-latch,
`save` valid with the clock already gated — is Open Item #5. If the N28 library
only offers retention flops requiring an active clock during save, steps (4) and
(7)'s save phase must swap. That is a library-driven fork, not an architectural
one, and it is unresolved.

### 9.2 Domain power-up

```
 (1) PCSMPREQ        supply on (staged), power_good, RESTORE
 (2) DEVRSTn         released after restore   (invariant: retention outside reset scope)
 (3) DEVISOLATEn     isolation released
 (4) DEVCLKEN        clock enabled
 (5) DEVQREQn HIGH   LPD-Q releases endpoints
 (6) ACCESS CONTROL  gate becomes transparent
 (7) SW RESUME       resume vector; NPU/DSP reload scratchpad/VRF from DRAM
```

**`power_good` is new and the built PCSM does not have it.** `ppu_pcsm.sv`'s
header states the omission deliberately — DEN 0051E §6.5 gives the PPU no
power-good input, so the model's handshake latency stands in for rail settling.
SOVRA §3.1 requires a real one. See §10.

### 9.3 S3 entry

Ordering follows §4.1 in reverse, with one system constraint SOVRA §6.5 gets
right and this design keeps:

```
 [1] DSP + NPU tiles OFF
 [2] CPU tiles 3..1 OFF
 [3] CPU tile 0: flush D-cache; trigger L2 flush and WAIT for completion
     (InclusiveCache needs an agent to write its flush register -- the SCP
      cannot do it)
 [4] CPU tile 0 requests OFF
 [5] LPDDR4 to self-refresh; hand pin control to the AON retention IO partition
 [6] PD_DDR OFF, PD_L2 OFF
 [7] PD_SYSTOP OFF          <-- new: mesh and PLIC leave the AON floor
 Remaining: PD_AON + PHY retention IO
```

---

## 10. What exists, and what must be built

> **Status update (2026-10-04).** This section is the original v0.1 plan. Since then: the **LPD-Q** is built (`rtl/qchannel/qchannel_lpd.sv`; `make lpdq lpdpd`), the **access-control gate** is built for TL-UL (`rtl/acg`; `make acg acgpd`), **`power_good` is decided against** (P5, `PGOOD_EN = 0`), and the **SCP firmware** is built (`src/pmu/fw`, `src/soc4/fw`; verified on soc4). Current status and plan: §14 and §15.

### 10.1 Built and verified in this repository

| Component | Where | Reuse |
|---|---|---|
| **PPU** (Q-Channel, `DEVCHAN_CFG=1`) | [`src/rtl/ppu/ppu_top.sv`](../src/rtl/ppu/ppu_top.sv) | ×15, as-is |
| **PCSM** | [`src/rtl/ppu/ppu_pcsm.sv`](../src/rtl/ppu/ppu_pcsm.sv) | ×15, **plus `power_good`** |
| **CLK-CTRL** | [`src/rtl/ppu/ppu_clk_ctrl.sv`](../src/rtl/ppu/ppu_clk_ctrl.sv) | ×15, as-is |
| **AXI4-Lite register interface** | [`src/rtl/ppu/ppu_axi_lite_adapter.sv`](../src/rtl/ppu/ppu_axi_lite_adapter.sv) | SCP → PPU |
| **Q-Channel / P-Channel protocol** | [`src/rtl/qchannel/`](../src/rtl/qchannel/), [`src/rtl/pchannel/`](../src/rtl/pchannel/) | every LPI |
| **CDC synchronizers** | [`src/rtl/common/cdc_sync.sv`](../src/rtl/common/cdc_sync.sv) | **closes SOVRA Open Item #10** |
| **Power sequencing checker** | [`src/tb/ppu/ppu_power_model.sv`](../src/tb/ppu/ppu_power_model.sv) | PU1–PU10 ≈ SOVRA assertions #1, #2, #10 |
| **UPF flow, power-aware sim** | [`src/upf/`](../src/upf/) | methodology |

### 10.2 To build

| # | Component | Size | Spec |
|---:|---|---|---|
| 1 | **LPD-Q** | medium — 2–32 channels, expander + sequencer, denial aggregation | PCK-600 §3.1, Table A.1 |
| 2 | **Access control gate** | medium — stall-and-wake + error models, Q-Channel controlled | PCSA §7.2.8 |
| 3 | **`power_good` on the PCSM** | small — one input, one wait state | SOVRA §3.1 |
| 4 | **LPC-Q** | small — N controllers, M devices, any/all rule | PCK-600 §3.3, Table A.3 |
| 5 | **Wake detect** | small — latch, mask, `DEVACTIVE` fan-out | PCSA §4.2.10 |
| 6 | **DDR retention IO** | specialised — vendor-dependent | SOVRA §5.4, Open Item #11 |
| 7 | **SCP firmware** | out of RTL scope | PCSA §6.4 |

**Build order: 1 → 3 → 2 → 4 → 5.** LPD-Q first because every domain needs it and
nothing else depends on decisions it forces. `power_good` next because it is
small and changes a block fifteen instances depend on. Access control third — it
is what makes S2 worth having. LPC-Q fourth, needed only by the `PD_L2`/`PD_DDR`
boundary. Wake detect last, being the simplest.

---

## 11. Open items

Inherited from SOVRA and still open:

| # | Item | Owner |
|---:|---|---|
| S5 | N28 retention style — balloon-latch vs clock-required save (§9.1) | Physical design |
| S9 | Scratchpad / VRF reload cost after wake | NPU/DSP IP owners |
| S11 | LPDDR4 PHY vendor low-power capability, retrain time | System integration |
| S8 | AON leakage at S3 — **now smaller**, mesh and PLIC moved to `PD_SYSTOP` | Physical design |

New, raised by this architecture:

| # | Item |
|---:|---|
| P1 | Stall-and-wake latency budget for `ACG_L2` / `ACG_DDR` — determines whether S2 DRAM gating is worth it |
| P2 | `PD_SYSTOP` quiescence with 18 endpoints — expander mode assumed, needs confirmation that NI Shells have no inter-dependency |
| P3 | LPD-Q exit ordering: PCK-600 Table 3-1 has no reverse-order parameter, so exit walks entry order. Probably masked by `DEVRSTn` being held until the domain is up, but that is an assumption, not a guarantee |
| P4 | Whether `PD_SYSTOP` gating in S3 is compatible with debug/JTAG access requirements |
| P5 | **Switch acknowledges are assumed always to arrive — there is no timeout.** Decided, not deferred. A stuck switch hangs the transition silently, and DEN 0051E §4.1.6 gives the PCSM P-Channel no `PDENY` to report it on, so a fault path would have to be an SCP sideband (SOVRA §4.2's `PWR_ERR_STATUS` reserves a "switch fault" code). Revisit only if a real power-good detector that can fail is used. |
| P6 | **Partition for the full component list (§1.1).** Assign each block not covered by §3.1 (RPU + TCM, OCM + OCMPU, DSP SRAM, the 6 baseband accelerators, the 6 security blocks, the peripherals, ISP, LPU, TL-DMAC, RoT) to a domain, and update the NPU cluster to 2 Rocket hosts + 4 Gemmini via ReRoCC + NPU DMA. This is the SoC team's decision; it sets the PPU count, and above 15 PPUs the SCP needs an interrupt aggregator. **A proposal is in §13** (27 domains) |
| P7 | **SovraV2 scope.** `pmu` is not in SovraV2, and `clkgate` / `tilereset` are partial: decide who drives a tile's clock and reset when its PPU also has device clock-enable and reset outputs, before the PMU is integrated |

---

## 12. Specification cross-check

Every citation above was checked against the PDFs in
[`references/standards/`](../references/standards/) rather than from memory.
Recorded because two of them were wrong on the first pass.

### 12.1 Verified verbatim

| Claim | Source | Status |
|---|---|:--:|
| SYSTOP/GIC domain gateable in sleep states | PCSA §4.2.10 | ✅ |
| Two wake-up methods: GIC interrupts **and** always-on domain wake events | PCSA §4.2.10 | ✅ |
| Other AON wake events are IMPLEMENTATION DEFINED | PCSA §4.2.10 | ✅ |
| Memory may be powered-off if transactions complete transparently; "available" defined | PCSA §4.2.10 | ✅ |
| Relatively-always-on ordering rule | PCSA §4.2.10 | ✅ |
| SYSTOP holds the GIC and the access path to memory | PCSA Fig 4.8 | ✅ |
| Three access-control response models (stall-and-wake / error / accept-and-ignore) | PCSA §7.2.8 | ✅ |
| "any wake-up logic must always be implemented in the upstream power domain" | PCSA §7.2.8 | ✅ |
| Isolation cells exist for powered-off/retained outputs, applied asynchronously | PCSA §7.2.9 | ✅ |
| LPC-Q: quiescent when **any** controller requests, exits when **all** do | PCSA §6.5.4 | ✅ |
| "The SCP does not control run time dynamic gating of clocks… hardware autonomous Q-Channel management" | PCSA §6.4.1 | ✅ |
| PCSM P-Channel "has no PDENY or PACTIVE signals" | DEN 0051E §4.1.6 | ✅ |
| "The type of bus interface used is IMPLEMENTATION DEFINED" | DEN 0051E §6.2.1 | ✅ |
| LPD-Q supports 2–32 device channels; expander and sequencer modes | PCK-600 §3.1 | ✅ |
| `NUM_QCHL` 2–32; no reverse-order parameter exists | PCK-600 Table 3-1 | ✅ |
| `PD_SYSTOP`'s 18 endpoints fit one LPD-Q | PCK-600 Table 3-1 | ✅ |
| PSCI `CPU_ON` / `CPU_OFF` / `CPU_SUSPEND` / `SYSTEM_SUSPEND` all exist | DEN 0022F | ✅ |
| GIC power-management surface (`GICR_WAKER`, `ProcessorSleep`, `ChildrenAsleep`) | IHI 0069H | ✅ |

### 12.2 Corrected during the cross-check

| Was | Should be |
|---|---|
| *"The PPU's own sequence (DEN 0051E **Table 4-9**)"* | **Wrong.** Table 4-9 is *"Reset behavior for each power mode"* — a table of signal **levels**, not a sequence. The ordering is §4.1.3 (Device Interface), §4.1.5 (Device Controls), §4.1.6 (PPU to PCSM Interface); Tables 4-9 and 4-11 give the per-mode levels only |
| *"§6.2 leaves the bus IMPLEMENTATION DEFINED"* | Correct but imprecise — it is **§6.2.1**, and the spec's own worked example is APB, not AXI |

### 12.3 Not verifiable from this repository

| Claim | Why |
|---|---|
| PLIC capabilities and interrupt-count limits | The RISC-V PLIC specification is **not** in `references/standards/` |
| RISC-V AIA (APLIC + IMSIC) behaviour, IMSIC being per-hart | AIA specification not present |
| SBI HSM as the PSCI analogue | RISC-V SBI specification not present |
| CVA6 / Ara / Gemmini LPI endpoint counts (§5.2) | **Inferred from architecture, not from RTL.** No CVA6, Ara or Gemmini source is checked out — `pulp_platform/` has only `cv32e40p` and `ibex`. The `NUM_QCHL` column is a design intent, not a measurement |

The last row is the most load-bearing unverified item in this document: §5.2 sizes
every LPD-Q, and those numbers should be re-derived once the real RTL is available.

---

## 13. SoC power modes and the power-domain partition (proposal, 2026-10-02)

This section maps the proposed SoC power modes onto power domains. It
assigns every block in §1.1 to the always-on domain, to a domain of its own,
or to a domain it shares with others, and gives the reason for each choice.
It is a **proposal for the SoC team**, who own the partition. It answers open
item P6, and where it differs from the 16-domain partition of §3.1, this
section is the newer one.

### 13.1 Proposed SoC power modes

**Legend:** ● on · ◐ partial / reduced · ○ off.

| IP / block | Turbo | Active | RX-Only | Eco | Sleep |
|---|:---:|:---:|:---:|:---:|:---:|
| RPU (2× real-time) | ● | ● | ● | ● | ◐ wake path |
| CPU (4× VtCPU) | ● 4 | ◐ 2–4 | ◐ 1–2 | ○ | ○ |
| DSP (4× VtDSP) | ● 4 | ◐ 2–4 | ◐ RX | ○ | ○ |
| NPU (2 host + 4 Gemmini) | ● | ○ | ○ | ○ | ○ |
| HWA — TX (IFFT / FEC-enc / BBTX) | ● | ● | ○ | ○ | ○ |
| HWA — RX (FFT / FEC-dec / BBRX) | ● | ● | ● | ◐ detect | ○ |
| Security (AES / SHA / TRNG) | ● | ● | ◐ decrypt | ○ | ○ |
| Ethernet / USB3 (high-speed) | ● | ◐ 1 link | ○ | ○ | ○ |
| UART / I²C / SPI / GPIO / QSPI (low-speed) | ● | ● | ● | ◐ UART | ○ |
| RTC + wake source | ● | ● | ● | ● | ● |
| Memory (L2 4 MiB / mem-ctrl / DRAM) | ● | ● | ◐ | ◐ OCM | ○ retention |
| ADRV9002 RF front end | RX+TX | RX+TX | RX only | Monitor | Standby |

### 13.2 The rules used to decide

Each block is placed by these rules, applied in order.

| Rule | Statement | Why |
|---|---|---|
| **R1 — always-on is minimal** | A block goes in `PD_AON` only if it must work in **Sleep**, or it controls power (the SCP, the PPUs, the PCSMs, clock and reset generation). | Everything in `PD_AON` leaks in every mode, including Sleep, so its contents set the Sleep power floor. The controllers must be relatively always-on to what they control (PCSA §7.2.3: *"The simplest approach is to place all the PPUs with the SCP in the always-on domain."*). |
| **R2 — a different row means a different domain** | Two blocks share a domain only if they need the same state in **every** mode of §13.1. If any mode needs one on and the other off, they are separated. | A domain has one power state. Sharing a domain across different rows forces the larger block on in the mode where only the smaller one is needed, and that leakage is what power gating exists to remove. |
| **R3 — a variable count means one domain per instance** | Where a mode needs *some* of N identical instances (CPU 2–4 or 1–2, DSP 2–4 or RX), each instance gets its own domain. | The ◐ is a count, so it can only be met by switching instances independently. |
| **R4 — group when the overhead outweighs the saving** | Small blocks whose rows match, or whose only difference is a ◐ inside a mode, are grouped, and their partial state is met by **clock gating**, not power gating. | Every domain costs a power switch, isolation on every output, a PPU, a PCSM, firmware sequencing and entry/exit energy and latency. For a small block, such as one UART among four, the leakage saved does not pay for that. |
| **R5 — memory keeps state with RAM pins, not domains** | SRAMs that must keep data while their logic is off (OCM, TCM, DSP SRAM) stay on the always-on rail with sleep/shutdown pins driven by their domain's PCSM, through the PPU's MEM_RET mode and per-bank retention registers. | This is how `ppu_device_ip` and soc4 already work, and it is what a compiled SRAM macro supports. A separate switched domain per memory would add switches and isolation and still need the macro's retention pins. |
| **R6 — caches are flushed and powered off** | L2 is not retained across Eco or Sleep. | Keeping 4 MiB of cache contents leaks more than refilling it costs after a wake, and DRAM, kept in self-refresh, already holds the data. |
| **R7 — the low-power island owns its fabric** | Every block that stays on in **Eco** must be reachable from the RPU without the mesh. | Otherwise the 4×4 mesh (`PD_SYSTOP`) must stay on in Eco just to connect a few small blocks, and that mesh is the largest single item in §8's S3 floor. See §13.5. |

### 13.3 The partition

27 gated domains plus `PD_AON`, so 27 PPUs.

| Domain | Contents | Placement | Why (rules) |
|---|---|---|---|
| **`PD_AON`** | SCP with its ROM and RAM; the 27 PPUs, PCSMs and CLK-CTRLs; RTC and wake detect, including the edge detectors of the GPIO wake pins; system counter; PLL and clock generation (`pll`, with the PLL itself powered down by its enable in Sleep); `clkgate`, `tilereset` and reset generation; `sysctl`, including the OTP shadow registers; **CLINT** (`mtime` must count through every mode, PCSA §4.2.10, and `mtimecmp` is a hart wake source; corrected 2026-10-04, see §14 A7); JTAG TAP and the debug power request; the LPDDR4 retention IO; the ADRV9002 control-pad retention (§13.7); the interrupt aggregator for more than 15 PPUs | **always-on** | R1. Only what Sleep needs and what controls power. |
| `PD_SYSTOP` | NoC 4×4 mesh (Constellation); the CPU A, CPU B and DSP cluster switches; PLIC; Boot ROM; debug module; error device; mscratch; TL-DMAC; performance monitor | **shared** | All of these are needed exactly when any mesh client is on, which is Turbo, Active and RX-Only (R2). Each one is small, and its use follows the mesh (R4). As in §3.2(a), the mesh is the access path, so it is gated rather than always-on. The cluster switches are too small to justify a domain of their own (R4). |
| `PD_CPU0..3` | One VtCPU each (CVA6 with L1) | **separate × 4** | R3: Active needs 2–4 and RX-Only 1–2. CPU0 is the last core on. |
| `PD_DSP0..3` | One VtDSP each (CVA6 + Ara, VRF) with its DSP SRAM on the always-on rail | **separate × 4** | R3: Active needs 2–4, RX-Only a subset. The DSP SRAM uses R5, so it can be retained between bursts (MEM_RET); the VRF is not retained (§1.3). |
| `PD_NPU` | 2 NPU hosts (Rocket), 4 Gemmini via ReRoCC, NPU DMA | **shared, one cluster domain** | R2: every part has the same row (Turbo only). One PPU instead of seven. If workloads later need half the NPU, split it into two host-plus-2-Gemmini domains. |
| `PD_L2` | 4 L2 banks (4 MiB) | **one domain** | R2 and R6: all banks follow the same row. The ◐ in RX-Only is met by clock gating idle banks. Bank power-down needs the cache to support disabling a bank or way, because InclusiveCache interleaves addresses over the banks (P9). |
| `PD_DDR` | LPDDR4 controller and PHY logic | **separate** | Different obligations from L2 (§3.2(b)). It is off in Eco and Sleep with DRAM in self-refresh, held by the retention IO in `PD_AON`. |
| `PD_RPUSYS` | RPU cluster switch, shared OCM 256 KiB on the always-on rail, OCM protection unit | **separate (cluster)** | The RPU row differs from every other block's: it stays on in Eco. Its OCM is the Eco working memory ("◐ OCM") and is kept in Sleep (R5, MEM_RET). It is the parent of `PD_RPU0..1` and the hub of the Eco island (§13.5). |
| `PD_RPU0`, `PD_RPU1` | One RPU each, with its TCM on the always-on rail | **separate × 2** | Sleep needs only "◐ wake path". RPU0 goes to MEM_RET (TCM kept, logic off) and restarts from resume code in its TCM, which avoids retention flops (FULL_RET) in the core. RPU1 goes OFF. Separate domains are what allow one RPU in MEM_RET and the other OFF (R3). |
| `PD_BBRX` | BBRX | **separate** | Its row (on through Eco for detect) differs from the rest of the baseband (R2). In Eco only its detect path runs; the rest is clock-gated (R4). |
| `PD_BBCORE` | FFT/IFFT, turbo, polar, LDPC | **shared** | Each of these blocks is one IP for both directions (FFT *and* IFFT, encoder *and* decoder), so it must be on whenever TX **or** RX is on. That is Turbo, Active and RX-Only for all four, the same row (R2). If turbo, which LTE uses and NR does not, is large, it is the first candidate to split out. |
| `PD_BBTX` | BBTX | **separate** | Off in RX-Only, while the rest of the baseband stays on (R2). |
| `PD_SECAES` | AES-256, security DMA | **separate** | RX-Only needs "◐ decrypt": AES and the DMA that feeds it, without SHA, RSA/ECC or TRNG (R2). |
| `PD_SEC` | SHA-256, RSA/ECC, TRNG | **shared** | Same row: Turbo and Active only (R2). |
| `PD_ROT` | RoT core (Ibex), OTP controller | **separate** | Not in the mode table. It is needed at boot and for key operations, and OTP is read once into the `sysctl` shadow, so it can be off otherwise. Whether the RoT must supervise each resume is a security decision (P11). |
| `PD_ETH`, `PD_USB3` | Ethernet MAC 1 Gbps; USB 3 | **separate × 2** | Active needs "◐ 1 link": either one alone (R3). Their PHYs' analog supplies follow the PHY vendor's power-down pins. |
| `PD_PERI` | Peripheral switch, UART × 4 | **shared** | Eco needs a UART ("◐ UART"), so the switch that reaches it must also be on in Eco. Three idle UARTs are clock-gated rather than split off (R4). |
| `PD_PERILS` | I²C, SPI, GPIO controller, QSPI, SD/eMMC, peripheral DMA | **shared** | Same row: on through RX-Only, off in Eco and Sleep (R2). They are small, so one domain (R4). The GPIO **wake** detectors are in `PD_AON`, so turning the GPIO controller off does not lose wake-up. |
| `PD_ISP`, `PD_LPU` | ISP; LPU | **separate × 2** | Not in the mode table, and their use is independent of everything else, so they are OFF unless an application turns them on. Revisit once their modes are defined (P10). |

### 13.4 Domain states per mode

PPU modes are as in DEN 0051E Table 3-1. "ON\*" means ON only if the mode's
count includes that instance.

| Domain | Turbo | Active | RX-Only | Eco | Sleep |
|---|:---:|:---:|:---:|:---:|:---:|
| `PD_AON` | on | on | on | on | on |
| `PD_SYSTOP` | ON | ON | ON | OFF ¹ | OFF |
| `PD_CPU0` | ON | ON | ON | OFF | OFF |
| `PD_CPU1` | ON | ON | ON\* | OFF | OFF |
| `PD_CPU2`, `PD_CPU3` | ON | ON\* | OFF | OFF | OFF |
| `PD_DSP0` | ON | ON | ON | OFF | OFF |
| `PD_DSP1` | ON | ON | ON\* | OFF | OFF |
| `PD_DSP2`, `PD_DSP3` | ON | ON\* | OFF | OFF | OFF |
| `PD_NPU` | ON | OFF | OFF | OFF | OFF |
| `PD_L2` | ON | ON | ON ² | OFF | OFF |
| `PD_DDR` | ON | ON | ON | OFF, DRAM self-refresh | OFF, DRAM self-refresh |
| `PD_RPUSYS` | ON | ON | ON | ON | MEM_RET (OCM kept) |
| `PD_RPU0` | ON | ON | ON | ON | MEM_RET (TCM kept) |
| `PD_RPU1` | ON | ON | ON | ON | OFF |
| `PD_BBTX` | ON | ON | OFF | OFF | OFF |
| `PD_BBCORE` | ON | ON | ON | OFF | OFF |
| `PD_BBRX` | ON | ON | ON | ON ³ | OFF |
| `PD_SECAES` | ON | ON | ON | OFF | OFF |
| `PD_SEC` | ON | ON | OFF | OFF | OFF |
| `PD_ROT` | on demand | on demand | on demand | OFF | OFF |
| `PD_ETH`, `PD_USB3` | ON | one ON ⁴ | OFF | OFF | OFF |
| `PD_PERI` | ON | ON | ON | ON ⁵ | OFF |
| `PD_PERILS` | ON | ON | ON | OFF | OFF |
| `PD_ISP`, `PD_LPU` | per application | per application | OFF | OFF | OFF |

¹ Only if the Eco island has its own fabric (§13.5); otherwise ON.
² The ◐ is met by clock-gating idle banks; bank power-down depends on P9.
³ Detect path only; the rest of BBRX is clock-gated.
⁴ Whichever link is in use.
⁵ One UART clocked, three clock-gated.

**What each PPU must support** (static modes, as soc4 configures them):
- every PPU supports ON, WARM_RST and OFF (mandatory);
- `PD_RPUSYS` and `PD_RPU0` add MEM_RET; `PD_DSP0..3` add MEM_RET if DSP SRAM is kept between bursts;
- FULL_RET is optional, for `PD_CPU0` only if its resume latency matters (soc4 demonstrates it);
- no domain needs FUNC_RET, MEM_OFF or LOGIC_RET for these modes.

### 13.5 The Eco island

Eco leaves on only `PD_AON`, `PD_RPUSYS`, `PD_RPU0..1`, `PD_PERI` (one UART)
and `PD_BBRX` (detect). Everything on the mesh is off: CPU, DSP, NPU, L2 and
the DDR controller. **Requirement on the interconnect:** the RPU cluster switch
must reach the peripheral switch (for the UART) and BBRX's registers and
detect interrupt **without passing through the mesh**. This can be a direct
link between switches, or BBRX also attached to the RPU switch.

If the topology instead routes these accesses through the mesh, `PD_SYSTOP`
must stay ON in Eco. That costs the leakage of 16 routers, the NI shells and
the PLIC, the item §8 identifies as the largest part of the floor. This is
the most valuable topology request in this section (P8).

The RPU's interrupts in Eco cannot come from the PLIC (it is in `PD_SYSTOP`).
They must come from an interrupt controller inside the RPU cluster, with the
wake sources routed to it and to the SCP from `PD_AON`.

### 13.6 Hierarchy (relatively always-on)

```
PD_AON
 ├── PD_SYSTOP ─┬── PD_CPU0..3
 │              ├── PD_DSP0..3
 │              ├── PD_NPU
 │              ├── PD_BBTX, PD_BBCORE
 │              ├── PD_SECAES, PD_SEC, PD_ROT
 │              ├── PD_ETH, PD_USB3
 │              ├── PD_ISP, PD_LPU
 │              └── PD_L2 ──► PD_DDR       (access-controlled, §4.2: not strict parents)
 ├── PD_RPUSYS ─── PD_RPU0, PD_RPU1
 ├── PD_PERI ───── PD_PERILS
 └── PD_BBRX                                (data path via PD_SYSTOP when it is on;
                                             detect and registers via the Eco island)
```

Each parent is powered on before its children and off after them
(PCSA §4.2.10, quoted in §4.1). The SCP enforces this in its firmware domain
table, as soc4's firmware does for its four domains.

### 13.7 The RF front end and pad retention

The ADRV9002 is off-chip; its modes (RX+TX, RX only, Monitor, Standby) are set
by the SoC through SPI and GPIO control pins. In Eco and Sleep, `PD_PERILS`
(SPI, GPIO) is **off**, but the transceiver must stay in Monitor or Standby.
So:

- its control pins need **pad retention in `PD_AON`**, latched before the domain
  goes off, like the LPDDR4 retention IO (§3.3);
- the RF mode change is a step in the mode-entry sequence: the SCP or RPU
  programs Monitor or Standby over SPI **before** `PD_PERILS` is turned off,
  and back **after** it is on again;
- in Eco, the detect signal from BBRX (§13.5) is what wakes the system to
  RX-Only.

### 13.8 Relation to the rest of this document

- **§3.1 partition:** `PD_SYSTOP`, the per-core CPU and DSP domains, and the
  `PD_L2`/`PD_DDR` split are kept. The NPU becomes one cluster domain (it was
  4 tiles), and 15 domains are added for the blocks of §1.1.
- **§8 states:** Turbo and Active are S0, with RX-Only between S0 and S1
  (fewer cores, no TX). Eco and Sleep are both below S3's compute floor: Eco
  keeps the RPU island, and Sleep keeps only `PD_AON` with OCM and TCM
  retained and DRAM in self-refresh.
- **Single rail (§2):** if "Turbo" means a higher frequency *at a higher
  voltage*, the single `VCC_MAIN` rail with no DVFS no longer holds, and the
  CPU, DSP and NPU domains would also need their own voltage domains with level
  shifters (P8). The table above assumes Turbo means more instances on at the
  same voltage.
- **SCP scale:** 27 PPUs exceed the SCP's 15 fast interrupt lines, so an
  interrupt aggregator in `PD_AON` is required (P6). The firmware domain table
  takes the 27 entries without structural change.

### 13.9 Open items raised by this section

| # | Item | Owner |
|---:|---|---|
| P8 | **Eco island fabric and Turbo voltage.** Confirm that the RPU switch reaches the peripheral switch and BBRX without the mesh (§13.5); otherwise `PD_SYSTOP` stays on in Eco. Confirm that Turbo needs no higher voltage (§13.8). | SoC / interconnect |
| P9 | **L2 partial state.** Can InclusiveCache disable banks or ways at run time? If it can, RX-Only's ◐ can power down banks; if it cannot, it is clock gating only. | SoC / memory |
| P10 | **ISP and LPU modes.** They are not in §13.1; define their rows so their domains get a policy. | SoC |
| P11 | **RoT on resume.** Whether the RoT must run on every resume (secure-boot chain) or only at cold boot sets `PD_ROT`'s policy and the resume latency. | Security |

---

## 14. Power-control platform checklist (revised 2026-10-04)

This checklist covers only what the **power-control platform** builds: its
hardware and firmware, which serve power-control requests from the AP side.
Work owned by other teams is in §14.6 as external dependencies.

**Status:**
- ✅ done and verified;
- ◐ partly built, or designed but not built;
- ❌ missing.

### 14.1 Decisions that define the platform (2026-10-04)

| # | Topic | Decision | Consequence |
|---:|---|---|---|
| PD1 | Interrupt controller | **Only the SoC has a PLIC.** Its output is wired to the SCP. Power-control interrupts (PPUs, mailbox doorbells) connect **inside the SCP side** | No PLIC is built for the SCP. The SCP needs its own way to take more interrupt sources than Ibex's 15 fast lines (H7) |
| PD2 | Timer | **The SCP's own timer only.** The AP's CLINT and the always-on system counter belong to the SoC | The existing SCP timer stays; CLINT placement is external (§14.6) |
| PD3 | Scope of this checklist | Items owned by others are removed and listed in §14.6 | — |
| PD4 | Device-side hardware | **The platform builds** the CVA6 and Rocket Q-Channel adapters and a **TL-UH** access-control gate | H14, H15 |
| PD5 | PPU policy | **Static only**, in every domain | No hardware (DEVQACTIVE) wake. Every power-up, including a CPU's wake from idle and memory stall-and-wake, is an SCP decision triggered by an interrupt. §6.2's DEVACTIVE path and §7's hardware wake are superseded (H22) |
| PD6 | Who requests | **Two agents: the AP (VtCPU cluster) and the RPU.** This supersedes D3 | A second RPMI transport and firewall entry, per-agent votes (a domain is ON while any agent votes ON) and per-domain permissions (H11, F6) |
| PD7 | Wake path in Eco and Sleep | **Raw wake lines go straight into SCP interrupt inputs.** The platform provides the inputs and firmware handling, not a wake-detect block | H9, F10 |
| PD9 | SoC power modes | **The SCP does not know the SoC modes** (§13). It receives control requests and executes them; Turbo … Sleep are managed by the AP side | No mode manager in the SCP (F8 dropped); the §13.4 matrix is the AP's to sequence |
| PD10 | SCP clock | **One fixed always-on clock**, supplied by the SoC | No clock switching in the platform; the timer tick is a platform constant (H19, F14 dropped) |
| PD8 | Tile clock and reset | **The SoC's `clkgate` / `tilereset` are the authority.** The PPU's device clock-enable and reset outputs become **requests** into them, and the platform sequences on their acknowledgement | A request/acknowledge bridge (H16) |

### 14.2 Hardware

| # | Item | Status | Notes |
|---:|---|:---:|---|
| H1 | PPU (DEN 0051E, Q-Channel) | ✅ | Every option a parameter; static configuration used (PD5) |
| H2 | PCSM: settle counters, 8 RAM-bank pins | ✅ | No power-good (P5) |
| H3 | CLK-CTRL | ✅ | |
| H4 | LPD-Q, for domains with several endpoints | ✅ | `qchannel_lpd`; per-domain sizing comes with the SoC partition |
| H5 | Domain wrapper `ppu_axi_dom_top` | ✅ | |
| H6 | SCP: Ibex, RAM, **own timer**, AXI4-Lite to the PPUs | ✅ | PD2 |
| H7 | **SCP interrupt inputs beyond 15** | ✅ | 2026-10-05: `scp_irq` (glue, `src/pmu/rtl/scp_irq.sv`) inside `scp_top` at `0x0001_1000`, `NUM_IRQ` inputs (≤ 32) onto `irq_external`; every PPU, the doorbell, the wake lines and the SoC PLIC input go through it, the fast lines are tied LOW. Not a PLIC (PD1); soc4bfm B12 `IRQ_PPU` |
| H8 | **SoC PLIC input** | ✅ | 2026-10-05: the PLIC's output and its per-hart pending are plain inputs of `scp_irq` (soc4: inputs 5-7); a CPU in FULL_RET and one in OFF powered up from per-hart pending (soc4bfm B12 `WAKE_PLIC`, `WAKE_LEVEL`) |
| H9 | **Raw wake-line inputs** | ✅ | 2026-10-05: the same generic bank: per input a two-flop synchroniser (reused `rtl/common/cdc_sync`), level/edge, mask and W1C pending; RTC, GPIO, BBRX, debug request and access-gate wakes are soc4 inputs 8-13 (soc4bfm B12; soc4neg M4) |
| H10 | AP mailbox (TL-UL) and firewall | ✅ | soc4 |
| H11 | **Second agent: RPU mailbox transport** | ✅ | 2026-10-05: `soc4_mbx` is an N-agent mailbox (`NUM_AGENTS` transports on `NUM_PORTS` TL-UL ports, each agent bound to a port): per agent a 1 KiB window of one shared `tc_sram`, its own doorbell `RING[k]` as its own `scp_irq` input, and its own firewall entry; soc4 has the AP on port 0 and the RPU stand-in on port 1 (soc4bfm R0, R1) |
| H12 | **Firewall source ranges** | ✅ | 2026-10-05: per transport `FW_EN[k]`, `FW_VAL[k]`, `FW_MASK[k]`, deny-all at reset; window k admits `(a_source & FW_MASK[k]) == FW_VAL[k]` through agent k's port only; `DENY_CNT[k]` and `FW_LAST` with the transport index (soc4bfm R0 `AG_RESET_DENY`, R1 `FW_AGENT`, `FW_MASK`; soc4neg M5) |
| H13 | **Mailbox port compatible with the SoC fabric** | ✅ | 2026-10-05: `soc4_tl_bound` on every mailbox port: `TL_A_USER_DEFAULT` for a host without `a_user` (soc4's port 1), `CmdIntgCheck = 0`, elaboration checks of address/data/source widths; the SoC converts TL-UH to TL-UL with standard Chipyard widgets (TLFragmenter, TLWidthWidget, TLSourceShrinker) |
| H14 | **Device adapters** | ✅ | 2026-10-06: one READY-bit Q-Channel adapter for **CVA6 and Rocket** (`src/rtl/adp/hart_ready_adp.sv`, glue; READY registers on the vendored `tlul_adapter_reg`, `hart_ready_regs.sv`): per-hart READY set by the hart, cleared by wake, return to ON and hart reset (clear wins); accepts only with READY and every TileLink port drained (A/D, and B/C/E on a TL-C port), denies otherwise (`make readyadp`, 2 mutants). Ibex WFI (soc4) and generic accelerator unchanged (PD4) |
| H15 | **Access-control gates** | ✅ | 2026-10-06: TL-UL (`rtl/acg/acg_tlul.sv`) and **TL-UH** (`acg_tluh.sv` on the unmodified `acg_ctrl`, data path `tluh_gate.sv`, glue: no open-source TL-UH gate): a burst completes before gating, every beat of a denied message answered, atomics as messages; stall-and-wake raises `wake_o` into an SCP input (PD5, H9) (`make acgtluh`, 4 mutants) |
| H16 | **Clock/reset request bridge** | ✅ | 2026-10-06: `src/rtl/ckrst/ckrst_bridge.sv` (glue), one per domain: forwards DEVCLKEN and the two device resets as requests, flags LATE (the PPU moved on first), MISSING and SPURIOUS acknowledgements as a sticky status (soc4_ctrl `CKRST_STAT`) and an SCP input (soc4 input 15); no PPU change (the wrappers only bring DEVCLKEN out as `dev_clken_req`) (`make ckrst`, mutant; in all four soc4 domains) |
| H17 | **Generic N-domain top** | ❌ | The domain count as a parameter, with a standard device-side port per domain (§15.4 phase 2) |
| H18 | **SCP watchdog** | ✅ | 2026-10-05: `scp_wdog` (glue, `src/pmu/rtl/scp_wdog.sv`) inside `scp_top` at `0x0001_2000`: CTRL (EN, sticky LOCK), TIMEOUT, KICK (key; a wrong one resets at once), COUNT, CAUSE on power-on reset only; expiry drains the AXI4-Lite manager, then resets the SCP subsystem alone, the PPUs and domains keep their state (soc4bfm W1, soc4wdog; soc4neg M7, M8) |
| H19 | **SCP clock-rate change** | ❌ | The SCP runs from a slow always-on clock in Sleep. The timer tick and any time constants must follow the rate, and if the SCP switches clocks itself, a glitch-free switch is needed |
| H20 | **Pad-retention control outputs** | ❌ | Register-driven outputs to the SoC pad ring (DDR retention IO, RF control pins; §3.3, §13.7) |
| H21 | SCP → agent notification interrupt | not planned | Both agents poll (D3 polling kept) |
| H22 | Remove the dynamic paths from the docs | ❌ | §6.2's DEVACTIVE wake and §7's hardware wake are replaced by wake lines into the SCP (PD5, PD7) |

### 14.3 Firmware

| # | Item | Status | Notes |
|---:|---|:---:|---|
| F1 | PPU driver `hal/ppu_v1` | ✅ | 2026-10-05 (phase 1, 63e671d): `ppu_set_ret_ram` writes each RAM-retention register IDR1 reports; `ppu_set_policy` refuses `PWR_DYN_EN` on a PPU with no dynamic mode (`PPU_E_UNSUPPORTED`); the `soc4_ret` helper removed |
| F2 | `pd`: non-blocking static requests with deadlines | ✅ | |
| F3 | Policy: hysteresis, deny → retry → force, FAULT, WARM_RST recovery, CPU cold boot and FULL_RET resume | ✅ | Built for a single agent; the agents' votes are combined into it since phase 3 (F6) |
| F4 | RPMI server: BASE + DEVICE_POWER | ✅ | One context |
| F5 | **One domain table** | ✅ | 2026-10-05 (phase 1, 63e671d): `SCP_PLAT_DOMAINS` in the platform header (`soc4/fw/soc4_plat.h`) is the only domain table: name, kind, the low-power mode RPMI OFF maps to, retention registers, expected IDR0/IDR1, CPU boot details; `pd`, the policy, the RPMI server and the CPU loader read it |
| F6 | **Two agents** | ✅ | 2026-10-05: the agent table `SCP_PLAT_AGENTS` (one librpmi context and transport each, BASE + DEVICE_POWER); a vote per agent per domain combined into the policy's one vote (ON while any agent votes ON); the domain table's `.agents` bitmap refuses others with `RPMI_ERR_DENIED`; `GET_STATE` is the caller's own vote; the lowest permitted agent owns a domain's wake vote (soc4bfm R1; soc4neg M6) |
| F7 | **Domain dependencies** | ❌ | Parent before child (§13.6) |
| F8 | **SoC mode manager** | ❌ | Turbo … Sleep: states, transitions, the per-domain sequence of §13.4, and triggers (an agent's request, a wake line) |
| F9 | **RPMI HSM, SYSTEM_SUSPEND, SYSTEM_RESET** | ❌ | HSM for per-hart power from OpenSBI; SYSTEM_SUSPEND for Eco and Sleep entry; SYSTEM_RESET (cold, D20) |
| F10 | **Interrupt handling** | ✅ | 2026-10-05: the input table `SCP_PLAT_INPUTS` in the platform header (power up, notify, wake reason, ignore; plus PPU and doorbell); handlers only set flags, the main loop acts; a power-up is a wake vote held until the owner's next OFF (`mod/policy.h`, WAKE INPUTS) |
| F11 | **Clock/reset bridge handling** | ✅ | 2026-10-06: the domain table's `.ckrst_lat` sets CLKEN_RST/CLKEN_ISO/RST_HWSTAT_DLY (`pd_dev_delays_of`); a bridge fault is logged (`FLOG_CLKRST`), the votes dropped and the domain put in FAULT (`mod/policy.h`; `make soc4ckrst`, soc4neg M9) |
| F12 | **Watchdog, fault reporting, logging** | ✅ | 2026-10-05: kick once per completed main-loop pass; after a watchdog reset the firmware reads CAUSE and takes the domains over with no PPU transition (`pd_adopt`, `policy_adopt`, votes kept); a 32-entry fault log (deadline FAULT, forced power-down, firewall denials, watchdog reset; clock/reset bridge reserved) in a RAM block crt0 does not touch, magic and checksums (`mod/flog.h`) |
| F13 | **Inrush-aware sequencing** | ❌ | When a mode change turns many domains on, power them up one after another, or within a budget |
| F14 | **Timer rate change** | ❌ | Deadlines and hysteresis stay correct when the SCP clock changes (H19) |

### 14.4 Verification

| # | Item | Status |
|---:|---|:---:|
| V1 | Unit tests, soc4 system and power-aware runs, negative controls (41 targets on 2026-10-04; the regression is 31 targets since `pmu_top`'s retirement and phases 1–6, `src/tb/README.md` §3) | ✅ |
| V2 | A testbench whose checks follow the domain list (N domains) | ❌ |
| V3 | Two-agent tests: votes, permissions, firewall per transport | ✅ |
| V4 | Wake-line, SoC PLIC input and access-gate wake tests in every mode | ❌ |
| V5 | Clock/reset bridge against a model of the SoC blocks | ✅ 2026-10-06: `tb/ckrst/soc_ckrst_model.sv` (configurable latency) in `ckrst` and every soc4 run; `soc4ckrst` K1 |
| V6 | CDC of the platform's own logic with several clocks | ✅ 2026-10-06, Synopsys VC (`make vccdc`, `make vcrdc`; [`src/signoff/SIGNOFF_REPORT.md`](../src/signoff/SIGNOFF_REPORT.md) §3, §4). **CDC:** soc4_top with its raw wake/PLIC lines asynchronous (all 9 synchronised); `ppu_axi_dom_top` with dclk asynchronous to aclk. That run found CDC-1: the raw DEVQACTIVE is unsynchronised into the clock controller unless `CLK_QACTIVE_SYNC = 1` (requirement R3). CDC-3 (DEVPORESETn synchronised twice) is open. **RDC:** soc4_top; 7,325 paths in 6 waived classes, among them the watchdog reset: clk_i-launched, after the drain |
| V7 | Static low-power checks and formal proofs of the platform handshakes | ✅ 2026-10-06 (`make vclp`, `make vcformal`, `make vcformalneg`; SIGNOFF_REPORT.md §2, §6). **VC LP** `-stage upf`: 66 redundant isolation cells removed (`-no_isolation`). LP-2 is open: VDD_RET off in ON, which depends on the retention style S5. The netlist stages need synthesis. **VC Formal:** 271/271 assertions fully proven and 127/127 covers hit on scp_irq, scp_wdog, ckrst_bridge, hart_ready_adp, soc4_mbx, tluh_gate and qchannel (LPI §2.1); all 10 mutants caught. Open: F-TLUH-1 (dev_a_valid_o withdrawn before ready) and F-ADP-3 (a pending TL-C Probe does not block power-down) |

### 14.5 This document

| # | Out of date |
|---:|---|
| X1 | §10: LPD-Q and the access gate are built; `power_good` is decided against; the SCP firmware is built |
| X2 | §5.2 endpoint table and §8 states describe the 16-domain partition |
| X3 | §6.2 wake through DEVACTIVE, and §7 hardware stall-and-wake: superseded by PD5 and PD7 |
| X4 | `RPMI_STACK_DECISIONS.md` D3 (AP is the only agent): superseded by PD6 |

### 14.6 External dependencies (owned by others; what the platform needs from them)

| Dependency | Needed by | Owner |
|---|---|---|
| Final power-domain partition and the PPU count (P6, proposal in §13) | H17, F5 | SoC |
| SoC PLIC placement and its output to the SCP, per-hart pending included | H8, F10 | SoC |
| CLINT / always-on system counter placement (the AP's time) | — | SoC |
| Wake sources wired as raw lines (RTC, GPIO wake, BBRX detect, debug request) | H9 | SoC |
| `clkgate` / `tilereset` request and acknowledgement interface and latency | H16 | SoC |
| Each agent's TileLink source-ID range and the mailbox address map | H12, H13 | SoC |
| Eco-island fabric and Turbo voltage (P8); L2 bank disable (P9); ISP and LPU modes (P10) | F8 | SoC |
| CVA6, Rocket, Ara, Gemmini, NoC and DMA quiescence signals (RTL) | H14, H4 | IP owners |
| Isolation clamp value of every switched output | UPF | IP owners |
| Switch settle times, retention style (S5), RAM macro list | PCSM parameters, F5 | Physical |
| Pad-ring partition; off-chip supplies and PMIC | H20 | SoC / board |
| RoT role on resume (P11); SCP firmware source and trust | boot | Security / SW |
| OpenSBI and RPU firmware using the software contract; the L2 flush before power-down | F6, F9 | Embedded |

### 14.7 Implementation choices (2026-10-04)

The user chose an implementation, or a deferral, for every item above that is
not done.

| Item | Decision | Implementation |
|---|---|---|
| F5 | **Planned** | One **firmware** domain table in the platform header (count, names, low-power mode, kind, retention, CPU boot details, agent permissions); `policy.c`'s hard-coded table removed |
| H17 | **Not planned** | The top keeps instantiating each domain **by hand** (no generic N-domain top) |
| H7 | **Planned** | An SCP-side interrupt status/enable block: **every** source (PPUs, doorbells, wake lines, SoC PLIC input) goes through it onto one Ibex line; fast lines unused |
| H8, H9 | **Planned** | **One generic input bank**: N synchronised inputs, each set to level or edge, with mask and W1C pending. The SoC PLIC's output, its per-hart pending, RTC, GPIO wake, BBRX detect, the debug request and access-gate wake requests are all inputs |
| F10 | **Planned** | **Table-driven**: the platform header maps each input to an action (power up a domain, notify the policy, record a wake reason, ignore). Handlers only set flags; the main loop acts |
| H11, F6 | **Planned** | **N-agent mailbox**: `soc4_mbx` generalised to NUM_AGENTS transports (queues + doorbell + firewall entry each); one librpmi context per agent; per-domain vote array (ON while any agent votes ON) and permission bitmap. SOVRA uses 2 (AP, RPU) |
| H12 | **Planned** | Firewall: SCP-programmed **value + mask** of `a_source` per transport, deny-all at reset |
| H13 | **Planned** | A **TL-UL boundary adapter** on each mailbox port (`a_user` default, no integrity, width checks); the SoC converts TL-UH to TL-UL with standard Chipyard widgets |
| H20 | **Skipped for now** | Pad retention left to the SoC |
| H14 (CVA6) | **Planned** | Per-hart always-on **READY** bit (OpenSBI sets it as its last store before WFI; hardware clears it on wake) plus a drained TileLink port; otherwise deny (D17/D18) |
| H14 (Rocket) | **Planned** | **The same READY-bit adapter as CVA6**, for uniformity |
| H15 | **Planned** | **SystemVerilog TL-UH gate on `acg_ctrl`**: burst-aware drain, an error response per beat, atomics. Its stall-and-wake raises a wake line into the SCP (PD5) |
| H16, F11 | **Planned** | **DCDR delays + acknowledgement check**: firmware sets each PPU's device-control delays to cover the SoC blocks' worst case; the bridge forwards the requests and flags a late acknowledgement to the SCP as a fault. No PPU change |
| F7 | **Deferred** | Flat domains for now |
| F8 | **Dropped** | PD9 |
| F9 | **Decide later** | HSM, SYSTEM_SUSPEND, SYSTEM_RESET (librpmi v1.0.0 ships all three groups) |
| H18, F12 | **Planned** | **Small glue watchdog** (counter, kick register, reset-request output) on the SCP bus, and a fault-log ring in SCP RAM |
| F13 | **Dropped** | No inrush limit: requested domains switch on as requests arrive; rail stability is left to physical design |
| H19, F14 | **Dropped** | PD10 |
| F1 | **Planned** | Fix `hal/ppu_v1` now: write each RAM-retention register that exists, report the `PWR_DYN_EN` case correctly, and remove the `soc4_ret` helper |
| H21 | Not planned | Agents poll |
| V2–V5 | **Planned, with each feature** | Testbench checks for the domain table, two-agent tests, wake/PLIC-input tests, the bridge against a model of the SoC blocks |
| V6–V7 | **Later sign-off phase** | CDC, static low-power checks, formal |
| X1–X4, H22 | **Done 2026-10-04** | Dated "superseded" notes in §5.2, §6.2, §7, §8, §10 and in `RPMI_STACK_DECISIONS.md` D3 |

---

## 15. The power-control platform: status and plan (revised 2026-10-04)

**Scope.** The deliverable is the **power-control platform**, built to the
decisions of §14.1:
- **hardware:** the SCP with its own timer, interrupt inputs, wake-line inputs
  and SoC PLIC input; PPUs with PCSMs and CLK-CTRLs; the mailboxes and firewall
  for two agents; device adapters; access gates; the clock/reset request bridge;
- **firmware** for all of the above.

It serves power-control requests from the AP and the RPU. Applications, the OS
and OpenSBI belong to the embedded team.

**Flexibility.** Adding or removing a power domain (soc4's 4 → SOVRA's 27, §13)
is a **by-hand edit in a small, known set of places**, without design rework.
Configuration is written by hand, not generated (decision of 2026-10-04).

### 15.1 Status

*2026-10-06:* phases 1–6 of §15.2 are done (commits 63e671d, 9a96ba6,
6db4734, d059a27, 68bb804, 732b7c7), so the "missing" lists below are the
2026-10-04 picture. What remains open is in §14.2–14.4 (❌ rows) and in the
deferred and dropped lists under §15.2; the sign-off's open findings are in
[`src/signoff/SIGNOFF_REPORT.md`](../src/signoff/SIGNOFF_REPORT.md) §8.

The item-by-item status is §14.2–14.4. In short (2026-10-04):
- **Done:** PPU, PCSM, CLK-CTRL, LPD-Q, domain wrapper, SCP with its timer, the
  TL-UL AP mailbox and firewall, the TL-UL access gate, the Ibex and generic
  adapters; the firmware's driver, `pd`, policy and BASE + DEVICE_POWER server;
  41 regression targets.
- **Missing, hardware:** SCP interrupt aggregation and the SoC PLIC and
  wake-line inputs (H7–H9); the RPU's transport and firewall ranges (H11–H13);
  the CVA6 and Rocket adapters and the TL-UH gate (H14–H15); the clock/reset
  bridge (H16); the N-domain top (H17); watchdog, clock-rate change and
  pad-retention outputs (H18–H20).
- **Missing, firmware:** the domain table, two agents, dependencies, the mode
  manager, HSM, SYSTEM_SUSPEND, SYSTEM_RESET, interrupt and wake handling,
  watchdog, inrush sequencing (F5–F14).

### 15.2 Plan (the items chosen in §14.7)

Each phase ends with an exit test, and soc4 keeps passing throughout.

| Phase | Work | Exit test |
|---|---|---|
| **1. Firmware domain table and driver fixes** | One firmware domain table in the platform header (F5); `policy.c` reads it. Fix `hal/ppu_v1` and remove the `soc4_ret` helper (F1) | soc4's 41 targets keep their counts |
| **2. Interrupt inputs** | The SCP interrupt status/enable block (H7), the generic input bank carrying the SoC PLIC input and the wake lines (H8, H9), and table-driven handling (F10) | soc4 extended with PLIC and wake inputs: a test per input, including a CPU powered up from a PLIC pending input; every PPU interrupt delivered through the block |
| **3. N-agent mailbox** | NUM_AGENTS transports with value + mask firewall entries (H11, H12); one librpmi context per agent, per-domain votes and permissions (F6); the TL-UL boundary adapter (H13) | soc4 with 2 agents: votes, permissions, firewall per transport (V3) |
| **4. Watchdog and fault log** | Glue watchdog and fault-log ring (H18, F12) | Watchdog expiry and kick tests; fault-log content checked |
| **5. SOVRA device side** | CVA6 and Rocket READY-bit adapters (H14), the TL-UH gate (H15), the clock/reset bridge with DCDR delays and acknowledgement check (H16, F11); **the software contract** for the embedded team (device-tree nodes, DOMAIN_ID map, agent permissions, timeouts and errors): [`docs/PMU_SOFTWARE_CONTRACT.md`](../docs/PMU_SOFTWARE_CONTRACT.md) | Unit tests per block; the bridge against a model of the SoC blocks (V5). **Done 2026-10-06** (`acgtluh`, `readyadp`, `ckrst`, `soc4ckrst`) |
| **6. Sign-off** | CDC, static low-power checks, formal (V6, V7), with the Synopsys VC suite: VC LP, VC CDC/RDC, VC Lint, VC Formal ([`src/signoff/SIGNOFF_REPORT.md`](../src/signoff/SIGNOFF_REPORT.md)) | Clean reports. **Done 2026-10-06** (`make signoff`). Every gate passes: each violation is fixed, waived with its justification in `src/signoff/*/waivers*.tcl`, or listed as an open finding (SIGNOFF_REPORT.md §8). Still open: the retention style for LP-2, CDC-1 and CDC-3, the TL-UH gate and READY-adapter findings, and VC Lint's language rules (NOT RUN: the SpyGlass-compatible checker is not installed). Regression 31/31 unchanged |

**Deferred:**
- F7: domain dependencies;
- F9: HSM, SYSTEM_SUSPEND, SYSTEM_RESET;
- H20: pad retention.

**Dropped:**
- F8: mode manager (PD9);
- F13: inrush limit;
- H19 and F14: SCP clock switching (PD10);
- H17: generic N-domain top (domains stay hand-instantiated).

### 15.3 Adding or removing a domain or an agent

**A domain:**

| # | Edit | File |
|---:|---|---|
| 1 | Instantiate the domain's `ppu_axi_dom_top` with its parameters, its IP and adapter, and its clock/reset bridge; or remove them; and the domain count (`NUM_PD` in `soc4_top.sv`, which sets `scp_top`'s `NUM_PPU`) | the platform top (by hand) |
| 2 | Add or remove its PPU interrupt as a wire in the status/enable block's source list (`irq_in`), and update `NUM_IRQ` and the `IRQ_ASYNC` mask: both index the inputs by position, so every input after the change moves | the platform top |
| 3 | The firmware entry: name, low-power mode, kind, retention, agent permissions, CPU boot details if a CPU; `SCP_NUM_PPU`; and the PPU's `I(...)` entry (`SCP_ACT_PPU`) in the input table, in the same position as its wire in `irq_in` (soc4: DOMAIN_ID = PPU index n = input n) | the platform's C header (`SCP_PLAT_DOMAINS`, `SCP_NUM_PPU`, `SCP_PLAT_INPUTS`) |
| 4 | Add or remove the domain in the power intent | the platform's UPF |
| 5 | Add or remove its testbench expectations | the platform testbench |
| 6 | Give the DOMAIN_ID and its permissions to the embedded team | the software contract ([`docs/PMU_SOFTWARE_CONTRACT.md`](../docs/PMU_SOFTWARE_CONTRACT.md) §2) |

**Current limits (2026-10-06).** The table above is the shared part. soc4
itself is built for exactly four domains, so on soc4 a domain cannot be added
or removed with those edits alone:

- **`soc4_ctrl` has a fixed register map** (`soc4/rtl/soc4_ctrl.sv`):
  `HWSTAT_n` at `0x020`–`0x02C` for n = 0..3, then `CKRST_STAT` at `0x030`,
  one 32-bit word with 8 bits per domain; two CPU boot registers
  (`CPU0_BOOT`, `CPU1_BOOT`) and per-CPU fields in `FETCH_EN` and
  `CPU_STAT`. `soc4_top`'s ext window has load ports for two CPUs. Another
  domain count needs a new map there and in `soc4/fw/hal/soc4_regs.h`.
- **soc4's tests and its domain enum hard-code four domains**:
  `soc4_regs.h`'s `SOC4_CPU0` … `SOC4_ACC1`, `SOC4_NDOM = 4`;
  `soc4/fw/test/soc4_stress.c` (`ND = 4u` and per-domain mode tables);
  `soc4/fw/ap/ap_main.c` (walks `SOC4_NDOM` and names the four domains); and
  `soc4_tb` (row 5). A testbench whose checks follow the domain list is V2,
  still open (§14.4).
- **The watchdog timeout grows with the platform.** `soc4/fw/scp/main.c`
  checks at compile time that `SCP_PLAT_WDOG_TIMEOUT - SCP_LOOP_KICK_TICKS`
  covers (agents × `SCP_RPMI_DRAIN_BUDGET` + POWER_UP inputs + 1) power-ups
  of 1 ms each (soc4: 2 × 5 + 5 + 1 = 16 ms against 18.4 ms). More agents or
  more `SCP_ACT_POWER_UP` inputs can fail that check; `SCP_PLAT_WDOG_TIMEOUT`
  in the platform header must then grow.
- **Bounds of the shared parts:** `scp_top` decodes 16 PPU slots
  (`NUM_PPU` ≤ 16) and `scp_irq` has at most 32 inputs (`NUM_IN` ≤ 32); soc4
  uses 4 and 16. The firmware takes 1 to 8 agents (`mod/agents.h`: a
  domain's `.agents` is one byte).

**An agent** (phase 3, 2026-10-05):

An agent (an RPMI requester such as the AP or the RPU) is one transport of the
N-agent mailbox (`soc4_mbx`). Adding or removing one is a by-hand edit in
these places, and no other:

| # | Edit | File |
|---:|---|---|
| 1 | The mailbox's `NUM_AGENTS`, `NUM_PORTS`, `AGENT_PORT` (the port each agent is bound to) and `PORT_HAS_A_USER`; the new port's wiring into the mailbox; the ext window's queue-memory mask (1 KiB per agent) | the platform top (`soc4_top.sv`, `MBX_*`) |
| 2 | The agent's doorbell `db_irq_o[k]` as an input of the interrupt block's source list | the platform top (`irq_in`) |
| 3 | The agent's entry: name, queue window, doorbell input, `a_source` value and mask, service groups; its doorbell's input-table entry (`SCP_ACT_DOORBELL`, arg k); its bit in the `.agents` of each domain it may vote for | the platform's C header (`SCP_PLAT_AGENTS`, `SCP_PLAT_INPUTS`, `SCP_PLAT_DOMAINS`) |
| 4 | Its window, doorbell, source IDs and DOMAIN_ID permissions for the agent's software | the software contract ([`docs/PMU_SOFTWARE_CONTRACT.md`](../docs/PMU_SOFTWARE_CONTRACT.md) §1, §2) |

The firmware's transports, contexts, votes, doorbells and librpmi arena
(512 bytes per agent) follow the agent table with no other edit; the
testbench's two-agent steps (R0, R1) are soc4's.
