# Power-control platform: software contract

For the software that asks the power-control platform for power: OpenSBI on
the application cores (the AP, the VtCPU cluster), the RPU firmware, and the
M-mode code on the CVA6 and Rocket cores that power down their own hart.

The platform is a System Control Processor (SCP) that owns every Power Policy
Unit (PPU). Software does not touch a PPU. It sends requests to the SCP over a
shared-memory mailbox using RPMI (the RISC-V Platform Management Interface),
and the SCP's firmware runs the power sequences.

Status: 2026-10-06. Values marked **(soc4)** are those of the 4-domain
verification platform in this repository (`src/soc4`). SOVRA's values are
filled in by the same rules when its partition is final (architecture
document §13 and §15.3). Anything not listed here is not part of the
contract.

References used below:

| Short name | What |
|---|---|
| librpmi | `src/pmu/fw/vendor/librpmi`, upstream v1.0.0, commit `7aaff6be` (its `REVISION.md`) |
| OpenSBI | OpenSBI v1.9 (tag `v1.9`, commit `cbf9f673`), the copy in `/sim/sovra/quyetdv/pmu/build/sw/mbx-survey/opensbi` |
| platform header | `src/soc4/fw/soc4_plat.h`: the SCP firmware's domain, input and agent tables |

---

## 1. Agents and their mailboxes

An **agent** is a requester with its own RPMI transport. There are two (§14.1
PD6 of the architecture document): the **AP** and the **RPU**. Each has:

- a **queue window** of 1 KiB in the mailbox's shared memory;
- a **doorbell**: any write to it tells the SCP that the agent has queued a
  request;
- a **firewall entry**: the window accepts an access only if its TileLink
  `a_source` matches the agent's value and mask, `(a_source & MASK) == VALUE`.

| Agent | Queue window | Doorbell | `a_source` VALUE / MASK | Accepted source IDs | Mailbox port |
|---|---|---|---|---|---|
| 0, AP **(soc4)** | `0x2000_0000`–`0x2000_03FF` | `0x2000_1000` | `0x10` / `0xFF` | `0x10` | 0 |
| 1, RPU **(soc4)** | `0x2000_2000`–`0x2000_23FF` | `0x2000_3000` | `0x20` / `0xFC` | `0x20`–`0x23` | 1 |

Rules of the window:

- Reads and writes of 1, 2 or 4 bytes, byte enables honoured.
- An access the firewall refuses is answered with a TileLink bus error
  (`d_error`), has no effect, and is counted by the SCP; each batch of
  denials is entered in the SCP's fault log. From reset until the SCP has
  booted and programmed the firewall, **every** access is refused.
- An access to another agent's window, or to `doorbell + 4` and above, is a
  bus error.
- The doorbell: any write, any data. A read returns 0.
- The SCP cannot interrupt an agent: agents **poll** for replies (§14.2 H21).

### 1.1 Queue layout (librpmi's shared-memory transport)

Each window holds two queues, one after the other
(librpmi `lib/rpmi_transport_shmem.c:236-247`), each of 8 slots of 64 bytes
(`src/pmu/fw/rpmi/scp_rpmi.h:142-146`; `RPMI_SLOT_SIZE_MIN`, librpmi
`include/librpmi.h:83`):

| Window offset | Queue | Who writes the slots | Head index | Tail index |
|---|---|---|---|---|
| `0x000`–`0x1FF` | A2P requests | the agent | slot 0 (`+0x000`), written by the SCP | slot 1 (`+0x040`), written by the agent |
| `0x200`–`0x3FF` | P2A acknowledgements | the SCP | slot 0 (`+0x200`), written by the agent | slot 1 (`+0x240`), written by the SCP |

- Slots 2–7 of each queue carry messages: 6 slots. A queue is full one slot
  short of that, so at most **5 requests may be outstanding** per agent.
- Head and tail are little-endian 32-bit slot indices into the 6 message
  slots (librpmi `lib/rpmi_transport_shmem.c:38-53`).
- A message is an 8-byte header and its data (librpmi
  `include/librpmi.h:38-110`): `servicegroup_id` (16 bits), `service_id`
  (8), `flags` (8: bits [2:0] the type, 0 normal request, 2 acknowledgement;
  `include/librpmi.h:53-65, 86-96`), `datalen` (16), `token` (16).
- The SCP zeroes both queues before it lets the AP run.
- To send: write the message into the slot at the A2P tail, advance the tail,
  then write the doorbell. To receive: wait until the P2A tail differs from
  the P2A head, read the slot at the head, advance the head. Match replies by
  `token`.
- A head or tail index out of range stops the SCP serving that agent until
  the index is valid again; other agents are not affected
  (`src/pmu/fw/rpmi/scp_rpmi.h`, queue guard).

### 1.2 Device-tree node for OpenSBI (`riscv,rpmi-shmem-mbox`)

OpenSBI's driver is `lib/utils/mailbox/fdt_mailbox_rpmi_shmem.c`. What it
reads, with line numbers:

| Property | Lines | Value for this platform |
|---|---|---|
| `compatible = "riscv,rpmi-shmem-mbox"` | 594-596, 813-815 | |
| `riscv,slot-size` (mandatory) | 599-609 | `<64>` |
| `riscv,a2p-doorbell-value` (optional, default 1) | 615-617 | omit: any value rings |
| `riscv,p2a-doorbell-sysmsi-index` (optional) | 611-613 | omit: no SCP-to-agent interrupt |
| `reg` / `reg-names`: one entry per queue, in queue order, then `"a2p-doorbell"` | 619-690 | below |
| `#mbox-cells = <1>`: the cell is the RPMI service group ID | 823, `fdt_mailbox.c:82-94` | |

The driver computes each queue's slot count as
`(size - 2 * slot-size) / slot-size` (line 650): with 512-byte queues and
64-byte slots, 6 slots, as the SCP has. The queue names are free text; the
order is what counts (A2P request queue first, then P2A acknowledgement
queue; the SCP has no P2A request queue).

The AP's node **(soc4 addresses)**:

```dts
mbox_ap: mailbox@20000000 {
    compatible = "riscv,rpmi-shmem-mbox";
    reg = <0x0 0x20000000 0x0 0x200>,   /* A2P request queue */
          <0x0 0x20000200 0x0 0x200>,   /* P2A acknowledgement queue */
          <0x0 0x20001000 0x0 0x4>;     /* doorbell */
    reg-names = "a2p-req", "p2a-ack", "a2p-doorbell";
    riscv,slot-size = <64>;
    #mbox-cells = <1>;
};

/* DEVICE_POWER (service group 0x0009) offered to the OS over SBI MPXY */
rpmi_dpwr: device-power {
    compatible = "riscv,rpmi-mpxy-device-power";   /* fdt_mpxy_rpmi_device_power.c:47-48 */
    mboxes = <&mbox_ap 0x0009>;
    riscv,sbi-mpxy-channel-id = <0x1000>;          /* fdt_mpxy_rpmi_mbox.c:287-291; any unused ID */
};
```

OpenSBI asks for the BASE group (0x0001) itself when it probes the node.
These queues must be M-mode only: OpenSBI adds each `reg` range to its root
domain as M-mode MMIO (lines 641-646, 684-688); keep them out of every
S-mode PMP region. The RPU's firmware uses the same layout at its own
window.

---

## 2. Domains and permissions

A **domain** is one PPU-controlled power domain. `DOMAIN_ID` is the
DEVICE_POWER domain number and is fixed per platform.

| DOMAIN_ID **(soc4)** | Name (`GET_ATTRIBUTES`) | What | Where OFF takes it | AP may vote | RPU may vote |
|---:|---|---|---|:---:|:---:|
| 0 | `CPU0` | CPU core 0 | full retention: the core resumes where it stopped | yes | no |
| 1 | `CPU1` | CPU core 1 | off: the next ON reboots it | yes | no |
| 2 | `ACC0` | accelerator 0 | memory retention: its RAM is kept | yes | yes |
| 3 | `ACC1` | accelerator 1 | off | yes | yes |

- **Votes.** Each agent has its own vote per domain. A domain is ON while
  **any** permitted agent votes ON, and goes down once **all** vote OFF.
  `GET_DPWR_STATE` returns the **caller's own vote**, not the domain's state.
- **Permission.** A request for a domain the agent may not vote for is
  refused with `RPMI_ERR_DENIED` (-4).
- **Wake vote.** A wake event the SCP handles (a PLIC pending interrupt for
  a powered-down hart, a wake line) powers the domain up and records an ON
  vote for the domain's **wake owner**, the lowest-numbered permitted agent
  (the AP for all four soc4 domains). The owner's next OFF ends it.

---

## 3. RPMI services

Every agent gets two service groups (librpmi `include/librpmi.h:188, 196`):

| Group | ID | Services (ID) | Lines |
|---|---|---|---|
| BASE | `0x0001` | ENABLE_NOTIFICATION (1), GET_IMPLEMENTATION_VERSION (2), GET_IMPLEMENTATION_IDN (3), GET_SPEC_VERSION (4), GET_PLATFORM_INFO (5), PROBE_SERVICE_GROUP (6), GET_ATTRIBUTES (7) | `include/librpmi.h:218-224` |
| DEVICE_POWER | `0x0009` | ENABLE_NOTIFICATION (1), GET_NUM_DOMAINS (2), GET_ATTRIBUTES (3), SET_DPWR_STATE (4), GET_DPWR_STATE (5) | `include/librpmi.h:328-332` |

States: `RPMI_DPWR_STATE_ON = 0`, `RPMI_DPWR_STATE_OFF = 3`
(`include/librpmi.h:1622-1623`). Notifications are not offered: agents poll.
`PROBE_SERVICE_GROUP` returns version 0 for every other group (librpmi
`lib/rpmi_context.c:140-163`): HSM, SYSTEM_RESET and SYSTEM_SUSPEND are not
offered yet (architecture document §14.7 F9).

Status codes software will see (`include/librpmi.h:115-160`):

| Code | Name | When |
|---:|---|---|
| 0 | `RPMI_SUCCESS` | done. For ON: the domain has reached ON. For OFF: the vote is recorded (the power-down follows, see §4) |
| -3 | `RPMI_ERR_INVALID_PARAM` | `DOMAIN_ID` not below `GET_NUM_DOMAINS`, or a state other than ON or OFF (librpmi `lib/rpmi_service_group_device_power.c:300-303`) |
| -4 | `RPMI_ERR_DENIED` | the agent may not vote for this domain (§2) |
| -8 | `RPMI_ERR_HW_FAULT` | the power-up failed or missed its deadline; the domain is in FAULT (§5) |
| -2 | `RPMI_ERR_NOTSUPP` | a service or group that is not offered |

A request that repeats the caller's recorded vote is answered `RPMI_SUCCESS`
without reaching the SCP's policy (`lib/rpmi_service_group_device_power.c:
128-131`).

---

## 4. Timing

| What | Value **(soc4)** | Source |
|---|---|---|
| SET_DPWR_STATE ON: worst-case time to the reply | 1 ms (then `RPMI_ERR_HW_FAULT`) | `src/pmu/fw/mod/policy.c`, `policy_cfg_default.on_ticks` |
| While an ON is in progress | the SCP serves no other request, from any agent | `src/pmu/fw/mod/policy.h`, ON |
| SET_DPWR_STATE OFF: reply | at once | |
| OFF vote to the start of the power-down (hysteresis); an ON inside it cancels the power-down | 1 ms | `hyst_ticks` |
| A device that refuses the power-down | retried after 100 µs, doubling, 3 times, then powered down without its agreement | `backoff_ticks`, `retry_cap` |
| `GET_ATTRIBUTES` transition latency | 0 (not measured yet) | platform header, domain table |
| Requests outstanding per agent | at most 5 | §1.1 |
| SCP unresponsive (watchdog) | reset of the SCP alone after about 21 ms; the domains keep their state and every agent's votes are kept; requests in flight are lost (no reply): time out and resend | `SCP_PLAT_WDOG_TIMEOUT`; architecture §14.2 H18 |
| Firewall closed after power-on | until the SCP has booted (soc4: about 3000 SCP cycles after reset in the tests) | §1 |

Suggested agent timeout per request: 5 ms (above the 1 ms ON bound plus a
full queue ahead of it).

---

## 5. What software sees

**A refusal by permission:** `RPMI_ERR_DENIED`; nothing changes.

**A domain in FAULT.** A power-up that misses its deadline, a power-down
the hardware cannot complete, or a clock/reset fault (below) puts the domain
in FAULT:

- an ON in progress returns `RPMI_ERR_HW_FAULT`;
- every agent's vote for the domain is dropped: `GET_DPWR_STATE` answers OFF;
- the SCP powers the domain down itself (3 tries, 1 ms apart) and logs it;
- the agent's next ON recovers it: an accelerator through a warm reset, a
  CPU through a cold reload. A CPU's state is lost after a FAULT.

**A clock/reset fault.** The SoC's clock gate and tile reset are the
authority over each tile's clock and reset (§14.1 PD8); the platform's
bridge checks that they answer in time. A late, missing or unrequested
acknowledgement puts the domain in FAULT as above, even if its ON had
already returned `RPMI_SUCCESS`. Software sees `GET_DPWR_STATE` = OFF
afterwards; an access to the domain's device may then be refused by its
access gate (below).

**An access to a domain that is off.** Through an access gate:

- voted OFF by the agent: the access is answered at once with a bus error
  (`d_denied` on TileLink); for a read or an atomic, every beat of the
  response is denied and corrupt; the SCP records the first offending
  address and source ID;
- powering up: the access waits until the domain is ON;
- otherwise (stall-and-wake): the access waits, the SCP is told and powers
  the domain up, and the access then completes.

**Wake.** A hart that is powered down wakes when an interrupt is pending for
it at the PLIC: the SCP powers its domain up (a wake vote, §2).

The SCP's fault log is not readable over RPMI.

---

## 6. The READY-bit protocol (CVA6 and Rocket harts)

CVA6 and Rocket have no output that says "this hart is in WFI", and a WFI
can retire with bus transactions still in flight. So a hart that is about to
be powered down tells the hardware itself, with a **READY bit**, and the
hardware also checks the hart's bus ports.

### 6.1 The register

One always-on register per hart, `READY_h`, at `READY_BASE + 4 * h`
(`src/rtl/adp/hart_ready_regs.sv`; `READY_BASE` is in the SoC address map,
not assigned yet):

| Offset | Name | Access | Meaning |
|---|---|---|---|
| `0x000 + 4*h` | `READY_h` | RW | bit 0: write 1 to set, write 0 to clear; read gives the current value |
| `0x100` | `READY_ALL` | RO | bit h = `READY_h` |
| `0x104` | `INFO` | RO | [7:0] number of harts |

32-bit accesses. Other offsets, and writes to read-only registers, return a
bus error. The page must be M-mode only (PMP).

### 6.2 What the hart's M-mode code does (OpenSBI platform hook)

Before a power-down (HSM stop, a non-retentive suspend, system suspend):

1. Finish every device access the hart owns.
2. Clean (write back and invalidate) the hart's data cache, then `fence`.
3. Disable interrupts that must not wake it (`mie`), leaving the wake sources
   enabled.
4. **The last store:** write 1 to `READY_h`, then `fence`.
5. `wfi`, in a loop: if it returns, clear `READY_h` (write 0) and take the
   normal resume path.

No store, load or fetch to memory may follow step 4 other than the `wfi`
loop.

### 6.3 What the hardware does

- `READY_h` is **cleared by hardware** on any enabled wake for the hart (an
  interrupt pending and enabled at the PLIC, its timer or software
  interrupt, a debug request), when the hart's domain comes back to ON, and
  while the hart is held in reset. **A clear and a set in the same cycle
  leave it clear**: if a wake races the last store, `READY_h` stays 0 and the
  `wfi` returns at once, because the wake is still pending.
- The SCP can clear it too.
- The power-down is **accepted** only while `READY_h` is 1, no wake is
  pending, and every bus port of the hart is idle: nothing on its request
  channel, no message part-way through its beats, no response owed (and on a
  cached TL-C port no Grant unacknowledged, no Release or Probe unanswered).
  Otherwise it is **refused**, and the SCP retries (§4).
- After a power-up `READY_h` reads 0.

---

## 7. Changes

| Date | Change |
|---|---|
| 2026-10-06 | First issue (platform plan phase 5) |
