# soc4: a 4-domain PPU + SCP power-control platform. Detailed design

> **Note (2026-10-06).** This is the soc4 design as written on 2026-10-01/02,
> before it was built. It is kept unchanged because the RTL, firmware and
> testbench comments cite it by section number. The design then evolved in
> the platform plan's phases 1–6 (commits 63e671d..732b7c7): one firmware
> domain table, SCP interrupt inputs, the two-agent mailbox, the SCP
> watchdog and fault log, the SOVRA device side and the sign-off. Where this
> document and the code differ, the code is right. For the current state see
> [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)
> §14–15, [`src/README.md`](../src/README.md) and the folder READMEs it links.
> Until 2026-10-06 this file lived only in the build area
> (`build/soc4_design/SOC4_DESIGN.md`).

Status: design for implementation. Repository baseline: `/project/sovra/WORK/quyetdv/pmu`, branch
`scp-ibex-firmware`, HEAD `fb460ab` (W2.1 mailbox and W4.1 policy merged). Nothing in this document
has been built. Date 2026-10-01.

Revision 2 (2026-10-01). This revision folds in an independent review (scratch trials in
`build/soc4_review/`) and the user's answers to revision 1. Revision 1 is kept as
`SOC4_DESIGN.v1.md`. What changed:

- **hold_busy.** A TB-only, always-on `hold_busy` input on all four adapters, ORed into
  dev_quiescent_busy and tied to 0 in a real SoC. It drives the ACC deadline miss, the
  deterministic deny/retry/force test, and a CPU1 OFF-side fault whose next ON reloads the image
  (5.1, 5.3, 5.5, 5.6, 10.5, 11.2).
- **Retention RAM.** `hal/ppu_v1.*` is left untouched, so pmu images are byte-identical. A
  soc4-only helper writes FULRR/MEMRR from IDR1 after `pd_init` (6.5, 9.6).
- **soc4stress coverage** is rebuilt against `PPU_FW_CONFORMANCE.md`'s check IDs. REG.BYTE,
  REG.RO, STA.QACT, STA.MIDWRITE, EVT.PTRN1, EDT.RESTART, DLY (exact value + 1 and the RST_HWSTAT
  handshake), SOAK and the second-hop denial are added. Only truly inapplicable features are left
  to the PPU unit tests (11.3).
- **Review fixes.** Deadline-miss injection by hold_busy, because START is accepted only in W_IDLE
  (`ppu_ip_core.sv:127-136`). Mutant M3 planted in glue. sysmsi linked. Warm/cold decided before
  the DEVREQEN re-enable. Errored fetches return 0. LOCK_EN and PWR_DYN_EN expectations
  corrected. Retention supply on CPU0's PD_DEV. tlul_assert bound in the TB. Logic-loss checks.
  Citations corrected.
- **Section 16** (implementation stages) added. Section 15.2 closures recorded.

Contents

1. Scope, references and citation convention
2. Block diagram and power domains
3. DOMAIN_ID and mode table; ppu_axi_dom_top parameters per domain
4. Address maps and register layouts
5. Module specifications
6. Changes to existing files
7. Vendoring (OpenTitan TL-UL)
8. Power intent
9. Firmware
10. Testbench
11. Tests
12. The later pmu_top deletion commit
13. Mapping to SOVRA
14. Traceability
15. Risks and open items
16. Implementation stages

---------------------------------------------------------------------------------------------------

## 1. Scope, references and citation convention

### 1.1 Scope

soc4 is a reduced system that checks the SCP's power-control functions. It has:

- the SCP (`scp_top`, Ibex "small") with 4 PPU slots;
- four power domains, each a `ppu_axi_dom_top` (PPU + PCSM, always-on) around a switched IP:
  two real Ibex cores (CPU0, CPU1) and two `ppu_device_ip` stand-in accelerators (ACC0, ACC1);
- one RPMI shared-memory transport between an AP and the SCP: queue SRAM, an AP-to-SCP doorbell
  on the SCP's `irq_external`, and a firewall on the TileLink a_source. It is built from OpenTitan
  TL-UL parts;
- an always-on AP: a third Ibex running a bare-metal test program. A testbench TL-UL BFM can
  replace it per test;
- SCP firmware: bare metal, RPMI v1.0 through librpmi v1.0.0 (BASE + DEVICE_POWER, one M-mode
  context, 4 domains);
- a UPF for the new top, with VCS as the only simulator.

Out of scope: AP software stacks (OpenSBI, Linux, U-Boot), QEMU, cache coherence, the
full-chip power-domain partition (Section 13), and the alert, RoT and OTP infrastructure.

`pmu_top` (12 domains) is retired, but only after soc4 passes, and in a separate commit
(Section 12). Until then, `pmu_top`, its AXI4-Lite mailbox (`scp_rpmi_mbox`) and the 34-target
regression keep working unchanged (Section 6).

### 1.2 Precedence

1. The user decisions of 2026-10-01 (items 1-15 of the task) and the "Mapping to SOVRA" request.
2. `Proposed_PMU/SOC4_TASK_PROMPT.md` (the brief).
3. `Proposed_PMU/RPMI_STACK_DECISIONS.md`, only where it does not go beyond the brief's scope.

Where 1 and 2 differ, 1 is followed and the difference is listed in Section 15.2.

### 1.3 References

| Tag | Document / source | Location |
|---|---|---|
| DEN 0051E | Arm PPU Architecture Specification v1.1 | `build/spec_txt/arm-power-policy-unit-architecture-spec-v1.1.txt` (cited as `PPU <section>` plus `spec:<line>`) |
| DEN 0050 | Arm PCSA | `build/spec_txt/arm-power-control-system-architecture-pcsa-den0050.txt` |
| librpmi | librpmi v1.0.0, upstream 7aaff6be, unmodified | `src/pmu/fw/vendor/librpmi` (cited as `LR <path>:<line>`) |
| OT | lowRISC OpenTitan at `16e86c9e031d52760780ac4efddaab2389bdb94b` | clone `/sim/sovra/quyetdv/pmu/build/sw/mbx-survey/opentitan` (cited as `OT <file>:<line>`, files under `hw/ip/{tlul,prim}/rtl`) |
| OpenSBI | OpenSBI v1.9 | clone `/sim/sovra/quyetdv/pmu/build/sw/mbx-survey/opensbi` |
| Ibex | lowRISC Ibex e1a6be2c (vendored verbatim) | `src/pmu/ibex/rtl` |
| PULP | tech_cells_generic v0.2.9 `tc_sram` (vendored) | `src/vendor/pulp/tech_cells_generic/tc_sram.sv` |
| facts | Interface surveys (W2.1/W4.1 trees; checked identical to HEAD except the two Makefiles, which were re-read) | `/sim/sovra/quyetdv/pmu/build/soc4_facts/{hw,fw}_facts.md` |

### 1.4 Citation convention

- Repository paths are relative to `src/` unless they start with `build/` or `Proposed_PMU/`.
  `file:N` or `file:N-M` gives line numbers at HEAD `fb460ab`.
- `PPU 4.1.3` is DEN 0051E section 4.1.3; `Table 4-4` is a DEN 0051E table unless prefixed.
- RPMI encodings (group IDs, service IDs, states, error codes, versions) are given only with a
  `LR` citation. PPU register offsets, fields and mode encodings are given only with a DEN 0051E
  citation or `hal/ppu_v1.h:<line>` (whose offsets match DEN Table 5-1, facts fw b).
- "NEW" marks a file this design adds; "EDIT" marks an existing file it changes.

### 1.5 Results of checks made while writing this document

Revision 2 adds two results from the reviewer's VCS trials (`build/soc4_review/`):

- **TL-UL trial (`mbx/`).** `tlul_socket_1n`, `tlul_adapter_sram`, `tlul_adapter_reg` and
  `tc_sram`, wired exactly as 5.2, with an AP-side `tlul_adapter_host` (MAX_REQS 2,
  EnableDataIntgGen 1) and the a_source override, compile and run under VCS W-2024.09-SP2
  (`mbx/files.f` is the compile order). This confirms 15.2-3 and 15.2-4.
- **UPF trial (`upf/`).** `UPF::get_supply_on_state(UPF::get_supply_value("VDD_SW"))` returns the
  switched net's state, relative to the UPF design top, and follows the switch. The low-power
  checker logs `[INFO] [LP_PSW_OSP_STATE]` on each switch change (`upf/vcs_lpmsg.log`). This
  confirms 8.4-2 and closes 15.2-7.

Revision 1 results:

- `deps.py tlul_socket_1n tlul_adapter_sram tlul_adapter_reg tlul_adapter_host` gives exactly 18
  new files and 3,764 lines (Section 7). Instantiations and package references were also checked
  by hand. The closure is complete.
- VCS W-2024.09-SP2 (`/system/EDA/Synopsys/vcs/W-2024.09-SP2`) elaborates a design whose
  *unselected* generate branch instantiates a module that is not compiled (no Error-[URMI]).
  This was tested on a 10-line scratch design, since deleted. It is why soc4 can leave
  `scp_rpmi_mbox.sv` and the PULP mailbox files out of its compile (Section 6.1).
- `tlul_adapter_host` checks response integrity on every response, whatever its parameters are:
  `tlul_rsp_intg_chk` decodes `d_user.rsp_intg` unconditionally (OT `tlul_rsp_intg_chk.sv:25`,
  `:47`) and `err_o = d_error | intg_err` (OT `tlul_adapter_host.sv:142`). Every TL-UL device the
  AP can reach must therefore generate response integrity. Section 5.2 sets `EnableRspIntgGen = 1`.
- `tlul_adapter_host` has no a_source parameter. a_source is 0 with `MAX_REQS = 1`, or a
  rotating counter otherwise (OT `tlul_adapter_host.sv:52-91`). The AP's fixed source is applied
  in glue after the adapter. The command integrity does not cover a_source
  (`tl_h2d_cmd_intg_t`, OT `tlul_pkg.sv:60-65`), so the override is integrity-neutral.

---------------------------------------------------------------------------------------------------

## 2. Block diagram and power domains

Legend: `[AON]` = always-on supply (PD_TOP or a domain's PD_AON_n). `[SW_n]` = switched supply of
domain n (PD_DEV_n). `[RET_0]` = CPU0's retention supply. RAM arrays are on the always-on rail,
and the PCSM drives their sleep/shutdown pins.

```
 soc4_tb
 +--------------------------------------------------------------------------------------------+
 |  scp_sim_ctrl (TB, TAG "fw")   AP sim ctrl = scp_sim_ctrl (TB, TAG "ap")   TL-UL BFM (TB)  |
 |        ^ sim_* port                 ^ ap_ext_* port                          | tl_bfm      |
 +--------|-----------------------------|----------------------------------------|-------------+
          |                             |                                        |
 soc4_top |                             |                                        |
 +--------|-----------------------------|----------------------------------------|-------------+
 | [AON]  |                             |                                        v             |
 |  scp_top (RPMI_MBOX=0, NUM_PPU=4)    |        soc4_ap [AON]                 bfm_sel_i       |
 |  +---------------------------+       |        +----------------------+    (static strap)   |
 |  | scp_core (Ibex)           |       +--ext-->| scp_core (Ibex, AP)  |          |          |
 |  | scp_ram 64K, timer, bus.sv|                | scp_ram 64K (+ap_fw) |          |          |
 |  | ext 0x0002_xxxx ----------+--+             | timer, bus.sv        |          |          |
 |  | m_axi[0..3] (AXI4-Lite)   |  |             | scp_data_split       |          |          |
 |  | irq_ext_i <---------+     |  |             | tlul_adapter_host ---+--tl_ap-->+ AP/BFM   |
 |  +--|------------------|-----+  |             +----------------------+          | mux      |
 |     |                  |        |                                               v          |
 |     |                  |   soc4 ext decode (bus.sv, 6 devices)          soc4_mbx [AON]     |
 |     |                  |    +-----+-----+------+-------+-------+        +---------------+  |
 |     |                  |    |sim  |ctrl |mbx   |qmem   |CPU0   |CPU1    | firewall sel  |  |
 |     |                  |    |port |     |regs  |port 0 |load   |load    | tlul_socket_1n|  |
 |     |                  |    v     v     v      v       |       |        |  dev0 sram ad.|  |
 |     |                  |  (TB) soc4_ctrl  +-->soc4_mbx<-+-------)--------+  dev1 reg ad. |  |
 |     |                  +--------------------- db_irq ---+       |        |  tc_sram 1KiB |  |
 |     |                                                   |       |        +---------------+  |
 |     | AXI4-Lite, one manager port per PPU               |       |                           |
 |     v                                                   v       v                           |
 |  +----------- domain 0: CPU0 ------------+  +----------- domain 1: CPU1 ------------+      |
 |  | ppu_axi_dom_top u_dom [AON]           |  | ppu_axi_dom_top u_dom [AON]           |      |
 |  |  PPU, PCSM; u_clkctrl [SW_0]          |  |  PPU, PCSM; u_clkctrl [SW_1]          |      |
 |  | soc4_cpu_adp u_adp [AON] (Q-Ch, wake) |  | soc4_cpu_adp u_adp [AON]              |      |
 |  | soc4_cpu_ram u_ram [AON] tc_sram 4K   |  | soc4_cpu_ram u_ram [AON] tc_sram 4K   |      |
 |  | scp_core u_core [SW_0], retained      |  | scp_core u_core [SW_1]                |      |
 |  |   whole core on [RET_0]               |  |                                       |      |
 |  +---------------------------------------+  +---------------------------------------+      |
 |  +----------- domain 2: ACC0 ------------+  +----------- domain 3: ACC1 ------------+      |
 |  | ppu_axi_dom_top u_dom [AON]           |  | ppu_axi_dom_top u_dom [AON]           |      |
 |  | ppu_device_ip u_ip: u_core,u_ret [SW_2]|  | ppu_device_ip u_ip: u_core,u_ret [SW_3]|     |
 |  |   banks u_ip.g_bank[*] [AON]          |  |   banks [AON]                         |      |
 |  +---------------------------------------+  +---------------------------------------+      |
 |  ppu_irq[n] -> scp_top.ppu_irq_i[n] -> irq_fast[n] -> mcause 16+n                         |
 +--------------------------------------------------------------------------------------------+
```

Clocks and resets: there is one free-running clock `clk_i` (10 ns in the TB, as in
`tb/pmu/pmu_tb.sv`). It is the SCP, AP, mailbox, PPU `aclk` and every domain's `dclk`. A domain's
switched logic runs on its gated `dev_clk`. `rst_ni` is the system reset. `scp_rst_ni` holds the
SCP subsystem alone in reset; its reset is `rst_ni & scp_rst_ni`. The mailbox, firewall,
soc4_ctrl, AP and PPUs are reset by `rst_ni` only. (`hold_busy_i[3:0]` is a TB-only always-on
input, one bit per domain, ORed into that domain's `dev_quiescent_busy`; 5.1. A real SoC ties it
to 0.) That is what lets soc4bfm show "the firewall
denies everything while the SCP is held in reset".

---------------------------------------------------------------------------------------------------

## 3. DOMAIN_ID and mode table; ppu_axi_dom_top parameters per domain

### 3.1 Domains

DOMAIN_ID = PPU index n = SCP interrupt line 16+n (`hal/scp_regs.h:71`, `scp_top.sv:182-185`).
PPU n is at `0x4000_0000 + n*0x1000` (`hal/scp_regs.h:62-66`).

| n | Name | IP (switched) | Supported modes (IDR0) | RPMI OFF -> mode | RPMI ON from LP | RAM |
|---|---|---|---|---|---|---|
| 0 | CPU0 | `scp_core` (Ibex small), whole core retained | OFF, FULL_RET, ON, WARM_RST | FULL_RET | static ON (warm resume); cold sequence if from OFF or after FAULT | 4 KB tc_sram on AON, bank-0 pins; FULRR bit 0 |
| 1 | CPU1 | `scp_core` | OFF, ON, WARM_RST | OFF | cold sequence (Section 9.5) | 4 KB tc_sram on AON, bank-0 pins (shut down in OFF) |
| 2 | ACC0 | `ppu_device_ip` | OFF, MEM_RET, ON, WARM_RST | MEM_RET | static ON | 8 banks x 16 words on AON; MEMRR |
| 3 | ACC1 | `ppu_device_ip` | OFF, ON, WARM_RST | OFF | static ON | 8 banks on AON (shut down in OFF) |

- ON, WARM_RST and OFF are mandatory (PPU 3.1.1, spec:564-566). One extra low-power mode per
  domain is enabled through `STA_*_SPT_CFG`. LOGIC_RET and DBG_RECOV do not exist on a Q-Channel
  PPU (Figure 3-2; `ppu_pkg.sv:38`, `:44`).
- RPMI DEVICE_POWER states: ON = 0, OFF = 3 (LR `include/librpmi.h:1622-1623`). No other state is
  accepted (`rpmi/scp_rpmi.c:56-58`).
- Mode encodings (Table 3-2, `hal/ppu_v1.h:53-65`, `ppu_pkg.sv:34-44`): OFF 0, MEM_RET 2,
  FULL_RET 5, ON 8, WARM_RST 9. PPUHWSTAT is one-hot, bit m (`ppu_pkg.sv:134-147`).
- Boot: all four domains stay in PPU OFF (`DEF_PWR_POLICY = PM_OFF`, `PCSM_RESET_MODESTAT =
  PM_OFF`). A Q-Channel PPU only moves between ON and the programmed mode (PPU 3.3.2,
  spec:1043-1044, "it only transitions between ON and the power mode programmed in the PPU_PWPR
  register"). Nothing needs retaining before the first ON. CPU0 and ACC0 reach their retention
  modes only from ON, after their first OFF vote.

### 3.2 Device controls per mode

As {PORESETn, WARMRESETn, RETRESETn, CLKEN, ISOLATEn} (`ppu_pkg.sv:224-235`;
`tb/pmu/pmu_tb.sv:296-307`; Tables 4-7, 4-9, 4-11):

| Mode | Controls | dev_nret_rst_n | dev_ret_rst_n (= core reset) | dev_clk | PCSM mode | ram_sd / ram_sleep (bank b, cfg = RR byte) |
|---|---|---|---|---|---|---|
| WARM_RST | 1 0 0 1 1 | 0 | 0 | running | ON (Table 3-2 note a; `ppu_pkg.sv:160-174`) | 0 / 0 |
| ON | 1 1 1 1 1 | 1 | 1 | running | ON | 0 / 0 |
| FULL_RET | 1 0 1 0 0 | 0 | 1 | stopped | FULL_RET | !cfg[b] / cfg[b] |
| MEM_RET | 0 0 0 0 0 | 0 | 0 | stopped | MEM_RET | !cfg[b] / cfg[b] |
| OFF | 0 0 0 0 0 | 0 | 0 | stopped | OFF | 1 / 0 |

`dev_nret_rst_n = sync(PORESETn & WARMRESETn)` and `dev_ret_rst_n = sync(PORESETn & RETRESETn)`
(`ppu_dom_top.sv:511-525`). ram_sleep/ram_sd come from `ppu_pcsm.sv:643-660`. During WARM_RST
the PCSM stays in ON, so a CPU RAM stays powered and accessible while the SCP loads it.

### 3.3 ppu_axi_dom_top parameters, every one, per domain

Defaults are from `rtl/ppu/ppu_axi_dom_top.sv:50-124`. "=" means the default is kept.

| Parameter | Default | CPU0 | CPU1 | ACC0 | ACC1 | Reason |
|---|---|---|---|---|---|---|
| DEF_PWR_DYN_EN | 0 | 0 | 0 | 0 | 0 | static only (decision 2) |
| DEF_PWR_POLICY | PM_ON | PM_OFF | PM_OFF | PM_OFF | PM_OFF | boot in OFF (decision 3) |
| WARM_RST_DEVREQEN_CFG | 1 | **0** | **0** | **0** | **0** | no handshake ON<->WARM_RST (PPU 4.2.5, Table 4-4, spec:2703-2712) |
| RST_HWSTAT_DLY_CFG | 2 | = | = | = | = | firmware programs DCDR (`mod/pd.c:43-49`) |
| ISO_CLKEN_DLY_CFG | 2 | = | = | = | = | " |
| CLKEN_RST_DLY_CFG | 2 | = | = | = | = | " |
| CLKEN_ISO_DLY_CFG | 2 | = | = | = | = | " |
| ISO_RST_DLY_CFG | 2 | = | = | = | = | " |
| DYN_ON_SPT_CFG | 1 | 0 | 0 | 0 | 0 | decision 2 |
| DYN_FUNC_RET_SPT_CFG | 1 | 0 | 0 | 0 | 0 | " |
| DYN_FULL_RET_SPT_CFG | 1 | 0 | 0 | 0 | 0 | " |
| DYN_MEM_OFF_SPT_CFG | 1 | 0 | 0 | 0 | 0 | " |
| DYN_MEM_RET_SPT_CFG | 1 | 0 | 0 | 0 | 0 | " |
| DYN_OFF_SPT_CFG | 1 | 0 | 0 | 0 | 0 | " |
| STA_FUNC_RET_SPT_CFG | 1 | 0 | 0 | 0 | 0 | " |
| STA_FULL_RET_SPT_CFG | 1 | **1** | 0 | 0 | 0 | CPU0's LP mode |
| STA_MEM_OFF_SPT_CFG | 1 | 0 | 0 | 0 | 0 | |
| STA_MEM_RET_SPT_CFG | 1 | 0 | 0 | **1** | 0 | ACC0's LP mode |
| OFF_MEM_RET_TRANS_CFG | 1 | 0 | 0 | 0 | 0 | decision 2 (legal: `ppu_top.sv:333-349` only forbids it without STA_MEM_RET) |
| FUNC_RET_RAM_REG_CFG | 1 | 0 | 0 | 0 | 0 | decision 2 |
| FULL_RET_RAM_REG_CFG | 1 | **1** | 0 | 0 | 0 | PPU_FULRR present on CPU0 (DEN Table 5-20) |
| MEM_RET_RAM_REG_CFG | 1 | 0 | 0 | **1** | 0 | PPU_MEMRR present on ACC0 (DEN Table 5-21) |
| LOCK_CFG | 1 | 0 | 0 | 0 | 0 | lock needs PWR_DYN_EN=1 and covers only OFF/MEM_RET (PPU 3.4.3 "Lock", spec:1384-1437) |
| SW_DEV_DEL_CFG | 1 | = | = | = | = | `pd_init` writes DCDR0/1 (`mod/pd.c:182`) |
| PWR_MODE_ENTRY_DEL_CFG | 1 | = | = | = | = | `pd_init` writes EDTR (`mod/pd.c:177`); soc4stress checks it |
| SYNC_STAGES | 2 | = | = | = | = | |
| PCSM_SYNC_EN | 0 | = | = | = | = | |
| DEV_SYNC_EN | 1 | = | = | = | = | adapter inputs are dclk-domain, unsynchronised (facts hw g) |
| DEV_ACTIVE_SYNC_EN | 1 | = | = | = | = | |
| PCSM_RESET_MODESTAT | PM_OFF | PM_OFF | PM_OFF | PM_OFF | PM_OFF | decision 2 |
| PCSM_RET_SETTLE | 0 | `SOC4_PCSM_RET_SETTLE` (default 0) | " | " | " | TB define, as `PMU_PCSM_*` in pmu_tb |
| PCSM_LOGIC_SETTLE | 0 | `SOC4_PCSM_LOGIC_SETTLE` (default 0) | " | " | " | " |
| PCSM_TINIT_WAIT | 16 | = | = | = | = | |
| CLK_Q_CH_SYNC | 0 | = | = | = | = | |
| CLK_QACTIVE_SYNC | 0 | = | = | = | = | |
| QCLK_SYNC_EN | 0 | = | = | = | = | |
| NUM_QACTIVE_ONLY | 1 | = | = | = | = | tied 0 |
| ACTIVE_DENY_EN | 1 | = | = | = | = | |
| AXI_ADDR_W | 32 | = | = | = | = | |
| WAKE_TIMEOUT | 1024 | = | = | = | = | |

Port tie-offs (as `pmu_top.sv:289-296`): `hc_qreqn_i = 1`, `qactive_only_i = 0`,
`clk_force_i = 0`, `entry_delay_i = 0`, `aclk = dclk = clk_i`, `aresetn = rst_ni`.

Expected identification, which `soc4_scp` checks at boot and soc4stress checks in full. The bits
are from DEN Table 5-26 and Table 5-27, as decoded by `hal/ppu_v1.c:9-41`:

| | IDR0 static bits (OFF b8, MEM_RET b10, FULL_RET b14, ON b16, WARM_RST b17) | IDR0 dynamic bits [29:20] | IDR1 b12 OFF_MEM_RET_TRANS | b6 FUNRR | b5 FULRR | b4 MEMRR | b2 LOCK | b1 SW_DEV_DEL | b0 ENTRY_DEL |
|---|---|---|---|---|---|---|---|---|---|
| CPU0 | b8, b14, b16, b17 | 0 | 0 | 0 | 1 | 0 | 0 | 1 | 1 |
| CPU1 | b8, b16, b17 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| ACC0 | b8, b10, b16, b17 | 0 | 0 | 0 | 0 | 1 | 0 | 1 | 1 |
| ACC1 | b8, b16, b17 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |

AIDR = 0x11 (`hal/ppu_v1.h:96`, `PPU_AIDR_V1_1`). IDR0[3:0] DEVCHAN = 0x1, one device
Q-Channel (`rtl/ppu/REGISTERS.md:768`), is checked too.

---------------------------------------------------------------------------------------------------

## 4. Address maps and register layouts

All registers are 32-bit. Accesses are word-wide unless a byte-enable behaviour is stated. "err"
means the device raises the error flag of its protocol: `err` for a bus.sv device, `d_error` for
TL-UL. On the SCP or AP core either one is a load/store access fault. An unmapped offset inside
a device always answers err.

### 4.1 SCP map (scp_core data port)

scp_top's own decode is unchanged (`scp_top.sv:149-166`). With `RPMI_MBOX = 0` (Section 6.1),
the 0x0003_0000 doorbell split no longer exists, and 0x1000_0000 is answered err.

| Base | Size | Target | Notes |
|---|---|---|---|
| 0x0000_0000 | 64 KB | scp_ram | image `+firmware=`; vectors at 0, reset at 0x80 (`link.ld`) |
| 0x0001_0000 | 1 KB | timer (Ibex `shared/timer.sv`) | MTIME 0x0, MTIMEH 0x4, MTIMECMP 0x8, MTIMECMPH 0xC |
| 0x0002_0000 | 64 KB | scp_top `ext_*` port -> soc4 ext decode (4.2) | bus.sv protocol, exactly 1 cycle |
| 0x0003_0000 | 4 KB | none (RPMI_MBOX = 0) | bus.sv decode err |
| 0x1000_0000 | 16 KB | bus.sv slot DevRpmiMem -> error responder (RPMI_MBOX = 0) | err, 1 cycle |
| 0x4000_0000 + n*0x1000 | 4 KB each | PPU n, n = 0..3, over scp_top's AXI4-Lite manager n | PPU decodes addr[11:0] (`ppu_axi_lite_adapter.sv:115-120`) |
| 0x4000_4000 .. 0x4000_FFFF | | scp_axi_lite_demux slots 4..15 | DECERR -> access fault (`scp_axi_lite_demux.sv:92, 137-142`) |

Interrupts: timer line 7, external line 11 = TL-UL doorbell (`irq_ext_i`), fast lines 16+n =
PPU n (n < 4). Fast lines 20..30 are tied low. Only `trap_fast` lines 16-19 can fire;
`crt0.S:42-44` keeps its 12 entries.

### 4.2 SCP ext window (soc4 ext decode, inside soc4_top)

A nested Ibex `bus.sv` (1 host, 6 devices). The host is scp_top's `ext_*`. Decode is
`(addr & mask) == base`, last match wins (`bus.sv:77-87`). The masks below do not overlap.

| Dev | Base | Mask | Size | Target |
|---|---|---|---|---|
| 0 | 0x0002_0000 | 0xFFFF_F000 | 4 KB | `sim_*` port of soc4_top -> TB `scp_sim_ctrl` (TAG "fw"). Only this 4 KB page reaches it, because scp_sim_ctrl decodes addr[11:0] only (`tb/pmu/scp_sim_ctrl.sv:115-116`) |
| 1 | 0x0002_1000 | 0xFFFF_F000 | 4 KB | soc4_ctrl (4.4) |
| 2 | 0x0002_2000 | 0xFFFF_F000 | 4 KB | soc4_mbx SCP registers (4.5) |
| 3 | 0x0002_4000 | 0xFFFF_FC00 | 1 KiB | soc4_mbx queue memory, tc_sram port 0 (byte enables honoured) |
| 4 | 0x0002_8000 | 0xFFFF_F000 | 4 KB | CPU0 RAM load port (soc4_cpu_ram, 5.4) |
| 5 | 0x0002_9000 | 0xFFFF_F000 | 4 KB | CPU1 RAM load port |
| - | anything else in 0x0002_xxxx | | | bus.sv decode err one cycle later (`bus.sv:99, 125-126`) |

The queue-memory layout is librpmi's (LR `lib/rpmi_transport_shmem.c:236-249`). With the
existing geometry (`rpmi/scp_rpmi.h:95-99`: slot 64 B, 8 slots per queue, queue 512 B, shmem
1 KiB): A2P request queue at +0x000 (head in slot 0 at +0x000, tail in slot 1 at +0x040,
messages in slots 2-7); P2A ACK queue at +0x200 (head +0x200, tail +0x240, messages from +0x280).

### 4.3 AP map (AP scp_core data port, inside soc4_ap)

| Base | Size | Target | Notes |
|---|---|---|---|
| 0x0000_0000 | 64 KB | scp_ram, `IMAGE_PLUSARG = "ap_firmware"` | the AP's code and data |
| 0x0001_0000 | 1 KB | timer | |
| 0x0002_0000 | 4 KB (mask 0xFFFF_F000) | `ap_ext_*` port -> TB `scp_sim_ctrl` (TAG "ap") | same offsets as `hal/sim.h:14-35`, so `SIM_HALT` = 0x0002_0008 as in `crt0.S:18` |
| 0x2000_0000 | 16 KB window (mask 0xFFFF_C000) | scp_data_split "axi" side -> tlul_adapter_host -> TL-UL | multi-cycle; see 4.6 for what answers inside |
| other | | bus.sv decode err | |

The AP's instruction port goes straight to scp_ram port B, as in scp_top (`scp_top.sv:399-404`).
The AP takes no interrupts and polls.

### 4.4 soc4_ctrl (SCP 0x0002_1000)

A bus.sv device answering in exactly one cycle, reset by `rst_ni`.

| Off | Name | Access | Reset | Fields / behaviour |
|---|---|---|---|---|
| 0x000 | CPU0_BOOT | RW | 0x0000_0000 | [31:8] boot address, to `u_cpu0.boot_addr_i`. [7:0] read 0, writes ignored: Ibex asserts `boot_addr_i[7:0] == 0` (`ibex_if_stage.sv:932`) and the reset PC is `{boot_addr_i[31:8], 8'h80}` (`ibex_if_stage.sv:243, 250-251`) |
| 0x004 | CPU1_BOOT | RW | 0x0000_0000 | as CPU0_BOOT |
| 0x008 | CPU_FETCH_EN | RW | 0 | [n] = fetch enable of CPUn (`scp_core.fetch_enable_i`); other bits 0 |
| 0x00C | AP_RUN | RW | 0 | [0]: AP fetch enable = AP_RUN && !bfm_sel_i |
| 0x010 | STRAPS | RO | - | [0] BFM_SEL (the static strap `bfm_sel_i`); [31:1] 0 |
| 0x014 | CPU_STAT | RO | - | [1:0] core_sleep of CPU1..0 as seen by the adapter (post-isolation); [5:4] load port open (5.4) for CPU1..0; [9:8] wake-pulse count bit 0 per CPU (diagnostic). **core_sleep is defined only while HWSTAT_n is ON or WARM_RST.** In OFF/MEM_RET-like modes RTL simulation reads 1 (Ibex `core_sleep_o` is 1 in reset, `ibex_top.sv:316-323`) and PA simulation reads 0 (isolation clamp). Neither the firmware nor the TB compares it outside ON/WARM_RST |
| 0x020 + 4n | HWSTAT_n (n = 0..3) | RO | - | [15:0] PPUHWSTAT of domain n (`ppu_axi_dom_top.ppuhwstat`); [31:16] 0 |
| other | | | | err |

Byte enables: writes to CPUn_BOOT honour `be`. The single-bit registers take bit 0 of byte lane 0.

### 4.5 soc4_mbx SCP registers (SCP 0x0002_2000)

A bus.sv device answering in exactly one cycle, reset by `rst_ni`. The AP cannot reach these:
the TL-UL socket decodes only the queue memory and the doorbell (4.6).

| Off | Name | Access | Reset | Fields / behaviour |
|---|---|---|---|---|
| 0x00 | DB_STATUS | RO | 0 | [0] RING: sticky, set by any accepted AP write to the doorbell (4.6). It drives `scp_top.irq_ext_i` as a level |
| 0x04 | DB_CLEAR | WO | - | write [0] = 1 clears RING. A ring in the same cycle wins (RING stays 1) |
| 0x08 | FW_EN | RW | **0** | [0]: 0 denies every TL-UL request (deny-all at reset) |
| 0x0C | FW_SRC | RW | 0x00 | [7:0] the one admitted a_source (TL_AIW = 8, OT `top/top_pkg.sv:10`) |
| 0x10 | FW_DENY_CNT | RO, write clears | 0 | [31:0] requests the firewall denied, counted at the socket's host-side A handshake. Saturates at 0xFFFF_FFFF |
| 0x14 | FW_LAST | RO | 0 | [7:0] a_source of the last denied request; [8] valid; [9] FW_EN was 0 at that denial; [31:10] 0 |
| 0x18 | DB_RING_CNT | RO, write clears | 0 | [31:0] accepted AP doorbell writes (diagnostic; soc4bfm checks "no side effect") |
| other | | | | err |

Firmware owns these: `hal/soc4_db.c` (DB_*) and `soc4_scp.c` boot (FW_*). Section 9.

### 4.6 AP-visible TL-UL window (soc4_mbx, decode on full a_address)

| a_address | Socket dev | Target | Behaviour |
|---|---|---|---|
| 0x2000_0000 - 0x2000_03FF | 0 | tlul_adapter_sram -> tc_sram port 1 | queue memory, Get / PutFull / PutPartial, any byte mask |
| 0x2000_1000 | 1 | tlul_adapter_reg -> doorbell glue | DOORBELL: any write (any data, any mask) sets RING; a read returns 0 with no side effect. This matches OpenSBI, which writes value 1 (default `riscv,a2p-doorbell-value`) to one write-only 32-bit register after the tail update (OpenSBI `lib/utils/mailbox/fdt_mailbox_rpmi_shmem.c:300-305, 616-617`) |
| 0x2000_1004 - 0x2000_1FFF | 1 | doorbell glue | d_error, no effect (`error_i`) |
| anything else | 3 | tlul_err_resp (inside the socket) | d_error, no effect |
| any address while `!FW_EN \|\| a_source != FW_SRC` | 3 | tlul_err_resp | d_error, no effect, FW_DENY_CNT++ |

### 4.7 CPU map (CPU0 and CPU1 cores, identical)

| Base | Size | Target | Notes |
|---|---|---|---|
| 0x0000_0000 | 4 KB | the CPU's tc_sram (instr = port 0; data = port 1) | boot address 0x0000_0000: vectors at 0, reset entry 0x80 |
| other | | soc4_cpu_ram returns err (instr: instruction access fault; data: load/store fault) | no RAM access |

CPU RAM layout (`cpu/cpu.ld`, NEW):

| Offset | Content |
|---|---|
| 0x000-0x07F | vector table (32 x `j`); every entry jumps to `cpu_trap` |
| 0x080 | reset entry `j cpu_start` |
| 0x084-0xBFF | code (under 512 B expected) |
| 0xC00 | MARKER: 0xC0DE_0000 \| mhartid, written after each boot |
| 0xC04 | BOOT_COUNT: incremented by every boot (the image holds 0) |
| 0xC08 | WAKE_COUNT (CPU0): incremented after every WFI return |
| 0xC0C | TRAP: mcause of an unexpected trap, else 0 |
| 0xC10-0xC3F | DUMP: s0, s1, s2..s11 (12 words) stored after each wake (CPU0) |
| 0xC80 | COUNT (CPU1): the loop counter, stored every iteration |
| 0xD00-0xFFF | stack (sp = 0x1000) |

### 4.8 Simulation controls

Both are `tb/pmu/scp_sim_ctrl.sv` with `NUM_PD = 4`, on bus.sv ports, register map unchanged
(`hal/sim.h:14-35`, `scp_sim_ctrl.sv:9-37`). A new `TAG` parameter (Section 6.4) sets the
console prefix: SCP "fw", AP "ap". Uses in soc4:

| Register | SCP instance (TAG "fw") | AP instance (TAG "ap") |
|---|---|---|
| OUT, CYCLE | console, time | console, time |
| HALT | end of soc4stress (SCP image is a test). In soc4/soc4bfm the server never halts | end of soc4 (AP verdict) |
| CHECK {[15:8] dom, [3:0] mode} | soc4stress: the PPU-level CHECK of pmu_tb (`pmu_tb.sv:705-748`) | soc4: the PPU-level CHECK plus the IP-state rule for (dom, mode) (10.4) |
| WAKE, DENY, WORK_LEN, START, LIGHT, IP_CMD, IP_SEED | soc4stress drives ACC stimulus | soc4 drives ACC stimulus. The TB ORs the two instances' outputs per domain; only one program drives in any test |
| TB_CHECKS, TB_ERRORS | read by the stress image | read by the AP at the end |
| AP_CMD / AP_STAT | soc4stress: AP_CMD carries the stress image's TB commands ('H' hold_busy mask, 'D' ACC deny mask; 10.1), echoed on AP_STAT. soc4bfm: AP_STAT input = BFM status | unused |
| OBS window | soc4stress: as pmu_tb's OBS (`sim.h:40-79`) for domains 0-3 | same |

---------------------------------------------------------------------------------------------------

## 5. Module specifications

New RTL lives in `src/soc4/rtl/` (NEW directory). Each module has a header that cites this
section. Every new module is glue: the reused IP is instantiated verbatim.

| Block | Module (NEW unless noted) | Reused IP, verbatim |
|---|---|---|
| System top | `soc4_top` | `scp_top` (EDIT, parameter only), Ibex `bus.sv` (ext decode) |
| TL-UL mailbox | `soc4_mbx` | OpenTitan `tlul_socket_1n`, `tlul_adapter_sram`, `tlul_adapter_reg` (+ closure, Section 7); PULP `tc_sram` |
| CPU domain | `soc4_cpu_dom` | `ppu_axi_dom_top`, `scp_core` (EDIT: boot_addr_i), Ibex |
| CPU RAM | `soc4_cpu_ram` | PULP `tc_sram` (2 ports) |
| CPU Q-Channel adapter | `soc4_cpu_adp` | none (about 40 lines) |
| ACC domain | `soc4_acc_dom` | `ppu_axi_dom_top`, `ppu_device_ip` |
| AP | `soc4_ap` | `scp_core`, `scp_ram` (EDIT: IMAGE_PLUSARG), Ibex `timer.sv`, `bus.sv`, `scp_data_split`, OpenTitan `tlul_adapter_host` |
| Control registers | `soc4_ctrl` | none |
| AP/BFM mux, ext decode | inside `soc4_top` | Ibex `bus.sv` |

### 5.0 Bus timing contracts (used below)

| Name | Rules | Source |
|---|---|---|
| **BUS1** (bus.sv device) | req/we/be/addr/wdata valid in the request cycle and not held. The device answers with rvalid (and rdata, err) **exactly one cycle later** and cannot stall. err is a load/store access fault on the core | `bus.sv:14-15, 95-97, 125-127`; facts hw a, d |
| **IBX** (Ibex core port) | req held until gnt; rvalid one or more cycles after gnt, in order; err only with rvalid. Instr side up to 2 outstanding, data side up to 2 | `scp_core.sv:105-112`; `ibex_prefetch_buffer.sv:44` |
| **TLUL** | TileLink-UL as `tlul_pkg`: A accepted on `a_valid & a_ready`, D on `d_valid & d_ready`; a_size 2 with an aligned address and a mask that is legal for that size (`tlul_err.sv:41-94`); a_user.instr_type a valid MuBi4 (`tlul_err.sv:35-39`) | OT `tlul_pkg.sv`, `tlul_err.sv` |
| **AXIL** | AXI4-Lite as scp_axi_lite_master / ppu_axi_lite_adapter: one transaction at a time, PROT 3'b001 | `scp_axi_lite_master.sv:219, 231`; `ppu_axi_lite_adapter.sv:281-282` |

### 5.1 soc4_top

```systemverilog
module soc4_top #(
  parameter logic [7:0]  AP_SOURCE         = 8'h10,  // the AP's TL-UL a_source (= SOC4_AP_SOURCE in soc4_regs.h)
  parameter int unsigned PCSM_RET_SETTLE   = 0,      // all four domains
  parameter int unsigned PCSM_LOGIC_SETTLE = 0,
  parameter int unsigned DEV_CNT_W         = 12      // ppu_device_ip CNT_W, as pmu_tb (sim.h WORK_LEN)
) (
  input  logic        clk_i,          // the only clock: SCP, AP, mailbox, PPU aclk, every dclk
  input  logic        rst_ni,         // system reset
  input  logic        scp_rst_ni,     // SCP subsystem held in reset while low (scp reset = rst_ni & scp_rst_ni)
  input  logic        scp_fetch_en_i, // scp_top.fetch_enable_i
  input  logic        bfm_sel_i,      // static per test: 1 = TB BFM drives the TL-UL socket; AP not fetched

  // SCP sim-control page 0x0002_0000-0x0002_0FFF, BUS1
  output logic        sim_req_o, sim_we_o, output logic [3:0] sim_be_o,
  output logic [31:0] sim_addr_o, sim_wdata_o,
  input  logic        sim_rvalid_i, input logic [31:0] sim_rdata_i, input logic sim_err_i,

  // AP sim-control page (AP 0x0002_0000-0x0002_0FFF), BUS1
  output logic        ap_ext_req_o, ap_ext_we_o, output logic [3:0] ap_ext_be_o,
  output logic [31:0] ap_ext_addr_o, ap_ext_wdata_o,
  input  logic        ap_ext_rvalid_i, input logic [31:0] ap_ext_rdata_i, input logic ap_ext_err_i,

  // TL-UL BFM port (used only when bfm_sel_i = 1)
  input  tlul_pkg::tl_h2d_t tl_bfm_i,
  output tlul_pkg::tl_d2h_t tl_bfm_o,

  // Accelerator stimulus (the TB ORs both sim controls into these), per ACC domain k = 0,1 (ACC0, ACC1)
  input  logic [1:0]           acc_start_i,
  input  logic [DEV_CNT_W-1:0] acc_work_len_i,
  input  logic [1:0]           acc_light_i,
  input  logic [1:0]           acc_wake_i,
  input  logic [1:0]           acc_deny_i,
  input  logic [1:0][1:0]      acc_ip_cmd_i,
  input  logic [7:0]           acc_ip_seed_i,

  // TB-only, always-on: per domain n, ORed into dev_quiescent_busy (5.3, 5.5, 5.6). A real SoC ties it to 0
  input  logic [3:0]           hold_busy_i,

  output logic        scp_sleep_o,    // scp_top.core_sleep_o
  output logic        ap_sleep_o      // AP core_sleep_o
);
```

Instances (names are part of the contract: the UPF and the TB use them):

| Instance | Module | Key connections |
|---|---|---|
| `u_scp` | `scp_top #(.NUM_PPU(4), .BOOT_ADDR(0), .RPMI_MBOX(1'b0))` | clk_i; rst_ni = rst_ni & scp_rst_ni; fetch_enable_i = scp_fetch_en_i; ext_* -> `u_ext` host; m_axi_*[n] -> domain n; `s_ap_axi_*` inputs tied 0, outputs open; ppu_irq_i[n] = domain n irq; irq_ext_i = `u_mbx.db_irq_o` |
| `u_ext` | Ibex `bus #(.NrDevices(6), .NrHosts(1), .DataWidth(32), .AddressWidth(32))` | host 0 = u_scp.ext_*; host_gnt ignored (it equals req: `bus.sv:134`); devices per 4.2 |
| `u_ctrl` | `soc4_ctrl` | ext device 1; boot/fetch to CPUs; ap_run to `u_ap` |
| `u_mbx` | `soc4_mbx #(.AP_SOURCE(AP_SOURCE))` | ext devices 2 (regs) and 3 (queue mem); TL-UL host side = mux output |
| `u_cpu0`, `u_cpu1` | `soc4_cpu_dom #(.HART_ID(0 / 1), .FULL_RET(1 / 0))` | PPU AXI n = 0 / 1; load port = ext device 4 / 5 |
| `u_acc0`, `u_acc1` | `soc4_acc_dom #(.MEM_RET(1 / 0))` | PPU AXI n = 2 / 3; stimulus bit k = 0 / 1 |
| `u_ap` | `soc4_ap #(.AP_SOURCE(AP_SOURCE))` | fetch_en = `u_ctrl.ap_run_o & ~bfm_sel_i`; ext -> ap_ext_*; TL-UL host -> mux |

AP/BFM mux (combinational, static select, about 10 lines):

```systemverilog
assign tl_sock_h   = bfm_sel_i ? tl_bfm_i : tl_ap_h;
always_comb begin
  tl_bfm_o = tl_sock_d;  tl_ap_d = tl_sock_d;            // payload to both
  if (bfm_sel_i) begin tl_ap_d.a_ready = 1'b0;  tl_ap_d.d_valid = 1'b0;  end
  else           begin tl_bfm_o.a_ready = 1'b0; tl_bfm_o.d_valid = 1'b0; end
end
```

`bfm_sel_i` must not change after reset. The TB drives it from `+bfm` at time 0.

Stimulus has three sources, ORed per domain in soc4_tb: the SCP sim control, the AP sim control,
and the TB's own stimulus block (the BFM tasks in soc4bfm; the SCP's TB commands in soc4stress,
10.1). `hold_busy_i` comes only from the TB block.

`hold_busy_i[n]` is TB-only. It models a device that is busy and never answers a quiescence
request. The PPU has no timeout, so it is the deterministic way to make a power-off step or a
pending ON miss its deadline (10.5). Its name and this paragraph mark it as a test port. The
production integration ties it to 0, and soc4_top's header says so.

Mutant hooks (soc4neg, Section 10.6) are `ifdef`s in soc4 glue only: `SOC4_MUT_CPU0_NRET`
(in soc4_cpu_dom), `SOC4_MUT_FW_OPEN` (in soc4_mbx), `SOC4_MUT_ACC0_NORET` (in soc4_acc_dom, the
ACC0 instance: the bank pins miswired so that retention acts as shutdown, 5.6). None of them
changes a PPU parameter or identification register. Vendored files carry none.

### 5.2 soc4_mbx (the TL-UL mailbox)

```systemverilog
module soc4_mbx #(parameter logic [7:0] AP_SOURCE = 8'h10) (
  input  logic clk_i, rst_ni,
  // AP side: TL-UL subordinate
  input  tlul_pkg::tl_h2d_t tl_h_i,
  output tlul_pkg::tl_d2h_t tl_h_o,
  // SCP registers (4.5), BUS1
  input  logic reg_req_i, reg_we_i, input logic [3:0] reg_be_i,
  input  logic [31:0] reg_addr_i, reg_wdata_i,
  output logic reg_rvalid_o, output logic [31:0] reg_rdata_o, output logic reg_err_o,
  // SCP queue-memory port (4.2 dev 3), BUS1
  input  logic mem_req_i, mem_we_i, input logic [3:0] mem_be_i,
  input  logic [31:0] mem_addr_i, mem_wdata_i,
  output logic mem_rvalid_o, output logic [31:0] mem_rdata_o, output logic mem_err_o,
  // doorbell interrupt to scp_top.irq_ext_i: level, sticky until DB_CLEAR
  output logic db_irq_o
);
```

(AP_SOURCE is used only as a reset-free documentation constant in assertions. The firmware
programs FW_SRC.)

Instances:

```systemverilog
// Firewall + address decode -> the socket's dev_select (OT tlul_socket_1n.sv:35-38: any value
// outside 0..N-1 gets an error response)
logic fw_ok;  logic [1:0] sel;
assign fw_ok = fw_en_q && (tl_h_i.a_source == fw_src_q);
always_comb begin
  if (!fw_ok)                                    sel = 2'd3;   // denied
  else if (tl_h_i.a_address[31:10] == 22'h08_0000) sel = 2'd0;  // 0x2000_0000-03FF queue memory
  else if (tl_h_i.a_address[31:12] == 20'h2_0001)  sel = 2'd1;  // 0x2000_1xxx doorbell page
  else                                           sel = 2'd3;   // unmapped
end
tlul_socket_1n #(.N(2)) u_sock (            // all other parameters default: pass-through FIFOs depth 1, ExplicitErrs
  .clk_i, .rst_ni, .tl_h_i, .tl_h_o, .tl_d_o(tl_dev_h), .tl_d_i(tl_dev_d), .dev_select_i(sel));

tlul_adapter_sram #(
  .SramAw(8), .SramDw(32), .SramDepth(256), .Outstanding(1), .ByteAccess(1),
  .ErrOnWrite(0), .ErrOnRead(0), .CmdIntgCheck(0),
  .EnableRspIntgGen(1), .EnableDataIntgGen(1), .EnableDataIntgPt(0),
  .SecFifoPtr(0), .EnableReadback(0), .DataXorAddr(0)
) u_sram_ad (
  .clk_i, .rst_ni, .tl_i(tl_dev_h[0]), .tl_o(tl_dev_d[0]),
  .en_ifetch_i(prim_mubi_pkg::MuBi4False),
  .req_o(q1_req), .req_type_o(), .gnt_i(1'b1), .we_o(q1_we), .addr_o(q1_addr),
  .wdata_o(q1_wdata), .wmask_o(q1_wmask), .intg_error_o(), .user_rsvd_o(),
  .rdata_i(q_rdata[1]), .rvalid_i(q1_rvalid_q), .rerror_i(2'b00),
  .compound_txn_in_progress_o(), .readback_en_i(prim_mubi_pkg::MuBi4False),
  .readback_error_o(), .wr_collision_i(1'b0), .write_pending_i(1'b0));

tlul_adapter_reg #(
  .CmdIntgCheck(0), .EnableRspIntgGen(1), .EnableDataIntgGen(1),
  .RegAw(12), .RegDw(32), .AccessLatency(0)
) u_db_ad (
  .clk_i, .rst_ni, .tl_i(tl_dev_h[1]), .tl_o(tl_dev_d[1]),
  .en_ifetch_i(prim_mubi_pkg::MuBi4False), .intg_error_o(),
  .re_o(db_re), .we_o(db_we), .addr_o(db_addr), .wdata_o(), .be_o(),
  .busy_i(1'b0), .rdata_i(32'h0), .error_i((db_re | db_we) && (db_addr != 12'h000)));

tc_sram #(.NumWords(256), .DataWidth(32), .ByteWidth(8), .NumPorts(2), .Latency(1),
          .SimInit("zeros")) u_qmem (
  .clk_i, .rst_ni,
  .req_i  ({q1_req,                 mem_req_i}),
  .we_i   ({q1_we,                  mem_we_i}),
  .addr_i ({q1_addr,                mem_addr_i[9:2]}),
  .wdata_i({q1_wdata,               mem_wdata_i}),
  .be_i   ({{q1_wmask[24], q1_wmask[16], q1_wmask[8], q1_wmask[0]}, mem_be_i}),
  .rdata_o(q_rdata));
```

Glue behaviour (the 60-80 lines the decision allows):

| Item | Rule |
|---|---|
| `q1_rvalid_q` | `<= q1_req & ~q1_we` each clk (a write needs no rvalid: OT `tlul_adapter_sram.sv` pushes the SRAM request FIFO only for reads, `sramreqfifo_wvalid = sram_ack & ~we_o`, adapter line 493) |
| SCP mem port | `mem_rvalid_o <= mem_req_i`; `mem_rdata_o = q_rdata[0]`; `mem_err_o = 0` (the window is exactly 1 KiB). This is BUS1: tc_sram Latency 1 (`tc_sram.sv:113-121`) |
| RING | `ring_d = (ring_q & ~(clr_wr & reg_wdata_i[0])) \| db_we_ok`, with `db_we_ok = db_we && db_addr == 0`. Set wins over clear |
| `db_irq_o` | `= ring_q` (level) |
| DB_RING_CNT | += `db_we_ok` |
| FW_DENY_CNT / FW_LAST | on `tl_h_i.a_valid & tl_h_o.a_ready & ~fw_ok`: count++ (saturating), FW_LAST = {fw_en_q==0, 1'b1, a_source} |
| SCP regs | 4.5. BUS1: `reg_rvalid_o <= reg_req_i`; err for an unmapped offset; registered rdata |
| Reset | FW_EN 0 (`SOC4_MUT_FW_OPEN`: FW_EN resets to 1 and FW_SRC to 8'h00, so a source 0 passes at reset and the BFM's source-0 probe in B0 gets through) |

Notes:

- **Integrity.** The AP's `tlul_adapter_host` rejects any response whose `rsp_intg` does not
  decode (Section 1.5). The two adapters therefore have `EnableRspIntgGen = 1`.
  `tlul_err_resp` already generates it (OT `tlul_err_resp.sv:29-35`). The socket FIFOs pass d_user
  unchanged. `CmdIntgCheck = 0` on both adapters (decision 10): the BFM sends
  `TL_A_USER_DEFAULT`, whose `cmd_intg` is all ones (OT `tlul_pkg.sv:53-58`) and would fail a check.
- **instr_type.** Both adapters reject an invalid `a_user.instr_type` (OT `tlul_err.sv:35-39`;
  `tlul_adapter_sram.sv:152-154`). `TL_A_USER_DEFAULT` carries `MuBi4False`.
- **Denied requests.** For a denied request, tlul_err_resp answers one cycle later with
  `d_error = 1`, `d_source = a_source`, and read data `DataWhenError` = all ones
  (OT `tlul_err_resp.sv:37-69`; `tlul_pkg.sv:44`). The request reaches no device, so it has no
  side effect.
- **Ordering.** The socket holds a request to a different device until all responses are back
  (OT `tlul_socket_1n.sv:132-134`), so responses come back in order. That is what IBX needs on
  the AP side.
- **Byte writes.** librpmi writes the queues one byte at a time (`port/rpmi_env.h:33-41`). tc_sram
  honours byte enables on both ports (`tc_sram.sv:153-157`). If both ports write the same word in
  one cycle, port 1 (AP) wins (`tc_sram.sv:45-48`). By the RPMI ownership of head and tail this
  never happens.
- **Timing.** AP side TLUL: about 1-2 cycles per access. SCP side BUS1.

### 5.3 soc4_cpu_dom (one CPU power domain)

```systemverilog
module soc4_cpu_dom #(
  parameter logic [31:0] HART_ID  = 32'd0,
  parameter bit          FULL_RET = 1'b0,  // 1: STA_FULL_RET_SPT_CFG and FULL_RET_RAM_REG_CFG (CPU0)
  parameter int unsigned PCSM_RET_SETTLE = 0, PCSM_LOGIC_SETTLE = 0
) (
  input  logic clk_i, rst_ni,
  // PPU AXI4-Lite subordinate: s_axi_* exactly as ppu_axi_dom_top (ppu_axi_dom_top.sv:125-147)
  ...,
  output logic        irq_o,
  input  logic [31:0] boot_addr_i,     // soc4_ctrl CPUn_BOOT (always-on into switched: no isolation needed)
  input  logic        fetch_en_i,      // soc4_ctrl CPU_FETCH_EN[n]
  // load port, BUS1 (SCP ext dev 4/5)
  input  logic ld_req_i, ld_we_i, input logic [3:0] ld_be_i,
  input  logic [31:0] ld_addr_i, ld_wdata_i,
  output logic ld_rvalid_o, output logic [31:0] ld_rdata_o, output logic ld_err_o,
  output logic [15:0] hwstat_o,        // PPUHWSTAT
  output logic        core_sleep_o,    // post-isolation, for CPU_STAT
  output logic        ld_open_o,
  input  logic        hold_busy_i      // TB-only (5.5); 0 in a real SoC
);
```

Instances: `u_dom` = `ppu_axi_dom_top` with the parameters of Section 3.3 for CPU0/CPU1;
`u_core` = `scp_core #(.HART_ID(HART_ID))`; `u_ram` = `soc4_cpu_ram`; `u_adp` = `soc4_cpu_adp`.

| Signal | Connection |
|---|---|
| u_core.clk_i | u_dom.dev_clk |
| u_core.rst_ni | u_dom.dev_ret_rst_n (decision 5). `ifdef SOC4_MUT_CPU0_NRET` and HART_ID == 0: u_dom.dev_nret_rst_n |
| u_core.boot_addr_i | boot_addr_i (new port, Section 6.2; sampled at reset release, `ibex_controller.sv:580-593`) |
| u_core.fetch_enable_i | fetch_en_i |
| u_core.irq_external_i | u_adp.wake_irq_o |
| u_core.irq_timer_i, irq_nm_i, irq_fast_i | 0 |
| u_core instr/data ports | u_ram ports 0 / 1 (IBX) |
| u_dom.dev_quiescent_busy | u_adp.busy_o (= hold_busy_i, TB-only; 5.5) |
| u_dom.dev_quiescent_deny | u_adp.deny_o |
| u_dom.dev_wake | 0 (decision 7: no device wake) |
| u_dom.dev_quiescent_ok | u_adp.qok_i |
| u_dom.ram_sleep[0], ram_sd[0] | u_ram.sleep_i, sd_i (banks 1-7 unused) |
| u_dom.ppuhwstat | hwstat_o and u_ram.hwstat_i |
| u_dom.dev_isolaten, logic_on, logic_ret, ret_n | open (named by the UPF at the PPU/PCSM pins) |
| core_sleep_o | u_core.core_sleep_o (the UPF clamps it to 0 while isolated) |

### 5.4 soc4_cpu_ram (CPU RAM wrapper)

```systemverilog
module soc4_cpu_ram (
  input  logic        dev_clk_i,     // the domain's gated clock: tc_sram and the CPU-side response flops
  input  logic        aon_clk_i,     // clk_i: the load port's response flop
  input  logic        aon_rst_ni,    // rst_ni
  input  logic        core_rst_ni,   // dev_ret_rst_n, the core's reset: clears the CPU-side response flops
  input  logic        sleep_i, sd_i, // PCSM bank-0 pins
  input  logic [15:0] hwstat_i,
  // port 0: instruction (IBX)
  input  logic i_req_i, output logic i_gnt_o, i_rvalid_o, input logic [31:0] i_addr_i,
  output logic [31:0] i_rdata_o, output logic i_err_o,
  // port 1: data (IBX)
  input  logic d_req_i, output logic d_gnt_o, d_rvalid_o, input logic d_we_i, input logic [3:0] d_be_i,
  input  logic [31:0] d_addr_i, d_wdata_i, output logic [31:0] d_rdata_o, output logic d_err_o,
  // load port (BUS1), shares tc_sram port 1
  input  logic ld_req_i, ld_we_i, input logic [3:0] ld_be_i, input logic [31:0] ld_addr_i, ld_wdata_i,
  output logic ld_rvalid_o, output logic [31:0] ld_rdata_o, output logic ld_err_o,
  output logic outstanding_o, ld_open_o
);
```

Inside: `tc_sram #(.NumWords(1024), .DataWidth(32), .ByteWidth(8), .NumPorts(2), .Latency(1),
.SimInit("none")) u_sram (.clk_i(dev_clk_i), .rst_ni(sram_rst_n), ...)`.

ppu_ip_sram pin behaviour (`rtl/ppu/ppu_ip_sram.sv:13-17, 68-105`) and how the wrapper reproduces
it without a second writer of the tc_sram array (Error-[ICPD], decision 15):

| ppu_ip_sram behaviour | Wrapper implementation |
|---|---|
| `accessible = (sleep === 0) && (shutdown === 0)` | `acc = (sleep_i === 1'b0) && (sd_i === 1'b0)` |
| shutdown destroys contents; they do not return | `sram_rst_n = aon_rst_ni && (sd_i === 1'b0)`. tc_sram's async reset loads `init_val` = X into the whole array (`tc_sram.sv:86-98, 124-129`) and holds it there while sd is 1. An X shutdown also counts as asserted |
| sleep keeps contents, no access | requests masked by `acc`, so the array keeps its values |
| an inaccessible read returns X | an inaccessible request is answered with err = 1 and data **0**. Ibex checks that `{rdata, err}` are known whenever rvalid is high (`IbexInstrRPayloadX`, `ibex_top.sv:1409-1410`; `IbexDataRPayloadX`, `:1497-1498`), so the wrapper cannot return X |

Port behaviour:

| Port | Behaviour |
|---|---|
| 0 (instr) | `i_gnt_o = i_req_i`. RAM request = `i_req_i & acc & (i_addr_i[31:12] == 0)`. On dev_clk, reset core_rst_ni: `i_rvalid_q <= i_req_i`; `i_err_q <= i_req_i & (addr out of range \| !acc)`. `i_rdata_o = i_ok_q ? rdata[0] : 32'h0` (an errored response carries 0, never X) |
| 1 (data) | `d_gnt_o = d_req_i & ~ld_req_i` (the load port has priority). Same range, acc and response rules as port 0 |
| load | `open = acc && (hwstat_i == 16'h0100 /*ON*/ \|\| hwstat_i == 16'h0200 /*WARM_RST*/)` (one-hot per `ppu_pkg.sv:134-147`). If `!open`: no RAM access, `ld_err` next cycle. Else tc_sram port 1 gets {ld_we, ld_addr[11:2], ld_wdata, ld_be}. Response on **aon_clk** (BUS1): `ld_rvalid_o <= ld_req_i`, `ld_err_o <= ld_req_i & ~open`, `ld_rdata_o = rdata[1]` |
| outstanding_o | `i_req_i \| d_req_i \| i_rvalid_q \| d_rvalid_q` (a request now, or a response owed) |
| ld_open_o | `open` |

Clocking notes:

- dev_clk is `clk_i` gated by a latch + AND (`common/clk_gate.sv`). Its edge falls in the same
  time step as `clk_i`'s, in a later delta. All inputs to tc_sram come from NBA-assigned flops
  (the SCP's and Ibex's), so tc_sram samples previous-cycle values with no race (facts hw hazard
  23). The load port's request is accepted at the same edge in which its response flop (on
  aon_clk) captures `ld_req_i`. So rdata is valid when bus.sv takes it one cycle later.
- The CPU-side response flops run on dev_clk and are reset by the core reset (decision 5: "a
  forced power-down freezes a request and its response together"). In OFF and MEM_RET the core
  reset clears them. In FULL_RET (CPU0) the core and these flops both hold, and resume together.
  This avoids the stale-rvalid assertion of facts hw hazard 6.
- Residual window (facts hw hazard 4): on the way down PPUHWSTAT still reads ON for
  CLKEN_ISO + ISO_RST + PCSM cycles after DEVCLKEN falls (`ppu_seq.sv:680-735, 844-846`). A load
  in that window would get its rvalid from the aon flop, but the RAM would not see it, because
  dev_clk is stopped. The bus does not hang. Firmware rule (Section 9.5): load only while the PPU
  is static WARM_RST with PWSR = WARM_RST.

### 5.5 soc4_cpu_adp (CPU Q-Channel adapter, always-on)

```systemverilog
module soc4_cpu_adp #(parameter int unsigned WAKE_PULSE = 8) (
  input  logic dclk_i, aon_rst_ni,
  input  logic core_sleep_i,   // Ibex core_sleep_o through isolation (clamp 0)
  input  logic outstanding_i,  // soc4_cpu_ram.outstanding_o
  input  logic qok_i,          // ppu_axi_dom_top.dev_quiescent_ok (= Q_STOPPED, combinational in dclk)
  input  logic hold_busy_i,    // TB-only (soc4_top.hold_busy_i[n]); 0 in a real SoC
  output logic busy_o,         // -> dev_quiescent_busy
  output logic deny_o,         // -> dev_quiescent_deny
  output logic wake_irq_o      // -> core irq_external_i
);
```

| Rule | Implementation | Why |
|---|---|---|
| accept a quiescence request only if the core is in WFI with nothing outstanding | `busy_o = hold_busy_i`; `deny_o = !hold_busy_i && !(core_sleep_i && !outstanding_i)`. With hold_busy low (always, in a real SoC), this is exactly decision 7. With hold_busy high, deny is suppressed so that the request waits in Q_REQUEST (a core that never answers), which is how soc4bfm B11 makes CPU1's power-off miss its deadline | qchannel_device: deny wins over busy; no deny and no busy -> Q_STOPPED (`qchannel_device.sv:77-128`). `core_sleep_o = 1` already means no outstanding fetch or LSU transaction (`ibex_top.sv:316-331`, `ibex_core.sv:507-516`) |
| no device wake | `dev_wake = 0` (in soc4_cpu_dom) | decision 7 |
| wake pulse after the Q-Channel exit | on `qok_q & ~qok_i` (leaving Q_STOPPED), drive `wake_irq_o = 1` for WAKE_PULSE dclk cycles | Ibex leaves WFI on `mip & mie` whatever `mstatus.MIE` is (`ibex_cs_registers.sv:1042-1043`; `ibex_controller.sv:603-620`). The pulse must end before the next WFI, or `core_sleep_o` stays 0 and the next OFF is denied (facts hw hazard 8). 8 cycles is far shorter than the CPU program's dump sequence |

The pulse also fires on the first ON from OFF, when the core is out of reset with FETCH_EN = 0.
It is harmless: the WARM_RST that follows resets the core.

After a *forced* entry (DEVREQEN = 0) there is no Q_STOPPED and so no pulse. CPU0 then resumes
exactly where it was frozen (the core and the RAM response flops held together, 5.4).

### 5.6 soc4_acc_dom (one accelerator power domain)

Ports: clk_i, rst_ni, PPU AXI subordinate, irq_o, hwstat_o, and stimulus start_i,
work_len_i[DEV_CNT_W], light_i, wake_i, deny_i, ip_cmd_i[1:0], ip_seed_i[7:0], hold_busy_i
(TB-only).
Parameter `MEM_RET` (1 for ACC0).

Instances `u_dom` (`ppu_axi_dom_top`, Section 3.3) and `u_ip` (`ppu_device_ip #(.CNT_W(DEV_CNT_W))`),
wired as `pmu_top.sv:283-336` (decision 7), plus the TB-only hold_busy:

| Signal | Connection |
|---|---|
| dev_quiescent_busy | `busy_t = u_ip.busy \| hold_busy_i` (u_ip.busy is an isolated output, clamp 0; hold_busy_i is TB-only) |
| dev_quiescent_deny | `deny_i && busy_t` |
| dev_wake | `wake_i \| busy_t` |
| u_ip.clk / nret_rst_n / ret_rst_n | dev_clk / dev_nret_rst_n / dev_ret_rst_n |
| u_ip.bank_sleep / bank_sd | ram_sleep / ram_sd (all 8 banks). `ifdef SOC4_MUT_ACC0_NORET` (MEM_RET = 1 instance only): `bank_sleep = '0`, `bank_sd = ram_sd \| ram_sleep`. Retention then acts as shutdown and the banks read X in MEM_RET. IDR0/IDR1 are unchanged, so `check_ident` still passes and `[chk:MEMRET_RAM]` is the check that trips |
| u_ip.done | open |

DEVQACTIVE = wake | busy (`qchannel_device.sv`: `QACTIVE <= busy | wake`). "busy delays
quiescence": busy without deny waits in Q_REQUEST with no timeout. "deny && busy refuses".

### 5.7 soc4_ap (the always-on AP)

```systemverilog
module soc4_ap #(parameter logic [7:0] AP_SOURCE = 8'h10) (
  input  logic clk_i, rst_ni,
  input  logic fetch_en_i,                 // AP_RUN && !bfm_sel_i
  output logic ext_req_o, ext_we_o, output logic [3:0] ext_be_o,
  output logic [31:0] ext_addr_o, ext_wdata_o,
  input  logic ext_rvalid_i, input logic [31:0] ext_rdata_i, input logic ext_err_i,   // BUS1
  output tlul_pkg::tl_h2d_t tl_o,
  input  tlul_pkg::tl_d2h_t tl_i,
  output logic core_sleep_o
);
```

| Instance | Module, parameters | Notes |
|---|---|---|
| u_core | `scp_core #(.HART_ID(32'h10))`, boot_addr_i = 0 | interrupts all 0 (the AP polls) |
| u_split | `scp_data_split #(.AXI_BASE(32'h2000_0000), .AXI_MASK(32'hFFFF_C000))` | keeps responses in order across its two sides (`scp_data_split.sv:22-31`); same-side requests pipeline (up to 2) |
| u_bus | `bus #(.NrDevices(3), .NrHosts(1))`: RAM 0x0000_0000/0xFFFF_0000, timer 0x0001_0000/0xFFFF_FC00, ext 0x0002_0000/0xFFFF_F000 | ext page mask 4 KB (scp_sim_ctrl aliasing) |
| u_ram | `scp_ram #(.IMAGE_PLUSARG("ap_firmware"))` | port B = fetch |
| u_timer | Ibex `timer` | |
| u_host | `tlul_adapter_host #(.MAX_REQS(2), .EnableDataIntgGen(1), .EnableRspDataIntgCheck(0))` | req/gnt/valid/err = scp_data_split's "axi" side (IBX). `instr_type_i = prim_mubi_pkg::MuBi4False`, `user_rsvd_i = '0`, `wdata_intg_i = '0` (regenerated, EnableDataIntgGen = 1) |

a_source glue:

```systemverilog
always_comb begin tl_o = tl_host; tl_o.a_source = AP_SOURCE; end
```

The command integrity does not cover a_source (OT `tlul_pkg.sv:60-65, 150-159`), and the adapter
ignores d_source (OT `tlul_adapter_host.sv` `unused_tl_i_fields`). MAX_REQS = 2 matches the two
same-side requests scp_data_split can issue. If MAX_REQS were 1, `gnt_o = a_ready` would accept
a second request regardless (OT `tlul_adapter_host.sv:117`, assertion only under INC_ASSERT).

Timing: AP accesses to 0x2000_xxxx are IBX (multi-cycle). RAM, timer and ext are BUS1.

### 5.8 soc4_ctrl

```systemverilog
module soc4_ctrl (
  input  logic clk_i, rst_ni,
  input  logic req_i, we_i, input logic [3:0] be_i, input logic [31:0] addr_i, wdata_i,
  output logic rvalid_o, output logic [31:0] rdata_o, output logic err_o,                // BUS1
  output logic [1:0][31:0] cpu_boot_o,  output logic [1:0] cpu_fetch_en_o,  output logic ap_run_o,
  input  logic bfm_sel_i, input logic [1:0] cpu_sleep_i, input logic [1:0] cpu_ld_open_i,
  input  logic [3:0][15:0] hwstat_i
);
```

Registers per 4.4. `rvalid_o <= req_i`; `err_o <= req_i & unmapped`; `rdata_o` registered.
`cpu_boot_o[n][7:0]` is constant 0 and every output is known from reset, so
`ASSERT_KNOWN(IbexBootAddrX)` (`ibex_top.sv:1404`) holds.

### 5.9 The ext-window decode (inside soc4_top)

An Ibex `bus.sv` instance, `u_ext`, with the six devices and masks of 4.2. Each device is BUS1,
so the total latency stays one cycle (`bus.sv` adds none; facts hw d). An unmapped address gets
`decode_err` (rvalid = err = 1) one cycle later. The masks were chosen not to overlap, because
`bus.sv` resolves overlaps silently (last match wins).

---------------------------------------------------------------------------------------------------

## 6. Changes to existing files

Every edit below keeps `pmu_top` and the 34-target regression unchanged. The 34 targets are the
28 of `build/regress/run_regress.sh` plus scprpmi, scprpmihw, scpdpwr, scpdpwrpa, acg and acgpd;
baseline counts are in `build/merge/merge_notes.md` Section 5. acgpdpa always runs xrun
and fails on CUMSTS. That predates this work and is not in the set. "pmu identical" means the
pmu_tb elaboration has the same instances and behaviour.

### 6.1 Item 11: how soc4 gets the TL-UL mailbox without breaking pmu_top

Options considered:

| Option | Edits now | pmu_top risk | Later deletion |
|---|---|---|---|
| A. Move the mailbox out of scp_top. scp_top exports the doorbell AXI path and the RpmiMem slot; each top instantiates its own mailbox | scp_top (-40/+40 lines of ports) and pmu_top (+60 lines) | pmu_top rewired | scp_top keeps an AXI doorbell port that soc4 does not use: a second cleanup |
| B. Two mailbox kinds inside scp_top, selected by a parameter, with TL-UL ports on scp_top | scp_top grows TL-UL ports and tlul_pkg types | every pmu target must compile tlul_pkg and the TL-UL closure (Makefile change for 34 targets) | remove the AXI kind |
| **C. (chosen)** scp_top parameter `RPMI_MBOX` (default 1 = today) plus one input `irq_ext_i`. With `RPMI_MBOX = 0` the internal mailbox and its split are not elaborated, and soc4 hangs its own `soc4_mbx` on the ext window | scp_top: about 30 lines. pmu_top: none. Makefile pmu section: none | none: pmu_top's elaboration takes the `RPMI_MBOX = 1` branch, which is today's code unchanged, and `irq_ext_i` reaches nothing | delete the `RPMI_MBOX = 1` branch, `s_ap_axi_*` and the parameter (Section 12) |

Why C: it is the least churn. pmu_top and its Makefile file lists stay unchanged. The edit is
confined to one generate block in scp_top. The VCS check of Section 1.5 shows that the
unselected branch needs no module definition, so soc4 compiles neither `scp_rpmi_mbox.sv` nor
any PULP mailbox file. Decision 10's "pulp mailbox_unit, axi_lite_xbar, axi_lite_to_axi and
axi_to_mem leave the mailbox path" therefore holds for soc4 from day one. It is the SCP's private
bus.sv (through the ext window) that reaches the doorbell, firewall and queue memory, as
decision 10 requires.

**EDIT `pmu/rtl/scp_top.sv`:**

1. Parameter list (`:77-80`): add
   `parameter bit RPMI_MBOX = 1'b1   // 1: scp_rpmi_mbox inside (pmu_top); 0: the mailbox is outside, on ext (soc4)`.
2. Ports (after `:138`): add
   `input logic irq_ext_i,   // RPMI_MBOX = 0 only: the external mailbox's doorbell level -> irq_external`.
3. Replace `.irq_external_i(|db_irq)` (`:209`) with `.irq_external_i(irq_ext)` and add
   ```systemverilog
   logic irq_ext;
   if (RPMI_MBOX) begin : g_irq_int  assign irq_ext = |db_irq;  end
   else           begin : g_irq_ext  assign irq_ext = irq_ext_i; end
   ```
   In pmu_top `irq_ext_i` is left unconnected. With `RPMI_MBOX = 1` the selected branch never
   reads it, so the floating input cannot reach Ibex's `ASSERT_KNOWN` on the interrupts.
4. Wrap `u_split_rpmi` (`:275-308`), `u_axi_rpmi` and `u_rpmi` (`:440-536`) in
   `if (RPMI_MBOX) begin : g_rpmi ... end`. Add
   ```systemverilog
   else begin : g_no_rpmi
     // loc_* straight to bus_*: 0x0003_0xxx now decodes as unmapped in bus.sv
     assign bus_req = loc_req;  assign bus_we = loc_we;  assign bus_be = loc_be;
     assign bus_addr = loc_addr; assign bus_wdata = loc_wdata;
     assign loc_gnt = bus_gnt;  assign loc_rvalid = bus_rvalid;
     assign loc_rdata = bus_rdata; assign loc_err = bus_err;
     // DevRpmiMem slot: BUS1 error responder
     always_ff @(posedge clk_i or negedge rst_ni)
       if (!rst_ni) rpmi_err_q <= 1'b0; else rpmi_err_q <= dev_req[DevRpmiMem];
     assign dev_rvalid[DevRpmiMem] = rpmi_err_q;  assign dev_err[DevRpmiMem] = rpmi_err_q;
     assign dev_rdata[DevRpmiMem]  = '0;
     assign db_irq = '0;
     assign s_ap_axi_awready = 1'b0; assign s_ap_axi_wready = 1'b0; assign s_ap_axi_bvalid = 1'b0;
     assign s_ap_axi_bresp = '0; assign s_ap_axi_arready = 1'b0; assign s_ap_axi_rvalid = 1'b0;
     assign s_ap_axi_rresp = '0; assign s_ap_axi_rdata = '0;
   end
   ```
5. Header comment: memory map and interrupt map for both settings.
6. `scp_core` instance (`:187`): `scp_core u_core (... .boot_addr_i(BOOT_ADDR) ...)` (6.2).

Regression effect: none. All pmu_tb targets build scp_top with the default `RPMI_MBOX = 1`.

Two side effects, checked:

- The generate renames the mailbox instances from `u_scp.u_rpmi` (and `u_split_rpmi`,
  `u_axi_rpmi`) to `u_scp.g_rpmi.u_rpmi` etc. Nothing references them by path. A grep of `src/`
  for `u_rpmi|u_split_rpmi|u_axi_rpmi` outside scp_top.sv finds only comments
  (`pmu_top.sv:11`, `upf/pmu_top.upf:62`), and pmu_top.upf puts them in PD_TOP through
  `-elements {.}`, not by name.
- In pmu_top `irq_ext_i` stays unconnected. That is at most a lint warning (VCS TFIPC under
  `+lint`), not an error, and the selected generate branch never reads it.

### 6.2 EDIT `pmu/rtl/scp_core.sv` (decision 5)

- Remove `parameter logic [31:0] BOOT_ADDR` (`:118-120`). Keep `HART_ID`.
- Add the port `input logic [31:0] boot_addr_i,   // sampled at reset release (ibex_controller.sv:580-593); [7:0] must be 0`.
- `:211` `.boot_addr_i(BOOT_ADDR)` becomes `.boot_addr_i(boot_addr_i)`.
- Header: the reset PC is `{boot_addr_i[31:8], 8'h80}`.

scp_top is the only instantiation (grep). `ibexlint` elaborates scp_core as the top, so the new
port is a top-level port there. ibexlint needs Xcelium and is not in the 34. Regression effect:
none, because scp_top ties the port to its BOOT_ADDR parameter (default 0, as before).

### 6.3 EDIT `pmu/rtl/scp_ram.sv`

- Add `parameter string IMAGE_PLUSARG = "firmware"` (`:34-35`).
- `:100` `$value$plusargs("firmware=%s", path)` becomes
  `$value$plusargs({IMAGE_PLUSARG, "=%s"}, path)`. The messages at `:102`, `:104` print
  IMAGE_PLUSARG.

This removes facts hazard 22 (two scp_ram instances loading one image). Default unchanged, so the
regression is unaffected.

### 6.4 EDIT `tb/pmu/scp_sim_ctrl.sv`

- Add `parameter string TAG = "fw"` (`:51-53`).
- `:200` (`$display("[%0t] fw| %s", ...)`) becomes `$display("[%0t] %s| %s", $time, TAG, line)`.

Default unchanged, so every "fw|" grep in the Makefile still matches.

### 6.5 Firmware edits (shared files; pmu images byte-identical)

Every edit below is preprocessor-only. Without `soc4_plat.h` force-included, each file
preprocesses to exactly what it is today, so **every pmu image is byte-identical** (the user's
decision of revision 2). `hal/ppu_v1.c` and `hal/ppu_v1.h` are not touched.

| File | Edit | pmu effect |
|---|---|---|
| `pmu/fw/hal/scp_regs.h:65` | `#ifndef SCP_NUM_PPU` / `#define SCP_NUM_PPU 12u` / `#endif` | byte-identical |
| `pmu/fw/mod/pd.c:57-64` | `#ifdef PD_PLAT_TAB` `struct pd pd_tab[PD_COUNT] = { PD_PLAT_TAB };` `#else` (the 12 entries) `#endif` | byte-identical |
| `pmu/fw/rpmi/scp_rpmi.h:106` | `#ifndef SCP_DPWR_COUNT` / `#define SCP_DPWR_COUNT 8u` / `#endif` | byte-identical |
| `pmu/fw/rpmi/scp_rpmi.c` | four `#ifdef SCP_PLAT_SOC4` blocks: (0) the SYSTEM_RESET table, `sysreset_do` and `sysreset_ops` (`:14-28`) compiled out; (1) `dpwr_data` (`:34-37`) = `SCP_PLAT_DPWR_DATA` ({0,"CPU0"}, {0,"CPU1"}, {0,"ACC0"}, {0,"ACC1"}); (2) in `scp_rpmi_init` (`:188`) the transport loop runs for t = 0 only (`ctx[1]` stays NULL; `scp_rpmi_drain` returns DRAINED for it, `:166`; `rpmi_context_process_all_events(NULL)` returns, facts fw e); (3) `:202-207`: no SYSTEM_RESET group, DEVICE_POWER on `ctx[SCP_T0A]` | byte-identical |

**Retention RAM registers: a soc4-only helper, not a driver change.** With the decision-2
configuration, CPU0 has only PPU_FULRR and ACC0 only PPU_MEMRR. `ppu_set_ret_ram` writes nothing
unless all three registers are present (`hal/ppu_v1.c:224-231`, `ret_ram_regs` at `:72`), so
`pd_init`'s call (`mod/pd.c:176`) returns PPU_E_UNSUPPORTED on soc4 and writes nothing (the return
is ignored, so this is harmless). Both registers would keep their reset value 0x00
(`ppu_regs.sv:389-391`), and the PCSM would shut the banks down in FULL_RET/MEM_RET
(`ppu_pcsm.sv:657-658`). The soc4 SCP images therefore call, right after `pd_init`:

```c
/* src/soc4/fw/mod/soc4_ret.c (NEW, soc4 images only). DEN Table 5-27: IDR1 b6 FUNRR, b5 FULRR,
   b4 MEMRR are separate presence bits (spec:5662-5676). Program each present register; a
   reserved one is never written. Before the first entry into the mode, while the PPU is idle. */
void soc4_ret_ram(uint8_t funrr, uint8_t fulrr, uint8_t memrr)
{
  for (unsigned d = 0; d < PD_COUNT; d++) {
    const struct ppu *p = &pd_tab[d].ppu;
    if (p->idr1 & (1u << 6)) ppu_wr(p, PPU_FUNRR, funrr);
    if (p->idr1 & (1u << 5)) ppu_wr(p, PPU_FULRR, fulrr);
    if (p->idr1 & (1u << 4)) ppu_wr(p, PPU_MEMRR, memrr);
  }
}
```

It uses only the driver's raw accessors `ppu_rd`/`ppu_wr` (`hal/ppu_v1.h:123-124`) and the IDR1
copy `ppu_probe` keeps in `struct ppu` (`:111`). `soc4_scp` calls `soc4_ret_ram(0xFF, 0xFF,
0xFF)`, and soc4stress calls it with its test masks (`PCSM.RAM`). The driver's all-or-nothing
reading of IDR1 b4-b6 (`ppu_v1.c:38, 72`) is recorded as a finding for whoever next changes the
driver. No pmu image needs the fix.

Not edited, and why:

- `rpmi/scp_loop.c`, `hal/rpmi_db.h`: soc4 keeps `SCP_NUM_XPORT = 2` and `RPMI_DB_COUNT = 2`.
  Its doorbell backend reports only bit 0 (T0a), so the static assert at `scp_loop.c:7-8` and
  `scp_loop_init`'s `rpmi_db_set_mask(0)` (`:19`) work as they are.
- `mod/policy.c`/`.h`: W4.1's policy is built on dynamic RUN and locked OFF (`policy.c:131, 160,
  271`) and on 8 domains offset by PD_DSP0 (`policy.h:99-100`). soc4's static policy is a
  separate module (9.4). Changing policy.c would put the 452/531 checks of rpmi_dpwr at risk for
  no gain.
- `crt0.S`, `link.ld`, `bin2vmem.py`, `lib/*`, `hal/{timer,trap,csr,sim}.*`: reused as they are.
- `pmu/fw/Makefile`: soc4 firmware has its own Makefile in `src/soc4/fw/`. Its sources are not
  under `pmu/fw/test`, so the `PROGS` wildcard (`pmu/fw/Makefile:96`) does not pick them up
  (facts fw hazard 17).

### 6.6 EDIT `src/Makefile` (additive)

A new section after the pmu section. It adds no change to any existing variable.

```make
# ---- soc4: 4-domain PPU + SCP platform (src/soc4, SOC4_DESIGN.md) ----
SOC4      := $(SRC)/soc4
SOC4_FW   := $(SOC4)/fw
SOC4_OUT  := $(BUILD)/fw/soc4
OT_TLUL   := $(OT)/top/top_pkg.sv $(OT)/prim/prim_count_pkg.sv $(OT)/tlul/tlul_pkg.sv \
  $(addprefix $(OT)/prim/,prim_secded_inv_64_57_enc.sv prim_secded_inv_64_57_dec.sv \
     prim_secded_inv_39_32_enc.sv prim_secded_inv_39_32_dec.sv prim_sec_anchor_buf.sv \
     prim_count.sv prim_fifo_sync_cnt.sv prim_fifo_sync.sv) \
  $(addprefix $(OT)/tlul/,tlul_data_integ_enc.sv tlul_data_integ_dec.sv tlul_cmd_intg_gen.sv \
     tlul_cmd_intg_chk.sv tlul_rsp_intg_gen.sv tlul_rsp_intg_chk.sv tlul_err.sv tlul_err_resp.sv \
     tlul_fifo_sync.sv tlul_socket_1n.sv tlul_sram_byte.sv tlul_adapter_sram.sv \
     tlul_adapter_reg.sv tlul_adapter_host.sv)
SOC4_RTL  := $(addprefix $(SOC4)/rtl/,soc4_cpu_ram.sv soc4_cpu_adp.sv soc4_cpu_dom.sv \
     soc4_acc_dom.sv soc4_ctrl.sv soc4_mbx.sv soc4_ap.sv soc4_top.sv)
# top_pkg first (tlul_pkg needs it); Ibex's prim packages (IBEX_SRCS) before tlul_pkg
SOC4_SRCS := $(OT)/top/top_pkg.sv $(SCP_SRCS) $(filter-out $(OT)/top/top_pkg.sv,$(OT_TLUL)) \
     $(PPU_SRCS) $(PULP_DIR)/tech_cells_generic/tc_sram.sv \
     $(IBEX)/shared/bus.sv $(IBEX)/shared/timer.sv \
     $(addprefix $(PMU_RTL)/,scp_ram.sv scp_data_split.sv scp_axi_lite_master.sv \
        scp_axi_lite_demux.sv scp_top.sv) \
     $(SOC4_RTL) $(TB)/ppu/ppu_power_model.sv $(TB)/pmu/scp_sim_ctrl.sv \
     $(OT)/tlul/tlul_assert.sv $(TB)/soc4/soc4_tb.sv
SOC4_FLAGS := +incdir+$(OT)/prim +incdir+$(OT)/dv_utils
SOC4_DIR  := $(call SIM_DIR,soc4_tb)
```

Targets: `soc4fw soc4 soc4bfm soc4stress soc4neg soc4pa soc4bfmpa soc4stresspa` (Section 11).
They are added to `.PHONY` and to the header comment block. Every one requires `SIM=vcs`, through
a `soc4simcheck` that refuses other simulators: the UPF flavour is VCS's, and Xcelium is
expired. `-licqueue` comes in through `VCSFLAGS`, as in `run_regress.sh`. The section adds
nothing to the pmu file lists, so the 34 targets compile exactly what they compile today.

### 6.7 Other edits

- `vendor/opentitan/README.md`: Section 7.3.
- `build/regress/run_regress.sh` is not edited until Section 12. soc4 targets are run with
  `TARGETS="soc4 soc4bfm soc4stress soc4neg soc4pa soc4bfmpa soc4stresspa"` (the 7 soc4
  targets) passed in the environment.

---------------------------------------------------------------------------------------------------

## 7. Vendoring (OpenTitan TL-UL)

### 7.1 Files

Source: lowRISC/opentitan, revision `16e86c9e031d52760780ac4efddaab2389bdb94b`. This is the
revision `vendor/opentitan/README.md` already records, and that of the local clone
(`git log -1`: `16e86c9e03 [dif,uart] ...`). Licence Apache-2.0. Every file keeps its header,
and `vendor/opentitan/LICENSE` already exists. Each file is copied verbatim and compared byte for
byte with the clone.

The list comes from `build/sw/mbx-survey/scratch/deps.py tlul_socket_1n tlul_adapter_sram
tlul_adapter_reg tlul_adapter_host` ("NEW files 18 lines 3764"), with the instantiations checked
by hand:

| # | Clone path (`hw/ip/...`) | Destination (`src/vendor/opentitan/...`) | Lines | Needed by |
|---|---|---|---:|---|
| 1 | `tlul/rtl/tlul_socket_1n.sv` | `tlul/` | 255 | firewall + 1:2 decode |
| 2 | `tlul/rtl/tlul_adapter_sram.sv` | `tlul/` | 688 | queue memory |
| 3 | `tlul/rtl/tlul_adapter_reg.sv` | `tlul/` | 307 | doorbell |
| 4 | `tlul/rtl/tlul_adapter_host.sv` | `tlul/` | 190 | AP |
| 5 | `tlul/rtl/tlul_fifo_sync.sv` | `tlul/` | 191 | socket FIFOs |
| 6 | `tlul/rtl/tlul_err.sv` | `tlul/` | 99 | both adapters' protocol check |
| 7 | `tlul/rtl/tlul_sram_byte.sv` | `tlul/` | 916 | inside tlul_adapter_sram (pass-through with EnableIntg = 0) |
| 8 | `tlul/rtl/tlul_cmd_intg_gen.sv` | `tlul/` | 58 | AP host |
| 9 | `tlul/rtl/tlul_cmd_intg_chk.sv` | `tlul/` | 53 | adapters (elaborated only if CmdIntgCheck; still referenced) |
| 10 | `tlul/rtl/tlul_rsp_intg_chk.sv` | `tlul/` | 54 | AP host |
| 11 | `tlul/rtl/tlul_data_integ_dec.sv` | `tlul/` | 27 | integrity checkers |
| 12 | `prim/rtl/prim_fifo_sync.sv` | `prim/` | 242 | FIFOs |
| 13 | `prim/rtl/prim_fifo_sync_cnt.sv` | `prim/` | 149 | prim_fifo_sync |
| 14 | `prim/rtl/prim_fifo_assert.svh` | `prim/` | 58 | `include`d by prim_fifo_sync |
| 15 | `prim/rtl/prim_count.sv` | `prim/` | 313 | prim_fifo_sync_cnt |
| 16 | `prim/rtl/prim_count_pkg.sv` | `prim/` | 15 | prim_count |
| 17 | `prim/rtl/prim_secded_inv_39_32_dec.sv` | `prim/` | 62 | data integrity decode |
| 18 | `prim/rtl/prim_secded_inv_64_57_dec.sv` | `prim/` | 87 | command/response integrity decode |
| | **Total** | | **3,764** | |
| TB | `tlul/rtl/tlul_assert.sv` | `tlul/` | 502 | testbench only: OpenTitan's TL-UL protocol checker, bound in soc4_tb at the socket's host port (EndpointType "Device") and at the AP adapter's output (EndpointType "Host"), as OpenTitan's own `mbx_bind.sv` does. It needs only `tlul_pkg`, `top_pkg` and `prim_assert.sv` (all present). Its UVM parts are under `ifdef UVM`, which is never defined here. Its failures print `[ASSERT FAILED]`, which `scp_verdict` already fails on |

Already vendored and reused (no new copy): `top/top_pkg.sv` (TL_AIW = 8 at `:10`), `tlul_pkg.sv`,
`tlul_err_resp.sv`, `tlul_rsp_intg_gen.sv`, `tlul_data_integ_enc.sv`,
`prim_secded_inv_{39_32,64_57}_enc.sv`, `prim_secded_pkg.sv`, `prim_mubi_pkg.sv`,
`prim_util_pkg.sv`, `prim_sec_anchor_buf.sv`, `prim_assert*.sv[h]`, `prim_flop_macros.sv`,
`prim_generic/{prim_buf,prim_flop}.sv`. deps.py marks all of these "have".

Not vendored: the OpenTitan `mbx` IP (DOE mailbox; it brings alerts, a register top and a DMA
host port that soc4 does not need) and `tl_agent` (UVM; README "What was deliberately NOT
taken").

From PULP: `tech_cells_generic/tc_sram.sv` v0.2.9 is already vendored (`vendor/pulp/README.md`).
soc4 uses it for the queue memory and both CPU RAMs.

### 7.2 Compile notes

- All new files `include` only `prim_assert.sv` and `prim_fifo_assert.svh`, both in `prim/`,
  which is on `+incdir`. This is the same prim_assert copy Ibex uses, so there is no `ASSERT macro
  clash (the clash is only with PULP files, `Makefile:1079-1082`).
- Order: `top_pkg`, then (from IBEX_SRCS) `prim_util_pkg`, `prim_mubi_pkg`, `prim_secded_pkg`,
  then `prim_count_pkg`, `tlul_pkg`, then the leaf modules (6.6).
- None of the files has a `timescale`; under VCS it comes from `VCSFLAGS` (`-timescale=1ns/1ps`).
- `acg` and `acgpd` compile their own `OT_SRCS` list (`Makefile:781-791`) and are not affected.

### 7.3 EDIT `vendor/opentitan/README.md`

1. "What is here" table: add a row "`tlul/{tlul_socket_1n, tlul_adapter_sram, tlul_adapter_reg,
   tlul_adapter_host, tlul_fifo_sync, tlul_err, tlul_sram_byte, tlul_cmd_intg_gen,
   tlul_cmd_intg_chk, tlul_rsp_intg_chk, tlul_data_integ_dec}.sv`,
   `prim/{prim_fifo_sync, prim_fifo_sync_cnt, prim_count, prim_count_pkg,
   prim_secded_inv_39_32_dec, prim_secded_inv_64_57_dec}.sv`, `prim/prim_fifo_assert.svh` |
   lowRISC/opentitan | `16e86c9e...` | added 2026-10 for soc4's AP-SCP mailbox".
2. A new subsection "For soc4's mailbox (`src/soc4/rtl/soc4_mbx.sv`, `soc4_ap.sv`)": the
   per-file table of 7.1 with lines, and the closure command
   (`deps.py tlul_socket_1n tlul_adapter_sram tlul_adapter_reg tlul_adapter_host`).
3. The integration rules, stated once: `a_user = tlul_pkg::TL_A_USER_DEFAULT` for any non-adapter
   requester (tlul_err rejects an invalid instr_type); `CmdIntgCheck = 0`;
   `EnableRspIntgGen = 1` on every device the AP's `tlul_adapter_host` reaches (its response
   check is unconditional); TL_AIW = 8; `tlul_adapter_host` has no source parameter, so a fixed
   source is set in glue.
4. A row for the TB-only `tlul/tlul_assert.sv` (502 lines), which is bound in `soc4_tb`.
5. "Nothing has been edited" stays true.

---------------------------------------------------------------------------------------------------

## 8. Power intent

### 8.1 Files

| File | Kind | Content |
|---|---|---|
| `upf/soc4_top.upf` | NEW | UPF 2.1 for `soc4_top`, the model being `upf/pmu_top.upf` |
| `upf/soc4_tb_vcs.upf` | NEW | `upf_version 2.1` / `set_design_top soc4_tb/u_dut` / `load_upf [file join [file dirname [info script]] soc4_top.upf]`. In UPF, set_design_top takes an instance path (decision 15; the pattern of `upf/pmu_tb_vcs.upf:26-30`) |
| `tb/soc4/soc4_pa_supply_vcs.sv` | NEW | the board rails: `pmu_pa_supply_vcs.sv` with the module renamed `soc4_pa_supply_vcs`. It is a second elaboration top: `import UPF::*`, `supply_on("VDD", 0.90)`, `supply_on("VSS", 0.00)`, and `$fatal` if either returns 0 (`tb/pmu/pmu_pa_supply_vcs.sv:14-26`). A separate file, because the pmu one is deleted in Section 12 |

### 8.2 soc4_top.upf

Top level, as `pmu_top.upf:72-90`: supply ports and nets VDD, VSS; `SS_TOP`;
`create_power_domain PD_TOP -elements {.} -supply {primary SS_TOP}`; state TOP_ON. PD_TOP holds
scp_top, soc4_ap, soc4_mbx, soc4_ctrl, the ext decode and the AP/BFM mux. They are always-on by
design: the AP must reach the mailbox while every domain is off.

Per domain, two Tcl procedures, with variables prefixed `s4_` because UPF is one Tcl interpreter
(`pmu_top.upf:94-96`). `$d` is the instance (`u_cpu0` etc.) and `$s` the suffix (`_0` etc.):

```tcl
proc s4_common {d s dev_elems {ret 0}} {
  create_supply_net VDD_LOGIC$s
  create_supply_set SS_AON$s -function {power VDD} -function {ground VSS}
  create_supply_set SS_DEV$s -function [list power VDD_LOGIC$s] -function {ground VSS}
  create_power_domain PD_AON$s -elements [list $d] -supply [list primary SS_AON$s]
  if {$ret} {
    create_supply_net VDD_RET$s
    create_supply_set SS_RET$s -function [list power VDD_RET$s] -function {ground VSS}
    create_power_domain PD_DEV$s -elements $dev_elems -supply [list primary SS_DEV$s] \
      -supply [list retention SS_RET$s]          ;# as pmu_top.upf:115-118
  } else {
    create_power_domain PD_DEV$s -elements $dev_elems -supply [list primary SS_DEV$s]
  }
  create_power_switch SW_LOGIC$s -domain PD_DEV$s -input_supply_port {VIN VDD} \
    -output_supply_port [list VOUT VDD_LOGIC$s] -control_port [list SW_ON $d/u_dom/u_pd/u_pcsm/logic_on] \
    -on_state {logic_on VIN {SW_ON}} -off_state {logic_off {!SW_ON}} -supply_set SS_AON$s
  add_power_state SS_AON$s -supply -state {AON_ON -supply_expr {(power == {FULL_ON 0.90}) && (ground == {FULL_ON 0.00})} -simstate NORMAL}
  add_power_state SS_DEV$s -supply \
    -state {DEV_ON  -supply_expr {(power == {FULL_ON 0.90}) && (ground == {FULL_ON 0.00})} -simstate NORMAL} \
    -state {DEV_OFF -supply_expr {(power == {OFF}) && (ground == {FULL_ON 0.00})} -simstate CORRUPT}
  set_isolation ISO_DEV$s -domain PD_DEV$s -applies_to outputs -isolation_supply_set SS_AON$s \
    -clamp_value 0 -isolation_signal $d/u_dom/u_pd/u_ppu/dev_isolaten -isolation_sense low -location parent
}
```

| Domain | PD_DEV elements | Retention |
|---|---|---|
| CPU0 (`u_cpu0`, `_0`) | `u_cpu0/u_core`, `u_cpu0/u_dom/u_pd/u_clkctrl` | **yes**: `s4_common u_cpu0 _0 {...} 1` creates `VDD_RET_0`, `SS_RET_0` and PD_DEV_0 with `-supply {retention SS_RET_0}`; then `SW_RET_0` controlled by `u_cpu0/u_dom/u_pd/u_pcsm/logic_ret`; states RET_ON/RET_OFF (CORRUPT); `set_retention RET_CPU0 -domain PD_DEV_0 -elements {u_cpu0/u_core} -retention_supply_set SS_RET_0 -save_signal {u_cpu0/u_dom/u_pd/u_pcsm/ret_n negedge} -restore_signal {u_cpu0/u_dom/u_pd/u_pcsm/ret_n posedge}` (the whole core, decision 5). PD_AON_0 states PM_RUN, PM_FULL_RET, PM_DOWN, as `pmu_top.upf:157-163` |
| CPU1 (`u_cpu1`, `_1`) | `u_cpu1/u_core`, `u_cpu1/u_dom/u_pd/u_clkctrl` | no retention rail. PD_AON_1 states PM_RUN, PM_DOWN |
| ACC0 (`u_acc0`, `_2`) | `u_acc0/u_ip/u_core`, `u_acc0/u_ip/u_ret`, `u_acc0/u_dom/u_pd/u_clkctrl` | none: MEM_RET is "logic OFF, RAM RET" (Table 3-1, spec:575-600). The banks `u_acc0/u_ip/g_bank[*]` stay in PD_AON_2 and are retained by their pins |
| ACC1 (`u_acc1`, `_3`) | as ACC0 | none |

The CPU RAM wrappers (`u_cpuN/u_ram`, with tc_sram), the adapters (`u_cpuN/u_adp`) and the
PPU/PCSM (`u_*/u_dom/u_pd` minus u_clkctrl) are in PD_AON_n. The RAM arrays are therefore on the
always-on rail, and only the PCSM pins decide retention (`ppu_ip_sram.sv:6-25`).

Isolation consequences, checked: outputs of PD_DEV clamp to 0. For a CPU these are `instr_req`,
`data_req` (no access), `core_sleep_o` (0 means not asleep, so the adapter denies; this matters
only outside ON, where no Q-Channel request is made) and `dev_clk` from u_clkctrl (0: the RAM
wrapper's CPU-side flops see no edge). For an ACC: `busy` (0). The inputs to PD_DEV
(`boot_addr_i`, `fetch_en_i`, `wake_irq_o`, resets) come from always-on logic and need no
isolation.

### 8.3 Supplies, build and run

`vcs $(VCSFLAGS) -top soc4_tb -top soc4_pa_supply_vcs +define+SOC4_PA -upf $(UPF)/soc4_tb_vcs.upf
... $(SOC4_SRCS) $(TB)/soc4/soc4_pa_supply_vcs.sv`, into `$(BUILD)/vcs_pa/soc4_tb`. This is the
pattern of `scppdpa` (`Makefile:1257-1268`).

### 8.4 How "zero low-power checker errors" is proven

1. **The gate.** The log is grepped as scppdpa does, and the target *fails* unless
   `grep -cE "\[ERROR\] \[LP_[A-Z0-9_]+\]" log` is 0. Today scppdpa only counts LP errors and
   does not fail on them (facts hw k, hazard 25). The per-kind summary
   (`grep -oE "\[(ERROR|WARNING)\] \[LP_[A-Z0-9_]+\]" | sort | uniq -c`) is printed as well.
2. **The intent is live, not just quiet.** Under `SOC4_PA` the TB queries the supply nets through
   the IEEE 1801 SystemVerilog `UPF` package. At every CHECK it requires that
   `VDD_LOGIC_n` is off exactly when the mode removes logic power (OFF, MEM_RET, FULL_RET), and
   that `VDD_RET_0` is on in CPU0 FULL_RET. These are supply nets, not registers inside the
   domain, so decision 14's rule holds. The call is
   `UPF::get_supply_on_state(UPF::get_supply_value("VDD_LOGIC_1"))`, with the net name relative
   to the UPF design top `soc4_tb/u_dut`. The reviewer's trial (`build/soc4_review/upf/d.sv`) shows
   it works under VCS W-2024.09-SP2 and follows the switch. As a second, independent signal, the
   target also requires at least one `[INFO] [LP_PSW_OSP_STATE]` line per `SW_LOGIC_n` reporting
   `FULL_ON to OFF` (the trial's `vcs_lpmsg.log` format).
3. **Behavioural evidence that cannot pass without the intent.** Under CORRUPT, CPU0's register
   signature survives FULL_RET only through `set_retention RET_CPU0` (soc4 check
   `[chk:FULLRET_REGS]`). CPU1 and the ACCs must reboot or reinitialise from reset after OFF
   (`[chk:CPU1_RESTART]`). The RAM checks are pin-driven and run identically with and without UPF.
4. The verdict also needs `RESULT: PASS` and no `ASSERT FAILED` (`scp_verdict`).

Known VCS NLP point to watch: CPU0's retained core contains Ibex's `prim_clock_gating` latch and
flops without reset (facts hw hazard 17). If NLP reports retention-strategy warnings on the
latch, they are recorded with the run. Errors fail the gate.

---------------------------------------------------------------------------------------------------

## 9. Firmware

### 9.1 Images and build

There are three images (decision 12). The CPU image is embedded only in the SCP images.

| Image | Runs on | Loaded by | Sources |
|---|---|---|---|
| `soc4_scp` | SCP | `+firmware=$(SOC4_OUT)/soc4_scp.vmem` | product server: 9.2 list + `scp/main.c` |
| `soc4_stress` | SCP | `+firmware=.../soc4_stress.vmem` | 9.2 list (no librpmi, no policy) + `test/soc4_stress.c` |
| `soc4_ap` | AP | `+ap_firmware=.../soc4_ap.vmem` | `ap/*` + librpmi transport subset |
| `cpu` | CPU0 and CPU1 | the SCP, through the load ports | `cpu/cpu.S`, `cpu/cpu.ld` -> `cpu.bin` (padded to 4096 B), incbin'd by `cpu/cpu_img.S` |

New directory `src/soc4/fw/` (NEW). Its own Makefile, invoked by `make soc4fw` as
`$(MAKE) -C $(SOC4_FW) OUT=$(SOC4_OUT)`:

```
src/soc4/fw/
  Makefile
  soc4_plat.h            force-included into every SCP-side compile (-include)
  hal/soc4_regs.h        4.1-4.7 constants (ext map, soc4_ctrl, mailbox regs, AP map, CPU layout, SOC4_AP_SOURCE 0x10)
  hal/soc4_db.c          rpmi_db.h backend for the TL-UL doorbell (9.3)
  mod/soc4_policy.[ch]   DEVICE_POWER policy for static-only PPUs (9.4)
  mod/soc4_cpu.[ch]      CPU image load and boot control (9.5)
  mod/soc4_ret.[ch]      retention RAM registers from IDR1 (6.5)
  scp/main.c             soc4_scp: boot order (9.6) then scp_loop_run()
  test/soc4_stress.c     soc4stress SCP program (11.3)
  ap/ap_main.c           soc4 AP test program (9.8)
  ap/ap_rpmi.[ch]        AP RPMI client over librpmi's transport (9.7)
  ap/ap_env.c            rpmi_env_* for the AP (arena 256 B)
  cpu/cpu.S cpu/cpu.ld cpu/cpu_img.S
```

Flags: those of `pmu/fw/Makefile:73-84`, unchanged: `-march=rv32imc_zicsr_zifencei -mabi=ilp32
-mcmodel=medany -Os -g -std=gnu11 -ffreestanding -nostdlib -nostartfiles
-fno-tree-loop-distribute-patterns ... -ffunction-sections -fdata-sections`, and
`-Wl,--gc-sections -Wl,--orphan-handling=error`. The CPU image uses `cpu/cpu.ld` (one region,
`ram ORIGIN 0 LENGTH 4K`; asserts `_reset_vector == 0x80` and that the end of the image is at or
below 0xC00). `cpu.bin` is padded with zeros to exactly 4096 B, so the SCP's copy defines every
word. tc_sram's X initial value would otherwise trip Ibex's `IbexInstrRPayloadX` when it
prefetches past the code (facts hw hazard 14).

Per-image source lists. "Linking only what an image uses" (decision 12) is enforced by explicit
lists, with no wildcards over `pmu/fw/hal` or `pmu/fw/mod`:

| Set | Files |
|---|---|
| BASE (every SCP image) | `pmu/fw/crt0.S`, `pmu/fw/lib/{console,string}.c`, `pmu/fw/hal/{ppu_v1,timer,trap}.c`, `pmu/fw/mod/pd.c` |
| RPMI (soc4_scp) | LR `lib/{rpmi_shmem,rpmi_transport,rpmi_transport_shmem,rpmi_context,rpmi_service_group_device_power,rpmi_service_group_sysmsi}.c` (no sysreset). sysmsi is required: `rpmi_context.c:412-414` calls `rpmi_service_group_sysmsi_inject_p2a` unconditionally at link level (it is guarded at run time by `cntx->sysmsi_group`, which soc4 leaves NULL), and pmu's RPMI_SRCS link it for the same reason (`pmu/fw/Makefile:100-102`). Then `pmu/fw/port/rpmi_env.c`, `pmu/fw/rpmi/{scp_rpmi,scp_loop}.c`, `hal/soc4_db.c`, `mod/soc4_policy.c`, `mod/soc4_cpu.c`, `mod/soc4_ret.c`, `cpu/cpu_img.S`, `scp/main.c` |
| STRESS (soc4_stress) | BASE + `mod/soc4_cpu.c`, `mod/soc4_ret.c`, `cpu/cpu_img.S`, `test/soc4_stress.c` |
| AP (soc4_ap) | `pmu/fw/crt0.S`, `pmu/fw/lib/{console,string}.c`, `pmu/fw/hal/{trap,timer}.c`, LR `lib/{rpmi_shmem,rpmi_transport,rpmi_transport_shmem}.c`, `ap/{ap_main,ap_rpmi,ap_env}.c` |

`rpmi_service_group_sysreset.c` is not linked: the 6.5 `#ifdef SCP_PLAT_SOC4` compiles out
scp_rpmi.c's sysreset table, ops and group creation, the only references to it. The block must
cover all three, or the link fails with an undefined `rpmi_service_group_sysreset_create`.

`soc4_plat.h` (all SCP-side compiles, `-include $(SOC4_FW)/soc4_plat.h`):

```c
#define SCP_PLAT_SOC4   1
#define SCP_NUM_PPU     4u            /* scp_regs.h guard (6.5) */
#define SCP_DPWR_COUNT  4u            /* scp_rpmi.h guard */
#define SCP_PLAT_DPWR_DATA { {0,"CPU0"}, {0,"CPU1"}, {0,"ACC0"}, {0,"ACC1"} }
#define PD_PLAT_TAB \
  { .name = "CPU0", .kind = PD_KIND_CPU }, { .name = "CPU1", .kind = PD_KIND_CPU }, \
  { .name = "ACC0", .kind = PD_KIND_DSP }, { .name = "ACC1", .kind = PD_KIND_DSP }
```

`pd.h`'s 12-name enum stays. soc4 code indexes domains by DOMAIN_ID 0-3 and does not use the
names. `pd_boot` and the `pd_state` paths are not called; `--gc-sections` drops them.

### 9.2 Platform abstraction (decision 12) and the path after the deletion

| Layer | Shared with pmu now | soc4-only now | After the Section 12 commit |
|---|---|---|---|
| PPU driver `hal/ppu_v1` | yes, **untouched** | retention RAM through `mod/soc4_ret.c` (6.5) | unchanged (optionally the IDR1 fix of 15.2-21, then the helper goes) |
| Domain manager `mod/pd` | yes: `pd_init`, `pd_poll`, `pd_request_static`, `pd_advance`, `pd_on_ppu_irq`, `pd_tick`, `pd_complete`, `pd_wait_mode`, `pd_busy` | table via `PD_PLAT_TAB` | 12-entry table, `pd_boot` and the dynamic/locked tuples deleted; the soc4 table becomes the only one |
| RPMI server `rpmi/scp_rpmi`, `scp_loop` | yes | `SCP_PLAT_SOC4` blocks | the `#else` (T0b, SYSTEM_RESET, 8 domains) deleted; `SCP_NUM_XPORT` may drop to 1 together with `rpmi_db.h` |
| Policy | `mod/policy.c` (W4.1) serves pmu only | `soc4/fw/mod/soc4_policy.c` | `git mv` soc4_policy.[ch] to `pmu/fw/mod/policy.[ch]`, replacing W4.1's, plus `agate*` deleted |
| Doorbell backend | `hal/rpmi_db_hw.c` (mailbox_unit), `rpmi_db_poll.c` (loopback) | `soc4/fw/hal/soc4_db.c` | the first two deleted; soc4_db.c moved to `pmu/fw/hal/` |

This keeps every pmu image byte-identical now (preprocessor branches only; stage S2 checks it with
`cmp`). The deletion then becomes removals and moves, not rewrites.

### 9.3 Doorbell backend `hal/soc4_db.c` (implements `hal/rpmi_db.h:52-56`)

| Function | Behaviour |
|---|---|
| `rpmi_db_init` | clear `mie.MEIE`; `db_mask = RPMI_DB_ALL`; write `DB_CLEAR = 1`; `trap_ext_pending = 0` |
| `rpmi_db_status` | `(mmio_read32(SOC4_MBX_DB_STATUS) & 1)` -> bit 0 (T0a). Bit 1 (T0b) is always 0 |
| `rpmi_db_clear(bits)` | if bit 0: write `DB_CLEAR = 1`; `trap_ext_pending = 0`; re-arm MEIE if bit 0 is unmasked |
| `rpmi_db_set_mask(mask)` | `db_mask = mask & RPMI_DB_ALL`; MEIE = !(mask bit 0). Bit 1 ignored (no hardware) |
| `rpmi_db_polled` | false |

The doorbell has no enable register. The SCP masks it with `mie.MEIE` alone, and the AP has no
way to clear or mask it (decision 10). `trap_external` (`hal/trap.c:83-88`) clears MEIE and sets
a flag; the handlers only set flags (decision 12).

### 9.4 The policy `mod/soc4_policy.[ch]`

Derived from W4.1's `mod/policy.c`, with the same hooks and loop contract
(`policy.h:10-17`): `scp_rpmi_hooks.dpwr_vote = soc4_policy_vote`;
`scp_loop_hooks.work = soc4_policy_work`; `.deadline = soc4_policy_deadline`. librpmi is called
only from the main loop. The vote hook runs inside librpmi's synchronous `set_state` (LR
`include/librpmi.h:1652-1665`), as in W4.1.

Configuration (per domain, `const`):

```c
struct s4_dom { uint8_t pd; uint8_t lp; bool cpu; uint8_t cpu_idx; };
static const struct s4_dom s4_dom[4] = {
  { 0, PPU_MODE_FULL_RET, true,  0 },   /* CPU0 */
  { 1, PPU_MODE_OFF,      true,  1 },   /* CPU1 */
  { 2, PPU_MODE_MEM_RET,  false, 0 },   /* ACC0 */
  { 3, PPU_MODE_OFF,      false, 0 },   /* ACC1 */
};
```

Timing config: W4.1's `policy_cfg` with the same defaults (`policy.c:19-25`): on_ticks 1 ms,
step_ticks 1 ms, hyst_ticks 1 ms, backoff 100 us (doubled per retry), retry_cap 3. A new field
`recover_tries = 3` (N in decision 9). One tick is one SCP cycle (`policy.h:102-106`).

States: `S4_LP` (static LP mode, or OFF before the first ON), `S4_ON` (static ON), `S4_HYST`,
`S4_PREP` (static ON, PWR_DEVACTIVEEN cleared), `S4_LPREQ`, `S4_BACKOFF`, `S4_FORCE`, `S4_FAULT`.
Per-domain RAM: `{state, vote, retries, recover, err, up, faulted, at, counters ons, offs,
cancels, denials, forced, faults, gaveup, recoveries}`, about 48 B.

**ON** (`vote_on`, synchronous, bounded by on_ticks; replies only when PWSR shows ON):

1. *Cancel*: `state == S4_HYST && up && !pd_busy(d)` -> `S4_ON`, vote ON, cancels++, and
   **no PPU access** (decision 8.2). `up` is set only when static ON was reached, so a HYST entered
   from FAULT never cancels.
2. `until = now + on_ticks`. If `going_down(p)` (W4.1 `policy.c:103-109`: a static policy below
   PWSR), `pd_wait_mode(d, to, left(until))`; DENIED counts as OK. A PPU transition cannot be
   interrupted (PPU 4.1.1). A timeout here is a failure (step 7).
3. **Classify, before any write** (review fix 7). Read PWSR once:
   `warm = cpu && !faulted && PWSR.STATUS == FULL_RET` (CPU0 only). This must come before step
   4: step 4's static ON would otherwise take a CPU0 left in a *forced* FULL_RET (DEVREQEN = 0) to
   ON first, and the cold path would then destroy its retained state.
4. If `PWCR.DEVREQEN0 == 0` (after a forced entry): `pd_request_static(d, ON)` then
   `ppu_set_devreq_en(p, 1)`. Re-enabling is allowed only from ON reached under a static policy
   (PPU 4.1.3, spec:2688-2692; `ppu_v1.c:176-187`). For a warm CPU0 this static ON *is* the warm
   resume.
5. The sequence for the class:
   - **warm**: `pd_request_static(d, ON)` (already reached if step 4 ran). After a handshaked
     entry the adapter's wake pulse (5.5) ends the WFI. After a forced entry the core resumes
     where it was frozen.
   - **cold CPU** (`cpu && !warm`): Section 9.5 steps 1-6, including step 1 `FETCH_EN = 0`. If
     step 4 already brought the domain to ON, 9.5 step 2 is reached at once.
   - **ACC**: if `faulted`, static ON, static WARM_RST, static ON (WARM_RST recovery, no
     handshake). Otherwise static ON (MEM_RET -> ON keeps ACC0's banks; OFF -> ON for ACC1).
   Every step is `run(d, pd_request_static(d, m, left(until)))` (W4.1 `policy.c:81-84`), so the
   whole sequence stays inside the one deadline.
6. Success: `S4_ON`, `up = 1`, `faulted = 0`, `recover = 0`, vote ON, ons++, return
   `RPMI_SUCCESS`.
7. Failure (any rc != OK, including PD_E_TIMEOUT, the deadline): `fault(id, rc)` (below), return
   `RPMI_ERR_HW_FAULT` (= -8, LR `include/librpmi.h:141`). The vote is not recorded
   (`rpmi/scp_rpmi.c:59-64`), so GET_STATE still answers OFF (decision 9).

**fault(id, rc)** is the one entry into `S4_FAULT`, used by both the ON path and the power-off
steps. It sets `faulted = 1`, `err = rc` and faults++. If it was not called by a recovery attempt,
it also sets `recover = recover_tries` (N = 3) and logs `scp: FAULT: DOMAIN_ID %u (%s), will retry
power-off %u times`. Then `at = now + hyst_ticks`. Every fault leaves the AP's vote at OFF: a
failed ON never records ON, and an OFF-side fault happens after the OFF was recorded. So the
policy itself must take the domain down (decision 9), because librpmi will not deliver another
OFF (LR `rpmi_service_group_device_power.c:128-131`).

**OFF** (`vote_off`, returns at once with SUCCESS, decision 8.1): vote OFF. From `S4_ON`:
`S4_HYST`, `at = now + hyst_ticks`. In any other state only the vote is recorded. The only way to
reach vote_off is an ON vote first (librpmi skips an OFF while GET_STATE answers OFF), and every
state other than S4_ON has vote OFF, so in practice vote_off is called from S4_ON alone.

**Power-off steps** (`step`, run to stability by `step_all`, non-blocking, each step bounded by
step_ticks):

| State | Event | Action |
|---|---|---|
| HYST | `at` passed | `retries = 0`. If PWPR == {lp, static} and PWSR == lp: `S4_LP` (nothing to do). Else `pd_request_static(d, ON)` -> PREP. pd clears PWR_DEVACTIVEEN on this request (the deeper path, facts fw c), so a busy device is asked rather than waited for (PPU 3.4.2, 3.4.1) (decision 8.3) |
| PREP / BACKOFF | PREP done OK, or backoff `at` passed | `pd_request_static(d, lp)` -> LPREQ (decision 8.4) |
| LPREQ | PD_E_DENIED | denials++. If `retries < retry_cap`: `at = now + (backoff << retries)`, retries++, BACKOFF (decision 8.5). Else: `ppu_set_devreq_en(p, 0)` (static ON reached: PPU 4.1.3), forced++, `pd_request_static(d, lp)` -> FORCE (decision 8.6) |
| LPREQ / FORCE | OK | `S4_LP`, `up = 0`, offs++. If this ended a recovery: recoveries++, log `scp: DOMAIN_ID %u recovered to %s` |
| FAULT | `recover > 0` and `at` passed | `recover--`. If `going_down(p)` (a hop still stuck, e.g. a device that never quiesces): this attempt fails at once and `fault()` re-arms `at` (as a recovery attempt). Else if PWPR == {lp, static} and PWSR == lp: `S4_LP`, recoveries++ (no PPU write). Else `retries = 0`, `pd_request_static(d, ON)` -> PREP (the normal power-off, flagged as a recovery) |
| FAULT | `recover == 0` (after at least one retry) | stay in `S4_FAULT`; gaveup++ once; log `scp: FAULT: DOMAIN_ID %u gave up after %u power-off retries (err %s)` with the count actually tried (N) |
| any | other error, or PD_E_TIMEOUT (step deadline) | `fault()` (a recovery attempt if the domain was recovering) |

An OFF-side deadline miss changes nothing visible at once. The OFF was answered already, and the
domain is in FAULT with `faulted = 1`. The policy retries the power-off up to N times. It shows
at the next ON, which runs the WARM_RST recovery (ACC) or the cold reload (CPU) and answers
SUCCESS if that completes inside on_ticks (decision 9; 15.2-5).

Steady states: static ON (`S4_ON`) and static LP (`S4_LP`). There is no lock, no dynamic
policy, and no LOCK_EN or PWR_DYN_EN write. Decision 12's LOCK_EN and PWR_DYN_EN rules are met
trivially, and `pd_request_static` still waits on PWR_DYN_STATUS (`pd.c:143-148`).

`soc4_policy_work` = `pd_poll()`; `pd_advance` on busy domains; `step_all()` (W4.1
`policy.c:308-317` without the agate). `soc4_policy_deadline` = `pd_tick()`; `step_all()`; the
earliest `at` of the HYST, BACKOFF and FAULT-with-recover states; and `SCP_LOOP_POLL_TICKS` while
any request is busy (W4.1 `policy.c:319-338`).

Validation in `soc4_policy_vote`: `id >= 4` gives `RPMI_ERR_INVALID_PARAM`. librpmi has already
answered INVALID_PARAM for `id >= count` (LR `rpmi_service_group_device_power.c:300-303` SET,
`:259-262` GET, `:214-217` GET_ATTRIBUTES). The `!dpwr` check at `:119-120` cannot fire
(facts fw g), so these are the effective lines. A state other than ON/OFF gets INVALID_PARAM
in `dpwr_set` (`rpmi/scp_rpmi.c:56-58`).

### 9.5 CPU cold ON and the loader `mod/soc4_cpu.[ch]`

API: `void cpu_fetch(unsigned n, bool en)` (read-modify-write of CPU_FETCH_EN);
`int cpu_load(unsigned n)` (copy the image, write CPUn_BOOT); `const uint32_t cpu_img[1024]`
(from `cpu_img.S`, `.section .rodata.cpu_img`, which link.ld's `*(.rodata .rodata.*)` collects at
`link.ld:38-43`).

The cold sequence inside `vote_on` (decision 6), one deadline for all of it:

| Step | Action | PPU mode after | Core |
|---|---|---|---|
| 1 | `cpu_fetch(n, 0)` | (unchanged) | fetch off |
| 2 | `pd_request_static(d, ON)` | ON | out of reset, fetch off: latches a boot address, then idles |
| 3 | `pd_request_static(d, WARM_RST)` (no handshake: WARM_RST_DEVREQEN = 0, Table 4-4) | WARM_RST | in reset (`dev_ret_rst_n = 0`, 3.2) |
| 4 | `cpu_load(n)`: check `CPU_STAT.ld_open[n]`; copy 1024 words with **word** stores to `0x0002_8000 + n*0x1000` (lib memcpy is byte-wise, `lib/string.c:10-16`, so it is not used); write `CPUn_BOOT = SOC4_CPU_BOOT` (0x0000_0000); `cpu_fetch(n, 1)` | WARM_RST | in reset |
| 5 | `pd_request_static(d, ON)` | ON | reset released: samples boot_addr_i (`ibex_controller.sv:580-593`), fetches at boot + 0x80 |
| 6 | return when PWSR shows ON (pd's raw request needs the exact mode, facts fw c) | ON | running |

The load runs only in step 4, while the PPU is static WARM_RST with PWSR = WARM_RST (5.4 residual
window). A load-port error is an access fault, which `die()`s unless armed
(`hal/trap.c:47-66`). soc4_stress arms it on purpose to test the guard (11.3). Cost: about 1024 x
2 cycles of stores plus loop overhead, about 4k cycles, well inside on_ticks (100k).

CPU0 resume from FULL_RET is step 5 alone (static ON). The core was never reset
(`dev_ret_rst_n = 1` in FULL_RET), and the adapter's wake pulse ends the WFI.

### 9.6 SCP boot (`scp/main.c`, decision 3)

```c
int main(void) {
  con_init();
  /* 1. the PPUs: probe, IMR/AIMR, clear ISR/AISR, retention RAM, entry delay, DCDR, mie lines.
        pd_init does not touch PWPR, so all four stay in OFF (DEF_PWR_POLICY = OFF) */
  if (pd_init() != 4) die_code(SOC4_E_PPU);
  for (unsigned d = 0; d < 4; d++) check_ident(d);   /* 3.3 table incl. DEVCHAN = 1; die on mismatch */
  soc4_ret_ram(0xFF, 0xFF, 0xFF);                     /* 6.5: FULRR on CPU0, MEMRR on ACC0 */
  /* 2. firewall: admit only the AP's a_source */
  mmio_write32(SOC4_MBX_FW_SRC, SOC4_AP_SOURCE);
  mmio_write32(SOC4_MBX_FW_EN, 1);
  /* 3. RPMI: one transport on the TL-UL queue memory, librpmi zeroes it
        (LR lib/rpmi_transport_shmem.c:218-220); BASE + DEVICE_POWER(4), M-mode */
  const uintptr_t shm[SCP_NUM_XPORT] = { SOC4_QMEM_BASE /*0x0002_4000*/, 0 };
  if (scp_rpmi_init(shm, &hooks) != SCP_RPMI_OK) die_code(SOC4_E_RPMI);
  soc4_policy_init(NULL);       /* every domain S4_LP, vote OFF */
  scp_loop_init(&loop_hooks);   /* timer, soc4_db, MEIE */
  /* 4. the AP may start */
  mmio_write32(SOC4_CTRL_AP_RUN, 1);
  scp_loop_run();
}
```

`pd_init`'s own `ppu_set_ret_ram` call (`mod/pd.c:176`) writes nothing on soc4 (6.5). Right
after it, `soc4_ret_ram(0xFF, 0xFF, 0xFF)` writes FULRR = 0xFF on CPU0 and MEMRR = 0xFF on ACC0
and skips the reserved registers. Every bank therefore retains in the LP mode
(the CPU RAM uses bank 0; ACC0 uses all 8). Arena use: one transport 120 + context 240 +
DEVICE_POWER 48 + 4 x 12 = 456 B of the 1024 B arena (`port/rpmi_env.h:56-72`, per-item figures).

### 9.7 AP client (`ap/ap_rpmi.[ch]`)

librpmi's transport is reused unchanged. `rpmi_transport_enqueue` and `rpmi_transport_dequeue`
accept any queue type below RPMI_QUEUE_MAX (LR `lib/rpmi_transport.c:71-124`). The AP enqueues
on `RPMI_QUEUE_A2P_REQ` (0) and dequeues from `RPMI_QUEUE_P2A_ACK` (1) (LR
`include/librpmi.h:164-170`).

```c
static enum rpmi_error ap_rd(void *p, rpmi_uint64_t a, void *in,  rpmi_uint32_t n) { memcpy(in, (void*)(uintptr_t)a, n); return RPMI_SUCCESS; }
static enum rpmi_error ap_wr(void *p, rpmi_uint64_t a, const void *o, rpmi_uint32_t n) { memcpy((void*)(uintptr_t)a, o, n); return RPMI_SUCCESS; }
static enum rpmi_error ap_fill(void *p, rpmi_uint64_t a, char c, rpmi_uint32_t n) { return RPMI_SUCCESS; }  /* no-op: the SCP owns init */
static const struct rpmi_shmem_platform_ops ap_ops = { ap_rd, ap_wr, ap_fill };   /* LR include/librpmi.h:395-407; all three mandatory, rpmi_shmem.c:154 */
```

- Init (after AP_RUN, so the SCP has initialised the queues):
  `rpmi_shmem_create("ap", 0x2000_0000, 1024, &ap_ops, NULL)`;
  `rpmi_transport_shmem_create("ap", 64, 512, 0, sh)`. Its fill (LR
  `rpmi_transport_shmem.c:218-220`) reaches the no-op `ap_fill`, so the SCP's queues are not
  wiped (facts fw hazard 3).
- `ap_call(grp, srv, req, len, rsp, &rlen, tmo)`: build a `struct rpmi_message` (header word 0
  group [15:0] | service [23:16] | flags [31:24], type NORMAL_REQUEST = 0; word 1 datalen [15:0] |
  token [31:16]; LR `include/librpmi.h:26-110, 88`); `rpmi_transport_enqueue`; ring the doorbell
  with `mmio_write32(0x2000_1000, 1)` (OpenSBI's order: tail first, then ring); then poll
  `rpmi_transport_dequeue(P2A_ACK)` every 32 cycles until success or `tmo` cycles (CYCLE register).
  Check the ACK: type ACKNOWLEDGEMENT (2), same group, service and token (LR
  `lib/rpmi_context.c:339-343`). Return `AP_E_TIMEOUT` on timeout. A timeout is a clean return,
  never a hang.
- The memcpy byte copies become TL-UL PutPartialData accesses with one mask bit (the adapter takes
  `be_i`, OT `tlul_adapter_host.sv:96-110`). The queue memory accepts them (ByteAccess = 1).
- Env (`ap/ap_env.c`): `rpmi_env_zalloc` from a 256 B arena (about 120 B used: shmem 32 +
  transport 56 + queue table 32, facts fw f); `rpmi_env_free` no-op; `rpmi_env_printf` only
  under LIBRPMI_DEBUG; `rpmi_env_writel` not needed.

### 9.8 AP test program (`ap/ap_main.c`) and its checkpoints

The AP records failures in `fails` and halts with `fails` (0 = pass) through its sim control. A
checkpoint is `CHECK {dom, mode}` on the AP sim control. The TB then checks the PPU mode and the
IP state rule (10.4). The AP waits for TB_CHECKS to advance before it continues (bounded). Seeds:
s0 = 0x5A (ACC0), s1 = 0xC3 (ACC1). Encodings come from librpmi only:

| Step | AP action | AP-side expectation (LR citation) | Checkpoint |
|---|---|---|---|
| A0 | init transport; read A2P/P2A head and tail | all 0 | |
| A1 | BASE GET_SPEC_VERSION (srv 0x04, `librpmi.h:221`) | status 0, `RPMI_BASE_VERSION(1,0)` = 0x0001_0000 (`librpmi.h:20-24, 228-236`) | |
| A1 | GET_IMPLEMENTATION_VERSION (0x02) / _IDN (0x03) | 0x0001_0000 (`librpmi.h:384-385`) / 0 (`:382`) | |
| A1 | PROBE_SERVICE_GROUP (0x06) of BASE 0x0001, DEVICE_POWER 0x0009, SYSTEM_RESET 0x0003 (`librpmi.h:186-200`) | non-zero version, non-zero version, 0 (absent) (`rpmi_context.c:140-164`) | |
| A1 | GET_ATTRIBUTES (0x07) | 5 words, status 0 (`rpmi_context.c:166-190`) | |
| A2 | DPWR GET_NUM_DOMAINS (0x02, `librpmi.h:329`) | {0, 4} | |
| A2 | GET_ATTRIBUTES (0x03) id 0..3 | names "CPU0","CPU1","ACC0","ACC1", trans_latency 0 | |
| A2 | GET_DPWR_STATE (0x05) id 0..3 | {0, 3 = OFF} (`librpmi.h:1623`) | CHECK(n, OFF) for n = 0..3 |
| A3 | SET_DPWR_STATE (0x04) CPU0 ON (state 0) | {0} | CHECK(0, ON) |
| A4 | CPU1 ON | {0} | CHECK(1, ON) |
| A5 | ACC0 ON; IP_SEED = s0; IP_CMD[2] = FILL; wait 64 cycles; IP_CMD = 0 | {0} | CHECK(2, ON) |
| A6 | ACC1 ON; fill with s1 | {0} | CHECK(3, ON) |
| A7 | CPU0 OFF; GET_STATE = OFF; wait hyst + 50k cycles | {0} at once | CHECK(0, FULL_RET) |
| A8 | CPU0 ON | {0} | CHECK(0, ON) |
| A9 | CPU1 OFF; wait hyst + 3 backoffs + 50k | {0} | CHECK(1, OFF) |
| A10 | CPU1 ON | {0} | CHECK(1, ON) |
| A11 | ACC0 OFF; wait | {0} | CHECK(2, MEM_RET) |
| A12 | ACC0 ON | {0} | CHECK(2, ON) |
| A13 | ACC1 OFF; wait | {0} | CHECK(3, OFF) |
| A14 | ACC1 ON | {0} | CHECK(3, ON) |
| A15 | all four OFF; wait; GET_STATE x4 = OFF | | CHECK(0, FULL_RET), CHECK(1, OFF), CHECK(2, MEM_RET), CHECK(3, OFF) |
| A16 | read TB_ERRORS; HALT(fails + (TB_ERRORS != 0)) | | |

### 9.9 CPU program (`cpu/cpu.S`, one image, behaviour by mhartid; decision 13)

Assembly only, because the s-register signature must not depend on the compiler.

```
cpu_start:  li sp,0x1000 ; lw t0,BOOT_COUNT ; addi t0,t0,1 ; sw t0,BOOT_COUNT
            csrr t1,mhartid ; li t2,0xC0DE0000 ; or t2,t2,t1 ; sw t2,MARKER
            bnez t1, cpu1
cpu0:       load s0..s11 with SIG(i) = 0x5100_0000 | (i << 8) | hartid
            li t0, MIE_MEIE ; csrw mie, t0          # mstatus.MIE stays 0: WFI wakes, no trap
loop0:      wfi
            lw t0,WAKE_COUNT ; addi t0,t0,1 ; sw t0,WAKE_COUNT
            sw s0..s11 -> DUMP[0..11]
            j loop0
cpu1:       li s0,0
loop1:      addi s0,s0,1 ; sw s0,COUNT ; j loop1     # never WFI: core_sleep_o stays 0
cpu_trap:   csrr t0,mcause ; sw t0,TRAP ; j cpu_trap_hang (wfi loop)
```

- CPU0's WFI exit needs `mie.MEIE` (bit 11) and an external-interrupt pulse. With
  `mstatus.MIE = 0` no trap is taken (`ibex_cs_registers.sv:1042-1043`;
  `ibex_controller.sv:603-620`).
- CPU1's store-every-iteration loop keeps `core_sleep_o = 0`, so the adapter denies every
  quiescence request. Its OFF is denied retry_cap + 1 = 4 times and then forced. After ON it
  restarts from its boot address, with BOOT_COUNT = 1 (fresh image), MARKER rewritten and COUNT
  from 1.
- The image (`cpu.bin`) holds 0 in BOOT_COUNT, WAKE_COUNT, TRAP and COUNT.

### 9.10 Estimated RAM per image

Based on the measured per-file sizes of `rpmi_dpwr` (facts fw k): rpmi_context 1.0 KB,
device_power 0.67 KB, transport_shmem 0.76 KB, pd.c 2.6 KB, ppu_v1 0.8 KB, console 0.63 KB,
trap 0.55 KB, scp_rpmi about 1.0 KB, policy.c 1.8 KB.

| Image | text | rodata | data + bss | Total | Limit | Margin |
|---|---:|---:|---:|---:|---:|---:|
| soc4_scp | ~12 KB (server + pd + soc4_policy about 2.2 KB + loader 0.3 KB + db 0.2 KB + main 0.5 KB) | ~5.5 KB (4 KB CPU image + strings) | ~2.6 KB (pd_tab 4 x 128 = 512, arena 1024, policy 4 x 48, loop/trap/stats) | ~20 KB | 64 KB - 4 KB stack minimum (`link.ld:22-23, 92-96`) | ~40 KB |
| soc4_stress | ~22 KB (BASE + loader + the test, est. 15 KB; ppu_stress.c is 1,909 lines for 12 domains and 35 features) | ~9 KB (CPU image + strings) | ~1.5 KB | ~33 KB | 60 KB | ~27 KB |
| soc4_ap | ~7 KB (transport subset 2 KB + client 1 KB + test 3 KB + console/trap) | ~1.5 KB | ~0.6 KB (arena 256) | ~9 KB | 60 KB | ~51 KB |
| cpu | < 0.5 KB code | | layout to 0xC80, stack 0xD00-0xFFF | 4 KB (padded) | 4 KB, code under 0xC00 (link assert) | ~2.5 KB code room |

Each `make soc4fw` prints `size` per image. If an image crosses 56 KB, the build is to be
reviewed (stack minimum 4 KB, link.ld).

---------------------------------------------------------------------------------------------------

## 10. Testbench (`tb/soc4/soc4_tb.sv`, NEW)

### 10.1 Structure

```
soc4_tb
  clk 10 ns; mclk 2.5 ns (ppu_monitor sampling); rst_n released after 8 negedges (as pmu_tb.sv:122-133)
  u_dut      soc4_top (PCSM_*_SETTLE from `SOC4_PCSM_RET_SETTLE / `SOC4_PCSM_LOGIC_SETTLE, default 0)
  u_sim      scp_sim_ctrl #(.NUM_PD(4), .TAG("fw"))  on u_dut.sim_*
  u_apsim    scp_sim_ctrl #(.NUM_PD(4), .TAG("ap"))  on u_dut.ap_ext_*
  stimulus   acc_*_i[k] = u_sim.*_o[2+k] | u_apsim.*_o[2+k] | tb_stim.*[k]   (three sources; bits 0-1
             of the sim controls are unused)
  tb_stim    the TB's own stimulus block: acc start/work_len/light/wake/deny/ip_cmd/ip_seed and
             hold_busy[3:0] (the only driver of u_dut.hold_busy_i). Driven by the BFM tasks
             (soc4bfm), or by the SCP's TB commands in soc4stress: the stress image writes
             u_sim's AP_CMD register (an output to the TB, `scp_sim_ctrl.sv` R_AP_CMD 0x038)
             with {[31:24] = 0x48 'H', [3:0] hold mask} for hold_busy, or {0x44 'D', mask} for
             deny. The TB applies the command and echoes it on AP_STAT
  tl_assert  tlul_assert #(.EndpointType("Device")) bound at u_dut.u_mbx (tl_h_i/tl_h_o), and
             #(.EndpointType("Host")) at u_dut.u_ap (tl_o/tl_i): OpenTitan's protocol checker,
             as mbx_bind.sv binds it (7.1)
  per domain n (generate over 0..3, AON probes only):
             ppu_monitor u_mon[n], ppu_power_model u_pm[n]      (as pmu_tb.sv:456-498)
             the per-hop spec checks of pmu_tb.sv:582-680 (Table 3-2, 4-7/9/11, 4-12, Table 4-5 spacing),
             transcribed for 4 domains
             rail-on to DEVWARMRESETn >= 20 cycles (pmu_tb SETTLE_CYCLES)
             hop log: every committed mode change (from, to, cycle), the QREQn/QACCEPTn/QDENY counts, AXI handshakes per PPU
  IP-state rules (10.4), CPU fetch watcher (first instr address after each core reset release)
  tl_bfm     the TL-UL BFM (10.2), active with +bfm
  report     on HALT (soc4, soc4stress) or BFM done (soc4bfm) or +max_cycles
```

**Probe rule (decision 14).** The TB never reads a register inside a switched domain. Allowed
reads are PPU and PCSM signals (`u_*/u_dom/u_pd/...`, always-on, **excluding**
`u_*/u_dom/u_pd/u_clkctrl`, which is in PD_DEV, 8.2), the always-on RAM arrays
(`u_cpuN/u_ram/u_sram.sram[]`, `u_accK/u_ip/g_bank[b].u_bank.mem[]`), isolated outputs on the
always-on side (`u_cpuN.core_sleep_o`, the CPU RAM wrapper's request inputs), soc4_ctrl and
soc4_mbx registers, and supply nets through `UPF::` under SOC4_PA. Every compare against a value
that could be X is written `!==` or `===`. `$isunknown` is applied to always-on arrays only, to
show loss. The isolated `core_sleep` is compared only while the domain's PPUHWSTAT is ON or
WARM_RST. Outside those modes it is 1 in RTL simulation (Ibex in reset) and 0 under PA (the clamp),
and both are correct (4.4).

pmu_tb's in-domain probes are not carried over: `pb_dead` (`pmu_tb.sv:450`) and `OB_RAM`
(`:574-577`). PA liveness comes from 8.4.

### 10.2 TL-UL BFM API

Tasks in soc4_tb, driving `u_dut.tl_bfm_i` on `clk` negedges and sampling on posedges. Every
task has a cycle timeout. On timeout it counts an error tagged `[bfm-timeout]` and returns, so
the run never hangs (the AXI VIP of pmu_tb had no timeout: facts hw hazard 10).

| Task | Behaviour |
|---|---|
| `tl_req(src, op, addr, data, mask, out rdata, out derr, tmo=200)` | one transaction. a_size = 2, `a_user = tlul_pkg::TL_A_USER_DEFAULT`, `d_ready = 1`; checks `d_source == src` and the d_opcode (AccessAck for a put, AccessAckData for a get) |
| `tl_wr(src, addr, data, mask='1)` / `tl_rd(src, addr, out data)` | wrappers; count an error if `d_error` is set |
| `tl_wr_err(src, addr, data)` / `tl_rd_err(src, addr)` | expect `d_error = 1`; a missing error counts as an error |
| `q_put(t_idx, msg[], len)` | write a message into A2P slot `tail + 2` (byte-exact layout of 4.2), then the tail |
| `ring(src)` | `tl_wr(src, 0x2000_1000, 1)` |
| `rpmi_send(grp, srv, tok, data[], n)` | header per LR `include/librpmi.h:26-110`, `q_put`, `ring(AP_SOURCE)` |
| `rpmi_ack(tmo, out got, out hdr, out data[])` | poll the P2A tail every 32 cycles until `tail != head` or `tmo`, then read the slot and advance the head. `got = 0` on timeout, with no error (the caller decides) |
| `rpmi_expect(grp, srv, tok, status, ...)` | send + ack (200000-cycle timeout) + compare |
| `ck_mode(dom, mode)` | the PPU-level CHECK of 10.3, called directly |
| `hold(n, on)` | drive `tb_stim.hold_busy[n]` (domain n = 0..3). The adapter then reports busy continuously; a CPU adapter also suppresses its deny (5.5) |
| `deny(k, on)` | drive `tb_stim.deny[k]` for ACC k (k = 0, 1). With `hold(2+k, 1)` every quiescence request of that ACC is denied (5.6: deny = deny_i && busy_t) |

The BFM checks report through `bck()`. Their count joins TB_CHECKS and TB_ERRORS. It reports
`AP_STAT = {errs, step}` to the SCP sim control's `ap_stat_i`, as in pmu_tb.

### 10.3 The PPU-level CHECK (both sim controls)

As `pmu_tb.sv:705-748`, for dom < 4: PPU committed mode == mode; PCSM committed (WARM_RST as
ON); PPUHWSTAT == 1 << mode; live device controls == the 3.2 row; PCSMPSTATE[7:0] == the PCSM
mode; logic rail on/ret; RAM rail on/ret. Added for soc4: PCSMPSTATE[15:8] == the domain's RR
byte in FULL_RET/MEM_RET, else 0 (Table 4-12). Under SOC4_PA: the supply-net rule of 8.4-2.
Domain >= 4 is an error.

### 10.4 IP-state rules, run on CHECK from the AP sim control (soc4) and from BFM steps (soc4bfm)

Each rule has a tag. soc4neg greps the tags.

| (dom, mode) | Rule (always-on reads only) | Tag |
|---|---|---|
| (0, ON) after a cold ON | within 20000 cycles: MARKER == 0xC0DE0000; BOOT_COUNT == 1; the first instr fetch after the core reset release was at CPU0_BOOT + 0x80; TRAP == 0 | `[chk:CPU0_BOOT]` |
| (0, FULL_RET) | `ram_sleep[0] === 1`, `ram_sd[0] === 0`; the CPU0 RAM array equals its snapshot from the last ON checkpoint (no word differs, no X) | `[chk:FULLRET_RAM]` |
| (0, ON) after FULL_RET | within 20000 cycles: WAKE_COUNT == previous + 1; DUMP[i] === SIG(i) for i = 0..11; BOOT_COUNT unchanged; no instr fetch at CPU0_BOOT + 0x80 since the FULL_RET checkpoint | `[chk:FULLRET_REGS]` |
| (1, ON) | the first fetch after release at CPU1_BOOT + 0x80; MARKER == 0xC0DE0001; COUNT advances (two samples 1000 cycles apart); BOOT_COUNT == 1 | `[chk:CPU1_RESTART]` |
| (1, OFF) | `ram_sd[0] === 1`; every CPU1 RAM word `$isunknown` (lost); since the OFF vote, QDENY pulses == retry_cap + 1 = 4, and the final down-hop had no QREQn fall (forced, DEVREQEN = 0) | `[chk:CPU1_OFF]` |
| (2, MEM_RET) | `ram_sleep === 8'hFF`; every bank word === `ip_pattern(s0, b, a)` (`ppu_device_ip.sv`: `{seed,5'd0,bank,8'd0,4'd0,addr} ^ 0xA5A55A5A`) | `[chk:MEMRET_RAM]` |
| (2, ON) after MEM_RET | the same pattern compare | `[chk:MEMRET_RAM]` |
| (3, OFF) and (3, ON) after OFF | `$isunknown` on every ACC1 bank word (lost; not restored by ON) | `[chk:OFF_RAM]` |
| (k, ON) after a fill | bank words === pattern (the fill happened) | `[chk:FILL]` |
| (2, MEM_RET) and (3, OFF) | **logic loss, without reading inside the domain**: since the down-hop committed, the PPU outputs `dev_ret_rst_n === 0` and `dev_nret_rst_n === 0` (always-on, 3.2) and `CLKEN === 0`. Under SOC4_PA, `VDD_LOGIC_n` is off (8.4-2). After the next ON, the isolated outputs `u_ip.busy === 0` and `u_ip.done === 0` (the device came up idle from reset) | `[chk:LOGIC_LOSS]` |
| (1, OFF) | the same reset/clock/supply evidence for CPU1's core | `[chk:LOGIC_LOSS]` |
| (1, ON) after a CPU1 FAULT (B11) | the cold path ran: a WARM_RST hop in the hop log after the last ON request, the load port wrote all 1024 words (TB counts load-port writes), BOOT_COUNT == 1, first fetch at CPU1_BOOT + 0x80 | `[chk:CPU_RECOVER]` |

### 10.5 Fault injection for "a deadline miss gives FAULT" (chosen method)

The method: **the TB-only `hold_busy` input** (user decision, revision 2). `hold(n, 1)` makes
domain n's adapter report busy continuously, and for a CPU it also suppresses the deny (5.5).
With PWR_DEVACTIVEEN cleared by PREP, the static LP request starts (PPU 3.4.1, spec:1186-1190;
3.4.2, spec:1272-1275). The Q-Channel device then waits in Q_REQUEST for as long as busy is high:
busy without deny waits indefinitely (`qchannel_device.sv:77-128`), and the PPU has no timeout.
Therefore:

- the OFF-side step deadline (step_ticks = 1 ms) expires for real, and the domain enters FAULT
  (OFF already answered);
- an ON sent while the down-hop is still stuck waits in `going_down` (PPU 4.1.1: a transition
  cannot be interrupted) until on_ticks expires, and is answered `RPMI_ERR_HW_FAULT`;
- `hold(n, 0)` lets the hop finish. The recovery (the policy's own power-off retries, then the
  WARM_RST recovery or the CPU reload on the next ON) is then observed.

Revision 1 re-pulsed START to keep the accelerator busy. That does not work: `ppu_ip_core`
accepts START only in W_IDLE (`ppu_ip_core.sv:127-136`), so a burst cannot be extended, and one
burst is too short to outlast a 1 ms deadline.

Why hold_busy:

1. It is deterministic and models the failure the deadline exists for: a device that never
   quiesces.
2. It works for every domain kind, CPUs included. CPU1 gets an OFF-side fault, and the next ON
   reloads the image (B11), which closes revision 1's open item 6.
3. It needs no rebuild, no `force` on PPU or PCSM internals, and no firmware knob. soc4bfm uses
   the product `soc4_scp`.
4. It also makes the deny/retry/force test deterministic: `hold(2, 1)` + `deny(0, 1)` gives a
   denial on every request (B6).

The cost is one TB-only port per domain. It is ORed in always-on glue, documented as test-only,
and tied to 0 in a real SoC (5.1).

### 10.6 Mutants (soc4neg), following the repo's pattern

The repo's automated negative controls build a deliberately wrong variant, run it, and require
`RESULT: FAIL` plus specific failure text found by grep. Examples: `scpdpwr`'s `rpmi_dpwr_neg`
(`Makefile:1210-1223`) and `scprpmihw`'s `+rpmi_bfm_negctl`, which requires exactly 2 tagged
errors (`:1181-1208`). soc4neg follows that pattern, with an RTL define per mutant (6.6
`sim_define`), each rebuilt into `$(SOC4_DIR)` as scpdpwr does:

| Mutant | Define | Planted fault | Test run | Must contain | Must not contain |
|---|---|---|---|---|---|
| M1 | `SOC4_MUT_CPU0_NRET` | CPU0's core on `dev_nret_rst_n`, which is asserted in FULL_RET (3.2) | soc4 (AP) | `RESULT: FAIL` and `[chk:FULLRET_REGS]` in a `tb| ERROR` line | an `ERROR` tagged `[bfm-timeout]` |
| M2 | `SOC4_MUT_FW_OPEN` | FW_EN resets to 1 (FW_SRC 0x00) | soc4bfm, B0 only (`+bfm_only=B0`) | `RESULT: FAIL` and `[chk:FW_RESET_DENY]` | |
| M3 | `SOC4_MUT_ACC0_NORET` | ACC0's bank pins miswired in soc4_acc_dom (`bank_sleep = 0`, `bank_sd = ram_sd \| ram_sleep`): retention acts as shutdown. The PPU configuration and IDR are unchanged, so boot's `check_ident` passes (revision 1 planted `MEM_RET_RAM_REG_CFG = 0`, which `check_ident` would have stopped at boot) | soc4 (AP) | `RESULT: FAIL` and `[chk:MEMRET_RAM]` | a `FATAL` from the SCP |

The target passes only if all three fail in exactly the expected way. It prints, per mutant, the
tagged error count, as scpdpwr does.

### 10.7 Plusargs

| Plusarg | Meaning | Default |
|---|---|---|
| `+firmware=<vmem>` | SCP image (scp_ram default IMAGE_PLUSARG) | required |
| `+ap_firmware=<vmem>` | AP image | none (the AP RAM is zero; it is not fetched when `+bfm`) |
| `+bfm` | `bfm_sel_i = 1` from time 0; run the BFM sequence | off |
| `+bfm_only=<Bn[,Bm]>` | run the listed BFM steps only (B0 always runs first if listed) | all |
| `+scp_hold=<cycles>` | keep `scp_rst_ni` low for that many cycles after `rst_n` | 0 (soc4bfm sets 3000) |
| `+max_cycles=<n>` | end with FAIL if no HALT / BFM done by then | 20,000,000 |
| `+quiet` | suppress per-hop log lines | off |

### 10.8 Summary format

```
==== soc4_tb report ====
 domain  hops  denies  forced  last_mode   (per domain 0..3)
 ppu_monitor violations: n  power_model violations: n  settle violations: n
 power intent APPLIED (SOC4_PA) | absent
 mode=<ap|bfm|scp>  SCP halt 0x%08h (or "server, not halted")  AP halt 0x%08h (or "-")
 BFM: %0d checks, %0d error(s)   (bfm mode)
 testbench %0d checks, %0d error(s)
 RESULT: PASS | RESULT: FAIL
```

The PASS condition: the run ended by HALT (soc4: AP; soc4stress: SCP) with code 0, or by BFM
done (soc4bfm); TB errors == 0 (checks + monitors + power model + settle + BFM); no
`[ASSERT FAILED]` (scp_verdict). Under PA, LP [ERROR] == 0 as well (8.4).

---------------------------------------------------------------------------------------------------

## 11. Tests

All targets need `SIM=vcs`. They are run as `make <t> SIM=vcs VCSFLAGS="-full64 -sverilog
-timescale=1ns/1ps -q -nc -licqueue"`. Each depends on `soc4fw` and builds `soc4_tb` into
`$(BUILD)/vcs/soc4_tb` (PA builds into `$(BUILD)/vcs_pa/soc4_tb`).

| Target | Build | Run | Pass condition |
|---|---|---|---|
| `soc4fw` | `$(MAKE) -C src/soc4/fw OUT=build/fw/soc4` | | the four images built; size table printed |
| `soc4` | default | `+firmware=soc4_scp.vmem +ap_firmware=soc4_ap.vmem` | scp_verdict; AP HALT 0 |
| `soc4bfm` | default | `+firmware=soc4_scp.vmem +bfm +scp_hold=3000` | scp_verdict; BFM done, 0 errors |
| `soc4stress` | default | `+firmware=soc4_stress.vmem +bfm +bfm_only=none +quiet` | scp_verdict; SCP HALT 0; every feature line `PASS` |
| `soc4neg` | 3 rebuilds with mutant defines (10.6) | soc4 / soc4bfm per mutant | each fails exactly as listed |
| `soc4pa` | PA (8.3) | as soc4 | scp_verdict and LP [ERROR] == 0 and supply-net checks |
| `soc4bfmpa` | PA | as soc4bfm | same |
| `soc4stresspa` | PA | as soc4stress | same. It costs no extra code, so it is included; expected run time is about 2x soc4stress |

Run lengths (estimates): soc4 about 1.5 M cycles (each OFF waits out 1 ms = 100k cycles of
hysteresis; CPU1's OFF adds 0.7 ms of back-off). soc4bfm about 4 M (B6, B7 and B11 each hold a
domain for 2-5 ms). soc4stress about 3 M (SOAK included).
`+max_cycles=20000000`.

### 11.1 soc4 (AP Ibex program)

Checks: the AP-side expectations of 9.8 (each a firmware check, counted in `fails`) and the TB
checks at each checkpoint (10.3 + 10.4, including `[chk:LOGIC_LOSS]` at A9, A11, A13 and A15).
`hold_busy` stays 0 throughout soc4. Also, continuously: ppu_monitor, ppu_power_model, the
Table 4-5 spacings, and settling >= 20 cycles. Expected: AP HALT 0, `RESULT: PASS`. The TB check
count is fixed by the sequence and is recorded at first pass as the baseline.

Expected PPU mode sequence per domain (committed hops, in order):

| Domain | Sequence |
|---|---|
| CPU0 | OFF (boot) -> ON -> WARM_RST -> ON [A3 cold] -> FULL_RET [A7] -> ON [A8 warm] -> FULL_RET [A15] |
| CPU1 | OFF -> ON -> WARM_RST -> ON [A4] -> (4 denied ON->OFF attempts, no hop) -> OFF forced [A9] -> ON -> WARM_RST -> ON [A10] -> (4 denials) -> OFF forced [A15] |
| ACC0 | OFF -> ON [A5] -> MEM_RET [A11] -> ON [A12] -> MEM_RET [A15] |
| ACC1 | OFF -> ON [A6] -> OFF [A13] -> ON [A14] -> OFF [A15] |

The steps A3-A6 show "ON replies once ON" by the CHECK right after the ACK. A7, A11 and A13 show
"OFF puts the domain in its configured low-power mode". A7/A8 show "FULL_RET keeps the core's
registers". A11/A12 show "MEM_RET keeps the RAM". A9/A13/A14 show "OFF loses both". A10 shows
"CPU1 restarts from its boot address".

### 11.2 soc4bfm (TL-UL BFM)

| Step | Stimulus | Checks (all must hold) | Tag |
|---|---|---|---|
| B0 | SCP held in reset (`+scp_hold`). BFM: `tl_wr_err` to 0x2000_1000 and 0x2000_0000, `tl_rd_err` 0x2000_0040, with sources AP_SOURCE, 0x00, 0xFF | every access d_error; `DB_STATUS == 0`, `irq_ext == 0`, `DB_RING_CNT == 0`; the tc_sram words unchanged (array peek); `FW_DENY_CNT == 9`; `FW_LAST[9] == 1` (FW_EN was 0) | `[chk:FW_RESET_DENY]` |
| B1 | release the SCP; wait for `soc4_ctrl.AP_RUN == 1` (peek), then 2000 cycles | the A2P/P2A head and tail are 0 (librpmi init) | `[chk:INIT]` |
| B2 | source 0x02 (unlisted): `tl_wr_err` doorbell, `tl_wr_err` queue word, `tl_rd_err` queue word; then AP_SOURCE: `tl_wr` queue word, `tl_rd` it back | denied accesses have no side effect (no ring, the memory unchanged, `FW_LAST[7:0] == 0x02`, `FW_LAST[9] == 0`, `FW_DENY_CNT` +3); the admitted ones are OK; restore the word | `[chk:FW_SRC_DENY]`, `[chk:FW_ADMIT]` |
| B3 | BASE discovery as A1; DPWR discovery as A2 | as 9.8 | `[chk:DISCOVER]` |
| B4 | each domain n: ON, then `ck_mode(n, ON)` + 10.4 rule; OFF, wait, `ck_mode(n, LP(n))` + rule | as 11.1 | `[chk:ONOFF]` |
| B5 | ACC1: ON; OFF; 20000 cycles later (inside the 100k window) ON | both ACKs SUCCESS; **no AXI handshake to PPU 3** and no hop between the OFF ACK and the ON ACK; PWSR stays ON; then OFF, wait, OFF reached | `[chk:CANCEL]` |
| B6 | ACC0: ON; `hold(2, 1)`, `deny(0, 1)`; OFF; wait hyst + 0.7 ms + 50k | deterministic: every request is denied. QDENY pulses == 4 (= retry_cap + 1); the final hop ON -> MEM_RET without a QREQn fall (forced, DEVREQEN = 0); `PWCR.DEVREQEN0 == 0` (PPU register peek, AON); then `hold(2, 0)`, `deny(0, 0)`; ON -> SUCCESS; `PWCR.DEVREQEN0 == 1` again; the next OFF (idle) handshakes normally (one QREQn fall, QACCEPTn) | `[chk:DENY_FORCE]` |
| B7 | ACC1: ON; `hold(3, 1)` (deny 0); OFF at t0; at t0 + 2.2 ms (after the 1 ms hysteresis and the 1 ms step deadline) ON | the OFF ACK is SUCCESS at once; the ON ACK is `RPMI_ERR_HW_FAULT` (-8, `librpmi.h:141`) and arrives about on_ticks after the request; GET_STATE == OFF (3) | `[chk:FAULT]` |
| B7 cont. | `hold(3, 0)` at t0 + 3.3 ms; wait 1.5 ms | the stuck hop completes and the PPU reaches OFF; the policy's next recovery attempt finds PWPR == PWSR == OFF and goes to S4_LP with no PPU write (no AXI write to PPU 3 after the release) | `[chk:FAULT_SETTLE]` |
| B7 cont. | ON | SUCCESS; the hop log since the last OFF shows OFF -> ON -> WARM_RST -> ON (WARM_RST recovery, decision 9); then OFF, and OFF is reached | `[chk:RECOVER]` |
| B8 | SET_DPWR_STATE id 4 and 0xFFFF_FFFF; GET_DPWR_STATE id 4; GET_ATTRIBUTES id 4; SET id 0 with state 1 | INVALID_PARAM (-3, `librpmi.h:121`) for each (`rpmi_service_group_device_power.c:300-303, 259-262, 214-217`; `scp_rpmi.c:56-58`); no PPU access | `[chk:BAD_ID]` |
| B9 | request to group 0x0003 (SYSTEM_RESET, not registered) and to group 0x00FF; `rpmi_ack(20000)` each; then GET_NUM_DOMAINS | the A2P head reaches the tail (consumed, `rpmi_context.c:328-333`); `got == 0` with no error and no hang; the following request is answered normally | `[chk:NO_GROUP]` |
| B10 | `tl_wr_err` 0x2000_1004; `tl_rd` 0x2000_1000; `tl_rd_err` 0x2000_2000 | d_error / data 0 with no ring / d_error | `[chk:TLUL_MAP]` |
| B11 | CPU1 (running, ON from B4's second ON): `hold(1, 1)`; OFF at t1; wait 2.5 ms | the static OFF waits in Q_REQUEST (deny suppressed, 5.5); the step deadline expires and the domain is in FAULT (no hop, PWSR still ON). The policy's recovery attempts fail while the hop is stuck (`going_down`), each one hysteresis apart | `[chk:CPU_FAULT]` |
| B11 cont. | `hold(1, 0)`; wait 2 ms | releasing busy ends the stuck request with a denial: CPU1 never sleeps, so its adapter denies again (5.5), and the PPU reverts the policy to ON (Table 4-1). At the next recovery attempt the policy powers off again: 4 denials, then forced, then OFF reached, logged as recovered | `[chk:CPU_FAULT_SETTLE]` |
| B11 cont. | ON | SUCCESS; the cold path with image reload ran: FETCH_EN 0, ON, WARM_RST, 1024 load-port writes, CPUn_BOOT written, FETCH_EN 1, ON. The 10.4 rule for (1, ON) after a FAULT passes. This is decision 9's "CPUs are then reloaded and booted" | `[chk:CPU_RECOVER]`, `[chk:CPU1_RESTART]` |

Expected mode sequence (soc4bfm): CPU0: OFF -> ON -> WARM_RST -> ON -> FULL_RET (B4). CPU1: OFF ->
ON -> WARM_RST -> ON -> (4 denials) -> OFF forced (B4) -> ON -> WARM_RST -> ON (B4) -> [B11: no hop
while held] -> (denials, then forced) -> OFF -> ON -> WARM_RST -> ON (B11 recovery with reload).
ACC0: OFF -> ON -> MEM_RET (B4) -> ON -> (4 denials) -> MEM_RET forced -> ON -> MEM_RET (B6).
ACC1: OFF -> ON -> OFF (B4) -> ON -> OFF (B5) -> ON -> [B7: no hop while held] -> OFF (after the
release) -> ON -> WARM_RST -> ON -> OFF (B7 recovery).

### 11.3 soc4stress (SCP firmware stress over 4 static-only PPUs)

It replaces scpstress for soc4. Image `soc4_stress`: BASE + loader + `soc4_ret` + the test, no
RPMI. The AP is held (`+bfm` with no BFM steps). The test drives `hold_busy` and ACC deny through
TB commands on AP_CMD (10.1). Each check prints one `RESULT <ID> PASS|FAIL|DEVIATION` line with
**the same IDs as ppu_stress** (`pmu/PPU_FW_CONFORMANCE.md` Section 3), so the two reports compare
row for row. Every PPU-level claim is cross-checked by a CHECK on the SCP sim control (10.3) and
by the continuous monitors.

Below, every row of `PPU_FW_CONFORMANCE.md` Section 3 is listed. "soc4" means what soc4stress does
on the four static-only PPUs. "N/A" means the soc4 PPUs are built without the feature (3.3), so no
firmware can reach it there.

| Check ID | Feature (PPU_FW_CONFORMANCE.md row) | DEN 0051E | soc4stress action | Status |
|---|---|---|---|---|
| `RST` | reset value of every register; default masks; default policy OFF: no transition and no interrupt out of reset | Tables 5-2..5-29; 4.2.1 | the offsets of ppu_stress on 4 PPUs, values derived for each soc4 configuration (PWPR policy OFF, DYN/LOCK fields 0) | soc4 |
| `ID` | AIDR 0x11, IDR0/IDR1 per 3.3, DEVCHAN 0x1, IIDR | 5.2.23-5.2.26 | exact values per domain; the driver's decoded sets (`sta_modes`, `dyn_modes = 0`) | soc4 |
| `REG.RW` | writable fields hold; reserved WI/RAZ; FUNRR on all 4, FULRR on CPU1/ACC0/ACC1 and MEMRR on CPU0/CPU1/ACC1 are reserved (read 0, writes ignored); PWPR `LOCK_EN` [12] and `PWR_DYN_EN` [8] reserved WI (`REGISTERS.md:273`; `ppu_regs.sv:325-326`) | 5.2, Tables 5-2, 5-19..5-21 | 5 patterns per RW register, raw `ppu_wr`/`ppu_rd` | soc4 |
| `REG.RO` | RO registers ignore writes; reserved registers read zero | 5.2, 5.2.6 | PWSR, DISR, MISR, IDR0/1, IIDR, AIDR with ones and zeros; PMER, STSR, OPSR, UNLK and unmapped offsets | soc4 (added) |
| `REG.BYTE` | byte-lane writes (WSTRB); PWPR admission judges policy and dynamic enable together | 6.2.1; 4.1.1 | `sb`/`sh` to EDTR0, DCDR0, PWCR, PWPR, ISR change only their lanes. PWPR admission on static-only PPUs: a lane-0 write of an unsupported policy (MEM_RET on CPU0) is refused whole with UNSPT_POLICY; a lane-1 write with PWR_DYN_EN set leaves the policy unchanged and DYN_EN reads 0 (reserved) | soc4 (added; the dynamic-WARM_RST case is N/A) |
| `REG.W1C` | ISR/AISR W1C; OTHER_IRQ mirrors AISR; IRQ the OR, as a level | 4.1.2, 5.2.12-5.2.13 | on 4 PPUs, line watched in `mip` and at the pin | soc4 |
| `STA.MATRIX` | every supported mode; every ordered pair; a hop has ON at one end; MEM_RET -> OFF through ON; ON <-> WARM_RST without a PCSM handshake; STA_POLICY_TRN condition 2; STA_ACCEPT per hop | Tables 3-1, 3-2; 3.3.2, 3.4.2, 4.1.2, 4.2.6, Table 4-14 | all ordered pairs of each domain's set: CPU0 {OFF, FULL_RET, ON, WARM_RST} 12, ACC0 {OFF, MEM_RET, ON, WARM_RST} 12, CPU1 and ACC1 {OFF, ON, WARM_RST} 6 each. OFF -> MEM_RET goes through ON here (OFF_MEM_RET_TRANS = 0) and is checked as such | soc4 (36 pairs instead of 42 x 12; the direct OFF -> MEM_RET hop is N/A) |
| (continuous) | device controls per mode; PPUHWSTAT one-hot; spacings >= value + 1; power-up/down order; settle >= 20; PCSMPSTATE stable while PREQ | Tables 4-7/9/11, 3-2, 4-5; 4.1.5; 4.1.6 | soc4_tb monitors, every hop | soc4 |
| `scpstresspa` -> `soc4stresspa` | supply removed in OFF, MEM_RET and FULL_RET logic, kept elsewhere | Table 3-1 | supply-net query (8.4) | soc4 |
| `EVT.UNSPT` | unsupported modes refused whole, one event each | 3.1, 4.1.1, Table 5-26 | OFF_EMU, MEM_RET_EMU, LOGIC_RET, DBG_RECOV, 11-15, MEM_OFF, FUNC_RET on all; MEM_RET on CPU0/CPU1/ACC1; FULL_RET on CPU1/ACC0/ACC1 | soc4 |
| `EVT.PTRN1` | a static write of the current mode makes no transition; STA_POLICY_TRN condition 1 | 3.3.2, 4.1.2 | each domain, each mode | soc4 (added) |
| `STA.QACT` | a static lower-priority transition waits for DEVQACTIVE LOW, including an intermediate hop through ON; higher priority not delayed; ON <-> WARM_RST never waits; the second hop from ON of an upward route waits; a disabled input counts as LOW | 3.4.1, 3.4.2 (spec:1186-1190, 1272-1275) | DEVQACTIVE from ACC wake/busy, and from hold_busy for CPUs. Routes ACC0 MEM_RET -> OFF (via ON), CPU0 OFF -> FULL_RET (via ON, second hop from ON); PWR_DEVACTIVEEN 0 and 1 | soc4 (added) |
| `STA.MIDWRITE` | a PWPR write does not interrupt a transition | 4.1.1 | ACC0's down-hop held in Q_REQUEST by hold_busy; write PWPR = ON; the hop ends only on accept (release) or deny | soc4 (added) |
| `SOAK` | everything at once; PPUs transitioning independently | - | the four domains on seeded random static sequences, concurrently, 2,000 requests, with CHECKs | soc4 (added; 4 PPUs instead of 12) |
| `DENY` | a denied static transition reverts the policy to the current mode and touches nothing; **denial of the second hop of a route through ON**; STA_POLICY_TRN condition 3 | 4.1.1, 4.1.2, 4.2.9, Table 4-1 | ACC deny + hold_busy; CPU1 not in WFI. Second hop: ACC0 in MEM_RET, policy OFF, route MEM_RET -> ON -> OFF, ON -> OFF denied (hold_busy + deny): policy reverts to ON, PWSR ON. Condition 3 by a mid-flight write equal to the current mode | soc4 (second hop added; the PWR_DYN_EN-during-denial and dynamic-denial cases are N/A) |
| `EVT.MASK` | a masked event sets no status; unmasking does not resurrect it | 5.2.10-5.2.11 | | soc4 |
| `EVT.EDGE` | edge event none/rise/fall/both; DISR shows DEVQACTIVE | 4.1.2, 5.2.4, 5.2.14 | ACC wake toggles | soc4 |
| `EVT.EDGE_OFF` | the edge event does not depend on PWR_DEVACTIVEEN | 4.1.3 | | soc4 |
| `EVT.LINES` | PPU n is SCP line 16 + n, and only that line | integration | | soc4 |
| `DEV.REQEN` | DEVREQEN = 0: no handshake, answer ignored; changes only static with the target reached; re-enabled only from ON | 4.1.3 | driver E_STATE cases + forced entries | soc4 |
| `DEV.WARM` | WARM_RST_DEVREQEN; one PCSM handshake per hop, none for ON <-> WARM_RST | Table 4-4; 4.1.6 | PTCR 0 (reset value, no handshake) and 1 (written: a handshake on ACC0's ON <-> WARM_RST) | soc4 |
| `DEV.STATUS` | DISR shows DEVQACTIVE; MISR shows DEVQACCEPTn, and also DEVDENY_STATUS and PCSMPACCEPT_STATUS | 5.2.4, 5.2.5 | the MISR deny and PCSM bits are added (ppu_stress left them "—") | soc4 (extended) |
| `DLY` | DCDR0/1 programmable and read back; each spacing **exactly** value + 1; RST_HWSTAT_DLY also waits for the device handshake | 4.1.5, Table 4-5, 5.2.21-22 | three DCDR settings, spacings measured by the TB (OBS UP/DN_LAST) and compared for equality; HWSTAT commit after QACCEPTn release measured on ACC0 | soc4 (exact value + 1 and the handshake added) |
| `EDT.STATIC` | entry delay = value + 1 for each field, static | 4.1.3, Figure 4-10 | the OFF, MEM_RET (ACC0) and FULL_RET (CPU0) fields; the MEM_OFF and FUNC_RET fields are N/A | soc4 (3 of 5 fields) |
| `EDT.SCOPE` | not applied upward, nor to ON <-> WARM_RST | 4.1.3 | | soc4 |
| `EDT.RESTART` | the count restarts when conditions go away mid-count; a value reprogrammed mid-count applies from the next count | 4.1.3 | DEVQACTIVE raised mid-count with PWR_DEVACTIVEEN = 1; EDTR rewritten mid-count | soc4 (added) |
| `PCSM.RR` | PCSMPSTATE[15:8] the retention byte of the mode entered, [7:4] 0, [3:0] the mode with WARM_RST as ON | Table 4-12 | FULL_RET on CPU0, MEM_RET on ACC0 with masks | soc4 |
| `PCSM.RAM` | the retention byte reaches the RAM | 5.2.16-5.2.18 | CPU0 FULRR bit 0 = 1 keeps / 0 loses the CPU RAM (on 0, the next ON runs the **cold** sequence, FETCH_EN = 0 first, so the core never wakes into X RAM); ACC0 MEMRR = 0xA5 keeps exactly banks 0, 2, 5, 7 (TB per-bank compare) | soc4 |
| `CLK` | the PPU's own clock gates when idle; accesses complete | PCK-600 clock Q-Channel | | soc4 |
| `FW.STATES` | the manager drives every state of every domain through the interrupt path | README 5.2 | soc4_policy drives every DPWR state of every domain: soc4, soc4bfm; soc4stress drives every static mode through `pd_request_static` and `pd_poll` | soc4 |
| `pd_multi` | refused and reverted writes reported as such by the driver | README 6 rules 1-2 | REFUSED for unsupported policies; REVERTED for denials | soc4 |
| (soc4) `S.CPUQ` | CPU adapter: accept in WFI only; deny awake; CPU1 always denies | decision 7 | | soc4-only |
| (soc4) `S.LOAD` | load port works in WARM_RST and ON; errors with no RAM access otherwise | decision 5 | `trap_expect_fault` | soc4-only |
| (soc4) `S.CPUBOOT` | cold sequence boots at CPUn_BOOT; FETCH_EN = 0 holds the core; WARM_RST of a running CPU1 restarts it | decision 6 | | soc4-only |
| (soc4) `S.LOCKREQ` | a LOCK_EN request on LOCK_SPT = 0: the driver returns PPU_E_UNSUPPORTED **without writing** (`ppu_v1.c:108`), and a raw write with LOCK_EN set leaves it 0 with no UNSPT event | 5.2 PPU_PWPR | | soc4-only |
| (soc4) `S.DYNREQ` | a raw PWPR write {m, PWR_DYN_EN = 1} with m statically supported: DYN_EN is masked (`ppu_regs.sv:325`), admission sees the static policy m (`:332`), the write takes effect as static m, no UNSPT event. The driver's `ppu_set_policy(m, dyn = true)` then reads back a mismatch and returns PPU_E_REFUSED although m took effect (`ppu_v1.c:113-118`). Reported as `DEVIATION` (a driver finding, not a PPU bug); soc4 firmware never asks for dyn (`pd_request_static`) | 4.1.1 | | soc4-only |

**N/A on soc4: left to the PPU unit testbenches.** The soc4 PPUs are built without these features
(3.3), so they are truly not applicable here:

- `DYN.FLOORS`, `DYN.ROUTE`, `DYN.STATUS`, `EDT.DYNAMIC`; dynamic WARM_RST unsupported;
  STA_POLICY_TRN condition 4; DYN_ACCEPT/DYN_DENY; the dynamic-denial and
  PWR_DYN_EN-during-denial rows of `DENY`; the driver's second PWR_DYN_EN change. All need
  DYN_*_SPT_CFG = 1.
- `LOCK.SET`, `LOCK.CLEAR`, `LOCK.RACE`, and "locks when a transition from a lockable mode is
  denied". All need LOCK_CFG = 1.
- MEM_OFF and FUNC_RET (modes, pairs, EDTR fields, FUNRR). STA_*_SPT_CFG = 0.
- The direct OFF -> MEM_RET hop. OFF_MEM_RET_TRANS_CFG = 0.
- PCSMMODESTAT reporting MEM_RET at reset. PCSM_RESET_MODESTAT = OFF (D2).

Covered by: `ppu` (`ppu_pd_tb`, 617 checks), `ppuneg`, `ppudeny`, `ppudevif`, `ppucfg`,
`ppuirq`, `ppuclkq`, `ppupcsmpg`, `ppurstf` (in the 28), and by ppu_stress on pmu_tb until the
Section 12 deletion.

**Applicable but not reachable from firmware** (as in PPU_FW_CONFORMANCE.md Section 5): "an event
set and cleared in the same cycle stays set" needs a single-cycle race that only a testbench can
place. It stays with `ppuirq`.

### 11.4 soc4neg

Section 10.6. Expected output: three "FAILED, as it must" lines, each with its tag count.

### 11.5 soc4pa, soc4bfmpa, soc4stresspa

The same checks as their RTL counterparts, plus 8.4. Expected: `LP [ERROR]` count 0; the
supply-net checks all pass; `power intent APPLIED`.

### 11.6 Regression after soc4 lands

The 34 targets (Section 6) are unchanged, with the baseline counts of `build/merge/merge_notes.md`
Section 5. Then add `soc4 soc4bfm soc4stress soc4neg soc4pa soc4bfmpa soc4stresspa`.

---------------------------------------------------------------------------------------------------

## 12. The later pmu_top deletion commit

A separate commit, made only after every soc4 target passes and the user approves.

### 12.1 Deleted

| Path (under `src/` unless stated) | Why |
|---|---|
| `pmu/rtl/pmu_top.sv` | the 12-domain top |
| `tb/pmu/pmu_tb.sv` | its testbench (AXI VIP AP model) |
| `tb/pmu/pmu_pa_supply_vcs.sv` | its rails (soc4 has its own) |
| `upf/pmu_top.upf`, `upf/pmu_tb.upf`, `upf/pmu_tb_vcs.upf` | its power intent |
| `pmu/rtl/scp_rpmi_mbox.sv` | the AXI4-Lite mailbox |
| `pmu/fw/test/{hello,pd_multi,ppu_stress,ppu_lock_probe,ppu_edge_probe,rpmi_loopback,rpmi_hw,rpmi_dpwr,rpmi_dpwr_neg,rpmi_dpwr_slow}.c` | the 12-domain firmware tests; all run only on pmu_tb |
| `pmu/fw/hal/rpmi_db_hw.c`, `pmu/fw/hal/rpmi_db_poll.c` | mailbox_unit and loopback doorbell backends |
| `pmu/fw/mod/policy.[ch]`, `pmu/fw/hal/agate.h`, `pmu/fw/hal/agate_stub.c` | W4.1's dynamic 8-domain policy and its gate stub; replaced by soc4_policy (12.2) |
| `vendor/pulp/mailbox_unit/` (4 files + LICENSE) | not instantiated any more |
| `vendor/pulp/axi/{axi_lite_xbar,axi_lite_demux,axi_lite_mux,axi_lite_to_axi,axi_err_slv,axi_to_mem}.sv`, `vendor/pulp/axi/include/axi/assign.svh` | mailbox crossbar path; `axi_intf.sv` includes only `typedef.svh` (`axi_intf.sv:346`) |
| `vendor/pulp/common_cells/` (17 files + include + LICENSE) | used only by the axi RTL, register_interface and mailbox_unit |
| `vendor/pulp/register_interface/` | used only by mailbox_unit |

Kept from PULP: `axi/{axi_test,axi_intf,axi_pkg}.sv`, `axi/include/axi/typedef.svh`,
`common_verification/{rand_id_queue,rand_verif_pkg}.sv` (PULP_VIP for `ppuaxi`), and
`tech_cells_generic/tc_sram.sv` (soc4).

### 12.2 Changed or moved

| Path | Change |
|---|---|
| `pmu/rtl/scp_top.sv` | delete the `RPMI_MBOX` parameter, the `g_rpmi` branch (u_split_rpmi, u_axi_rpmi, u_rpmi), the `s_ap_axi_*` ports and the DevRpmiMem slot (NrDevices 3); `irq_external_i = irq_ext_i`; header map updated |
| `soc4/fw/mod/soc4_policy.[ch]` -> `pmu/fw/mod/policy.[ch]` | `git mv`, then rename the symbols |
| `soc4/fw/hal/soc4_db.c` -> `pmu/fw/hal/rpmi_db.c` | `git mv` |
| `soc4/fw/mod/soc4_ret.[ch]` -> `pmu/fw/mod/` | `git mv`. Optionally the driver's `ppu_set_ret_ram` is then fixed to honour IDR1 b4-b6 separately (Table 5-27) and the helper deleted, now that no pmu image constrains it |
| `pmu/fw/mod/pd.[ch]` | delete the 12-entry table, `pd_boot`, the `pd_state`/tuple paths and the 12-name enum; keep the `PD_PLAT_TAB` table |
| `pmu/fw/rpmi/scp_rpmi.[ch]` | delete the `#else` branches (T0b, SYSTEM_RESET, 8 names); optionally `SCP_NUM_XPORT = 1` with `rpmi_db.h` `RPMI_DB_COUNT = 1` |
| `pmu/fw/hal/scp_regs.h` | delete `SCP_RPMI_DB*`, `SCP_RPMI_MEM*`, `AP_RPMI_*`, `MBX_*`; `SCP_NUM_PPU` from the platform header |
| `pmu/fw/Makefile` | `RPMI_DB_POLL`, `RPMI_DB_HW`, `POLICY`, `DPWR_PROGS`, `RPMI_PROGS` removed; or merge with `soc4/fw/Makefile` |
| `src/Makefile` | delete targets `scphello scppd scprun scpstress scpstresspa scprpmi scprpmihw scpdpwr scpdpwrpa scppdpa` (both SIM branches) and the variables `PMU_SRCS PMU_TB_SRCS PMU_DIR PMU_SETTLE PCSM_RET_SETTLE PCSM_LOGIC_SETTLE pmu_run STRESS_ARGS DPWR_SLOW_SETTLE PA_PROG PA_ARGS PMU_PA_DIR PULP_RPMI PULP_RPMI_INC`; `SCP_FLAGS` without `PULP_RPMI_INC`; header comments; `.PHONY` |
| `build/regress/run_regress.sh` | `TARGETS`: drop scphello, scppd, scprun:ppu_lock_probe, scprun:ppu_edge_probe, scpstress, scppdpa, scpstresspa; add the 7 soc4 targets |

### 12.3 Documents to update

`vendor/pulp/README.md` (file tables, versions, "Building with it"), `vendor/opentitan/README.md`
(the soc4 consumer stays), `pmu/README.md` (pmu_top sections, memory map 0x0003_0000/0x1000_0000,
the AXI4-Lite AP port, the test list), `pmu/FUNCTIONS.md`, `pmu/PPU_FW_CONFORMANCE.md`
(scpstress -> soc4stress plus the unit-test split of 11.3), `rtl/ppu/README.md` where it names
pmu_top, the `src/Makefile` header block, `Proposed_PMU/RPMI_STACK_DECISIONS.md` (T0b, AXI4-Lite
AP port, IOPMP notes superseded by the TL-UL firewall), and the soc4 design notes.

### 12.4 Regression after the deletion

The 28 standard targets minus the 7 pmu_tb ones = 21: ppu upfcheck ppuneg ppurst ppuratio
ppucfg ppurstf ppuirq ppupm ppuregdoc ppube ppudeny ppudevif ppuclkctrl ppuclkq ppuaxi ppudemo
ppupcsmpg ppusrc ppudecl ppulatch. Plus acg and acgpd (2), plus the 7 soc4 targets: **30
targets**. scprpmi, scprpmihw, scpdpwr and scpdpwrpa go with pmu_tb. Their functions are covered
by soc4 (BASE/DPWR over the real TL-UL hardware), soc4bfm (the BFM, negative cases, FAULT) and
soc4neg (the negative control). Expected: all PASS, with the counts of the 23 non-soc4 targets
identical to `build/merge/merge_notes.md` Section 5, and soc4 counts equal to their own baseline
from first pass. `ppusrc` (`lint/ppu_srclist_check.py`) compares PPU_SRCS with the synthesis
list and is unaffected.

### 12.5 Done (2026-10-02), and where it departs from 12.1-12.4

Carried out on `scp-ibex-firmware` after `e978f0d`, left uncommitted for review. 12.1 deleted as
listed, plus `pmu/fw/Makefile`. 12.2 as listed, with these choices and departures:

- **Firmware build.** `src/soc4/fw/Makefile` is the only firmware build; `pmu/fw/Makefile` (which
  would have built nothing once `test/` was empty) and the `scpfw` target are gone, its flag
  rationale moved into the soc4 Makefile header.
- **`SCP_NUM_XPORT = 1`** taken, with `RPMI_DB_COUNT = 1`; the SYSTEM_RESET hook and stats went
  with the `#else` branches. `SCP_PLAT_SOC4` is gone: the shared files now take `SCP_NUM_PPU`,
  `SCP_DPWR_COUNT`, `SCP_PLAT_DPWR_DATA` and `PD_PLAT_TAB` from the platform header with no default
  (`#error` if absent).
- **The AP image also force-includes `soc4_plat.h`.** `hal/trap.c`, which the AP links, sizes its
  PPU lines with `SCP_NUM_PPU`; it used to get the 12-domain default. The AP's fast interrupts are
  tied off, so nothing it does changes.
- **`mod/pd`** keeps only the static-request path; `struct pd_tuple`, the `PD_PH_LOCK` phase and
  the state fields went with the state layer. Logic of `pd_request_static` / `pd_advance` is the
  same register sequence as before.
- **`hal/ppu_v1`** untouched; `soc4_ret` kept (12.2's option not taken).
- **soc4bfm / soc4bfmpa check counts.** BFM 26,221 / TB 26,623 (26,654 PA) instead of 26,299 /
  26,701 (26,732). The BFM polls the P2A tail every 32 cycles with two checks per poll
  (`soc4_tb.sv` `rpmi_ack`), so its count follows the firmware's response latency; the new images
  answer at slightly different times (the smaller `pd`, one transport, and code alignment: e.g.
  `cpu_load`'s copy loop now starts at a halfword address, +646 cycles per cold boot). Run on the
  new RTL and testbench with the HEAD (`e978f0d`) firmware, soc4bfm gives exactly 26,299 / 26,701.
  Every step outcome is identical; all other soc4 counts are unchanged.

---------------------------------------------------------------------------------------------------

## 13. Mapping to SOVRA

The scope is the SCP and PPUs as the AP's power-control host (SOVRA IP #47, `pmu`). soc4 is a
reduced system that checks those functions. **How the full chip is partitioned into power
domains is the SoC team's decision, not ours.** The rows below show only how soc4's stand-ins
correspond to SOVRA domain kinds, and what must scale.

### 13.1 (a) Stand-ins and SOVRA domain kinds

| soc4 domain | Stands in for (SOVRA) | Mode set exercised | Notes |
|---|---|---|---|
| CPU0 (Ibex, FULL_RET) | a VtCPU core tile (CVA6 in a Chipyard tile, 4x) or a VtDSP tile (CVA6 + Ara, 4x) | ON, WARM_RST, OFF, FULL_RET | the cold-boot sequence (WARM_RST hold, image/boot address, release) and warm resume are the SCP functions under test |
| CPU1 (Ibex, OFF) | the same tile kinds with OFF as the LP mode; also the RPU cores (2x) and the NPU host (Rocket) | ON, WARM_RST, OFF | shows the deny / retry / force path for a core that never idles |
| ACC0 (ppu_device_ip, MEM_RET) | a block whose SRAM must survive while its logic is off: **DSP SRAM** (VtDSP), **RPU TCM**, **OCM**, NPU scratchpads | ON, WARM_RST, OFF, MEM_RET | MEM_RET with RAM retention through PPU_MEMRR and macro pins |
| ACC1 (ppu_device_ip, OFF) | accelerators without retained state: Gemmini (4x, via ReRoCC), NPU DMA, baseband FFT/turbo/polar/LDPC/BBTX/BBRX, secdma, AES/SHA/RSA-ECC | ON, WARM_RST, OFF | busy/deny Q-Channel behaviour of a datapath block |

System blocks (bootrom, CLINT, PLIC, debug, pll, sysctl, the Ibex RoT, OTP, TRNG, peripherals)
are not modelled. soc4's AP stands in for the VtCPU cluster acting as the RPMI agent.

### 13.2 (b) What must scale, and how

| Item | soc4 | Full chip |
|---|---|---|
| PPU count | `scp_top #(.NUM_PPU(4))`; 4 AXI4-Lite manager ports; `scp_axi_lite_demux` SEL_W = 4 (16 slots, `scp_top.sv:583-588`) | NUM_PPU = number of SoC power domains. Above 12, the `$error` guard (`scp_top.sv:144-146`) and the 16-slot demux (SEL_W, the 64 KB window) must grow |
| Firmware domain table | `PD_PLAT_TAB` (4 entries), `SCP_NUM_PPU 4u` in `soc4_plat.h` | one generated platform header per SoC: names, kinds, PPU base per domain |
| DOMAIN_ID numbering | DOMAIN_ID = PPU index = line 16+n | keep DOMAIN_ID = PPU index (librpmi uses 0..count-1, LR `rpmi_service_group_device_power.c:300-303`). The AP-side DT/ACPI table is published from the same header |
| Per-domain LP-mode table | `s4_dom[]` (lp, cpu) in soc4_policy | the same table, generated: lp mode per domain kind (FULL_RET for retaining core tiles if the SoC partition allows; MEM_RET for SRAM/TCM/OCM holders; OFF otherwise), plus per-domain on/step/hyst deadlines |
| PPU parameters | 3.3 table, per domain | generated per domain from the same table (STA_*_SPT, *_RAM_REG_CFG) |
| IRQ lines | PPU n -> `irq_fast[n]`; Ibex has 15 fast lines (`scp_core.sv:148`; 12 usable after the reserved ones in `crt0.S:45-48`) | more PPUs than fast lines need an **interrupt aggregator** (status/mask registers on the SCP's private bus, one fast line per group). This is an open item (15.2-17), and `pd_poll` must read the aggregator |
| Mailbox | one transport, one agent (AP_SOURCE) | more agents or transports: socket N grows, and the firewall becomes a per-device source list |
| Load ports / boot control | 2 CPU load ports, CPUn_BOOT, FETCH_EN | per tile: boot address and reset/clock owner (13.3); image loading may move to the bootrom (13.3) |

### 13.3 (c) Integration interfaces the full chip needs and soc4 does not model

- **Clock and reset ownership of a Chipyard tile.** A PPU drives DEVCLKEN and DEVPORESETn /
  WARMRESETn / RETRESETn, and SOVRA has `clkgate` (TileClockGater) and `tilereset`
  (TileResetSetter). One owner per tile must be chosen, with the other subordinate: either the
  PPU's device outputs drive the TileClockGater/TileResetSetter inputs, or software writes to
  those blocks are forbidden while a PPU controls the tile. soc4 has a single owner (the PPU) by
  construction.
- **A CVA6/Rocket Q-Channel adapter** in place of Ibex `core_sleep_o` (5.5): a WFI-idle
  indication from CVA6/Rocket (or the tile's own), tile-level drain of outstanding TileLink
  transactions (outer-cache flush and coherence quiescence for a cached tile), and a wake path
  (the PLIC/CLINT pending interrupt) to replace the soc4 wake pulse.
- **TileLink adapter from OpenTitan TL-UL to Chipyard TileLink.** OpenTitan `a_user` (the
  instr_type MuBi and the integrity fields) has no Chipyard counterpart. The bridge must drive
  `TL_A_USER_DEFAULT` toward the mailbox and keep `CmdIntgCheck = 0`. It must also either
  generate response integrity or terminate it before the host side (1.5). Chipyard's source-ID
  remapping (TLSourceShrinker, crossbars) changes a_source, so the firewall's `a_source ==
  FW_SRC` match must be computed on the ID as it arrives at soc4_mbx. Alternatively the firewall
  takes a requester-ID sideband the fabric preserves. To be settled with the SoC fabric owner.
- **SCP boot ROM vs the sw team's SW_PMU_BootROM.** soc4 loads the SCP image by `$readmemh`. On
  silicon the SCP needs a boot ROM and an image source, which overlaps with SW_PMU_BootROM.
  Ownership of the SCP's reset vector, the image format and the CPU-image handoff (9.5) must be
  agreed.
- **RoT/OTP and SCP firmware trust** (the Ibex RoT, OTP, secure boot of the SCP image, debug
  lock): out of scope; noted only.

---------------------------------------------------------------------------------------------------

## 14. Traceability

Columns: requirement (brief sentence P-n, decision D-n, or revision-2 item R-n), where it is designed (section),
module or file, function, and test or check that shows it. "15.2-k" points to an open item. In the
test column, B0-B11 are soc4bfm steps (11.2), A0-A16 are soc4 AP steps (9.8), and S.* or
dotted IDs are soc4stress checks (11.3).

### 14.1 The brief (`Proposed_PMU/SOC4_TASK_PROMPT.md`)

| # | Requirement | Section | Module / file | Function | Test / check |
|---|---|---|---|---|---|
| P1 | out of scope: AP software, OpenSBI, Linux, QEMU, coherence | 1.1 | - | - | - |
| P2 | new minimal 4-domain top next to pmu_top; leave pmu_top alone | 5.1, 6.1 | `soc4_top`; scp_top `RPMI_MBOX` | - | the 34 targets unchanged (11.6) |
| P3 | SCP: reuse scp_top with 4 PPU slots | 5.1 | `u_scp` NUM_PPU = 4 | - | soc4stress `ID` |
| P4 | four domains, each ppu_axi_dom_top around its IP | 3, 5.3, 5.6 | `soc4_cpu_dom`, `soc4_acc_dom` | - | 11.1 sequences |
| P5 | PD_CPU0 real Ibex small, tiny program, own RAM, LP FULL_RET | 3.1, 5.3-5.4, 9.9 | `scp_core`, `soc4_cpu_ram`, `cpu.S` | cpu0 loop | `[chk:CPU0_BOOT]`, `[chk:FULLRET_REGS]` |
| P6 | PD_CPU1 real Ibex, LP OFF | 3.1, 9.9 | same | cpu1 loop | `[chk:CPU1_RESTART]`, `[chk:CPU1_OFF]` |
| P7 | PD_ACC0 stand-in, LP MEM_RET | 3.1, 5.6 | `ppu_device_ip` | - | `[chk:MEMRET_RAM]` |
| P8 | PD_ACC1 stand-in, LP OFF | 3.1, 5.6 | same | - | `[chk:OFF_RAM]` |
| P9 | exactly ON, WARM_RST, OFF + one LP mode via *_SPT_CFG; IDR0 reports only those | 3.3 | soc4_top parameters | `check_ident` | `ID`, `EVT.UNSPT` |
| P10 | LOGIC_RET, DBG_RECOV not available on Q-Channel | 3.1 | - | - | `EVT.UNSPT` |
| P11 | CPU adapter: accept only in WFI with the bus drained, deny otherwise | 5.5 | `soc4_cpu_adp` | deny_o | S.CPUQ, `[chk:CPU1_OFF]` |
| P12 | ACC adapter follows busy/deny | 5.6 | `soc4_acc_dom` | - | B6, `DENY` |
| P13 | mailbox: one RPMI shmem transport, queue SRAM, doorbell on irq_external, firewall deny-all at reset admitting only the AP's ID | 4.5-4.6, 5.2 | `soc4_mbx` | `soc4_db.c` | B0, B2, B10 |
| P14 | AP reaches it over AXI4-Lite | superseded by D10 (TL-UL) | 5.2, 5.7 | - | - (15.2-10, closed) |
| P15 | always-on AP: third Ibex, bare-metal program sending RPMI requests | 5.7, 9.7-9.8 | `soc4_ap`, `ap_main.c` | `ap_call` | soc4 |
| P16 | TB AP BFM on the same port, selectable per test | 5.1, 10.2 | AP/BFM mux, soc4_tb | BFM tasks | soc4bfm |
| P17 | UPF: IPs switched; PPUs, PCSMs, adapters, SCP, mailbox, AP always-on; RAM on AON with PCSM pins | 8.2 | `soc4_top.upf` | - | soc4pa |
| P18 | firmware: BASE + DEVICE_POWER, one M-mode context, DOMAIN_ID 0-3 = CPU0, CPU1, ACC0, ACC1 | 9.1, 9.6 | `scp_rpmi.c` (SOC4 branch), `soc4_plat.h` | `scp_rpmi_init` | A1-A2, B3 |
| P19 | ON puts the domain in ON and replies once ON, within a deadline | 9.4, 9.5 | `soc4_policy.c` | `vote_on` | A3-A6 + CHECK |
| P20 | OFF puts the domain in its LP mode | 9.4 | same | `step` | A7, A9, A11, A13 |
| P21 | static policy, so a busy IP can deny; on denial back off and retry up to a cap, then force | 9.4 | same | LPREQ/BACKOFF/FORCE | B6, `[chk:CPU1_OFF]` |
| P22 | expired deadline -> FAULT + error reply | 9.4 | same | `fault` | B7 `[chk:FAULT]` |
| P23 | GET_STATE returns the AP's last vote | 9.4 | `scp_rpmi.c` `dpwr_get` | - | B7 (OFF after a failed ON), A2, A15 |
| P24 | WARM_RST by the SCP only: hold a CPU core in reset until boot address and RAM are ready | 9.5 | `soc4_cpu.c` | cold sequence | `[chk:CPU0_BOOT]`, `[chk:CPU1_RESTART]`, S.CPUBOOT |
| P25 | WARM_RST as the recovery action for a faulted IP | 9.4 | `soc4_policy.c` | `vote_on` step 4 | B7 `[chk:RECOVER]` |
| P26 | the AP does not request WARM_RST | 9.4 | DPWR states ON/OFF only | `dpwr_set` | B8 (state 1 rejected) |
| P27 | boot: all four OFF and the AP released; CPU IPs up only when asked | 9.6 | `scp/main.c` | `main` | A2 CHECK(n, OFF) |
| P28 | handlers only set flags; librpmi only from the main loop; hal/ppu_v1.h driver rules | 9.3, 9.4 | `trap.c`, `scp_loop.c` | - | code review; `pd_multi` (driver reports) |
| P29 | tests are make targets, SIM=vcs, -licqueue via VCSFLAGS | 6.6, 11 | `src/Makefile` | - | all |
| P30 | AP test: discover BASE and DEVICE_POWER, every domain ON/OFF, check PWSR and IP state | 9.8, 10.4 | `ap_main.c`, soc4_tb | - | soc4 |
| P31 | FULL_RET keeps core registers; MEM_RET keeps RAM; OFF loses both | 10.4 | soc4_tb | IP-state rules | `[chk:FULLRET_REGS]`, `[chk:MEMRET_RAM]`, `[chk:CPU1_OFF]`, `[chk:OFF_RAM]`, `[chk:LOGIC_LOSS]` |
| P32 | a CPU running code powered OFF and ON restarts from its boot address | 9.9, 10.4 | `cpu.S`, soc4_tb | fetch watcher | `[chk:CPU1_RESTART]` |
| P33 | BFM: ON/OFF each domain | 11.2 | soc4_tb | - | B4 |
| P34 | BFM: ON inside the hysteresis window cancels | 11.2 | `vote_on` cancel | - | B5 |
| P35 | BFM: busy accelerator refuses, retried, forced | 11.2 | | | B6 |
| P36 | BFM: deadline miss gives FAULT | 10.5, 11.2 | | | B7 |
| P37 | BFM: out-of-range DOMAIN_ID rejected | 11.2 | | | B8 |
| P38 | BFM: firewall deny-all before programming; unlisted requester denied | 11.2 | | | B0, B2 |
| P39 | BFM: unregistered group gets no reply; BFM times out cleanly | 10.2, 11.2 | | `rpmi_ack` | B9 |
| P40 | power-aware variants, zero LP checker errors | 8.4, 11.5 | | | soc4pa, soc4bfmpa, soc4stresspa |
| P41 | the existing regression plus scprpmi still pass | 6, 11.6 | | | 34 targets |
| P42 | plan first, then wait for go | done before this document | - | - | - |
| P43 | file changes with Bash, yes/no approvals | process | - | - | - |
| P44 | no invented encodings; cite spec or librpmi | 1.4 | throughout | - | - |
| P45 | TB never reads inside a switched domain; X-tolerant compares; a negative control that must fail | 10.1, 10.6 | soc4_tb | | soc4neg |
| P46 | -nostdlib, -fno-tree-loop-distribute-patterns | 9.1 | soc4 fw Makefile | | soc4fw |
| P47 | link new code only into images that use it | 9.1 | explicit source lists | | soc4fw size table |
| P48 | LOCK_EN once, in the held mode; PWR_DYN_EN only after PWR_DYN_STATUS | 9.4 | no LOCK_EN / PWR_DYN_EN writes; pd waits DYN | | `S.LOCKREQ`, `REG.RW` (LOCK_EN reserved WI) |
| P49 | VCS traps: always_ff second writer (ICPD); set_design_top instance path | 5.4, 8.1 | `soc4_cpu_ram` (tc_sram reset, not a second writer), `soc4_tb_vcs.upf` | | build |
| P50 | report results with check counts, files changed, deviations, open issues | 15 | | | at implementation |

### 14.2 The user decisions of 2026-10-01

| # | Decision | Section | Module / file | Function | Test / check |
|---|---|---|---|---|---|
| D1 | DOMAIN_ID = PPU n = line 16+n, PPU at 0x4000_0000 + n*0x1000; CPU0 FULL_RET, CPU1 OFF, ACC0 MEM_RET, ACC1 OFF; ON = 0, OFF = 3 | 3.1, 4.1 | soc4_top, `s4_dom[]` | | `EVT.LINES`, A2-A15 |
| D2 | DYN_* = 0, LOCK_CFG = 0, OFF_MEM_RET_TRANS = 0; STA_FULL_RET only CPU0, STA_MEM_RET only ACC0; RAM_REG per domain; WARM_RST_DEVREQEN_CFG = 0; DEF_PWR_POLICY OFF, PCSM reset OFF; AXI4-Lite only for SCP-PPU | 3.3, 6.5 (soc4-only helper; ppu_v1 untouched) | soc4_top params; `soc4/fw/mod/soc4_ret.c` | `soc4_ret_ram` | `ID`, `REG.RW`, `PCSM.RAM`, `DEV.WARM` |
| D3 | boot: all OFF; order PPUs -> firewall -> RPMI + librpmi -> AP_RUN | 9.6 | `scp/main.c` | `main` | B0-B1, A2 |
| D4 | device controls per mode | 3.2 | (PPU) | | CHECK (10.3) |
| D5 | scp_core boot_addr_i; CPUn_BOOT / FETCH_EN; core reset = dev_ret_rst_n; CPU0 whole core retained; 4 KB tc_sram, 2 ports, load port shares port 1; sleep/shutdown glue on bank-0 pins; RAM on dev_clk; load port errors unless ON/WARM_RST | 5.3, 5.4, 6.2, 8.2 | `soc4_cpu_dom`, `soc4_cpu_ram`, `soc4_ctrl`, scp_core EDIT | | S.LOAD, `[chk:FULLRET_REGS]`, soc4pa |
| D6 | CPU cold ON steps 1-6; CPU0 warm = static ON + wake pulse; Ibex wakes on mip & mie | 9.5, 5.5 | `soc4_cpu.c`, `soc4_cpu_adp` | cold sequence | `[chk:CPU0_BOOT]`, `[chk:FULLRET_REGS]` |
| D7 | CPU adapter: WFI and no outstanding else deny, no wake; ACC as pmu_top, stimulus from TB ports | 5.5, 5.6, 10.1 | | | S.CPUQ, B6 |
| D8 | OFF: reply at once; hysteresis with cancel; static ON prep with PWR_DEVACTIVEEN cleared; static LP; backoff doubling to a cap; force DEVREQEN = 0; steady static ON / static LP | 9.4 | `soc4_policy.c` | `vote_off`, `step` | B5, B6, A9 |
| D9 | FAULT on an expired deadline -> HW_FAULT; failed ON -> power-off with N retries then FAULT + log; next ON after a fault applies WARM_RST first, CPUs reloaded; OFF-side miss shows at the next ON; GET_STATE, INVALID_PARAM, unregistered group no reply | 9.4, 9.5, 10.5 | same; `hold_busy` (TB) | `fault`, recovery | B7, B8, B9, B11 (`[chk:CPU_RECOVER]` closes the CPU reload path; 15.2-5) |
| D10 | TL-UL from OpenTitan 16e86c9e verbatim (18 files, 3,764 lines); socket N = 2 with firewall in dev_select; tlul_adapter_sram on tc_sram port 1, port 0 on the SCP's bus; doorbell glue behind tlul_adapter_reg, sticky, SCP clears; FW regs on the SCP bus; TL_A_USER_DEFAULT, CmdIntgCheck = 0, TL_AIW 8; AP Ibex with own RAM/timer/bus, tlul_adapter_host fixed source; AP fetch = AP_RUN && !BFM; static AP/BFM mux | 4.5-4.6, 5.1, 5.2, 5.7, 7 | `soc4_mbx`, `soc4_ap`, vendor/opentitan | | B0, B2, B10, soc4 |
| D11 | pmu_top retired later, separately; until then pmu_top, scp_rpmi_mbox and 34 targets unchanged; least-churn option; deletion list | 6.1, 12 | scp_top `RPMI_MBOX` | | 11.6, 12.4 |
| D12 | mod/pd and mod/policy serve pmu_top until the deletion; platform abstraction; three images, CPU image only in the SCP image; AP reuses librpmi transport, rings, polls with timeout; SCP initialises queues; firmware rules | 9.1, 9.2, 9.7 | `soc4_plat.h`, `soc4_policy`, `ap_rpmi.c` | `ap_call` | soc4, soc4fw |
| D13 | one CPU image, behaviour by mhartid; CPU0 signature + marker + WFI loop + dump; CPU1 counting loop, never WFI, denied -> retried -> forced, restarts from boot | 9.9 | `cpu.S` | | `[chk:FULLRET_REGS]`, `[chk:CPU1_OFF]`, `[chk:CPU1_RESTART]` |
| D14 | targets soc4, soc4bfm, soc4stress, soc4neg, soc4pa, soc4bfmpa (+ soc4stresspa); probe rule; checkpoints from the AP; reuse scp_sim_ctrl CHECK/IP_CMD/IP_SEED/TB_CHECKS; stress coverage map; mutants in the repo pattern | 10, 11 | soc4_tb, Makefile | | all |
| D15 | ICPD; set_design_top instance path; VCS only; acgpdpa runs xrun (pre-existing) | 5.4, 6.6, 8.1, 6 | | | build; 11.6 |

### 14.3 Revision 2: the user's new decisions and the review fixes

| # | Item | Section | Module / file | Test / check |
|---|---|---|---|---|
| R1 | TB-only `hold_busy` on all 4 adapters, ORed into dev_quiescent_busy, tied 0 in a SoC; third stimulus source | 5.1, 5.3, 5.5, 5.6, 10.1 | `soc4_top`, `soc4_cpu_adp`, `soc4_acc_dom`, soc4_tb `tb_stim` | B6, B7, B11 |
| R2 | hold_busy for the ACC deadline miss | 10.5 | | B7 `[chk:FAULT]` |
| R3 | hold_busy + deny for a deterministic deny/retry/force | 10.5 | | B6 `[chk:DENY_FORCE]` |
| R4 | hold_busy for an OFF-side fault on CPU1; the next ON does WARM_RST + image reload | 9.4, 11.2 | `soc4_policy`, `soc4_cpu` | B11 `[chk:CPU_FAULT]`, `[chk:CPU_RECOVER]` |
| R5 | soc4stress adds REG.BYTE, REG.RO, STA.QACT, STA.MIDWRITE, EVT.PTRN1, EDT.RESTART, DLY exact + handshake, SOAK, second-hop denial; honest N/A list | 11.3 | `test/soc4_stress.c` | soc4stress RESULT lines |
| R6 | `hal/ppu_v1.*` untouched; soc4-only FULRR/MEMRR helper after pd_init; pmu images byte-identical | 6.5, 9.6 | `mod/soc4_ret.c` | 11.6 (34 unchanged), `PCSM.RAM` |
| R7 | (review 1) deadline miss by hold_busy, not START re-pulse (`ppu_ip_core.sv:127-136`) | 10.5 | | B7 |
| R8 | (review 2) mutant M3 in glue (pin miswire), not MEM_RET_RAM_REG_CFG | 5.6, 10.6 | `soc4_acc_dom` | soc4neg M3 |
| R9 | (review 3) link `rpmi_service_group_sysmsi.c` | 9.1 | soc4 fw Makefile | soc4fw |
| R10 | (review 6) LOCK_EN/PWR_DYN_EN reserved WI expectations | 11.3 | | `REG.RW`, `S.LOCKREQ`, `S.DYNREQ` |
| R11 | (review 7) warm/cold decided before the DEVREQEN re-enable | 9.4 | `soc4_policy` `vote_on` step 3 | soc4stress forced CPU0 FULL_RET then ON (`DEV.REQEN`), `[chk:FULLRET_REGS]` |
| R12 | (minors) errored fetch returns 0; probe list without u_clkctrl; retention supply on CPU0 PD_DEV; CPU_STAT.core_sleep defined; logic-loss checks; tlul_assert bound; citations | 5.4, 10.1, 8.2, 4.4, 10.4, 7.1 | | `[chk:LOGIC_LOSS]`, `[ASSERT FAILED]` gate |
| R13 | implementation stages | 16 | | stage exits |

### 14.4 The "Mapping to SOVRA" request

| Item | Section |
|---|---|
| (a) stand-ins -> SOVRA domain kinds (VtCPU/VtDSP tiles; accelerators/NPU; MEM_RET for DSP SRAM, RPU TCM, OCM) | 13.1 |
| (b) scaling: PPU count, firmware table, DOMAIN_ID, LP-mode table, IRQ lines and the aggregator | 13.2, 15.2-17 |
| (c) clkgate/tilereset ownership; CVA6/Rocket Q-Channel adapter; TL-UL to Chipyard adapter (a_user, integrity, source remapping vs the firewall); SCP boot ROM vs SW_PMU_BootROM; RoT/OTP note | 13.3 |
| power-domain partition is the SoC team's decision | 13 (opening) |

---------------------------------------------------------------------------------------------------

## 15. Risks and open items

### 15.1 Risks

| # | Risk | Mitigation |
|---|---|---|
| R1 | VCS NLP retention of CPU0's whole Ibex core: Ibex holds a `prim_clock_gating` latch and flops without reset (facts hw hazard 17); NLP may warn or mis-handle them | soc4pa runs early (stage S4). `[chk:FULLRET_REGS]` shows whether the architectural state survived. LP warnings are recorded; LP errors fail the gate |
| R2 | Run time: 1 ms hysteresis = 100k cycles per OFF, with three Ibex cores; soc4bfm B6/B7/B11 add several ms each | estimates in Section 11 (1.5-4 M cycles). policy_cfg can be shortened in a test build if needed, though that changes the product path's timing |
| R3 | soc4_stress size is an estimate (about 33 KB, more with the revision-2 additions; budget about 40 KB) | 9.10 margin; `size` printed per build; the stress may be split into two images if it exceeds 56 KB |
| R4 | The shutdown model is tc_sram's async reset held while `sd === 1` (5.4). It is behavioural and not a synthesis view | silicon uses the RAM macro's SD/SLEEP pins, as `ppu_ip_sram.sv:6-25` explains |
| R5 | dev_clk and clk_i share an edge (gated clock, later delta). The load port relies on NBA-sourced inputs | all inputs come from NBA flops (5.4); a blocking-assigned TB driver into dev_clk logic is forbidden (facts hw hazard 23) |
| R6 | Someone sets `EnableRspIntgGen = 0` on a mailbox adapter: every AP access then faults | stated in 5.2 and the vendor README rule (7.3). soc4 fails at A1; the TL-UL trial used the stated parameters |
| R7 | `hold_busy_i` leaks into a product integration untied | it is named and documented as TB-only (5.1); soc4_top's header and the SoC integration checklist say "tie to 0". A lint waiver must not hide an unconnected hold_busy_i |

### 15.2 Open items (decisions kept as given; contradictions and interpretations listed)

Closed in revision 2 (kept for the record, numbering as in revision 1):

| # | Item | Closure |
|---|---|---|
| 1 | Retention RAM registers with FULRR/MEMRR only | **Closed.** `hal/ppu_v1.*` untouched; the soc4-only `soc4_ret_ram` helper writes each present register from IDR1 after `pd_init` (6.5) |
| 3 | Fixed AP a_source applied in glue | **Closed.** Confirmed by the TL-UL trial (`build/soc4_review/mbx/`) |
| 4 | `EnableRspIntgGen = 1` on both device adapters | **Closed.** Confirmed by the TL-UL trial |
| 6 | CPU-domain FAULT recovery not injected | **Closed.** `hold_busy` on CPU1 gives an OFF-side fault, and the next ON does WARM_RST + image reload (B11, `[chk:CPU_RECOVER]`) |
| 7 | UPF supply query in VCS | **Closed.** `UPF::get_supply_on_state(UPF::get_supply_value(...))` works under W-2024.09-SP2 (`build/soc4_review/upf/d.sv`) |
| 9 | Boot state: PPU OFF rather than the LP mode | **Closed.** D3 followed; recorded as a deliberate difference from the brief |
| 10 | AP port AXI4-Lite (brief) vs TL-UL (D10) | **Closed.** D10 followed |
| 11 | "28 targets + scprpmi" (brief) vs 34 now | **Closed.** All 34 kept |
| 12 | librpmi `:119-120` cited by D9 is dead code | **Closed.** Effective lines `:300-303`, `:259-262`, `:214-217` cited; behaviour identical |
| 15 | Forced FULL_RET of CPU0 gives no wake pulse | **Closed.** The core resumes where it was frozen (5.5), and `vote_on` classifies warm before re-enabling DEVREQEN (9.4 step 3), so the retained state is not cold-booted away |
| 16 | IDR0 DEVCHAN | **Closed.** DEVCHAN = 0x1 (`REGISTERS.md:768`), checked by `check_ident` and `ID` |

Still open:

2. **Doorbell "any AP write".** Interpreted as any write, any data and any mask, to
   0x2000_1000. Writes to the rest of the doorbell page answer d_error and do not ring (4.6). If
   the literal reading (any offset rings) is wanted, `error_i` becomes 0 and the ring condition
   drops the address test.
5. **What the next ON returns after an OFF-side deadline miss.** This design answers SUCCESS if
   the recovery (WARM_RST for an ACC, the cold reload for a CPU) plus ON completes within
   on_ticks, and HW_FAULT otherwise. W4.1's Q6 behaves the same (`test/rpmi_dpwr.c:618-631`). If
   the user wants that ON to return HW_FAULT regardless, change step 7 of `vote_on`.
8. **Load-port residual window** on the way down (5.4). Closed by the firmware rule (load only in
   static WARM_RST, 9.5). The hardware could close it fully only with the PPU's internal DEVCLKEN,
   which is not a port (facts hw hazard 4).
13. **README Section 6 rule 5** ("PWR_DEVACTIVEEN is restored after every power-up",
    `pmu/README.md:396`). In soc4, PREP clears PWR_DEVACTIVEEN before each power-off, and it stays
    cleared in static ON. This is not inert. PWR_DEVACTIVEEN gates static lower-priority
    transitions: a disabled DEVACTIVE input counts as LOW (PPU 3.4.1, spec:1186-1190), and a
    static transition from ON waits for every enabled DEVQACTIVE to be LOW (PPU 3.4.2,
    spec:1272-1275). Clearing it is exactly what lets the policy *ask* a busy device (which may
    deny) instead of waiting for it (decision 8.3). Keeping it cleared in steady static ON has no
    effect until the next static request, which PREP issues with it cleared anyway. The deviation
    from rule 5 is deliberate and confined to the static steady states. soc4stress `STA.QACT`
    exercises both settings.
14. **Edits beyond D5's scp_core port**: `scp_ram` IMAGE_PLUSARG (otherwise the AP loads the SCP
    image) and `scp_sim_ctrl` TAG (otherwise both consoles print "fw|"). Both are
    backward-compatible (6.3, 6.4).
17. **Interrupt aggregator** for more PPUs than SCP fast lines (12 usable of 15): needed for the
    full chip (13.2), not for soc4.
18. **Firewall granularity.** One admitted source. Several agents, or Chipyard source remapping,
    need a source list or a preserved requester-ID sideband (13.3).
19. **Chosen constants** (not given by the decisions): AP_SOURCE = 0x10; HART_IDs AP 0x10, CPU0 0,
    CPU1 1; recover_tries N = 3; retry_cap 3, hysteresis, step and on deadlines 1 ms, back-off
    100 us (W4.1 placeholders, `policy.h:116`); CPU boot address 0x0000_0000; seeds 0x5A/0xC3; TB
    command codes 'H'/'D' on AP_CMD.
20. **Coverage after the deletion.** Dynamic transitions, lock, MEM_OFF/FUNC_RET, OFF -> MEM_RET
    direct and PCSMMODESTAT = MEM_RET move from ppu_stress to the PPU unit testbenches only
    (11.3). `PPU_FW_CONFORMANCE.md` must say so.
21. **Driver finding (new).** `ppu_set_policy(m, dyn = true)` on a PPU without dynamic support
    writes, and static m takes effect, yet it returns PPU_E_REFUSED (`S.DYNREQ`). The driver
    reads IDR1 b4-b6 all-or-nothing (`ppu_v1.c:38, 72`) against DEN Table 5-27. Neither affects
    soc4 or pmu images: soc4 never requests dyn, and retention uses the helper. Both are recorded
    for the next driver change, which the user has ruled out for now.

---------------------------------------------------------------------------------------------------

## 16. Implementation stages

Each stage ends with an exit test. A stage starts only when the previous exit test passes.
Every change is made with Bash (yes/no approvals), and nothing is committed without the user.

| Stage | Files (NEW unless marked EDIT) | Exit test |
|---|---|---|
| **S1** Vendor + RTL + lint/elab | `vendor/opentitan/tlul/*` and `prim/*` (the 18 files of 7.1, plus TB-only `tlul_assert.sv`), `vendor/opentitan/README.md` (EDIT); `soc4/rtl/{soc4_top, soc4_mbx, soc4_cpu_dom, soc4_cpu_ram, soc4_cpu_adp, soc4_acc_dom, soc4_ctrl, soc4_ap}.sv`; `pmu/rtl/scp_top.sv`, `scp_core.sv`, `scp_ram.sv` (EDIT, 6.1-6.3); `tb/pmu/scp_sim_ctrl.sv` (EDIT, 6.4); `src/Makefile` (EDIT, 6.6, plus a `soc4elab` helper target) | each new file byte-compares to the clone at 16e86c9e; `vcs ... -top soc4_top` elaborates with no Error and no ICPD; `make scphello SIM=vcs` still passes (scp_top/scp_core/scp_ram edits are neutral) |
| **S2** Firmware images build | `soc4/fw/{Makefile, soc4_plat.h, hal/soc4_regs.h, hal/soc4_db.c, mod/soc4_policy.[ch], mod/soc4_cpu.[ch], mod/soc4_ret.[ch], scp/main.c, test/soc4_stress.c, ap/ap_main.c, ap/ap_rpmi.[ch], ap/ap_env.c, cpu/cpu.S, cpu/cpu.ld, cpu/cpu_img.S}`; `pmu/fw/hal/scp_regs.h`, `mod/pd.c`, `rpmi/scp_rpmi.[ch]` (EDIT, preprocessor-only, 6.5) | `make soc4fw` builds 4 images with no warnings and prints sizes within 9.10; `make scpfw` produces **byte-identical** `.bin` files for every pmu image (cmp against a pre-change build) |
| **S3** Testbench + RTL targets | `tb/soc4/soc4_tb.sv` (BFM, monitors, IP-state rules, tlul_assert binds) | `make soc4`, `soc4bfm`, `soc4stress`, `soc4neg` pass (SIM=vcs, -licqueue); check counts recorded as the soc4 baseline; soc4neg fails each mutant exactly as 10.6 |
| **S4** UPF + PA targets | `upf/soc4_top.upf`, `upf/soc4_tb_vcs.upf`, `tb/soc4/soc4_pa_supply_vcs.sv` | `make soc4pa`, `soc4bfmpa`, `soc4stresspa` pass with LP [ERROR] = 0, the supply-net checks passing and `power intent APPLIED` |
| **S5** Full regression unchanged | none (`build/regress/run_regress.sh` untouched) | the 34 targets with counts identical to `build/merge/merge_notes.md` Section 5 (acgpdpa excluded as before), plus the 7 soc4 targets. Only then is the Section 12 deletion commit proposed |
