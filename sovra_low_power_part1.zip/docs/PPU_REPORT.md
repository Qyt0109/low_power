# Báo cáo kỹ thuật — Power Policy Unit (PPU)

| | |
|---|---|
| **Khối** | `ppu_top` / `ppu_pd_top` — Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E) |
| **Cấu hình** | Q-Channel PPU, **một** device Q-Channel (`DEVCHAN_CFG = 1`), không operating mode, không emulation mode |
| **Ngôn ngữ** | SystemVerilog-2012, tổng hợp được (synthesizable) |
| **Power intent** | IEEE 1801 (UPF) 2.1 — `src/upf/ppu_pd_top.upf` và 4 biến thể tích hợp |
| **Ngày** | 2026-09-11 · commit `971632d` |
| **Công cụ đã chạy để lập báo cáo** | Cadence Xcelium 25.09-s001 (`make ppu SIM=xcelium`, `make ppupaall`, `make lpdpdpa acgpdpa`) |

---

## 0. Tóm tắt điều hành

PPU trong repo này là **lớp chính sách nguồn (power policy)** cho một miền nguồn: phần mềm ghi một
chính sách vào thanh ghi, PPU biến nó thành một chuỗi thao tác có thứ tự trên ba giao diện —
Q-Channel tới thiết bị, năm tín hiệu điều khiển thiết bị (clock enable / isolation / ba reset), và
P-Channel tới PCSM (khối thực sự đóng-cắt nguồn).

Ba điểm định hình toàn bộ thiết kế:

1. **PPU không phát minh lại giao thức.** `qchannel_controller` và `pchannel_controller` đã có sẵn
   trong repo và được instantiate **nguyên vẹn**. Phần thiết kế mới duy nhất là bộ tuần tự
   `ppu_seq` (13 trạng thái) — đúng quan hệ kiến trúc mà PCSA mô tả.
2. **Power intent là một sản phẩm bàn giao thật, đã chạy.** Không chỉ review: toàn bộ 9 testbench
   có miền nguồn đều chạy dưới `-lps_1801` với `-simstate CORRUPT`, hai power switch thật sự mở/đóng.
3. **Mọi khẳng định đều được đo.** Kể cả ba vi phạm giao thức Q-Channel *được spec cho phép* cũng
   được đếm và assert đúng số lượng, thay vì bị tắt đi.

**Kết quả đo lại hôm nay:** `make ppu SIM=xcelium` → **584 checks, 0 errors**; `make ppupaall`
(9 suite dưới UPF) → **PASS toàn bộ**; `lpdpdpa` + `acgpdpa` → **PASS**. Chi tiết ở [§11](#11-kết-quả-kiểm-chứng-đo-ngày-2026-09-11).

---

## 1. Bối cảnh và phạm vi

### 1.1 PPU là gì trong ngăn xếp low-power

Một Q-Channel hay P-Channel chỉ trả lời câu hỏi *"thiết bị có sẵn sàng bị dừng không?"*. Nó **không**
nói "dừng" nghĩa là gì, gỡ thứ gì trước thứ gì, và làm sao quay lại. Đó chính là việc của PPU:

```
   phần mềm  ──►  ppu_regs ──policy──► ppu_seq ──┬──► qchannel_controller ══► device
                     ▲                     │     │       DEVQREQn / DEVQACCEPTn
                     │ status              │     │       / DEVQDENY / DEVQACTIVE
                     └─────────────────────┘     │
                     ▲                     │     ├──► DEVCLKEN, DEVISOLATEn,
                  ppu_irq ◄─── events ─────┘     │    DEV*RESETn, PPUHWSTAT
                     │                           │
                     └──► IRQ                    └──► pchannel_controller ══► PCSM
                                                       PCSMPSTATE / PCSMPREQ
                                                       / PCSMPACCEPT
```

Giao diện thiết bị là **Q-Channel**, giao diện PCSM là **P-Channel**. Đây là hai lựa chọn độc lập,
không mâu thuẫn: §2.2 của spec nói rõ *"The interface between the PPU and the PCSM is a P-Channel"*
bất kể giao diện thiết bị là gì. `MEM_RET`, `FULL_RET`, `FUNC_RET` đều cần P-Channel, vì retention
là việc của PCSM chứ không phải thứ Q-Channel diễn đạt được.

### 1.2 Phạm vi cấu hình, và vì sao

| Lựa chọn | Giá trị | Lý do |
|---|---|---|
| Số device channel | **1 Q-Channel** | Đây là cắt giảm lớn nhất spec cho phép, và nó cắt giảm *cái có thể tồn tại*: operating mode, `DBG_RECOV`, `LOGIC_RET` là phần mở rộng chỉ-P-Channel (§3.1.1, §3.1.2); Table 5-26 hard-wire bit hỗ trợ của chúng về 0 *"for a Q-Channel PPU"*. |
| Tập chế độ nguồn | 7 chế độ | Đúng tập Figure 3-2 dành cho Q-Channel PPU, trừ hai emulation mode tùy chọn. |
| Mức tính năng | **full-feature tier** | Mọi tính năng tùy chọn §7 đều được build, và mọi lựa chọn đều báo lại phần mềm qua `PPU_IDR0`/`IDR1`. |
| Bus phần mềm | generic strobe | §6.2.1 để IMPLEMENTATION DEFINED, APB chỉ là ví dụ. Có thêm cầu AXI4-Lite (`ppu_axi_lite_adapter`). |
| `PPU_IIDR.IMPLEMENTER` | `0x000` | Cố ý **không** dùng `0x43B` — đó là mã JEP106 của Arm, và đây không phải bản Arm cấp phép. |

Tổng kết đối chiếu spec (từ [`CONFORMANCE.md`](../src/rtl/ppu/CONFORMANCE.md)):

| Hạng mục | Số lượng |
|---|---:|
| Tính năng spec đã hiện thực **và** đã kiểm chứng | 33 |
| Hiện thực nhưng chưa có test | 0 |
| Không hiện thực — **bất khả thi về kiến trúc** với Q-Channel PPU | 8 |
| Không hiện thực — tùy chọn, mang tính cộng thêm | 3 |
| Sai lệch / đơn giản hóa đã biết | 5 |
| Không tuân thủ đã xác nhận | **8/8 đã sửa** |

---

## 2. Kiến trúc

### 2.1 Bốn giao diện

| Giao diện | Nguồn spec | Tín hiệu | Vai trò của PPU |
|---|---|---|---|
| **Software** | §6.2 | `reg_waddr/raddr[11:0]`, `reg_wdata/rdata[31:0]`, `reg_wen/ren`, `reg_wstrb[3:0]`, `irq` | slave |
| **Device** | §6.3 | `DEVQREQn`, `DEVQACCEPTn`, `DEVQDENY`, `DEVQACTIVE` | **Q-Channel controller** |
| **Device control** | §6.4 | `PPUHWSTAT[15:0]`, `DEVCLKEN`, `DEVPORESETn`, `DEVRETRESETn`, `DEVWARMRESETn`, `DEVISOLATEn` | driver |
| **PCSM** | §6.5 | `PCSMPSTATE[15:0]`, `PCSMPREQ`, `PCSMPACCEPT`, `PCSMMODESTAT[7:0]` | **P-Channel master** (không `PDENY`, không `PACTIVE`) |
| *(bổ sung)* **Clock control** `PPUCLK*` | **PCK-600 §3.6, Table A-29** — *không có* trong DEN 0051E | `ppuclk_qreqn`, `ppuclk_qacceptn`, `ppuclk_qdeny`, `ppuclk_qactive`, `pwakeup` | **Q-Channel device** |

Giao diện thứ năm là điểm đáng chú ý: nó đảo chiều vai trò. Ở giao diện thiết bị PPU là *controller*;
ở đây PPU là *device* của một clock controller nằm phía trên. Lý do tồn tại: PPU bắt buộc nằm trong
miền always-on (PCSA §7.2.2) và rỗi gần như suốt thời gian, nên clock của nó là leakage thuần giữa
các lần chuyển chế độ — và một SoC có một PPU cho mỗi miền nguồn thì có cả tá khối như vậy.

> **`PPUCLKQACTIVE` phải là dây tổ hợp, không phải flip-flop.** Clock dùng để register nó chính là
> clock nó đang xin; một khi giao diện vào `Q_STOPPED` và controller cắt clock, một `QACTIVE` đã
> flop sẽ không bao giờ lên lại được và PPU không bao giờ đánh thức được nữa. LPI Table 3-7 nói
> thẳng: *"The path from a device to the controller QACTIVE is combinatorial."* Trong RTL, biểu thức
> này tồn tại **hai bản**: bản ra chân dùng `DEVQACTIVE` **thô**, bản đi vào flop trạng thái dùng
> `sync_dev_qactive` (nếu không thì đó là một crossing không đồng bộ đi thẳng vào state enum).

### 2.2 Nguyên tắc thiết kế đáng ghi nhớ

- **`DEVQACTIVE` thuộc quyền PPU, không thuộc Q-Channel controller.**
  `ppu_top` nối `enb_qactive_led_quiescence_exit` xuống **LOW** và đưa `DEVQACTIVE` vào bộ tuần tự.
  Nếu để controller tự thoát quiescence, nó sẽ kéo giao diện ra khỏi `Q_STOPPED` trong khi nguồn còn
  chưa về — vi phạm AMBA LPI §2.1.2. Định tuyến qua chính sách biến `DEVQACTIVE` thành một **yêu cầu
  đánh thức**: sequencer khôi phục PCSM, bỏ isolation, chạy lại clock, nhả reset *rồi mới* hạ yêu cầu
  quiescence.
- **Wrapper thiết bị không bị giữ trong reset của miền.** `ppu_pd_top` cấp cho `u_dev` tín hiệu
  `aon_rst_n` đã đồng bộ sang `dclk`. Nhờ đó giao diện còn sống khi miền đã mất nguồn và một wake
  thật sự hồi sinh được nó (đo ở phase P7). Đây là nửa còn thiếu mà thiết kế Q-Channel cũ không làm
  được một mình.
- **PPU đồng bộ lại những tín hiệu mà controller đã đồng bộ.** `qchannel_controller` giữ kết quả
  đồng bộ của nó ở dạng private; ba hộ tiêu thụ ở đây cần nó (`PPU_DISR`/`PPU_MISR`, bộ dò cạnh của
  `ppu_irq`, và `ppu_seq`). Thêm bộ đồng bộ độc lập là cách chuẩn để làm CDC nhiều hộ tiêu thụ — rẻ
  hơn nhiều so với sửa một khối đã verified mà hai top-level khác đang dùng.

---

## 3. Phân cấp thiết kế (hierarchy)

### 3.1 Cây phân cấp của DUT chính `ppu_pd_top`

```
ppu_pd_top                                     ← miền nguồn hoàn chỉnh (DUT chính)
├── u_ppu        : ppu_top                     PPU          [aon_clk, PD_AON]
│   ├── u_regs   : ppu_regs                    tệp thanh ghi Chapter 5
│   ├── u_irq    : ppu_irq                     IMR/AIMR/ISR/AISR/IESR
│   ├── u_seq    : ppu_seq                     ★ bộ tuần tự chế độ (13 trạng thái)
│   ├── u_clkq   : qchannel_device_comb        PPUCLK* — PPU đóng vai device
│   ├── u_devq   : qchannel_controller         giao diện thiết bị (dùng lại nguyên vẹn)
│   └── u_pcsm   : pchannel_controller         giao diện PCSM  (dùng lại nguyên vẹn)
├── u_pcsm       : ppu_pcsm                    PCSM         [aon_clk, PD_AON]
├── u_wrap_rst   : rst_sync                    reset wrapper, độc lập với miền  [PD_AON]
├── u_dev        : qchannel_device             device wrapper  [dclk, PD_AON]
├── u_clken_sync : cdc_sync                    DEVCLKEN → dclk [PD_AON]
├── u_wl_rst     : rst_sync                    PORESETn & WARMRESETn → dclk
├── u_ret_rst    : rst_sync                    PORESETn & RETRESETn  → dclk
├── u_clkctrl    : clk_gate                    ICG            [**PD_DEV**]
└── u_ip         : ppu_device_ip               thiết bị được điều khiển
    ├── u_core       : ppu_ip_core             logic không retain  [**PD_DEV**]
    ├── u_ret        : ppu_ip_ret              logic có retain     [**PD_DEV** + set_retention]
    └── g_bank[0..7].u_bank : ppu_ip_sram      8 bank SRAM  [rail always-on, chân sleep/shutdown]
```

Ký hiệu `[PD_AON]` / `[PD_DEV]` là miền nguồn UPF — xem [§9](#9-upf-power-intent).

### 3.2 Bảng module

| Module | File | Vai trò |
|---|---|---|
| `ppu_pkg` | [`ppu_pkg.sv`](../src/rtl/ppu/ppu_pkg.sv) | mã hóa chế độ, bảng tra device-control (Table 4-7/4-9/4-11), mã `PPUHWSTAT`/`PCSMPSTATE`, offset thanh ghi, giải mã hỗ trợ |
| `ppu_regs` | [`ppu_regs.sv`](../src/rtl/ppu/ppu_regs.sv) | tệp thanh ghi; sở hữu nơi **duy nhất** một lệnh ghi có thể bị từ chối |
| `ppu_irq` | [`ppu_irq.sv`](../src/rtl/ppu/ppu_irq.sv) | trọng tài set/clear của các bit trạng thái ngắt |
| `ppu_seq` | [`ppu_seq.sv`](../src/rtl/ppu/ppu_seq.sv) | **bộ tuần tự chế độ** — phần thiết kế mới duy nhất |
| `ppu_top` | [`ppu_top.sv`](../src/rtl/ppu/ppu_top.sv) | PPU: ba khối trên + hai protocol engine dùng lại |
| `ppu_pcsm` | [`ppu_pcsm.sv`](../src/rtl/ppu/ppu_pcsm.sv) | mô hình PCSM — đầu device P-Channel + giải mã actuation Table 3-1 |
| `ppu_monitor` | [`ppu_monitor.sv`](../src/rtl/ppu/ppu_monitor.sv) | monitor giao thức cho **luật riêng của PPU** (`U1`–`U12`), mù với sequencer |
| `ppu_device_ip` | [`ppu_device_ip.sv`](../src/rtl/ppu/ppu_device_ip.sv) | thiết bị được điều khiển: 3 lớp trạng thái để mọi chế độ đều phân biệt được |
| `ppu_clk_ctrl` | [`ppu_clk_ctrl.sv`](../src/rtl/ppu/ppu_clk_ctrl.sv) | clock controller kiểu PCK-600 CLK-CTRL: 1–8 device Q-Channel, 0–32 veto QACTIVE-only |
| `ppu_axi_lite_adapter` | [`ppu_axi_lite_adapter.sv`](../src/rtl/ppu/ppu_axi_lite_adapter.sv) | AXI4-Lite → generic strobe, có `PWAKEUP` và khóa liên động clock |
| `qchannel_device_comb` | [`qchannel_device_comb.sv`](../src/rtl/qchannel/qchannel_device_comb.sv) | FSM device Q-Channel cho giao diện *clock*: `QACCEPTn`/`QDENY` có flop, `QACTIVE` **tổ hợp** |
| `rst_sync`, `cdc_sync`, `clk_gate` | [`rtl/common/`](../src/rtl/common/) | hạ tầng dùng chung |

### 3.3 Năm top-level tích hợp

Cùng một `ppu_top`, đặt vào năm bối cảnh khác nhau. Mỗi cái đóng một khoảng trống mà cái trước
không chạm tới:

| Top | File | Thêm gì | Câu hỏi nó trả lời |
|---|---|---|---|
| `ppu_pd_top` | [`ppu_pd_top.sv`](../src/rtl/ppu/ppu_pd_top.sv) | PPU + PCSM + wrapper + device IP | Miền nguồn cơ sở. Đây là DUT của phần lớn testbench và là nơi UPF gắn vào. |
| `ppu_clkq_top` | [`ppu_clkq_top.sv`](../src/rtl/ppu/ppu_clkq_top.sv) | `ppu_clk_ctrl` + ICG phía trên | Clock **của chính PPU** bị cắt khi PPU rỗi. Chứng minh clock gating và power gating không can thiệp nhau. |
| `ppu_axi_pd_top` | [`ppu_axi_pd_top.sv`](../src/rtl/ppu/ppu_axi_pd_top.sv) | AXI4-Lite + clock gate + miền nguồn | Ba thứ cùng lúc: phần mềm qua AXI, clock PPU đã dừng, miền nó quản lý đã mất nguồn. |
| `ppu_lpd_pd_top` | [`ppu_lpd_pd_top.sv`](../src/rtl/ppu/ppu_lpd_pd_top.sv) | `qchannel_lpd` phân phối 1 Q-Channel ra N thiết bị | Một miền **nhiều thiết bị** mà **không đụng vào `ppu_seq`**. Hai chế độ PCK-600: expander và sequencer. |
| `ppu_acg_pd_top` | [`ppu_acg_pd_top.sv`](../src/rtl/ppu/ppu_acg_pd_top.sv) | access control gate trên TL-UL (OpenTitan `tlul_lc_gate` vendored) | PCSA §4.2.10: giao dịch tới một miền **đã mất nguồn** bị *stall* chứ không fail, kéo `DEVQACTIVE`, PPU tự khôi phục miền, giao dịch hoàn tất — không có phần mềm nào trên đường đó. |

---

## 4. Mô hình chế độ nguồn và trình tự

### 4.1 Bảy chế độ

| Power Mode | Logic | RAM | `PWR_POLICY[3:0]` | `PCSMPSTATE[3:0]` | `PPUHWSTAT` | Ưu tiên |
|---|---|---|---|---|---|---|
| `WARM_RST` | ON | ON | `0b1001` (9) | `0b1000`ᵃ | bit 9 | Cao |
| `ON`       | ON | ON | `0b1000` (8) | `0b1000` | bit 8 | │ |
| `FUNC_RET` | ON | RET | `0b0111` (7) | `0b0111` | bit 7 | │ |
| `MEM_OFF`  | ON | OFF | `0b0110` (6) | `0b0110` | bit 6 | │ |
| `FULL_RET` | RET | RET | `0b0101` (5) | `0b0101` | bit 5 | │ |
| `MEM_RET`  | OFF | RET | `0b0010` (2) | `0b0010` | bit 2 | │ |
| `OFF`      | OFF | OFF | `0b0000` (0) | `0b0000` | bit 0 | Thấp |

ᵃ Ở `WARM_RST`, PPU yêu cầu PCSM giữ đúng điều kiện của `ON` (Table 3-2 chú thích a — PCSM không có
khái niệm warm reset, chỉ giao diện thiết bị mới có). Chính phép thay thế đó làm cho `ON ↔ WARM_RST`
là một chuyển đổi **không có handshake PCSM nào cả**: trạng thái yêu cầu không đổi nên không có gì
để yêu cầu.

**Ưu tiên *chính là* mã hóa:** `OFF(0) < MEM_RET(2) < FULL_RET(5) < MEM_OFF(6) < FUNC_RET(7) < ON(8) < WARM_RST(9)`.
Vì thế câu hỏi "đây có phải chuyển xuống chế độ ưu tiên thấp hơn không?" là một phép so sánh độ lớn
thuần túy, và trong RTL không có bảng tra ưu tiên riêng nào.

Các giá trị `1` (`OFF_EMU`), `3` (`MEM_RET_EMU`), `4` (`LOGIC_RET`), `10` (`DBG_RECOV`) và `11`–`15`
được **giải mã để từ chối**: ghi vào để nguyên `PPU_PWPR` và dựng `UNSPT_POLICY_IRQ` (§4.1.1).

### 4.2 Đồ thị chuyển đổi

§3.3.2, nguyên văn: *"Although multiple power modes are supported with a Q-Channel PPU it only
transitions between ON and the power mode programmed in the PPU_PWPR register."* Mọi bước nhảy đều
có `ON` ở một đầu, nên đồ thị co lại thành **một quyết định** thay vì một bảng:

```
ON(8) <──────────► WARM_RST(9)   handshake tùy chọn (PPU_PTCR.WARM_RST_DEVREQEN)
ON(8) <──────────► FUNC_RET(7)   handshake thiết bị + PCSM đầy đủ
ON(8) <──────────► MEM_OFF(6)
ON(8) <──────────► FULL_RET(5)
ON(8) <──────────► MEM_RET(2)
ON(8) <──────────► OFF(0)

OFF(0) ──────────► MEM_RET(2)    MỘT CHIỀU. Chỉ PCSM, không handshake thiết bị
```

`FULL_RET → MEM_OFF` là `FULL_RET → ON → MEM_OFF`: hai chuỗi device-control liên tiếp, và phase P4
đếm số handshake để chứng minh. Lối tắt `OFF → MEM_RET` là **một chiều**: Table 4-14 chỉ cho
`MEM_RET` đúng một end mode là `ON`.

**Static vs dynamic:**

- Static (`PWR_DYN_EN = 0`): `PWR_POLICY` là đích.
- Dynamic (`PWR_DYN_EN = 1`, §3.4.3): chính sách là một **ngưỡng tối thiểu**. Ở `ON`, tất cả
  `DEVQACTIVE` đã bật đều LOW → chuyển xuống chính sách; ở chế độ chính sách, bất kỳ `DEVQACTIVE` nào
  HIGH → chuyển về `ON`. `WARM_RST` bị loại hoàn toàn — luôn static.

Cả hai chiều gói gọn trong một biểu thức của `ppu_seq`:

```systemverilog
if (locked_q)          final_tgt = cur_mode;
else if (dyn_status_q) final_tgt = qactive_eff ? PM_ON : pwr_policy;
else                   final_tgt = pwr_policy;
```

**Lock (§3.4.3):** khi cả `LOCK_EN` và `PWR_DYN_EN` được set, chạm tới chế độ khóa được (`OFF` hoặc
`MEM_RET`) sẽ ghim PPU ở đó *"even if the DEVACTIVE inputs, or software set minimum policy, are
requesting a higher priority power mode"*, cho tới khi ghi `PPU_UNLK.UNLOCK` hoặc xóa một trong hai
enable.

### 4.3 Giá trị device control theo chế độ

| Power Mode | `DEVPORESETn` | `DEVWARMRESETn` | `DEVRETRESETn` | `DEVCLKEN` | `DEVISOLATEn` |
|---|---|---|---|---|---|
| `WARM_RST` | 1 | **0** | **0** | 1 | 1 |
| `ON`       | 1 | 1 | 1 | 1 | 1 |
| `FUNC_RET` | 1 | 1 | 1 | 1 | 1 |
| `MEM_OFF`  | 1 | 1 | 1 | 1 | 1 |
| `FULL_RET` | 1 | **0** | 1 | **0** | **0** |
| `MEM_RET`  | **0** | **0** | **0** | **0** | **0** |
| `OFF`      | **0** | **0** | **0** | **0** | **0** |

Hai hàng chỉ assert *một* warm reset gần như đối nghịch nhau và rất dễ chép nhầm sang nhau — điều
đã thực sự xảy ra một lần và được ghi lại thành F1 trong `CONFORMANCE.md`. Table 4-8 phân biệt:
`DEVWARMRESETn` là warm reset cho thanh ghi **không retain**, `DEVRETRESETn` cho thanh ghi **có retain**.

- **`FULL_RET`** chỉ assert `DEVWARMRESETn`: logic không retain được reset trong khi thanh ghi retain
  vẫn sống trên rail retention. Một chế độ reset một số flop và không reset số khác chỉ có nghĩa
  nếu có flop thật sự retain — đây chính là lý do UPF phải mang chiến lược retention.
- **`WARM_RST`** assert **cả hai**, vì warm reset một component thì reset toàn bộ trạng thái của nó.

`FUNC_RET` và `MEM_OFF` dùng chung nguyên hàng của `ON`. Toàn bộ khác biệt giữa chúng và `ON` nằm ở
giao diện PCSM.

### 4.4 Thứ tự tuần tự (§4.1.5)

**Rời `ON`** — handshake thiết bị trước, *rồi*:

1. Hạ clock enable
2. Assert isolation, sau `CLKEN_ISO_DLY` chu kỳ
3. Assert reset, sau `ISO_RST_DLY` chu kỳ
4. Handshake PCSM tới `PCSMPSTATE` của đích

**Về `ON`** — handshake PCSM trước, *rồi*:

1. Bỏ isolation
2. Bật clock enable, sau `ISO_CLKEN_DLY` chu kỳ
3. Nhả reset, sau `CLKEN_RST_DLY` chu kỳ
4. Handshake thiết bị để thoát quiescence, song song với
5. Cập nhật `PPUHWSTAT`, sau `RST_HWSTAT_DLY` chu kỳ **và** handshake thiết bị hoàn tất — Table 4-5
   nói rõ delay này *"also dependant on the completion of the device interface"*

Mỗi delay là *"minimum cycles = N + 1"*, nên 0 là hợp lệ và nghĩa là một chu kỳ. `ON → WARM_RST` dùng
thứ tự *khởi hành* mặc dù `WARM_RST` ưu tiên cao hơn `ON` (Figure 4-26) — cái quyết định thứ tự là
**đầu nào của bước nhảy là `ON`**, không phải chế độ nào ưu tiên cao hơn. Một phép so ưu tiên sẽ sai
đúng ở ca này.

### 4.5 Bộ tuần tự `ppu_seq` — 13 trạng thái

```
S_IDLE ──► S_DELAY ──► S_DN_QREQ ──► S_DN_CLKEN ──► S_DN_ISO ──► S_DN_RST ──► S_DN_PCSM
              (entry       │ bị từ chối                                             │
               delay)      ▼                                                        │
                        S_DENIED ─────────────────────────────────────────────┐     │
                                                                              ▼     ▼
S_IDLE ◄── S_UP_RST ◄── S_UP_CLKEN ◄── S_UP_ISO ◄── S_UP_PCSM ◄── S_IDLE    S_IDLE

S_IDLE ──► S_PCSM_ONLY ──► S_IDLE      (OFF → MEM_RET: chỉ handshake PCSM, không gì khác)
```

Hai thứ tự của §4.1.5 là **hai chuỗi trạng thái tách biệt**, không phải một chuỗi chung có cờ hướng:
chúng chỉ đảo ngược nhau ở *tên tín hiệu*, không ở *cái mà mỗi bước chờ đợi*, và gộp lại sẽ giấu mất
điều đó.

**Chuỗi device control được đi qua vô điều kiện**, kể cả ở những bước nhảy mà một tín hiệu cụ thể
không đổi giá trị (`ON ↔ FUNC_RET` là no-op hoàn toàn trên dây). Đây là chủ ý: bỏ bước sẽ khiến
timing quan sát được của một chuyển đổi phụ thuộc vào cặp chế độ nào đang nối — khó verify hơn nhiều
so với "chuỗi luôn cùng một hình dạng", và Table 4-5 chỉ ràng buộc khoảng cách *tối thiểu* mà một
delay thừa không thể vi phạm.

### 4.6 Đường từ chối (denial)

Một chuyển đổi Q-Channel lên chế độ ưu tiên cao hơn **không thể bị từ chối**, và ở đường khởi hành
handshake thiết bị chạy *trước* mọi device control. Đây là phát biểu của chính spec PPU, §4.2.9: *"Q-Channel PPU transitions to higher
priority power modes, except for those to warm reset, cannot be denied."* Cũng trong mục đó,
Figure 4-36 cho thấy một P-Channel PPU *bị* từ chối ở `FULL_RET → ON`.
Cái làm nó đúng ở đây là AMBA LPI (ARM IHI 0068C) Table 2-1: `Q_DENIED` chỉ tới được từ `Q_REQUEST`,
và đường thoát `Q_STOPPED → Q_EXIT → Q_RUN` không có trạng thái từ chối nào.

Hệ quả: trạng thái duy nhất có thể thấy `DEVQDENY` là `S_DN_QREQ`, và lúc đó chưa có gì được tuần tự.
Vì vậy câu *"reverse whatever device controls were already sequenced"* của §4.1.1 trở thành vô nghĩa
ở đây — không có gì để đảo, và P5 kiểm tra rằng không clock/isolation/reset nào bị chạm. Việc đường
từ chối thực sự làm là nửa còn lại của §4.1.1: khôi phục `PWR_POLICY` về chế độ hiện tại theo
Table 4-1, dựng sự kiện từ chối, và chờ Q-Channel tự hồi phục `Q_DENIED → Q_CONTINUE → Q_RUN` trước
khi về idle.

---

## 5. Programmer's model

### 5.1 Bản đồ thanh ghi

| Offset | Tên | Access | Ghi chú |
|---|---|---|---|
| `0x000` | `PPU_PWPR` | R/W | `[12]` `LOCK_EN`, `[8]` `PWR_DYN_EN`, `[3:0]` `PWR_POLICY`. Thanh ghi **duy nhất** mà lệnh ghi có thể bị từ chối |
| `0x004` | `PPU_PMER` | — | **Reserved**: không có emulation mode |
| `0x008` | `PPU_PWSR` | RO | `[12]` `LOCK_STATUS`, `[8]` `PWR_DYN_STATUS`, `[3:0]` `PWR_STATUS` |
| `0x010` | `PPU_DISR` | RO | `[0]` trạng thái `DEVQACTIVE`; một kênh nên `[10:1]` reserved |
| `0x014` | `PPU_MISR` | RO | `[16]` `DEVQDENY`, `[8]` `DEVQACCEPTn`, `[0]` `PCSMPACCEPT` — giá trị chân, không phải nghĩa đã giải mã |
| `0x018` | `PPU_STSR` | — | **Reserved** (§5.2.6, một Q-Channel) |
| `0x01C` | `PPU_UNLK` | WO | `[0]` `UNLOCK`; đọc ra 0 |
| `0x020` | `PPU_PWCR` | R/W | `[8]` `PWR_DEVACTIVEEN[0]`, `[0]` `DEVREQEN[0]`; cả hai reset HIGH |
| `0x024` | `PPU_PTCR` | R/W | `[0]` `WARM_RST_DEVREQEN` |
| `0x030` | `PPU_IMR` | R/W | `[5]` `LOCKED`, `[2]` `STA_DENY`, `[1]` `STA_ACCEPT`, `[0]` `STA_POLICY_TRN` |
| `0x034` | `PPU_AIMR` | R/W | `[2]` `DYN_DENY`, `[1]` `DYN_ACCEPT`, `[0]` `UNSPT_POLICY` |
| `0x038` | `PPU_ISR` | R/W1C | gương của `PPU_IMR`, thêm `[8]` input edge và `[7]` `OTHER_IRQ` (dẫn xuất) |
| `0x03C` | `PPU_AISR` | R/W1C | gương của `PPU_AIMR` |
| `0x040` | `PPU_IESR` | R/W | `[1:0]` `DEVACTIVE00_EDGE` |
| `0x044` | `PPU_OPSR` | — | **Reserved**: operating mode chỉ có ở P-Channel |
| `0x050`/`0x054`/`0x058` | `PPU_FUNRR`/`FULRR`/`MEMRR` | R/W | `[7:0]` → `PCSMPSTATE[15:8]` ở chế độ tương ứng |
| `0x160`/`0x164` | `PPU_EDTR0`/`EDTR1` | R/W | bộ định thời trễ vào chế độ |
| `0x170`/`0x174` | `PPU_DCDR0`/`DCDR1` | R/W | năm trễ device control |
| `0xFB0` | `PPU_IDR0` | RO | `0x1E53_E501` cho build này |
| `0xFB4` | `PPU_IDR1` | RO | `0x0000_1077` cho build này |
| `0xFC8` | `PPU_IIDR` | RO | `0x50C0_1000` — `IMPLEMENTER = 0x000` |
| `0xFCC` | `PPU_AIDR` | RO | `0x0000_0011` — kiến trúc v1.1 |

Thanh ghi reserved *do cấu trúc* được **giải mã rồi bỏ** thay vì rơi vào nhánh default, để một truy
cập vào chúng nhìn thấy rõ là "thanh ghi PPU này không có" chứ không lẫn với một địa chỉ gõ sai.
Mọi bit reserved là WI/RAZ (§5.2).

`reg_waddr` và `reg_raddr` là **hai bus riêng**, không phải một địa chỉ kèm bit hướng: AXI4-Lite
không đặt thứ tự giữa AW/W/B và AR/R, nên một cầu nối có thể có một write và một read cùng outstanding.
Hai bus riêng làm bộ giải mã chạy hai lần và cầu nối không cần trọng tài nào.

### 5.2 Ba luật chi phối toàn bộ logic ngắt

1. **Mask chặn *bit trạng thái*, không chỉ chặn output** (§5.2.10) — mask là một phép AND trên số hạng
   *set*. Bỏ mask sau đó **không** làm sống lại một sự kiện đã xảy ra lúc đang bị mask.
2. **Set thắng clear trong cùng chu kỳ** (§4.1.2) — *"If an event is cleared in the same cycle that
   it re-occurs the interrupt status stays HIGH."*
3. **`OTHER_IRQ` là dẫn xuất, không bao giờ lưu** (§5.2.12) — nó là phép OR sống của `PPU_AISR`, nên
   không bao giờ có thể mâu thuẫn với thanh ghi mà nó tóm tắt.

---

## 6. Miền clock, reset và CDC

| Miền | Nội dung | Ghi chú |
|---|---|---|
| `aon_clk` | `ppu_top` (toàn bộ), `ppu_pcsm` | Miền của PPU. P-Channel PCSM có **cả hai đầu** ở đây |
| `dclk` | `qchannel_device` wrapper, ba `rst_sync`, `cdc_sync` của DEVCLKEN, ICG, device IP | Miền của thiết bị |

**P-Channel PCSM không phải là một crossing.** `ppu_pd_top` nối cả `u_ppu` và `u_pcsm` vào `aon_clk`,
nên `PCSM_SYNC_EN = 0` và `cdc_sync` với `STAGES = 0` trở thành passthrough — tiết kiệm 4 chu kỳ cho
mỗi handshake PCSM (mà mọi chuyển chế độ đều có ít nhất một) cùng khoảng mười flop. Đây là **tham số
chứ không phải hằng số**, vì PCSA §7.2.3 ràng buộc *miền nguồn* của PCSM chứ không nói gì về clock:
một integration khác hoàn toàn có quyền cấp clock riêng cho PCSM.

**Giao diện thiết bị giữ nguyên bộ đồng bộ** — `u_dev` chạy trên `dclk` và là crossing bất đồng bộ
thực sự duy nhất của thiết kế. PCSA §7.1.3 khuyến nghị phân vùng miền clock *"at either asynchronous
boundaries or at other natural divergences in the clock tree such as a power domain boundary"* — đúng
chỗ crossing này nằm.

**Hai đường reset thiết bị, không phải một:**

```
dev_rst_in_n     = DEVPORESETn & DEVWARMRESETn   → u_wl_rst  → u_ip/u_core   (không retain)
dev_ret_rst_in_n = DEVPORESETn & DEVRETRESETn    → u_ret_rst → u_ip/u_ret    (có retain)
```

Hàng `FULL_RET` là lý do cặp này tồn tại: PORESETn=1, WARMRESETn=0, RETRESETn=1 → tích thứ nhất là 0,
tích thứ hai là 1. Mọi chế độ khác lái hai tích giống nhau.

**Quét tỉ số clock đã được đo**, vì §4.1.5 nói thẳng *"allowances must be made for differences in clock
frequencies between the PPU and the controlled device"* — mọi device-control delay đếm bằng chu kỳ
**PPU** trong khi thứ bị giãn cách sống trong miền **thiết bị**:

| `aon_clk` | `dclk` | Tỉ số | Kết quả |
|---|---|---|---|
| 4.30 ns | 13.70 ns | 3.19 | PASS |
| 2.00 ns | 20.00 ns | 10.00 | PASS |
| 10.00 ns | 11.00 ns | 1.10 | PASS |
| 20.00 ns | 3.00 ns | **0.15** — PPU chậm hơn 6.7× | PASS |

Cùng một chuyển đổi tốn **30 chu kỳ PPU ở tỉ số chậm và 67 ở tỉ số nhanh** — đúng như kỳ vọng, vì
handshake thiết bị tốn một số cố định chu kỳ *thiết bị*. Hành vi độc lập với tỉ số; chỉ độ trễ dịch
chuyển.

---

## 7. Thiết bị được điều khiển và PCSM

### 7.1 `ppu_device_ip` — vì sao nó phải tồn tại

`dummy_workload` trước đây chỉ là một bộ đếm với cờ busy: đủ để đàm phán Q-Channel và không gì khác.
Hệ quả đáng nói thẳng: **dưới PCSM, sáu trong bảy chế độ nguồn là cùng một thứ.** Nó không có RAM nên
ba thanh ghi `PPU_FUNRR`/`FULRR`/`MEMRR` không chạm tới gì; nó không có trạng thái retain nên
`FULL_RET` không phân biệt được với `MEM_RET`.

`ppu_device_ip` giữ **ba lớp trạng thái sống sót qua những thứ khác nhau**:

| Chế độ | `u_core` (không retain) | `u_ret` (retain) | bank, `cfg`=1 | bank, `cfg`=0 |
|---|---|---|---|---|
| `ON` | giữ | giữ | giữ | giữ |
| `WARM_RST` | reset | reset | giữ | giữ |
| `FUNC_RET` | giữ | giữ | giữ | **mất** |
| `MEM_OFF` | giữ | giữ | **mất** | **mất** |
| `FULL_RET` | **reset** | giữ | giữ | **mất** |
| `MEM_RET` | corrupt | corrupt | giữ | **mất** |
| `OFF` | corrupt | corrupt | **mất** | **mất** |

Không hai hàng nào giống nhau. Đó là toàn bộ thiết kế của khối này. Phase P23a đi hết sáu hàng
non-`ON` và kiểm tra cả bốn cột của mỗi hàng.

### 7.2 RAM **không** nằm trong miền chuyển mạch

Tám bank SRAM bị **loại khỏi `PD_DEV`**. Chúng nằm trên rail always-on và `ppu_pcsm` lái chân
`sleep`/`shutdown` của từng bank. Đây là mô hình **trung thực**, không phải lối tắt:

- Một SRAM biên dịch sẵn **không** bị power-gate bởi switch của rail standard-cell; nó có chân điều
  khiển riêng, và model của memory compiler hiện thực chúng.
- Đưa mảng vào miền chuyển mạch sẽ **sai một cách chủ động**: `MEM_RET` là "Logic OFF, RAM RET", nên
  `-simstate CORRUPT` sẽ phá hủy bộ nhớ đúng ở chế độ mà định nghĩa của nó là *sống sót* — và
  transcript vẫn trông đúng, vì PPU tuần tự chế độ đó y hệt trong cả hai trường hợp.

`ram_cfg` chính là `PCSMPSTATE[15:8]`, thứ mà spec để IMPLEMENTATION DEFINED. Thiết kế này định nghĩa
nó là một bit cho phép retention cho mỗi bank.

### 7.3 Ba lỗi mà IP mới phơi ra

Cả ba đều vô hình với mọi kiểm tra tồn tại trước nó, và cả ba cùng một hình dạng: **một điều khiển
trông đúng ở trạng thái đã ổn định và sai trong lúc chuyển tiếp.**

1. **Chân shutdown của SRAM glitch ở mỗi lần đổi chế độ.** Giải mã `sleep`/`shutdown` từ ba phép gán
   liên tục off một thanh ghi khiến chúng ổn định ở ba delta cycle khác nhau, làm số hạng shutdown
   đúng trong chốc lát cho đúng những bank mà chế độ đó sinh ra để giữ. Đo được: bank 0 giữ
   `0xe2a55a5a` trước chuyển đổi `ON`→`FUNC_RET` và `X` ngay sau đó. Sửa bằng cách tính và
   **register** cả hai chân trong `ppu_pcsm`.
2. **Chiến lược retention chưa bao giờ save.** `-save_signal {u_ppu/dev_retresetn negedge}` được chọn
   vì Table 4-8 gọi `DEVRETRESETn` là reset của thanh ghi retention — nhưng Table 4-9 để nó **HIGH
   suốt `FULL_RET`**. Một save signal không có cạnh thì không bao giờ save. Điều khiển đúng là một
   output của PCSM (`ret_n`): Figure 4-1 cho thấy PPU **không có** save/restore trong các output
   thiết bị của nó, và PCSM lái thứ mà hình vẽ gọi là *technology specific controls*.
3. **Rail retention không make-before-break.** `SW_LOGIC` mở trước khi `SW_RET` đóng, `VDD_RET` vắng
   mặt trong chốc lát — đủ lâu để `SS_RET` khớp trạng thái `CORRUPT` và phá hủy đúng giá trị vừa
   được lưu. Rút gọn được thành một testcase 40 dòng.

Lỗi thứ ba cũng sửa luôn một luật trong power model: `PU7` từng đọc là "hai nguồn không bao giờ bật
cùng lúc", điều *tình cờ* đúng khi hai tín hiệu là hai decode loại trừ nhau — nó phát biểu lại phép
decode thay vì kiểm tra một hazard, và nó cấm đúng cái thứ tự an toàn duy nhất.

---

## 8. Testbench và môi trường kiểm chứng

### 8.1 Danh mục testbench

| Suite | File | Nội dung |
|---|---|---|
| `ppu` | [`ppu_pd_tb.sv`](../src/tb/ppu/ppu_pd_tb.sv) | **Suite chính**: các phase P0–P34 (P26 là phase ngẫu nhiên có ràng buộc), 584 checks |
| `ppuneg` | [`ppu_monitor_negtest.sv`](../src/tb/ppu/ppu_monitor_negtest.sv) | Negative test của `ppu_monitor`: mỗi luật bị vi phạm có chủ đích một lần |
| `ppurst` | [`ppu_reset_tb.sv`](../src/tb/ppu/ppu_reset_tb.sv) | Table 4-13 — hành vi **nhả reset**, 5 DUT vì cả hai input quyết định đều là elaboration-time |
| `ppurstf` | [`ppu_rstflight_tb.sv`](../src/tb/ppu/ppu_rstflight_tb.sv) | Assert `RESETn` **giữa** chuyển đổi, quét 1–60 chu kỳ × 3 đích = 180 lần |
| `ppuratio` | [`ppu_clkratio_tb.sv`](../src/tb/ppu/ppu_clkratio_tb.sv) | Bốn tỉ số clock PPU:device từ 10× nhanh tới 6.7× chậm |
| `ppucfg` | [`ppu_minconfig_tb.sv`](../src/tb/ppu/ppu_minconfig_tb.sv) | Build rút gọn theo Chapter 7: 5 DUT (`u_max`, `u_min`, `u_nlk`, `u_nofr`, `u_mix`) trên **một** bus chung |
| `ppuirq` | [`ppu_irq_tb.sv`](../src/tb/ppu/ppu_irq_tb.sv) | Unit test `ppu_irq`: luật §4.1.2 chính xác đến chu kỳ |
| `ppupm` | [`ppu_pm_tb.sv`](../src/tb/ppu/ppu_pm_tb.sv) | Unit test `ppu_power_model`: một lỗi có chủ đích cho mỗi luật PU |
| `ppube` | [`ppu_be_tb.sv`](../src/tb/ppu/ppu_be_tb.sv) | Byte-lane write strobe — suite **duy nhất** ghi với lane bị mask |
| `ppudeny` | [`ppu_deny_tb.sv`](../src/tb/ppu/ppu_deny_tb.sv) | Đường từ chối ở mức unit của `ppu_seq`. Tìm ra **F10** |
| `ppudevif` | [`ppu_devif_tb.sv`](../src/tb/ppu/ppu_devif_tb.sv) | Tương tác PPU ↔ thiết bị, tổ chức theo **câu phát biểu của spec** thay vì theo hành vi |
| `ppuregdoc` | [`ppu_regdoc_tb.sv`](../src/tb/ppu/ppu_regdoc_tb.sv) | Kiểm mọi khẳng định hành vi trong `REGISTERS.md` |
| `ppuclkctrl` | [`ppu_clkctrl_tb.sv`](../src/tb/ppu/ppu_clkctrl_tb.sv) | Unit test clock controller (PCK-600 CLK-CTRL) |
| `ppuclkq` | [`ppu_clkq_tb.sv`](../src/tb/ppu/ppu_clkq_tb.sv) | Q-Channel clock của chính PPU, end-to-end, 2 DUT |
| `ppuaxi` | [`ppu_axi_lite_tb.sv`](../src/tb/ppu/ppu_axi_lite_tb.sv) | Giao diện AXI4-Lite, kích thích bằng **VIP AXI của pulp-platform** |
| `lpdpd` | [`ppu_lpd_pd_tb.sv`](../src/tb/ppu/ppu_lpd_pd_tb.sv) | Một PPU, một LPD-Q, N thiết bị |
| `acgpd` | [`ppu_acg_pd_tb.sv`](../src/tb/acg/ppu_acg_pd_tb.sv) | Access control gate trong một miền nguồn thật |
| `ppudemo` | [`ppu_demo_tb.sv`](../src/tb/ppu/ppu_demo_tb.sv) | Tour hướng dẫn: mỗi tính năng một lần, dựng để **xem trên waveform** |

### 8.2 Ba bộ kiểm tra chạy xuyên suốt

| Checker | Luật | Nhìn thấy gì |
|---|---|---|
| `qchannel_monitor` | `R1`–`R10` | Giao thức AMBA LPI trên dây Q-Channel |
| `ppu_monitor` | `U1`–`U12` | Luật kiến trúc **của riêng PPU** — mù với sequencer, chỉ thấy `PPUHWSTAT`, năm device control, PCSM request và dây Q-Channel, đúng như một khối hàng xóm nhìn thấy |
| `ppu_power_model` | `PU1`–`PU10` | Đối tác plain-sim của power intent: mô hình hóa `create_power_switch`, `-simstate CORRUPT`, `set_isolation`, `set_retention` theo hành vi |

Luật của `ppu_monitor`:

| Luật | Tính chất | Spec |
|---|---|---|
| `U1` | `PPUHWSTAT` luôn one-hot | §4.1.4 |
| `U2` | `PPUHWSTAT` chỉ mã hóa chế độ được hỗ trợ | Table 3-2 |
| `U3` | khi đã ổn định, năm điều khiển khớp chế độ mà `PPUHWSTAT` báo | Tables 4-7/4-9/4-11 |
| `U4` | `DEVISOLATEn` chỉ assert khi `DEVCLKEN` đã LOW | §4.1.5 |
| `U5` | `DEVCLKEN` chỉ assert khi `DEVISOLATEn` đã HIGH | §4.1.5 |
| `U6` | reset chỉ được nhả khi `DEVCLKEN` đã HIGH | §4.1.5 |
| `U7` | `DEVPORESETn` chỉ assert khi `DEVISOLATEn` đã LOW | §4.1.5 |
| `U8` | `PCSMPSTATE` chỉ đổi khi `PCSMPREQ` LOW | AMBA LPI §2.2.2 |
| `U9` | mọi cặp chế độ có `ON` ở một đầu, hoặc là `OFF → MEM_RET` | §3.3.2 |
| `U10` | `PCSMPSTATE[7:4]` luôn bằng 0 | Table 4-12 |
| `U11` | `PCSMPSTATE[15:8]` bằng 0 trừ khi mode field là `FUNC_RET`/`FULL_RET`/`MEM_RET` | Table 4-12 |
| `U12` | `PPUHWSTAT` không đổi khi Q-Channel còn ở `Q_EXIT` | Table 4-5 |

> **`U3` là luật tinh vi.** Trong lúc chuyển đổi, các điều khiển đi qua chuỗi §4.1.5 trong khi
> `PPUHWSTAT` vẫn báo chế độ đang *rời đi*, nên nó chỉ được đánh giá khi mọi thứ đã ổn định — và một
> bộ đếm "im lặng bao lâu" là không đủ, vì `RST_HWSTAT_DLY` lập trình được tới 255 và một chuyển đổi
> hợp lệ có thể im lặng lâu hơn bất kỳ ngưỡng cố định nào. Tiêu chí phân biệt là **sự kiện nào xảy ra
> cuối cùng**: commit theo cấu trúc là sự kiện cuối của một chuyển đổi, nên `U3` chỉ đánh giá khi
> thay đổi gần nhất là của `PPUHWSTAT`.
>
> Hai luật **cố ý vắng mặt**, cùng một lý do — phiên bản ngây thơ sẽ nổ trên hành vi hợp lệ.
> "Mọi reset chỉ assert dưới isolation" sai vì `WARM_RST` reset một component *đang có nguồn*;
> "thiết bị phải quiesce trước khi điều khiển nào dịch chuyển" sai vì Table 4-4 và §4.1.3 đều cho
> phần mềm tắt handshake.

**Mọi checker đều được chứng minh không rỗng (non-vacuous):** `ppu_monitor_negtest` lái monitor qua
một vi phạm có chủ đích cho *mỗi* luật và xác nhận tất cả đều nổ — cộng bốn chuỗi hợp lệ (kể cả bước
nhảy `OFF → MEM_RET` được phép) phải im lặng.

### 8.3 Ba vi phạm giao thức được kỳ vọng

`qchannel_monitor` báo **đúng ba** vi phạm trong cả lần chạy — một ở P3, hai ở P15 — và cả hai phase
đều **assert đúng con số** thay vì bỏ qua. Cả hai là trường hợp spec PPU cố ý ghi đè AMBA LPI §2.1.2
(*"a controller must only assert a device reset when the interface is in the Q_STOPPED state"*):

- **P3, một vi phạm.** Table 4-4 cho `WARM_RST_DEVREQEN = 0` bỏ qua handshake cho `ON ↔ WARM_RST`,
  nên `DEVWARMRESETn` assert khi giao diện còn ở `Q_RUN`. Đó chính là mục đích của tùy chọn: một
  component *không* hỗ trợ `WARM_RST` vẫn warm-reset được, và không được hỏi ý kiến.
- **P15, hai vi phạm.** Xóa `PPU_PWCR.DEVREQEN` là phần mềm rút component ra khỏi hợp đồng LPI hoàn
  toàn (§4.1.3), nên clock gate (R10) và reset (R8) đều rơi vào `Q_RUN`.

> Một ngoại lệ giao thức được cho phép mà **không ai đo** thì không phân biệt được với một lỗi; một
> ngoại lệ **được đo** là một kết quả có tài liệu.

### 8.4 Coverage được assert, không phải in ra

`ppu_coverage.sv` đo ma trận **cặp chuyển đổi** bên trong `make ppu`. Đo hôm nay:

```
                 OFF      MEM_RET  FULL_RET MEM_OFF  FUNC_RET ON       WARM_RST
   OFF           .        3        .        .        .        38       .
   MEM_RET       .        .        .        .        .        11       .
   FULL_RET      .        .        .        .        .        17       .
   MEM_OFF       .        .        .        .        .        13       .
   FUNC_RET      .        .        .        .        .        13       .
   ON            38       11       17       13       13       .        9
   WARM_RST      .        .        .        .        .        9        .

   reachable pairs 13, covered 13, uncovered 0
   events covered 7 of 7
```

Hình dạng ma trận chính là tính neo-vào-`ON` của §3.3.2 được nhìn thấy. Hai điều biến nó thành một
*kiểm tra* chứ không phải một bản in:

- **Một cặp reachable chưa cover làm hỏng lần chạy.** Đột biến bỏ bước nhảy trực tiếp → coverage tụt
  xuống 12/13 và check summary fail.
- **Một cặp *bất hợp lệ* nếu xảy ra sẽ bị gắn cờ riêng** (`!n`). Điều đó biến collector thành một
  kiểm tra tuân thủ chứ không chỉ là đồng hồ đo.

Sự kiện được lấy **tại nguồn trong sequencer**, không lấy từ `PPU_ISR` — một sự kiện bị mask không
bao giờ set bit trạng thái, nên đếm bit trạng thái sẽ báo "chưa cover" đúng lúc suite cố ý mask.

### 8.5 Những gì testbench đã bắt được

Hai lỗi thiết kế, cả hai đều im lặng:

- **`pcsm_req_valid` không bao giờ được xóa.** `pchannel_controller` commit `cur_state` và phát
  `xfer_done` trên cùng một cạnh, nên ở chu kỳ hoàn tất thì "PCSM đã ở nơi tôi muốn" *cũng* đúng —
  nhánh nào test trước thì thắng, và request ở nguyên, kích hoạt sớm handshake PCSM của chuyển đổi
  *kế tiếp*. Sửa bằng cách dẫn xuất cả lối thoát lẫn request từ **một** biểu thức (`pcsm_needed`),
  khiến độ lệch trở thành không biểu diễn được.
- **`revert_policy` được register trên cùng cạnh với valid của chính nó**, nên `ppu_regs` lấy mẫu giá
  trị *trước* khi bị từ chối. Giờ nó là tổ hợp, chỉ strobe được register.

Ngoài ra: chiến dịch **mutation testing** nhiều đợt (ghi trong [`TEST_MATRIX.md`](../src/tb/ppu/TEST_MATRIX.md)
§"Mutation campaign") đã tìm ra ba khoảng trống thật, dẫn tới các phase P31–P34, và hai "survivor"
hóa ra là equivalent mutant chứ không phải lỗ hổng.

### 8.6 Build rút gọn — vì sao nó quan trọng hơn "một nhánh chưa test"

PPU có bảy tham số tùy chọn Chapter 7, và cho tới khi có `make ppucfg` thì **năm trong số đó chưa bao
giờ được elaborate ở giá trị nào khác `1`**. Mười bảy guard trong RTL tổng hợp được phụ thuộc vào
chúng, và nhánh false của mỗi cái là dead code — đã viết, đã review, chưa bao giờ mô phỏng.

Điểm mấu chốt: **một PPU rút gọn không phải là PPU đầy đủ bị tắt một tính năng lúc chạy; nó là một
PPU khác với một bản đồ thanh ghi khác**, và phần mềm khám phá bản đồ đó chỉ bằng cách đọc
`PPU_IDR0/IDR1`. Một build quảng cáo tính năng nó không có là hỏng theo cách mà không bao nhiêu test
trên build đầy đủ có thể phát hiện.

`ppu_minconfig_tb` chạy năm DUT trên **một bus thanh ghi chung**, và **mọi check đều đòi các build
phải bất đồng ý với nhau** — đọc ra 0 từ build rút gọn tự nó không chứng minh gì (một địa chỉ chưa
decode đọc ra 0, một bus hỏng cũng vậy). Đọc ra `0xA5` từ build đầy đủ qua *cùng* giao dịch ở *cùng*
thời điểm mới chứng minh bus hoạt động và khác biệt đến từ tham số.

DUT thứ ba xứng đáng có mặt: trong build rút gọn hoàn toàn, lock *và* dynamic transition đều không
được hỗ trợ — mà §3.4.3 nhả lock bất cứ khi nào `PWR_DYN_EN` bằng 0. Nên "nó không bao giờ lock" đúng
vì **hai lý do độc lập** và không test được lý do nào. `u_nlk` giữ dynamic và chỉ bỏ lock.

Phân biệt dễ sai nhất mà spec vạch ra:

| Tham số bị xóa | Thanh ghi trở thành | Đọc ra |
|---|---|---|
| `PWR_MODE_ENTRY_DEL_SPT` | **reserved** (§5.2.19) | `0` |
| `SW_DEV_DEL_SPT` | **read-only** (§5.2.21) | giá trị đã cấu hình — và §7.1.4 biến chúng thành "the fixed values for the device control delays", vẫn được áp dụng |

Coi cả hai là reserved sẽ đọc ra 0 từ `PPU_DCDR0` và, tệ hơn, có thể **pass** một register test trong
khi chạy hoàn toàn không có giãn cách device control.

### 8.7 Reset giữa chuyển đổi

Trục thứ ba từng bị giữ cố định. Mọi testbench PPU khác lái `aon_rst_n` đúng một lần ở thời điểm 0,
nên `RESETn` chưa bao giờ rơi vào *lúc PPU đang làm việc gì đó*. Điều này quan trọng vì reset bất
đồng bộ là sự kiện duy nhất có thể đưa output của PPU tới nơi sequencer chưa bao giờ chọn — và các
output đó là clock enable, isolation, ba reset và một yêu cầu power switch.

`ppu_rstflight_tb` assert `RESETn` ở 1–60 chu kỳ vào chuyển đổi, cho ba đích — 180 lần lặp:

| Tính chất | Kết quả |
|---|---|
| Hồi phục về chế độ Table 4-13 | 180/180 |
| PPU và PCSM đồng ý về miền sau đó | 180/180 |
| Hồi phục về `ON` thực sự cấp nguồn, bỏ isolation, nhả reset | 180/180 |
| Vẫn chuyển đổi bình thường sau đó | 180/180 |
| Vi phạm device-control của `ppu_monitor` | **0** |
| Vi phạm thứ tự nguồn của `ppu_power_model` | **0** |

Vi phạm Q-Channel được **phân loại, không bị tắt**: reset lấy trong `Q_STOPPED` phải im lặng (142 ca),
reset vào giữa một handshake đang sống phải được ghi nhận (38 ca), và *sau khi hồi phục, hoạt động
bình thường phải hoàn toàn sạch* (180 ca).

---

## 9. UPF power intent

### 9.1 Cấu trúc file

| File | Mục đích |
|---|---|
| [`ppu_pd_top.upf`](../src/upf/ppu_pd_top.upf) | Power intent cho miền do PPU điều khiển. **Scope-relative**, nên cùng một file phục vụ synthesis, P&R và mô phỏng |
| [`ppu_pa_bench.upf`](../src/upf/ppu_pa_bench.upf) | Nửa bench, viết một lần: đặt design top, tạo rail, bind file intent vào từng DUT instance |
| `ppu_<tb>.upf` × 12 | Mỗi testbench một file, chỉ chứa **hai sự kiện khác nhau** — tên module top và danh sách instance DUT — rồi source `ppu_pa_bench.upf` |
| `ppu_lpd_pd_top.upf`, `ppu_acg_pd_top.upf` | Biến thể cho hai top tích hợp nhiều-thiết-bị / access-control-gate |
| `qchannel_pd_top.upf`, `qchannel_pd_tb.upf` | Miền Q-Channel cũ (đối chứng) |

Mười wrapper bind vào `ppu_pd_top`: `ppu_pd_tb`, `ppu_demo_tb`, `ppu_be_tb`, `ppu_regdoc_tb`,
`ppu_reset_tb`, `ppu_rstflight_tb`, `ppu_minconfig_tb`, `ppu_clkratio_tb`, `ppu_clkq_tb`,
`ppu_axi_lite_tb`. Hai trong số đó (`ppu_reset_tb`, `ppu_minconfig_tb`) mang **năm** instance mỗi
cái và `ppu_clkq_tb` mang hai, nên tổng cộng **19 cặp `PD_AON`/`PD_DEV` độc lập** được elaborate;
thêm `ppu_lpd_pd_tb` (2 instance) và `ppu_acg_pd_tb` (1) trên hai file intent riêng.

`ppu_clkq_tb.upf` là file đầu tiên bind intent **dưới top level**: hai DUT của nó là `u_dev` và
`u_top/u_pd`, cái thứ hai nằm trong `ppu_clkq_top`. `load_upf -scope` nhận đường dẫn phân cấp không
phàn nàn, và báo cáo elaboration gọi tên cả hai — đó là cách nó được *xác nhận* thay vì *giả định*.

### 9.2 Mạng lưới nguồn

```
   VDD ----+-------------------------------------> PD_AON  (always on)
           |
           +--[ SW_LOGIC ]--> VDD_LOGIC ----------> PD_DEV  nguồn chính
           |
           +--[ SW_RET   ]--> VDD_RET ------------> PD_DEV  nguồn retention
   VSS -------------------------------------------> cả hai miền
```

**Hai switch, không phải một**, vì PPU phân biệt **ba** trạng thái cho miền chứ không phải hai: nguồn
đầy đủ, nguồn retention, và tắt. `VDD_RET` là net riêng chứ không phải cùng rail vì đó là thứ làm
`FULL_RET` *biểu diễn được*: trong `FULL_RET` nguồn retention có mặt trong khi nguồn chính vắng — đúng
cặp trạng thái mà một switch đơn không diễn đạt nổi.

Ba supply set: `SS_AON` (VDD), `SS_DEV` (VDD_LOGIC), `SS_RET` (VDD_RET). Một điện áp duy nhất 0.90 V
→ **không có level shifter**: `PD_DEV` hoặc cùng điện áp với `PD_AON`, hoặc trên rail retention cùng
điện áp, hoặc tắt. Level shifter dành cho chênh lệch điện áp; chênh lệch on/off là việc của isolation.

### 9.3 Phân vùng miền

| Miền | Nội dung | Lý do |
|---|---|---|
| `PD_AON` (mặc định, `-elements {.}`) | `u_ppu`, `u_pcsm`, `u_dev`, `u_wrap_rst`, `u_wl_rst`, `u_ret_rst`, `u_clken_sync`, **`u_ip` (vỏ) và 8 bank SRAM** | PCSA §7.2.2: *"the PPU must be placed in a power domain that is relative always-on to the power domain it is controlling."* Một khối không thể gate cái nguồn nuôi chính nó. |
| `PD_DEV` (chuyển mạch) | `u_clkctrl`, `u_ip/u_core`, `u_ip/u_ret` | Đúng thứ mà việc tắt nguồn *dành cho*. |

> **Dòng quan trọng nhất trong file là danh sách `-elements` của `PD_DEV`.** Nó nêu tên **hai khối
> logic của IP, không phải vỏ IP**. `u_ip` được để ở `PD_AON` vì nó thuần cấu trúc — giải mã chân và
> đi dây — và nêu tên nó ở đây sẽ kéo theo cả `u_ip/u_bank*` vào cùng, phá hủy RAM đúng ở chế độ
> `MEM_RET`.

Ba bộ đồng bộ reset và bộ đồng bộ clock-enable chạy trên `dclk` nhưng sống trong `PD_AON`. Đó là bình
thường và đúng: toàn bộ mục đích của chúng là tiếp tục làm việc trong khi miền chúng nhắm tới không
có nguồn.

### 9.4 Power switch và acknowledge

```tcl
create_power_switch SW_LOGIC \
  -domain PD_DEV -input_supply_port {VIN VDD} -output_supply_port {VOUT VDD_LOGIC} \
  -control_port {SW_ON u_pcsm/logic_on} \
  -on_state {logic_on VIN {SW_ON}} -off_state {logic_off {!SW_ON}} \
  -ack_port {SW_ACK pg_logic} -ack_delay {SW_ACK 200000} -supply_set SS_AON
```

Cả hai điều khiển đến từ **decode `PCSMPSTATE` của PCSM** (Table 3-1), đó là chỗ đúng về mặt kiến
trúc: §2.2 biến PCSM thành khối *"controls the power switches"*, và PPU chỉ với tới nó qua P-Channel.
Nên điều khiển switch **không phải** là một output của PPU — nó là **diễn giải của PCSM về một output
của PPU**, và đó là lý do việc gỡ nguồn không thể xảy ra trước `PCSMPACCEPT`.

| Trạng thái PCSM | Rail |
|---|---|
| `logic_on` — `ON`, `FUNC_RET`, `MEM_OFF` | nguồn logic đầy đủ |
| `logic_ret` — `FULL_RET` | chỉ nguồn retention |
| không cái nào — `MEM_RET`, `OFF` | logic mất nguồn |

**Về `-ack_port` ở `PGOOD_EN = 0`:** ghi chú trong file từng viết "không có `-ack_port` trên switch
nào: RTL không có input power-good". Điều đó hết đúng khi `ppu_pcsm` có thêm `ack_logic_on`/
`ack_logic_ret`, và để nguyên sẽ tệ hơn là lỗi thời: `ppu_pd_top` mang tham số `PGOOD_EN`, và bật nó
mà không có `-ack_port` ở đây sẽ để `pg_logic`/`pg_ret` **hoàn toàn không có driver** — X đi vào PCSM,
rồi PCSM chờ chúng mãi mãi. Một treo im lặng sinh ra bởi một thiết lập tham số hợp lệ.

### 9.5 Power state

`-simstate CORRUPT` là thứ làm mô phỏng power-aware khác mô phỏng RTL thường: nó lái mọi thanh ghi và
net trên nguồn đó về X khi nguồn vắng mặt.

| Chế độ | `VDD_LOGIC` | `VDD_RET` | Quan sát |
|---|---|---|---|
| `FULL_RET` | off | **on** | flop có retain giữ giá trị, flop không retain corrupt |
| `MEM_RET` | off | off | logic corrupt; chỉ RAM mà PCSM giữ mới sống |
| `OFF` | off | off | mọi thứ corrupt |

Các power state ở mức domain được **đặt tên theo chế độ nguồn của PPU** (`PM_RUN`, `PM_FULL_RET`,
`PM_DOWN`) chứ không theo rail. Đó là chủ ý: nó cho phép hỏi một static low-power checker *"chiến lược
isolation ở §7 có đủ trong `PM_FULL_RET` không?"* và nhận câu trả lời có nghĩa — và đó là chỗ duy nhất
trong flow mà UPF và bảng chế độ trong `ppu_pkg.sv` có thể được đối chiếu với nhau.

### 9.6 Isolation

```tcl
set_isolation ISO_DEV_BUSY \
  -domain PD_DEV -applies_to outputs -isolation_supply_set SS_AON \
  -clamp_value 0 -isolation_signal u_ppu/dev_isolaten -isolation_sense low \
  -location parent
```

**Enable là một tín hiệu được tuần tự thật sự.** Đây là khác biệt so với `qchannel_pd_top.upf`, nơi
isolation enable và switch control là **cùng một thanh ghi** và do đó không thể tách rời trong thời
gian. Ở đây `ppu_seq` lái chúng tách nhau, theo thứ tự §4.1.5, với khoảng cách lập trình được:

```
xuống   quiesce → DEVCLKEN low → [CLKEN_ISO_DLY] → DEVISOLATEn low
        → [ISO_RST_DLY] → resets → PCSM (gỡ nguồn)
lên     PCSM (cấp nguồn) → DEVISOLATEn high → [ISO_CLKEN_DLY]
        → DEVCLKEN high → [CLKEN_RST_DLY] → resets → un-quiesce
```

Isolation vì thế kích hoạt **nghiêm ngặt trước** khi nguồn đi và nhả **nghiêm ngặt sau** khi nguồn về —
đúng thứ tự silicon cần và là thứ thiết kế Q-Channel chỉ có thể *mô tả* chứ không *hiện thực*.

**`clamp_value 0`:** `busy` nghĩa là "tôi chưa thể bị dừng"; một miền không có nguồn thì theo định
nghĩa là quiescent, nên 0 là giá trị **trung thực** — cùng nguyên tắc ở khắp nơi: giá trị clamp là
giá trị *quiescent*.

Clamp này **thực sự chịu tải** ở đây, khác với thiết kế Q-Channel. Ở đó wrapper bị giữ trong reset khi
miền down nên output của nó bị ghim bất kể `busy` làm gì. Ở đây wrapper **sống**, nên clamp bằng 1 sẽ
làm hỏng thiết kế hai lần:

- `dev_quiescent_deny = deny_enb && busy` → thiết bị từ chối **mọi** yêu cầu quiescence thay mặt một
  workload không tồn tại → PPU không bao giờ vào lại được chế độ tiết kiệm sau một lần wake.
- `dev_wake = wake | busy` → `DEVQACTIVE` kẹt HIGH → một PPU dynamic đọc thấy yêu cầu wake vĩnh viễn
  và leo về `ON` ngay khi vừa tới `OFF`, mãi mãi.

**Có *hai* tín hiệu rời `PD_DEV`, không phải một.** Cả hai file UPF từng ghi "chính xác MỘT" cho tới
khi intent được chạy lần đầu và báo cáo elaboration của Xcelium bất đồng ý:

```
Isolation: ISO_DEV_BUSY
  Ports: u_dummy.busy
         u_clkctrl.gated_clk
```

Cái thứ hai *trông như* ở trong miền: cả driver (`u_clkctrl`) lẫn load (`u_ip`) đều ở `PD_DEV`. Nhưng
**net** giữa chúng, `dummy_clk`, được khai báo trong scope của chính `ppu_pd_top`, và scope đó là
`PD_AON`. **Thành viên miền theo scope của net, không theo instance của hai đầu.** Chiến lược được
viết ở mức **domain** với `-applies_to outputs`, nên crossing này đã được bao phủ sẵn — đó là lập luận
cho chiến lược mức domain gói trong một câu.

### 9.7 Retention

```tcl
set_retention RET_DEV_LOGIC \
  -domain PD_DEV -elements {u_ip/u_ret} \
  -retention_supply_set SS_RET \
  -save_signal    {u_pcsm/ret_n negedge} \
  -restore_signal {u_pcsm/ret_n posedge}
```

`qchannel_pd_top.upf` bác bỏ retention thẳng thừng và **đúng** với thiết kế đó: PCSA §8.3.4 nói *"the
reset state of the component should be equivalent to the quiescent state"*, thứ duy nhất trong miền
chuyển mạch của nó là một workload có quiescent state *chính là* reset state, nên không có gì để lưu.

Lập luận đó **không sống sót** khi có PPU. `FULL_RET` được định nghĩa là "Logic RET, RAM RET"
(Table 3-1) và được hậu thuẫn bởi một hàng device-control không tìm thấy ở chế độ nào khác
(Table 4-11). Một chế độ reset một số flop và không reset số khác chỉ có nghĩa nếu có flop retain —
nên retention ở đây không phải phần thêm tùy chọn, nó **là ý nghĩa của chế độ đó**.

**Danh sách element là `u_ip/u_ret` MỘT MÌNH, và sự chính xác đó là điểm mấu chốt.** Retention cell
tốn diện tích và leakage trên mỗi flop chúng phủ. Nếu `u_ip/u_core` cũng được retain thì `FULL_RET` và
`MEM_OFF` sẽ bảo toàn đúng cùng một trạng thái, và chế độ cần một hàng device-control riêng sẽ thôi
cần nó. `ppu_ip_ret` là một module riêng chính vì lý do này: ranh giới giữa trạng thái retain và
không retain là **một sự thật cấu trúc mà người đọc nhìn thấy trong hierarchy**, chứ không phải một
quy ước đặt tên mà danh sách này phải theo dõi.

### 9.8 Cố ý vắng mặt, kèm lý do

| Hạng mục | Trạng thái | Lý do |
|---|---|---|
| UPF cho RAM (switch thứ ba / retention) | **Vắng mặt có chủ đích** | RAM *có tồn tại* (8 bank). Nhưng một macro biên dịch sẵn không bị gate bởi switch của rail standard-cell; `ppu_pcsm` lái `ram_sleep[i]`/`ram_sd[i]` **đã register** cho từng bank. Đưa mảng vào `PD_DEV` sẽ phá hủy nó ở `MEM_RET` |
| Level shifter | Không cần | Một điện áp 0.90 V |
| Power-good acknowledge thật | **Còn mở** | Kiến trúc PPU không có input power-good (§6.5 không liệt kê cái nào). Nghĩa vụ chuyển sang PCSM: một PCSM thật phải không assert `PCSMPACCEPT` cho tới khi rail ổn định. Hạ tầng `-ack_port` + `PGOOD_EN` đã có sẵn |
| Power sequencing gộp | **Đã đóng** | Đây là hạng mục mà thiết kế Q-Channel không thể đóng. Xem §9.6 |

### 9.9 Chạy mô phỏng power-aware

```sh
xrun -sv -access +rwc \
     -lps_1801 src/upf/ppu_pd_tb.upf \
     -top ppu_pd_tb -top ppu_pa_supply \
     +define+PA_TOP=ppu_pd_tb +define+PPU_PA \
     -lps_logfile lps.log -lps_verbose 3 \
     <rtl> <tb> src/tb/ppu/ppu_pa_supply.sv
```

Bốn điều không đoán được, mỗi điều tốn một lần chạy hỏng để tìm ra:

1. **`-lps_1801`, không phải `-lps_upf`.** `-lps_upf`/`-lps_top` là cách viết của VCS. Xcelium không
   có `-lps_top` nào cả: *design* top đến từ `set_design_top` bên trong UPF, *elaboration* top là
   `-top` thông thường.
2. **`supply_on` không còn tồn tại.** Đó là lệnh Accellera UPF 1.0; IEEE 1801-2013 đã bỏ nó và
   Xcelium từ chối thẳng (`*E,UPFERRM ... [1801_LINT_CMD1]: Unknown command`), kể cả với
   `-lps_relax_1801`. Rail được cấp điện từ [`ppu_pa_supply.sv`](../src/tb/ppu/ppu_pa_supply.sv) bằng
   system task `$supply_on` của Xcelium, elaborate như một top thứ hai.
3. **Đường dẫn của `$supply_on` phải là hằng số lúc elaborate.** Plusarg cho `*E,SARGBAD1`;
   `parameter string` bị `-defparam` ghi đè thì bị bỏ qua *im lặng*. Phải dùng `` `define `` với toán
   tử stringification `` `" `` bên trong thân macro.
4. **`set_design_top <tb> -testbench`**, nếu không sẽ nhận `*SE,UPFNDEF: ... missing a default power
   domain`. Cách thay thế — tạo một domain phủ lên testbench — sẽ chạy nhưng tệ hơn: nó làm chính bộ
   kiểm tra chịu tác động của power intent, nên một sai sót ở rail làm hỏng luôn bench và lần chạy
   **không báo gì** thay vì báo lỗi.

> Một lưu ý đáng nhớ: một supply **net** top-level không có driver **mặc định là always-on** trong
> Xcelium (`-lps_enable_anon_tlp_supply`), nên việc đơn giản xóa các dòng `supply_on` *trông có vẻ*
> chạy được. Đó là mặc định của công cụ, không phải tính chất của thiết kế: dưới
> `-lps_disable_anon_tlp_supply` cùng UPF đó corrupt toàn bộ bench ở thời điểm 0.

### 9.10 Kiểm tra tĩnh: `make ppuupf`

Power intent có **cùng chế độ hỏng với một ràng buộc XDC `-quiet`: một đường dẫn không nêu tên gì thì
áp dụng lên không gì cả, một cách im lặng.** Một chiến lược isolation có danh sách element không khớp
cell nào, một switch có control port nêu tên tín hiệu không tồn tại, một retention strategy trên danh
sách rỗng — không cái nào hiện ra như lỗi trong mô phỏng chức năng, vì mô phỏng chức năng không đọc UPF.

[`lint/ppu_upf_check.py`](../src/lint/ppu_upf_check.py) đối chiếu mọi tham chiếu tới design object với
hierarchy mà **simulator đã elaborate**, lấy từ header VCD chứ không phải cào lại từ SystemVerilog —
nếu một module bị đổi tên hay một port bị xóa, VCD biết còn source scrape có thể không. Hiện có **22
tham chiếu**, tất cả đều resolve.

Hai quyết định thiết kế của script đáng ghi lại:

- **`-ports` được phân loại theo *lệnh*, không theo *option*.** Trong `set_port_attributes` nó nêu
  tên design port; trong `connect_supply_net` nó nêu tên *supply* port — là UPF object không tồn tại
  trong netlist.
- **Mọi option phải được phân loại, nếu không lần chạy fail.** Kiểm đúng hai mươi tham chiếu chẳng
  nói lên gì nếu file chứa cái thứ hai mươi mốt mà parser không nhận ra — đó sẽ là chế độ hỏng của
  chính script này, cao hơn một mức.

Nó **không** kiểm tra intent có *đúng* hay không (giá trị clamp, cạnh save/restore, biểu thức supply)
— đó là câu hỏi review. Nó trả lời câu hỏi hẹp hơn mà review làm dở nhất: **mọi cái tên có trỏ tới thứ
gì đó có thật không.**

### 9.11 Lần chạy power-aware đầu tiên tìm ra gì

Power intent chưa từng được chạy. Chạy nó **không thay đổi gì trong RTL, và không thay đổi gì trong
cấu trúc của power intent** — không miền nào dịch chuyển, không giá trị clamp nào đổi, không chiến
lược nào được thêm hay bỏ. Cái nó thay đổi là **bốn điểm quan sát trong testbench** và **hai khẳng
định trong comment**.

Phân bố đó chính là kết quả đáng phát biểu thẳng: **hành vi của PPU dưới IEEE 1801 power intent khớp
với spec Arm PPU ở mọi check mà suite thực hiện.**

Bốn phát hiện:

1. **Bốn probe của testbench đọc thanh ghi *bên trong* miền chuyển mạch.** `clk_gated` là
   `~u_top.u_clkctrl.en_latch` trong bốn testbench. Hai chế độ hỏng riêng biệt: check dùng nó fail
   *trong khi thiết kế đúng*; và `qchannel_monitor` trigger trên `posedge clk_gated`, mà trong Verilog
   `x -> 1` **là** một posedge, nên mỗi lần cấp nguồn lại đều sinh một R10 giả. Sửa bằng cách so sánh
   với 1 thay vì đảo bit — giải X thành "đã gate", cách đọc trung thực.
   **→ Đây là luật rút ra: một probe của testbench không bao giờ được đọc thanh ghi bên trong miền
   chuyển mạch.**
2. **Isolation cell đánh bại chính negative control của testbench.** P24 tồn tại để chứng minh clamp
   *có làm việc*. Nó defeat clamp *hành vi* trong `ppu_power_model` rồi assert rằng X thoát ra net
   always-on. Dưới power intent thật, X **không** thoát: `ISO_DEV_BUSY` giữ biên giới một mình và
   không gì trong testbench với tới nó được. Đó là dạng mạnh hơn của khẳng định P24 định đưa ra, nên
   dưới `PPU_PA` phase assert thẳng điều đó.
3. **`dummy_workload.cnt` không có reset — dự đoán, rồi quan sát được, rồi sửa.** `work_count` đọc ra
   X sau mỗi chu kỳ nguồn, nơi mô phỏng thường cho thấy giá trị cũ. Lành tính, nhưng "lành tính" là
   một *lập luận*, không phải một *tính chất*. `ppu_device_ip` thay workload đó và reset bộ đếm.
4. **Hai tín hiệu rời `PD_DEV`, không phải một** — xem §9.6.

---

## 10. Constraints, synthesis và các cổng lint

| Hạng mục | File | Ghi chú |
|---|---|---|
| Clock & I/O environment | [`ppu_pd_top.xdc`](../src/constraints/ppu_pd_top.xdc) | Đọc **trước** — ràng buộc CDC chọn đường theo launching clock nên clock phải tồn tại trước |
| Ràng buộc CDC | [`ppu_lpi.xdc`](../src/constraints/ppu_lpi.xdc) | Pure XDC. Ghi rõ crossing nào *thật sự* bất đồng bộ và crossing nào không (P-Channel PCSM: **không**) |
| Tự kiểm ràng buộc | [`ppu_lpi_check.tcl`](../src/constraints/ppu_lpi_check.tcl), [`ppu_synth_check.tcl`](../src/constraints/ppu_synth_check.tcl) | Bắt chế độ hỏng "`-quiet` + regexp không khớp gì" |
| Lint Python | [`ppu_upf_check.py`](../src/lint/ppu_upf_check.py), [`ppu_srclist_check.py`](../src/lint/ppu_srclist_check.py), [`ppu_comb_check.py`](../src/lint/ppu_comb_check.py), [`ppu_declinit_check.py`](../src/lint/ppu_declinit_check.py), [`ppu_regdoc_check.py`](../src/lint/ppu_regdoc_check.py) | UPF↔hierarchy, synthesis↔simulation đọc cùng RTL, suy diễn latch, cross-check `REGISTERS.md` với bảng của spec |

`ppu_srclist_check` đáng chú ý: nó kiểm tra **flow tổng hợp và flow mô phỏng đọc cùng một tập RTL** —
hai danh sách file lệch nhau là một lớp lỗi không testbench nào bắt được.

**Về môi trường hiện tại:** máy này chỉ có Xcelium. Icarus, Vivado và Verilator đều không có, nên
`make ppuvlint`, `make ppusynth`, `make synth` và `make xsim-diff` **không chạy được ở đây**.
`make ppulatch`, `ppusrc`, `ppudecl` và `ppuupf` là Python thuần và chạy bình thường.

---

## 11. Kết quả kiểm chứng (đo ngày 2026-09-11)

### 11.1 Mô phỏng chức năng

```
make ppu SIM=xcelium   →   checks=584   errors=0   *** PPU TESTBENCH PASSED ***
                           Q-Channel monitor: không vi phạm ngoài hai ngoại lệ được phép
                           reachable pairs 13, covered 13, uncovered 0
                           events covered 7 of 7
```

### 11.2 Mô phỏng power-aware (`make ppupaall`, UPF áp dụng, `-simstate CORRUPT`)

| Suite | Checks | Kết quả |
|---|---:|---|
| `ppu_pd_tb` | 584 | **PASS** |
| `ppu_be_tb` | 38 | **PASS** |
| `ppu_regdoc_tb` | 100 | **PASS** |
| `ppu_reset_tb` (5 DUT) | 38 | **PASS** |
| `ppu_rstflight_tb` (180 lần lặp) | 12 | **PASS** |
| `ppu_minconfig_tb` (3 DUT) | 90 | **PASS** |
| `ppu_clkratio_tb` (4 tỉ số) | 4 lần chạy | **PASS** × 4 |
| `ppu_clkq_tb` (2 DUT) | 72 | **PASS** |
| `ppu_axi_lite_tb` (2 DUT) | 64 | **PASS** |

### 11.3 Hai top tích hợp

| Suite | Checks | Kết quả |
|---|---:|---|
| `ppu_lpd_pd_tb` (LPD-Q, N thiết bị, dưới UPF) | 45 | **PASS** |
| `ppu_acg_pd_tb` (access control gate, dưới UPF) | 30 | **PASS** |

### 11.4 Cảnh báo còn tồn tại

Xcelium phát `*W,APMDRV` cho `SW_ACK`/`RET_ACK`: ack port được nối tới tín hiệu có HDL driver. Đây là
**đúng như thiết kế** ở `PGOOD_EN = 0` — `ppu_pd_top` tie `pg_logic`/`pg_ret` vào chính các control,
và PCSM bỏ qua chúng, nên timing đúng bằng trước khi các port này tồn tại. Ở `PGOOD_EN = 1` khối
generate tie-off không được elaborate và UPF trở thành driver duy nhất.

---

## 12. Hạn chế đã biết và hướng phát triển

### 12.1 Hạn chế

| Hạng mục | Trạng thái |
|---|---|
| **Không có power-good acknowledge thật** | Kiến trúc PPU không có input này (§6.5). Nghĩa vụ nằm ở PCSM: một PCSM thật phải không assert `PCSMPACCEPT` cho tới khi rail ổn định. Hạ tầng đã sẵn (`PGOOD_EN`, `-ack_port`, `-ack_delay`), chỉ chưa bật mặc định. Thêm nó **không** thay đổi PPU |
| **Hai sơ đồ điều khiển nguồn cùng tồn tại** | `qchannel_pd_top` vẫn tuần tự miền của nó bằng logic `clk_gate` + `qchannel_devrst_ctrl` viết tay; miền PPU dùng PPU. Xây dựng độc lập là lựa chọn có chủ đích, nhưng rút lui đường ad hoc cần một follow-up gắn `qchannel_pd_top` lên `ppu_top` |
| **Emulation mode (`OFF_EMU`, `MEM_RET_EMU`)** | Không build. Mang tính cộng thêm |
| **Nhiều Q-Channel trên PPU (`DEVCHAN_CFG > 1`)** | Không build — nhưng `ppu_lpd_pd_top` cho thấy một miền nhiều thiết bị đạt được bằng LPD-Q **mà không đụng `ppu_seq`** |
| **Synthesis trong công cụ thật** | Chưa chạy được ở máy này (không có Vivado/Verilator). `ppusynth`/`ppuvlint` đã viết nhưng chưa thực thi |

### 12.2 Lệch tài liệu phát hiện khi lập báo cáo

Sáu chỗ trong [`src/rtl/ppu/README.md`](../src/rtl/ppu/README.md) đã lỗi thời so với RTL hiện tại —
đáng sửa vì chúng là những con số người đọc sẽ trích dẫn:

| Chỗ | README nói | Thực tế |
|---|---|---|
| §Verification, mở đầu | *"make ppu → **477 checks**"* và *"Verified with Icarus Verilog 14.0"* | **584 checks**; Icarus không có trên máy này, suite chạy dưới Xcelium 25.09 |
| §9.3 | `ppu_monitor` kiểm *"nine ... rules (U1–U9)"* | Bảng ngay dưới đó liệt kê tới `U11`, và RTL hiện có **`U1`–`U12`** |
| §9.4 | `ppu_power_model` có *"eight continuous sequencing rules (PU1–PU8)"* | Hiện có **`PU1`–`PU10`** |
| §9.3.2 (dòng 754) | `ppu_minconfig_tb` *"runs **three** DUTs"* | **Năm** DUT: `u_max`, `u_min`, `u_nlk`, `u_nofr`, `u_mix` |
| §11 "Known gaps" | *"No RAM in the domain ... `dummy_workload` is flops"* | Đã lỗi thời: `ppu_device_ip` có **8 bank SRAM** và ba thanh ghi retention RAM đã quan sát được |
| §9 | Có **hai** heading cùng tên `### 9.3` | Lỗi đánh số |

Ngoài ra `README.md` §2.3 vẫn ghi UPF là *"in scope ... even where no installed simulator can execute
it"* — câu đó có từ trước khi Xcelium chạy được intent, và [`src/upf/README.md`](../src/upf/README.md)
đã cập nhật còn file này thì chưa.

### 12.3 Hướng tiếp theo (theo `CONFORMANCE.md` §5)

- **Tier 1** — kiểm chứng thứ đã tồn tại: bật `PGOOD_EN` mặc định và đo đường chờ power-good.
- **Tier 2** — tính năng spec chưa build: emulation mode; `DEVCHAN_CFG > 1`.
- **Tier 3** — tích hợp và vật lý: chạy synthesis thật, rút lui sơ đồ điều khiển viết tay của
  `qchannel_pd_top`, mở rộng lên thiết kế SoC nhiều miền
  ([`Proposed_PMU/PCSA_FLAT_DOMAIN_SOC.md`](../Proposed_PMU/PCSA_FLAT_DOMAIN_SOC.md)).

---

## 13. Phụ lục — lệnh chạy

> Trên máy này **bắt buộc** dùng `SIM=xcelium` cho mọi target chức năng; mặc định `SIM=icarus` sẽ fail
> ở cổng `simcheck`. Các target power-aware gọi `xrun` trực tiếp nên không chịu ảnh hưởng của `SIM`.

```sh
# ---- Chức năng ----
make ppu SIM=xcelium        # suite chính (584 checks)
make ppuall SIM=xcelium     # mọi suite PPU
make ppuneg SIM=xcelium     # negative test của monitor
make ppurst   / ppurstf     # nhả reset (Table 4-13) / reset giữa chuyển đổi
make ppuratio / ppucfg      # quét tỉ số clock / build rút gọn Chapter 7
make ppuirq / ppupm / ppube / ppudeny / ppudevif / ppuregdoc
make ppuclkctrl / ppuclkq / ppuaxi
make ppudemo                # tour hướng dẫn, dựng để xem trên waveform

# ---- Power-aware (IEEE 1801, cần Xcelium) ----
make ppupaall               # cả 9 suite dưới power intent
make ppupa                  # riêng ppu_pd_tb
make lpdpdpa / acgpdpa      # hai top tích hợp
make ppudemopa              # tour hướng dẫn dưới power intent
make pa                     # miền Q-Channel (đối chứng)

# ---- Kiểm tra tĩnh ----
make ppuupf                 # đối chiếu UPF với hierarchy đã elaborate (cần make ppu trước)
make ppusrc / ppudecl / ppulatch
make ppucheck               # cổng lint tổng hợp đầy đủ (ppuvlint cần Verilator — không có ở đây)

# ---- Tái lập / soak ----
cd ../build && vvp ppu_pd_tb +seed=999    # chạy lại một seed
cd ../build && vvp ppu_pd_tb +iters=500   # soak dài
```

---

## 14. Tài liệu tham chiếu trong repo

| Tài liệu | Nội dung |
|---|---|
| [`src/rtl/ppu/README.md`](../src/rtl/ppu/README.md) | Khối hoạt động thế nào — tài liệu kiến trúc chính |
| [`src/rtl/ppu/CONFORMANCE.md`](../src/rtl/ppu/CONFORMANCE.md) | Đối chiếu spec theo từng tính năng + roadmap |
| [`src/rtl/ppu/REGISTERS.md`](../src/rtl/ppu/REGISTERS.md) | Tài liệu tham chiếu cho người lập trình |
| [`src/rtl/ppu/FUNCTIONS.md`](../src/rtl/ppu/FUNCTIONS.md) | Checklist bề mặt spec theo *chức năng* |
| [`src/rtl/ppu/OPTIONS.md`](../src/rtl/ppu/OPTIONS.md) | Checklist tham số cấu hình Chapter 7, có cột "đã elaborate" |
| [`src/tb/ppu/TEST_MATRIX.md`](../src/tb/ppu/TEST_MATRIX.md) | Ma trận phase, coverage, chiến dịch mutation |
| [`src/upf/README.md`](../src/upf/README.md) | Power intent: quyết định, lý do, và lần chạy đầu tiên tìm ra gì |
| [`notes/11-arm-ip-power-architecture.md`](../notes/11-arm-ip-power-architecture.md) | Nền tảng lý thuyết: Q/P-Channel, PPU, PCSA, SCP, SCMI |
