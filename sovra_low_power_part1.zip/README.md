# pmu: the SOVRA power-control platform (SCP + PPU)

This repository is the **`pmu` IP of SOVRA** (SoC IP #47, PMU / power
controller): a power-control platform built to the Arm Power Control System
Architecture (PCSA, DEN 0050D). A **System Control Processor (SCP)**, a lowRISC
Ibex core with private RAM, timer, interrupt block and watchdog, runs bare-metal
firmware that owns every power domain. It drives each domain through a **Power
Policy Unit (PPU)** built to the Arm PPU Architecture v1.1 (DEN 0051E), which
sequences a Q-Channel to its device and a P-Channel to its power-control state
machine (PCSM).

Software on the application side asks for power over **RPMI v1.0** (the RISC-V
Platform Management Interface). The SCP answers with **librpmi v1.0.0** as its
server. Requests and replies go through a **TL-UL mailbox for N agents**: each
agent (SOVRA has two, the AP and the RPU) has its own queue window, doorbell and
firewall entry on its TileLink source ID.

**soc4** is the reference system that puts it all together: the SCP, four PPU
domains (two Ibex CPUs and two stand-in accelerators), an always-on AP running a
librpmi client, the two-agent mailbox, and the clock/reset request bridges to
models of SOVRA's `clkgate` / `tilereset`. The target SoC is SOVRA
(Chipyard/TileLink); its power architecture and the platform plan are in
[`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md).

## Status (2026-10-06)

The six phases of the platform plan (architecture document §15.2) are done
and committed on branch `scp-ibex-firmware`:

| Phase | Commit | What |
|---|---|---|
| 1 | `63e671d` | One firmware domain table (`SCP_PLAT_DOMAINS`); PPU driver fixes |
| 2 | `9a96ba6` | SCP interrupt inputs (`scp_irq`): PPUs, doorbells, SoC PLIC input, raw wake lines; table-driven handling |
| 3 | `6db4734` | N-agent mailbox: two agents on two TL-UL ports, value + mask firewall per agent, per-agent votes and permissions |
| 4 | `d059a27` | SCP watchdog (`scp_wdog`) and a fault log that survives a watchdog reset |
| 5 | `68bb804` | SOVRA device side: READY-bit adapter for CVA6/Rocket, TL-UH access gate, clock/reset request bridge; the software contract |
| 6 | `732b7c7` | Sign-off with the Synopsys VC suite: VC LP, CDC, RDC, Lint, Formal |

- **Regression:** 31 targets, all passing at their baselines (VCS; listed with
  their check counts in [`src/tb/README.md`](src/tb/README.md) §3).
- **Sign-off:** `make signoff` passes. Every waiver is justified; the open
  findings need design decisions: the retention style (LP-2), two CDC items,
  the TL-UH gate and READY-adapter formal findings, and VC Lint's language
  rules, which did not run (the SpyGlass-compatible checker is not installed).
  See [`src/signoff/SIGNOFF_REPORT.md`](src/signoff/SIGNOFF_REPORT.md) §8.
- **Not built yet** (deferred by decision): domain dependencies, RPMI HSM /
  SYSTEM_SUSPEND / SYSTEM_RESET, pad-retention outputs. Synthesis has not been
  run.

## Repository map

| Path | What | Start here |
|---|---|---|
| `src/` | All RTL, firmware, testbenches, power intent and sign-off | [src/README.md](src/README.md) |
| `src/pmu/` | The SCP: vendored Ibex, the SCP RTL (`scp_top` and its blocks), the shared SCP firmware, the firmware's DEN 0051E conformance report | [src/pmu/README.md](src/pmu/README.md) |
| `src/rtl/` | Low-power IP: Q-Channel and P-Channel, the PPU, access gates, the READY-bit adapter, the clock/reset bridge, TL-UH helpers, shared cells | [src/rtl/README.md](src/rtl/README.md) |
| `src/soc4/` | The reference system (`soc4_top`) and the only firmware build (`src/soc4/fw/Makefile`) | [src/soc4/README.md](src/soc4/README.md) |
| `src/tb/` | Testbenches, one folder per block; the regression and its baselines | [src/tb/README.md](src/tb/README.md) |
| `src/upf/` | IEEE 1801 power intent for the power-aware runs | [src/upf/README.md](src/upf/README.md) |
| `src/formal/` | SVA property modules for VC Formal, one folder per block | [src/formal/README.md](src/formal/README.md) |
| `src/signoff/` | VC suite scripts, waivers, open findings and the sign-off report | [src/signoff/README.md](src/signoff/README.md) |
| `src/vendor/` | Third-party RTL copied verbatim: OpenTitan TL-UL, PULP, SOVRA `tl_pkg` | [src/vendor/README.md](src/vendor/README.md) |
| `docs/` | Software contract, soc4 design document, status report, the user's PPU report | [Key documents](#key-documents) |
| `Proposed_PMU/` | The SOVRA power architecture and platform plan; the RPMI stack decisions; the soc4 brief | [Key documents](#key-documents) |
| `scripts/` | `run_regress.sh` (the regression) | [Building and running](#building-and-running) |
| `references/`, `PMU.md`, `training/` | Research material on low-power design | [Research material](#research-material) |
| `IPs/FEC_Turbo_Code/` | A separate in-house turbo-code IP (git submodule), unrelated to the power platform | — |
| `build` | A symlink to `/sim/sovra/quyetdv/pmu/build`, where every build writes | — |

Third-party code is vendored verbatim and never edited: Ibex in `src/pmu/ibex/`,
librpmi in `src/pmu/fw/vendor/librpmi/`, the rest in `src/vendor/`. Platform
configuration (domains, interrupt inputs, agents) is written by hand, not
generated: `src/soc4/rtl/soc4_top.sv` and `src/soc4/fw/soc4_plat.h`.

## Building and running

Everything runs from [`src/Makefile`](src/Makefile); `make -C src help` prints
its header, which lists every target.

**Tools.**
- **Synopsys VCS** for simulation (the default `SIM=vcs`). The soc4 targets,
  including the power-aware `soc4pa`, `soc4bfmpa` and `soc4stresspa` (VCS
  native low power), need it.
- **Synopsys VC suite** (VC Static: VC LP, VC SpyGlass CDC/RDC/Lint; VC
  Formal) for sign-off, found through `VC_STATIC_HOME` (the Makefile's default
  is `/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`).
- **Cadence Xcelium** (25.09, `/system/EDA/Cadence/xcelium/25.09.001`) for the
  Xcelium-only targets: the PPU, Q-Channel, LPD-Q and access-gate power-aware
  runs (`pa`, `ppupa`, `ppupaall` and the other `ppu*pa`, `lpdpdpa`, `acgpdpa`,
  `ppudemopa`).
- A RISC-V GCC (`riscv64-unknown-elf-` by default) and `python3` for the
  firmware.
- Icarus Verilog (`SIM=icarus`) still runs the Q-Channel, P-Channel and most
  PPU targets; see the Makefile header for which.

The VCS and VC suite licences run to 2026-10-31 (renewal in progress).

**Main targets** (`make -C src <target>`):

| Target | What |
|---|---|
| `soc4fw` | Build the soc4 firmware images into `build/fw/soc4` |
| `soc4` | The product path: `soc4_scp` on the SCP, the AP program as the RPMI agent |
| `soc4bfm` | `soc4_scp` against the testbench's TL-UL BFMs: firewall, discovery, ON/OFF, faults, interrupt inputs, the second agent, the watchdog |
| `soc4stress` | The SCP firmware against DEN 0051E on the four PPUs, one result per feature |
| `soc4wdog`, `soc4ckrst`, `soc4neg` | The watchdog test, the clock/reset bridges' firmware side, the nine planted mutants |
| `soc4pa`, `soc4bfmpa`, `soc4stresspa` | The same soc4 runs under the UPF power intent |
| `ppu`, `ppuall` | The PPU's main domain suite; all the PPU suites |
| `acgtluh`, `readyadp`, `ckrst` | The SOVRA device-side blocks, each with its mutants |
| `signoff` | All six sign-off targets: `vclp`, `vccdc`, `vcrdc`, `vclint`, `vcformal`, `vcformalneg` |
| `clean` | Remove the build directory |

Each simulation target exits non-zero when its run fails, and keeps the full
log under `build/<sim>/<top>/`.

**Regression.** [`scripts/run_regress.sh`](scripts/run_regress.sh) runs the
31 VCS targets of the phase 6 regression and the 13 Xcelium power-aware
targets, one log per target, and writes a summary; `TARGETS="..."` picks a
subset. Its header gives the usage. The baselines to compare against are in
[`src/tb/README.md`](src/tb/README.md) §3.

**Output.** Nothing is written into the source tree. `build/` at the repository
root is a symlink to `/sim/sovra/quyetdv/pmu/build`: simulation builds in
`build/vcs/<top>/` (power-aware soc4 in `build/vcs_pa/`), firmware in
`build/fw/soc4/`, sign-off runs in `build/signoff/`.

## Key documents

| Document | What |
|---|---|
| [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md) | SOVRA's PCSA power architecture; §13 SoC power modes and the domain partition; §14 the platform checklist and its decisions; §15 status, the phase plan, and how to add or remove a domain or an agent |
| [`Proposed_PMU/RPMI_STACK_DECISIONS.md`](Proposed_PMU/RPMI_STACK_DECISIONS.md) | The RPMI stack decisions (agents, transports, librpmi, no core patches), with dated notes where later decisions superseded them |
| [`docs/PMU_SOFTWARE_CONTRACT.md`](docs/PMU_SOFTWARE_CONTRACT.md) | What agent software sees: windows, doorbells, source IDs, DOMAIN_IDs, permissions, RPMI services, timing, the READY-bit protocol |
| [`docs/SOC4_DESIGN.md`](docs/SOC4_DESIGN.md) | The soc4 design as written before it was built (2026-10-01/02); the RTL and firmware comments cite it by section. The current state is in the READMEs and architecture §14–15 |
| [`src/signoff/SIGNOFF_REPORT.md`](src/signoff/SIGNOFF_REPORT.md) | Phase 6 sign-off: tools, results, waivers, open findings, integration requirements R1–R5 |
| [`docs/SOC4_STATUS_REPORT.jira`](docs/SOC4_STATUS_REPORT.jira) | The status report in Jira markup |
| [`src/pmu/PPU_FW_CONFORMANCE.md`](src/pmu/PPU_FW_CONFORMANCE.md), [`src/rtl/ppu/CONFORMANCE.md`](src/rtl/ppu/CONFORMANCE.md) | PPU conformance to DEN 0051E, from the firmware and from the RTL |

`docs/PPU_REPORT.md` and `Proposed_PMU/SOC4_TASK_PROMPT.md` are the user's own
report and brief.

## Research material

The repository began in August 2026 as a research dossier on power management
for SoC and VLSI design. Its 17 research notes (`notes/`) were removed on
2026-10-06; they are in the git history. What is kept as background:

- [`references/standards/`](references/standards/): the specifications the
  design cites: Arm PPU (DEN 0051E), AMBA Low Power Interface (IHI 0068C),
  PCSA (DEN 0050), CoreLink PCK-600 TRM, SCMI, PSCI, GIC, SBSA, and a
  low-power methodology document.
- [`PMU.md`](PMU.md): the PMU design track, a Zynq UltraScale+ PMU case study
  and a plan for a PMU on an Ibex core, which led to this platform.
- `training/`: Cadence low-power (IEEE 1801) course material, kept locally for
  reference. It is copyrighted, git-ignored and not in the repository.
