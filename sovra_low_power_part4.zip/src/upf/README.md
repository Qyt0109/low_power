> **Executed, not just reviewed.** Every PPU and Q-Channel file here runs
> under Cadence Xcelium 25.09. `make ppupaall` runs the whole PPU suite with the power intent
> applied — 8 testbenches, 12 ppu_pd_top instances, all passing. What that
> first execution found is in
> [What the first power-aware runs found](#what-the-first-power-aware-runs-found).
> The soc4 files run under Synopsys VCS native low power instead
> (`make soc4pa SIM=vcs`, also `soc4bfmpa` and `soc4stresspa`), and
> `soc4_top.upf` is also checked statically by VC LP (`make vclp`, see
> `../signoff/lp/README.md`). `make ppuupf`, which cross-checked the
> design-object references of `ppu_pd_top.upf`, was retired on 2026-10-05; see
> [Validation](#validation-what-make-ppuupf-did-retired).

# UPF power intent

IEEE 1801 (UPF) power intent for the switchable power domains in this
repository (the Q-Channel domain, the PPU domain and its variants, and soc4's
four domains), plus the power-aware simulation wrappers that bind each to its
testbench.

| File | Purpose |
|---|---|
| `qchannel_pd_top.upf` | Power intent for the Q-Channel gate-able domain. Scope-relative, so the same file serves synthesis, P&R and simulation. |
| `qchannel_pd_tb.upf`  | Simulation wrapper: sets the design top and loads the above with `-scope u_top`. |
| `ppu_pd_top.upf` | Power intent for the PPU-controlled domain. Same structure; see [The PPU domain](#the-ppu-domain) for what it does differently. |
| `ppu_pa_bench.upf` | The bench half of the PPU intent, once. Sets the design top, creates the rails, and binds `ppu_pd_top.upf` to each DUT instance. |
| `ppu_lpd_pd_top.upf`, `ppu_acg_pd_top.upf`, `ppu_axi_pd_top.upf` | The intent of `ppu_pd_top.upf` adapted to `ppu_lpd_pd_top` (three devices behind one LPD-Q), `ppu_acg_pd_top` (a responder behind an access control gate, the gate in `PD_AON`) and `ppu_axi_pd_top` (`ppu_dom_top` one level down, under `u_dom/u_pd`). Bound by `ppu_lpd_pd_tb.upf`, `ppu_acg_pd_tb.upf` and `ppu_axi_lite_tb.upf`, which set `ppu_pa_dut_upf` to them. |
| `ppu_*_tb.upf` | One per PPU testbench. Each holds only the two facts that differ — the top module's name and its list of `ppu_pd_top` instances — and sources `ppu_pa_bench.upf`. |
| `soc4_top.upf` | Power intent for the 4-domain soc4 platform: four switched domains (CPU0, CPU1, ACC0, ACC1), CPU0's whole core under retention on the PCSM's `ret_n`, every switched output isolated on `dev_isolaten`, RAMs on the always-on rail. The Tcl variable `s4_ret_sense` (default `edge`) chooses how `RET_CPU0` names its save/restore on `ret_n`: `edge` (`negedge`/`posedge`, used by VCS) or `level` (`low`/`high`, used by VC LP). See `build/soc4_design/SOC4_DESIGN.md` Section 8. |
| `soc4_tb_vcs.upf` | VCS wrapper for the soc4 testbench: `set_design_top soc4_tb/u_dut`, then loads `soc4_top.upf`. Used by `soc4pa`, `soc4bfmpa` and `soc4stresspa`. |
| `../signoff/lp/soc4_vclp.upf` | Not in this directory: the VC LP wrapper (`make vclp`). Sets `s4_ret_sense level`, because VC LP rejects edge-sensitive save/restore (`UPF_INVALIDPOLINRET`, sign-off finding LP-1), then loads `soc4_top.upf` at the design top `soc4_top` with no `set_design_top`. |

The nine PPU wrappers are `ppu_pd_tb`, `ppu_demo_tb`, `ppu_be_tb`,
`ppu_regdoc_tb`, `ppu_reset_tb`, `ppu_rstflight_tb`, `ppu_minconfig_tb`,
`ppu_clkratio_tb` and `ppu_clkq_tb`. Two of those carry **five** `ppu_pd_top`
instances each (`ppu_reset_tb`, one per Table 4-13 row plus the long-`tinit`
instance, and `ppu_minconfig_tb`, one per Chapter 7 configuration), so a run of
the suite elaborates eighteen independent `PD_AON`/`PD_DEV` pairs. (This
sentence read "twelve" before `ppu_clkq_tb` was added, and was already wrong:
six single-DUT wrappers plus two five-DUT ones is sixteen, and
`ppu_clkq_tb` brings two more.)

`ppu_clkq_tb.upf` is the first one to bind the intent **below the top level**:
its two DUTs are `u_dev` and `u_top/u_pd`, the second of them inside
`ppu_clkq_top`. `load_upf -scope` takes the hierarchical path without
complaint, and the elaboration report names both — `ppu_clkq_tb.u_dev.u_ppu`
and `ppu_clkq_tb.u_top.u_pd.u_ppu` — which is how it was confirmed rather than
assumed.

The PPU testbenches with no wrapper — `ppu_irq_tb`, `ppu_pm_tb`,
`ppu_monitor_negtest`, `ppu_deny_tb` and `ppu_clkctrl_tb` — are unit tests on
`ppu_irq`, `ppu_power_model`, `ppu_monitor`, `ppu_seq` and `ppu_clk_ctrl`. None
instantiates `ppu_pd_top`, so none has a power domain and there is nothing for a
power intent to say about them. `ppu_clk_ctrl` is the clearest case: it is the
block that removes a **clock**, not one that loses a supply.

### The clock controller sits above the power intent, not inside it

`ppu_pd_top.upf` creates `PD_AON` and `PD_DEV` *inside* `ppu_pd_top`, so
everything `ppu_clkq_top` adds above that boundary — `ppu_clk_ctrl`, the gate,
and the wires between them — is outside the power intent and is covered by
`set_design_top … -testbench`.

That is what the partition actually is, not a shortcut. A clock controller is
not part of a power domain; it sits above one and usually above several, and
PCK-600 Figure 3-8 draws it that way. In a real integration it would belong to
the always-on domain of whatever encloses both it and the PPU, and that
enclosure does not exist in this repository.

What running `ppu_clkq_tb` under UPF does prove is the interesting half — that
clock gating and power gating do not interfere. The PPU and the PCSM are in
`PD_AON`, which never loses its supply, so stopping their clock must be
invisible to `PD_DEV`'s corruption behaviour. And the wake in group G3 crosses
the domain boundary: `DEVQACTIVE` leaves an **unpowered** `PD_DEV`, is clamped
by `ISO_DEV_BUSY`, and reaches `PPUCLKQACTIVE` combinationally. Without the
power intent, "domain OFF" is a domain held in reset and that clamp is never
exercised at all.

The split mirrors `src/constraints`, where `qchannel_lpi.xdc` describes the
blocks and `qchannel_pd_top.xdc` describes the environment they sit in.

Most of this document describes the **Q-Channel** domain, which came first and
is the simpler of the two. The PPU domain is covered in its own section at the
end, because the interesting thing about it is precisely the set of gaps it
closes relative to this one.

---

## The power intent, and where it comes from

### Only one of the two Q-Channels is power intent

`qchannel_pd_top` carries two independent Q-Channel interfaces because PCSA
§8.2.1 requires it — *"The clock control Q-Channels must be separate from any
power control LPIs."* They actuate different physical resources, and the
distinction decides what belongs in this directory:

| Channel | Actuator | Effect on state | UPF? |
|---|---|---|---|
| Clock control (`u_ctrl_clk` ↔ `u_dev_clk`) | `clk_gate` (ICG) | **Frozen** — testbench P5 proves a half-finished burst resumes rather than restarts | No. A clock gate is not a power domain. |
| Power control (`u_ctrl_pwr` ↔ `u_dev_pwr`) | `qchannel_devrst_ctrl` → `drst_n` | **Lost** — domain re-initialises from reset | Yes. This is all of it. |

Modelling the clock gate as a power domain would be wrong, and would also
destroy the one property P5 exists to demonstrate.

### Domains

```
VDD ──┬──────────────────────────────► PD_AON   always-on
      │
      └──[ SW_DEV ]──► VDD_DEV ───────► PD_DEV   switched
```

| Domain | Contents | Why |
|---|---|---|
| `PD_AON` (default) | `u_ctrl_clk`, `u_ctrl_pwr`, `u_devrst`, **`u_dev_clk`, `u_dev_pwr`** | PCSA §7.2.3: *"the PPU must be placed in a power domain that is relative always-on to the power domain it is controlling."* A block cannot generate the reset for — or gate the supply of — a domain it lives in. The same reasoning covers the interface. |
| `PD_DEV` (switched) | `u_clkctrl`, `u_dummy` | What the power-down is actually *for*. |

`u_devrst` sits in `PD_AON` while containing `dclk`-clocked flops. That is
correct: a reset synchroniser targeting a switchable domain has to keep working
while that domain has no supply.

### The interface is not in the switched domain

Both Q-Channel device wrappers stay always-on. This is the most consequential
partitioning decision here, and it runs against the RTL's own comment
(`qchannel_pd_top.sv` calls `drst_n` *"the ONE reset shared by `u_dev_clk`,
`u_dev_pwr` and `dummy_workload` — once the domain is genuinely powered down,
everything in it, wrapper logic included, goes down together"*).

- **A wrapper is a protocol agent, not payload.** Powering it off and clamping
  its outputs does not preserve the protocol — it replaces a live participant
  with a constant that imitates one. The interface still reads `Q_STOPPED`, but
  nothing is holding that state; six independent clamp values are.
- **That imitation is only safe while clamp value == reset value.** Get one of
  the six wrong and the controller waits forever for an acknowledge from a
  domain that resets into a different state than it was clamped to. Keeping the
  wrappers powered removes the dependency: the reset value *is* the value,
  driven by real flops, with no second copy in a constraint file to drift.
- **Isolation count goes down, 6 → 1.** Switching the wrappers off makes every
  one of their outputs an off-to-on crossing. Leaving them on makes the only
  crossing the workload's `busy`.
- **The leakage cost is two six-state FSMs and their synchronisers** — a few
  dozen flops — against a workload domain large enough to be worth switching
  off. Not a real trade.
- **It matches ARM's model.** In PCSA the PPU negotiates a component back up
  over a live LPI, so the interface cannot itself be what goes down.

`u_clkctrl` stays switched because its only load is `u_dummy`; a clock gate
feeding a domain with no supply has nothing to do. Its enable arrives from
`u_dev_clk` in `PD_AON` — an on-to-off crossing, needing no isolation.

> **Outstanding.** The RTL still resets both wrappers from `drst_n`, so while
> the domain is down they are *powered but held in reset*. This partition
> removes the clamp fragility today; making the interface functionally alive
> needs the wrappers' reset separated from `drst_n`, which is an RTL change —
> see [Known gaps](#known-gaps).

### Switch control — the AMBA rule as a register

`SW_DEV` is controlled by `u_devrst/rst_hold_n`, active low. It is low in
exactly two situations, both legal reasons to have no supply:

- **cold power-up** — `rst_hold_n` resets to 0, so `PD_DEV` starts *off* and is
  powered up by PM policy rather than by default. This falls out of the
  register's active-low polarity for free.
- **`dev_rst_req` asserted *and* `dev_stopped_pwr` asserted** — the policy has
  asked for power-down *and* the power-control Q-Channel has independently
  negotiated its way to `Q_STOPPED`.

The second case is AMBA LPI §2.1.2 — *a controller may only remove a device's
clock or power in `Q_STOPPED`* — implemented in silicon rather than asserted in
a document. A policy that asserts `dev_rst_req` too early cannot remove the
supply; it simply has no effect until the handshake completes. Testbench P7
asserts `dev_rst_req` mid-burst specifically to prove that.

The control comes from the **power** channel's `dev_stopped`, never the clock
channel's (PCSA §8.2.1). A clock quiescing tells you nothing about whether it is
safe to remove the supply.

### Isolation — two signals

This said "exactly one" until the intent was first executed. Xcelium's
elaboration report lists two:

```
u_dummy/busy        -> u_dev_clk/dev_quiescent_busy, u_dev_pwr/dev_quiescent_busy
                       and the top-level terms (deny_enb && busy), (wake | busy)
u_clkctrl/gated_clk -> dummy_clk -> u_dummy/clk
```

The second looks internal because both endpoints are in `PD_DEV`, but the net
between them is declared in `qchannel_pd_top`'s own scope, which is `PD_AON`.
**Domain membership follows the net's scope, not the endpoints' instances** —
so the workload's clock leaves the switched domain, crosses an always-on net,
and comes back.

Nothing else crosses: `done` and `work_count` are unconnected; `dev_clk_en`,
`drst_n`, `dclk`, `start`, `work_len` and `light_work` all travel on-to-off.
The strategy is written at domain level rather than naming the pin, so both
crossings were covered anyway — which is the argument for domain-level
strategies in one sentence.

**Clamp value 0.** `busy` means "I cannot be stopped yet"; a domain with no
supply is quiescent by definition, so 0 is the truthful value — the same
principle as everywhere else here, that the clamp value is the *quiescent* value.

What the clamp does *today* is narrower than it looks, and worth stating
precisely. `busy` feeds two always-on combinational terms which reach both
wrappers — but the RTL still holds those wrappers in reset via `drst_n` while
the domain is down, and `qchannel_device` drives `qacceptn`/`qdeny`/`qactive` to
0 unconditionally in reset. So the clamp value cannot reach the interface at
all right now. Its job today is preventing X from an unpowered `u_dummy`
propagating onto always-on nets — which a power-aware checker flags on its own
account, regardless of what happens to be masking it downstream.

It becomes functionally load-bearing once the wrappers' reset is split from
`drst_n`. With live wrappers a clamp of 1 would break the design twice:
`deny_enb && busy` would deny every quiescence request on behalf of a workload
that does not exist, and `wake | busy` would jam `QACTIVE` high — so the
controller would leave `Q_STOPPED` and try to run a domain with no supply, an
LPI §2.1.2 violation caused entirely by a constraint file. Getting it right now
removes a trap from that later change.

The isolation cell is powered by `SS_AON` and placed with `-location parent` —
an isolation cell inside the domain it is isolating clamps nothing.

### `wake` is still inert while the domain is down

`QACTIVE` is driven by the device *wrapper*, and although the wrappers now keep
their supply, `drst_n` still holds them in reset — so `QACTIVE` stays low and
`wake` cannot revive the domain. P7 measures this: `wake` held high for ten
device cycles produces no `QACTIVE`, no clock edges, and no exit from
`Q_STOPPED`.

The difference the partition makes is *why* the interface reads `Q_STOPPED`: it
is now held there by real flip-flops rather than imitated by six clamp constants
that have to independently agree with the RTL's reset values. Revival is still
`dev_rst_req`'s job, which is consistent with PCSA §8.3.4 — wake signalling for
a powered-down domain comes from outside it.

> **Integration hazard.** `qchannel_pd_top` routes its top-level `wake` port
> *into* `u_dev_clk`/`u_dev_pwr` as `dev_wake`, and those are reset by `drst_n`,
> so `wake` does nothing while the domain is down. An always-on PM policy built
> on this must have its own wake input. Wiring the power domain's exit condition
> to `QACTIVE` alone — which `enb_qactive_led_quiescence_exit=1'b1` invites,
> being correct for *clock* gating — produces a domain that can never be
> revived.

### No retention, and that is the intent

PCSA §8.3.4: *"the reset state of the component should be equivalent to the
quiescent state."* This design takes it literally. `drst_n` resets the whole
domain including both Q-Channel wrappers, and the wrappers reset straight into
`Q_STOPPED` with `QACCEPTn` and `QDENY` low — the same values the isolation clamp
holds. The state the domain wakes into is already the state it went down in, so
there is nothing to save.

Adding `set_retention` would make power gating behave like clock gating, at far
higher area and leakage cost, to preserve state the architecture has already
declared disposable. If a future workload does need to survive power-down, the
strategy belongs on `u_dummy` alone — never on the Q-Channel wrappers, whose
whole contract is that reset equals quiescent.

### No level shifters

Single rail at 0.90 V. `PD_DEV` is either at `PD_AON`'s voltage or off. Level
shifters are for voltage differences; on/off differences are isolation's job.

---

## Specification → UPF mapping

| Clause | Requirement | Where it lands |
|---|---|---|
| PCSA §7.2.3 | Controller must be relatively always-on | `PD_AON` holds both controllers, `u_devrst`, and both device wrappers |
| PCSA §8.2.1 | Separate clock and power LPIs | Switch control comes from `dev_stopped_pwr`, not `dev_stopped_clk` |
| PCSA §8.3.4 | Reset state ≡ quiescent state | No `set_retention` |
| PCSA §8.3.4 | Wake from outside the domain | Revival via `dev_rst_req`, an always-on port |
| LPI §2.1.2 | Remove clock/power only in `Q_STOPPED` | `-control_port {SW_ON u_devrst/rst_hold_n}` |
| LPI Table 2-1 | `Q_STOPPED` = `{0,0,0}` | Held by the wrappers' own reset, not by clamps — the reason they are always-on |

---

## Verification

`src/tb/qchannel/qchannel_pd_tb.sv` phase **P7 — Power Shutoff and Restore**
exercises every decision above:

| Check | Proves |
|---|---|
| `dev_rst_req` asserted mid-burst leaves `drst_n` high | The switch control interlock |
| `drst_n` falls only once both channels reach `Q_STOPPED` | LPI §2.1.2 |
| `QACCEPTn`/`QDENY`/`QACTIVE` all read 0 while down | The interface state — now held by the wrappers' own reset |
| Zero gated-clock edges while down | The domain is genuinely stopped |
| `wake` held high for 10 device cycles changes nothing | Revival is `dev_rst_req`'s job — PCSA §8.3.4 |
| A fresh burst runs after restore | Re-initialisation from reset, no retention |

Not covered: **the `busy` clamp itself**. As explained above, the wrappers'
reset masks it, so no plain-simulation check can reach it — it is only
observable under a power-aware simulator, as X on the always-on terms if the
isolation were removed.

These pass under ordinary RTL simulation as well, because the reset state and
the clamp state are the same values — which *is* the PCSA §8.3.4 equivalence the
intent is built on. Power-aware simulation adds what plain simulation cannot
show: with `-simstate CORRUPT`, any register in `PD_DEV` read before
re-initialisation comes back X.

```
make pd          # Icarus — 79 checks, 0 errors, 0 monitor violations
make xsim-diff   # xsim   — transcripts byte-identical
```

---

## Running power-aware simulation

Cadence Xcelium 25.09 is installed here and every target below has been run.
Icarus and Vivado xsim have no UPF support at all, which is why the power-aware
targets are separate and why every testbench is written to pass with the intent
absent as well as present.

```sh
make ppupaall     # the whole PPU suite under power intent
make ppupa        # ppu_pd_tb alone -- 537 checks
make ppudemopa    # the guided tour, to watch rather than to read
make pa           # the Q-Channel domain
```

### The invocation, and the three things that are not obvious

```sh
xrun -sv -access +rwc \
     -lps_1801 src/upf/ppu_pd_tb.upf \
     -top ppu_pd_tb -top ppu_pa_supply \
     +define+PA_TOP=ppu_pd_tb +define+PPU_PA \
     -lps_logfile lps.log -lps_verbose 3 \
     <rtl> <tb> src/tb/ppu/ppu_pa_supply.sv
```

**`-lps_1801`, not `-lps_upf`.** `-lps_upf` and `-lps_top` are VCS's spelling.
This document previously gave the VCS form as the Xcelium one, and the
`ppupa` target carried it unexecuted. Xcelium takes `-lps_1801 <file>`, and it
has no `-lps_top` at all: the *design* top is set inside the UPF with
`set_design_top`, and the *elaboration* top is the ordinary `-top`.

**`supply_on` no longer exists.** It is an Accellera UPF 1.0 command. IEEE
1801-2013 dropped it, and Xcelium rejects it outright — with or without
`-lps_relax_1801`:

```
*E,UPFERRM: [LPS] IEEE 1801 parsing error during parsing command (supply_on)
            ([1801_LINT_CMD1]: Unknown command.)
```

In 1801-2013 a supply net's state comes from its drivers, and a board rail at
the top of the bench has none. So the rails are energised from
[`tb/ppu/ppu_pa_supply.sv`](../tb/ppu/ppu_pa_supply.sv) with Xcelium's
`$supply_on` task, elaborated as a second top. That module is where the
`+define+PA_TOP` comes from, and why it is a `define` rather than a plusarg or
a parameter — both of those were tried and both fail, which its header records.

An undriven top-level supply net does default to always-on in Xcelium
(`-lps_enable_anon_tlp_supply`), so simply deleting the `supply_on` lines
appears to work. That is a tool default, not a property of the design: under
`-lps_disable_anon_tlp_supply` the same UPF corrupts the entire bench at time
zero. `$supply_on` states the rail explicitly and checks its own return status,
because a path that names nothing is otherwise silent.

**`set_design_top <tb> -testbench`.** Without `-testbench`:

```
*SE,UPFNDEF: [LPS] The following design top scope is missing a default
             power domain: ppu_pd_tb.
```

The alternative — creating a domain over the testbench — would work but is
worse: it makes the checker itself subject to the power intent, so a mistake in
the rails corrupts the bench along with the design and the run reports nothing
rather than reporting a failure.

### The other two simulators

The power intent itself is tool-independent; only the invocation is not.

```sh
# VCS
vcs -sverilog -upf src/upf/ppu_pd_tb.upf -power_top ppu_pd_tb <rtl> <tb>

# Questa
vopt -pa_upf src/upf/ppu_pd_tb.upf -pa_top /ppu_pd_tb ...
vsim -pa ...
```

Neither has been run here. Both would need their own equivalent of
`ppu_pa_supply.sv`, since `$supply_on` is a Cadence task.

---

## What the first power-aware runs found

The power intent had never been executed. Running it changed nothing in the
RTL, and nothing in the power intent's structure — no domain moved, no clamp
value changed, no strategy was added or removed. What it changed was four
**observation points in the testbenches** and two **claims in the comments**.

That distribution is the result worth stating plainly: **the PPU's behaviour
under IEEE 1801 power intent matches the ARM PPU specification in every check
the suite makes.** 537 checks in `ppu_pd_tb`, plus seven other testbenches and
four clock ratios, all pass with `-simstate CORRUPT` active and both switched
rails genuinely removed.

### 1. Four testbench probes read registers inside the switched domain

`clk_gated` was `~u_top.u_clkctrl.en_latch` in four testbenches (and a fifth in
`qchannel_pd_tb`). `u_clkctrl` is in `PD_DEV`, so once the supply is removed
`en_latch` reads X and `~` propagates it. Two separate failures:

- **`ppu_pd_tb` P22** — `check(clk_gated)` in `FULL_RET` failed. Probed at the
  failure: `logic_on=0`, `logic_ret=1`, `dev_isolaten=0`, `busy=0`. The design
  was doing exactly what Table 3-1 and Section 4.1.5 require; the probe simply
  could not report it, because the register it reads had no supply.
- **Spurious R10** — `qchannel_monitor` triggers on `posedge clk_gated`, and in
  Verilog `x -> 1` *is* a posedge. Every power-up raised a bogus "resource gated
  outside `Q_STOPPED`", and P30's count of sanctioned violations went 2 → 3.

Fixed by comparing against 1 rather than inverting, which resolves X to
"gated" — the truthful reading, since a domain with no supply has no clock. In
ordinary simulation `en_latch` is only ever 0 or 1, so the change is a no-op
there and the non-power-aware transcripts are byte-identical.

### 2. The isolation cell defeats the testbench's own negative control

`ppu_pd_tb` P24 exists to prove the clamp does work rather than decorating the
netlist. It sets `iso_defeat`, which removes the *behavioural* clamp in
[`ppu_power_model.sv`](../tb/ppu/ppu_power_model.sv), and then asserts that X
escapes onto an always-on net.

Under real power intent it does not escape. Measured with the model's clamp
defeated:

| signal | value |
|---|---|
| `u_top.u_dummy.busy` | `x` — inside `PD_DEV`, unpowered |
| `u_top.busy` | `0` — the always-on side |
| `dev_qactive` | `0` |

`ISO_DEV_BUSY` is holding the boundary on its own, and nothing in the testbench
can reach it. That is the stronger form of the claim P24 was written to make,
so under `PPU_PA` the phase asserts it directly instead. Both branches make two
checks, so the count is 537 either way.

This is also the answer to the question the Q-Channel section below leaves
open — whether the clamp is load-bearing or merely X-suppression. Here it is
load-bearing, and now measured rather than argued.

### 3. `dummy_workload.cnt` has no reset — confirmed, then fixed

Predicted at the end of `ppu_pd_top.upf` and in [Known gaps](#known-gaps), and
now observed: `work_count` reads X after every power cycle, where ordinary
simulation shows the stale pre-shutdown value.

```
[25170000]   work_count frozen at x        (plain simulation: 60)
[36599000]   note P26 iter 3: work_count still X from a power cycle
```

It was benign — `cstate` resets to `IDLE` and `cnt` is reloaded from `work_len`
before it is ever read — but "benign" was an argument, not a property.
`ppu_device_ip` replaced that workload and resets its counter, so for the PPU
domain it is now a property. `qchannel_pd_top` still instantiates
`dummy_workload` and still has the finding.

### 4. Two signals leave `PD_DEV`, not one

Both `ppu_pd_top.upf` and `qchannel_pd_top.upf` said "exactly ONE signal leaves
`PD_DEV`... `dummy_clk` has both ends inside `PD_DEV`". Xcelium's elaboration
report disagrees:

```
Isolation: ISO_DEV_BUSY
  Ports: u_dummy.busy
         u_clkctrl.gated_clk
```

Both *endpoints* of the clock are in `PD_DEV`, but the net between them —
`dummy_clk` — is declared in `ppu_pd_top`'s own scope, and that scope is
`PD_AON`. Domain membership follows the net's scope, not the endpoints'
instances. So the workload's clock leaves the switched domain, crosses an
always-on net, and comes back.

Nothing needed to change: both strategies are written at domain level with
`-applies_to outputs`, precisely so that a crossing nobody enumerated is
covered anyway. But the clamp value turns out to matter more than the comment
implied — 0 holds the workload's clock LOW while isolated, which is what a
stopped clock should look like, whereas 1 would have parked it HIGH at the
moment of isolation. Both files now say so, because the busy-only argument for
`clamp_value 0` no longer covers everything the clamp applies to.

### What did *not* need changing

No RTL. No domain boundary, switch, power state, isolation strategy or
retention strategy. The Section 4.1.5 ordering held at all four clock ratios
including the PPU-slower-than-device case (0.15), which is the case that
stretches the window in which the supply is absent and the isolation must stay
engaged.

---

## Known gaps

**The wrappers are powered but still reset by `drst_n`.** The partition puts
them in `PD_AON`, but `qchannel_pd_top` still wires `u_dev_clk.rst_n` and
`u_dev_pwr.rst_n` to `drst_n`, so they go down with the workload anyway. That
already buys the important thing — the interface state is *held* rather than
imitated — but not a live interface.

Separating their reset (giving them `aon_rst_n` resynchronised into `dclk`,
while `u_dummy` keeps `drst_n`) would make `QACTIVE` work while the domain is
off, restoring LPI §2.1.3's anti-deadlock mechanism and making the top-level
`wake` port meaningful during power-down. That is what ARM's PPU model assumes.

The cost is a sequencing obligation, not area. Once `QACTIVE` can rise from an
unpowered domain, the interface can leave `Q_STOPPED` before the supply is
back — and LPI §2.1.2 forbids power being absent outside `Q_STOPPED`. The
always-on policy would have to treat `QACTIVE` as a wake *request* and restore
the supply before letting the handshake complete, which is the PPU sequencer
below. Doing the reset split without that sequencer trades a fragility for a
protocol violation, so the two belong in one change.

**Power sequencing is collapsed.** The switch control and the isolation enable
are both `rst_hold_n`, so isolation-enable and switch-off land on the same edge.
Silicon needs them staggered:

```
down   assert reset  → enable isolation → open switch
up     close switch  → wait power-good  → disable isolation → release reset
```

`qchannel_devrst_ctrl` implements only the reset leg — `drst_n` asserts
asynchronously the instant `rst_hold_n` falls, and releases two `dclk` edges
after it rises — but nothing staggers isolation against the switch, because
there is no sequencer. That sequencer is what PCSA calls the PPU, and it belongs
in `PD_AON` next to `u_devrst`. The collapse is safe for functional simulation
(the clamp already equals the reset state, so no unclamped window exists) but
not for silicon, where the switch has real turn-on time. Adding a sequencer
changes two lines: the `-control_port` and the `-isolation_signal`.

**No power-good acknowledge.** The RTL has no such input, so
`create_power_switch` carries no `-ack_port`. In silicon the acknowledge should
gate the reset release so `drst_n` cannot deassert before the rail settles.

**`dummy_workload.cnt` has no reset.** Expect this on the first power-aware run:
`work_count` will come back X after power restore, where plain RTL simulation
shows the stale pre-shutdown value. It is benign — `cstate` resets to `IDLE` and
`cnt` is reloaded from `work_len` before it is ever read — but it makes
`work_count` unusable as a post-restore observability signal until `cnt` gets a
reset value, and it is exactly the class of difference power-aware simulation
exists to surface.

---

## The PPU domain

`ppu_pd_top.upf` / `ppu_pd_tb.upf`, for the domain in
[`src/rtl/ppu`](../rtl/ppu/README.md). Same file split, same PCSA rules, same
`make`-target shape (`make ppupa`). What is worth reading it for is that
**three of the four "Known gaps" above are answered there rather than
restated** — not because the Q-Channel design was changed, but because a PPU is
the block whose absence made them unanswerable.

The gaps are still open for `qchannel_pd_top`. Nothing in this section retires
them; it describes a second, independent domain that does not have them.

| Gap above | Status in `ppu_pd_top.upf` |
|---|---|
| Wrappers powered but still reset by the domain reset | **Closed.** `u_dev` takes `aon_rst_n` resynchronised into `dclk`, so `DEVQACTIVE` is live while the domain is down and `wake` genuinely revives it — testbench phase P7 measures exactly that. |
| Power sequencing collapsed onto one signal | **Closed.** The isolation enable is `DEVISOLATEn` and the switch control is the PCSM's decode of `PCSMPSTATE`. `ppu_seq` drives them apart in the §4.1.5 order with programmable gaps, so isolation engages strictly before the supply goes and releases strictly after it returns. |
| No power-good acknowledge | **Still open**, and unchanged: the PPU architecture has no power-good input either (spec §6.5 lists none). The obligation moves to the PCSM, which must not assert `PCSMPACCEPT` until its rails have settled. |
| `dummy_workload.cnt` has no reset | **Closed for the PPU domain.** `dummy_workload` was replaced by `ppu_device_ip`, whose counter is reset. Still open for `qchannel_pd_top`, which still instantiates the old workload. |

### Why the reset split was safe here and not there

The gap note above says the two changes "belong in one change", and gives the
reason: once `QACTIVE` can rise from an unpowered domain, the interface can
leave `Q_STOPPED` before the supply is back, which LPI §2.1.2 forbids.

`ppu_top` discharges that by tying `qchannel_controller`'s
`enb_qactive_led_quiescence_exit` **LOW** — the opposite of the Figure 2-8
policy the other integrations use — and routing `DEVQACTIVE` into the sequencer
instead. The controller then cannot un-quiesce on its own; `DEVQACTIVE` becomes
a wake *request*, and `ppu_seq` restores the PCSM state, de-isolates, restarts
the clock and releases the resets before dropping the quiescence request. The
protocol violation the gap note warned about is structurally unreachable.

### One thing it needs that the Q-Channel domain did not

**Retention.** `qchannel_pd_top.upf` rejects it outright and is right to: PCSA
§8.3.4 makes reset equivalent to quiescent, and its switched domain holds
nothing worth saving.

That argument does not survive a PPU. `FULL_RET` is defined as "Logic RET, RAM
RET" (spec Table 3-1) and backed by a device-control row found in no other mode
(Table 4-11): `DEVWARMRESETn` asserts to reset the non-retained logic while
`DEVPORESETn` and `DEVRETRESETn` stay HIGH. A mode that resets some flops and
not others is only meaningful if some flops retain — so `ppu_pd_top.upf`
carries a `set_retention` strategy on the workload, saved and restored on
`DEVRETRESETn`, powered from a second switched rail.

That second rail is also why the PPU domain has **two** power switches where
the Q-Channel domain has one: `FULL_RET` needs the retention supply present
while the primary supply is absent, which is a pair of states a single switch
cannot express.

### What power-aware simulation adds there specifically

Under `make ppu` — no power intent — `FULL_RET`, `MEM_RET` and `OFF` are
indistinguishable: in all three the workload is held in reset and reads back its
reset values. Under `make ppupa`, `-simstate CORRUPT` plus the retention
strategy separates them, which is the only way to demonstrate that the PPU's
mode distinctions reach anything physical.


## Validation: what `make ppuupf` did (retired)

> **Retired on 2026-10-05.** `make ppuupf` and `lint/ppu_upf_check.py` were
> removed with `src/lint` (commit 63e671d). This section is kept as the record
> of what the check did. Today the design-object references are resolved by
> the power-aware runs themselves, and for `soc4_top.upf` also by VC LP's
> static checks (`make vclp`).

`make ppuupf` predated the power-aware runs. It was written when no tool here
read UPF at all and this file was validated by **reading it**, which is
precisely the standard the rest of this repository refuses to accept.

It is still worth keeping now that `make ppupaall` runs, because the two catch
different things and the cheap one catches them sooner. A simulation proves the
references resolved *for the instances it elaborated*; this proves it for the
file, in about a second, without a simulator licence, and it names the offending
option and line rather than presenting the failure as X propagation somewhere
downstream. It is also the only check that runs against `ppu_pd_top.upf` as the
synthesis input, where there is no testbench wrapper at all.

The power intent has the same failure mode as a `-quiet` XDC constraint, and it
is the one the Vivado constraint check `ppu_lpi_check.tcl` (removed with
`src/constraints` on 2026-10-06) was written to catch: **a path that names nothing applies to nothing, silently.**
An isolation strategy whose element list matches no cells, a switch whose control
port names a signal that does not exist, a retention strategy on an empty list —
none of it appears as an error in a functional simulation, because a functional
simulation does not read the UPF.

`lint/ppu_upf_check.py` (removed) checked every design-object
reference against the hierarchy the simulator **elaborated**, taken from the VCD
header rather than re-derived by scraping SystemVerilog — if a module is renamed
or a port removed, the VCD knows and a source scrape might not. That is also why
the target depends on `make ppu`: it refuses to report success without one.

When this section was written, **22 references**, all resolving:

| Kind | Examples |
|---|---|
| instances (`-elements`) | `u_clkctrl`, `u_dummy` |
| design ports (`-ports`) | `aon_clk`, `dclk`, `wake`, … |
| signals | `u_ppu/dev_isolaten`, `u_ppu/dev_retresetn`, `u_pcsm/logic_on`, `u_pcsm/logic_ret` |

Two design decisions worth recording:

- **`-ports` is classified per command, not per option.** In
  `set_port_attributes` it names design ports; in `connect_supply_net` it names
  *supply* ports, which are UPF objects with no netlist existence. Keying on the
  option alone would either fail on correct intent or check nothing.
- **Every option must be classified, or the run fails.** Checking twenty
  references correctly says nothing if the file contains a twenty-first the
  parser did not recognise — that would be this script's own failure mode, one
  level up. Adding an unknown option produces
  `FAIL option -sink_off_clamp in set_isolation -- not classified` rather than a
  silent pass.

What it does **not** check is whether the intent is *correct* — clamp values,
save/restore edges, supply expressions. Those are review questions, argued above.
This answers the narrower one review is worst at: does every name refer to
something real.

---

## The device IP, and what it made observable

`dummy_workload` was a counter with a busy flag. It was enough to negotiate a
Q-Channel with and nothing else, and that had a consequence worth stating
plainly: **below the PCSM, six of the seven power modes were the same thing.**
It had no RAM, so `PPU_FUNRR`/`PPU_FULRR`/`PPU_MEMRR` — three whole registers of
RAM retention configuration — reached nothing; and it had no retained state, so
`FULL_RET` was indistinguishable from `MEM_RET`.

[`ppu_device_ip`](../rtl/ppu/ppu_device_ip.sv) replaces it with three classes of
state that survive different things, so that every mode produces a different
observable result:

| mode | `u_core` (non-retained) | `u_ret` (retained) | bank, `cfg`=1 | bank, `cfg`=0 |
|---|---|---|---|---|
| `ON` | keep | keep | keep | keep |
| `WARM_RST` | reset | reset | keep | keep |
| `FUNC_RET` | keep | keep | keep | **lost** |
| `MEM_OFF` | keep | keep | **lost** | **lost** |
| `FULL_RET` | **reset** | keep | keep | **lost** |
| `MEM_RET` | corrupt | corrupt | keep | **lost** |
| `OFF` | corrupt | corrupt | **lost** | **lost** |

No two rows are alike. `ppu_pd_tb` phase P23a walks all six non-`ON` rows and
checks all four columns of each.

### Where the RAM's power intent lives, and why it is not here

The eight SRAM banks are **excluded from `PD_DEV`**. They sit on the always-on
rail, and `ppu_pcsm` drives their `sleep`/`shutdown` pins per bank instead.

That is the faithful model, not a shortcut. A compiled SRAM is not power-gated
by the standard-cell rail's switch — it has its own pins, and the memory
compiler's model implements them. Putting the array in the switched domain would
also be actively wrong: `MEM_RET` is "Logic OFF, RAM RET", so `-simstate
CORRUPT` would destroy the memory in exactly the mode whose definition is that
it survives, and the transcript would still look correct because the PPU
sequences that mode identically either way.

`ram_cfg` is `PCSMPSTATE[15:8]`, which the specification leaves IMPLEMENTATION
DEFINED. This design defines it as one retention enable per bank, so a bank
whose bit is clear is shut down even in a RAM-retaining mode. That is what makes
the three RAM retention registers observable for the first time.

### Three bugs the new IP exposed

All three were invisible to every check that existed before it, and all three
are the same shape: **a control that looked correct in its settled state and was
wrong in transition.**

**The SRAM shutdown pin glitched on every mode change.** Decoding
`sleep`/`shutdown` in the device from `ram_on`, `ram_ret` and `ram_cfg` — three
separate continuous assignments off one register — let them settle in three
different delta cycles, leaving the shutdown term momentarily true for banks the
mode existed to retain. Measured: bank 0 held `0xe2a55a5a` before an
`ON`→`FUNC_RET` transition and `X` immediately after, with its shutdown bit
reading 0 on both sides. Fixed by computing and **registering** both pins in
`ppu_pcsm`. A tidier combinational decode would have fixed simulation and still
glitched in silicon, where the gates have unequal delays.

**The retention strategy never saved.** `-save_signal {u_ppu/dev_retresetn
negedge}` was chosen because Table 4-8 calls `DEVRETRESETn` the retention
register reset — but Table 4-9 leaves it **HIGH throughout `FULL_RET`**. A save
signal with no edge never saves. The correct control is a PCSM output:
Figure 4-1 shows the PPU has no save/restore among its device outputs at all,
and the PCSM drives what the figure labels *technology specific controls*.

**The retention rail had no make-before-break.** `logic_on` and `logic_ret` were
both continuous assignments off `cur_state`, so `SW_LOGIC` opened before
`SW_RET` closed and `VDD_RET` was briefly absent — long enough for `SS_RET` to
match its `CORRUPT` state and destroy the value that had just been saved.
Reduced to a 40-line testcase: driving the two switch controls from two
independent signals passes, and changing *only* their derivation to two
continuous assignments off one shared register fails.

That last one also corrected a rule in the power model. `PU7` read "the full and
retention supplies are never on together", which was *accidentally* true when
the two were mutually-exclusive decodes — it restated the decode instead of
checking a hazard, and it forbade the only safe ordering. It now checks
make-before-break in both directions, and mutation-testing confirms it fires on
the original bug at the first `FULL_RET` transition.
