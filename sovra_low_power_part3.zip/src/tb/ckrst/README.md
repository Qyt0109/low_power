# ckrst_bridge testbench

The clock/reset request bridge
[`src/rtl/ckrst/ckrst_bridge.sv`](../../rtl/ckrst/ckrst_bridge.sv) (platform
plan H16, F11, V5) on a real PPU domain, against a model of the SoC's clock
gate and tile reset blocks. The bridge forwards the PPU's DEVCLKEN and device
resets as requests to the SoC and flags an acknowledgement that is late,
missing or spurious. The RTL is described in
[`src/rtl/ckrst/README.md`](../../rtl/ckrst/README.md).

## Files

| File | Top / role | Target | What it does |
|---|---|---|---|
| `ckrst_bridge_tb.sv` | `ckrst_bridge_tb` | `ckrst` | `ppu_dom_top` (PPU, PCSM, device wrapper; DEF_PWR_POLICY OFF) driving a `ckrst_bridge`, answered by `soc_ckrst_model`; the testbench plays the SCP |
| `soc_ckrst_model.sv` | `soc_ckrst_model` | (also used by `soc4_tb`, one per domain) | The SoC's clkgate/tilereset for one tile: each acknowledgement follows its request after `lat_clk` / `lat_rst` cycles (at least 1). `hold_clk` / `hold_rst` never acknowledge; `flip_clk` HIGH for one cycle makes the clock acknowledgement change on its own. `n_edges` counts request edges. At reset every acknowledgement is LOW (clock stopped, resets applied) |

## What is checked (18 checks in the latest regression)

The testbench does what the firmware does (`mod/pd.c`): it programs the PPU's
DCDR fields from the domain's worst-case latency L (`ckrst_lat`):
CLKEN_RST_DLY, CLKEN_ISO_DLY and RST_HWSTAT_DLY = max(default, L).

| Tag | Claim |
|---|---|
| `DCDR` | The DCDR registers read back as programmed for L = 6 (`0x0006_1406`, `0x0000_0602`) |
| `COVER` | DCDR from L, the SoC answering within L: no fault over OFF → ON → OFF → ON → WARM_RST → ON → OFF, and a clean power-down at the end |
| `FWD` | Every request equals its PPU control in every cycle; at least 12 request edges seen |
| `LATE` | DCDR at the defaults (2) with the SoC at 6: LATE on the clock at power-up (reset released before the clock is acknowledged) and at power-down (isolation before the clock is acknowledged stopped); DCDR from 6 with the SoC at 18: LATE again; W1C clears the status; `fault_o` |
| `MISSING` | Reset 0 never acknowledged: MISSING on that reset; cleared after the late acknowledgement and a W1C |
| `SPURIOUS` | The clock acknowledgement moving on its own |

Mutant: `CKRST_MUT_NOLATE` (`rtl/ckrst/ckrst_bridge.sv`) removes the LATE
check, so an acknowledgement that arrives after the PPU moved on passes. It
must fail at `LATE`; in the latest regression it raised 3 `[chk:LATE]` errors.

## Running

```
make -C src ckrst SIM=vcs
```

The target fails unless `RESULT: PASS`, then rebuilds with `CKRST_MUT_NOLATE`
and fails unless that run ends `RESULT: FAIL` with a `[chk:LATE]` error. Log:
`build/vcs/ckrst_bridge_tb/ckrst.log`. The firmware's side of the bridge (DCDR
from the domain table, a late acknowledgement logged and FAULTed) is
`make soc4ckrst`, step K1 of [`soc4_tb`](../soc4/README.md).

## Adding a test

Add a step to the "SCP" `initial` block, using the model's knobs (`lat_*`,
`hold_*`, `flip_clk`) for the SoC's behaviour, and check with
`tck("<TAG>", cond, msg)`. A new mutant needs an `` `ifdef `` in the RTL and a
`$(call unit_neg,ckrst_bridge_tb,$(CKRST_SRCS),<DEFINE>,<TAG>)` line in the
`ckrst` target.

## References

- [`src/rtl/ckrst/README.md`](../../rtl/ckrst/README.md) and the header of
  `ckrst_bridge.sv` (WHAT IS A FAULT, THE CHANNELS AND THE PROTOCOL).
- Arm DEN 0051E Section 4.1.5 and Table 4-5 (the device control delays).
- Formal: [`src/formal/ckrst_bridge/`](../../formal/ckrst_bridge/README.md).
