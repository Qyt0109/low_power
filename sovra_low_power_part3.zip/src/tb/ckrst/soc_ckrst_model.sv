`timescale 1ns/1ps
// A model of the SoC's clkgate and tilereset for one tile, as the clock/reset
// request bridge (rtl/ckrst/ckrst_bridge.sv, platform plan H16, V5) sees
// them: each acknowledgement follows its request after a configurable
// latency. Testbench only (ckrst_bridge_tb, soc4_tb).
//
// lat_clk, lat_rst  cycles from a request edge (as the bridge sees it) to the
//                   acknowledgement edge (as the bridge sees it); at least 1
// hold_clk/hold_rst never acknowledge (a missing acknowledgement)
// flip_clk          HIGH for one cycle: the clock acknowledgement changes on
//                   its own (a spurious one); it then follows the request again
//
// Reset: every acknowledgement LOW (clock stopped, resets applied), which is
// what the PPU drives at reset (DEVCLKEN LOW, the resets asserted).

module soc_ckrst_model #(
  parameter int unsigned NUM_RST = 2
) (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               clk_req,
  output logic               clk_ack,
  input  logic [NUM_RST-1:0] rst_req_n,
  output logic [NUM_RST-1:0] rst_ack_n,
  input  int unsigned        lat_clk,
  input  int unsigned        lat_rst,
  input  bit                 hold_clk,
  input  bit                 hold_rst,
  input  bit                 flip_clk
);

  int unsigned cnt [NUM_RST + 1];
  int unsigned n_edges = 0;             // request edges seen, all channels
  logic [NUM_RST:0] req_d = '0;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      clk_ack   <= 1'b0;
      rst_ack_n <= '0;
      foreach (cnt[c]) cnt[c] = 0;
    end else begin
      for (int c = 0; c <= NUM_RST; c++) begin
        automatic logic r = (c == 0) ? clk_req : rst_req_n[c - 1];
        automatic logic a = (c == 0) ? clk_ack : rst_ack_n[c - 1];
        automatic int unsigned l = (c == 0) ? lat_clk : lat_rst;
        automatic bit h = (c == 0) ? hold_clk : hold_rst;
        if (r !== req_d[c]) n_edges++;
        req_d[c] = r;
        if (c == 0 && flip_clk && r === a) begin
          clk_ack <= ~clk_ack;
          cnt[c] = 0;
        end else if (r !== a) begin
          if (!h && cnt[c] + 1 >= ((l == 0) ? 1 : l)) begin
            if (c == 0) clk_ack <= r;
            else        rst_ack_n[c - 1] <= r;
            cnt[c] = 0;
          end else begin
            cnt[c] = cnt[c] + 1;
          end
        end else begin
          cnt[c] = 0;
        end
      end
    end
  end

endmodule
