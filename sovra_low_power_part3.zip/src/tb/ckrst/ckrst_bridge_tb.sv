`timescale 1ns/1ps
// ckrst_bridge_tb -- the clock/reset request bridge (rtl/ckrst/
// ckrst_bridge.sv; platform plan H16, F11, V5) on a real PPU domain
// (ppu_dom_top: PPU, PCSM, device wrapper) against a model of the SoC's
// clkgate and tilereset with a configurable acknowledgement latency
// (soc_ckrst_model.sv).
//
//   TB "SCP" ──reg──► ppu_dom_top ──dev_clken_req, dev_*_rst_n, dev_isolaten──►
//                        ckrst_bridge ──requests──► soc_ckrst_model ──acks──┐
//                             ▲ stat_o, fault_o ◄───────────────────────────┘
//
// The testbench does what the firmware does (mod/pd.c): it programs the
// PPU's DCDR fields from the domain's worst-case latency L (ckrst_lat),
// CLKEN_RST_DLY, CLKEN_ISO_DLY and RST_HWSTAT_DLY = max(default, L). Groups,
// tagged for the negative control (make ckrst):
//   [chk:FWD]       every request forwarded unchanged, every cycle
//   [chk:COVER]     DCDR from L, the SoC answering within L: no fault, over
//                   ON/OFF/ON/WARM_RST/ON/OFF
//   [chk:LATE]      the DCDR fields left at their defaults (2) with the SoC at
//                   L = 6: LATE on the clock at power-up (the reset released
//                   before the clock is acknowledged) and at power-down
//                   (isolation before the clock is acknowledged stopped);
//                   with DCDR from L but the SoC at 3 * L: LATE again. W1C,
//                   and fault_o
//   [chk:MISSING]   a reset never acknowledged: MISSING on that reset
//   [chk:SPURIOUS]  the clock acknowledgement moving on its own
//   [chk:DCDR]      the DCDR registers read back as programmed

module ckrst_bridge_tb;
  import ppu_pkg::*;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  int unsigned checks = 0, errors = 0;
  task automatic tck(input string tag, input bit cond, input string msg);
    checks++;
    if (!cond) begin
      errors++;
      $display("[%0t] tb| ERROR: [chk:%s] %s", $time, tag, msg);
    end
  endtask

  // ---- The PPU domain ----
  logic [11:0] reg_waddr = '0, reg_raddr = '0;
  logic [31:0] reg_wdata = '0, reg_rdata;
  logic        reg_wen = 1'b0, reg_ren = 1'b0, irq;
  logic        dclk_gated, clken_req, nret_rst_n, ret_rst_n, isolaten, qok;
  logic [15:0] hwstat;

  ppu_dom_top #(
    .DEF_PWR_POLICY     (PM_OFF),
    .PCSM_RESET_MODESTAT(PM_OFF),
    .WARM_RST_DEVREQEN_CFG(1'b0)
  ) u_pd (
    .aon_clk(clk), .aon_rst_n(rst_n),
    .reg_waddr(reg_waddr), .reg_wdata(reg_wdata), .reg_wen(reg_wen), .reg_wstrb(4'hF),
    .reg_raddr(reg_raddr), .reg_ren(reg_ren), .reg_rdata(reg_rdata), .irq(irq),
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(), .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(clk),
    .dev_quiescent_busy(1'b0), .dev_quiescent_deny(1'b0), .dev_wake(1'b0),
    .dev_quiescent_ok(qok), .dev_clk(dclk_gated), .dev_clken_req(clken_req),
    .dev_nret_rst_n(nret_rst_n), .dev_ret_rst_n(ret_rst_n), .dev_isolaten(isolaten),
    .ppuhwstat(hwstat), .logic_on(), .logic_ret(), .ret_n(), .ram_sleep(), .ram_sd()
  );

  // ---- The bridge and the SoC blocks ----
  logic       clk_req, clk_ack, fault;
  logic [1:0] rst_req_n, rst_ack_n;
  logic [7:0] stat, stat_clr = '0;
  int unsigned lat_clk = 1, lat_rst = 1;
  bit          hold_clk = 0, hold_rst = 0, flip_clk = 0;

  ckrst_bridge #(.NUM_RST(2), .STEP_W(1), .STEP_SYNC(2), .ACK_SYNC(0), .MAX_WAIT(300)) u_br (
    .clk_i(clk), .rst_ni(rst_n),
    .clken_i(clken_req), .rst_n_i({ret_rst_n, nret_rst_n}), .step_i(isolaten),
    .clk_req_o(clk_req), .clk_ack_i(clk_ack), .rst_req_no(rst_req_n), .rst_ack_ni(rst_ack_n),
    .stat_o(stat), .stat_clr_i(stat_clr), .fault_o(fault));

  soc_ckrst_model #(.NUM_RST(2)) u_soc (
    .clk(clk), .rst_n(rst_n), .clk_req(clk_req), .clk_ack(clk_ack),
    .rst_req_n(rst_req_n), .rst_ack_n(rst_ack_n),
    .lat_clk(lat_clk), .lat_rst(lat_rst), .hold_clk(hold_clk), .hold_rst(hold_rst),
    .flip_clk(flip_clk));

  // ---- FWD: every cycle ----
  int unsigned fwd_bad = 0;
  always @(posedge clk)
    if (rst_n && (clk_req !== clken_req || rst_req_n !== {ret_rst_n, nret_rst_n})) fwd_bad++;

  // ---- The "SCP" ----
  task automatic wreg(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); reg_waddr = a; reg_wdata = d; reg_wen = 1'b1;
    @(negedge clk); reg_wen = 1'b0;
  endtask
  task automatic rreg(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk); reg_raddr = a; reg_ren = 1'b1;
    @(negedge clk); reg_ren = 1'b0;
    @(negedge clk); d = reg_rdata;
  endtask
  task automatic go(input logic [3:0] m, output bit ok);
    int unsigned t = 0;
    wreg(12'h000, {28'h0, m});                  // PPU_PWPR: static policy m
    while (u_pd.u_ppu.u_seq.pwr_status !== m && t < 5000) begin @(posedge clk); t++; end
    repeat (20) @(posedge clk);
    ok = (u_pd.u_ppu.u_seq.pwr_status === m);
  endtask
  // mod/pd.c's rule: each field that paces a bridged step >= the latency
  function automatic logic [7:0] cover_dly(input logic [7:0] dflt, input int unsigned lat);
    return (lat > dflt) ? 8'(lat) : dflt;
  endfunction
  task automatic dcdr_from(input int unsigned lat);
    wreg(12'h170, {8'h0, cover_dly(8'd2, lat), 8'd20, cover_dly(8'd4, lat)});   // RST_HWSTAT, ISO_CLKEN, CLKEN_RST
    wreg(12'h174, {16'h0, cover_dly(8'd2, lat), 8'd2});                    // CLKEN_ISO, ISO_RST
  endtask
  task automatic clear_stat();
    @(negedge clk) stat_clr = 8'hFF;
    @(negedge clk) stat_clr = 8'h00;
  endtask

  logic [31:0] r0, r1;
  bit ok;

  initial begin
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (8) @(negedge clk);

    // ---- COVER: DCDR from L = 6, the SoC answering in 6 ----
    dcdr_from(6);
    rreg(12'h170, r0);
    rreg(12'h174, r1);
    tck("DCDR", r0 === 32'h0006_1406 && r1 === 32'h0000_0602,
        $sformatf("DCDR0 0x%08h DCDR1 0x%08h, expected 0x00061406 0x00000602 (L = 6)", r0, r1));
    lat_clk = 6; lat_rst = 6;
    go(PM_ON, ok);   tck("COVER", ok, "OFF -> ON");
    go(PM_OFF, ok);  tck("COVER", ok, "ON -> OFF");
    go(PM_ON, ok);   tck("COVER", ok, "OFF -> ON");
    go(PM_WARM_RST, ok); tck("COVER", ok, "ON -> WARM_RST");
    go(PM_ON, ok);   tck("COVER", ok, "WARM_RST -> ON");
    go(PM_OFF, ok);  tck("COVER", ok, "ON -> OFF");
    tck("COVER", stat === 8'h00 && !fault,
        $sformatf("the SoC within the programmed delays: status 0x%02h, expected 0", stat));
    tck("FWD", u_soc.n_edges >= 12, $sformatf("only %0d request edges seen", u_soc.n_edges));
    $display("[%0t] tb| COVER: six transitions with DCDR from L = 6 and the SoC at 6: no fault (%0d request edges)",
             $time, u_soc.n_edges);

    // ---- LATE: DCDR at the defaults, the SoC at 6 ----
    wreg(12'h170, 32'h0002_1404);
    wreg(12'h174, 32'h0000_0202);
    go(PM_ON, ok);
    tck("LATE", ok && stat[0] === 1'b1 && stat[4] === 1'b1 && fault === 1'b1,
        $sformatf("power-up with CLKEN_RST_DLY 4 and the clock acknowledged in 6: status 0x%02h, expected LATE|CLK", stat));
    clear_stat();
    tck("LATE", stat === 8'h00 && fault === 1'b0, "W1C did not clear the status");
    go(PM_OFF, ok);
    tck("LATE", ok && stat[0] === 1'b1 && stat[4] === 1'b1,
        $sformatf("power-down with CLKEN_ISO_DLY 2 and the clock acknowledged in 6: status 0x%02h, expected LATE|CLK", stat));
    clear_stat();
    // DCDR from L, but the SoC slower than L
    dcdr_from(6);
    lat_clk = 18; lat_rst = 18;
    go(PM_ON, ok);
    tck("LATE", ok && stat[0] === 1'b1, $sformatf("the SoC at 18 against DCDR from 6: status 0x%02h, expected LATE", stat));
    go(PM_OFF, ok);
    clear_stat();
    $display("[%0t] tb| LATE: the clock acknowledged after the reset release, and after the isolation: flagged", $time);

    // ---- MISSING: reset 0 never acknowledged ----
    lat_clk = 2; lat_rst = 2;
    dcdr_from(2);
    hold_rst = 1;
    wreg(12'h000, {28'h0, PM_ON});
    repeat (600) @(posedge clk);
    tck("MISSING", stat[1] === 1'b1 && stat[5] === 1'b1 && fault === 1'b1,
        $sformatf("a reset release never acknowledged: status 0x%02h, expected MISSING|RST0", stat));
    hold_rst = 0;
    repeat (20) @(posedge clk);
    clear_stat();
    go(PM_ON, ok);
    tck("MISSING", ok && stat === 8'h00, $sformatf("after the late acknowledgement and a clear: status 0x%02h", stat));

    // ---- SPURIOUS: the clock acknowledgement moves on its own ----
    @(negedge clk) flip_clk = 1;
    @(negedge clk) flip_clk = 0;
    repeat (10) @(posedge clk);
    tck("SPURIOUS", stat[2] === 1'b1 && stat[4] === 1'b1,
        $sformatf("the clock acknowledgement dropped with DEVCLKEN HIGH: status 0x%02h, expected SPURIOUS|CLK", stat));
    clear_stat();
    go(PM_OFF, ok);
    tck("COVER", ok && stat === 8'h00, $sformatf("a clean power-down to finish: status 0x%02h", stat));

    tck("FWD", fwd_bad == 0, $sformatf("%0d cycle(s) with a request not equal to the PPU's control", fwd_bad));

    $display("");
    $display("ckrst_bridge_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display("RESULT: PASS");
    else             $display("RESULT: FAIL");
    $finish;
  end

  initial begin
    #5ms;
    $display("[%0t] tb| ERROR: [chk:TIMEOUT] the run did not finish", $time);
    $display("ckrst_bridge_tb: %0d checks, %0d error(s)", checks, errors + 1);
    $display("RESULT: FAIL");
    $finish;
  end

endmodule
