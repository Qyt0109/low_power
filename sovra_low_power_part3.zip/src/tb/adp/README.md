# hart_ready_adp testbench

One unit testbench for the READY-bit Q-Channel adapter
[`src/rtl/adp/hart_ready_adp.sv`](../../rtl/adp/hart_ready_adp.sv) and its
TL-UL READY registers `hart_ready_regs.sv` (platform plan H14): the adapter
that lets a CVA6 or Rocket hart, which has no Q-Channel of its own, be powered
down by a PPU once its software has set READY and its TileLink ports have
drained. The RTL is described in [`src/rtl/adp/README.md`](../../rtl/adp/README.md).

## Files

| File | Top | Target | What it checks |
|---|---|---|---|
| `hart_ready_adp_tb.sv` | `hart_ready_adp_tb` | `readyadp` | The adapter and its registers against a modelled core with two harts and three ports, each hart's decision seen through a `qchannel_device` as inside `ppu_axi_dom_top` |

The modelled core: port 0 is hart 0's TL-C port (a CVA6 cached port: A, B, C,
D, E), port 1 hart 0's TL-UH port (its Ara vector port), port 2 hart 1's TL-UH
port (a Rocket hart). The testbench drives both valid and ready on every
channel (the adapter only observes them), writes the READY registers through
the vendored `tlul_adapter_reg` as the hart's last store would, and plays the
PPU: one static power-down request per check (`QREQn`), reading
`QACCEPTn`/`QDENY`.

## What is checked (35 checks in the latest regression)

| Tag | Claim |
|---|---|
| `REG` | `INFO` reads the number of harts; `READY_h` reads back the hart's write; `READY_ALL` reads the OR and a write to it answers `d_error` and changes nothing; an unmapped offset answers `d_error` |
| `ACCEPT` | Accept only with READY set and every port of the hart idle; deny with READY clear, and with a wake in the cycle of the request; harts are independent (hart 1's busy port does not hold hart 0); `dev_busy_o` stays 0 |
| `DRAIN` | Deny while any message is in flight: an A request on the wires not yet taken, an A burst part-sent, a D burst part-received (8-beat AccessAckData), a response owed, a Grant not acknowledged on E, a Release not acknowledged, a Probe not answered; accept once each completes |
| `CLEAR` | READY cleared by a wake, by the domain returning to ON, by the hart's reset, by software and by the SCP; hart 1's READY untouched by hart 0's clears |
| `CLR_WINS` | A clear and a set in the same cycle leave READY clear (a wake in exactly the cycle of the hart's last store; a set while the hart is held in reset; a set while a wake is pending) |

Mutants (`make readyadp` rebuilds once per define):

| Define | Where | The fault | Must fail at | Latest run |
|---|---|---|---|---|
| `HART_READY_MUT_NODRAIN` | `rtl/adp/hart_ready_adp.sv` | the ports' outstanding transactions are not looked at | `DRAIN` | 8 `[chk:DRAIN]` errors |
| `HART_READY_MUT_SETWINS` | `rtl/adp/hart_ready_adp.sv` | a set wins over a clear | `CLR_WINS` | 2 `[chk:CLR_WINS]` errors |

## Running

```
make -C src readyadp SIM=vcs
```

The target fails unless the run prints `RESULT: PASS`, then rebuilds with
each mutant define and fails unless that run ends `RESULT: FAIL` with at least
one error of its own tag. The log is `build/vcs/hart_ready_adp_tb/readyadp.log`
(mutants: `neg_<DEFINE>.log`).

## Adding a test

Add stimulus in the main `initial` block and check with
`tck("<TAG>", cond, msg)`. A new mutant is an
`` `ifdef HART_READY_MUT_<X> `` in the RTL with a `NEGATIVE CONTROL` comment, and
one more `$(call unit_neg,hart_ready_adp_tb,$(ACG_OPTS) $(READYADP_SRCS),HART_READY_MUT_<X>,<TAG>)`
line in the `readyadp` target.

## References

- [`src/rtl/adp/README.md`](../../rtl/adp/README.md) and the header of
  `hart_ready_adp.sv` (READY, idle, THE DECISION).
- AMBA LPI (ARM IHI 0068C) Section 2.1 for the Q-Channel device side.
- Formal: [`src/formal/hart_ready_adp/`](../../formal/hart_ready_adp/README.md)
  proves the same rules, against the same two mutants, with an independent
  message model per port.
