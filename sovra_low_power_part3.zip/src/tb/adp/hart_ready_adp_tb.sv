`timescale 1ns/1ps
// hart_ready_adp_tb -- the READY-bit Q-Channel adapter (rtl/adp/
// hart_ready_adp.sv) and its TL-UL READY registers (hart_ready_regs.sv),
// platform plan H14, against a modelled core: three TileLink ports driven by
// the testbench (both valid and ready: the adapter only observes them) and
// a TL-UL host writing the READY registers, as the hart's last store would.
//
//   port 0  hart 0  TL-C   (a CVA6 core's cached port: A, B, C, D, E)
//   port 1  hart 0  TL-UH  (the same CVA6's Ara vector port)
//   port 2  hart 1  TL-UH  (a Rocket hart, the NPU host)
//
// Each hart's Q-Channel goes through a qchannel_device, as inside
// ppu_axi_dom_top; the testbench is the PPU (QREQn) and reads QACCEPTn/QDENY.
// Checks, tagged for the negative controls (make readyadp):
//   [chk:REG]       the registers: READY_h, READY_ALL, INFO, errors
//   [chk:ACCEPT]    accept only with READY set and every port of the hart
//                   idle; deny with READY clear, and with a wake in the
//                   cycle of the request; harts independent
//   [chk:DRAIN]     deny while any message is in flight: a request on the A
//                   wires, an A burst part-sent, a D burst part-received, a
//                   response owed, a Grant not acknowledged on E, a Release
//                   not acknowledged, a Probe not answered
//   [chk:CLEAR]     READY cleared by a wake, by the domain returning to ON,
//                   by the hart's reset, by software and by the SCP
//   [chk:CLR_WINS]  a clear and a set in the same cycle leave READY clear

module hart_ready_adp_tb;
  import tl_pkg::*;
  import tlul_pkg::*;

  localparam int unsigned NH = 2, NP = 3, SZW = 4;
  localparam logic [NP-1:0][7:0] PORT_HART = {8'd1, 8'd0, 8'd0};
  localparam logic [NP-1:0]      PORT_TLC  = 3'b001;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  int unsigned checks = 0, errors = 0;
  task automatic tck(input string tag, input bit cond, input string msg);
    checks++;
    if (!cond) begin
      errors++;
      $display("[%0t] tb| ERROR: [chk:%s] %s", $time, tag, msg);
    end
  endtask

  // ---- The modelled ports ----
  logic [NP-1:0]          a_valid = '0, a_ready = '1, d_valid = '0, d_ready = '1;
  logic [NP-1:0]          b_valid = '0, b_ready = '1, c_valid = '0, c_ready = '1;
  logic [NP-1:0]          e_valid = '0, e_ready = '1;
  logic [NP-1:0][2:0]     a_opcode = '0, d_opcode = '0, c_opcode = '0;
  logic [NP-1:0][SZW-1:0] a_size = '0, d_size = '0, c_size = '0;
  logic [NP-1:0]          idle;

  // ---- READY's clears, and the Q-Channels ----
  logic [NH-1:0] wake = '0, dom_on = '0, hart_rst_n = '1, scp_clr = '0, ready;
  logic [NH-1:0] busy, deny, sw_set, sw_clr;
  logic [NH-1:0] qreqn = '1, qacceptn, qdeny, qactive, qok;
  bit            race = 1'b0;           // wake[0] = the set pulse itself (CLR_WINS)
  logic [NH-1:0] wake_eff;
  assign wake_eff = wake | {1'b0, race & sw_set[0]};

  tl_h2d_t tl_h = TL_H2D_DEFAULT;
  tl_d2h_t tl_d;

  hart_ready_regs #(.NUM_HARTS(NH)) u_regs (
    .clk_i(clk), .rst_ni(rst_n), .tl_i(tl_h), .tl_o(tl_d),
    .ready_i(ready), .sw_set_o(sw_set), .sw_clr_o(sw_clr));

  hart_ready_adp #(
    .NUM_HARTS(NH), .NUM_PORTS(NP), .PORT_HART(PORT_HART), .PORT_TLC(PORT_TLC),
    .SZW(SZW), .LOG2_BYTES(3)
  ) u_dut (
    .clk_i(clk), .rst_ni(rst_n),
    .sw_set_i(sw_set), .sw_clr_i(sw_clr), .scp_clr_i(scp_clr),
    .wake_i(wake_eff), .dom_on_i(dom_on), .hart_rst_ni(hart_rst_n), .ready_o(ready),
    .a_valid_i(a_valid), .a_ready_i(a_ready), .a_opcode_i(a_opcode), .a_size_i(a_size),
    .d_valid_i(d_valid), .d_ready_i(d_ready), .d_opcode_i(d_opcode), .d_size_i(d_size),
    .b_valid_i(b_valid), .b_ready_i(b_ready), .c_valid_i(c_valid), .c_ready_i(c_ready),
    .c_opcode_i(c_opcode), .c_size_i(c_size), .e_valid_i(e_valid), .e_ready_i(e_ready),
    .port_idle_o(idle), .dev_busy_o(busy), .dev_deny_o(deny));

  for (genvar h = 0; h < NH; h++) begin : g_q
    qchannel_device #(.SYNC_STAGES(2)) u_q (
      .clk(clk), .rst_n(rst_n), .qreqn(qreqn[h]), .qacceptn(qacceptn[h]), .qdeny(qdeny[h]),
      .qactive(qactive[h]), .dev_quiescent_busy(busy[h]), .dev_quiescent_deny(deny[h]),
      .dev_wake(1'b0), .dev_quiescent_ok(qok[h]));
  end

  // ---- TL-UL host on the READY registers ----
  task automatic reg_acc(input bit wr, input logic [11:0] off, input logic [31:0] wd,
                         output logic [31:0] rd, output bit err);
    @(negedge clk);
    tl_h.a_valid   = 1'b1;
    tl_h.a_opcode  = wr ? PutFullData : Get;
    tl_h.a_size    = 2'd2;
    tl_h.a_mask    = 4'hF;
    tl_h.a_address = {20'h0, off};
    tl_h.a_data    = wd;
    tl_h.a_source  = 8'h05;
    tl_h.d_ready   = 1'b1;
    @(posedge clk);
    while (!tl_d.a_ready) @(posedge clk);
    @(negedge clk) tl_h.a_valid = 1'b0;
    while (!tl_d.d_valid) @(posedge clk);
    rd  = tl_d.d_data;
    err = tl_d.d_error;
    @(negedge clk);
  endtask

  // ---- The ports, beat by beat (one beat per cycle) ----
  function automatic int unsigned nb(input bit data, input int unsigned size);
    return (!data || size <= 3) ? 1 : (1 << (size - 3));
  endfunction
  task automatic a_beats(input int p, input logic [2:0] op, input int unsigned size, input int unsigned n);
    for (int k = 0; k < n; k++) begin
      @(negedge clk) a_valid[p] = 1'b1; a_opcode[p] = op; a_size[p] = SZW'(size);
    end
    @(negedge clk) a_valid[p] = 1'b0;
  endtask
  task automatic d_beats(input int p, input logic [2:0] op, input int unsigned size, input int unsigned n);
    for (int k = 0; k < n; k++) begin
      @(negedge clk) d_valid[p] = 1'b1; d_opcode[p] = op; d_size[p] = SZW'(size);
    end
    @(negedge clk) d_valid[p] = 1'b0;
  endtask
  task automatic c_beats(input int p, input logic [2:0] op, input int unsigned size, input int unsigned n);
    for (int k = 0; k < n; k++) begin
      @(negedge clk) c_valid[p] = 1'b1; c_opcode[p] = op; c_size[p] = SZW'(size);
    end
    @(negedge clk) c_valid[p] = 1'b0;
  endtask
  task automatic pulse(ref logic [NP-1:0] v, input int p);
    @(negedge clk) v[p] = 1'b1;
    @(negedge clk) v[p] = 1'b0;
  endtask

  // ---- The testbench as the PPU: one static power-down request ----
  // 1 = accepted (then exited again), 0 = denied.
  task automatic request(input int h, output bit accepted);
    int unsigned t = 0;
    @(negedge clk) qreqn[h] = 1'b0;
    while (qacceptn[h] !== 1'b0 && qdeny[h] !== 1'b1 && t < 50) begin @(posedge clk); t++; end
    accepted = (qacceptn[h] === 1'b0);
    @(negedge clk) qreqn[h] = 1'b1;
    t = 0;
    while (!(qacceptn[h] === 1'b1 && qdeny[h] === 1'b0) && t < 50) begin @(posedge clk); t++; end
  endtask

  task automatic set_ready(input int h, input bit v);
    logic [31:0] rd; bit err;
    reg_acc(1'b1, 12'(4 * h), {31'd0, v}, rd, err);
  endtask

  logic [31:0] rd;
  bit err, acc;

  initial begin
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (4) @(negedge clk);

    // ---- The registers ----
    reg_acc(1'b0, 12'h104, 0, rd, err);
    tck("REG", !err && rd == NH, $sformatf("INFO reads 0x%0h, expected %0d harts", rd, NH));
    reg_acc(1'b1, 12'h100, 32'h3, rd, err);
    tck("REG", err && ready == 2'b00, "a write to READY_ALL must answer d_error and change nothing");
    reg_acc(1'b0, 12'h200, 0, rd, err);
    tck("REG", err, "an unmapped offset must answer d_error");

    // ---- ACCEPT: READY clear denies; READY set and idle accepts ----
    request(0, acc);
    tck("ACCEPT", !acc, "hart 0: a request with READY clear must be denied");
    set_ready(0, 1'b1);
    reg_acc(1'b0, 12'h000, 0, rd, err);
    tck("REG", !err && rd == 1 && ready == 2'b01, $sformatf("READY_0 reads %0d after the hart's write of 1", rd));
    reg_acc(1'b0, 12'h100, 0, rd, err);
    tck("REG", !err && rd == 32'h1, $sformatf("READY_ALL reads 0x%0h, expected 0x1", rd));
    request(0, acc);
    tck("ACCEPT", acc, "hart 0: READY set and both ports idle: the request must be accepted");
    request(1, acc);
    tck("ACCEPT", !acc, "hart 1: READY clear: denied, whatever hart 0 does");

    // ---- DRAIN on port 0 (TL-C): a Get owed, then its 8-beat AccessAckData ----
    a_beats(0, TL_A_GET, 6, 1);
    request(0, acc);
    tck("DRAIN", !acc, "a Get's response owed: the request must be denied");
    fork
      d_beats(0, TL_D_ACCESS_ACKDATA, 6, 8);
      begin
        repeat (4) @(posedge clk);
        tck("DRAIN", !idle[0] && deny[0], "port 0 part-way through an 8-beat AccessAckData must not be idle");
      end
    join
    request(0, acc);
    tck("DRAIN", acc, "the Get answered in full: accepted");

    // ---- DRAIN on port 1 (Ara, TL-UH): a Put burst part-sent ----
    a_beats(1, TL_A_PUT_FULL, 5, 2);
    request(0, acc);
    tck("DRAIN", !acc, "a Put burst with 2 of its 4 beats sent: denied");
    a_beats(1, TL_A_PUT_FULL, 5, 2);
    request(0, acc);
    tck("DRAIN", !acc, "the Put burst sent, its AccessAck owed: denied");
    d_beats(1, TL_D_ACCESS_ACK, 5, 1);
    request(0, acc);
    tck("DRAIN", acc, "the Put acknowledged: accepted");

    // ---- DRAIN: a request on the wires, not yet taken ----
    @(negedge clk) a_ready[1] = 1'b0; a_valid[1] = 1'b1; a_opcode[1] = TL_A_GET; a_size[1] = 3;
    request(0, acc);
    tck("DRAIN", !acc, "an A request on the wires (a_valid HIGH, not yet taken): denied");
    @(negedge clk) a_valid[1] = 1'b0; a_ready[1] = 1'b1;

    // ---- DRAIN on the TL-C port: Acquire/GrantData/GrantAck, Release, Probe ----
    a_beats(0, TL_A_ACQUIRE_BLK, 6, 1);
    d_beats(0, TL_D_GRANT_DATA, 6, 8);
    request(0, acc);
    tck("DRAIN", !acc, "a GrantData received, its GrantAck (E) not yet sent: denied");
    pulse(e_valid, 0);
    request(0, acc);
    tck("DRAIN", acc, "GrantAck sent: accepted");
    c_beats(0, TL_C_RELEASE_DATA, 6, 8);
    request(0, acc);
    tck("DRAIN", !acc, "a ReleaseData sent, its ReleaseAck owed: denied");
    d_beats(0, TL_D_RELEASE_ACK, 6, 1);
    pulse(b_valid, 0);
    request(0, acc);
    tck("DRAIN", !acc, "a Probe received and not answered: denied");
    c_beats(0, TL_C_PROBE_ACK, 6, 1);
    request(0, acc);
    tck("DRAIN", acc, "the Probe answered: accepted");

    // ---- Harts are independent: port 2 (hart 1) busy does not touch hart 0 ----
    set_ready(1, 1'b1);
    a_beats(2, TL_A_ARITH, 3, 1);
    request(1, acc);
    tck("ACCEPT", !acc, "hart 1 with an atomic owed on port 2: denied");
    request(0, acc);
    tck("ACCEPT", acc, "hart 0 is not held up by hart 1's port");
    d_beats(2, TL_D_ACCESS_ACKDATA, 3, 1);
    request(1, acc);
    tck("ACCEPT", acc, "hart 1's atomic answered: accepted");

    // ---- A wake in the cycle of the request denies it ----
    @(negedge clk) wake[0] = 1'b1;
    request(0, acc);
    tck("ACCEPT", !acc, "a wake pending at the request: denied");
    @(negedge clk) wake[0] = 1'b0;

    // ---- CLEAR: each clear ----
    tck("CLEAR", ready[0] === 1'b0, "the wake must have cleared READY_0");
    set_ready(0, 1'b1);
    @(negedge clk) dom_on[0] = 1'b1;
    @(negedge clk);
    tck("CLEAR", ready[0] === 1'b0, "the domain returning to ON must clear READY_0");
    set_ready(0, 1'b1);
    @(negedge clk) hart_rst_n[0] = 1'b0;
    @(negedge clk);
    tck("CLEAR", ready[0] === 1'b0, "the hart's reset must clear READY_0");
    set_ready(0, 1'b1);
    tck("CLR_WINS", ready[0] === 1'b0, "a set while the hart is held in reset must not take");
    @(negedge clk) hart_rst_n[0] = 1'b1;
    set_ready(0, 1'b1);
    set_ready(0, 1'b0);
    tck("CLEAR", ready[0] === 1'b0, "software's write of 0 must clear READY_0");
    set_ready(0, 1'b1);
    @(negedge clk) scp_clr[0] = 1'b1;
    @(negedge clk) scp_clr[0] = 1'b0;
    tck("CLEAR", ready[0] === 1'b0, "the SCP's clear must clear READY_0");
    tck("CLEAR", ready[1] === 1'b1, "hart 1's READY must be untouched by hart 0's clears");

    // ---- CLR_WINS: a wake in exactly the cycle of the hart's last store ----
    race = 1'b1;
    set_ready(0, 1'b1);
    race = 1'b0;
    tck("CLR_WINS", ready[0] === 1'b0, "a wake in the same cycle as the set must leave READY clear");
    request(0, acc);
    tck("CLR_WINS", !acc, "...and the request after it denied");
    @(negedge clk) wake[1] = 1'b1;
    set_ready(1, 1'b1);
    @(negedge clk) wake[1] = 1'b0;
    tck("CLR_WINS", ready[1] === 1'b0, "a set while a wake is pending must not take");

    tck("ACCEPT", busy === '0, "dev_busy_o must stay 0: the adapter answers at once");

    $display("");
    $display("hart_ready_adp_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display("RESULT: PASS");
    else             $display("RESULT: FAIL");
    $finish;
  end

  initial begin
    #2ms;
    $display("[%0t] tb| ERROR: [chk:TIMEOUT] the run did not finish", $time);
    $display("hart_ready_adp_tb: %0d checks, %0d error(s)", checks, errors + 1);
    $display("RESULT: FAIL");
    $finish;
  end

endmodule
