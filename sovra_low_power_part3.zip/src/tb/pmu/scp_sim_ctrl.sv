`timescale 1ns/1ps
// Simulation control: the SCP firmware's window onto its testbench.
//
// Testbench only. It sits on scp_top's ext_* port at 0x0002_0000 and speaks
// bus.sv's protocol -- answer exactly one cycle after the request -- so to the
// firmware it is an ordinary private peripheral. src/pmu/fw/hal/sim.h is the
// firmware's half of this register map; the two must agree.
//
//   off    name        access  what it does
//   0x000  OUT         W       byte to the console; '\n' ends the line
//   0x004  CYCLE       R       free-running cycle count since reset
//   0x008  HALT        W       end the test; the value is the firmware's verdict
//                              (0 = pass, anything else = its failure code)
//   0x00C  CHECK       W       {[15:8] domain, [3:0] mode}: the firmware claims
//                              that domain is in that mode, and the testbench
//                              checks the claim against the hardware
//   0x010  WAKE        RW      bit n -> domain n's wake input (DEVQACTIVE)
//   0x014  DENY        RW      bit n -> domain n's deny_enb
//   0x018  WORK_LEN    RW      [15:0] burst length for START, all domains (the
//                              testbench uses as many bits as its device has)
//   0x01C  START       W       bit n -> a one-cycle start pulse to domain n
//   0x020  LIGHT       RW      bit n -> domain n's light_work (1 = never busy)
//   0x024  TB_CHECKS   R       checks the testbench has made so far
//   0x028  TB_ERRORS   R       ...and how many failed
//   0x02C  OBS_DOM     RW      which domain the observation window shows
//   0x030  IP_CMD      RW      [2n+1:2n] -> domain n's device IP command
//                              (00 idle, 01 fill RAM, 10 verify RAM)
//   0x034  IP_SEED     RW      [7:0] the fill/verify pattern seed, all domains
//   0x038  AP_CMD      RW      a command to the testbench (0 = none); soc4_tb
//                              takes 'H' (hold_busy mask) and 'D' (ACC deny
//                              mask), SOC4_DESIGN.md Section 10.1
//   0x03C  AP_STAT     R       the testbench's report: soc4_tb echoes the
//                              command once it is applied
//   0x040  OBS[0..31]  R       the testbench's pin-level observations of that
//   ..0x0BC                    domain (soc4_tb.sv, "Observation window"): counts
//                              of handshakes and PCSM requests, measured
//                              latencies and spacings, live pin values
//
// Any other offset is a bus error, so a firmware bug that strays into this
// window faults instead of silently writing nothing.
//
// WHY THE FIRMWARE DRIVES THE DEVICE STIMULUS
//
// In the SoC, wake and busy come from the software and interrupts in each
// domain, which a stand-in device does not have. Here
// the SCP firmware plays their part as well as its own, through WAKE, DENY and
// START, so that a test is one program with one timeline instead of a
// firmware and a testbench racing each other. The line between the two roles
// is kept in the firmware: everything touching these registers is in a test
// program (soc4/fw/test/), never in pmu/fw/hal/ or pmu/fw/mod/.

module scp_sim_ctrl #(
  parameter int unsigned NUM_PD = 12,
  // The console prefix: "fw" for the SCP, "ap" for soc4's AP (SOC4_DESIGN.md
  // Section 6.4). Every "fw|" the Makefile greps for is the default.
  parameter string       TAG    = "fw"
) (
  input  logic              clk_i,
  input  logic              rst_ni,

  // ---- bus.sv device port ----
  input  logic              req_i,
  input  logic              we_i,
  input  logic [3:0]        be_i,
  input  logic [31:0]       addr_i,
  input  logic [31:0]       wdata_i,
  output logic              rvalid_o,
  output logic [31:0]       rdata_o,
  output logic              err_o,

  // ---- To the testbench ----
  output logic              halt_o,        // sticky
  output logic [31:0]       halt_code_o,
  output logic              check_o,       // one cycle per CHECK write
  output logic [7:0]        check_dom_o,
  output logic [3:0]        check_mode_o,
  input  logic [31:0]       tb_checks_i,
  input  logic [31:0]       tb_errors_i,

  // ---- Device stimulus ----
  output logic [NUM_PD-1:0] wake_o,
  output logic [NUM_PD-1:0] deny_o,
  output logic [NUM_PD-1:0] light_o,
  output logic [NUM_PD-1:0] start_o,       // one-cycle pulses
  output logic [15:0]       work_len_o,
  output logic [NUM_PD-1:0][1:0] ip_cmd_o,
  output logic [7:0]        ip_seed_o,

  // ---- A command to the testbench, and its report ----
  output logic [31:0]       ap_cmd_o,
  input  logic [31:0]       ap_stat_i,

  // ---- Observation window: the testbench supplies obs_val_i for the
  //      domain and index shown, combinationally ----
  output logic [7:0]        obs_dom_o,
  output logic [4:0]        obs_idx_o,
  input  logic [31:0]       obs_val_i
);

  localparam logic [11:0] R_OUT       = 12'h000;
  localparam logic [11:0] R_CYCLE     = 12'h004;
  localparam logic [11:0] R_HALT      = 12'h008;
  localparam logic [11:0] R_CHECK     = 12'h00C;
  localparam logic [11:0] R_WAKE      = 12'h010;
  localparam logic [11:0] R_DENY      = 12'h014;
  localparam logic [11:0] R_WORK_LEN  = 12'h018;
  localparam logic [11:0] R_START     = 12'h01C;
  localparam logic [11:0] R_LIGHT     = 12'h020;
  localparam logic [11:0] R_TB_CHECKS = 12'h024;
  localparam logic [11:0] R_TB_ERRORS = 12'h028;
  localparam logic [11:0] R_OBS_DOM   = 12'h02C;
  localparam logic [11:0] R_IP_CMD    = 12'h030;
  localparam logic [11:0] R_IP_SEED   = 12'h034;
  localparam logic [11:0] R_AP_CMD    = 12'h038;
  localparam logic [11:0] R_AP_STAT   = 12'h03C;
  localparam logic [11:0] R_OBS_LO    = 12'h040;
  localparam logic [11:0] R_OBS_HI    = 12'h0BC;

  logic [11:0] off;
  assign off = addr_i[11:0];

  logic [7:0]  obs_dom_q;
  logic        obs_hit;
  logic [11:0] obs_off;
  assign obs_hit   = (off >= R_OBS_LO) && (off <= R_OBS_HI) && (off[1:0] == 2'b00);
  assign obs_off   = off - R_OBS_LO;
  assign obs_dom_o = obs_dom_q;
  assign obs_idx_o = obs_off[6:2];

  logic [31:0] cycle_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rvalid_o     <= 1'b0;
      rdata_o      <= '0;
      err_o        <= 1'b0;
      halt_o       <= 1'b0;
      halt_code_o  <= '0;
      check_o      <= 1'b0;
      check_dom_o  <= '0;
      check_mode_o <= '0;
      wake_o       <= '0;
      deny_o       <= '0;
      light_o      <= '0;
      start_o      <= '0;
      work_len_o   <= '0;
      cycle_q      <= '0;
      obs_dom_q    <= '0;
      ip_cmd_o     <= '0;
      ip_seed_o    <= '0;
      ap_cmd_o     <= '0;
    end else begin
      cycle_q  <= cycle_q + 32'd1;
      check_o  <= 1'b0;
      start_o  <= '0;
      rvalid_o <= req_i;
      err_o    <= 1'b0;
      rdata_o  <= '0;
      if (req_i) begin
        unique case (off)
          R_OUT:       ;                              // see the console below
          R_CYCLE:     rdata_o <= cycle_q;
          R_HALT:      if (we_i) begin
                         halt_o      <= 1'b1;
                         halt_code_o <= wdata_i;
                       end
          R_CHECK:     if (we_i) begin
                         check_o      <= 1'b1;
                         check_dom_o  <= wdata_i[15:8];
                         check_mode_o <= wdata_i[3:0];
                       end
          R_WAKE:      if (we_i) wake_o     <= wdata_i[NUM_PD-1:0];
                       else      rdata_o    <= 32'(wake_o);
          R_DENY:      if (we_i) deny_o     <= wdata_i[NUM_PD-1:0];
                       else      rdata_o    <= 32'(deny_o);
          R_WORK_LEN:  if (we_i) work_len_o <= wdata_i[15:0];
                       else      rdata_o    <= 32'(work_len_o);
          R_START:     if (we_i) start_o    <= wdata_i[NUM_PD-1:0];
          R_LIGHT:     if (we_i) light_o    <= wdata_i[NUM_PD-1:0];
                       else      rdata_o    <= 32'(light_o);
          R_TB_CHECKS: rdata_o <= tb_checks_i;
          R_TB_ERRORS: rdata_o <= tb_errors_i;
          R_OBS_DOM:   if (we_i) obs_dom_q <= wdata_i[7:0];
                       else      rdata_o   <= 32'(obs_dom_q);
          R_IP_CMD:    if (we_i) ip_cmd_o  <= wdata_i[2*NUM_PD-1:0];
                       else      rdata_o   <= 32'(ip_cmd_o);
          R_IP_SEED:   if (we_i) ip_seed_o <= wdata_i[7:0];
                       else      rdata_o   <= 32'(ip_seed_o);
          R_AP_CMD:    if (we_i) ap_cmd_o  <= wdata_i;
                       else      rdata_o   <= ap_cmd_o;
          R_AP_STAT:   rdata_o <= ap_stat_i;
          default:     if (obs_hit && !we_i) rdata_o <= obs_val_i;
                       else                  err_o   <= 1'b1;
        endcase
      end
    end
  end

  // ---- The console: one $display per line the firmware writes ----
  string line = "";
  always @(posedge clk_i) begin
    if (rst_ni && req_i && we_i && off == R_OUT && be_i[0]) begin
      if (wdata_i[7:0] == 8'h0A) begin
        $display("[%0t] %s| %s", $time, TAG, line);
        line = "";
      end else if (wdata_i[7:0] != 8'h0D) begin
        line = $sformatf("%s%c", line, wdata_i[7:0]);
      end
    end
  end

endmodule
