# SCP simulation control

`scp_sim_ctrl.sv` is the SCP firmware's window onto its testbench: a
testbench-only peripheral that looks to the firmware like any other private
device. It has no testbench of its own. Its one user is
[`soc4_tb`](../soc4/README.md), which instantiates it twice: `u_sim` (TAG
`"fw"`) on `soc4_top`'s `sim_*` port for the SCP, and `u_apsim` (TAG `"ap"`) on
`ap_ext_*` for the always-on AP. (It began with the 12-domain `pmu_tb`, retired
on 2026-10-02.) It does not exist in silicon.

## Files

| File | Module | Used by |
|---|---|---|
| `scp_sim_ctrl.sv` | `scp_sim_ctrl #(NUM_PD = 12, TAG = "fw")` | `soc4_tb` (`NUM_PD` 4), through `SOC4_SRCS` in `src/Makefile` |

The firmware's half of the register map is
[`src/pmu/fw/hal/sim.h`](../../pmu/fw/hal/sim.h) (`SCP_SIM_BASE` 0x0002_0000 in
`scp_regs.h`); the two must agree.

## Bus

The device port speaks the protocol of `src/pmu/ibex/shared/bus.sv`: the
answer (`rvalid_o`, `rdata_o`, `err_o`) comes exactly one cycle after
`req_i`, and it cannot stall. Only `addr_i[11:0]` is decoded (soc4's AP maps
a 4 KB page). Any offset not in the map below answers `err_o`, so a firmware
bug that strays into the window faults rather than writing nothing. Writes to
read-only registers are ignored; reads of write-only registers return 0.

## Register map

| Offset | Name | Access | Function |
|---|---|---|---|
| 0x000 | `OUT` | W | A byte to the console (byte lane 0). `\n` ends the line, which is printed as `[<time>] <TAG>\| <line>`; `\r` is dropped. The Makefile greps for `fw\|` and `ap\|` |
| 0x004 | `CYCLE` | R | Free-running cycle count since reset |
| 0x008 | `HALT` | W | End the test; the value is the firmware's verdict (0 = pass, anything else its failure code). `halt_o` is sticky, `halt_code_o` holds the value |
| 0x00C | `CHECK` | W | `{[15:8] domain, [3:0] mode}`: the firmware claims that domain is in that mode; `check_o` pulses for one cycle and the testbench checks the claim against the hardware |
| 0x010 | `WAKE` | RW | Bit n → domain n's wake input (DEVQACTIVE) |
| 0x014 | `DENY` | RW | Bit n → domain n's `deny_enb` |
| 0x018 | `WORK_LEN` | RW | [15:0] burst length for `START`, all domains (the testbench uses as many bits as its device has; soc4 `DEV_CNT_W` = 12) |
| 0x01C | `START` | W | Bit n → a one-cycle start pulse to domain n |
| 0x020 | `LIGHT` | RW | Bit n → domain n's `light_work` (1 = never busy) |
| 0x024 | `TB_CHECKS` | R | Checks the testbench has made so far (`tb_checks_i`) |
| 0x028 | `TB_ERRORS` | R | Failed checks so far; soc4_tb adds every monitor, power-model, AXI and settle violation (`tb_errors_i`) |
| 0x02C | `OBS_DOM` | RW | [7:0] which domain the observation window shows |
| 0x030 | `IP_CMD` | RW | [2n+1:2n] → domain n's device IP command (00 idle, 01 fill RAM, 10 verify RAM) |
| 0x034 | `IP_SEED` | RW | [7:0] the fill/verify pattern seed, all domains |
| 0x038 | `AP_CMD` | RW | A command to the testbench (0 = none). soc4_tb takes `'H'` in [31:24] (hold_busy mask in [3:0]) and `'D'` (ACC deny mask in [1:0]) |
| 0x03C | `AP_STAT` | R | The testbench's report (`ap_stat_i`): soc4_tb echoes the command once it is applied, otherwise shows the BFM's status |
| 0x040-0x0BC | `OBS[0..31]` | R | The testbench's pin-level observations of domain `OBS_DOM`, index `(offset - 0x40) / 4` (`obs_idx_o`), returned from `obs_val_i` combinationally. soc4_tb fills indices 0-26: counts of handshakes and PCSM requests, events, measured latencies and Table 4-5 spacings, live pins, RAM verify result, errors per domain (the list is `enum sim_obs` in `sim.h`) |

The stimulus outputs (`wake_o`, `deny_o`, `light_o`, `start_o`, `work_len_o`,
`ip_cmd_o`, `ip_seed_o`) are ORed in soc4_tb with the AP's copy and the
testbench's own stimulus before they reach the accelerators.

Why the firmware drives device stimulus: in the SoC, wake and busy come from
software and interrupts in each domain, which a stand-in device does not have.
Here the firmware plays their part through `WAKE`, `DENY` and `START`, so a
test is one program with one timeline. Everything that touches these
registers is in a test program (`src/soc4/fw/test/`), never in
`src/pmu/fw/hal/` or `src/pmu/fw/mod/`.

## Changing the map

Add the offset to the `localparam` list and the `unique case`, add the port if
the testbench must see it, mirror it in `sim.h`, and connect it in both
instances in `soc4_tb.sv`. Keep any unused offset an error.

## References

- [`src/pmu/fw/hal/sim.h`](../../pmu/fw/hal/sim.h): the firmware side and the
  `OBS_*` indices.
- [`src/tb/soc4/soc4_tb.sv`](../soc4/soc4_tb.sv): "Observation window", the
  CHECK handling (`ppu_check`, `checkpoint`), `AP_CMD`.
- [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md) Sections 6.4 and 10.1.
