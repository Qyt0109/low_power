`timescale 1ns/1ps
// A PPU, an access control gate, and a domain that really loses power.
//
// Reference: Arm PCSA (DEN 0050 D) Sections 4.2.10 and 7.2.8.
//
// acg_tlul_tb proves the gate obeys 7.2.8 in isolation: it drains, it stalls,
// it errors, it goes transparent again. What it cannot prove is the sentence
// the gate exists FOR, because nothing in it ever loses power:
//
//   "The definition of available in this case is that the memory will respond
//    to requests without requiring intervention from software running on AP
//    cores. Therefore, it is possible for the memory system to be powered-off
//    when agents that require its availability are active, provided those
//    requests trigger a mechanism that allows the transaction to be completed
//    transparently."                                           -- PCSA 4.2.10
//
// C5 is that sentence, executed: the domain is OFF, its registers are X, a read
// arrives, stalls, wakes the domain through DEVQACTIVE with no software
// anywhere on the path, and completes with the retained value.
//
// Run it power-aware (make acgpdpa) for the checks that matter. Without UPF the
// domain never actually corrupts, and C4/C5's retention half is vacuous -- so
// those checks are compiled out rather than left to pass for the wrong reason.

import ppu_pkg::*;
import tlul_pkg::*;

module ppu_acg_pd_tb;

  logic aon_clk = 1'b0, dclk = 1'b0, aon_rst_n = 1'b0;
  always #5 aon_clk = ~aon_clk;
  always #5 dclk    = ~dclk;      // same rate: the gate and the PPU share it

  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask
  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask
  task automatic settle(); repeat (200) @(posedge aon_clk); endtask

  // ===========================================================================
  logic [11:0] waddr, raddr;
  logic [31:0] wdata, rdata;
  logic        wen, ren, irq;
  logic [3:0]  wstrb;
  tl_h2d_t     h2d;
  tl_d2h_t     d2h;
  logic        gated, gerr, qact;

  ppu_acg_pd_top #(.RESP_MODEL(0), .Outstanding(8)) u_dut (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(waddr), .reg_wdata(wdata), .reg_wen(wen), .reg_wstrb(wstrb),
    .reg_raddr(raddr), .reg_ren(ren), .reg_rdata(rdata), .irq(irq),
    .dclk(dclk),
    .tl_h2d_i(h2d), .tl_d2h_o(d2h),
    .acg_gated(gated), .acg_err(gerr), .dev_qactive_o(qact));

  // ===========================================================================
  // THE INVARIANT THAT MAKES THE WHOLE THING SAFE
  //
  // A transaction must never reach the responder while its supply is gone. If
  // it did, the gate would have failed at the one job PCSA 7.2.8 gives it.
  // ===========================================================================
  int unsigned leak_viol = 0;
  always @(posedge dclk) begin
    if (aon_rst_n && !u_dut.logic_on &&
        (u_dut.tl_h2d_dev.a_valid || u_dut.tl_d2h_dev.d_valid)) begin
      leak_viol++;
      $display("[%0t] LEAK-VIOLATION: TL traffic at the responder with no supply", $time);
    end
  end

  // ===========================================================================
  task automatic wr(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk); waddr = a; wdata = d; wstrb = 4'hF; wen = 1'b1;
      @(negedge aon_clk); wen = 1'b0;
    end
  endtask

  task automatic tl_idle(); begin h2d = TL_H2D_DEFAULT; h2d.a_valid = 1'b0; h2d.d_ready = 1'b1; end endtask

  task automatic tl_req(input tl_a_op_e op, input logic [31:0] addr,
                        input logic [31:0] wd, input int tmo,
                        output logic [31:0] rd, output bit got, output bit er);
    int n;
    begin
      got = 0; er = 0; rd = '0;
      @(negedge dclk);
      h2d = TL_H2D_DEFAULT;
      h2d.a_valid = 1'b1; h2d.a_opcode = op; h2d.a_size = 2'd2;
      h2d.a_source = '0;  h2d.a_address = addr; h2d.a_mask = 4'hF;
      h2d.a_data = wd;    h2d.d_ready = 1'b1;
      n = 0;
      while (!(h2d.a_valid && d2h.a_ready) && n < tmo) begin @(negedge dclk); n++; end
      if (n >= tmo) begin h2d.a_valid = 1'b0; return; end
      @(negedge dclk); h2d.a_valid = 1'b0;
      n = 0;
      while (!d2h.d_valid && n < tmo) begin @(negedge dclk); n++; end
      if (d2h.d_valid) begin got = 1; er = d2h.d_error; rd = d2h.d_data; @(negedge dclk); end
    end
  endtask

  logic [31:0] rv;
  bit          got, er;

  localparam logic [31:0] A_MEM = 32'h0000_0004;
  localparam logic [31:0] A_RET = 32'h0000_0010;

  initial begin
    $dumpfile("ppu_acg_pd_tb.vcd");
    $dumpvars(0, ppu_acg_pd_tb);
    $display("==============================================================");
    $display(" ppu_acg_pd_tb -- PCSA 4.2.10 through a 7.2.8 gate");
    $display("==============================================================");

    waddr='0; wdata='0; wen=0; wstrb='0; raddr='0; ren=0;
    tl_idle();
    repeat (10) @(posedge aon_clk);
    aon_rst_n = 1'b1;
    settle();

    // ---- C1: the domain is up and reachable ----
    section("C1 up and reachable");
    ck(u_dut.pcsm_mode == PM_ON, "C1 PPU is ON");
    ck(gated == 1'b0,            "C1 gate transparent");
    tl_req(PutFullData, A_MEM, 32'h1111_2222, 300, rv, got, er);
    ck(got && !er, "C1 write to the protected domain");
    tl_req(PutFullData, A_RET, 32'h3333_4444, 300, rv, got, er);
    ck(got && !er, "C1 write to its retained register");
    tl_req(Get, A_MEM, 32'h0, 300, rv, got, er);
    ck(got && !er && rv == 32'h1111_2222, $sformatf("C1 read back: %08h", rv));

    // ---- C2: power it down. The gate closes first. ----
    // PWR_DYN_EN MATTERS HERE AND DEFAULTS OFF.
    //
    // PPU_PWPR.PWR_POLICY alone is a STATIC policy: the PPU goes to OFF and
    // stays there, and DEVQACTIVE is not permitted to bring it back. The
    // autonomous wake PCSA 4.2.10 describes -- "without requiring intervention
    // from software running on AP cores" -- is the DYNAMIC path, and
    // ppu_pd_top defaults DEF_PWR_DYN_EN to 0.
    //
    // Writing the policy without bit 8 left the domain OFF with a transaction
    // stalled against it forever, which is the correct behaviour for a static
    // policy and useless for an access control gate.
    section("C2 power down through the gate");
    wr(12'h000, {23'd0, 1'b1, 4'd0, PM_OFF});   // PWR_DYN_EN | PWR_POLICY = OFF
    settle();
    ck(gated == 1'b1,            "C2 gate reached Q_STOPPED");
    ck(u_dut.pcsm_mode == PM_OFF, "C2 PPU reached OFF");
    ck(u_dut.logic_on == 1'b0,   "C2 the logic supply is GONE");
    ck(leak_viol == 0,           "C2 nothing reached the responder unpowered");

`ifdef PPU_PA
    // ---- C3: the domain really lost power ----
    // Only meaningful under UPF. Without the power intent the registers keep
    // their values and this would pass for the wrong reason.
    // BOTH corrupt, and that is correct. OFF is not a retaining mode: ppu_pcsm
    // sets ret_keep only for FULL_RET, so in OFF the retention RAIL is removed
    // too and the retention cell has no supply to hold anything with. The UPF
    // models that faithfully and the first version of this check expected the
    // opposite.
    //
    // The retention story belongs in C6, where the mode that retains is used.
    section("C3 corruption");
    ck($isunknown(u_dut.u_resp.mem_q[1]),
       "C3 non-retained memory CORRUPTED with the rail gone");
    ck($isunknown(u_dut.u_resp.u_ret.ret_q),
       "C3 and so did the retention cell -- OFF removes its rail too");
`endif

    // ---- C4: a transaction arrives at a domain with no power ----
    // PCSA 7.2.8 stall-and-wake. The read must not fail and must not reach the
    // responder; it must wait and ask for the domain back.
    //
    // The stall is checked EARLY, within a few cycles. A later sample is racing
    // the wake it is supposed to observe the start of: with PWR_DYN_EN set the
    // PPU begins restoring the domain as soon as DEVQACTIVE rises, so a check
    // 25 cycles in found the supply already back and failed "while the supply
    // is still gone" -- correct behaviour, wrong check.
    section("C4 stall at an unpowered domain");
    fork
      tl_req(Get, A_RET, 32'h0, 600, rv, got, er);
      begin
        repeat (4) @(posedge dclk);
        ck(d2h.a_ready == 1'b0,    "C4 the read is STALLED, not accepted");
        ck(d2h.d_valid == 1'b0,    "C4 and no response was invented");
        ck(u_dut.logic_on == 1'b0, "C4 with the supply still gone");
        repeat (10) @(posedge dclk);
        ck(qact == 1'b1,           "C4 DEVQACTIVE raised: the domain is asked for");
      end
    join

    // ---- C5: PCSA 4.2.10, executed ----
    //
    // THE OBSERVABLE IS THE TRANSACTION, NOT A PERSISTENT POWER STATE, and the
    // first version of this group got that wrong. A DYNAMIC policy of OFF means
    // "be OFF unless there is activity": the PPU restores the domain, the
    // transaction completes, activity ends, and it goes back OFF. Checking for
    // pcsm_mode == ON afterwards fails against a design doing exactly what was
    // asked of it.
    //
    // What 4.2.10 actually promises is that "the memory will respond to
    // requests without requiring intervention from software running on AP
    // cores", and that is what is checked: the read came back, correct, and
    // nothing in this testbench wrote a register to make it happen.
    section("C5 the transaction completed with no software on the path");
    ck(got && !er, "C5 the stalled read COMPLETED");

    // AND IT RETURNS ZERO, NOT THE OLD VALUE. OFF is not a retaining mode:
    // DEN 0051E Table 4-9 asserts DEVPORESETn in OFF, which resets the
    // retention register along with everything else. Only FULL_RET keeps it,
    // by asserting DEVWARMRESETn alone -- that is C6.
    //
    // The first version of this check expected 3333_4444 back and was simply
    // wrong about what OFF means. What 4.2.10 promises is that the transaction
    // COMPLETES rather than failing, not that the data outlives a power-off.
    ck(rv == 32'h0000_0000,
       $sformatf("C5 returning 0: OFF reset the domain, as it must (%08h)", rv));
    ck(leak_viol == 0, "C5 nothing ever reached the responder unpowered");

    // And the domain settles back down again, because the policy still says OFF.
    settle();
    ck(u_dut.pcsm_mode == PM_OFF,
       "C5 domain returned to OFF once the activity ended -- dynamic policy");

    // Back to a static ON for the rest of the run.
    wr(12'h000, {28'd0, PM_ON});
    settle();
    ck(u_dut.pcsm_mode == PM_ON, "C5 static ON restored");

    // ---- C6: FULL_RET, the mode retention exists for ----
    section("C6 FULL_RET");
    tl_req(PutFullData, A_RET, 32'hAAAA_5555, 300, rv, got, er);
    ck(got && !er, "C6 reseeded the retained register");
    wr(12'h000, {28'd0, PM_FULL_RET});
    settle();
    ck(u_dut.pcsm_mode == PM_FULL_RET, "C6 reached FULL_RET");
    ck(u_dut.logic_on == 1'b0 && u_dut.logic_ret == 1'b1,
       "C6 on the retention rail, not the full one");
`ifdef PPU_PA
    // MID-RETENTION, THE REGISTER READS X, AND THAT IS NOT A FAILURE.
    //
    // set_retention does not keep the register readable while its primary
    // supply is gone -- it corrupts like any other and the value lives in a
    // shadow until the restore signal brings it back. So probing ret_q DURING
    // FULL_RET distinguishes nothing from OFF, which is what the first version
    // of this check tried to do.
    //
    // The observable difference is what happens AFTER: the value returns here
    // and does not after OFF (C7). Those two together are the demonstration.
    ck($isunknown(u_dut.u_resp.mem_q[1]),
       "C6 non-retained memory corrupted during FULL_RET");
`endif
    wr(12'h000, {28'd0, PM_ON});
    settle();
    tl_req(Get, A_RET, 32'h0, 400, rv, got, er);
    ck(got && !er && rv == 32'hAAAA_5555,
       $sformatf("C6 retained value survived FULL_RET: %08h", rv));

    // ---- C7: repeated cycles ----
    section("C7 repeated power cycles");
    // Reported per condition rather than as one boolean: a single all_ok hides
    // WHICH of gated / supply / data failed, and the first version of this
    // group did exactly that.
    begin
      int bad_gate = 0, bad_supply = 0, bad_open = 0, bad_data = 0;
      for (int r = 0; r < 3; r++) begin
        wr(12'h000, {23'd0, 1'b1, 4'd0, PM_OFF});  settle();
        if (gated !== 1'b1)          bad_gate++;
        if (u_dut.logic_on !== 1'b0) bad_supply++;
        wr(12'h000, {28'd0, PM_ON});               settle();
        if (gated !== 1'b0)          bad_open++;
        // Zero, not AAAA_5555: each cycle goes through OFF, which resets the
        // retained register. Expecting it to survive was the same mistake C5
        // made -- retention is FULL_RET's property, not power cycling's.
        tl_req(Get, A_RET, 32'h0, 600, rv, got, er);
        if (!got || er || rv !== 32'h0000_0000) bad_data++;
      end
      ck(bad_gate   == 0, $sformatf("C7 gate closed on every power-down (%0d bad)", bad_gate));
      ck(bad_supply == 0, $sformatf("C7 supply removed every time (%0d bad)", bad_supply));
      ck(bad_open   == 0, $sformatf("C7 gate transparent on every power-up (%0d bad)", bad_open));
      ck(bad_data   == 0, $sformatf("C7 read completed and correctly reset every time (%0d bad)", bad_data));
    end

    section("C8 summary");
    ck(leak_viol == 0, $sformatf("C8 leak invariant: %0d violation(s)", leak_viol));

    $display("");
    $display("==============================================================");
    $display(" ppu_acg_pd_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (2000000) @(posedge aon_clk);
    $display(" RESULT: FAIL -- timeout");
    $finish;
  end

endmodule
