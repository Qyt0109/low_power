# Access control gate testbenches

Three testbenches for the access control gates of `src/rtl/acg/` (PCSA DEN
0050D Section 7.2.8): the TL-UL gate `acg_tlul` alone, the same gate in front
of a PPU-controlled domain, and the TL-UH gate `acg_tluh` with the SCP's wake
line. The RTL is described in [`src/rtl/acg/README.md`](../../rtl/acg/README.md).

## Files

| File | Top / role | Target | What it checks |
|---|---|---|---|
| `acg_tlul_tb.sv` | `acg_tlul_tb` | `acg` | PCSA 7.2.8 sentence by sentence on three `acg_tlul` instances: `u_stall` (RESP_MODEL 0, stall-and-wake), `u_err` (RESP_MODEL 1, error), `u_d21` (the SCP's run-time mode, decision D21), each with a `qchannel_monitor` |
| `ppu_acg_pd_tb.sv` | `ppu_acg_pd_tb` | `acgpd`, `acgpdpa` | `ppu_acg_pd_top`: a PPU, the gate and a responder in a domain that loses power. The point is PCSA 4.2.10: an access to an OFF domain stalls, wakes it through DEVQACTIVE with no software on the path, and completes |
| `acg_tluh_tb.sv` | `acg_tluh_tb` | `acgtluh` | `acg_tluh` (the unmodified `acg_ctrl` + `tluh_gate`) with a TL-UH host BFM, `tluh_mem_model` as the device, the testbench as the domain's PPU on the Q-Channel, and `scp_irq` on the wake line |
| `tluh_mem_model.sv` | `tluh_mem_model` | (used by `acg_tluh_tb`) | A TL-UH memory: every TL-UH A message as a burst of 2^(size-3) beats when it carries data, answered in order after `rsp_dly` cycles, `a_ready` stalled one cycle in `stall_every`. `on = 0` models the domain OFF behind its isolation: `a_ready` LOW, no D beats, and every `a_valid` counted in `n_off_viol` |

## What is checked

### `acg_tlul_tb` (78 checks in the latest regression)

| Group | Claim |
|---|---|
| A1, A6 | Transparent outside the gated state, and again after it |
| A2, B1, B2, B7 | Outstanding transactions complete before the gate reaches the gated state, including several in flight and a request withdrawn mid-drain |
| A4, A5, B3, B4 | Stall and wake: an access at a gated stall-and-wake gate is held (writes too), raises the wake, and the wake drops if the request is withdrawn |
| A7, A8 | Error model: every access answered with an error, with no power request |
| B5, B6, B8, B9 | Nothing leaks through, fields preserved, repeated gate/un-gate, reset while gated |
| D1-D7 | Decision D21 (`Proposed_PMU/RPMI_STACK_DECISIONS.md`): DEFAULT, VOTED OFF (domain up and powering down: answer with an error at once, record the first errored access), POWERING UP (hold, no wake), and leaving VOTED OFF with the domain OFF (D6 held until ON, D7 errored if the SCP goes back to VOTED OFF); every cycle, nothing reaches the OFF domain |
| A9 | All three `qchannel_monitor`s and the drain invariant report 0 violations |

The stimulus is written in the testbench; OpenTitan's `tl_agent` is UVM and is
not used.

### `ppu_acg_pd_tb` (27 checks in the latest regression)

Groups C1-C8: up and reachable; power-down through the gate; corruption (C3);
a stall at the unpowered domain (C4); the transaction completing with no
software on the path (C5); FULL_RET; repeated power cycles; a summary with the
leak invariant. The leak invariant runs every cycle: TL-UL traffic at the
responder while `logic_on` is 0 is a violation.

C3 and the retention half of C6 read the responder's memory, which is inside
the switched domain, to see it corrupt or survive. They only mean something
under UPF, so they are compiled only with `+define+PPU_PA` (`make acgpdpa`,
Xcelium). The VCS target `acgpd` runs without them.

### `acg_tluh_tb` (26 checks in the latest regression)

Every check is tagged, and the negative controls require each mutant to fail
at its own tag:

| Tag | Claim |
|---|---|
| `PASS` | Bursts and a Hint pass through with the gate open; traffic resumes in DEFAULT; no A beat reaches the device while it is OFF |
| `ATOMIC` | Atomics (multi-beat included) pass through, and are answered beat for beat when denied |
| `BURST_DRAIN` | A quiescence request in the middle of a Put burst, with a Get burst's responses owed, and across a multi-beat atomic: every beat reaches the device and every response the host before QACCEPTn; nothing new is let through once requested; the device never holds a part-received message when the gate reports gated |
| `WAKE_LINE` | An access at the closed gate (domain OFF) is held, raises `wake_o`, which sets `scp_irq`'s PENDING and its line (PD5); it completes after the power-up, and the line drops |
| `BEAT_ERR` | VOTED OFF: every beat of a denied burst is answered, nothing reaches the device; the next message after a mode change is denied |
| `RECORD` | The error record (address, source, write, overflow) and its clear |

Mutants (`make acgtluh` rebuilds once per define):

| Define | Where | The fault | Must fail at |
|---|---|---|---|
| `ACG_TLUH_MUT_SPLIT` | `rtl/acg/tluh_gate.sv` | the route is decided again at every beat, so a flush or an error request splits a burst | `BURST_DRAIN` |
| `ACG_TLUH_MUT_ONEBEAT` | `rtl/acg/tluh_gate.sv` | one error beat per message, whatever its size | `BEAT_ERR` |
| `ACG_TLUH_MUT_NOWAKE` | `rtl/acg/acg_tluh.sv` | no wake line | `WAKE_LINE` |
| `ACG_TLUH_MUT_ATOM` | `rtl/tluh/tluh_pkg.sv` | the two atomics counted as messages without A data, so a multi-beat atomic is split | `ATOMIC` |

Latest regression: SPLIT 5 `[chk:BURST_DRAIN]` errors, ONEBEAT 1
`[chk:BEAT_ERR]`, NOWAKE 2 `[chk:WAKE_LINE]`, ATOM 3 `[chk:ATOMIC]`.

## Running

```
make -C src acg     SIM=vcs
make -C src acgpd   SIM=vcs
make -C src acgtluh SIM=vcs
```

- `acgtluh` has a real verdict: it fails unless `RESULT: PASS`, and unless
  each mutant ends `RESULT: FAIL` with its own tag.
- `acg` and `acgpd` return 0 whatever the result: read the `RESULT:` line at
  the end of the log.
- `acg` and `acgpd` print `[ASSERT FAILED] AssertConnected_A` at time 0 from
  the vendored `prim_sparse_fsm_flop.sv` (three in `acg`, one in `acgpd`):
  OpenTitan's check that the FSM's alert trigger is connected, which this
  wrapper does not do. It is not one of the testbench's checks and does not
  change `RESULT`.
- `acgpdpa` runs under Xcelium; see [`../README.md`](../README.md) §2.

## Adding a test

- `acg_tlul_tb`, `ppu_acg_pd_tb`: add a `section("<group> <title>")` and `ck()`
  calls before the summary; keep the group letters (A: PCSA sentences, B:
  corner cases, C: the powered domain, D: decision D21).
- `acg_tluh_tb`: use `tck("<TAG>", cond, msg)`. For a new mutant, add an
  `` `ifdef ACG_TLUH_MUT_<X> `` in the RTL with a `NEGATIVE CONTROL` comment and
  a `$(call unit_neg,acg_tluh_tb,$(ACGTLUH_SRCS),ACG_TLUH_MUT_<X>,<TAG>)` line
  in the `acgtluh` target.

## References

- Arm PCSA DEN 0050D Sections 4.2.10 and 7.2.8.
- [`src/rtl/acg/README.md`](../../rtl/acg/README.md); `vendor/sovra_tl/tl_pkg.sv`
  (TileLink encodings); `src/vendor/opentitan/tlul/tlul_lc_gate.sv` (the
  TL-UL data path, unmodified).
- Formal: [`src/formal/tluh_gate/`](../../formal/tluh_gate/README.md) proves
  `tluh_gate` against the same mutants (except NOWAKE, which is in
  `acg_tluh`).
