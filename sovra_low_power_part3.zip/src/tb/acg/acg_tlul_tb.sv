`timescale 1ns/1ps
// acg_tlul -- PCSA (DEN 0050 D) Section 7.2.8, checked sentence by sentence.
//
// The gate's DATA PATH is vendor/opentitan/tlul/tlul_lc_gate.sv, unmodified and
// already verified upstream. What is under test here is the PCSA behaviour that
// the wrapper is responsible for:
//
//   "Any outstanding transactions are completed before entering the gated
//    state."                                                       -> A2, A3
//   "Once in the gated state, transaction attempts are either stalled or
//    receive a response ... according to the implemented response model."
//                                                                  -> A4, A7
//   "Stall and wake: A transaction arriving at a gated access control
//    component is initially stalled. A wake-up signal is asserted indicating
//    that the downstream power domain must be made available. Once available
//    the access control is un-gated and the transaction progresses as normal."
//                                                                  -> A5, A6
//   "After exiting the gated state, the access control component is
//    transparent."                                                 -> A1, A6
//   "Error: The access control component generates an error response to any
//    arriving transaction. There is no request to change any power domain
//    mode."                                                        -> A7, A8
//
// Group D is decision D21 (Proposed_PMU/RPMI_STACK_DECISIONS.md): the SCP's
// run-time mode on a stall-and-wake gate. VOTED OFF answers at once with an
// error, whether or not the domain is down yet, records the first errored
// access for the SCP and raises its event; POWERING UP holds the access
// until the domain is ON, with no wake; DEFAULT is RESP_MODEL's behaviour,
// which groups A and B check with the mode tied to DEFAULT.
//
// D6 and D7 leave VOTED OFF with the domain OFF, when the device's A channel
// is an isolation clamp that may read ready and never answers. The access
// comes 0 to 4 cycles after the mode change. It must be held, never reach the
// OFF domain, and complete once the domain is ON (D6), or be answered with an
// error if the SCP goes back to VOTED OFF before the gate has closed again
// (D7). Every cycle, nothing may reach the OFF domain, and u_d21 is held to
// the same drain invariant as the other two gates, in every mode.
//
// THE STIMULUS IS WRITTEN HERE RATHER THAN PULLED. OpenTitan's tl_agent is UVM
// in 10 of its 11 files and every testbench in this repository is plain
// SystemVerilog; adopting it would mean adopting UVM for one test. The protocol
// is what tlul_pkg provides -- these tasks only drive it.

module acg_tlul_tb
  import tlul_pkg::*;
;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  task automatic settle(); repeat (40) @(posedge clk); endtask

  // ===========================================================================
  // Two DUTs: stall-and-wake, and error
  // ===========================================================================
  logic    s_qreqn = 1'b1, e_qreqn = 1'b1;
  logic    s_qacceptn, s_qdeny, s_qactive, s_gated, s_err;
  logic    e_qacceptn, e_qdeny, e_qactive, e_gated, e_err;
  tl_h2d_t s_h2d, s_h2d_dev, e_h2d, e_h2d_dev;
  tl_d2h_t s_d2h, s_d2h_dev, e_d2h, e_d2h_dev;

  acg_tlul #(.RESP_MODEL(0), .Outstanding(8)) u_stall (
    .clk(clk), .rst_n(rst_n),
    .qreqn(s_qreqn), .qacceptn(s_qacceptn), .qdeny(s_qdeny), .qactive(s_qactive),
    .tl_h2d_i(s_h2d), .tl_d2h_o(s_d2h),
    .tl_h2d_o(s_h2d_dev), .tl_d2h_i(s_d2h_dev),
    .mode_i(2'd0), .err_valid_o(), .err_addr_o(), .err_source_o(),
    .err_write_o(), .err_overflow_o(), .err_clr_i(1'b0),
    .gated_o(s_gated), .gate_err_o(s_err));

  acg_tlul #(.RESP_MODEL(1), .Outstanding(8)) u_err (
    .clk(clk), .rst_n(rst_n),
    .qreqn(e_qreqn), .qacceptn(e_qacceptn), .qdeny(e_qdeny), .qactive(e_qactive),
    .tl_h2d_i(e_h2d), .tl_d2h_o(e_d2h),
    .tl_h2d_o(e_h2d_dev), .tl_d2h_i(e_d2h_dev),
    .mode_i(2'd0), .err_valid_o(), .err_addr_o(), .err_source_o(),
    .err_write_o(), .err_overflow_o(), .err_clr_i(1'b0),
    .gated_o(e_gated), .gate_err_o(e_err));

  // Group D's gate: stall-and-wake, the model a DSP or NPU port would be built
  // with, under the SCP's D21 mode.
  logic    d_qreqn = 1'b1;
  logic    d_qacceptn, d_qdeny, d_qactive, d_gated, d_err;
  tl_h2d_t d_h2d, d_h2d_dev;
  tl_d2h_t d_d2h, d_d2h_dev;
  logic [1:0] d_mode = 2'd0;
  logic       d_clr  = 1'b0;
  logic       d_ev, d_wr, d_ovf;
  logic [top_pkg::TL_AW-1:0]  d_eaddr;
  logic [top_pkg::TL_AIW-1:0] d_esrc;

  acg_tlul #(.RESP_MODEL(0), .Outstanding(8)) u_d21 (
    .clk(clk), .rst_n(rst_n),
    .qreqn(d_qreqn), .qacceptn(d_qacceptn), .qdeny(d_qdeny), .qactive(d_qactive),
    .tl_h2d_i(d_h2d), .tl_d2h_o(d_d2h),
    .tl_h2d_o(d_h2d_dev), .tl_d2h_i(d_d2h_dev),
    .mode_i(d_mode), .err_valid_o(d_ev), .err_addr_o(d_eaddr), .err_source_o(d_esrc),
    .err_write_o(d_wr), .err_overflow_o(d_ovf), .err_clr_i(d_clr),
    .gated_o(d_gated), .gate_err_o(d_err));

  // u_d21's device, which the testbench can switch OFF (d_off). OFF, it sees
  // nothing and answers nothing, and its A channel reads a_ready =
  // d_clamp_rdy, the value an isolation clamp holds it at: with the clamp at
  // 1, an access driven into the OFF domain is taken and never answered.
  logic    d_off = 1'b0, d_clamp_rdy = 1'b1;
  tl_h2d_t d_h2d_ip;
  tl_d2h_t d_d2h_ip;
  always_comb begin
    d_h2d_ip  = d_h2d_dev;
    d_d2h_dev = d_d2h_ip;
    if (d_off) begin
      d_h2d_ip          = TL_H2D_DEFAULT;
      d_d2h_dev         = TL_D2H_DEFAULT;
      d_d2h_dev.a_ready = d_clamp_rdy;
    end
  end

  acg_resp_tlul u_d_resp (.clk(clk), .rst_n(rst_n), .ret_rst_n(rst_n),
                          .rsp_delay(8'd0),
                          .tl_h2d_i(d_h2d_ip), .tl_d2h_o(d_d2h_ip));

  logic [7:0] s_rdly = 8'd0, e_rdly = 8'd0;

  acg_resp_tlul u_s_resp (.clk(clk), .rst_n(rst_n), .ret_rst_n(rst_n),
                          .rsp_delay(s_rdly),
                          .tl_h2d_i(s_h2d_dev), .tl_d2h_o(s_d2h_dev));
  acg_resp_tlul u_e_resp (.clk(clk), .rst_n(rst_n), .ret_rst_n(rst_n),
                          .rsp_delay(e_rdly),
                          .tl_h2d_i(e_h2d_dev), .tl_d2h_o(e_d2h_dev));

  // Protocol monitors on both control channels.
  int unsigned s_viol, e_viol;
  qchannel_monitor u_s_mon (
    .clk(clk), .rst_n(rst_n), .crst_n(rst_n), .drst_n(rst_n), .clk_gated(1'b0),
    .qreqn(s_qreqn), .qacceptn(s_qacceptn), .qdeny(s_qdeny), .violations(s_viol));
  qchannel_monitor u_e_mon (
    .clk(clk), .rst_n(rst_n), .crst_n(rst_n), .drst_n(rst_n), .clk_gated(1'b0),
    .qreqn(e_qreqn), .qacceptn(e_qacceptn), .qdeny(e_qdeny), .violations(e_viol));
  int unsigned d_viol;
  qchannel_monitor u_d_mon (
    .clk(clk), .rst_n(rst_n), .crst_n(rst_n), .drst_n(rst_n), .clk_gated(1'b0),
    .qreqn(d_qreqn), .qacceptn(d_qacceptn), .qdeny(d_qdeny), .violations(d_viol));

  // Group D's invariant, every cycle: in VOTED OFF nothing new reaches the
  // device -- the gate may still be draining what it had already accepted,
  // so a request presented downstream while nothing is outstanding is the
  // violation -- and in either D21 mode the gate never asks for power. And in
  // any mode, nothing reaches the domain while it is OFF.
  int unsigned d21_viol = 0, d_off_hits = 0, d_off_taken = 0;
  always @(posedge clk) begin
    if (rst_n) begin
      if (d_mode == 2'd1 && d_h2d_dev.a_valid && !u_d21.resp_pending) begin
        d21_viol++;
        $display("[%0t] D21-VIOLATION: a request reached the device in VOTED OFF", $time);
      end
      if ((d_mode == 2'd1 || d_mode == 2'd2) && d_qactive) begin
        d21_viol++;
        $display("[%0t] D21-VIOLATION: QACTIVE raised in a D21 mode", $time);
      end
      if (d_off && d_h2d_dev.a_valid) begin
        d21_viol++;
        d_off_hits++;
        if (d_d2h_dev.a_ready) d_off_taken++;
        $display("[%0t] D21-VIOLATION: a request reached the OFF domain's A channel (mode %0d)%0s",
                 $time, d_mode, d_d2h_dev.a_ready ? ", and the clamp took it" : "");
      end
    end
  end

  // ===========================================================================
  // THE CAPABILITY-1 INVARIANT
  //
  // "Any outstanding transactions are completed before entering the gated
  // state." Watched every cycle: the gate must never report Q_STOPPED while a
  // transaction is still in flight to the device. A sampled check cannot see a
  // one-cycle overlap.
  // ===========================================================================
  int unsigned drain_viol = 0;
  always @(posedge clk) begin
    if (rst_n) begin
      if (s_gated && (s_h2d_dev.a_valid || s_d2h_dev.d_valid)) begin
        drain_viol++;
        $display("[%0t] DRAIN-VIOLATION stall: gated with traffic still on the device side", $time);
      end
      if (e_gated && (e_h2d_dev.a_valid || e_d2h_dev.d_valid)) begin
        drain_viol++;
        $display("[%0t] DRAIN-VIOLATION err: gated with traffic still on the device side", $time);
      end
      if (d_gated && (d_h2d_dev.a_valid || d_d2h_dev.d_valid)) begin
        drain_viol++;
        $display("[%0t] DRAIN-VIOLATION d21: gated with traffic still on the device side (mode %0d)",
                 $time, d_mode);
      end
    end
  end

  // ===========================================================================
  // TL-UL stimulus
  // ===========================================================================
  task automatic tl_idle(output tl_h2d_t h);
    begin h = TL_H2D_DEFAULT; h.a_valid = 1'b0; h.d_ready = 1'b1; end
  endtask

  // Issue a request and wait for its response. `timeout_cyc` bounds the wait so
  // a stalled transaction can be OBSERVED stalling rather than hanging the run.
  task automatic tl_req(ref tl_h2d_t h, const ref tl_d2h_t d,
                        input tl_a_op_e op, input logic [31:0] addr,
                        input logic [31:0] wdata, input int timeout_cyc,
                        output logic [31:0] rdata, output bit got, output bit err);
    int n;
    begin
      got = 1'b0; err = 1'b0; rdata = '0;
      @(negedge clk);
      h           = TL_H2D_DEFAULT;
      h.a_valid   = 1'b1;
      h.a_opcode  = op;
      h.a_size    = 2'd2;
      h.a_source  = '0;
      h.a_address = addr;
      h.a_mask    = 4'hF;
      h.a_data    = wdata;
      h.d_ready   = 1'b1;
      // wait for the address handshake
      n = 0;
      while (!(h.a_valid && d.a_ready) && n < timeout_cyc) begin
        @(negedge clk); n++;
      end
      if (n >= timeout_cyc) begin h.a_valid = 1'b0; return; end
      @(negedge clk);
      h.a_valid = 1'b0;
      // wait for the response
      n = 0;
      while (!d.d_valid && n < timeout_cyc) begin @(negedge clk); n++; end
      if (d.d_valid) begin
        got   = 1'b1;
        err   = d.d_error;
        rdata = d.d_data;
        @(negedge clk);
      end
    end
  endtask

  // Issue without waiting for the response, so a transaction can be left
  // GENUINELY OUTSTANDING while something else happens. tl_req cannot do this:
  // it waits, which is exactly what the drain test must not do.
  task automatic tl_issue(ref tl_h2d_t h, const ref tl_d2h_t d,
                          input tl_a_op_e op, input logic [31:0] addr,
                          input logic [31:0] wdata, input int timeout_cyc,
                          output bit accepted);
    int n;
    begin
      accepted = 1'b0;
      @(negedge clk);
      h           = TL_H2D_DEFAULT;
      h.a_valid   = 1'b1;
      h.a_opcode  = op;
      h.a_size    = 2'd2;
      h.a_source  = '0;
      h.a_address = addr;
      h.a_mask    = 4'hF;
      h.a_data    = wdata;
      h.d_ready   = 1'b1;
      n = 0;
      while (!(h.a_valid && d.a_ready) && n < timeout_cyc) begin
        @(negedge clk); n++;
      end
      if (n < timeout_cyc) accepted = 1'b1;
      @(negedge clk);
      h.a_valid = 1'b0;
    end
  endtask

  // Wait for a response that a previous tl_issue left outstanding.
  task automatic tl_collect(ref tl_h2d_t h, const ref tl_d2h_t d, input int timeout_cyc,
                            output logic [31:0] rdata, output bit got, output bit err);
    int n;
    begin
      got = 1'b0; err = 1'b0; rdata = '0;
      n = 0;
      while (!d.d_valid && n < timeout_cyc) begin @(negedge clk); n++; end
      if (d.d_valid) begin
        got = 1'b1; err = d.d_error; rdata = d.d_data;
        @(negedge clk);
      end
    end
  endtask

  // Drive a request with an explicit source id, to prove the gate returns it.
  task automatic tl_req_src(ref tl_h2d_t h, const ref tl_d2h_t d,
                            input tl_a_op_e op, input logic [31:0] addr,
                            input logic [31:0] wdata,
                            input logic [top_pkg::TL_AIW-1:0] src,
                            input int timeout_cyc,
                            output logic [31:0] rdata,
                            output logic [top_pkg::TL_AIW-1:0] rsrc,
                            output bit got);
    int n;
    begin
      got = 1'b0; rdata = '0; rsrc = '0;
      @(negedge clk);
      h           = TL_H2D_DEFAULT;
      h.a_valid   = 1'b1;
      h.a_opcode  = op;
      h.a_size    = 2'd2;
      h.a_source  = src;
      h.a_address = addr;
      h.a_mask    = 4'hF;
      h.a_data    = wdata;
      h.d_ready   = 1'b1;
      n = 0;
      while (!(h.a_valid && d.a_ready) && n < timeout_cyc) begin @(negedge clk); n++; end
      if (n >= timeout_cyc) begin h.a_valid = 1'b0; return; end
      @(negedge clk);
      h.a_valid = 1'b0;
      n = 0;
      while (!d.d_valid && n < timeout_cyc) begin @(negedge clk); n++; end
      if (d.d_valid) begin
        got = 1'b1; rdata = d.d_data; rsrc = d.d_source;
        @(negedge clk);
      end
    end
  endtask

  logic [31:0] rd;
  bit          got, err, acc;
  logic [top_pkg::TL_AIW-1:0] rsrc;

  localparam logic [31:0] A_MEM = 32'h0000_0004;   // non-retained word 1
  localparam logic [31:0] A_RET = 32'h0000_0010;   // the retained word

  // ---- D6 and D7: leaving VOTED OFF with the domain OFF ----
  // One access at a time, from these tasks alone. t_* is its outcome.
  bit          t_took, t_got, t_err, t_woke;
  logic [31:0] t_rdata;

  // The gate closed in VOTED OFF, the domain OFF with the clamp at rdy, the
  // record cleared. Returns just after a negedge.
  task automatic d21_off(input bit rdy);
    tl_idle(d_h2d);
    d_mode = 2'd0; d_off = 1'b0; d_qreqn = 1'b1; settle();
    d_mode = 2'd1; repeat (4) @(posedge clk);
    d_qreqn = 1'b0; settle();
    d_clamp_rdy = rdy; d_off = 1'b1;
    d_clr = 1'b1; @(posedge clk); #1 d_clr = 1'b0;
    @(negedge clk);
    t_took = 1'b0; t_got = 1'b0; t_err = 1'b0; t_woke = 1'b0; t_rdata = '0;
  endtask

  // Present a read of A_MEM, source 6, now, and keep it presented.
  task automatic d21_present();
    d_h2d           = TL_H2D_DEFAULT;
    d_h2d.a_valid   = 1'b1;
    d_h2d.a_opcode  = Get;
    d_h2d.a_size    = 2'd2;
    d_h2d.a_source  = 8'd6;
    d_h2d.a_address = A_MEM;
    d_h2d.a_mask    = 4'hF;
    d_h2d.d_ready   = 1'b1;
  endtask

  // Run the presented access for up to n cycles, or until its response.
  // Sampled 1 ns after each negedge, when the next posedge's handshake is
  // already decided; a_valid drops at the negedge after the handshake, as
  // TL-UL has it.
  task automatic d21_run(input int n);
    for (int c = 0; c < n && !t_got; c++) begin
      #1;
      if (d_qactive) t_woke = 1'b1;
      if (t_took && d_d2h.d_valid) begin
        t_got = 1'b1; t_err = d_d2h.d_error; t_rdata = d_d2h.d_data;
      end
      if (!t_took && d_h2d.a_valid && d_d2h.a_ready) t_took = 1'b1;
      @(negedge clk);
      if (t_took) d_h2d.a_valid = 1'b0;
    end
  endtask

  initial begin
    $dumpfile("acg_tlul_tb.vcd");
    $dumpvars(0, acg_tlul_tb);
    $display("==============================================================");
    $display(" acg_tlul_tb -- PCSA 7.2.8 access control");
    $display("==============================================================");

    tl_idle(s_h2d); tl_idle(e_h2d); tl_idle(d_h2d);
    repeat (5) @(posedge clk);
    rst_n = 1'b1;
    settle();

    // ---- A1: transparent when not gated ----
    section("A1 transparent");
    ck(s_gated == 1'b0, "A1 not gated out of reset");
    tl_req(s_h2d, s_d2h, PutFullData, A_MEM, 32'hCAFE_0001, 200, rd, got, err);
    ck(got && !err, "A1 write accepted");
    tl_req(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && !err && rd == 32'hCAFE_0001,
       $sformatf("A1 read back what was written: %08h", rd));

    // ---- A2 / A3: drain, then gate ----
    section("A2 drain before gating");
    s_qreqn = 1'b0;                       // the PPU asks for quiescence
    settle();
    ck(s_gated == 1'b1,       "A2 gate reached Q_STOPPED");
    ck(s_qacceptn == 1'b0,    "A2 and accepted on the Q-Channel");
    ck(drain_viol == 0,       "A3 never gated with traffic still in flight");

    // ---- A4 / A5: stalled, and asking for the domain back ----
    section("A4 stall and wake");
    ck(s_qactive == 1'b0, "A4 nothing pending yet, QACTIVE LOW");
    fork
      begin
        tl_req(s_h2d, s_d2h, Get, A_MEM, 32'h0, 60, rd, got, err);
      end
      begin
        repeat (20) @(posedge clk);
        ck(s_d2h.a_ready == 1'b0, "A4 request STALLED -- a_ready withheld");
        ck(s_d2h.d_valid == 1'b0, "A4 and no response invented");
        ck(s_qactive == 1'b1,     "A5 QACTIVE raised: the domain is being asked for");
      end
    join
    ck(!got, "A4 the transaction did not complete while gated");

    // ---- A6: un-gate, and the transaction goes through ----
    section("A6 un-gate and complete");
    s_qreqn = 1'b1;
    settle();
    ck(s_gated == 1'b0,    "A6 gate left Q_STOPPED");
    ck(s_qactive == 1'b0,  "A6 QACTIVE dropped once nothing is stalled");
    tl_req(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && !err && rd == 32'hCAFE_0001,
       $sformatf("A6 transparent again, data intact: %08h", rd));

    // ---- A7 / A8: the error model ----
    section("A7 error model");
    tl_req(e_h2d, e_d2h, PutFullData, A_MEM, 32'hBEEF_0002, 200, rd, got, err);
    ck(got && !err, "A7 ungated write accepted");
    e_qreqn = 1'b0;
    settle();
    ck(e_gated == 1'b1, "A7 error-model gate reached Q_STOPPED");
    tl_req(e_h2d, e_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && err, "A7 gated read answered with a BUS ERROR, not a stall");
    ck(e_qactive == 1'b0,
       "A8 and NO wake: 7.2.8 says the error model makes no power request");
    e_qreqn = 1'b1;
    settle();
    tl_req(e_h2d, e_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && !err && rd == 32'hBEEF_0002, "A8 transparent again after un-gating");

    // =======================================================================
    // GROUP B -- the gate on its own, beyond the happy path
    // =======================================================================

    // ---- B1: drain with a transaction GENUINELY OUTSTANDING ----
    //
    // A2 gates from idle, so the drain invariant has nothing to catch there.
    // This is the real form of 7.2.8's "any outstanding transactions are
    // completed before entering the gated state": hold a response inside the
    // responder, ask for quiescence, and require the gate NOT to reach
    // Q_STOPPED until that response has come back.
    section("B1 drain with traffic in flight");
    s_rdly = 8'd30;                        // responder holds for 30 cycles
    tl_issue(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, acc);
    ck(acc, "B1 read accepted and now outstanding");
    repeat (4) @(posedge clk);
    s_qreqn = 1'b0;                        // ask to quiesce MID-TRANSACTION
    // SAMPLED ACROSS THE WHOLE WINDOW, not once at the end. A single sample
    // ten cycles in passed against a mutated gate that dropped the drain
    // requirement entirely -- it simply had not gated YET at that instant, and
    // only the continuous invariant caught it. A directed check that can be
    // beaten by timing is not a directed check.
    begin
      bit held = 1'b1;
      for (int w = 0; w < 25; w++) begin
        @(posedge clk);
        if (s_gated !== 1'b0 || s_qacceptn !== 1'b1) held = 1'b0;
      end
      ck(held, "B1 gate never gated while a response was still owed");
    end
    tl_collect(s_h2d, s_d2h, 200, rd, got, err);
    ck(got && !err && rd == 32'hCAFE_0001,
       $sformatf("B1 the in-flight read completed normally: %08h", rd));
    settle();
    ck(s_gated == 1'b1, "B1 and only THEN did the gate quiesce");
    ck(drain_viol == 0, "B1 drain invariant still clean");
    s_rdly = 8'd0;
    s_qreqn = 1'b1;
    settle();

    // ---- B2: several outstanding at once ----
    // Outstanding is 8 on these DUTs; tlul_lc_gate sizes its counter from it and
    // carries its own overflow assertion. Three in flight is enough to show the
    // counter is counting rather than tracking a single bit.
    section("B2 several outstanding");
    s_rdly = 8'd25;
    tl_issue(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, acc);
    ck(acc, "B2 first accepted");
    s_qreqn = 1'b0;
    repeat (6) @(posedge clk);
    ck(s_gated == 1'b0, "B2 not gated with one outstanding");
    tl_collect(s_h2d, s_d2h, 300, rd, got, err);
    ck(got, "B2 outstanding response returned");
    settle();
    ck(s_gated == 1'b1, "B2 gated once drained");
    s_rdly = 8'd0; s_qreqn = 1'b1; settle();

    // ---- B3: a WRITE stalls too ----
    // A4 only stalled a read. 7.2.8 says "transaction attempts", not "reads".
    section("B3 writes stall as well");
    s_qreqn = 1'b0;
    settle();
    ck(s_gated == 1'b1, "B3 gated");
    fork
      tl_req(s_h2d, s_d2h, PutFullData, A_MEM, 32'hDEAD_BEEF, 60, rd, got, err);
      begin
        repeat (20) @(posedge clk);
        ck(s_d2h.a_ready == 1'b0, "B3 write STALLED, not accepted");
        ck(s_qactive == 1'b1,     "B3 and it raised the wake");
      end
    join
    ck(!got, "B3 the write did not complete while gated");

    // ---- B4: the wake DROPS when the host gives up ----
    // Nothing in PCSA says so, but a QACTIVE that latches HIGH would keep the
    // domain awake forever after one abandoned transaction -- the same trap
    // ppu_clk_ctrl's DENY_RETRY_DLY exists for.
    section("B4 wake drops when the request withdraws");
    ck(s_qactive == 1'b1, "B4 wake still asserted from B3");
    tl_idle(s_h2d);
    repeat (10) @(posedge clk);
    ck(s_qactive == 1'b0, "B4 wake DROPPED once nothing was waiting");
    ck(s_gated == 1'b1,   "B4 and the gate stayed gated");

    // ---- B5: the value written while gated never reached the device ----
    // The stall must not have leaked a partial write through.
    section("B5 nothing leaked through the gate");
    s_qreqn = 1'b1;
    settle();
    tl_req(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && !err && rd == 32'hCAFE_0001,
       $sformatf("B5 memory still holds the pre-gate value: %08h", rd));

    // ---- B6: source and size survive the round trip ----
    // The gate blanks both directions with prim_blanker when erroring; a
    // transparent gate must not perturb the fields it passes.
    section("B6 fields preserved");
    tl_req_src(s_h2d, s_d2h, PutFullData, A_MEM, 32'h1234_5678, 8'd5, 200, rd, rsrc, got);
    ck(got && rsrc == 8'd5, $sformatf("B6 write returned source 5, got %0d", rsrc));
    tl_req_src(s_h2d, s_d2h, Get, A_MEM, 32'h0, 8'd9, 200, rd, rsrc, got);
    ck(got && rsrc == 8'd9 && rd == 32'h1234_5678,
       $sformatf("B6 read returned source 9 and data: src=%0d data=%08h", rsrc, rd));

    // ---- B7: quiescence request WITHDRAWN mid-drain ----
    // The controller changing its mind before Q_STOPPED. IHI 0068C allows it
    // (Q_REQUEST -> Q_CONTINUE is not a thing, but QREQn rising from Q_REQUEST
    // is what the monitor checks), and the gate must end up transparent rather
    // than stuck part-way.
    section("B7 request withdrawn mid-drain");
    s_rdly = 8'd30;
    tl_issue(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, acc);
    repeat (3) @(posedge clk);
    s_qreqn = 1'b0;
    repeat (6) @(posedge clk);
    s_qreqn = 1'b1;                      // changed its mind
    tl_collect(s_h2d, s_d2h, 300, rd, got, err);
    ck(got, "B7 the in-flight transaction still completed");
    s_rdly = 8'd0;
    settle();
    ck(s_gated == 1'b0, "B7 gate ended up transparent, not stuck");
    tl_req(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && !err && rd == 32'h1234_5678, "B7 and still passes traffic");

    // ---- B8: repeated cycles ----
    // A sparse-encoded FSM that can only be entered once would pass everything
    // above.
    section("B8 repeated gate/un-gate");
    begin
      bit all_ok = 1'b1;
      for (int r = 0; r < 6; r++) begin
        s_qreqn = 1'b0; settle();
        if (s_gated !== 1'b1) all_ok = 1'b0;
        s_qreqn = 1'b1; settle();
        if (s_gated !== 1'b0) all_ok = 1'b0;
        tl_req(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
        if (!got || err || rd !== 32'h1234_5678) all_ok = 1'b0;
      end
      ck(all_ok, "B8 six gate/un-gate cycles, each transparent afterwards");
    end

    // ---- B9: reset while gated ----
    section("B9 reset while gated");
    s_qreqn = 1'b0;
    settle();
    ck(s_gated == 1'b1, "B9 gated before reset");
    rst_n = 1'b0;
    repeat (6) @(posedge clk);
    rst_n = 1'b1;
    s_qreqn = 1'b1;
    settle();
    ck(s_gated == 1'b0, "B9 transparent again after reset");
    tl_req(s_h2d, s_d2h, PutFullData, A_MEM, 32'hFEED_0003, 200, rd, got, err);
    ck(got && !err, "B9 write works after reset");
    tl_req(s_h2d, s_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && !err && rd == 32'hFEED_0003, "B9 and reads back");

    // =======================================================================
    // GROUP D -- D21: the SCP's run-time mode
    // =======================================================================
    rst_n = 1'b0; repeat (4) @(posedge clk); rst_n = 1'b1; settle();

    // ---- D1: DEFAULT is the stall model, unchanged ----
    section("D1 DEFAULT mode");
    tl_req(d_h2d, d_d2h, PutFullData, A_MEM, 32'h0D21_0001, 200, rd, got, err);
    ck(got && !err, "D1 transparent write");
    d_qreqn = 1'b0; settle();
    ck(d_gated == 1'b1, "D1 gated");
    fork
      tl_req(d_h2d, d_d2h, Get, A_MEM, 32'h0, 40, rd, got, err);
      begin
        repeat (20) @(posedge clk);
        ck(d_d2h.a_ready == 1'b0 && d_qactive == 1'b1, "D1 stalled and waking, as RESP_MODEL 0 does");
      end
    join
    ck(!got && !d_ev, "D1 nothing completed and nothing recorded");
    tl_idle(d_h2d);
    d_qreqn = 1'b1; settle();

    // ---- D2: VOTED OFF while the domain is still up ----
    // The AP voted OFF and the hysteresis window has not run out: the domain
    // is ON, the gate open. An access is a software bug all the same.
    section("D2 VOTED OFF, domain still up");
    ck(d_gated == 1'b0, "D2 the gate is open");
    d_mode = 2'd1; repeat (4) @(posedge clk);
    begin
      int n0;
      n0 = $time / 10;
      tl_req_src(d_h2d, d_d2h, PutFullData, A_MEM + 32'h8, 32'hBAD0_0002, 8'd7, 200, rd, rsrc, got);
      ck(got, "D2 the write was answered");
      ck(($time / 10) - n0 < 10, $sformatf("D2 at once: %0d cycles", ($time / 10) - n0));
    end
    ck(d_ev == 1'b1,              "D2 event raised");
    ck(d_eaddr == A_MEM + 32'h8,  $sformatf("D2 address recorded: %08h", d_eaddr));
    ck(d_esrc == 8'd7,            $sformatf("D2 source recorded: %0d", d_esrc));
    ck(d_wr == 1'b1 && !d_ovf,    "D2 recorded as a write, no overflow");
    tl_req(d_h2d, d_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && err, "D2 a read gets a BUS ERROR too");
    ck(d_ovf == 1'b1 && d_eaddr == A_MEM + 32'h8 && d_esrc == 8'd7,
       "D2 a second error sets overflow and keeps the first record");

    // ---- D3: the domain goes down underneath the error ----
    section("D3 VOTED OFF, domain powering down");
    d_qreqn = 1'b0; settle();
    ck(d_gated == 1'b1 && d_qacceptn == 1'b0, "D3 the PPU's quiescence request is accepted");
    d_clr = 1'b1; @(posedge clk); #1 d_clr = 1'b0;
    ck(d_ev == 1'b0 && d_ovf == 1'b0, "D3 the SCP's clear drops the event");
    tl_req_src(d_h2d, d_d2h, Get, A_MEM + 32'hC, 32'h0, 8'd3, 200, rd, rsrc, got);
    ck(got && d_ev && d_eaddr == A_MEM + 32'hC && d_esrc == 8'd3 && !d_wr,
       $sformatf("D3 gated read errored and recorded: ev %0b addr %08h src %0d wr %0b",
                 d_ev, d_eaddr, d_esrc, d_wr));
    d_clr = 1'b1; @(posedge clk); #1 d_clr = 1'b0;

    // ---- D4: POWERING UP holds the access until the domain is ON ----
    section("D4 POWERING UP");
    d_mode = 2'd2;
    // The mode first, then the access, four cycles apart. D6 presents it 0 to
    // 4 cycles after the change, with the domain OFF.
    repeat (4) @(posedge clk);
    fork
      tl_req(d_h2d, d_d2h, Get, A_MEM, 32'h0, 300, rd, got, err);
      begin
        repeat (40) @(posedge clk);
        ck(d_d2h.a_ready == 1'b0 && d_d2h.d_valid == 1'b0, "D4 held: not accepted, not answered");
        ck(d_qactive == 1'b0, "D4 and no wake: the SCP is powering the domain up");
        d_qreqn = 1'b1;               // the domain is ON; the PPU opens the gate
      end
    join
    ck(got && !err && rd == 32'h0D21_0001,
       $sformatf("D4 completed once ON, with the data: %08h", rd));
    ck(!d_ev, "D4 nothing recorded");

    // ---- D4b: RESP_MODEL = 1 in DEFAULT errors as before, and is recorded ----
    // The data path is PCSA 7.2.8's error model, which A7/A8 check on u_err;
    // the record is new, so it is checked here on the same kind of error.
    d_mode = 2'd1; d_qreqn = 1'b0; settle();
    d_clr = 1'b1; @(posedge clk); #1 d_clr = 1'b0;
    tl_req_src(d_h2d, d_d2h, PutFullData, A_MEM, 32'h0, 8'd9, 200, rd, rsrc, got);
    ck(got && d_ev && d_esrc == 8'd9 && d_eaddr == A_MEM,
       "D4b a gated write in VOTED OFF: recorded with its source and address");
    d_clr = 1'b1; @(posedge clk); #1 d_clr = 1'b0;
    d_mode = 2'd2; repeat (4) @(posedge clk);
    d_qreqn = 1'b1; settle();

    // ---- D5: back to DEFAULT ----
    section("D5 DEFAULT again");
    d_mode = 2'd0; settle();
    tl_req(d_h2d, d_d2h, Get, A_MEM, 32'h0, 200, rd, got, err);
    ck(got && !err && rd == 32'h0D21_0001, "D5 transparent again");
    ck(d21_viol == 0, $sformatf("D5 group D invariant: %0d violation(s)", d21_viol));

    // ---- D6: leaving VOTED OFF with the domain OFF, swept ----
    // The gate walks from StError back to StFlush through one cycle in which
    // it neither blocks nor errors (acg_ctrl's header). Without a hold, an
    // access in that cycle went to the OFF domain, and with the clamp at 1 it
    // was taken and never answered. Here the access comes 0 to 4 cycles after
    // the change (0: in the same cycle), with the clamp at 1 and at 0, into
    // POWERING UP and into DEFAULT. Every one must be held -- not accepted,
    // not answered, never on the OFF domain's A channel -- for 30 cycles, and
    // then complete with the data once the domain is ON and the PPU opens the
    // gate, with nothing recorded. POWERING UP raises no wake; DEFAULT, the
    // stall model, does.
    section("D6 leaving VOTED OFF, domain OFF");
    begin
      bit held_all = 1'b1, done_all = 1'b1, wake_all = 1'b1, rec_none = 1'b1;
      int unsigned hits0 = d_off_hits, taken0 = d_off_taken, trials = 0;
      for (int m = 0; m < 2; m++)
        for (int r = 1; r >= 0; r--)
          for (int k = 0; k <= 4; k++) begin
            bit         held, woke_held;
            logic [1:0] to;
            string      tn;
            to = (m == 0) ? 2'd2 : 2'd0;
            tn = $sformatf("%0s, access %0d cycle(s) after, clamp %0d",
                           (m == 0) ? "POWERING UP" : "DEFAULT", k, r);
            d21_off(r[0]);
            d_mode = to;                     // the SCP's change, at a negedge
            repeat (k) @(negedge clk);
            d21_present();                   // k = 0: in the same cycle
            d21_run(30);                     // the domain is still OFF
            held = !t_took && !t_got;
            woke_held = t_woke;
            d_off = 1'b0;                    // ON again; the PPU opens the gate
            d_qreqn = 1'b1;
            d21_run(200);
            trials++;
            if (!held) begin
              held_all = 1'b0;
              $display("[%0t] FAIL D6 %0s: not held (accepted %0b, answered %0b, error %0b)",
                       $time, tn, t_took, t_got, t_err);
            end
            if (!(t_took && t_got && !t_err && t_rdata == 32'h0D21_0001)) begin
              done_all = 1'b0;
              $display("[%0t] FAIL D6 %0s: once ON, accepted %0b, answered %0b, error %0b, data %08h",
                       $time, tn, t_took, t_got, t_err, t_rdata);
            end
            if (woke_held != (to == 2'd0) || (to == 2'd2 && t_woke)) begin
              wake_all = 1'b0;
              $display("[%0t] FAIL D6 %0s: QACTIVE while held %0b, at all %0b",
                       $time, tn, woke_held, t_woke);
            end
            if (d_ev) begin
              rec_none = 1'b0;
              $display("[%0t] FAIL D6 %0s: an error was recorded", $time, tn);
            end
            tl_idle(d_h2d);
          end
      ck(held_all, $sformatf("D6 held while the domain was OFF, in all %0d trials", trials));
      ck(d_off_hits == hits0 && d_off_taken == taken0,
         $sformatf("D6 nothing reached the OFF domain's A channel: %0d request(s), %0d taken",
                   d_off_hits - hits0, d_off_taken - taken0));
      ck(done_all, "D6 each completed with the data once the domain was ON");
      ck(wake_all, "D6 no wake in POWERING UP; the stall model's wake in DEFAULT");
      ck(rec_none, "D6 nothing recorded as an error");
    end

    // ---- D7: back to VOTED OFF before the gate has closed again ----
    // The walk out of VOTED OFF takes a few cycles. If the SCP goes back to
    // VOTED OFF within it, the gate must first finish the walk to StFlush
    // (acg_ctrl keeps its error path off until then) and only then error:
    // an early return would put the gate back through StActive, open, or
    // leave the access held for good. The access comes with the first change
    // and must be answered with an error, recorded, with nothing on the OFF
    // domain's A channel and no wake.
    section("D7 VOTED OFF again during the walk");
    begin
      bit ok_all = 1'b1;
      int unsigned hits0 = d_off_hits;
      for (int j = 1; j <= 4; j++) begin
        d21_off(1'b1);
        d_mode = 2'd2;                       // POWERING UP ...
        d21_present();
        d21_run(j);
        d_mode = 2'd1;                       // ... and VOTED OFF again j cycles later
        d21_run(100);
        if (!(t_took && t_got && t_err && d_ev && d_eaddr == A_MEM && d_esrc == 8'd6 &&
              !d_wr && !t_woke)) begin
          ok_all = 1'b0;
          $display("[%0t] FAIL D7 back after %0d cycle(s): accepted %0b, answered %0b, error %0b, recorded %0b (addr %08h src %0d wr %0b), wake %0b",
                   $time, j, t_took, t_got, t_err, d_ev, d_eaddr, d_esrc, d_wr, t_woke);
        end
        tl_idle(d_h2d);
      end
      ck(ok_all && d_off_hits == hits0,
         $sformatf("D7 back to VOTED OFF 1 to 4 cycles into the walk: errored and recorded, %0d request(s) on the OFF domain",
                   d_off_hits - hits0));
    end
    d_mode = 2'd0; d_off = 1'b0; d_qreqn = 1'b1; settle();
    ck(d21_viol == 0, $sformatf("D7 group D invariant, D6 and D7 included: %0d violation(s)", d21_viol));

    // ---- A9: protocol ----
    section("A9 protocol");
    ck(s_viol + e_viol + d_viol == 0,
       $sformatf("A9 qchannel_monitor: %0d violation(s)", s_viol + e_viol + d_viol));
    ck(drain_viol == 0,
       $sformatf("A9 drain invariant: %0d violation(s)", drain_viol));

    $display("");
    $display("==============================================================");
    $display(" acg_tlul_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (200000) @(posedge clk);
    $display(" RESULT: FAIL -- timeout");
    $finish;
  end

endmodule
