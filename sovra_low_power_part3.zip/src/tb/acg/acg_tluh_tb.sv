`timescale 1ns/1ps
// acg_tluh_tb -- the TL-UH access control gate (rtl/acg/acg_tluh.sv,
// tluh_gate.sv; platform plan H15) with a TL-UH host BFM, a TL-UH memory
// (tluh_mem_model.sv), the testbench as the domain's PPU on the Q-Channel,
// and the SCP's interrupt block (pmu/rtl/scp_irq.sv) on the wake line.
//
//   host BFM ──► acg_tluh ──► tluh_mem_model (on = the domain powered)
//                  ▲  │ wake_o
//   TB "PPU" ──────┘  └──► scp_irq input 0 (edge) ──► irq_o
//
// Groups, each check tagged for the negative controls (make acgtluh runs
// the mutants and requires each to fail at its own tag):
//   P  pass-through: bursts, atomics (multi-beat included) and a Hint, with
//      the gate open                                          [chk:PASS], [chk:ATOMIC]
//   B  burst-aware drain: a quiescence request in the middle of a Put burst,
//      with a Get burst's responses still owed, and with a multi-beat atomic:
//      every beat reaches the device and every response the host before
//      QACCEPTn; nothing new is let through once requested       [chk:BURST_DRAIN]
//   W  stall-and-wake: an access at the closed gate (domain OFF) is held, raises
//      wake_o, which sets scp_irq's PENDING and its line (PD5); it completes
//      after the power-up                                     [chk:WAKE_LINE]
//   E  the error path (D21 VOTED OFF): every beat of a denied burst answered,
//      atomics included, nothing reaching the device; a burst under way when
//      the mode changes completes; the record                 [chk:BEAT_ERR],
//                                                             [chk:ATOMIC], [chk:RECORD]
// Checked throughout: nothing reaches the domain while it is OFF, and the
// device never holds a part-received message when the gate reports gated.

module acg_tluh_tb;
  import tl_pkg::*;

  localparam int unsigned DW = 64, SZW = 4, SRCW = 8, AW = 32;
  localparam time TCLK = 10ns;

  logic clk = 1'b0, rst_n = 1'b0;
  always #(TCLK/2) clk = ~clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  int unsigned checks = 0, errors = 0;
  task automatic tck(input string tag, input bit cond, input string msg);
    checks++;
    if (!cond) begin
      errors++;
      $display("[%0t] tb| ERROR: [chk:%s] %s", $time, tag, msg);
    end
  endtask

  // ---------------------------------------------------------------------------
  // DUT and surroundings
  // ---------------------------------------------------------------------------
  logic             qreqn = 1'b1, qacceptn, qdeny, qactive;
  logic [1:0]       mode = 2'd0;
  logic             err_clr = 1'b0;
  logic             err_valid, err_write, err_overflow, wake, gated, gate_err;
  logic [AW-1:0]    err_addr;
  logic [SRCW-1:0]  err_source;

  // host
  logic             a_valid = 1'b0, a_ready;
  logic [2:0]       a_opcode = '0, a_param = '0;
  logic [SZW-1:0]   a_size = '0;
  logic [SRCW-1:0]  a_source = '0;
  logic [AW-1:0]    a_address = '0;
  logic [DW/8-1:0]  a_mask = '0;
  logic [DW-1:0]    a_data = '0;
  logic             d_valid, d_ready = 1'b1, d_denied, d_corrupt;
  logic [2:0]       d_opcode;
  logic [1:0]       d_param;
  logic [SZW-1:0]   d_size;
  logic [SRCW-1:0]  d_source;
  logic [0:0]       d_sink;
  logic [DW-1:0]    d_data;
  // device
  logic             m_a_valid, m_a_ready, m_a_corrupt, m_d_valid, m_d_ready, m_d_denied, m_d_corrupt;
  logic [2:0]       m_a_opcode, m_a_param, m_d_opcode;
  logic [1:0]       m_d_param;
  logic [SZW-1:0]   m_a_size, m_d_size;
  logic [SRCW-1:0]  m_a_source, m_d_source;
  logic [AW-1:0]    m_a_address;
  logic [DW/8-1:0]  m_a_mask;
  logic [DW-1:0]    m_a_data, m_d_data;

  bit          dev_on = 1'b1;
  int unsigned rsp_dly = 0, stall_every = 0;

  acg_tluh #(.RESP_MODEL(0), .AW(AW), .DW(DW), .SRCW(SRCW), .SINKW(1), .SZW(SZW),
             .OUTSTANDING(4)) u_dut (
    .clk(clk), .rst_n(rst_n),
    .qreqn(qreqn), .qacceptn(qacceptn), .qdeny(qdeny), .qactive(qactive),
    .a_valid_i(a_valid), .a_ready_o(a_ready), .a_opcode_i(a_opcode), .a_param_i(a_param),
    .a_size_i(a_size), .a_source_i(a_source), .a_address_i(a_address), .a_mask_i(a_mask),
    .a_data_i(a_data), .a_corrupt_i(1'b0),
    .d_valid_o(d_valid), .d_ready_i(d_ready), .d_opcode_o(d_opcode), .d_param_o(d_param),
    .d_size_o(d_size), .d_source_o(d_source), .d_sink_o(d_sink), .d_denied_o(d_denied),
    .d_data_o(d_data), .d_corrupt_o(d_corrupt),
    .dev_a_valid_o(m_a_valid), .dev_a_ready_i(m_a_ready), .dev_a_opcode_o(m_a_opcode),
    .dev_a_param_o(m_a_param), .dev_a_size_o(m_a_size), .dev_a_source_o(m_a_source),
    .dev_a_address_o(m_a_address), .dev_a_mask_o(m_a_mask), .dev_a_data_o(m_a_data),
    .dev_a_corrupt_o(m_a_corrupt),
    .dev_d_valid_i(m_d_valid), .dev_d_ready_o(m_d_ready), .dev_d_opcode_i(m_d_opcode),
    .dev_d_param_i(m_d_param), .dev_d_size_i(m_d_size), .dev_d_source_i(m_d_source),
    .dev_d_sink_i(1'b0), .dev_d_denied_i(m_d_denied), .dev_d_data_i(m_d_data),
    .dev_d_corrupt_i(m_d_corrupt),
    .mode_i(mode), .err_valid_o(err_valid), .err_addr_o(err_addr), .err_source_o(err_source),
    .err_write_o(err_write), .err_overflow_o(err_overflow), .err_clr_i(err_clr),
    .wake_o(wake), .gated_o(gated), .gate_err_o(gate_err)
  );

  tluh_mem_model #(.DW(DW), .SZW(SZW), .SRCW(SRCW), .AW(AW)) u_mem (
    .clk(clk), .rst_n(rst_n), .on(dev_on), .rsp_dly(rsp_dly), .stall_every(stall_every),
    .a_valid(m_a_valid), .a_ready(m_a_ready), .a_opcode(m_a_opcode), .a_param(m_a_param),
    .a_size(m_a_size), .a_source(m_a_source), .a_address(m_a_address), .a_mask(m_a_mask),
    .a_data(m_a_data),
    .d_valid(m_d_valid), .d_ready(m_d_ready), .d_opcode(m_d_opcode), .d_param(m_d_param),
    .d_size(m_d_size), .d_source(m_d_source), .d_denied(m_d_denied), .d_data(m_d_data),
    .d_corrupt(m_d_corrupt)
  );

  // The SCP's interrupt block, one input: the gate's wake line (PD5, H9).
  logic        i_req = 1'b0, i_we = 1'b0, i_rv, i_err, irq_line;
  logic [31:0] i_addr = '0, i_wd = '0, i_rd;
  scp_irq #(.NUM_IN(1), .ASYNC(32'h0)) u_irq (
    .clk_i(clk), .rst_ni(rst_n),
    .req_i(i_req), .we_i(i_we), .be_i(4'hF), .addr_i(i_addr), .wdata_i(i_wd),
    .rvalid_o(i_rv), .rdata_o(i_rd), .err_o(i_err),
    .in_i(wake), .irq_o(irq_line)
  );

  task automatic irq_acc(input bit wr, input logic [11:0] off, input logic [31:0] wd,
                         output logic [31:0] rd);
    @(negedge clk);
    i_req = 1'b1; i_we = wr; i_addr = {20'h0, off}; i_wd = wd;
    @(negedge clk);
    i_req = 1'b0; i_we = 1'b0;
    rd = i_rd;
  endtask

  // ---------------------------------------------------------------------------
  // Host BFM: A messages beat by beat; every D beat collected
  // ---------------------------------------------------------------------------
  typedef struct {
    logic [2:0] op; logic [SZW-1:0] size; logic [SRCW-1:0] src;
    bit denied, corrupt; logic [DW-1:0] data;
  } dbeat_t;
  dbeat_t dq [$];
  int unsigned host_a_beats = 0;

  always @(posedge clk)
    if (rst_n && d_valid && d_ready) begin
      dbeat_t b;
      b.op = d_opcode; b.size = d_size; b.src = d_source; b.denied = d_denied;
      b.corrupt = d_corrupt; b.data = d_data;
      dq.push_back(b);
    end
  always @(posedge clk) if (rst_n && a_valid && a_ready) host_a_beats++;

  function automatic int unsigned beats_of(input logic [2:0] op, input int unsigned size, input bit resp);
    bit data = resp ? (op == TL_A_GET || op == TL_A_ARITH || op == TL_A_LOGICAL)
                    : (op == TL_A_PUT_FULL || op == TL_A_PUT_PARTIAL || op == TL_A_ARITH || op == TL_A_LOGICAL);
    return (!data || size <= 3) ? 1 : (1 << (size - 3));
  endfunction

  // Send one message; data[k] is beat k. Returns once its last beat is taken
  // (or after tmo cycles with nothing taken, ok = 0).
  task automatic send(input logic [2:0] op, input logic [2:0] prm, input int unsigned size,
                      input logic [SRCW-1:0] src, input logic [AW-1:0] addr,
                      input logic [63:0] data [], input int unsigned tmo, output bit ok);
    int unsigned n = beats_of(op, size, 1'b0), t;
    ok = 1'b1;
    for (int k = 0; k < n; k++) begin
      @(negedge clk);
      a_valid = 1'b1; a_opcode = op; a_param = prm; a_size = SZW'(size); a_source = src;
      a_address = addr; a_mask = 8'hFF; a_data = (k < data.size()) ? data[k] : 64'h0;
      t = 0;
      @(posedge clk);
      while (!a_ready && t < tmo) begin @(posedge clk); t++; end
      if (!a_ready) begin ok = 1'b0; break; end
    end
    @(negedge clk);
    a_valid = 1'b0;
  endtask

  task automatic wait_d(input int unsigned n, input int unsigned tmo, output bit ok);
    int unsigned t = 0;
    while (dq.size() < n && t < tmo) begin @(posedge clk); t++; end
    ok = (dq.size() >= n);
  endtask

  task automatic cycles(input int unsigned n);
    repeat (n) @(posedge clk);
  endtask

  // ---------------------------------------------------------------------------
  // The testbench as the PPU on the Q-Channel
  // ---------------------------------------------------------------------------
  task automatic quiesce(output bit accepted, input int unsigned tmo);
    int unsigned t = 0;
    @(negedge clk) qreqn = 1'b0;
    while (qacceptn !== 1'b0 && qdeny !== 1'b1 && t < tmo) begin @(posedge clk); t++; end
    accepted = (qacceptn === 1'b0);
  endtask

  task automatic unquiesce();
    int unsigned t = 0;
    @(negedge clk) qreqn = 1'b1;
    while (qacceptn !== 1'b1 && t < 200) begin @(posedge clk); t++; end
  endtask

  // ---------------------------------------------------------------------------
  // Always-on checks
  // ---------------------------------------------------------------------------
  int unsigned partial_at_gate = 0, gated_cycles = 0;
  always @(posedge clk)
    if (rst_n && gated) begin
      gated_cycles++;
      if (u_mem.partial) partial_at_gate++;
    end

  // ---------------------------------------------------------------------------
  // The tests
  // ---------------------------------------------------------------------------
  logic [63:0] v [];
  logic [31:0] r;
  bit ok, acc;
  int unsigned m0, b0, n0;

  initial begin
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    cycles(4);
    irq_acc(1'b1, 12'h008, 32'h1, r);          // EDGE[0] = 1: the wake line is an edge input
    irq_acc(1'b1, 12'h004, 32'h1, r);          // ENABLE[0]

    // ---- P: pass-through ----
    v = new[4]; v = '{64'hA0, 64'hA1, 64'hA2, 64'hA3};
    send(TL_A_PUT_FULL, 3'd0, 5, 8'h11, 32'h100, v, 50, ok);
    wait_d(1, 100, ok);
    tck("PASS", ok && dq[0].op == TL_D_ACCESS_ACK && !dq[0].denied && dq[0].size == 5 && dq[0].src == 8'h11,
        "PutFullData burst (4 beats): expected one AccessAck, not denied, size 5, source 0x11");
    dq.delete();
    v = new[0];
    send(TL_A_GET, 3'd0, 5, 8'h12, 32'h100, v, 50, ok);
    wait_d(4, 100, ok);
    tck("PASS", ok && dq.size() == 4 && dq[0].op == TL_D_ACCESS_ACKDATA && !dq[3].denied &&
               dq[0].data == 64'hA0 && dq[1].data == 64'hA1 && dq[2].data == 64'hA2 && dq[3].data == 64'hA3,
        "Get burst (size 5): expected 4 AccessAckData beats A0..A3");
    dq.delete();
    v = new[1]; v[0] = 64'd5;
    send(TL_A_ARITH, TL_ATOM_ADD, 3, 8'h13, 32'h100, v, 50, ok);
    wait_d(1, 100, ok);
    tck("ATOMIC", ok && dq.size() == 1 && dq[0].op == TL_D_ACCESS_ACKDATA && dq[0].data == 64'hA0 &&
                 u_mem.mem[32] == 64'hA5,
        $sformatf("ArithmeticData ADD: expected the old value 0xA0 and memory 0xA5, got 0x%0h and 0x%0h",
                  dq.size() ? dq[0].data : 64'hX, u_mem.mem[32]));
    dq.delete();
    v = new[2]; v = '{64'h55, 64'h66};
    send(TL_A_LOGICAL, TL_ATOM_SWAP, 4, 8'h14, 32'h110, v, 50, ok);
    wait_d(2, 100, ok);
    tck("ATOMIC", ok && dq.size() == 2 && dq[0].data == 64'hA2 && dq[1].data == 64'hA3 &&
                 u_mem.mem[34] == 64'h55 && u_mem.mem[35] == 64'h66 && u_mem.n_msgs == 4,
        "LogicalData SWAP burst (2 beats): expected 2 AccessAckData beats A2, A3 and memory 0x55, 0x66 as ONE message");
    dq.delete();
    v = new[0];
    send(TL_A_HINT, 3'd0, 3, 8'h15, 32'h100, v, 50, ok);
    wait_d(1, 100, ok);
    tck("PASS", ok && dq.size() == 1 && dq[0].op == TL_D_HINT_ACK && !dq[0].denied,
        "Hint: expected one HintAck");
    dq.delete();
    $display("[%0t] tb| P: bursts, atomics and a Hint passed through; %0d device messages", $time, u_mem.n_msgs);

    // ---- B1: a request in the middle of a Put burst ----
    stall_every = 2; rsp_dly = 20;
    m0 = u_mem.n_msgs; b0 = u_mem.n_beats;
    v = new[8]; foreach (v[k]) v[k] = 64'hB0 + k;
    fork
      send(TL_A_PUT_FULL, 3'd0, 6, 8'h21, 32'h200, v, 100, ok);
      begin
        wait (u_mem.n_beats == b0 + 1);
        quiesce(acc, 2000);
      end
    join
    tck("BURST_DRAIN", acc && u_mem.n_beats == b0 + 8 && u_mem.n_msgs == m0 + 1 && !u_mem.partial,
        $sformatf("quiescence asked after beat 1 of an 8-beat Put: accepted %b with %0d of 8 beats at the device",
                  acc, u_mem.n_beats - b0));
    tck("BURST_DRAIN", dq.size() == 1 && dq[0].op == TL_D_ACCESS_ACK && !dq[0].denied,
        "the Put's AccessAck must reach the host before QACCEPTn");
    dq.delete();
    // A new message at the closed gate: held; the domain goes OFF behind it.
    dev_on = 1'b0;
    n0 = u_mem.n_msgs;
    v = new[0];
    fork
      send(TL_A_GET, 3'd0, 6, 8'h22, 32'h200, v, 100000, ok);
      begin : wake_side
        int unsigned t = 0;
        while (wake !== 1'b1 && t < 200) begin @(posedge clk); t++; end
        tck("WAKE_LINE", wake === 1'b1, "an access stalled at the closed gate did not raise wake_o");
        cycles(3);
        irq_acc(1'b0, 12'h000, 32'h0, r);
        tck("WAKE_LINE", r[0] === 1'b1 && irq_line === 1'b1,
            $sformatf("wake_o into scp_irq: PENDING %b line %b, expected both HIGH", r[0], irq_line));
        tck("BURST_DRAIN", u_mem.n_msgs == n0 && a_ready === 1'b0,
            "a new message went past the closed gate");
        // The SCP powers the domain up: rail, then the PPU's exit.
        cycles(20);
        dev_on = 1'b1;
        cycles(5);
        unquiesce();
        irq_acc(1'b1, 12'h000, 32'h1, r);      // W1C PENDING
      end
    join
    wait_d(8, 200, ok);
    tck("WAKE_LINE", ok && dq.size() == 8 && dq[0].data == 64'hB0 && dq[7].data == 64'hB7 && !dq[0].denied,
        "the stalled Get must complete after the power-up with the burst written before the gate closed");
    tck("WAKE_LINE", wake === 1'b0 && irq_line === 1'b0, "wake_o or the SCP line still HIGH after the power-up");
    dq.delete();
    $display("[%0t] tb| B1/W: Put burst drained across the request; the stalled Get raised the SCP wake line and completed after power-up",
             $time);

    // ---- B2: a Get burst's responses owed when quiescence is asked ----
    stall_every = 0; rsp_dly = 30;
    v = new[0];
    send(TL_A_GET, 3'd0, 6, 8'h23, 32'h200, v, 50, ok);
    quiesce(acc, 2000);
    tck("BURST_DRAIN", acc && dq.size() == 8,
        $sformatf("QACCEPTn with %0d of the Get burst's 8 D beats delivered", dq.size()));
    dq.delete();
    unquiesce();

    // ---- B3: a multi-beat atomic across the request ----
    stall_every = 2; rsp_dly = 10;
    b0 = u_mem.n_beats;
    v = new[2]; v = '{64'h0F, 64'hF0};
    fork
      send(TL_A_LOGICAL, TL_ATOM_XOR, 4, 8'h24, 32'h200, v, 100, ok);
      begin
        wait (u_mem.n_beats == b0 + 1);
        quiesce(acc, 2000);
      end
    join
    tck("ATOMIC", acc && u_mem.n_beats == b0 + 2 && dq.size() == 2 && dq[0].data == 64'hB0 &&
                 dq[1].data == 64'hB1 && u_mem.mem[64] == (64'hB0 ^ 64'h0F),
        "a 2-beat LogicalData XOR across the request: both beats at the device, both AccessAckData beats back, before QACCEPTn");
    dq.delete();
    unquiesce();
    stall_every = 0; rsp_dly = 0;
    $display("[%0t] tb| B2/B3: responses and atomics drained before the accept", $time);

    // ---- E: VOTED OFF, every beat answered ----
    mode = 2'd1;
    cycles(4);
    m0 = u_mem.n_msgs;
    v = new[0];
    send(TL_A_GET, 3'd0, 6, 8'h31, 32'h300, v, 50, ok);
    wait_d(8, 100, ok);
    begin
      automatic bit all = (dq.size() == 8);
      foreach (dq[k]) all &= dq[k].op == TL_D_ACCESS_ACKDATA && dq[k].denied && dq[k].corrupt &&
                             dq[k].size == 6 && dq[k].src == 8'h31;
      tck("BEAT_ERR", ok && all, $sformatf("denied Get burst: %0d D beats; expected 8, each AccessAckData denied and corrupt",
                                            dq.size()));
    end
    dq.delete();
    v = new[4]; v = '{64'h1, 64'h2, 64'h3, 64'h4};
    b0 = host_a_beats;
    send(TL_A_PUT_FULL, 3'd0, 5, 8'h32, 32'h300, v, 50, ok);
    wait_d(1, 100, ok);
    cycles(5);
    tck("BEAT_ERR", ok && host_a_beats == b0 + 4 && dq.size() == 1 && dq[0].op == TL_D_ACCESS_ACK &&
                   dq[0].denied && !dq[0].corrupt,
        "denied Put burst: all 4 A beats taken, one AccessAck denied (not corrupt)");
    dq.delete();
    v = new[1]; v[0] = 64'h9;
    send(TL_A_ARITH, TL_ATOM_MAXU, 3, 8'h33, 32'h300, v, 50, ok);
    wait_d(1, 100, ok);
    tck("ATOMIC", ok && dq.size() == 1 && dq[0].op == TL_D_ACCESS_ACKDATA && dq[0].denied && dq[0].corrupt,
        "denied ArithmeticData: one AccessAckData, denied and corrupt");
    dq.delete();
    v = new[2]; v = '{64'h1, 64'h2};
    send(TL_A_LOGICAL, TL_ATOM_OR, 4, 8'h34, 32'h300, v, 50, ok);
    wait_d(2, 100, ok);
    cycles(5);
    tck("ATOMIC", ok && dq.size() == 2 && dq[0].denied && dq[1].denied && dq[0].corrupt && dq[1].corrupt &&
                 dq[1].op == TL_D_ACCESS_ACKDATA,
        $sformatf("denied 2-beat LogicalData: %0d D beats, expected 2 AccessAckData, denied and corrupt", dq.size()));
    dq.delete();
    tck("BEAT_ERR", u_mem.n_msgs == m0, "a message reached the device in VOTED OFF");
    tck("RECORD", err_valid && err_addr == 32'h300 && err_source == 8'h31 && !err_write && err_overflow,
        $sformatf("record: valid %b addr 0x%0h source 0x%0h write %b overflow %b; expected the Get at 0x300 from 0x31, overflow",
                  err_valid, err_addr, err_source, err_write, err_overflow));
    @(negedge clk) err_clr = 1'b1;
    @(negedge clk) err_clr = 1'b0;
    tck("RECORD", !err_valid && !err_overflow, "record not cleared by err_clr");
    $display("[%0t] tb| E: VOTED OFF answered every beat (Get 8, Put 1 after 4 A beats, atomics); record kept and cleared",
             $time);

    // ---- E2: a burst under way when the mode goes to VOTED OFF completes ----
    mode = 2'd0;
    cycles(4);
    stall_every = 3; rsp_dly = 5;
    m0 = u_mem.n_msgs; b0 = u_mem.n_beats;
    v = new[4]; v = '{64'hC0, 64'hC1, 64'hC2, 64'hC3};
    fork
      send(TL_A_PUT_FULL, 3'd0, 5, 8'h41, 32'h400, v, 100, ok);
      begin
        wait (u_mem.n_beats == b0 + 1);
        @(negedge clk) mode = 2'd1;
      end
    join
    wait_d(1, 200, ok);
    tck("BURST_DRAIN", ok && u_mem.n_beats == b0 + 4 && u_mem.n_msgs == m0 + 1 && dq.size() == 1 &&
                      !dq[0].denied && u_mem.mem[128] == 64'hC0 && u_mem.mem[131] == 64'hC3,
        "a Put burst under way when the mode went to VOTED OFF must complete at the device, not be split");
    dq.delete();
    v = new[0];
    send(TL_A_GET, 3'd0, 3, 8'h42, 32'h400, v, 50, ok);
    wait_d(1, 100, ok);
    tck("BEAT_ERR", ok && dq.size() == 1 && dq[0].denied, "the next message after the change must be denied");
    dq.delete();
    mode = 2'd0; stall_every = 0; rsp_dly = 0;
    cycles(10);
    send(TL_A_GET, 3'd0, 3, 8'h43, 32'h400, v, 50, ok);
    wait_d(1, 100, ok);
    tck("PASS", ok && dq.size() == 1 && !dq[0].denied && dq[0].data == 64'hC0, "traffic resumes in DEFAULT");
    dq.delete();

    // ---- The always-on checks ----
    tck("BURST_DRAIN", partial_at_gate == 0,
        $sformatf("the device held a part-received message in %0d of %0d gated cycles", partial_at_gate, gated_cycles));
    tck("PASS", u_mem.n_off_viol == 0, $sformatf("%0d A beats offered to the device while it was OFF", u_mem.n_off_viol));

    $display("");
    $display("acg_tluh_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display("RESULT: PASS");
    else             $display("RESULT: FAIL");
    $finish;
  end

  initial begin
    #5ms;
    $display("[%0t] tb| ERROR: [chk:TIMEOUT] the run did not finish", $time);
    $display("acg_tluh_tb: %0d checks, %0d error(s)", checks, errors + 1);
    $display("RESULT: FAIL");
    $finish;
  end

endmodule
