`timescale 1ns/1ps
// A TL-UH memory for testing the TL-UH access gate (acg_tluh_tb). NOT a
// general TileLink device: one 64-bit-word array, every TL-UH A message
// (PutFullData, PutPartialData, ArithmeticData, LogicalData, Get, Hint) as a
// burst of 2^(size-3) beats when it carries data, answered in order after a
// programmable delay. Atomics operate on each 64-bit beat as a whole (the
// testbench uses size >= 3 for them). Encodings: vendor/sovra_tl/tl_pkg.sv.
//
// on = 0 models the domain OFF behind its isolation: a_ready clamped LOW, no
// D beats, and every a_valid seen counted as a violation (nothing may reach
// a powered-down domain).

module tluh_mem_model
  import tl_pkg::*;
#(
  parameter int unsigned DW   = 64,
  parameter int unsigned SZW  = 4,
  parameter int unsigned SRCW = 8,
  parameter int unsigned AW   = 32,
  parameter int unsigned WORDS = 256
) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic             on,
  input  int unsigned      rsp_dly,       // cycles from a message's last A beat to its first D beat
  input  int unsigned      stall_every,   // 0: a_ready always HIGH; n: LOW one cycle in n

  input  logic             a_valid,
  output logic             a_ready,
  input  logic [2:0]       a_opcode,
  input  logic [2:0]       a_param,
  input  logic [SZW-1:0]   a_size,
  input  logic [SRCW-1:0]  a_source,
  input  logic [AW-1:0]    a_address,
  input  logic [DW/8-1:0]  a_mask,
  input  logic [DW-1:0]    a_data,
  output logic             d_valid,
  input  logic             d_ready,
  output logic [2:0]       d_opcode,
  output logic [1:0]       d_param,
  output logic [SZW-1:0]   d_size,
  output logic [SRCW-1:0]  d_source,
  output logic             d_denied,
  output logic [DW-1:0]    d_data,
  output logic             d_corrupt
);

  logic [63:0] mem [WORDS];

  int unsigned n_msgs = 0, n_beats = 0, n_off_viol = 0, cnt = 0;
  int unsigned beat_in_msg = 0, msg_beats = 0;     // the message being received
  bit          partial = 1'b0;                      // a message is part-way in

  typedef struct {
    logic [2:0]      op;
    logic [SZW-1:0]  size;
    logic [SRCW-1:0] src;
    logic [63:0]     data [$];
    longint unsigned at;
  } rsp_t;
  rsp_t rq [$];
  longint unsigned cyc = 0;

  function automatic int unsigned nbeats(input logic [2:0] op, input int unsigned size, input bit resp);
    bit data = resp ? (op == TL_A_GET || op == TL_A_ARITH || op == TL_A_LOGICAL)
                    : (op == TL_A_PUT_FULL || op == TL_A_PUT_PARTIAL || op == TL_A_ARITH || op == TL_A_LOGICAL);
    return (!data || size <= 3) ? 1 : (1 << (size - 3));
  endfunction

  function automatic logic [63:0] atomic(input logic [2:0] op, input logic [2:0] prm,
                                         input logic [63:0] o, input logic [63:0] d);
    if (op == TL_A_ARITH)
      case (prm)
        TL_ATOM_MIN:  return ($signed(o) < $signed(d)) ? o : d;
        TL_ATOM_MAX:  return ($signed(o) > $signed(d)) ? o : d;
        TL_ATOM_MINU: return (o < d) ? o : d;
        TL_ATOM_MAXU: return (o > d) ? o : d;
        default:      return o + d;                 // TL_ATOM_ADD
      endcase
    case (prm)
      TL_ATOM_XOR: return o ^ d;
      TL_ATOM_OR:  return o | d;
      TL_ATOM_AND: return o & d;
      default:     return d;                        // TL_ATOM_SWAP
    endcase
  endfunction

  assign a_ready = on && (stall_every == 0 || (cnt % stall_every) != stall_every - 1);

  // ---- The A channel: collect each message, act on it at its last beat ----
  rsp_t cur;
  logic [2:0] cur_prm;
  logic [AW-1:0] cur_addr;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    cnt <= cnt + 1;
    if (rst_n && a_valid && !on) n_off_viol++;
    if (rst_n && a_valid && a_ready) begin
      automatic int unsigned w;
      n_beats++;
      if (!partial) begin
        cur.op = a_opcode; cur.size = a_size; cur.src = a_source; cur.data = {};
        cur_prm = a_param; cur_addr = a_address;
        msg_beats = nbeats(a_opcode, a_size, 1'b0);
        beat_in_msg = 0;
        n_msgs++;
      end
      w = ((cur_addr >> 3) + beat_in_msg) % WORDS;
      case (cur.op)
        TL_A_PUT_FULL, TL_A_PUT_PARTIAL:
          for (int b = 0; b < 8; b++) if (a_mask[b]) mem[w][8*b +: 8] = a_data[8*b +: 8];
        TL_A_ARITH, TL_A_LOGICAL: begin
          cur.data.push_back(mem[w]);
          mem[w] = atomic(cur.op, cur_prm, mem[w], a_data[63:0]);
        end
        default: ;
      endcase
      beat_in_msg++;
      partial = (beat_in_msg < msg_beats);
      if (!partial) begin
        if (cur.op == TL_A_GET)
          for (int k = 0; k < nbeats(cur.op, cur.size, 1'b1); k++)
            cur.data.push_back(mem[((cur_addr >> 3) + k) % WORDS]);
        cur.at = cyc + rsp_dly;
        rq.push_back(cur);
      end
    end
  end

  // ---- The D channel: in order, every beat of a response contiguous ----
  // Re-evaluated whenever cyc advances (every edge), after the A process
  // above has pushed or the D process below has popped.
  int unsigned d_beat = 0;
  always @(*) begin
    d_valid = 1'b0; d_opcode = '0; d_param = '0; d_size = '0; d_source = '0;
    d_denied = 1'b0; d_data = '0; d_corrupt = 1'b0;
    if (on && rq.size() > 0 && cyc >= rq[0].at) begin
      d_valid  = 1'b1;
      d_size   = rq[0].size;
      d_source = rq[0].src;
      case (rq[0].op)
        TL_A_PUT_FULL, TL_A_PUT_PARTIAL: d_opcode = TL_D_ACCESS_ACK;
        TL_A_HINT:                       d_opcode = TL_D_HINT_ACK;
        default: begin
          d_opcode = TL_D_ACCESS_ACKDATA;
          d_data   = DW'(rq[0].data[d_beat]);
        end
      endcase
    end
  end

  always @(posedge clk)
    if (rst_n && d_valid && d_ready) begin
      if (d_beat + 1 >= nbeats(rq[0].op, rq[0].size, 1'b1)) begin
        d_beat = 0;
        void'(rq.pop_front());
      end else begin
        d_beat++;
      end
    end

endmodule
