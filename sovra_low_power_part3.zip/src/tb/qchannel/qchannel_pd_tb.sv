`timescale 1ns/1ps
// Testbench for the Q-Channel gate-able power domain (qchannel_pd_top).
//
// Exercises the full "shut the clock off through the handshake" flow:
//   controller (pd_req) -> QREQn -> device -> dev_clk_en -> clock-control ICG ->
//   dummy_workload clock.
//
//   P0  Reset & bring-up: domain runs, workload clock toggles.
//   P1  Start a burst: workload goes busy, work counts down, then drains.
//   P2  Idle-path: request quiesce while already idle -> immediate gate off,
//       zero edges, and exit by WITHDRAWING pd_req.
//   P3  Sustained gating: hold Q_STOPPED for 20 dclk cycles, zero edges, no
//       drift, then exit via QACTIVE while pd_req is still asserted.
//   P4  Q_DENIED -> Q_CONTINUE recovery: denied mid-burst with the clock still
//       running, auto-recovering to Q_STOPPED once the workload drains.
//   P5  Light work freezes mid-countdown while gated and RESUMES (does not
//       restart).
//   P6  deny_enb=0: device does not deny, but waits for the burst to drain.
//   P7  Power shutoff and restore: the reset/power interlock refuses to remove
//       the supply until the POWER-control channel reaches Q_STOPPED, the
//       device outputs hold the Q_STOPPED encoding while the domain is down,
//       and the domain comes back from reset rather than from retained state.
//       This is the phase that exercises the UPF power intent in src/upf --
//       see src/upf/README.md.
//
// The two exit paths are deliberately split across P2 and P3: P2 leaves
// Q_STOPPED by withdrawing pd_req, P3 by raising QACTIVE with pd_req still
// held. Those are different terms in the controller's Q_STOPPED arm.
//
// Earlier revisions had four more phases -- a standalone deny-while-busy, an
// accept-after-drain, a wake, and a post-gate functional burst. Every one of
// them re-ran a sequence P4 already performs end to end with strictly more
// checks, so they were folded in rather than maintained in parallel. The two
// checks that were unique to them (clock still ON during a denial, and "QACTIVE
// caused this exit, not a withdrawn request") now live in P4 and P3.
//
// The Q-Channel protocol monitors (one per channel) run throughout and must
// report zero violations.
//
// STIMULUS TIMING CONVENTION
// Every DUT input is driven on the NEGEDGE of the clock that samples it, so the
// sampling posedge lands in the middle of the data eye rather than on its edge.
// Driving on the posedge -- as this testbench originally did -- puts the input
// transition and the sampling edge at the same simulation time, which leaves
// the result dependent on event-ordering inside the simulator, produces
// waveforms whose cause and effect are impossible to read apart, and hides
// exactly the setup/hold problems a testbench exists to expose.
//
// The one deliberate exception is the gated-clock edge counter below, which
// must stay on the posedge: counting clock edges is its whole purpose.


module qchannel_pd_tb;

  import qchannel_pkg::*;

  localparam int unsigned CNT_W = 8;

  // Independent clocks: AON (controller + reset control) 4.3 ns, device/workload
  // 13.7 ns, monitor 1 ns.
  logic dclk = 1'b0, aon_clk = 1'b0, mclk = 1'b0;
  always #6.85 dclk    = ~dclk;
  always #2.15 aon_clk = ~aon_clk;
  always #0.50 mclk    = ~mclk;

  logic aon_rst_n   = 1'b0;  // AON domain root reset, async ACTIVE LOW -- also
                              // both controllers' own reset, since they now
                              // live in the AON domain alongside qchannel_devrst_ctrl
  logic pwr_req     = 1'b1;  // PM policy: request the POWER-control channel to
                              // quiesce (mirrors pd_req, but on the separate
                              // power-control Q-Channel -- PCSA 8.2.1)
  logic dev_rst_req = 1'b1;  // PM policy: 1 = hold device in reset (boot default)
  // Monitor's own operating reset: deasserted once, early, and never again --
  // independent of the domain resets so the monitor's pipeline survives (and
  // can therefore observe/check) later domain-reset events (R8/R9 in the
  // monitor).
  logic mrst_n = 1'b0;
  initial begin mrst_n = 1'b0; #1 mrst_n = 1'b1; end

  // Stimulus
  logic             pd_req = 1'b0;
  logic             start  = 1'b0;
  logic [CNT_W-1:0] work_len = '0;
  logic             light_work = 1'b0;
  logic             deny_enb = 1'b1;  // 1 = deny on busy, 0 = wait for completion
  logic             wake   = 1'b0;

  logic [CNT_W-1:0] frozen_count;  // captured work_count during P9

  int unsigned viol, viol_pwr;
  int unsigned tb_errors = 0, checks = 0;

  // ---- DUT ----
  // qchannel_pd_top only exposes real, system-level ports (clocks, resets,
  // PM-policy control/stimulus). No debug/observability ports.
  qchannel_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .pd_req(pd_req),
    .pwr_req(pwr_req), .dev_rst_req(dev_rst_req),
    .dclk(dclk), .start(start), .work_len(work_len), .light_work(light_work), .deny_enb(deny_enb), .wake(wake)
  );

  // ---- Observability via hierarchical reference into the DUT ----
  // Everything below is a plain read of u_top's internal signals -- the DUT
  // itself carries no debug-only ports (see its header comment).
  wire             clk__qreqn      = u_top.clk__qreqn;
  wire             clk__qacceptn   = u_top.clk__qacceptn;
  wire             clk__qdeny      = u_top.clk__qdeny;
  wire             clk__qactive    = u_top.clk__qactive;
  wire             drst_n_local    = u_top.drst_n;
  wire             pwr__qreqn      = u_top.pwr__qreqn;
  wire             pwr__qacceptn   = u_top.pwr__qacceptn;
  wire             pwr__qdeny      = u_top.pwr__qdeny;
  wire             pwr__qactive    = u_top.pwr__qactive;
  wire             dev_stopped_clk = u_top.u_ctrl_clk.dev_stopped;
  wire             dev_stopped_pwr = u_top.dev_stopped_pwr;
  wire             dev_clk_en      = u_top.dev_clk_en;
  wire             dummy_clk       = u_top.dummy_clk;
  // clk_gated port was removed (no functional consumer), so this reads the
  // gate's enable latch directly. u_clkctrl is in PD_DEV, the SWITCHED domain,
  // so under "make pa" en_latch is X whenever the supply is absent -- including
  // at time zero, because rst_hold_n resets to 0 and PD_DEV therefore starts
  // OFF. Inverting propagated that X into qchannel_monitor, whose R10 rule
  // triggers on "posedge clk_gated", and in Verilog x->1 IS a posedge: one
  // spurious "resource gated outside Q_STOPPED" at 55 ns.
  //
  // Comparing against 1 resolves X to "gated", which is the truthful reading --
  // a domain with no supply has no clock. In ordinary simulation en_latch is
  // only ever 0 or 1, so this is identical to ~en_latch and "make pd" (and
  // "make xsim-diff", removed 2026-10-06) are unaffected. Same change, same
  // reason, as in
  // tb/ppu/ppu_pd_tb.sv.
  wire             clk_gated       = (u_top.u_clkctrl.en_latch !== 1'b1);
  wire             busy            = u_top.busy;
  wire             done            = u_top.u_dummy.done;
  wire [CNT_W-1:0] work_count      = u_top.u_dummy.work_count;

  // Count edges of the (gated) workload clock to prove gating/ungating.
  int unsigned dclk_edges = 0;
  always @(posedge dummy_clk) dclk_edges = dclk_edges + 1;

  // ---- Protocol monitor on the clock-control interface wires ----
  // crst_n now watches aon_rst_n (the controllers' reset, since they live in
  // the AON domain). drst_n watches the DUT's *generated* device reset
  // (drst_n_local), not the raw dev_rst_req stimulus -- R8 is checking
  // qchannel_devrst_ctrl's output, which is the thing the spec's "only assert
  // in Q_STOPPED" rule is actually about. clk_gated feeds the analogous R10
  // check ("only remove clock or power when Q_STOPPED") for this channel's
  // actual physical clock gate.
  qchannel_monitor u_mon (
    .clk(mclk), .rst_n(mrst_n),
    .crst_n(aon_rst_n), .drst_n(drst_n_local), .clk_gated(clk_gated),
    .qreqn(clk__qreqn), .qacceptn(clk__qacceptn), .qdeny(clk__qdeny), .violations(viol)
  );

  // ---- Protocol monitor on the power-control interface wires (separate
  // channel per PCSA 8.2.1) ----
  // clk_gated tied LOW: this channel never gates a clock -- its equivalent
  // resource removal is the device reset, already covered by R8.
  qchannel_monitor u_mon_pwr (
    .clk(mclk), .rst_n(mrst_n),
    .crst_n(aon_rst_n), .drst_n(drst_n_local), .clk_gated(1'b0),
    .qreqn(pwr__qreqn), .qacceptn(pwr__qacceptn), .qdeny(pwr__qdeny), .violations(viol_pwr)
  );

  // ---- Helpers ----
  function automatic qch_state_e cur_state();
    return qch_decode(clk__qreqn, clk__qacceptn, clk__qdeny);
  endfunction

  // The POWER channel's state. cur_state() above decodes the CLOCK channel, and
  // the two are independent -- a phase that drives pwr_req and waits on
  // cur_state() waits on something it never touched.
  function automatic qch_state_e pwr_state();
    return qch_decode(pwr__qreqn, pwr__qacceptn, pwr__qdeny);
  endfunction

  task automatic wait_pwr_state(input qch_state_e exp, input int limit_ns,
                                input string tag);
    time t0; bit done_l;
    begin
      t0 = $time; done_l = 1'b0; checks++;
      while (!done_l) begin
        if (pwr_state() === exp) begin
          $display("[%0t]  ok  %s: power channel reached %s", $time, tag, qch_name(exp));
          done_l = 1'b1;
        end else if (($time - t0) > limit_ns) begin
          tb_errors++;
          $display("[%0t] FAIL %s: timeout for %s, power channel stuck in %s",
                   $time, tag, qch_name(exp), qch_name(pwr_state())); done_l = 1'b1;
        end else #1;
      end
    end
  endtask

  task automatic wait_state(input qch_state_e exp, input int limit_ns, input string tag);
    time t0; bit done_l;
    begin
      t0 = $time; done_l = 1'b0; checks++;
      while (!done_l) begin
        if (cur_state() === exp) begin
          $display("[%0t]  ok  %s: reached %s", $time, tag, qch_name(exp)); done_l = 1'b1;
        end else if (($time - t0) > limit_ns) begin
          tb_errors++;
          $display("[%0t] FAIL %s: timeout for %s, stuck in %s",
                   $time, tag, qch_name(exp), qch_name(cur_state())); done_l = 1'b1;
        end else #1;
      end
    end
  endtask

  task automatic check(input bit cond, input string tag);
    checks++;
    if (!cond) begin tb_errors++; $display("[%0t] FAIL %s", $time, tag); end
    else            $display("[%0t]  ok  %s", $time, tag);
  endtask

  // ---- Current test phase, as ASCII in the waveform ----
  // VCD has no string type, so the phase name lives in a packed byte vector:
  // dumpers emit that as an ordinary reg, and GTKWave renders it as text once
  // the trace's Data Format is set to ASCII. A SystemVerilog `string` will not
  // survive the dump -- Icarus will not even cast one into a packed vector.
  //
  // Sized to hold the longest phase name below without truncation. That matters:
  // an over-long name assigned straight through $sformat would overflow and keep
  // the RIGHTMOST characters, silently dropping the "P7"/"P8" prefix that
  // identifies the test. set_phase truncates from the right instead.
  localparam int unsigned PHASE_CHARS = 56;
  reg [8*PHASE_CHARS-1:0] test_phase;

  // Single source of truth for the phase: drives the waveform signal and prints
  // the log banner together, so the two can never disagree.
  task automatic set_phase(input string name);
    begin
      if (name.len() > PHASE_CHARS)
        $sformat(test_phase, "%-56s", name.substr(0, PHASE_CHARS-1));
      else
        $sformat(test_phase, "%-56s", name);
      $display("\n[%0t] ========== %0s ==========", $time, name);
    end
  endtask

  // Wait for busy to reach a value (poll), with timeout.
  task automatic wait_busy(input bit val, input int limit_ns, input string tag);
    time t0; begin
      t0 = $time; checks++;
      while (busy !== val && ($time - t0) <= limit_ns) #1;
      if (busy === val) $display("[%0t]  ok  %s: busy=%0b", $time, tag, val);
      else begin tb_errors++; $display("[%0t] FAIL %s: busy stuck at %0b", $time, tag, busy); end
    end
  endtask

  // ---- Stimulus ----
  initial begin
    time t0; int unsigned e0; bit busy_at_stopped;
    $dumpfile("qchannel_pd_tb.vcd");
    $dumpvars(0, qchannel_pd_tb);

    set_phase("P0: Reset and Bring-Up");
    $display("[%0t]   Goal: Verify clean startup - Q_RUN state, clock enabled", $time);
    $display("[%0t]   Step 1: Hold the AON domain (both controllers + devrst_ctrl) in reset,", $time);
    $display("[%0t]           device reset requested", $time);
    aon_rst_n = 0; pwr_req = 1; dev_rst_req = 1; pd_req = 0; start = 0; work_len = 0; wake = 0;

    $display("[%0t]   Step 2: Release the AON domain -- both controllers reset straight into", $time);
    $display("[%0t]           Q_STOPPED, so dev_stopped_pwr is immediately valid for the reset", $time);
    $display("[%0t]           interlock, same-domain, no resync needed", $time);
    #30 @(negedge aon_clk) aon_rst_n = 1'b1;

    $display("[%0t]   Step 3: PM policy releases the power-control request and the device reset", $time);
    $display("[%0t]           request together (qchannel_devrst_ctrl only lets the latter take", $time);
    $display("[%0t]           effect once power-control Q_STOPPED is confirmed -- trivially true", $time);
    $display("[%0t]           here since it always is at boot)", $time);
    #20 @(negedge aon_clk) begin pwr_req = 1'b0; dev_rst_req = 1'b0; end

    wait_state(Q_RUN, 3000, "P0.bringup");
    check(dev_clk_en, "P0: workload clock enabled in Q_RUN");
    e0 = dclk_edges; #100;
    check(dclk_edges > e0, "P0: workload clock is toggling while running");

    set_phase("P1: Regular Work Burst");
    $display("[%0t]   Goal: Verify workload starts and busy=1, work_count decrements", $time);
    @(negedge dclk); work_len = 8'd10; start = 1'b1;
    wait_busy(1'b1, 1000, "P1.busy");
    @(negedge dclk); start = 1'b0;
    #40;
    check(work_count < 8'd10 && work_count > 0, "P1: work is counting down");
    // Drain the burst before moving on: the next phase tests the IDLE request
    // path, which only means anything if the workload is genuinely idle.
    wait_busy(1'b0, 3000, "P1.drained");

    set_phase("P2: Idle-Path Clock Gating");
    $display("[%0t]   Goal: Quiesce request while idle → immediate Q_STOPPED and gate", $time);
    $display("[%0t]   Step 1: Request quiesce (workload already idle)", $time);
    @(negedge aon_clk); pd_req = 1'b1;
    wait_state(Q_STOPPED, 2000, "P2.stopped");
    t0 = $time; while (!clk_gated && ($time - t0) < 800) #1;
    check(clk_gated, "P2: idle domain gated off on request");
    e0 = dclk_edges; #200;
    check(dclk_edges == e0, "P2: clock stays gated (zero edges)");
    @(negedge aon_clk); pd_req = 1'b0;
    wait_state(Q_RUN, 2000, "P2.run");

    set_phase("P3: Sustained Power Savings");
    $display("[%0t]   Goal: Hold Q_STOPPED for 20 dclk cycles, clock gated (0 edges)", $time);
    $display("[%0t]   Step 1: Start regular work", $time);
    @(negedge dclk); work_len = 8'd8; start = 1'b1;
    wait_busy(1'b1, 1000, "P3.busy");
    @(negedge dclk); start = 1'b0;
    wait_busy(1'b0, 3000, "P3.done");

    $display("[%0t]   Step 2: Request quiesce (work complete)", $time);
    @(negedge aon_clk); pd_req = 1'b1;
    wait_state(Q_STOPPED, 2000, "P3.request");
    t0 = $time; while (!clk_gated && ($time - t0) < 800) #1;
    check(clk_gated && !dev_clk_en, "P3: clock gated on quiesce");

    $display("[%0t]   Step 3: Hold Q_STOPPED for 20 dclk cycles (sustained gating)", $time);
    // Hold Q_STOPPED for 20 dclk cycles (sustained gating)
    e0 = dclk_edges;
    #(20 * 13.7);  // 20 dclk cycles @ 13.7 ns period
    check(dclk_edges == e0, "P3: clock edges during 20-cycle hold = 0");
    check(cur_state() == Q_STOPPED, "P3: stayed in Q_STOPPED (no drift)");

    $display("[%0t]   Step 4: Wake and resume from sustained gating", $time);
    // Resume from sustained Q_STOPPED
    @(negedge dclk); wake = 1'b1;
    wait_state(Q_EXIT, 2000, "P3.exit-on-qactive");
    // pd_req is still asserted, so QACTIVE -- not a withdrawn request -- is what
    // forced the exit. That is the Section 2.1.3 anti-deadlock policy, and the
    // distinction from P2's withdrawal-driven exit.
    check(pd_req == 1'b1, "P3: exited Q_STOPPED via QACTIVE while pd_req asserted");
    pd_req = 1'b0; @(negedge dclk); wake = 1'b0;
    wait_state(Q_RUN, 2000, "P3.run");
    e0 = dclk_edges; #100;
    check(dclk_edges > e0, "P3: clock resumed after sustained gating");

    set_phase("P4: Q_DENIED/Q_CONTINUE Recovery Path");
    $display("[%0t]   Goal: Request quiesce during busy → Q_DENIED, auto-recover to Q_STOPPED", $time);
    $display("[%0t]   Step 1: Start regular work", $time);
    @(negedge dclk); work_len = 8'd12; start = 1'b1;
    wait_busy(1'b1, 1000, "P4.busy");
    @(negedge dclk); start = 1'b0;

    $display("[%0t]   Step 2: Let work progress mid-burst (~5 cycles)", $time);
    // Wait ~5 cycles into work (workload still busy, mid-countdown)
    #(5 * 13.7);

    $display("[%0t]   Step 3: Verify work is mid-burst", $time);
    // Verify workload is indeed still busy
    #1;
    check(busy, "P4: workload is busy before requesting quiesce");
    check(work_count > 0 && work_count < 12, "P4: work_count is mid-burst");

    $display("[%0t]   Step 4: Request quiesce while work busy → Q_DENIED", $time);
    // Request quiesce while BUSY
    @(negedge aon_clk); pd_req = 1'b1;
    // Device sends Q_DENIED to refuse quiescence while workload is busy
    wait_state(Q_DENIED, 2000, "P4.denied");
    check(busy, "P4: device reports busy during Q_DENIED");
    check(work_count > 0, "P4: work_count > 0 in Q_DENIED");
    // A denial must leave the device fully operational -- the clock keeps
    // running and the burst keeps draining. Without this the phase would pass
    // even if the device had gated the clock while claiming to deny.
    check(dev_clk_en && !clk_gated, "P4: clock still ON (device refused gating)");
    check(cur_state() == Q_DENIED, "P4: stays in Q_DENIED while busy");

    $display("[%0t]   Step 5: Hold pd_req, wait for work completion", $time);
    // Hold pd_req, wait for work completion (device auto-recovers via Q_CONTINUE)
    wait_busy(1'b0, 5000, "P4.work-complete");

    // Once workload finishes, device accepts quiesce -> Q_STOPPED
    wait_state(Q_STOPPED, 3000, "P4.stopped");
    t0 = $time; while (!clk_gated && ($time - t0) < 800) #1;  // wait for clock gate to propagate
    check(clk_gated && !dev_clk_en, "P4: clock gated after recovery");

    // Resume
    @(negedge dclk); wake = 1'b1;
    wait_state(Q_EXIT, 2000, "P4.exit");
    pd_req = 1'b0; @(negedge dclk); wake = 1'b0;
    wait_state(Q_RUN, 2000, "P4.run");

    set_phase("P5: Light Work Hang (Frozen During Clock Gate)");
    $display("[%0t]   Goal: Light work freezes mid-countdown when clock gated, resumes (no restart)", $time);
    $display("[%0t]   Step 1: Start light work (no busy flag set)", $time);
    @(negedge dclk); work_len = 8'd20; light_work = 1'b1; start = 1'b1;  // longer work for more margin
    wait_busy(1'b0, 1000, "P5.idle");  // light work doesn't set busy
    @(negedge dclk); start = 1'b0; light_work = 1'b0;

    $display("[%0t]   Step 2: Let light work progress mid-burst (~8 cycles)", $time);
    // Let light work run for ~8 dclk cycles (should have cnt ~12 remaining)
    #(8 * 13.7);

    $display("[%0t]   Step 3: Verify light work mid-burst (busy should be 0)", $time);
    // Verify light work is in progress (work_count should be mid-burst)
    #1;
    check(work_count > 0 && work_count < 20, "P5: light work is mid-burst before quiesce");

    $display("[%0t]   Step 4: Request quiesce → device accepts (no Q_DENIED)", $time);
    // Request quiesce while light work in-flight
    @(negedge aon_clk); pd_req = 1'b1;

    // Device should accept (busy=0 during light work)
    wait_state(Q_REQUEST, 1000, "P5.request");
    check(!busy, "P5: light work never sets busy");

    // Device accepts quiesce immediately (no Q_DENIED)
    wait_state(Q_STOPPED, 2000, "P5.stopped");
    t0 = $time; while (!clk_gated && ($time - t0) < 800) #1;
    check(clk_gated && !dev_clk_en, "P5: clock gated while light work mid-count");

    $display("[%0t]   Step 5: Clock gated - capture frozen work_count", $time);
    // Capture work_count during freeze (should be ~12-15)
    #1;  // One time unit to ensure clean capture
    frozen_count = work_count;
    check((frozen_count > 0) && (frozen_count < 20),
          "P5: work_count frozen mid-burst (should be partial count)");

    $display("[%0t]   Step 6: Hold gated for 10 dclk cycles (verify clock OFF, work frozen)", $time);
    // Hold gated for 10 cycles
    e0 = dclk_edges;
    #(10 * 13.7);
    check(dclk_edges == e0, "P5: clock edges during gating = 0");
    check(work_count == frozen_count, "P5: work_count stayed frozen");

    $display("[%0t]   Step 7: Wake via QACTIVE - work resumes from frozen state", $time);
    // Wake up via QACTIVE
    @(negedge dclk); wake = 1'b1;
    wait_state(Q_EXIT, 2000, "P5.exit");
    pd_req = 1'b0; @(negedge dclk); wake = 1'b0;
    wait_state(Q_RUN, 2000, "P5.run");

    // Verify light work continues countdown from frozen state
    e0 = dclk_edges;
    #200;  // Wait ~15 dclk cycles for countdown to complete
    check(dclk_edges > e0, "P5: clock toggling after wake");

    // Wait for done to complete
    #500;
    check(work_count == 0, "P5: work_count reached 0 after resume");

    set_phase("P6: Deny Disabled (Accept Quiesce While Busy)");
    $display("[%0t]   Goal: With deny_enb=0, device accepts quiesce even during busy work", $time);

    // Reset to Q_RUN
    #100; @(negedge aon_clk) pd_req = 1'b0;
    wait_state(Q_RUN, 2000, "P6.idle");

    $display("[%0t]   Step 1: Disable denial behavior (deny_enb = 0)", $time);
    // Disable denial behavior: allow controller to wait for work completion
    deny_enb = 1'b0;

    $display("[%0t]   Step 2: Start regular work burst (longer to observe behavior)", $time);
    // Start regular work burst (longer work to give more time to observe)
    @(negedge dclk); start = 1'b1; work_len = 'd30; light_work = 1'b0;
    @(negedge dclk); start = 1'b0;
    check(busy == 1'b1, "P6.busy: regular work started, busy=1");

    $display("[%0t]   Step 3: Let work progress mid-burst (~10 cycles)", $time);
    // Let work progress for 10 dclk cycles (still in progress)
    #(10 * 13.7);
    check(work_count > 0, "P6: work is mid-burst before quiesce request");
    check(work_count <= 30, "P6: work_count is in valid range");

    $display("[%0t]   Step 4: Request quiesce while work busy (deny disabled)", $time);
    // Request quiesce while work is busy
    @(negedge aon_clk); pd_req = 1'b1;

    $display("[%0t]   Step 5: Device does not deny -- it holds in Q_REQUEST until the burst drains", $time);
    // deny_enb=0 removes the DENIAL, not the WAIT. dev_quiescent_deny is
    // (deny_enb && busy), so with deny_enb=0 the device never enters Q_DENIED --
    // but dev_quiescent_busy is still HIGH, so the FSM sits in Q_REQUEST
    // (operational, clock running) until the burst finishes, and only then
    // accepts. Expect roughly the remaining work_len in dclk cycles here, not an
    // immediate gate. See TEST_MATRIX.md.
    // Capture busy BEFORE waiting for state, to catch it before work completes
    wait_state(Q_STOPPED, 2000, "P6.stopped");
    // Check immediately - work may complete during synchronizer delay
    busy_at_stopped = busy;
    frozen_count = work_count;

    // Clock gates off immediately
    t0 = $time; while (!clk_gated && ($time - t0) < 800) #1;
    check(clk_gated && !dev_clk_en, "P6: clock gated once accepted (no Q_DENIED with deny_enb=0)");

    // Verify intent: when deny disabled, device accepts even if work ongoing at request time
    // (busy might complete during CDC synchronizer delay, so check snapshot)
    check(busy_at_stopped == 1'b1 || work_count < 30,
          "P6: device accepts quiesce when deny disabled (work may finish during CDC)");

    $display("[%0t]   Step 6: Hold gated and confirm zero clock edges", $time);
    // The burst has already drained by this point (that is what unblocked the
    // accept), so this is confirming the gate holds, not that work freezes --
    // freezing mid-burst is P9's job.
    e0 = dclk_edges;
    #(10 * 13.7);
    check(dclk_edges == e0, "P6: clock edges while gated = 0");

    $display("[%0t]   Step 7: Wake and verify work completes successfully", $time);
    // When we wake up, work should be further along or complete
    @(negedge dclk); wake = 1'b1;
    wait_state(Q_EXIT, 2000, "P6.exit");
    pd_req = 1'b0; @(negedge dclk); wake = 1'b0;
    wait_state(Q_RUN, 2000, "P6.run");

    // Work finishes after wake
    e0 = $time;
    while (busy && (($time - e0) < 1000)) #1;
    check(busy == 1'b0, "P6.done: work completed after wake");

    // Re-enable denial for subsequent tests
    deny_enb = 1'b1;

    set_phase("P7: Power Shutoff and Restore");
    $display("[%0t]   Goal: The supply is removed only once the POWER-control channel", $time);
    $display("[%0t]         reaches Q_STOPPED, the device outputs hold the Q_STOPPED", $time);
    $display("[%0t]         encoding while the domain is down, and the domain comes back", $time);
    $display("[%0t]         from RESET rather than from retained state.", $time);
    $display("[%0t]         This is the phase that exercises src/upf/qchannel_pd_top.upf:", $time);
    $display("[%0t]         the switch control, the isolation clamp values, and the", $time);
    $display("[%0t]         deliberate absence of a retention strategy.", $time);

    $display("[%0t]   Step 1: Start a regular burst so the domain has work in flight", $time);
    @(negedge dclk); work_len = 8'd25; light_work = 1'b0; start = 1'b1;
    wait_busy(1'b1, 1000, "P7.busy");
    @(negedge dclk); start = 1'b0;

    $display("[%0t]   Step 2: PM policy asks for the reset/power hold WHILE busy. No", $time);
    $display("[%0t]           quiescence has been negotiated, so qchannel_devrst_ctrl's", $time);
    $display("[%0t]           interlock must refuse it -- AMBA LPI 2.1.2 permits removing", $time);
    $display("[%0t]           a device's clock or power only in Q_STOPPED, and here that", $time);
    $display("[%0t]           rule is a register, not a note in a specification.", $time);
    @(negedge aon_clk); dev_rst_req = 1'b1;
    #(5 * 13.7);
    check(busy, "P7: workload still busy");
    check(!dev_stopped_pwr, "P7: power-control channel is not in Q_STOPPED while busy");
    check(drst_n_local === 1'b1,
          "P7: power-down refused by the interlock before Q_STOPPED");

    $display("[%0t]   Step 3: Request quiesce on BOTH channels. PCSA 8.2.1 keeps clock", $time);
    $display("[%0t]           and power control as separate negotiations, so a full", $time);
    $display("[%0t]           power-down has to win both of them.", $time);
    @(negedge aon_clk) begin pd_req = 1'b1; pwr_req = 1'b1; end
    wait_busy(1'b0, 8000, "P7.drained");
    t0 = $time; while (drst_n_local !== 1'b0 && ($time - t0) < 4000) #1;
    check(drst_n_local === 1'b0,
          "P7: supply/reset removed once the power channel reached Q_STOPPED");
    check(dev_stopped_pwr, "P7: power-control channel in Q_STOPPED at power-down");
    check(dev_stopped_clk, "P7: clock-control channel in Q_STOPPED at power-down");

    $display("[%0t]   Step 4: While the domain is down its outputs must still read the", $time);
    $display("[%0t]           Q_STOPPED encoding of Table 2-1 {QREQn,QACCEPTn,QDENY}={0,0,0}.", $time);
    $display("[%0t]           Those are exactly the isolation clamp values in the UPF -- a", $time);
    $display("[%0t]           clamp to 1 would advertise Q_RUN from a domain with no supply.", $time);
    #50;
    check(clk__qacceptn === 1'b0 && clk__qdeny === 1'b0,
          "P7: clock-channel device outputs at the Q_STOPPED clamp while powered down");
    check(pwr__qacceptn === 1'b0 && pwr__qdeny === 1'b0,
          "P7: power-channel device outputs at the Q_STOPPED clamp while powered down");
    check(clk__qactive === 1'b0 && pwr__qactive === 1'b0,
          "P7: no wake asserted from a powered-down domain (PCSA 8.3.4)");
    e0 = dclk_edges;
    #(10 * 13.7);
    check(dclk_edges == e0, "P7: workload clock edges while powered down = 0");

    $display("[%0t]   Step 5: Assert wake while the domain is DOWN. It does nothing.", $time);
    $display("[%0t]           QACTIVE is the interface's own anti-deadlock mechanism", $time);
    $display("[%0t]           (LPI 2.1.3), but it is driven BY the device wrapper, and", $time);
    $display("[%0t]           drst_n holds both wrappers in reset -- qchannel_device drives", $time);
    $display("[%0t]           qacceptn/qdeny/qactive to 0 unconditionally in reset. So the", $time);
    $display("[%0t]           interface reads Q_STOPPED because real flops are holding it", $time);
    $display("[%0t]           there, which is why src/upf keeps the wrappers ALWAYS-ON:", $time);
    $display("[%0t]           the value is held rather than imitated by isolation clamps.", $time);
    $display("[%0t]           Revival is dev_rst_req's job (PCSA 8.3.4 -- wake signalling", $time);
    $display("[%0t]           comes from outside the domain). Compare P3/P5, where wake DOES", $time);
    $display("[%0t]           revive a merely clock-gated domain, because there the workload", $time);
    $display("[%0t]           is powered and busy/dev_wake reach a running FSM.", $time);
    @(negedge dclk); wake = 1'b1;
    e0 = dclk_edges;
    #(10 * 13.7);
    check(clk__qactive === 1'b0 && pwr__qactive === 1'b0,
          "P7: wake cannot raise QACTIVE from a powered-down domain");
    check(drst_n_local === 1'b0, "P7: wake does not revive the domain -- still held down");
    check(dclk_edges == e0, "P7: wake produced no workload clock edges while down");
    check(cur_state() == Q_STOPPED, "P7: interface still reads Q_STOPPED under wake");
    @(negedge dclk); wake = 1'b0;

    $display("[%0t]   Step 6: Restore. Supply and reset come back FIRST; only then is the", $time);
    $display("[%0t]           interface allowed to leave Q_STOPPED.", $time);
    @(negedge aon_clk); dev_rst_req = 1'b0;
    t0 = $time; while (drst_n_local !== 1'b1 && ($time - t0) < 2000) #1;
    check(drst_n_local === 1'b1, "P7: device reset released after the supply is restored");
    @(negedge aon_clk) begin pd_req = 1'b0; pwr_req = 1'b0; end
    wait_state(Q_RUN, 3000, "P7.run");

    $display("[%0t]   Step 7: The restored domain runs a fresh burst. It re-initialises", $time);
    $display("[%0t]           from reset rather than resuming -- the opposite of P5, where", $time);
    $display("[%0t]           CLOCK gating froze a burst and resumed it. PCSA 8.3.4 makes", $time);
    $display("[%0t]           the reset state equal the quiescent state, which is why the", $time);
    $display("[%0t]           UPF carries no set_retention.", $time);
    @(negedge dclk); work_len = 8'd6; start = 1'b1;
    wait_busy(1'b1, 3000, "P7.rework");
    @(negedge dclk); start = 1'b0;
    wait_busy(1'b0, 3000, "P7.recomplete");

    // -------------------------------------------------------------------------
    set_phase("P8: Re-request before the device has acknowledged an exit");
    $display("[%0t]   AMBA LPI 2.1.2: QREQn may fall only with QACCEPTn HIGH", $time);
    $display("[%0t]   (monitor rule R1). The controller therefore has to stay in", $time);
    $display("[%0t]   Q_EXIT until the device raises QACCEPTn, and only then", $time);
    $display("[%0t]   return to Q_RUN where a new request is legal.", $time);
    $display("[%0t]", $time);
    $display("[%0t]   Every earlier phase lets an exit finish before asking for", $time);
    $display("[%0t]   anything else, so a controller that skipped the Q_EXIT wait", $time);
    $display("[%0t]   behaved identically -- QREQn is already HIGH there and no", $time);
    $display("[%0t]   pin moves. It only becomes visible if a new request arrives", $time);
    $display("[%0t]   inside the device's response latency, which is what this", $time);
    $display("[%0t]   phase creates: withdraw and immediately re-assert.", $time);

    // Park the power channel in Q_STOPPED.
    @(negedge aon_clk) pwr_req = 1'b1;
    wait_pwr_state(Q_STOPPED, 8000, "P8.stopped");

    begin
      int unsigned v0;
      v0 = viol_pwr;
      // Withdraw, then WAIT UNTIL THE CHANNEL IS ACTUALLY IN Q_EXIT before
      // re-asserting. A fixed short pulse is not enough and was the first
      // attempt: at one aon_clk it never reached Q_EXIT at all, so the wait
      // being tested was never entered and the phase passed against a
      // controller that skipped it. Waiting for the state makes the scenario
      // deterministic regardless of the clock ratio.
      @(negedge aon_clk) pwr_req = 1'b0;
      wait_pwr_state(Q_EXIT, 8000, "P8.exit");
      // Now re-request, still inside the device's acknowledge latency: the
      // device runs on the slower dclk and has not raised QACCEPTn yet.
      check(pwr__qacceptn === 1'b0,
            "P8: the device has not acknowledged the exit yet");
      @(negedge aon_clk) pwr_req = 1'b1;
      // Let the whole thing settle: the controller must complete the exit
      // handshake first, then run the new request to completion.
      wait_pwr_state(Q_STOPPED, 20000, "P8.stopped_again");
      check(viol_pwr == v0,
            "P8: re-requesting inside the exit latency raised no protocol violation");
      check(pwr__qacceptn === 1'b0,
            "P8: and the channel really did land back in Q_STOPPED");
    end

    @(negedge aon_clk) pwr_req = 1'b0;
    wait_pwr_state(Q_RUN, 20000, "P8.run");

    // Verdict
    #200;
    check(viol == 0, "MONITOR: zero clock-control protocol-rule violations");
    check(viol_pwr == 0, "MONITOR: zero power-control protocol-rule violations");

    $display("\n==================== PD SUMMARY ====================");
    $display(" checks run        : %0d", checks);
    $display(" testbench errors  : %0d", tb_errors);
    $display(" monitor violations (clock): %0d", viol);
    $display(" monitor violations (power): %0d", viol_pwr);
    if (tb_errors == 0 && viol == 0 && viol_pwr == 0) $display(" RESULT: PASS");
    else                             $display(" RESULT: FAIL");
    $display("===================================================\n");
    $finish;
  end

  initial begin #200000; $display("[%0t] FATAL: global timeout", $time); $finish; end

endmodule
