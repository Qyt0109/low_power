# Q-Channel testbenches

Two testbenches for the Q-Channel RTL in
[`src/rtl/qchannel/`](../../rtl/qchannel/README.md) (AMBA LPI, ARM IHI 0068C,
Section 2.1; PCK-600 Section 3.1 for the LPD-Q). The per-phase
control-signal matrix of the domain testbench is
[`TEST_MATRIX.md`](TEST_MATRIX.md).

## Files

| File | Top | Targets | What it checks |
|---|---|---|---|
| `qchannel_pd_tb.sv` | `qchannel_pd_tb` | `pd`, `lint`, `wave-pd`, `pa` | `qchannel_pd_top`: the whole "shut the clock off through the handshake" flow (controller → QREQn → device → clock enable → ICG → workload clock), plus the separate power-control channel, the reset/power interlock and power shutoff. One `qchannel_monitor` per channel |
| `qchannel_lpd_tb.sv` | `qchannel_lpd_tb` | `lpdq` | `qchannel_lpd` (LPD-Q) against PCK-600 Section 3.1 and Table A-1, group by group: `u_a` expander and `u_b` sequencer on four real `qchannel_device` instances each, `u_c` the minimum configuration (two channels, synchronizers removed), `u_d` with ACTIVE_DENY = 1, `u_e` at NUM_QCHL = 32 (elaboration only). A `qchannel_monitor` on every channel |
| `TEST_MATRIX.md` | | | Which inputs each phase of `qchannel_pd_tb` drives, the two exit paths, the phases removed as redundant, notes on P6 and P7 |

## What is checked

`qchannel_pd_tb` (clocks: AON 4.3 ns, device 13.7 ns, monitor 1 ns):

| Phase | Claim |
|---|---|
| P0 | Reset and bring-up: the domain runs, the workload clock toggles |
| P1 | A burst: busy, the count drains |
| P2 | Quiesce while idle: immediate gating, zero edges; exit by withdrawing `pd_req` |
| P3 | Q_STOPPED held 20 device cycles with zero edges; exit by QACTIVE with `pd_req` still asserted |
| P4 | Q_DENIED → Q_CONTINUE: denied mid-burst with the clock running, auto-recovery to Q_STOPPED once the burst drains |
| P5 | Light work freezes mid-countdown while gated and resumes |
| P6 | `deny_enb` = 0: no denial, the device waits for the burst to drain |
| P7 | Power shutoff and restore: the interlock refuses to remove the supply until the power channel reaches Q_STOPPED, the outputs hold the Q_STOPPED encoding while down, the domain comes back from reset |

`qchannel_lpd_tb`, groups L1-L17: reset; expander entry, held accept and
denial; sequencer ordering, exit, and a denial stopping the walk; `ctrl_qactive_o`
as the combinational OR; `clk_qactive_o` (all four bullets); ACTIVE_DENY (checked
on the device request vector, not on `ctrl_qdeny_o`, which a mutant leaves
unchanged); `dftcgen`; NUM_QCHL maximum; the minimum configuration; repeated
entry/exit; protocol (every monitor at zero). The sequencer's ordering rule is a
continuous invariant, not a sampled check.

## Running

```
make -C src pd   SIM=vcs
make -C src lpdq SIM=vcs
```

- `qchannel_pd_tb` passes with `RESULT: PASS` only if there are no testbench
  errors and both channel monitors report zero violations; `qchannel_lpd_tb`
  prints `RESULT: PASS` with zero errors. The make targets return 0 whatever
  the result: read the line.
- Neither target is in the VCS regression, and neither has a VCS log in the
  build tree. The count in `rtl/qchannel/README.md` (79 checks for `pd`) is an
  Icarus run. `pa` (P7 under `upf/qchannel_pd_tb.upf`) needs Xcelium. The
  Vivado targets `xsim-pd` and `xsim-diff` were removed on 2026-10-06.
- `lpdq` is not in the Makefile's `.PHONY` list or its header comment.

## Probes

`clk_gated` reads the clock gate's enable latch, which is in the switched
domain `PD_DEV`; it is compared against 1 so that X under power intent reads as
"gated" (the comment at its declaration and `upf/README.md` explain why). Do
not add other reads inside `PD_DEV`.

## Adding a test

`qchannel_pd_tb`: add a phase with its `========== ... ==========` banner (the
phase name is also `test_phase` in the waveform), drive on the negedge, and add
a row to `TEST_MATRIX.md`. `qchannel_lpd_tb`: add a
`section("L<n> <title>")` that names the PCK-600 sentence it checks, with
`ck()` calls.

## References

- AMBA Low Power Interface Specification, ARM IHI 0068C, Sections 2.1, 3.1.
- Arm CoreLink PCK-600 TRM (101150), Section 3.1 and Table A-1.
- [`src/rtl/qchannel/README.md`](../../rtl/qchannel/README.md),
  [`TEST_MATRIX.md`](TEST_MATRIX.md), [`src/upf/README.md`](../../upf/README.md).
- Formal: [`src/formal/qchannel/`](../../formal/qchannel/README.md) proves the
  controller and device FSMs against the same handshake rules.
