# Q-Channel testbench — control-signal matrix

Which DUT control inputs each phase of
[`qchannel_pd_tb.sv`](qchannel_pd_tb.sv) drives, and what that combination is
meant to prove. Phase names match the `test_phase` signal in the waveform and
the `========== ... ==========` banners in the log.

DUT is [`qchannel_pd_top`](../../rtl/qchannel/qchannel_pd_top.sv). See
[the Q-Channel README](../../rtl/qchannel/README.md) for the protocol itself.

## The two knobs that decide the outcome

Everything interesting in this testbench comes from how `deny_enb` and
`light_work` interact with the workload's `busy`. The DUT wires them like this:

```systemverilog
.dev_quiescent_busy(busy)
.dev_quiescent_deny(deny_enb && busy)
```

and the device FSM resolves a request in `Q_REQUEST` as:

```
if      (dev_quiescent_deny)   -> Q_DENIED      // refuse outright
else if (!dev_quiescent_busy)  -> Q_STOPPED     // accept
else                            stay in Q_REQUEST  // wait for idle
```

So **denial is gated on `busy`**, and `light_work` is what decides whether `busy`
ever asserts. That gives four meaningful combinations:

| `deny_enb` | `light_work` | `busy` at request | Device response | Phase |
|:---:|:---:|:---:|---|---|
| 1 | 0 | 1 | **`Q_DENIED`** — refuses outright, stays operational, clock stays on | P4 |
| 1 | 0 | 0 | Accepts immediately → `Q_STOPPED`, clock gates | P2, P3 |
| 1 | 1 | 0 | Accepts immediately **mid-burst** — light work never raises `busy`, so the burst simply freezes | P5 |
| 0 | 0 | 1 | **Holds in `Q_REQUEST`** until the burst drains, *then* accepts. No denial, but no immediate gating either | P6 |

Two combinations are not separately exercised, and deliberately so:

* `deny_enb=0, light_work=0, busy=0` — identical to row 2. With `busy` LOW,
  `dev_quiescent_deny` is LOW regardless of `deny_enb`.
* `deny_enb=0, light_work=1` — identical to row 3, for the same reason: light
  work never raises `busy`, so `deny_enb` cannot affect the outcome. P5 covers
  the behaviour with `deny_enb=1`; flipping it changes nothing.

## The two exit paths

`Q_STOPPED` can be left two different ways, and they are different terms in the
controller's `Q_STOPPED` arm. Each has exactly one phase:

| Exit trigger | Phase | Controller term |
|---|---|---|
| `pd_req` withdrawn | P2 | `!req_dev_quiescence` |
| `QACTIVE` raised with `pd_req` **still asserted** | P3 (also P4, P5, P6 as teardown) | `enb_qactive_led_quiescence_exit && qactive` |

Both require the device to be **powered**. Once the domain's supply is removed
the second path is gone entirely — `QACTIVE` is a device output — and only an
always-on signal can bring it back. P7 measures that; see the notes at the end.

## Per-phase matrix

`—` means the phase does not touch that signal (it holds the value shown for the
preceding phase). `aon_rst_n` is driven only in P0. The power-control signals
`pwr_req` / `dev_rst_req` are driven in P0 (boot release) and P7 (power
shutoff); every phase in between leaves them at 0, so P1–P6 exercise the
**clock-control** channel alone and are omitted from those rows.

| Phase | `pd_req` | `work_len` | `light_work` | `deny_enb` | `wake` | What it proves |
|---|:---:|:---:|:---:|:---:|:---:|---|
| **P0** Reset and Bring-Up | 0 | 0 | 0 | 1 | 0 | AON released first, then `pwr_req` and `dev_rst_req` withdrawn together. Reaches `Q_RUN`; workload clock enabled and toggling. |
| **P1** Regular Work Burst | 0 | 10 | 0 | 1 | 0 | `start` pulse raises `busy`; `work_count` decrements; burst then drained so the next phase starts genuinely idle. |
| **P2** Idle-Path Clock Gating | **0→1→0** | — | 0 | 1 | 0 | Requesting quiesce while *already idle* gates immediately, with no `Q_REQUEST` dwell and no denial. Exits by **withdrawing `pd_req`**. |
| **P3** Sustained Power Savings | **0→1→0** | 8 | 0 | 1 | **0→1→0** | Holds `Q_STOPPED` for 20 device cycles: **0 gated-clock edges**, no state drift. Exits via **`QACTIVE` with `pd_req` still asserted** — the §2.1.3 anti-deadlock policy — and the clock resumes. |
| **P4** Q_DENIED/Q_CONTINUE Recovery | **0→1→0** | 12 | 0 | **1** | **0→1→0** | Denied mid-burst with the **clock still running**; `pd_req` held; the device **auto-recovers to `Q_STOPPED`** once the burst drains, without the controller re-requesting. Its setup burst also doubles as the post-gate functional check. |
| **P5** Light Work Hang | **0→1→0** | 20 | **1** | 1 | **0→1→0** | Light work never raises `busy`, so the request is accepted **mid-countdown**. `work_count` is captured, held 10 gated cycles, and proven **frozen** — then it **resumes rather than restarts** and reaches 0. |
| **P6** Deny Disabled | **0→1→0** | 30 | 0 | **0** | **0→1→0** | With denial disabled the device **does not refuse** — but it also does not gate immediately: it holds in `Q_REQUEST` until the burst drains (~21 device cycles here), then accepts. |
| **P7** Power Shutoff and Restore | **0→1→0** | 25, then 6 | 0 | 1 | **0→1→0** (no effect) | Also drives `pwr_req` **0→1→0** and `dev_rst_req` **0→1→0**. Asserting `dev_rst_req` mid-burst is **refused by the interlock**; the supply drops only once *both* channels reach `Q_STOPPED`; the device outputs hold the `Q_STOPPED` encoding while down; a fresh burst runs after restore. Exercises the UPF power intent — see [`src/upf/README.md`](../../upf/README.md). |

`light_work` is asserted only across P5's `start` pulse and dropped immediately
after; the workload latches the mode at `start`, so it applies for that burst
only. `deny_enb` is restored to 1 at the end of P6.

### Phases removed as redundant

An earlier revision ran eleven phases. Four were dropped because each re-ran a
sequence P4 already performs end to end, with fewer checks:

| Removed | Was | Now covered by |
|---|---|---|
| old P2 | deny while busy | P4 (`denied`, `busy` during `Q_DENIED`, clock still ON) |
| old P3 | accept after drain → gate → zero edges | P4 (`stopped`, `clock gated after recovery`) + P3 (20-cycle zero-edge hold) |
| old P4 | `QACTIVE` wake exit | P3 (`exit-on-qactive` with the `pd_req` still-asserted check) |
| old P5 | fresh burst after gate/ungate | P4's own setup burst, which starts after P3's wake and runs to completion |

The two checks that were genuinely unique to the removed phases — "clock still
ON during a denial" and "`QACTIVE`, not a withdrawn request, caused this exit" —
were moved into P4 and P3 respectively rather than dropped.

## Notes on P6 (Deny Disabled)

The phase name reads as if the device gates the clock the moment the request
arrives. It does not, and the waveform shows it clearly — the request goes out
while the burst is still draining, and `Q_STOPPED` only arrives ~21 device
cycles later, once `busy` falls.

`deny_enb=0` removes the *denial*, not the *wait*. The device sits in
`Q_REQUEST` — operational, clock running — until `busy` falls, which is exactly
row 4 of the matrix above and the behaviour the spec calls "requested to become
quiescent when idle".

The assertion covering this is also weaker than it looks:

```systemverilog
check(busy_at_stopped == 1'b1 || work_count < 30, "P6: device accepts quiesce when deny disabled ...");
```

By the time `Q_STOPPED` is reached the burst has finished, so `busy_at_stopped`
is 0 and `work_count` is 0 — the second term passes unconditionally. The check
would still pass if the device had denied and recovered exactly like P4. Making
P6 distinguish itself from P4 needs a check that the interface **never entered
`Q_DENIED`**, which nothing currently asserts.

## Notes on P7 (Power Shutoff and Restore)

P7 is the only phase that drives the **power-control** channel. P1–P6 all leave
`pwr_req` and `dev_rst_req` at 0 and negotiate over `pd_req` alone, so
everything they prove is about removing the *clock*. PCSA §8.2.1 keeps those
negotiations separate precisely because they actuate different resources, and
the two have opposite effects on state:

| | Actuator | Workload state |
|---|---|---|
| P5 — clock gating | `clk_gate` | **Frozen**, resumes mid-countdown |
| P7 — power gating | `qchannel_devrst_ctrl` → `drst_n` | **Lost**, re-initialises from reset |

Reading P5 and P7 next to each other is the clearest statement of what the two
channels are for. The `wake` column says the same thing from the other side: in
P3 and P5 `wake` revives the domain, because a clock-gated device is still
powered and can raise `QACTIVE`. In P7 it does nothing at all — P7 holds `wake`
high for ten device cycles while the domain is down and checks that `QACTIVE`
stays low, no clock edges appear, and the interface stays in `Q_STOPPED`.

The mechanism is the reset, not the power. `QACTIVE` is driven by the device
*wrapper*, and `qchannel_device` drives `qacceptn`/`qdeny`/`qactive` to 0
unconditionally while `rst_n` is low — so `drst_n` alone is enough to make the
interface read `Q_STOPPED` and ignore `dev_wake`. The UPF in [`src/upf`](../../upf/)
keeps both wrappers **always-on** for exactly this reason: the `Q_STOPPED`
encoding is then held by real flip-flops rather than imitated by isolation
clamps that have to independently match the RTL's reset values. Revival comes
from `dev_rst_req`, an always-on port — consistent with PCSA §8.3.4, which puts
wake signalling for a powered-down domain outside it.

The catch worth knowing about: `qchannel_pd_top` routes the top-level `wake`
port into `dev_wake` on both wrappers, and those are reset by `drst_n`, so any
PM policy layered on this must carry its own wake input rather than relying on
`QACTIVE`.

P7 requests quiesce on **both** channels before asserting `dev_rst_req`, which
is what a real power-down policy does. Requesting only the power channel would
reset `u_dev_clk` while its own interface was still in `Q_RUN` — legal-looking
in this RTL, since the two wrappers share `drst_n`, but a violation of §2.1.2
for the clock interface, and monitor rule R8 would catch it.

The phase's checks pass under plain RTL simulation *and* under power-aware
simulation, for different reasons in each: plain simulation holds the device in
reset with `QACCEPTn`/`QDENY` low, while power-aware simulation clamps them low
through the isolation cells. That the two agree is PCSA §8.3.4's
reset-state-equals-quiescent-state equivalence, and it is the reason the UPF
carries no retention strategy.
