`timescale 1ns/1ps
// qchannel_lpd (LPD-Q), checked against PCK-600 Section 3.1 and Table A-1.
//
// Every group below names the sentence it is checking. The four rules of
// Section 3.1 are:
//
//   ACCEPT    "The LPD-Q accepts a controller quiescence request, if all
//             devices indicate acceptance of the quiescence request by setting
//             dev_qacceptn_i<X> LOW."
//   DENY      "A dev_qdeny_i<X> asserts, in response to the assertion of
//             dev_qreqn_o<X>." / "A dev_qactive_i<X> goes HIGH, between the
//             assertion of all dev_qreqn_o<X> signals and the assertion of the
//             last dev_qacceptn_i<X> ... when ACTIVE_DENY ... is set to 1."
//   ACTIVITY  "The ctrl_qactive_o output is the logical OR of the multiple
//             device inputs ... a combinatorial path."
//   CLOCK     the four clk_qactive_o bullets.
//
// The DEVICES are real qchannel_device instances, not behavioural stubs, so
// the handshakes the LPD-Q sees are the ones a real device produces. Every
// channel additionally carries a qchannel_monitor, so a protocol violation on
// any of them fails the run independently of what the directed checks look at.

import qchannel_pkg::*;

module qchannel_lpd_tb;

  localparam int unsigned N = 4;   // channels on the two main DUTs

  logic clk = 1'b0;
  logic reset_n = 1'b0;
  always #5 clk = ~clk;

  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  task automatic settle(); repeat (60) @(posedge clk); endtask

  // ===========================================================================
  // DUT A -- expander,  DUT B -- sequencer,  DUT C -- minimum config
  // ===========================================================================
  logic             a_ctrl_qreqn = 1'b1, b_ctrl_qreqn = 1'b1, c_ctrl_qreqn = 1'b1;
  logic             a_ctrl_qacceptn, a_ctrl_qdeny, a_ctrl_qactive, a_clk_qactive;
  logic             b_ctrl_qacceptn, b_ctrl_qdeny, b_ctrl_qactive, b_clk_qactive;
  logic             c_ctrl_qacceptn, c_ctrl_qdeny, c_ctrl_qactive, c_clk_qactive;

  logic [N-1:0]     a_qreqn, a_qacceptn, a_qdeny, a_qactive;
  logic [N-1:0]     b_qreqn, b_qacceptn, b_qdeny, b_qactive;
  logic [1:0]       c_qreqn, c_qacceptn, c_qdeny, c_qactive;

  // Device stimulus: per channel, per DUT.
  logic [N-1:0]     a_busy = '0, a_deny = '0, a_wake = '0;
  logic [N-1:0]     b_busy = '0, b_deny = '0, b_wake = '0;
  logic [1:0]       c_busy = '0, c_deny = '0, c_wake = '0;
  logic             a_dft = 1'b0;

  // ---- DUT D: ACTIVE_DENY, the second denial condition ----
  // Implemented from the first commit and NOT exercised by any DUT until the
  // spec cross-check noticed. Section 3.1's second bullet only happens when
  // ACTIVE_DENY == 1, so it needs its own instance.
  logic         d_ctrl_qreqn = 1'b1;
  logic         d_ctrl_qacceptn, d_ctrl_qdeny, d_ctrl_qactive, d_clk_qactive;
  logic [N-1:0] d_qreqn, d_qacceptn, d_qdeny, d_qactive;
  logic [N-1:0] d_busy = '0, d_deny = '0, d_wake = '0;

  qchannel_lpd #(.NUM_QCHL(N), .SEQUENCER(1'b0),
                 .ACTIVE_DENY(1'b1), .DEV_QACTIVE_SYNC(1'b1))
    u_d (.clk(clk), .reset_n(reset_n),
         .ctrl_qreqn_i(d_ctrl_qreqn), .ctrl_qacceptn_o(d_ctrl_qacceptn),
         .ctrl_qdeny_o(d_ctrl_qdeny), .ctrl_qactive_o(d_ctrl_qactive),
         .dev_qreqn_o(d_qreqn), .dev_qacceptn_i(d_qacceptn),
         .dev_qdeny_i(d_qdeny), .dev_qactive_i(d_qactive),
         .clk_qactive_o(d_clk_qactive), .dftcgen(1'b0));

  // ---- DUT E: NUM_QCHL at the Table 3-1 maximum ----
  // Elaboration-only. 32 is the documented ceiling and the counter width,
  // $clog2(NUM_QCHL+1), is where an off-by-one would show.
  logic [31:0] e_qreqn, e_qacceptn = '1, e_qdeny = '0, e_qactive = '0;
  logic        e_ctrl_qacceptn, e_ctrl_qdeny, e_ctrl_qactive, e_clk_qactive;
  qchannel_lpd #(.NUM_QCHL(32), .SEQUENCER(1'b1))
    u_e (.clk(clk), .reset_n(reset_n),
         .ctrl_qreqn_i(1'b1), .ctrl_qacceptn_o(e_ctrl_qacceptn),
         .ctrl_qdeny_o(e_ctrl_qdeny), .ctrl_qactive_o(e_ctrl_qactive),
         .dev_qreqn_o(e_qreqn), .dev_qacceptn_i(e_qacceptn),
         .dev_qdeny_i(e_qdeny), .dev_qactive_i(e_qactive),
         .clk_qactive_o(e_clk_qactive), .dftcgen(1'b0));

  qchannel_lpd #(.NUM_QCHL(N), .SEQUENCER(1'b0), .ACTIVE_DENY(1'b0))
    u_a (.clk(clk), .reset_n(reset_n),
         .ctrl_qreqn_i(a_ctrl_qreqn), .ctrl_qacceptn_o(a_ctrl_qacceptn),
         .ctrl_qdeny_o(a_ctrl_qdeny), .ctrl_qactive_o(a_ctrl_qactive),
         .dev_qreqn_o(a_qreqn), .dev_qacceptn_i(a_qacceptn),
         .dev_qdeny_i(a_qdeny), .dev_qactive_i(a_qactive),
         .clk_qactive_o(a_clk_qactive), .dftcgen(a_dft));

  qchannel_lpd #(.NUM_QCHL(N), .SEQUENCER(1'b1), .ACTIVE_DENY(1'b0))
    u_b (.clk(clk), .reset_n(reset_n),
         .ctrl_qreqn_i(b_ctrl_qreqn), .ctrl_qacceptn_o(b_ctrl_qacceptn),
         .ctrl_qdeny_o(b_ctrl_qdeny), .ctrl_qactive_o(b_ctrl_qactive),
         .dev_qreqn_o(b_qreqn), .dev_qacceptn_i(b_qacceptn),
         .dev_qdeny_i(b_qdeny), .dev_qactive_i(b_qactive),
         .clk_qactive_o(b_clk_qactive), .dftcgen(1'b0));

  // Minimum legal configuration, and the only one with synchronizers removed:
  // proves the STAGES=0 passthrough path elaborates and handshakes.
  qchannel_lpd #(.NUM_QCHL(2), .SEQUENCER(1'b1), .ACTIVE_DENY(1'b0),
                 .CTRL_Q_CH_SYNC(1'b0), .DEV_Q_CH_SYNC(1'b0))
    u_c (.clk(clk), .reset_n(reset_n),
         .ctrl_qreqn_i(c_ctrl_qreqn), .ctrl_qacceptn_o(c_ctrl_qacceptn),
         .ctrl_qdeny_o(c_ctrl_qdeny), .ctrl_qactive_o(c_ctrl_qactive),
         .dev_qreqn_o(c_qreqn), .dev_qacceptn_i(c_qacceptn),
         .dev_qdeny_i(c_qdeny), .dev_qactive_i(c_qactive),
         .clk_qactive_o(c_clk_qactive), .dftcgen(1'b0));

  int unsigned a_viol [N];
  int unsigned b_viol [N];

  // ---- real devices on every channel ----
  generate
    for (genvar i = 0; i < N; i++) begin : g_a_dev
      qchannel_device #(.SYNC_STAGES(2)) u_d (
        .clk(clk), .rst_n(reset_n),
        .qreqn(a_qreqn[i]), .qacceptn(a_qacceptn[i]),
        .qdeny(a_qdeny[i]), .qactive(a_qactive[i]),
        .dev_quiescent_busy(a_busy[i]), .dev_quiescent_deny(a_deny[i]),
        .dev_wake(a_wake[i]), .dev_quiescent_ok());
      qchannel_monitor u_m (
        .clk(clk), .rst_n(reset_n), .crst_n(reset_n), .drst_n(reset_n),
        .clk_gated(1'b0), .qreqn(a_qreqn[i]), .qacceptn(a_qacceptn[i]),
        .qdeny(a_qdeny[i]), .violations(a_viol[i]));
    end
    for (genvar i = 0; i < N; i++) begin : g_b_dev
      qchannel_device #(.SYNC_STAGES(2)) u_d (
        .clk(clk), .rst_n(reset_n),
        .qreqn(b_qreqn[i]), .qacceptn(b_qacceptn[i]),
        .qdeny(b_qdeny[i]), .qactive(b_qactive[i]),
        .dev_quiescent_busy(b_busy[i]), .dev_quiescent_deny(b_deny[i]),
        .dev_wake(b_wake[i]), .dev_quiescent_ok());
      qchannel_monitor u_m (
        .clk(clk), .rst_n(reset_n), .crst_n(reset_n), .drst_n(reset_n),
        .clk_gated(1'b0), .qreqn(b_qreqn[i]), .qacceptn(b_qacceptn[i]),
        .qdeny(b_qdeny[i]), .violations(b_viol[i]));
    end
    for (genvar i = 0; i < N; i++) begin : g_d_dev
      qchannel_device #(.SYNC_STAGES(2)) u_d (
        .clk(clk), .rst_n(reset_n),
        .qreqn(d_qreqn[i]), .qacceptn(d_qacceptn[i]),
        .qdeny(d_qdeny[i]), .qactive(d_qactive[i]),
        .dev_quiescent_busy(d_busy[i]), .dev_quiescent_deny(d_deny[i]),
        .dev_wake(d_wake[i]), .dev_quiescent_ok());
    end
    for (genvar i = 0; i < 2; i++) begin : g_c_dev
      qchannel_device #(.SYNC_STAGES(2)) u_d (
        .clk(clk), .rst_n(reset_n),
        .qreqn(c_qreqn[i]), .qacceptn(c_qacceptn[i]),
        .qdeny(c_qdeny[i]), .qactive(c_qactive[i]),
        .dev_quiescent_busy(c_busy[i]), .dev_quiescent_deny(c_deny[i]),
        .dev_wake(c_wake[i]), .dev_quiescent_ok());
    end
  endgenerate

  // Monitors on the two control channels too -- the LPD-Q is a device there and
  // must obey the same protocol it enforces below.
  int unsigned a_viol_ctrl, b_viol_ctrl;
  qchannel_monitor u_m_actrl (
    .clk(clk), .rst_n(reset_n), .crst_n(reset_n), .drst_n(reset_n),
    .clk_gated(1'b0), .qreqn(a_ctrl_qreqn), .qacceptn(a_ctrl_qacceptn),
    .qdeny(a_ctrl_qdeny), .violations(a_viol_ctrl));
  qchannel_monitor u_m_bctrl (
    .clk(clk), .rst_n(reset_n), .crst_n(reset_n), .drst_n(reset_n),
    .clk_gated(1'b0), .qreqn(b_ctrl_qreqn), .qacceptn(b_ctrl_qacceptn),
    .qdeny(b_ctrl_qdeny), .violations(b_viol_ctrl));

  // ===========================================================================
  // THE CONTINUOUS INVARIANT: sequencer ordering
  //
  // Section 3.1.2: "The LPD-Q waits for the response from each device before
  // sending a quiescence request to the next device."
  //
  // Watched every cycle rather than sampled, because the failure it catches is
  // a momentary overlap: channel k+1 asked while channel k has not yet
  // responded. A directed check that looks only at settled state cannot see it.
  // ===========================================================================
  // A denial is TRANSIENT by design: the LPD-Q withdraws the request, which
  // walks the device Q_DENIED -> Q_CONTINUE -> Q_RUN and clears QDENY. Sampling
  // it after settle() therefore sees nothing, so it is latched.
  logic [N-1:0] b_saw_deny = '0, a_saw_deny = '0;
  always @(posedge clk) if (reset_n) begin
    b_saw_deny <= b_saw_deny | b_qdeny;
    a_saw_deny <= a_saw_deny | a_qdeny;
  end

  // The invariant is EDGE-triggered, and the first version was not.
  //
  // Written as a level check -- "while the control request is asserted, channel
  // k+1 must not be requested unless k has responded" -- it fired four times on
  // correct behaviour. After the L7 denial the control channel goes to
  // Q_DENIED, so the LPD-Q begins releasing devices while ctrl_qreqn is still
  // LOW at the testbench. Channel 0 is legitimately walked back to Q_RUN, its
  // QACCEPTn returns HIGH, and the level check reads that as "channel 0 has not
  // responded" while channel 1 is still held.
  //
  // What the rule actually says (Section 3.1.2) is about the MOMENT a new
  // request is issued: "The LPD-Q waits for the response from each device
  // before sending a quiescence request to the next device." So the check is on
  // the falling edge of dev_qreqn_o[k+1] -- the instant channel k+1 is asked,
  // channel k must already have accepted or denied. That is immune to whatever
  // the levels do afterwards.
  int unsigned order_viol = 0;
  logic [N-1:0] b_qreqn_d;
  always @(posedge clk) b_qreqn_d <= b_qreqn;

  always @(posedge clk) begin
    if (reset_n) begin
      for (int k = 0; k < N-1; k++) begin
        // channel k+1 just asked (QREQn fell) ...
        if (b_qreqn_d[k+1] == 1'b1 && b_qreqn[k+1] == 1'b0) begin
          // ... while channel k had neither accepted nor denied.
          if (b_qacceptn[k] == 1'b1 && b_qdeny[k] == 1'b0) begin
            order_viol++;
            $display("[%0t] ORDER-VIOLATION: ch%0d asked before ch%0d responded",
                     $time, k+1, k);
          end
        end
      end
    end
  end

  // ===========================================================================
  task automatic quiesce_bench();
    begin
      a_ctrl_qreqn = 1'b1; b_ctrl_qreqn = 1'b1; c_ctrl_qreqn = 1'b1;
      a_busy = '0; a_deny = '0; a_wake = '0;
      b_busy = '0; b_deny = '0; b_wake = '0;
      c_busy = '0; c_deny = '0; c_wake = '0;
      settle();
    end
  endtask

  int t0;

  initial begin
    $dumpfile("qchannel_lpd_tb.vcd");
    $dumpvars(0, qchannel_lpd_tb);
    $display("==============================================================");
    $display(" qchannel_lpd_tb -- LPD-Q against PCK-600 Section 3.1");
    $display("==============================================================");

    repeat (5) @(posedge clk);
    reset_n = 1'b1;
    settle();

    // ---- L1: reset state ----
    section("L1 reset");
    ck(a_qreqn == '1, "L1 expander: no device requested out of reset");
    ck(b_qreqn == '1, "L1 sequencer: no device requested out of reset");
    ck(a_ctrl_qacceptn == 1'b1, "L1 control QACCEPTn HIGH out of reset");
    ck(a_ctrl_qdeny    == 1'b0, "L1 control QDENY LOW out of reset");

    // ---- L2: expander broadcast, all accept ----
    // "sends the request to all the device Q-Channels" / "waits for all devices
    // to accept ... before it generates the response to the controller"
    section("L2 expander entry");
    a_ctrl_qreqn = 1'b0;
    // Each channel now has its own qchannel_controller, so QREQn falls a few
    // cycles after the control request -- control-side synchronizer, then the
    // per-channel FSM. What "together" means is that they fall on the SAME
    // cycle as each other, which is checked on the edge rather than by waiting
    // a fixed number of cycles and hoping.
    @(negedge a_qreqn[0]);
    ck(a_qreqn == '0, "L2 all four devices requested on the same cycle");
    settle();
    ck(a_qacceptn == '0,       "L2 all four devices accepted");
    ck(a_ctrl_qacceptn == 1'b0, "L2 control QACCEPTn LOW once all accepted");
    ck(a_ctrl_qdeny    == 1'b0, "L2 no denial");

    // ---- L3: the accept is HELD until the LAST device accepts ----
    section("L3 expander accept is held");
    quiesce_bench();
    a_busy[2] = 1'b1;                 // device 2 will not accept yet
    a_ctrl_qreqn = 1'b0;
    settle();
    ck(a_qacceptn[0] == 1'b0 && a_qacceptn[1] == 1'b0 && a_qacceptn[3] == 1'b0,
       "L3 the other three accepted");
    ck(a_qacceptn[2] == 1'b1,   "L3 device 2 has not accepted");
    ck(a_ctrl_qacceptn == 1'b1, "L3 control accept WITHHELD -- the ACCEPT rule");
    a_busy[2] = 1'b0;
    settle();
    ck(a_ctrl_qacceptn == 1'b0, "L3 control accepts once the last device does");

    // ---- L4: expander denial ----
    section("L4 expander denial");
    quiesce_bench();
    a_saw_deny = '0;
    a_deny[1] = 1'b1;
    a_ctrl_qreqn = 1'b0;
    settle();
    ck(a_saw_deny[1] == 1'b1,   "L4 device 1 denied");
    ck(a_ctrl_qdeny == 1'b1,    "L4 control QDENY HIGH -- the DENY rule");
    ck(a_ctrl_qacceptn == 1'b1, "L4 control did NOT accept");
    a_ctrl_qreqn = 1'b1;        // controller walks Q_DENIED -> Q_CONTINUE -> Q_RUN
    a_deny[1] = 1'b0;
    settle();
    ck(a_ctrl_qdeny == 1'b0,    "L4 denial cleared after the request withdrew");

    // ---- L5: sequencer ordering, the headline ----
    section("L5 sequencer ordering");
    quiesce_bench();
    b_busy = '1;                       // every device stalls until released
    b_ctrl_qreqn = 1'b0;
    repeat (6) @(posedge clk);
    ck(b_qreqn[0] == 1'b0, "L5 channel 0 asked first");
    ck(b_qreqn[1] == 1'b1 && b_qreqn[2] == 1'b1 && b_qreqn[3] == 1'b1,
       "L5 channels 1-3 NOT asked while 0 is outstanding");
    b_busy[0] = 1'b0;                  // release device 0
    settle();
    ck(b_qacceptn[0] == 1'b0, "L5 channel 0 accepted");
    ck(b_qreqn[1] == 1'b0,    "L5 channel 1 asked only after 0 responded");
    ck(b_qreqn[2] == 1'b1 && b_qreqn[3] == 1'b1, "L5 channels 2-3 still untouched");
    b_busy[1] = 1'b0; settle();
    ck(b_qreqn[2] == 1'b0, "L5 channel 2 asked after 1 responded");
    b_busy[2] = 1'b0; settle();
    ck(b_qreqn[3] == 1'b0, "L5 channel 3 asked after 2 responded");
    b_busy[3] = 1'b0; settle();
    ck(b_qacceptn == '0,        "L5 all four accepted");
    ck(b_ctrl_qacceptn == 1'b0, "L5 control accepts only at the end of the walk");

    // ---- L6: sequencer exit ----
    section("L6 sequencer exit");
    b_ctrl_qreqn = 1'b1;
    settle();
    ck(b_qreqn == '1,           "L6 every device released");
    ck(b_qacceptn == '1,        "L6 every device back in Q_RUN");
    ck(b_ctrl_qacceptn == 1'b1, "L6 control back in Q_RUN");

    // ---- L7: a denial stops the walk ----
    // INTERPRETATION 2 in the module header: the transition is off, so the
    // devices beyond the denier are never asked.
    section("L7 sequencer denial stops the walk");
    quiesce_bench();
    b_saw_deny = '0;
    b_deny[1] = 1'b1;
    b_ctrl_qreqn = 1'b0;
    settle();
    ck(b_saw_deny[1] == 1'b1, "L7 channel 1 denied");
    ck(b_ctrl_qdeny == 1'b1, "L7 control QDENY HIGH");
    ck(b_qreqn[2] == 1'b1 && b_qreqn[3] == 1'b1,
       "L7 channels 2-3 were NEVER asked after the denial");
    b_ctrl_qreqn = 1'b1; b_deny[1] = 1'b0;
    settle();

    // ---- L8: ACTIVITY -- combinational OR ----
    section("L8 ctrl_qactive_o");
    quiesce_bench();
    ck(a_ctrl_qactive == 1'b0, "L8 quiet: control QACTIVE LOW");
    a_wake[3] = 1'b1;
    settle();
    ck(a_ctrl_qactive == 1'b1, "L8 one device active -> control QACTIVE HIGH");
    a_wake[3] = 1'b0;
    settle();
    ck(a_ctrl_qactive == 1'b0, "L8 activity withdrawn -> LOW again");

    // The path must be COMBINATIONAL (Section 3.1). Checked with zero clock
    // edges between the device output changing and the control output
    // following, which a registered path cannot pass.
    section("L9 QACTIVE is combinational");
    quiesce_bench();
    @(negedge clk);
    a_wake[0] = 1'b1;
    #0;
    ck(a_qactive[0] == 1'b0, "L9 device QACTIVE is registered (rises on a clock edge)");
    settle();
    a_wake[0] = 1'b0; settle();
    // Drive the LPD's dev_qactive_i directly to isolate its own path.
    force a_qactive[1] = 1'b1;
    #1;
    ck(a_ctrl_qactive == 1'b1, "L9 ctrl_qactive_o followed with ZERO clock edges");
    release a_qactive[1];
    settle();

    // ---- L10: clk_qactive_o ----
    // Four bullets of Section 3.1. Checked for the two that are reachable
    // without forcing: a control handshake in flight, and a device mismatch.
    section("L10 clk_qactive_o");
    quiesce_bench();
    ck(a_clk_qactive == 1'b0, "L10 idle: no handshake in flight, LOW");
    a_busy = '1;
    a_ctrl_qreqn = 1'b0;
    repeat (3) @(posedge clk);
    ck(a_clk_qactive == 1'b1, "L10 handshake in flight -> HIGH");
    a_busy = '0;
    settle();
    ck(a_clk_qactive == 1'b0, "L10 handshake settled -> LOW");
    a_ctrl_qreqn = 1'b1; settle();

    // ---- L14: ACTIVE_DENY, Section 3.1's second denial condition ----
    // "A dev_qactive_i<X> goes HIGH, between the assertion of all dev_qreqn_o<X>
    // signals and the assertion of the last dev_qacceptn_i<X>."
    //
    // The entry is held open by FORCING one device's QACCEPTn HIGH rather than
    // by asserting dev_quiescent_busy. qchannel_device drives
    // "qactive <= dev_quiescent_busy | dev_wake", so busy IS activity -- using
    // it here denied the request before the test had injected anything, which
    // is what the first version of this group did.
    //
    // DUT D carries no qchannel_monitor, which is why the forces live here.
    section("L14 ACTIVE_DENY");
    force d_qacceptn[0] = 1'b1;          // device 0 never accepts: entry stays open
    d_ctrl_qreqn = 1'b0;
    repeat (12) @(posedge clk);
    ck(d_ctrl_qdeny == 1'b0, "L14 entry open, no activity: no denial");
    force d_qactive[2] = 1'b1;           // activity INSIDE the window
    settle();
    ck(d_ctrl_qdeny == 1'b1, "L14 activity mid-entry denied the request");
    release d_qactive[2];
    release d_qacceptn[0];
    d_ctrl_qreqn = 1'b1;
    settle();
    ck(d_ctrl_qdeny == 1'b0, "L14 denial cleared once the request withdrew");

    // Outside the window it must NOT deny. Section 3.1 bounds the window
    // "between the assertion of all dev_qreqn_o<X> signals and the assertion of
    // the last dev_qacceptn_i<X>" -- once every device has accepted, the entry
    // is over and activity is the controller's business, not a denial.
    //
    // Checked on the DEVICES, not on ctrl_qdeny_o, and that distinction is what
    // makes the check real. Dropping the entry_in_flight guard from the RTL
    // leaves ctrl_qdeny_o at 0 either way -- qchannel_device_comb will not deny
    // from a state that has already accepted -- so a check on the control pin
    // alone passes against broken RTL. Measured: that mutation survived until
    // this group looked at dev_qreqn_o instead.
    //
    // What it actually breaks is the request vector: any_denied also clears
    // dev_req, so activity after a completed entry would RELEASE every device
    // and wake the domain with nobody having asked.
    force d_qacceptn[0] = 1'b0;   // let the entry complete this time
    d_ctrl_qreqn = 1'b0;
    settle();
    release d_qacceptn[0];
    settle();
    ck(d_qacceptn == '0,        "L14 entry completed, all devices in Q_STOPPED");
    ck(d_ctrl_qacceptn == 1'b0, "L14 control accepted");
    force d_qactive[2] = 1'b1;
    settle();
    ck(d_qreqn == '0,           "L14 activity AFTER the window leaves the devices held");
    ck(d_ctrl_qdeny == 1'b0,    "L14 and does not deny");
    ck(d_ctrl_qactive == 1'b1,  "L14 but it does raise ctrl_qactive_o");
    release d_qactive[2];
    d_ctrl_qreqn = 1'b1;
    settle();

    // ---- L15: clk_qactive_o, the two bullets L10 could not reach ----
    section("L15 clk_qactive_o bullets 2 and 4");
    ck(d_clk_qactive == 1'b0, "L15 quiet baseline");
    force d_qdeny[2] = 1'b1;             // bullet 2: "any dev_qdeny_i<X> is HIGH"
    #1;
    ck(d_clk_qactive == 1'b1, "L15 bullet 2: a device QDENY raises it");
    release d_qdeny[2];
    settle();
    force u_d.ctrl_qdeny_o = 1'b1;       // bullet 4: "ctrl_qdeny_o is HIGH"
    #1;
    ck(d_clk_qactive == 1'b1, "L15 bullet 4: control QDENY raises it");
    release u_d.ctrl_qdeny_o;
    settle();

    // ---- L16: dftcgen, Table A-5 ----
    // "ensures that the clk logic is active during DFT shift mode" -- it
    // overrides the four bullets rather than joining them.
    section("L16 dftcgen");
    ck(a_clk_qactive == 1'b0, "L16 idle before DFT");
    a_dft = 1'b1;
    #1;
    ck(a_clk_qactive == 1'b1, "L16 dftcgen holds the clock request HIGH");
    a_dft = 1'b0;
    settle();
    ck(a_clk_qactive == 1'b0, "L16 released");

    // ---- L17: NUM_QCHL = 32 ----
    section("L17 NUM_QCHL maximum");
    ck(e_qreqn !== 'x, "L17 a 32-channel instance elaborated and is driving");

    // ---- L11: minimum configuration ----
    section("L11 minimum config, synchronizers removed");
    c_ctrl_qreqn = 1'b0;
    settle();
    ck(c_qacceptn == '0,        "L11 both devices accepted");
    ck(c_ctrl_qacceptn == 1'b0, "L11 control accepted");
    c_ctrl_qreqn = 1'b1;
    settle();
    ck(c_ctrl_qacceptn == 1'b1, "L11 back to Q_RUN");

    // ---- L12: repeated cycles ----
    section("L12 repeated entry/exit");
    quiesce_bench();
    for (int r = 0; r < 4; r++) begin
      b_ctrl_qreqn = 1'b0; settle();
      if (b_ctrl_qacceptn != 1'b0) errors++;
      b_ctrl_qreqn = 1'b1; settle();
      if (b_ctrl_qacceptn != 1'b1) errors++;
    end
    ck(1'b1, "L12 four entry/exit cycles completed");

    // ---- L13: protocol monitors ----
    section("L13 protocol");
    begin
      int unsigned tot = a_viol_ctrl + b_viol_ctrl;
      for (int i = 0; i < N; i++) tot += a_viol[i] + b_viol[i];
      ck(tot == 0, $sformatf("L13 qchannel_monitor: %0d violation(s) across all 10 channels", tot));
    end
    ck(order_viol == 0,
       $sformatf("L13 sequencer ordering invariant: %0d violation(s)", order_viol));

    $display("");
    $display("==============================================================");
    $display(" qchannel_lpd_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (200000) @(posedge clk);
    $display(" RESULT: FAIL -- timeout");
    $finish;
  end

endmodule
