`timescale 1ns/1ps
// Byte-lane (write strobe) testbench.
//
// Section 6.2.1 makes the bus type IMPLEMENTATION DEFINED and shows an APB3
// example with no strobe, so this interface is an extension rather than
// something the specification mandates. That is exactly why it needs its own
// suite: nothing in Chapter 5 or 6 constrains it, so the only definition of
// correct is the one asserted here.
//
// WHY THE OTHER SIXTEEN SUITES CANNOT COVER THIS
//
// Every other testbench drives wstrb = 4'hF through its write task. That is
// deliberate -- it proves the addition is backward compatible -- but it also
// means all of them would keep passing if wstrb were ignored outright and the
// register file went back to writing whole words. A build with the strobe
// wired to nothing is an equivalent mutant as far as those suites can tell.
//
// So this file only ever writes with SOME lanes masked. Every check here fails
// if the strobe is dropped.
//
// THE CASE THAT MOTIVATES THE DESIGN
//
// Two registers have fields spread across byte lanes, and they are the two that
// are not plain read-write:
//
//   PPU_PWPR  PWR_POLICY [3:0] in lane 0, PWR_DYN_EN [8] and LOCK_EN [12] in
//             lane 1 -- and Section 4.1.1 admits or rejects the write as a
//             PAIR. A lane-0-only write must therefore be validated against the
//             PWR_DYN_EN the register already holds, not against the bits the
//             master left on wdata[8] in a lane it did not select. Group B4 is
//             that case, and it is the one an obvious implementation gets
//             wrong.
//
//   PPU_ISR   the four event bits in lane 0, PWR_ACTIVE_EDGE [8] in lane 1, and
//             the register is write-1-to-clear. A masked lane must clear
//             nothing there, which means the strobe has to reach the W1C term
//             rather than being resolved as a read-modify-write merge -- a
//             merge would feed the register's own set bits back in as clear
//             requests. Group B6.

module ppu_be_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  logic aon_clk = 1'b0, dclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;
  always #6.85 dclk    = ~dclk;

  logic        aon_rst_n = 1'b0;
  logic [11:0] reg_waddr  = 12'h000;
  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0]  reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;
  logic [31:0] reg_rdata;
  logic        irq;

  logic             start = 1'b0;
  logic [CNT_W-1:0] work_len = '0;
  logic             light_work = 1'b1;
  logic             wake = 1'b0;
  logic             deny_enb = 1'b0;

  ppu_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata), .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_ren(reg_ren), .reg_rdata(reg_rdata), .irq(irq),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(start), .work_len(work_len),
    .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0] pwr_status = u_top.u_dom.u_ppu.u_seq.pwr_status;

  int unsigned checks = 0, errors = 0;
  string       sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  logic [31:0] rd;
  task automatic rreg(input logic [11:0] a);
    begin
      @(negedge aon_clk); reg_raddr = a; reg_ren = 1'b1;
      @(negedge aon_clk); reg_ren = 1'b0;
      @(negedge aon_clk); rd = reg_rdata;
    end
  endtask

  // The only write task in this file, and it always takes a strobe. There is no
  // whole-word convenience wrapper on purpose: a check that accidentally used
  // one would silently stop testing anything.
  task automatic wreg_be(input logic [11:0] a, input logic [31:0] d,
                         input logic [3:0] be);
    begin
      @(negedge aon_clk);
      reg_waddr = a; reg_wdata = d; reg_wstrb = be; reg_wen = 1'b1;
      @(negedge aon_clk);
      reg_wen = 1'b0; reg_wstrb = 4'hF;
    end
  endtask

  task automatic ck_reg(input logic [11:0] a, input logic [31:0] exp, input string what);
    begin
      rreg(a);
      checks++;
      if (rd !== exp) begin
        errors++;
        $display("[%0t] FAIL %0s: %0s -- read 0x%08h, expected 0x%08h",
                 $time, sect, what, rd, exp);
      end else $display("[%0t]  ok  %0s: %0s = 0x%08h", $time, sect, what, exp);
    end
  endtask

  task automatic settle(); repeat (400) @(posedge aon_clk); endtask

  task automatic clear_irqs();
    begin
      wreg_be(A_ISR,  32'hFFFF_FFFF, 4'hF);
      wreg_be(A_AISR, 32'hFFFF_FFFF, 4'hF);
    end
  endtask

  // Did an interrupt fire since the last clear? Read rather than sampled, so
  // the checks below cannot depend on when the pulse happened.
  function automatic bit aisr_bit(input int b); return rd[b]; endfunction

  initial begin
    logic [31:0] prev_val;

    $dumpfile("ppu_be_tb.vcd");
    $dumpvars(0, ppu_be_tb);

    $display("==============================================================");
    $display(" ppu_be_tb: byte-lane write strobes (Section 6.2.1 extension)");
    $display("==============================================================");

    repeat (8) @(posedge aon_clk);
    aon_rst_n = 1'b1;
    settle();

    // =========================================================================
    section("B1 wstrb = 0 is not a write");
    // =========================================================================
    // A transaction with no lane selected transfers nothing, so it must have no
    // side effect at all -- not on the register, and not on the interrupts a
    // real write would raise. The bogus policy on wdata is the point: if the
    // strobe did not qualify the write, 0xF would be admitted for validation
    // and raise UNSPT_POLICY_IRQ from a transaction that moved no data.
    wreg_be(A_PWPR, {28'h0, PM_ON}, 4'hF);
    settle();
    clear_irqs();
    rreg(A_PWPR); prev_val = rd;

    wreg_be(A_PWPR, 32'hFFFF_FFFF, 4'h0);
    settle();
    ck_reg(A_PWPR, prev_val, "PPU_PWPR unchanged by a zero-strobe write");
    rreg(A_AISR);
    ck(aisr_bit(AISR_UNSPT_POLICY) === 1'b0,
       "no UNSPT_POLICY_IRQ from a zero-strobe write");

    // The check that actually pins `wr = wen && |wstrb` down. Everything else in
    // this group survives without that qualifier, because the per-lane gates
    // below already stop any field from moving and the PWPR merge collapses to
    // the register's current contents -- which is a legal pair, so it is
    // admitted rather than rejected. What the qualifier alone prevents is the
    // policy_wr PULSE, and Section 4.1.2 makes that pulse a completion event.
    // Without it, a transaction carrying no data raises an interrupt.
    rreg(A_ISR);
    ck(rd[ISR_STA_POLICY_TRN] === 1'b0,
       "no STA_POLICY_TRN_IRQ either -- a zero-strobe write is not a write");

    // A zero-strobe write to a W1C register must not clear it either.
    wreg_be(A_PWPR, {28'h0, 4'hF}, 4'h1);          // provoke a real event
    settle();
    rreg(A_AISR);
    ck(aisr_bit(AISR_UNSPT_POLICY) === 1'b1, "setup: UNSPT_POLICY_IRQ is set");
    wreg_be(A_AISR, 32'hFFFF_FFFF, 4'h0);
    rreg(A_AISR);
    ck(aisr_bit(AISR_UNSPT_POLICY) === 1'b1,
       "zero-strobe write to PPU_AISR clears nothing");
    clear_irqs();

    // =========================================================================
    section("B2 PPU_DCDR0, three delays in three lanes");
    // =========================================================================
    // Table 5-24: RST_HWSTAT_DLY [23:16], ISO_CLKEN_DLY [15:8],
    // CLKEN_RST_DLY [7:0]. One field per lane, so each lane is checked to move
    // its own field and leave the other two alone.
    wreg_be(A_DCDR0, 32'h00AA_BBCC, 4'hF);
    ck_reg(A_DCDR0, 32'h00AA_BBCC, "baseline, all lanes");

    wreg_be(A_DCDR0, 32'h0011_2233, 4'b0001);
    ck_reg(A_DCDR0, 32'h00AA_BB33, "lane 0 moves CLKEN_RST_DLY only");

    wreg_be(A_DCDR0, 32'h0044_5566, 4'b0010);
    ck_reg(A_DCDR0, 32'h00AA_5533, "lane 1 moves ISO_CLKEN_DLY only");

    wreg_be(A_DCDR0, 32'h0077_8899, 4'b0100);
    ck_reg(A_DCDR0, 32'h0077_5533, "lane 2 moves RST_HWSTAT_DLY only");

    // Lane 3 selects [31:24], which Table 5-24 leaves reserved.
    wreg_be(A_DCDR0, 32'hFF00_0000, 4'b1000);
    ck_reg(A_DCDR0, 32'h0077_5533, "lane 3 is reserved, so nothing moves");

    // Two lanes at once, to show the gate is per lane and not a priority pick.
    wreg_be(A_DCDR0, 32'h00EE_DDCC, 4'b0101);
    ck_reg(A_DCDR0, 32'h00EE_55CC, "lanes 0 and 2 move together, lane 1 held");

    // =========================================================================
    section("B3 PPU_EDTR0, a field in the top lane");
    // =========================================================================
    // Table 5-22: FULL_RET_DEL is [31:24]. Every other register's fields live in
    // the low three lanes, so without this check lane 3 is never proven to do
    // anything at all -- B2 only ever proves it does nothing.
    wreg_be(A_EDTR0, 32'h1100_2233, 4'hF);
    ck_reg(A_EDTR0, 32'h1100_2233, "baseline, all lanes");

    wreg_be(A_EDTR0, 32'h9900_0000, 4'b1000);
    ck_reg(A_EDTR0, 32'h9900_2233, "lane 3 moves FULL_RET_DEL only");

    wreg_be(A_EDTR0, 32'h0000_0077, 4'b0001);
    ck_reg(A_EDTR0, 32'h9900_2277, "lane 0 moves OFF_DEL, FULL_RET_DEL held");

    // =========================================================================
    section("B4 PPU_PWPR, admission across two lanes");
    // =========================================================================
    // The case the whole design turns on. Section 4.1.1 validates the
    // (policy, dynamic-enable) PAIR, but the two fields are in different lanes,
    // so a single-lane write has to be admitted against the merge of what
    // software sent and what the register already holds.
    wreg_be(A_PWPR, {28'h0, PM_ON}, 4'hF);
    settle();
    clear_irqs();
    ck_reg(A_PWPR, 32'h0000_0008, "setup: policy ON, PWR_DYN_EN clear");

    // Lane 1 only: set PWR_DYN_EN, with an UNSUPPORTED policy sitting on the
    // masked lane 0. The merged pair is (ON, dyn) which is supported, so the
    // write must be ADMITTED and the 0xF must be ignored entirely.
    //
    // An implementation that validated the raw wdata would see policy 0xF,
    // reject the write, raise UNSPT_POLICY_IRQ and never set PWR_DYN_EN. All
    // three of the next checks catch it.
    wreg_be(A_PWPR, 32'h0000_010F, 4'b0010);
    settle();
    rreg(A_PWPR);
    ck(rd[3:0] === PM_ON,  "masked lane 0: PWR_POLICY still ON, 0xF ignored");
    ck(rd[8]   === 1'b1,   "lane 1 set PWR_DYN_EN");
    rreg(A_AISR);
    ck(aisr_bit(AISR_UNSPT_POLICY) === 1'b0,
       "admitted against the CURRENT policy, so no UNSPT_POLICY_IRQ");

    // The mirror image: lane 0 only, with garbage on the masked lane 1. The
    // policy moves, PWR_DYN_EN must hold the value it already had.
    wreg_be(A_PWPR, 32'h0000_0000 | {23'h0, 1'b0, 8'h00} | {28'h0, PM_OFF}, 4'b0001);
    settle();
    rreg(A_PWPR);
    ck(rd[3:0] === PM_OFF, "lane 0 moved PWR_POLICY to OFF");
    ck(rd[8]   === 1'b1,   "masked lane 1: PWR_DYN_EN kept its old value");
    clear_irqs();

    // Rejection still works through a single lane. Policy 0xF is a reserved
    // encoding, so a lane-0 write of it is refused as a whole.
    wreg_be(A_PWPR, {28'h0, PM_ON}, 4'b0001);
    settle();
    clear_irqs();
    wreg_be(A_PWPR, {28'h0, 4'hF}, 4'b0001);
    settle();
    rreg(A_PWPR);
    ck(rd[3:0] === PM_ON, "lane-0 write of a reserved policy is refused");
    rreg(A_AISR);
    ck(aisr_bit(AISR_UNSPT_POLICY) === 1'b1,
       "and it does raise UNSPT_POLICY_IRQ");
    clear_irqs();

    // LOCK_EN is [12], lane 1. A lane-0 policy write must not disturb it.
    wreg_be(A_PWPR, 32'h0000_1008, 4'hF);          // lock, policy ON
    settle();
    rreg(A_PWPR);
    ck(rd[12] === 1'b1, "setup: LOCK_EN set");
    wreg_be(A_PWPR, {28'h0, PM_ON}, 4'b0001);      // lane 0, LOCK_EN bit low
    settle();
    rreg(A_PWPR);
    ck(rd[12] === 1'b1, "masked lane 1: LOCK_EN survives a lane-0 write");
    wreg_be(A_PWPR, 32'h0000_0008, 4'hF);          // unlock again
    settle();

    // =========================================================================
    section("B5 PPU_IMR, read-modify-write on the masked lane");
    // =========================================================================
    // All PPU_IMR bits are in lane 0, so a lane-1 write must leave the register
    // exactly as it was. This is the merge path in ppu_irq: without it the
    // masked lanes would write zeros and clear the mask.
    wreg_be(A_IMR, 32'h0000_0027, 4'hF);
    ck_reg(A_IMR, 32'h0000_0027, "baseline mask");
    wreg_be(A_IMR, 32'h0000_0000, 4'b0010);
    ck_reg(A_IMR, 32'h0000_0027, "lane-1 write leaves PPU_IMR untouched");
    wreg_be(A_IMR, 32'h0000_0004, 4'b0001);
    ck_reg(A_IMR, 32'h0000_0004, "lane-0 write does change it");
    wreg_be(A_IMR, 32'h0000_0022, 4'hF);           // back to the reset mask

    // =========================================================================
    section("B6 PPU_ISR, write-1-to-clear per lane");
    // =========================================================================
    // PPU_ISR straddles the boundary: STA_POLICY_TRN [0] in lane 0 and
    // PWR_ACTIVE_EDGE [8] in lane 1. Set both, then clear them one lane at a
    // time. A merge implementation fails the first clear -- it would feed bit 8
    // back in as a clear request and take both bits down together.
    clear_irqs();
    wreg_be(A_IESR, 32'h0000_0003, 4'hF);          // enable both DEVACTIVE edges
    wreg_be(A_PWPR, {28'h0, PM_ON}, 4'hF);
    settle();
    wake = 1'b1;  repeat (60) @(posedge aon_clk);  // provoke a DEVACTIVE edge
    wake = 1'b0;  repeat (60) @(posedge aon_clk);
    settle();

    rreg(A_ISR);
    ck(rd[ISR_STA_POLICY_TRN] === 1'b1, "setup: STA_POLICY_TRN_IRQ set (lane 0)");
    ck(rd[ISR_PWR_ACTIVE_EDGE] === 1'b1, "setup: PWR_ACTIVE_EDGE_IRQ set (lane 1)");

    wreg_be(A_ISR, 32'h0000_0101, 4'b0001);
    rreg(A_ISR);
    ck(rd[ISR_STA_POLICY_TRN]  === 1'b0, "lane-0 clear takes STA_POLICY_TRN_IRQ down");
    ck(rd[ISR_PWR_ACTIVE_EDGE] === 1'b1, "and leaves PWR_ACTIVE_EDGE_IRQ set");

    wreg_be(A_ISR, 32'h0000_0101, 4'b0010);
    rreg(A_ISR);
    ck(rd[ISR_PWR_ACTIVE_EDGE] === 1'b0, "lane-1 clear then takes it down too");

    // =========================================================================
    section("B7 PPU_UNLK, the key is in lane 0");
    // =========================================================================
    // PPU_UNLK.UNLOCK is [0]. A write whose lane 0 is masked carries no key, so
    // it must not unlock however the other lanes are set.
    //
    // Getting locked takes more than setting LOCK_EN. Section 4.1.4 needs BOTH
    // enables -- LOCK_EN [12] and PWR_DYN_EN [8] -- and ppu_mode_lockable
    // admits only OFF and MEM_RET, so the PPU also has to actually BE in one.
    // Setting LOCK_EN alone, or setting it while ON, leaves LOCK_STATUS clear
    // and would make every check below vacuously true.
    wreg_be(A_PWPR, 32'h0000_1100 | {28'h0, PM_OFF}, 4'hF);
    settle();
    rreg(A_PWSR);
    ck(rd[12] === 1'b1, "setup: PPU_PWSR.LOCK_STATUS is locked in OFF");

    wreg_be(A_UNLK, 32'hFFFF_FFFF, 4'b1110);       // every lane BUT the key
    settle();
    rreg(A_PWSR);
    ck(rd[12] === 1'b1, "masked lane 0: no key, so still locked");

    wreg_be(A_UNLK, 32'h0000_0001, 4'b0001);
    settle();
    rreg(A_PWSR);
    ck(rd[12] === 1'b0, "lane-0 write of the key does unlock");

    wreg_be(A_PWPR, {28'h0, PM_ON}, 4'hF);         // back up, both enables cleared
    settle();

    // =========================================================================
    section("B8 a masked lane cannot forge a device control");
    // =========================================================================
    // PPU_PWCR: DEVREQEN [0] in lane 0, PWR_DEVACTIVEEN [8] in lane 1. Table
    // 5-10 resets both to 1. Clearing one must not clear the other, because
    // the two disable completely different things (Sections 4.1.3 and 4.1.5)
    // and a driver that clears one expects the other to keep working.
    wreg_be(A_PWCR, 32'h0000_0101, 4'hF);
    ck_reg(A_PWCR, 32'h0000_0101, "baseline: both enables set");
    wreg_be(A_PWCR, 32'h0000_0000, 4'b0001);
    ck_reg(A_PWCR, 32'h0000_0100, "lane 0 cleared DEVREQEN, PWR_DEVACTIVEEN held");
    wreg_be(A_PWCR, 32'h0000_0000, 4'b0010);
    ck_reg(A_PWCR, 32'h0000_0000, "lane 1 then cleared PWR_DEVACTIVEEN");
    wreg_be(A_PWCR, 32'h0000_0101, 4'hF);

    // =========================================================================
    $display("");
    $display("==============================================================");
    $display(" ppu_be_tb: %0d checks, %0d error(s)", checks, errors);
    $display(" RESULT: %0s", (errors == 0) ? "PASS" : "FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    #400000;
    $display("RESULT: FAIL");
    $fatal(1, "ppu_be_tb watchdog");
  end

endmodule
