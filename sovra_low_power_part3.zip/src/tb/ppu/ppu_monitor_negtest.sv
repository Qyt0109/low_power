`timescale 1ns/1ps
// Negative test for ppu_monitor -- proves the checker is not vacuous.
//
// There is no DUT here. The testbench drives the monitor's inputs directly,
// first through legal sequences (the monitor must stay silent) and then through
// one deliberate violation of each rule (the monitor must fire). Without this,
// the "0 PPU protocol violations" line at the end of ppu_pd_tb would be
// worthless: a checker that never fires reports zero on everything.
//
// Same structure and same reasoning as pchannel_monitor_negtest, including its
// central caveat: each sub-test starts from a known legal idle so the
// violations stay isolated, and asserts only that the count GREW. Some illegal
// wire states inherently trip more than one rule at once -- leaving a control
// at the wrong value and then committing a mode trips U3, and if the control
// happens to be isolation it may trip U4 on the way there -- so demanding an
// exact delta would assert an implementation detail of the monitor rather than
// its behaviour. The monitor's own log lines identify which rule fired.
//
// One rule needs a specific setup rather than a single wrong wire, and it is
// worth knowing why. U3 only evaluates while the most recent change was to
// PPUHWSTAT (see the monitor's header: that is what makes it robust to a
// software-programmable RST_HWSTAT_DLY). So provoking U3 means moving a control
// to the WRONG value first and committing the mode afterwards -- which is
// exactly the shape of the bug it exists to catch: the PPU claims a mode while
// one of its controls says otherwise.

import ppu_pkg::*;

module ppu_monitor_negtest;

  logic mclk = 1'b0;
  always #0.5 mclk = ~mclk;

  logic mrst_n    = 1'b0;
  logic ppu_rst_n = 1'b1;

  logic [15:0] hwstat = 16'h0000;
  logic        clken   = 1'b1;
  logic        iso     = 1'b1;
  logic        pore    = 1'b1;
  logic        warm    = 1'b1;
  logic        retn    = 1'b1;
  logic [15:0] pstate  = 16'h0008;
  logic        preq    = 1'b0;
  logic        qreqn    = 1'b1;
  logic        qacceptn = 1'b1;
  logic        qdeny    = 1'b0;

  int unsigned viol;
  int unsigned tb_errors = 0, checks = 0, viol_before;

  // Small settle so the test runs quickly. The ordering guarantee in U3 comes
  // from the last-event test, not from this number, so shrinking it does not
  // weaken what is being proved.
  ppu_monitor #(.SETTLE_CYCLES(4)) u_mon (
    .clk(mclk), .rst_n(mrst_n), .ppu_rst_n(ppu_rst_n),
    .ppuhwstat(hwstat),
    .dev_clken(clken), .dev_isolaten(iso),
    .dev_poresetn(pore), .dev_warmresetn(warm), .dev_retresetn(retn),
    .pcsm_pstate(pstate), .pcsm_preq(preq),
    .dev_qreqn(qreqn), .dev_qacceptn(qacceptn), .dev_qdeny(qdeny),
    .violations(viol)
  );

  // Advances on the NEGEDGE, so every assignment below lands half a monitor
  // cycle away from the posedge the monitor samples on. The first version of
  // this file stepped on the posedge, which put the stimulus and the sampling
  // edge at the same simulation time and made three "legal" sequences fail
  // depending on Icarus's event ordering -- the same trap the functional
  // testbenches' STIMULUS TIMING CONVENTION exists to avoid.
  task automatic step(input int unsigned n);
    repeat (n) @(negedge mclk);
  endtask

  task automatic banner(input string name);
    $display("\n[%0t] ---------- %0s ----------", $time, name);
  endtask

  // Legal, settled ON: every control released, PCSM idle, interface in Q_RUN.
  //
  // Reached by TELEPORT, under the PPU reset. Jumping straight from OFF to ON
  // asserts the clock and releases the resets in one step, which genuinely
  // breaks U5 and U6 -- and correctly so. Holding ppu_rst_n LOW across the jump
  // is how the monitor is documented to be told "these outputs are not the
  // result of a transition", and it keeps each sub-test's violation isolated to
  // the rule it is probing.
  task automatic idle_on();
    begin
      ppu_rst_n = 1'b0;
      step(2);
      preq   = 1'b0;
      pstate = 16'h0008;
      clken = 1'b1; iso = 1'b1; pore = 1'b1; warm = 1'b1; retn = 1'b1;
      qreqn = 1'b1; qacceptn = 1'b1; qdeny = 1'b0;
      hwstat = ppu_hwstat(PM_ON);
      step(2);
      ppu_rst_n = 1'b1;
      step(12);
    end
  endtask

  // Legal, settled OFF: everything asserted, interface quiesced in Q_STOPPED.
  task automatic idle_off();
    begin
      ppu_rst_n = 1'b0;
      step(2);
      preq   = 1'b0;
      pstate = 16'h0000;
      clken = 1'b0; iso = 1'b0; pore = 1'b0; warm = 1'b0; retn = 1'b0;
      qreqn = 1'b0; qacceptn = 1'b0; qdeny = 1'b0;
      hwstat = ppu_hwstat(PM_OFF);
      step(2);
      ppu_rst_n = 1'b1;
      step(12);
    end
  endtask

  task automatic expect_fire(input string rule);
    begin
      step(10);
      checks++;
      if (viol > viol_before)
        $display("[%0t]  ok  %0s fired (%0d -> %0d)", $time, rule, viol_before, viol);
      else begin
        tb_errors++;
        $display("[%0t] FAIL %0s did not fire -- the rule is vacuous", $time, rule);
      end
    end
  endtask

  task automatic expect_quiet(input string tag);
    begin
      step(10);
      checks++;
      if (viol == viol_before)
        $display("[%0t]  ok  %0s: monitor stayed silent", $time, tag);
      else begin
        tb_errors++;
        $display("[%0t] FAIL %0s: monitor fired on a LEGAL sequence (%0d -> %0d)",
                 $time, tag, viol_before, viol);
      end
    end
  endtask

  initial begin
    $dumpfile("ppu_monitor_negtest.vcd");
    $dumpvars(0, ppu_monitor_negtest);

    // Release the monitor's own reset, then establish a legal idle.
    step(2); mrst_n = 1'b1;
    idle_on();

    // =========================================================================
    banner("Baseline: a legal ON -> OFF -> ON sequence must be silent");
    viol_before = viol;
    // Departure order (Section 4.1.5): quiesce, clock, isolation, resets, PCSM.
    qreqn = 1'b0;              step(4);   // Q_REQUEST
    qacceptn = 1'b0;           step(4);   // Q_STOPPED
    clken = 1'b0;              step(4);
    iso   = 1'b0;              step(4);
    pore  = 1'b0; warm = 1'b0; retn = 1'b0; step(4);
    pstate = 16'h0000; step(2); preq = 1'b1; step(4); preq = 1'b0; step(2);
    hwstat = ppu_hwstat(PM_OFF); step(12);
    // Return order: PCSM, isolation, clock, resets, release quiescence.
    pstate = 16'h0008; step(2); preq = 1'b1; step(4); preq = 1'b0; step(2);
    iso   = 1'b1;              step(4);
    clken = 1'b1;              step(4);
    pore  = 1'b1; warm = 1'b1; retn = 1'b1; step(4);
    qreqn = 1'b1;              step(4);   // Q_EXIT
    qacceptn = 1'b1;           step(4);   // Q_RUN
    hwstat = ppu_hwstat(PM_ON); step(12);
    expect_quiet("legal.on_off_on");

    // =========================================================================
    banner("U1: PPUHWSTAT not one-hot");
    idle_on();
    viol_before = viol;
    hwstat = ppu_hwstat(PM_ON) | ppu_hwstat(PM_OFF);   // two bits set
    expect_fire("U1");

    idle_on();
    viol_before = viol;
    hwstat = 16'h0000;                                  // no bits set
    expect_fire("U1.zero");

    // =========================================================================
    banner("U2: PPUHWSTAT encodes a mode this PPU cannot be in");
    idle_on();
    viol_before = viol;
    hwstat = ppu_hwstat(PM_LOGIC_RET);   // P-Channel only, one-hot but invalid
    expect_fire("U2");

    // =========================================================================
    banner("U3: settled controls disagree with the committed mode");
    // The bug shape: leave a control at another mode's value, then commit ON.
    idle_on();
    viol_before = viol;
    iso    = 1'b0;                       // FULL_RET's isolation, in ON
    step(4);
    hwstat = ppu_hwstat(PM_ON);          // commit is the last event -> U3 arms
    // hwstat is unchanged in value, so force a real change through OFF and back
    // to make the commit observable as an event.
    hwstat = ppu_hwstat(PM_OFF); step(2); hwstat = ppu_hwstat(PM_ON);
    expect_fire("U3");

    // =========================================================================
    banner("U4: isolation asserted before the clock was removed");
    idle_on();
    viol_before = viol;
    iso = 1'b0;                          // clken still HIGH
    expect_fire("U4");

    // =========================================================================
    banner("U5: clock asserted before isolation was released");
    idle_off();
    viol_before = viol;
    clken = 1'b1;                        // iso still LOW
    expect_fire("U5");

    // =========================================================================
    banner("U6: reset released before the clock was enabled");
    idle_off();
    viol_before = viol;
    pore = 1'b1;                         // clken still LOW
    expect_fire("U6");

    // =========================================================================
    banner("U7: DEVPORESETn asserted before isolation");
    idle_on();
    viol_before = viol;
    pore = 1'b0;                         // iso still HIGH
    expect_fire("U7");

    // =========================================================================
    banner("U8: PCSMPSTATE changed while PCSMPREQ was HIGH");
    idle_on();
    viol_before = viol;
    preq = 1'b1; step(4);
    pstate = 16'h0005;                   // AMBA LPI 2.2.2 rule 3
    expect_fire("U8");
    preq = 1'b0;

    // =========================================================================
    banner("U10: PCSMPSTATE operating-mode field non-zero");
    idle_on();
    viol_before = viol;
    pstate = 16'h0038;                   // [7:4] = 3, reserved on a Q-Channel PPU
    expect_fire("U10");

    // =========================================================================
    banner("U11: RAM retain field set for a mode that has none");
    idle_on();
    viol_before = viol;
    pstate = 16'hA508;                   // retain value with mode field = ON
    expect_fire("U11");

    banner("U11 does NOT fire for the three modes that DO carry one");
    idle_on();
    viol_before = viol;
    pstate = 16'hA502; step(6);          // MEM_RET
    pstate = 16'hA505; step(6);          // FULL_RET
    pstate = 16'hA507; step(6);          // FUNC_RET
    expect_quiet("legal.retain_field");
    pstate = 16'h0008;

    // =========================================================================
    banner("U9: mode pair with ON at neither end");
    idle_on();
    // Settle legally in FULL_RET first, so the jump is the only violation.
    clken = 1'b0; iso = 1'b0; warm = 1'b0; step(4);
    hwstat = ppu_hwstat(PM_FULL_RET); step(12);
    viol_before = viol;
    hwstat = ppu_hwstat(PM_MEM_OFF);     // FULL_RET -> MEM_OFF, Section 3.3.2
    expect_fire("U9");

    // =========================================================================
    banner("U9 does NOT fire on the one sanctioned exception");
    idle_off();
    viol_before = viol;
    // Section 3.3.2: OFF -> MEM_RET is made "without going through ON", with no
    // device handshake and no device control change at all.
    pstate = 16'h0002; step(2); preq = 1'b1; step(4); preq = 1'b0; step(2);
    hwstat = ppu_hwstat(PM_MEM_RET); step(12);
    expect_quiet("legal.off_to_mem_ret");

    // =========================================================================
    banner("Checks are suspended while the PPU is in reset");
    idle_on();
    viol_before = viol;
    ppu_rst_n = 1'b0;
    step(2);
    hwstat = 16'hFFFF;                   // nonsense, but the PPU is held down
    clken = 1'bx; iso = 1'bx;            // so are the controls
    step(10);
    hwstat = ppu_hwstat(PM_ON);
    clken = 1'b1; iso = 1'b1;
    step(2);
    ppu_rst_n = 1'b1;
    expect_quiet("reset.suspended");

    // =========================================================================
    banner("Still silent on a legal sequence afterwards");
    idle_on();
    viol_before = viol;
    qreqn = 1'b0; step(4); qacceptn = 1'b0; step(4);
    clken = 1'b0; step(4);
    iso   = 1'b0; step(4);
    warm  = 1'b0; step(4);
    hwstat = ppu_hwstat(PM_FULL_RET); step(12);
    expect_quiet("legal.after");

    $display("\n==================== NEGATIVE TEST SUMMARY ====================");
    $display(" checks run       : %0d", checks);
    $display(" testbench errors : %0d", tb_errors);
    $display(" total violations flagged by the monitor: %0d", viol);
    $display(" RESULT: %s", (tb_errors == 0) ? "PASS" : "FAIL");
    $display("===============================================================\n");
    $finish;
  end

endmodule
