# ppu_demo_probe.tcl -- waveform setup for "make wave-ppudemopa"
#
# ppu_demo_tb is the one testbench built to be WATCHED rather than read: every
# PPU feature once, in order, with gaps between them, and a demo_step bookmark
# strip that matches the numbered transcript. Under power intent it is also the
# only view in this repository where the PPU's mode distinctions are visibly
# physical -- without UPF, FULL_RET, MEM_RET and OFF are three names over an
# identical set of traces, because the workload is held in reset in all three.
#
# This probes the design to an SHM database so the waveform survives the run,
# and probes the UPF supply nets explicitly: they are not part of the HDL
# hierarchy, so "probe -all" over the design does not reach them, and without
# them the whole point of the power-aware run is missing from the waveform.
#
# Referenced by the ppudemopa / wave-ppudemopa targets in src/Makefile.

database -open -shm -into waves.shm waves -default

# The design, including the testbench's own state so demo_step and the phase
# strings line up with the transcript.
probe -create -database waves ppu_demo_tb -depth all -all -memories

# The power intent's own objects. These are NOT addressable as HDL paths --
# "describe ppu_demo_tb.u_top.VDD_LOGIC" answers *SE,PNOOBJ, because a UPF
# supply net is not part of the design hierarchy. They need the probe command's
# own low-power switches instead:
#
#   -power        every low-power simulation control expression: the supply
#                 nets, the switch on/off states, the isolation enable and the
#                 corruption state of each domain
#   -pwr_mode     the named power states from add_power_state -- PM_RUN,
#                 PM_FULL_RET, PM_DOWN, so the waveform is annotated with the
#                 PPU mode names rather than only with rail voltages
#   -sr_all_save  the retention cells' saved values, which is what makes
#                 FULL_RET distinguishable from MEM_RET on the waveform at all
#
# VDD_LOGIC and VDD_RET are the two traces to look for: the pair of states a
# single switch cannot express, and the reason ppu_pd_top.upf creates two nets.
#
# Two probes rather than one, and -pwr_mode takes no object. Both of those are
# enforced rather than stylistic:
#   *E,CPFPPR  the option -pwr_mode is not allowed when probing low power
#              simulation with -power
#   *E,CPFPMO  the option/object ppu_demo_tb is not allowed when probing low
#              power simulation power modes
probe -create -database waves -power -sr_all_save ppu_demo_tb -depth all
probe -create -database waves -pwr_mode

run
