`timescale 1ns/1ps
// PPU reset-in-flight testbench -- RESETn asserted during a transition.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Section 4.2.1 "PPU Reset Behavior", Section 4.1.6 "PCSM
// P-Channel Reset", and AMBA Low Power Interface (ARM IHI 0068C) Section 2.1.2.
//
// WHY THIS EXISTS
//
// The third axis every other PPU testbench holds constant. Each of them drives
// aon_rst_n exactly once, at time zero, and releases it before anything happens:
//
//     ppu_pd_tb  ppu_reset_tb  ppu_clkratio_tb  ppu_minconfig_tb
//
// So RESETn has never landed while the PPU was doing something. ppu_reset_tb is
// about reset RELEASE -- Table 4-13, which mode the PPU comes up in -- and says
// nothing about assertion. That leaves the whole of the sequencer's state space
// untested against an asynchronous reset: every device-control step, both
// handshake directions, the entry-delay wait and the PCSM exchange.
//
// It is not a hypothetical. An asynchronous reset of a power controller is the
// one event that can take its outputs somewhere the sequencer never chose, and
// the outputs in question are a clock enable, an isolation enable, three resets
// and a power-switch request. Getting the reset VALUES right is necessary but
// not sufficient -- what matters is whether the resulting jump is a legal move
// from wherever the PPU happened to be.
//
// WHAT IS ACTUALLY BEING ASKED
//
// Three questions, and they have different characters:
//
//   1. Does the PPU RECOVER? After release it must reach its Table 4-13 mode,
//      agree with the PCSM about where the domain is, and still work.
//
//   2. Is the POWER SEQUENCE still legal? ppu_power_model's PU1-PU8 are ordering
//      rules -- isolation before supply removal, supply before isolation
//      release. A reset that drops the supply while isolation is inactive is a
//      real hardware hazard, and it is invisible to any test that only checks
//      where the PPU ends up.
//
//   3. Is the Q-CHANNEL left legal? Here the answer is known in advance to be
//      "no, and correctly so". qchannel_monitor R9 fires when the controller is
//      reset outside Q_STOPPED, which is AMBA LPI Section 2.1.2 -- a device left
//      believing a request is outstanding while the controller has forgotten it.
//      Interrupting a handshake is exactly what this testbench does on purpose.
//
// SO THE VIOLATIONS ARE CLASSIFIED, NOT MUTED
//
// Muting R9 would throw away the only check that knows this scenario is
// dangerous. Instead the monitor's counter is sampled around each reset and each
// recovery, and the DELTA is checked against what the channel state says should
// have happened:
//
//   reset taken in Q_STOPPED      ->  delta must be 0. A reset with the
//                                     interface already parked is a normal,
//                                     silent event, and it must stay silent.
//   reset taken anywhere else     ->  delta must be non-zero. Interrupting a
//                                     live handshake must be noticed.
//   after recovery, normal running ->  delta must be 0. Whatever the reset did
//                                     to the interface, the PPU has to leave it
//                                     usable.
//
// That last one is the sharpest check in the file and the one worth having: 180
// times over, a Q-Channel that has just had a handshake torn up underneath it
// runs a full ON->OFF->ON round trip with the monitor completely quiet.
//
// Deltas rather than an exact predicted total, because the monitor exposes one
// aggregate counter and a single reset edge trips up to three rules at once --
// R9 (controller reset), R8 (device reset) and R10 (resource gated). Predicting
// which combination fires would mean modelling the clock-gate latch's timing in
// the testbench, which encodes implementation detail into a conformance check.
// The delta form asserts the property that actually matters and is indifferent
// to how many rules noticed.
//
// THAT R8 FIRES ALONGSIDE R9 IS THE TOPOLOGY, AND IT IS CORRECT
//
// In ppu_pd_top both ends of the device Q-Channel are reset by aon_rst_n -- the
// device wrapper is always-on and takes the same reset, deliberately, because
// that is what lets a powered-down domain still signal a wake. So an interrupted
// handshake shows up as R9 *and* R8: the monitor sees both ends being reset,
// which is precisely the AMBA LPI-legal way to interrupt one. A design where
// only R9 fired would be the broken one -- a controller that forgot a request
// the device is still waiting on.

module ppu_rstflight_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  // How deep into a transition to reach. A departure plus its return costs well
  // under this at the ratio used here, so the sweep covers every sequencer state
  // including the idle tail after completion -- the tail matters, because a
  // reset landing there must be harmless.
  localparam int unsigned MAX_DELAY = 60;

  logic aon_clk = 1'b0, dclk = 1'b0, mclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;
  always #6.85 dclk    = ~dclk;
  always #0.5  mclk    = ~mclk;

  logic aon_rst_n = 1'b0;
  logic mrst_n    = 1'b0;   // the monitors' own reset, released once and kept

  logic [11:0] reg_waddr  = 12'h000;

  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0] reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;
  logic [31:0] reg_rdata;
  logic        irq;

  logic             start = 1'b0;
  logic [CNT_W-1:0] work_len = '0;
  logic             light_work = 1'b1;
  logic             wake = 1'b0;
  logic             deny_enb = 1'b0;

  int unsigned tb_errors = 0, checks = 0;

  ppu_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),
    .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_ren(reg_ren), .reg_rdata(reg_rdata), .irq(irq),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(start), .work_len(work_len),
    .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0] pwr_status = u_top.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] pcsm_mode  = u_top.u_dom.u_pcsm.mode;
  wire       seq_busy   = (u_top.u_dom.u_ppu.u_seq.state !== 4'd0);
  // Compared against 1 rather than inverted so that an unpowered PD_DEV reads
  // as "gated" instead of X under "make ppurstfpa" -- u_clkctrl is in the
  // switched domain. Identical to ~en_latch in ordinary simulation. The full
  // reasoning, and the two failures it caused, are in ppu_pd_tb.sv.
  wire       clk_gated  = (u_top.u_dom.u_clkctrl.en_latch !== 1'b1);

  int unsigned qviol, uviol, pmviol;

  qchannel_monitor u_qmon (
    .clk(mclk), .rst_n(mrst_n),
    .crst_n(aon_rst_n), .drst_n(u_top.u_dom.dev_rst_in_n), .clk_gated(clk_gated),
    .qreqn(u_top.u_dom.dev_qreqn), .qacceptn(u_top.u_dom.dev_qacceptn),
    .qdeny(u_top.u_dom.dev_qdeny), .violations(qviol)
  );

  ppu_monitor u_umon (
    .clk(mclk), .rst_n(mrst_n), .ppu_rst_n(aon_rst_n),
    .ppuhwstat(u_top.ppuhwstat),
    .dev_clken(u_top.u_dom.dev_clken), .dev_isolaten(u_top.dev_isolaten),
    .dev_poresetn(u_top.u_dom.dev_poresetn), .dev_warmresetn(u_top.u_dom.dev_warmresetn),
    .dev_retresetn(u_top.u_dom.dev_retresetn),
    .pcsm_pstate(u_top.u_dom.pcsm_pstate), .pcsm_preq(u_top.u_dom.pcsm_preq),
    .dev_qreqn(u_top.u_dom.dev_qreqn), .dev_qacceptn(u_top.u_dom.dev_qacceptn),
    .dev_qdeny(u_top.u_dom.dev_qdeny),
    .violations(uviol)
  );

  // The power model is the reason this file is worth writing. PU1-PU8 are the
  // ordering rules an asynchronous reset is most likely to break, and they are
  // checked continuously -- including across the reset edge itself.
  ppu_power_model u_pwr (
    .clk(aon_clk), .rst_n(mrst_n),
    .dev_clken(u_top.u_dom.dev_clken), .dev_isolaten(u_top.dev_isolaten),
    .dev_poresetn(u_top.u_dom.dev_poresetn), .dev_warmresetn(u_top.u_dom.dev_warmresetn),
    .dev_retresetn(u_top.u_dom.dev_retresetn),
    .logic_on(u_top.logic_on), .logic_ret(u_top.logic_ret),
    .ram_on(u_top.u_dom.ram_on), .ram_ret(u_top.u_dom.ram_ret),
    .ret_n(u_top.ret_n), .wl_rst_n(u_top.wl_rst_n),
    .corrupt(), .iso_clamp(), .ret_valid(), .do_save(), .do_restore(),
    .violations(pmviol)
  );

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  task automatic check(input bit cond, input string tag);
    begin
      checks++;
      if (!cond) begin tb_errors++; $display("[%0t] FAIL %0s", $time, tag); end
      else            $display("[%0t]  ok  %0s", $time, tag);
    end
  endtask

  task automatic reg_write(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk);
      reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk);
      reg_wen = 1'b0;
    end
  endtask

  task automatic set_policy(input logic [3:0] m);
    reg_write(A_PWPR, {28'h0, m});
  endtask

  task automatic settle();
    repeat (400) @(posedge aon_clk);
  endtask

  // Was the channel parked when the reset landed?
  //
  // Read from the MONITOR's registered view of the channel rather than from the
  // pins directly, and the distinction is not pedantic -- it was a real failure.
  // R9 evaluates {c_req, c_acc, c_den} at the instant crst_n falls; those are
  // the monitor's own sampled copies, up to one monitor clock stale. Reading the
  // raw pins at the same instant disagrees with them for exactly one sample
  // whenever the channel is changing state right then, and the sweep found it:
  // one iteration in 180 landed on the edge where the channel was parking, so
  // the testbench called it parked and the monitor called it live.
  //
  // Both readings were defensible, which is what makes it a testbench bug rather
  // than a design bug -- two observers disagreeing about an instant, not a
  // hardware rule being broken. Classifying from the same state R9 classifies
  // from removes the ambiguity at its source instead of widening a tolerance
  // until the failure stops appearing.
  bit          rst_in_stopped;
  int unsigned n_stopped = 0, n_live = 0;

  task automatic reset_pulse();
    begin
      @(negedge aon_clk);
      rst_in_stopped = (u_qmon.c_req === 1'b0 && u_qmon.c_acc === 1'b0
                        && u_qmon.c_den === 1'b0);
      if (rst_in_stopped) n_stopped++; else n_live++;
      aon_rst_n = 1'b0;
      repeat (6) @(posedge aon_clk);
      @(negedge aon_clk) aon_rst_n = 1'b1;
    end
  endtask

  // Per-iteration failure tallies. A sweep this size would otherwise print
  // thousands of "ok" lines and bury the summary; failures are always printed
  // with their iteration, and the aggregate becomes a handful of real checks.
  int unsigned n_iter = 0;
  int unsigned f_recover = 0, f_agree = 0, f_func = 0, f_actuate = 0;
  int unsigned f_silent = 0, f_unnoticed = 0, f_dirty = 0;
  int unsigned q_mark;

  task automatic check_recovery(input string ctx, input int unsigned d);
    begin
      n_iter++;

      // 1. Table 4-13 row 3: PCSMMODESTAT reports OFF and the default policy is
      //    ON, so the PPU comes up in OFF and then transitions to ON by itself.
      settle();
      if (pwr_status !== PM_ON) begin
        f_recover++;
        $display("[%0t] FAIL %0s d=%0d: after reset the PPU settled in %0s, expected ON",
                 $time, ctx, d, ppu_mode_name(pwr_status));
      end

      // 2. The PPU and the PCSM must agree about where the domain is. This is
      //    the check that a reset cannot be allowed to desynchronize them: the
      //    PPU's idea of the mode comes from its own registers, the PCSM's from
      //    the P-Channel, and nothing re-reconciles them afterwards.
      if (pcsm_mode !== PM_ON) begin
        f_agree++;
        $display("[%0t] FAIL %0s d=%0d: PCSM committed %0s while the PPU reports %0s",
                 $time, ctx, d, ppu_mode_name(pcsm_mode), ppu_mode_name(pwr_status));
      end

      // 3. ON must mean ON at the pins, not just in a register.
      if (!(u_top.logic_on === 1'b1 && u_top.u_dom.ram_on === 1'b1
            && u_top.dev_isolaten === 1'b1 && u_top.u_dom.dev_clken === 1'b1
            && u_top.u_dom.dev_poresetn === 1'b1 && u_top.u_dom.dev_warmresetn === 1'b1)) begin
        f_actuate++;
        $display("[%0t] FAIL %0s d=%0d: recovered to ON but the actuation is wrong (logic_on=%0b ram_on=%0b iso=%0b clken=%0b)",
                 $time, ctx, d, u_top.logic_on, u_top.u_dom.ram_on,
                 u_top.dev_isolaten, u_top.u_dom.dev_clken);
      end

      // 4. The interface reacted to the reset the way its state said it should.
      if (rst_in_stopped && (qviol != q_mark)) begin
        f_silent++;
        $display("[%0t] FAIL %0s d=%0d: reset taken in Q_STOPPED still raised %0d violation(s)",
                 $time, ctx, d, qviol - q_mark);
      end
      if (!rst_in_stopped && (qviol == q_mark)) begin
        f_unnoticed++;
        $display("[%0t] FAIL %0s d=%0d: reset interrupted a live handshake and nothing noticed",
                 $time, ctx, d);
      end
      q_mark = qviol;

      // 5. Still a working PPU: a full round trip after the interruption, with
      //    the monitor required to stay completely quiet through it.
      set_policy(PM_OFF);
      settle();
      if (pwr_status !== PM_OFF) begin
        f_func++;
        $display("[%0t] FAIL %0s d=%0d: post-reset ON->OFF failed, stuck in %0s",
                 $time, ctx, d, ppu_mode_name(pwr_status));
      end
      set_policy(PM_ON);
      settle();
      if (pwr_status !== PM_ON) begin
        f_func++;
        $display("[%0t] FAIL %0s d=%0d: post-reset OFF->ON failed, stuck in %0s",
                 $time, ctx, d, ppu_mode_name(pwr_status));
      end

      if (qviol != q_mark) begin
        f_dirty++;
        $display("[%0t] FAIL %0s d=%0d: %0d violation(s) during normal running AFTER recovery",
                 $time, ctx, d, qviol - q_mark);
      end
      q_mark = qviol;
    end
  endtask

  // One sweep: from ON, request `tgt`, wait d cycles, reset, verify recovery.
  task automatic sweep(input logic [3:0] tgt, input string ctx);
    begin
      int unsigned d;
      $display("\n[%0t] ---- sweeping reset into ON -> %0s, d = 1..%0d ----",
               $time, ppu_mode_name(tgt), MAX_DELAY);
      for (d = 1; d <= MAX_DELAY; d++) begin
        set_policy(PM_ON);
        settle();
        set_policy(tgt);
        repeat (d) @(posedge aon_clk);
        q_mark = qviol;
        reset_pulse();
        check_recovery(ctx, d);
      end
    end
  endtask

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("ppu_rstflight_tb.vcd");
    $dumpvars(0, ppu_rstflight_tb);

    $display("==============================================================");
    $display(" PPU reset-in-flight run");
    $display("   RESETn asserted 1..%0d cycles into a transition, three", MAX_DELAY);
    $display("   destinations, with the monitors watching ACROSS the reset.");
    $display("==============================================================");

    aon_rst_n = 1'b0; mrst_n = 1'b0;
    repeat (10) @(posedge aon_clk);
    @(negedge aon_clk) aon_rst_n = 1'b1;
    repeat (4) @(posedge aon_clk);
    mrst_n = 1'b1;      // released once, never again -- it must see every reset
    settle();

    check(pwr_status === PM_ON, "initial bring-up reached ON");

    // OFF exercises the full departure: quiesce, clock, isolation, reset, PCSM.
    // MEM_RET is the other unpowered mode and takes the RAM-retention path.
    // FULL_RET keeps the supply and stops at isolation, so its reset points land
    // in a different part of the sequence.
    sweep(PM_OFF,      "ON->OFF");
    sweep(PM_MEM_RET,  "ON->MEM_RET");
    sweep(PM_FULL_RET, "ON->FULL_RET");

    // -------------------------------------------------------------------------
    $display("\n[%0t] ========== Aggregate ==========", $time);
    $display("[%0t]   %0d reset-in-flight iterations", $time, n_iter);

    check(f_recover  == 0, "every reset recovered to the Table 4-13 mode");
    check(f_agree    == 0, "the PPU and the PCSM never disagreed after a reset");
    check(f_actuate  == 0, "recovery to ON always powered, unisolated and unreset the domain");
    check(f_func     == 0, "the PPU still transitioned normally after every reset");

    $display("[%0t]   resets taken in Q_STOPPED %0d, into a live handshake %0d",
             $time, n_stopped, n_live);
    $display("[%0t]   qchannel_monitor raised %0d violation(s), all at reset edges",
             $time, qviol);

    check(n_live > 0,
          "the sweep really did interrupt live handshakes");
    check(n_stopped > 0,
          "the sweep also caught the interface already parked");
    check(f_silent == 0,
          "a reset taken in Q_STOPPED was always silent");
    check(f_unnoticed == 0,
          "a reset that interrupted a handshake was always noticed");
    check(f_dirty == 0,
          "after recovery the Q-Channel ran clean -- zero violations in normal operation");

    // These two must be clean. Neither has a topology excuse: PU1-PU8 are about
    // the order power, clock, isolation and reset move in, and U1-U11 about the
    // device-control sequence -- an asynchronous reset changes when they move,
    // never whether the order is allowed.
    check(uviol  == 0, "ppu_monitor: no device-control violations across any reset");
    check(pmviol == 0, "ppu_power_model: no power-ordering violations across any reset");

    $display("\n==============================================================");
    $display(" ppu_rstflight_tb: %0d checks, %0d error(s)", checks, tb_errors);
    $display("   iterations %0d (%0d in Q_STOPPED, %0d live)   qch %0d   ppu_monitor %0d   power %0d",
             n_iter, n_stopped, n_live, qviol, uviol, pmviol);
    if (tb_errors == 0) $display(" RESULT: PASS");
    else                $display(" RESULT: FAIL");
    $display("==============================================================\n");
    $finish;
  end

  initial begin
    repeat (4000000) @(posedge aon_clk);
    $display("\n[%0t] ppu_rstflight_tb: WATCHDOG -- simulation did not finish", $time);
    $display(" RESULT: FAIL");
    $fatal(1, "watchdog");
  end

endmodule
