`timescale 1ns/1ps
// REGISTERS.md conformance testbench.
//
// Every other PPU testbench is organised by RTL behaviour. This one is organised
// by the DOCUMENT: it walks rtl/ppu/REGISTERS.md section by section and checks
// each behavioural claim it makes. The failure mode it catches is a different
// one -- not "the RTL is wrong" but "the programmer's reference says something
// the RTL does not do".
//
// That distinction is why the overlap with ppu_pd_tb, ppu_minconfig_tb and
// ppu_irq_tb is deliberate rather than wasteful. Those suites would keep passing
// if someone edited a default value or a field position in the document; this
// one would not.
//
// Check tags carry the section number, so a failure points straight at the
// paragraph that is wrong.
//
// WHAT IT DOES NOT DO
//
// The claims are transcribed into SystemVerilog by hand, so editing REGISTERS.md
// does not by itself break this file. What it pins down is the other direction:
// every behaviour the document asserts has been executed at least once against
// the RTL, and any later RTL change that contradicts a documented behaviour
// fails here. Keeping the two in step when the document changes is still a
// human job -- this removes the case where they were never in step to begin
// with.

module ppu_regdoc_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  logic aon_clk = 1'b0, dclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;
  always #6.85 dclk    = ~dclk;

  logic aon_rst_n = 1'b0;
  logic [11:0] reg_waddr  = 12'h000;
  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0] reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;
  logic [31:0] reg_rdata;
  logic        irq;

  logic             start = 1'b0;
  logic [CNT_W-1:0] work_len = '0;
  logic             light_work = 1'b1;
  logic             wake = 1'b0;
  logic             deny_enb = 1'b0;

  ppu_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),
    .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_ren(reg_ren), .reg_rdata(reg_rdata), .irq(irq),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(start), .work_len(work_len),
    .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0]  pwr_status = u_top.u_dom.u_ppu.u_seq.pwr_status;
  wire [15:0] pcsm_pstate = u_top.u_dom.u_ppu.pcsm_pstate;
  wire        seq_busy   = (u_top.u_dom.u_ppu.u_seq.state !== 4'd0);
  wire        dev_qreqn   = u_top.u_dom.dev_qreqn;
  // PPU_MISR reflects three PINS directly (Table 5-6), so the only way to pin
  // its bit positions down is to compare against those pins at the moment the
  // read is captured.
  // ppu_top wires the register file to the SYNCHRONIZED versions, not the pads
  // -- so these probe there. Comparing against the raw pins instead fails by
  // exactly SYNC_STAGES cycles, which is a real difference and not a tolerance
  // to widen: PPU_MISR is defined as a view of what the PPU has sampled.
  wire        pin_dev_qdeny    = u_top.u_dom.u_ppu.sync_dev_qdeny;
  wire        pin_dev_qacceptn = u_top.u_dom.u_ppu.sync_dev_qacceptn;
  wire        pin_pcsm_paccept = u_top.u_dom.u_ppu.sync_pcsm_paccept;
  wire        busy            = u_top.busy;

  int unsigned checks = 0, errors = 0;
  string       sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  logic [31:0] rd;
  logic [31:0] save0, save1;   // section 1 borrows PPU_DCDR0/1 and puts them back
  task automatic rreg(input logic [11:0] a);
    begin
      @(negedge aon_clk); reg_raddr = a; reg_ren = 1'b1;
      @(negedge aon_clk); reg_ren = 1'b0;
      @(negedge aon_clk); rd = reg_rdata;
    end
  endtask

  task automatic wreg(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk); reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk); reg_wen = 1'b0;
    end
  endtask

  task automatic ck_reg(input logic [11:0] a, input logic [31:0] exp, input string what);
    begin
      rreg(a);
      checks++;
      if (rd !== exp) begin
        errors++;
        $display("[%0t] FAIL %0s: %0s -- read 0x%08h, doc says 0x%08h",
                 $time, sect, what, rd, exp);
      end else $display("[%0t]  ok  %0s: %0s = 0x%08h", $time, sect, what, exp);
    end
  endtask

  // Write all-ones and check only the documented writable bits stick.
  task automatic ck_wmask(input logic [11:0] a, input logic [31:0] mask, input string what);
    begin
      wreg(a, 32'hFFFF_FFFF);
      rreg(a);
      checks++;
      if (rd !== mask) begin
        errors++;
        $display("[%0t] FAIL %0s: %0s -- writable mask reads 0x%08h, doc says 0x%08h",
                 $time, sect, what, rd, mask);
      end else $display("[%0t]  ok  %0s: %0s = 0x%08h", $time, sect, what, mask);
    end
  endtask

  task automatic settle(); repeat (400) @(posedge aon_clk); endtask

  // ---- PPU_MISR, sampled against its pins -------------------------------
  //
  // A whole-word compare against a constant cannot check this register: its
  // three fields are live pin views, and at rest all three sit at values that
  // make a misplaced bit indistinguishable from a correct one. Two bit-position
  // mutations survived the entire suite before this existed -- DEVDENY_STATUS
  // moved 16 -> 17 and PCSMPACCEPT_STATUS moved 0 -> 1 -- because nothing ever
  // read PPU_MISR while those pins were HIGH.
  //
  // So this samples the pins at the edge that loads rdata and compares. Called
  // in a loop across a transition and a denial, it sees each pin in both
  // states; misr_saw_* records that, because a relational check against pins
  // that never move is exactly as vacuous as the constant compare it replaces.
  int  misr_bad = 0;
  bit  misr_saw_deny = 0, misr_saw_acc = 0, misr_saw_pa = 0;

  task automatic sample_misr();
    bit d, a, pa;
    begin
      @(negedge aon_clk); reg_raddr = A_MISR; reg_ren = 1'b1;
      @(posedge aon_clk); d = pin_dev_qdeny; a = pin_dev_qacceptn; pa = pin_pcsm_paccept;
      @(negedge aon_clk); reg_ren = 1'b0;
      @(negedge aon_clk);
      if (reg_rdata[16] !== d || reg_rdata[8] !== a || reg_rdata[0] !== pa)
        misr_bad++;
      if (d)  misr_saw_deny = 1'b1;
      if (!a) misr_saw_acc  = 1'b1;   // DEVQACCEPTn is active LOW
      if (pa) misr_saw_pa   = 1'b1;
    end
  endtask

  task automatic go(input logic [3:0] m);
    begin wreg(A_PWPR, {28'h0, m}); settle(); end
  endtask

  task automatic clear_irqs();
    begin wreg(A_ISR, 32'hFFFF_FFFF); wreg(A_AISR, 32'hFFFF_FFFF); repeat (20) @(posedge aon_clk); end
  endtask

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("ppu_regdoc_tb.vcd");
    $dumpvars(0, ppu_regdoc_tb);
    $display("==============================================================");
    $display(" REGISTERS.md conformance -- every claim the document makes");
    $display("==============================================================");

    repeat (10) @(posedge aon_clk);
    @(negedge aon_clk) aon_rst_n = 1'b1;
    settle();

    // =======================================================================
    section("1. The bus");
    // "reg_rdata is registered -- valid the cycle after reg_ren".
    //
    // The first version of this check asserted rdata was NOT yet valid one
    // negedge after the strobe, and failed -- because it IS valid there. Setting
    // ren at a negedge means the following POSEDGE loads rdata, so the next
    // negedge already has it. That is exactly "the cycle after", so the document
    // was right and the check was testing the wrong edge.
    //
    // What "registered" actually buys is that rdata does not follow the address
    // combinationally, and that is what is checked here: park a known value,
    // point the address somewhere else with ren asserted, and confirm rdata has
    // not moved until a clock edge has passed.
    rreg(A_AIDR);
    ck(rd === 32'h0000_0011, "a read returns the addressed register");
    @(negedge aon_clk); reg_raddr = A_IDR1; reg_ren = 1'b1;
    #1;
    ck(reg_rdata === 32'h0000_0011,
       "rdata holds its previous value while ren is asserted (registered, not combinational)");
    @(negedge aon_clk); reg_ren = 1'b0;
    ck(reg_rdata === 32'h0000_1077, "rdata valid the cycle after reg_ren");
    // "Any unmapped offset reads zero"
    ck_reg(12'h0FC, 32'h0, "unmapped offset 0x0FC reads zero");
    ck_reg(12'h800, 32'h0, "unmapped offset 0x800 reads zero");

    // ---- Independent write and read address buses ----
    //
    // The whole point of splitting reg_addr in two: AXI4-Lite orders AW/W/B
    // against AR/R not at all, so a bridge may have one of each outstanding.
    // With a shared address bus it would need an arbiter and would serialise
    // them. These checks drive both strobes on the SAME cycle, which is not
    // expressible at all on a shared bus.
    // Section 2 checks these two for their reset defaults, so borrow and restore
    // rather than leaving the values this group needs sitting in them.
    rreg(A_DCDR0); save0 = rd;
    rreg(A_DCDR1); save1 = rd;
    wreg(A_DCDR1, 32'h0000_1234);

    // C1: write one register while reading a different one.
    @(negedge aon_clk);
    reg_waddr = A_DCDR0; reg_wdata = 32'h0056_78AB; reg_wstrb = 4'hF; reg_wen = 1'b1;
    reg_raddr = A_DCDR1; reg_ren = 1'b1;
    @(negedge aon_clk);
    reg_wen = 1'b0; reg_ren = 1'b0;
    ck(reg_rdata === 32'h0000_1234,
       "concurrent access: the read returns ITS address, not the write's");
    ck_reg(A_DCDR0, 32'h0056_78AB, "concurrent access: and the write still landed");

    // C2: write and read the SAME register on the same cycle. REGISTERS.md
    // says the read returns the value from before the write.
    @(negedge aon_clk);
    reg_waddr = A_DCDR1; reg_wdata = 32'h0000_5678; reg_wstrb = 4'hF; reg_wen = 1'b1;
    reg_raddr = A_DCDR1; reg_ren = 1'b1;
    @(negedge aon_clk);
    reg_wen = 1'b0; reg_ren = 1'b0;
    ck(reg_rdata === 32'h0000_1234,
       "same-address collision: the read returns the pre-write value");
    ck_reg(A_DCDR1, 32'h0000_5678, "same-address collision: the write still landed");

    // C3: the write address must not disturb the read decode even when it
    // points at a register with a completely different value. This is the check
    // that fails outright if the two decodes are ever merged back into one.
    @(negedge aon_clk);
    reg_waddr = A_IMR; reg_wdata = 32'h0000_0000; reg_wstrb = 4'h0;   // no-op write
    reg_wen = 1'b1;
    reg_raddr = A_IDR0; reg_ren = 1'b1;
    @(negedge aon_clk);
    reg_wen = 1'b0; reg_ren = 1'b0;
    ck(reg_rdata === 32'h1E53_E501,
       "the write address never reaches the read decode");

    wreg(A_DCDR0, save0);
    wreg(A_DCDR1, save1);

    // =======================================================================
    section("2. Address map defaults");
    ck_reg(A_PWPR,  32'h0000_0008, "PPU_PWPR  default (DEF_PWR_POLICY = ON)");
    ck_reg(A_PWCR,  32'h0000_0101, "PPU_PWCR  default");
    ck_reg(A_PTCR,  32'h0000_0001, "PPU_PTCR  default");
    ck_reg(A_IMR,   32'h0000_0022, "PPU_IMR   default");
    ck_reg(A_AIMR,  32'h0000_0006, "PPU_AIMR  default");
    ck_reg(A_ISR,   32'h0000_0000, "PPU_ISR   default");
    ck_reg(A_AISR,  32'h0000_0000, "PPU_AISR  default");
    ck_reg(A_IESR,  32'h0000_0000, "PPU_IESR  default");
    ck_reg(A_FUNRR, 32'h0000_0000, "PPU_FUNRR default");
    ck_reg(A_FULRR, 32'h0000_0000, "PPU_FULRR default");
    ck_reg(A_MEMRR, 32'h0000_0000, "PPU_MEMRR default");
    ck_reg(A_EDTR0, 32'h0000_0000, "PPU_EDTR0 default");
    ck_reg(A_EDTR1, 32'h0000_0000, "PPU_EDTR1 default");
    ck_reg(A_DCDR0, 32'h0002_0202, "PPU_DCDR0 default (the *_DLY_CFG params)");
    ck_reg(A_DCDR1, 32'h0000_0202, "PPU_DCDR1 default");
    ck_reg(A_IDR0,  32'h1E53_E501, "PPU_IDR0");
    ck_reg(A_IDR1,  32'h0000_1077, "PPU_IDR1");
    ck_reg(A_IIDR,  32'h50C0_1000, "PPU_IIDR (IMPLEMENTER 0x000, not Arm's 0x43B)");
    ck_reg(A_AIDR,  32'h0000_0011, "PPU_AIDR (architecture v1.1)");
    // reserved registers read zero permanently, not merely after reset
    wreg(A_PMER, 32'hFFFF_FFFF); ck_reg(A_PMER, 32'h0, "PPU_PMER reserved, reads zero after a write");
    wreg(A_STSR, 32'hFFFF_FFFF); ck_reg(A_STSR, 32'h0, "PPU_STSR reserved, reads zero after a write");
    wreg(A_OPSR, 32'hFFFF_FFFF); ck_reg(A_OPSR, 32'h0, "PPU_OPSR reserved, reads zero after a write");

    // =======================================================================
    section("3. Power mode values");
    begin
      logic [3:0] sup [0:6];
      sup[0]=PM_OFF; sup[1]=PM_MEM_RET; sup[2]=PM_FULL_RET; sup[3]=PM_MEM_OFF;
      sup[4]=PM_FUNC_RET; sup[5]=PM_ON;  sup[6]=PM_WARM_RST;
      for (int i = 0; i < 7; i++) begin
        wreg(A_PWPR, {28'h0, sup[i]});
        rreg(A_PWPR);
        ck(rd[3:0] === sup[i],
           $sformatf("%0s accepted as a static policy", ppu_mode_name(sup[i])));
        settle();
      end
    end
    go(PM_ON); clear_irqs();
    // unsupported encodings are write-ignored and raise UNSPT_POLICY_IRQ
    begin
      logic [3:0] bad [0:3];
      bad[0]=4'd1; bad[1]=4'd3; bad[2]=4'd4; bad[3]=4'd10;
      for (int i = 0; i < 4; i++) begin
        clear_irqs();
        wreg(A_PWPR, {28'h0, bad[i]});
        repeat (20) @(posedge aon_clk);
        rreg(A_PWPR);
        ck(rd[3:0] === PM_ON, $sformatf("policy 0x%01h write-ignored", bad[i]));
        rreg(A_AISR);
        ck(rd[0] === 1'b1, $sformatf("policy 0x%01h raises UNSPT_POLICY_IRQ", bad[i]));
      end
    end
    // WARM_RST: legal static, illegal dynamic -- the same value, both ways
    clear_irqs();
    wreg(A_PWPR, {19'h0, 1'b0, 3'h0, 1'b0, 4'h0, PM_WARM_RST});
    rreg(A_PWPR); ck(rd[3:0] === PM_WARM_RST, "WARM_RST accepted as a STATIC policy");
    settle(); go(PM_ON); clear_irqs();
    wreg(A_PWPR, {19'h0, 1'b0, 3'h0, 1'b1, 4'h0, PM_WARM_RST});
    repeat (20) @(posedge aon_clk);
    rreg(A_PWPR); ck(rd[3:0] === PM_ON, "WARM_RST rejected as a DYNAMIC policy");
    rreg(A_AISR); ck(rd[0] === 1'b1, "...and raises UNSPT_POLICY_IRQ");
    clear_irqs();

    // =======================================================================
    section("4.1 PWPR / PWSR / UNLK");
    // PPU_PWPR cannot be probed with an all-ones write the way the other
    // registers can: 0xFFFFFFFF carries policy 0xF, which is an unsupported
    // encoding, so the write is rejected WHOLESALE -- LOCK_EN and PWR_DYN_EN
    // included -- and the register keeps its old value. That is the document's
    // own point that the register "is written at once", and it makes an
    // all-ones probe measure rejection rather than the writable mask. Probe with
    // a supported policy in the low nibble instead.
    wreg(A_PWPR, 32'hFFFF_FFFF);
    rreg(A_PWPR);
    ck(rd === 32'h0000_0008,
       "an unsupported policy rejects the WHOLE PPU_PWPR write, not just the policy");
    wreg(A_PWPR, 32'hFFFF_FFF8);          // all ones, but policy = ON
    rreg(A_PWPR);
    ck(rd === 32'h0000_1108, "PPU_PWPR writable bits are [12], [8], [3:0]");
    wreg(A_PWPR, 32'h0000_0008);
    settle();
    go(PM_ON); clear_irqs();
    rreg(A_PWSR);
    ck(rd[3:0] === PM_ON, "PPU_PWSR.PWR_STATUS reports the current mode");
    ck(rd[8]   === 1'b0,  "PPU_PWSR.PWR_DYN_STATUS clear while static");
    ck(rd[12]  === 1'b0,  "PPU_PWSR.LOCK_STATUS clear while unlocked");
    ck_reg(A_UNLK, 32'h0, "PPU_UNLK reads zero (write-only strobe)");
    wreg(A_UNLK, 32'h1);
    ck_reg(A_UNLK, 32'h0, "PPU_UNLK still reads zero after writing 1");

    // =======================================================================
    section("4.2 DISR / MISR");
    @(negedge dclk) wake = 1'b1;  repeat (60) @(posedge aon_clk);
    rreg(A_DISR); ck(rd[0] === 1'b1, "PPU_DISR[0] follows DEVQACTIVE");
    // the doc's claim: DISR shows the RAW input, before PWR_DEVACTIVEEN
    wreg(A_PWCR, 32'h0000_0001);          // PWR_DEVACTIVEEN = 0
    repeat (40) @(posedge aon_clk);
    rreg(A_DISR);
    ck(rd[0] === 1'b1, "PPU_DISR still HIGH with PWR_DEVACTIVEEN=0 (raw input)");
    wreg(A_PWCR, 32'h0000_0101);
    @(negedge dclk) wake = 1'b0;  repeat (60) @(posedge aon_clk);
    rreg(A_DISR); ck(rd[0] === 1'b0, "PPU_DISR[0] drops with DEVQACTIVE");
    rreg(A_MISR);
    ck(rd[31:24] === 8'h0 && rd[7:1] === 7'h0, "PPU_MISR reserved fields read zero");

    // Walk PPU_MISR against its pins through a PCSM handshake (drives
    // PCSMPACCEPT) and a denied departure from ON (drives DEVQDENY).
    repeat (6) sample_misr();
    wreg(A_PWPR, {28'h0, PM_OFF});             // PCSM handshake in both directions
    repeat (40) sample_misr();
    wreg(A_PWPR, {28'h0, PM_ON});
    repeat (40) sample_misr();
    settle();

    // Section 3.4.1: a disabled DEVACTIVE input "is always assumed to be LOW for
    // the purposes of transition control", so clearing PWR_DEVACTIVEEN lets the
    // PPU commit to the descent and gives the device something to refuse. Left
    // enabled, the busy workload would drive DEVQACTIVE and the PPU would ask
    // for ON instead of being denied on the way down -- and DEVQDENY would
    // never assert at all.
    wreg(A_PWCR, 32'h0000_0001);               // PWR_DEVACTIVEEN = 0
    deny_enb = 1'b1;
    @(negedge dclk); work_len = 8'd60; light_work = 1'b0; start = 1'b1;
    @(negedge dclk); start = 1'b0;
    while (!busy) @(negedge dclk);
    wreg(A_PWPR, {28'h0, PM_OFF});             // denied: DEVQDENY goes HIGH
    repeat (30) sample_misr();
    deny_enb = 1'b0; light_work = 1'b1;
    wreg(A_PWPR, {28'h0, PM_ON});
    wreg(A_PWCR, 32'h0000_0101);
    settle();
    clear_irqs();

    ck(misr_bad == 0,
       "PPU_MISR tracks its three pins at [16], [8] and [0] on every sample");
    ck(misr_saw_deny, "  ...and DEVQDENY was seen HIGH, so [16] is not vacuous");
    ck(misr_saw_acc,  "  ...and DEVQACCEPTn was seen LOW, so [8] is not vacuous");
    ck(misr_saw_pa,   "  ...and PCSMPACCEPT was seen HIGH, so [0] is not vacuous");

    // =======================================================================
    section("4.3 PWCR / PTCR");
    ck_wmask(A_PWCR, 32'h0000_0101, "PPU_PWCR writable bits are [8] and [0]");
    ck_wmask(A_PTCR, 32'h0000_0001, "PPU_PTCR writable bit is [0]");
    // DEVREQEN = 0 -> DEVQREQn driven permanently HIGH
    go(PM_ON);
    wreg(A_PWCR, 32'h0000_0100);          // DEVREQEN = 0
    go(PM_OFF);
    ck(dev_qreqn === 1'b1, "DEVREQEN=0 holds DEVQREQn HIGH through a transition");
    ck(pwr_status === PM_OFF, "...and the transition still completes");
    go(PM_ON);
    wreg(A_PWCR, 32'h0000_0101);
    clear_irqs();

    // =======================================================================
    section("4.4 Interrupts");
    ck_wmask(A_IMR,  32'h0000_0027, "PPU_IMR writable bits [5], [2:0]");
    ck_wmask(A_AIMR, 32'h0000_0007, "PPU_AIMR writable bits [2:0]");
    wreg(A_IMR, 32'h0000_0022); wreg(A_AIMR, 32'h0000_0006);
    // AIMR[4:3] reserved -- the doc's STA_POLICY_PWR/OP claim
    rreg(A_AIMR); ck(rd[4:3] === 2'b00, "PPU_AIMR[4:3] read zero (reserved)");
    rreg(A_AISR); ck(rd[4:3] === 2'b00, "PPU_AISR[4:3] read zero (reserved)");
    // OTHER_IRQ is derived from PPU_AISR and cannot be cleared directly
    clear_irqs();
    wreg(A_PWPR, {28'h0, 4'd1});          // unsupported -> sets AISR[0]
    repeat (20) @(posedge aon_clk);
    rreg(A_ISR);  ck(rd[7] === 1'b1, "PPU_ISR.OTHER_IRQ set while a PPU_AISR bit is set");
    wreg(A_ISR, 32'h0000_0080);           // try to clear OTHER directly
    rreg(A_ISR);  ck(rd[7] === 1'b1, "OTHER_IRQ not clearable directly (derived)");
    wreg(A_AISR, 32'h0000_0001);
    rreg(A_ISR);  ck(rd[7] === 1'b0, "OTHER_IRQ follows once PPU_AISR is cleared");
    ck(irq === 1'b0, "IRQ drops when both status registers are empty");
    // masking suppresses the STATUS BIT itself
    wreg(A_AIMR, 32'h0000_0007);          // mask UNSPT_POLICY
    wreg(A_PWPR, {28'h0, 4'd1});
    repeat (20) @(posedge aon_clk);
    rreg(A_AISR); ck(rd[0] === 1'b0, "a masked event does not set its status bit");
    ck(irq === 1'b0, "...and raises no interrupt");
    wreg(A_AIMR, 32'h0000_0006);
    // IESR encodings
    ck_wmask(A_IESR, 32'h0000_0003, "PPU_IESR writable bits [1:0] (one channel)");

    // Section 4.1.3, and the one documented claim that had no positive check
    // anywhere -- only the indirect evidence of a mutation being killed:
    // "These enables have no effect on the generation of interrupts. If an
    // interrupt for a DEVACTIVE is unmasked it still generates an interrupt
    // event when the input changes."
    //
    // So a DEVQACTIVE edge must still set PPU_ISR[8] with PWR_DEVACTIVEEN
    // CLEARED -- the enable governs transitions, not reporting.
    @(negedge dclk) wake = 1'b0; repeat (60) @(posedge aon_clk);
    wreg(A_IESR, 32'h0000_0003);          // edge sensitivity: both
    wreg(A_PWCR, 32'h0000_0001);          // PWR_DEVACTIVEEN = 0, DEVREQEN = 1
    clear_irqs();
    rreg(A_ISR); ck(rd[8] === 1'b0, "no edge event pending before the toggle");
    @(negedge dclk) wake = 1'b1; repeat (80) @(posedge aon_clk);
    rreg(A_ISR);
    ck(rd[8] === 1'b1,
       "a DEVQACTIVE edge still raises PWR_ACTIVE_EDGE_IRQ with PWR_DEVACTIVEEN=0");
    ck(irq === 1'b1, "...and the interrupt output follows");
    @(negedge dclk) wake = 1'b0; repeat (60) @(posedge aon_clk);
    wreg(A_PWCR, 32'h0000_0101);
    wreg(A_IESR, 32'h0000_0000);
    clear_irqs();

    // =======================================================================
    section("4.5 Retention / PCSMPSTATE");
    go(PM_ON);
    wreg(A_FUNRR, 32'h0000_0071);
    wreg(A_FULRR, 32'h0000_00B2);
    wreg(A_MEMRR, 32'h0000_00E3);
    ck_reg(A_FUNRR, 32'h0000_0071, "PPU_FUNRR is 8 bits wide");
    go(PM_FUNC_RET); ck(pcsm_pstate === 16'h7107, "FUNC_RET -> PCSMPSTATE 0x7107");
    go(PM_ON);       ck(pcsm_pstate === 16'h0008, "ON -> PCSMPSTATE 0x0008, retain field zero");
    go(PM_FULL_RET); ck(pcsm_pstate === 16'hB205, "FULL_RET -> PCSMPSTATE 0xB205");
    go(PM_ON);
    go(PM_MEM_RET);  ck(pcsm_pstate === 16'hE302, "MEM_RET -> PCSMPSTATE 0xE302");
    go(PM_ON);
    go(PM_MEM_OFF);  ck(pcsm_pstate === 16'h0006, "MEM_OFF -> retain field zero");
    go(PM_ON);
    go(PM_OFF);      ck(pcsm_pstate === 16'h0000, "OFF -> PCSMPSTATE 0x0000");
    go(PM_ON);
    ck(pcsm_pstate[7:4] === 4'h0, "PCSMPSTATE[7:4] permanently zero (no operating modes)");

    // a mid-mode retention write is not re-sent
    go(PM_FUNC_RET);
    wreg(A_FUNRR, 32'h0000_00AA);
    repeat (400) @(posedge aon_clk);
    ck(pcsm_pstate === 16'h7107, "retention write while IN the mode is not re-sent");
    // ...and A -> A does not refresh it, but does raise STA_POLICY_TRN_IRQ
    clear_irqs();
    wreg(A_PWPR, {28'h0, PM_FUNC_RET});
    repeat (400) @(posedge aon_clk);
    ck(pcsm_pstate === 16'h7107, "A -> A does not refresh the retain value");
    ck(seq_busy === 1'b0,       "A -> A runs no transition");
    rreg(A_ISR);
    ck(rd[0] === 1'b1, "A -> A does raise STA_POLICY_TRN_IRQ (4.1.2)");
    go(PM_ON);
    go(PM_FUNC_RET); ck(pcsm_pstate === 16'hAA07, "leaving and re-entering applies the new value");
    go(PM_ON);
    wreg(A_FUNRR, 32'h0); wreg(A_FULRR, 32'h0); wreg(A_MEMRR, 32'h0);
    clear_irqs();

    // =======================================================================
    section("4.6 Timing");
    ck_wmask(A_EDTR0, 32'hFF00_FFFF, "PPU_EDTR0 writable, [23:16] reserved (LOGIC_RET)");
    ck_wmask(A_EDTR1, 32'h0000_FFFF, "PPU_EDTR1 writable bits [15:0]");
    ck_wmask(A_DCDR0, 32'h00FF_FFFF, "PPU_DCDR0 writable bits [23:0]");
    ck_wmask(A_DCDR1, 32'h0000_FFFF, "PPU_DCDR1 writable bits [15:0]");
    wreg(A_EDTR0, 32'h0); wreg(A_EDTR1, 32'h0);
    wreg(A_DCDR0, 32'h0002_0202); wreg(A_DCDR1, 32'h0000_0202);

    // =======================================================================
    $display("");
    $display("==============================================================");
    $display(" ppu_regdoc_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (2000000) @(posedge aon_clk);
    $display(" RESULT: FAIL");
    $fatal(1, "ppu_regdoc_tb watchdog");
  end

endmodule
