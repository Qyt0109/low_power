`timescale 1ns/1ps
// ppu_power_model unit testbench -- one targeted fault per PU rule.
//
// WHY THIS EXISTS
//
// PU1-PU8 were proven as a SET: an early mutation released isolation ahead of
// the PCSM restore and produced a storm of violations, which showed the model
// was wired up and looking at the right signals. It did not show that each rule
// is individually alive, and the rules overlap enough that the distinction
// matters. Disabling PU1 outright and re-applying the fault that trips it, the
// fault is still caught -- by PU8, whose condition covers the same ground. A
// dead rule hides behind its neighbours.
//
// So this file drives ppu_power_model's inputs directly and asserts, for each
// rule, that the rule fires AND which others do. The per-rule tally inside the
// model is what makes that possible; the aggregate counter cannot.
//
// WHY SOME STIMULI TRIP MORE THAN ONE RULE ON PURPOSE
//
// Not every rule can be isolated, and the reason is a property of the rules
// rather than a limitation here:
//
//   PU8 is "the domain is unpowered with isolation inactive", a LEVEL rule.
//   Reaching that state means either dropping the supply while isolation is
//   inactive (PU1) or releasing isolation while unpowered (PU4). There is no
//   third way in, so PU8 can never be the first rule to fire.
//
// Where a rule can be isolated, the check demands exactly it. Where it cannot,
// the check demands the specific expected combination -- which is still a much
// sharper statement than "the total went up".

module ppu_pm_tb;

  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n = 1'b0;

  logic dev_clken = 1'b0, dev_isolaten = 1'b0;
  logic dev_poresetn = 1'b0, dev_warmresetn = 1'b0, dev_retresetn = 1'b0;
  logic logic_on = 1'b0, logic_ret = 1'b0, ram_on = 1'b0, ram_ret = 1'b0;
  logic wl_rst_n = 1'b0;
  logic ret_n    = 1'b1;   // HIGH = no save outstanding, as at reset
  int unsigned viol;

  ppu_power_model u_pm (
    .clk(clk), .rst_n(rst_n),
    .dev_clken(dev_clken), .dev_isolaten(dev_isolaten),
    .dev_poresetn(dev_poresetn), .dev_warmresetn(dev_warmresetn),
    .dev_retresetn(dev_retresetn),
    .logic_on(logic_on), .logic_ret(logic_ret),
    .ram_on(ram_on), .ram_ret(ram_ret), .ret_n(ret_n), .wl_rst_n(wl_rst_n),
    .corrupt(), .iso_clamp(), .ret_valid(), .do_save(), .do_restore(),
    .violations(viol)
  );

  int unsigned checks = 0, errors = 0;
  int unsigned base [1:10];

  task automatic snap();
    for (int i = 1; i <= 10; i++) base[i] = u_pm.viol_rule[i];
  endtask

  // Assert exactly which rules fired since the last snap(), by bit mask.
  task automatic expect_rules(input logic [10:1] mask, input string tag);
    logic [10:1] got;
    string      s_got, s_exp;
    begin
      checks++;
      got = '0;
      for (int i = 1; i <= 10; i++)
        if (u_pm.viol_rule[i] != base[i]) got[i] = 1'b1;
      s_got = ""; s_exp = "";
      for (int i = 1; i <= 10; i++) begin
        if (got[i])  s_got = {s_got, $sformatf("PU%0d ", i)};
        if (mask[i]) s_exp = {s_exp, $sformatf("PU%0d ", i)};
      end
      if (got !== mask) begin
        errors++;
        $display("[%0t] FAIL %0s: fired {%0s}, expected {%0s}", $time, tag, s_got, s_exp);
      end else begin
        $display("[%0t]  ok  %0s: fired exactly {%0s}", $time, tag, s_exp);
      end
    end
  endtask

  // Park in a legal powered, running, out-of-reset state without tripping
  // anything, so each fault starts from the same place.
  task automatic park_on();
    begin
      @(negedge clk);
      logic_on = 1'b1; logic_ret = 1'b0;
      dev_isolaten = 1'b1; dev_clken = 1'b1;
      dev_poresetn = 1'b1; dev_warmresetn = 1'b1; dev_retresetn = 1'b1;
      repeat (3) @(posedge clk);
    end
  endtask

  // Park unpowered-but-retained: supply off, retention on, isolation ACTIVE.
  // pd_unpowered is false here, which is what keeps PU8 out of the way.
  task automatic park_ret();
    begin
      @(negedge clk);
      logic_on = 1'b0; logic_ret = 1'b1;
      dev_isolaten = 1'b0; dev_clken = 1'b0;
      dev_poresetn = 1'b0; dev_warmresetn = 1'b0; dev_retresetn = 1'b0;
      repeat (3) @(posedge clk);
    end
  endtask

  initial begin
    $dumpfile("ppu_pm_tb.vcd");
    $dumpvars(0, ppu_pm_tb);
    $display("==============================================================");
    $display(" ppu_power_model unit test -- one targeted fault per rule");
    $display("==============================================================");

    repeat (3) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    repeat (2) @(posedge clk);

    // ---- PU1: supply removed with isolation inactive ----
    // logic_ret is raised BEFORE the drop, for two reasons: pd_unpowered stays
    // false so PU8 cannot join in, and the rail leads the primary so PU7 does
    // not either. Clock off and resets asserted keep PU2 and PU3 out.
    park_on();
    @(negedge clk) begin dev_clken = 1'b0; dev_poresetn = 1'b0; dev_warmresetn = 1'b0; end
    repeat (2) @(posedge clk);
    @(negedge clk) logic_ret = 1'b1;   // rail up FIRST -- make before break
    repeat (2) @(posedge clk);
    snap();
    @(negedge clk) logic_on = 1'b0;
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0000_0001, "PU1 supply removed, isolation inactive");

    // ---- PU2: supply removed with the clock still enabled ----
    park_on();
    @(negedge clk) begin dev_isolaten = 1'b0; dev_poresetn = 1'b0; dev_warmresetn = 1'b0; end
    repeat (2) @(posedge clk);
    @(negedge clk) logic_ret = 1'b1;   // rail up FIRST -- make before break
    repeat (2) @(posedge clk);
    snap();
    @(negedge clk) logic_on = 1'b0;                               // dev_clken still 1
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0000_0010, "PU2 supply removed, clock still running");

    // ---- PU3: supply removed with the domain not in reset ----
    park_on();
    @(negedge clk) begin dev_isolaten = 1'b0; dev_clken = 1'b0; end
    repeat (2) @(posedge clk);
    @(negedge clk) logic_ret = 1'b1;   // rail up FIRST -- make before break
    repeat (2) @(posedge clk);
    snap();
    @(negedge clk) logic_on = 1'b0;                               // resets still released
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0000_0100, "PU3 supply removed, domain not in reset");

    // ---- PU4: isolation released before the supply returned ----
    park_ret();
    snap();
    @(negedge clk) dev_isolaten = 1'b1;
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0000_1000, "PU4 isolation released with no supply");

    // ---- PU5: clock enabled with no logic supply ----
    park_ret();
    snap();
    @(negedge clk) dev_clken = 1'b1;
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0001_0000, "PU5 clock enabled with no supply");

    // ---- PU6: reset released with no logic supply ----
    // The clock is held ON so the rule's second arm (reset released with the
    // clock disabled) stays out and only the supply arm fires.
    park_ret();
    @(negedge clk) dev_clken = 1'b1;      // trips PU5, so snap AFTER it settles
    repeat (3) @(posedge clk);
    snap();
    @(negedge clk) dev_poresetn = 1'b1;
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0010_0000, "PU6 reset released with no supply");

    // ---- PU6 second arm: reset released with the clock disabled ----
    park_on();
    @(negedge clk) begin dev_clken = 1'b0; dev_poresetn = 1'b0; end
    repeat (3) @(posedge clk);
    snap();
    @(negedge clk) dev_poresetn = 1'b1;   // supply on, clock off
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0010_0000, "PU6 reset released with the clock disabled");

    // ---- PU7: the retention rail must MAKE BEFORE BREAK ----
    // Both directions of the same rule. The old test raised logic_ret while
    // logic_on was still high and expected a violation; that is now the
    // CORRECT sequence -- the overlap is mandatory, and it is the GAP that
    // destroys retained state. See ppu_power_model.sv.
    //
    // Isolation active, clock off and resets asserted keep PU1-PU3 quiet, and
    // logic_ret rising in the same step keeps pd_unpowered false so PU8 stays
    // out. That leaves PU7 alone.
    park_on();
    @(negedge clk) begin dev_isolaten = 1'b0; dev_clken = 1'b0;
                         dev_poresetn = 1'b0; dev_warmresetn = 1'b0; end
    repeat (2) @(posedge clk);
    snap();
    @(negedge clk) begin logic_on = 1'b0; logic_ret = 1'b1; end   // same step: a gap
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0100_0000, "PU7 retention rail rose as the primary fell");

    park_ret();
    snap();
    @(negedge clk) begin logic_on = 1'b1; logic_ret = 1'b0; end   // same step again
    repeat (2) @(posedge clk);
    expect_rules(10'b00_0100_0000, "PU7 retention rail fell as the primary returned");

    // ---- PU8: unpowered with isolation inactive ----
    // Reached the only way it can be: through PU1. The retention supply is
    // raised with the drop (PU1 only), then removed, and PU8 fires on the level
    // with no new edge -- so the snap after the drop isolates it.
    park_on();
    @(negedge clk) begin dev_clken = 1'b0; dev_poresetn = 1'b0; dev_warmresetn = 1'b0; end
    repeat (2) @(posedge clk);
    @(negedge clk) logic_ret = 1'b1;   // rail up first, so PU7 stays out
    repeat (2) @(posedge clk);
    @(negedge clk) logic_on = 1'b0;    // PU1 here
    repeat (3) @(posedge clk);
    snap();
    @(negedge clk) logic_ret = 1'b0;     // now genuinely unpowered, iso inactive
    repeat (2) @(posedge clk);
    expect_rules(10'b00_1000_0000, "PU8 unpowered with isolation inactive");

    // ---- PU9: a save taken with no retention supply ----
    //
    // The defect ppu_pcsm shipped with, in its exact shape: the save taken
    // first and the retention rail arriving a cycle later. Since MEM_RET and OFF
    // stopped saving (Table 3-1: Logic Mode OFF), PU9 is the full rule and
    // fires at the save itself. Isolation active, clock off
    // and resets asserted keep PU1-PU3 out; logic_on stays HIGH throughout so
    // PU7, PU8 and PU10 stay out too.
    park_on();
    @(negedge clk) begin dev_isolaten = 1'b0; dev_clken = 1'b0;
                         dev_poresetn = 1'b0; dev_warmresetn = 1'b0; end
    repeat (2) @(posedge clk);
    snap();
    @(negedge clk) ret_n = 1'b0;       // save FIRST, rail still LOW
    repeat (2) @(posedge clk);
    @(negedge clk) logic_ret = 1'b1;   // rail arrives late -- the violation
    repeat (2) @(posedge clk);
    expect_rules(10'b01_0000_0000, "PU9 retention supply arrived after the save");
    @(negedge clk) begin ret_n = 1'b1; logic_ret = 1'b0; end
    repeat (2) @(posedge clk);

    // ---- PU10: a restore with no logic supply ----
    // The mirror of PU9 on the way back up. logic_ret is raised first so the
    // domain is not unpowered (PU8 out) and the rail leads (PU7 out), then
    // logic_on is dropped and the restore is issued into it.
    park_on();
    @(negedge clk) begin dev_isolaten = 1'b0; dev_clken = 1'b0;
                         dev_poresetn = 1'b0; dev_warmresetn = 1'b0; end
    repeat (2) @(posedge clk);
    @(negedge clk) logic_ret = 1'b1;
    repeat (2) @(posedge clk);
    @(negedge clk) ret_n = 1'b0;       // save, correctly, onto a live rail
    repeat (2) @(posedge clk);
    @(negedge clk) logic_on = 1'b0;
    repeat (2) @(posedge clk);
    snap();
    @(negedge clk) ret_n = 1'b1;       // restore, with no logic supply
    repeat (2) @(posedge clk);
    expect_rules(10'b10_0000_0000, "PU10 restore with no logic supply");

    $display("");
    $display("   per-rule tally:");
    for (int i = 1; i <= 10; i++)
      $display("     PU%0d  %0d", i, u_pm.viol_rule[i]);
    $display("");
    $display("==============================================================");
    $display(" ppu_pm_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (100000) @(posedge clk);
    $display(" RESULT: FAIL");
    $fatal(1, "ppu_pm_tb watchdog");
  end

endmodule
