`timescale 1ns/1ps
// PPU clock-ratio conformance testbench.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Section 4.1.5 "Device Control Delays".
//
// WHY THIS EXISTS
//
// Every other PPU testbench runs at ONE clock ratio: aon_clk 4.3 ns against
// dclk 13.7 ns, so the PPU is about 3.2x faster than the domain it sequences.
// That is a comfortable and realistic choice, and it is also an untested
// assumption baked into every result the suite produces.
//
// Section 4.1.5 says the ratio matters, in as many words:
//
//   "When calculating these settings allowances must be made for differences in
//    clock frequencies between the PPU and the controlled device and any other
//    delays such as re-synchronization... if CLKEN_RST_DLY is used to guarantee
//    that the device reset is LOW for several device clock cycles, the clock
//    enable re-synchronization requirements must be considered. If the clock
//    enable is re-synchronized the clock might not be running as soon as the
//    clock enable is asserted from the PPU, so a larger delay period might need
//    to be used."
//
// Every device control delay is counted in PPU clock cycles (Table 4-5), while
// the thing being spaced lives in the device's clock domain. So the same
// programmed delay means a different amount of DEVICE time at every ratio, and
// the case the spec is really warning about -- a PPU SLOWER than its device --
// has never run here at all.
//
// WHAT IT ASSERTS
//
// Not timing numbers, which are ratio-dependent by definition. Only that the
// PPU still CONFORMS: every mode is reachable, every transition completes, the
// interface protocol holds, and the PPU's own architectural rules hold. Those
// are the properties that must be true at any ratio, and if the sequencer had a
// latent assumption about relative clock speed this is where it would surface as
// a hang or a protocol violation rather than as a slow transition.
//
// EVERY WAIT IS EDGE-COUNTED, NEVER IN NANOSECONDS
//
// The one thing that cannot be reused from ppu_pd_tb: its timeouts are absolute
// times, which silently become too short as soon as the PPU clock slows down. A
// timeout expressed in nanoseconds is a hidden ratio assumption of exactly the
// kind this file exists to remove, so everything here waits on a budget of
// aon_clk edges instead.
//
// RUNNING IT
//
//   make ppuratio                    all four ratios
//   vvp ppu_clkratio_tb +aonhp=10.0 +dclkhp=1.5    one specific ratio
//
// The half-periods are plusargs rather than parameters so one compiled image
// covers every ratio, and the clocks are started from inside an initial block
// after the plusargs are read -- an `always #(var)` would sample the variable at
// time zero, racing whichever initial block sets it.

module ppu_clkratio_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  // Defaults match ppu_pd_tb, so a plain run reproduces the familiar ratio.
  real aon_hp  = 2.15;
  real dclk_hp = 6.85;
  real mclk_hp = 0.50;

  logic aon_clk = 1'b0, dclk = 1'b0, mclk = 1'b0;
  logic aon_rst_n = 1'b0;
  logic mrst_n    = 1'b0;

  logic [11:0] reg_waddr  = 12'h000;

  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0] reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;
  logic [31:0] reg_rdata;
  logic        irq;

  logic             start      = 1'b0;
  logic [CNT_W-1:0] work_len   = '0;
  logic             light_work = 1'b0;
  logic             wake       = 1'b0;
  logic             deny_enb   = 1'b1;

  int unsigned qviol, uviol;
  int unsigned tb_errors = 0, checks = 0;

  // ---------------------------------------------------------------------------
  // Clocks, started only once the plusargs have been read
  // ---------------------------------------------------------------------------
  initial begin
    void'($value$plusargs("aonhp=%f",  aon_hp));
    void'($value$plusargs("dclkhp=%f", dclk_hp));
    // The monitors sample the interface, so their clock has to be comfortably
    // faster than either domain or they would alias the very edges they check.
    mclk_hp = ((aon_hp < dclk_hp) ? aon_hp : dclk_hp) / 4.0;

    $display("");
    $display("==============================================================");
    $display(" PPU clock-ratio run");
    $display("   aon_clk period %0.2f ns   (PPU and PCSM)", aon_hp * 2.0);
    $display("   dclk    period %0.2f ns   (device and workload)", dclk_hp * 2.0);
    $display("   ratio          %0.2f  (>1 = PPU faster than the device)",
             dclk_hp / aon_hp);
    $display("   monitor period %0.2f ns", mclk_hp * 2.0);
    $display("==============================================================");

    fork
      forever #(aon_hp)  aon_clk = ~aon_clk;
      forever #(dclk_hp) dclk    = ~dclk;
      forever #(mclk_hp) mclk    = ~mclk;
    join_none
  end

  // ---------------------------------------------------------------------------
  ppu_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),
    .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_ren(reg_ren), .reg_rdata(reg_rdata), .irq(irq),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(start), .work_len(work_len),
    .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0]  pwr_status = u_top.u_dom.u_ppu.u_seq.pwr_status;
  wire [15:0] hwstat     = u_top.ppuhwstat;
  wire        seq_busy   = (u_top.u_dom.u_ppu.u_seq.state !== 4'd0);
  wire        busy       = u_top.busy;
  // Compared against 1 rather than inverted so that an unpowered PD_DEV reads
  // as "gated" instead of X under "make ppuratiopa" -- u_clkctrl is in the
  // switched domain. Identical to ~en_latch in ordinary simulation. The full
  // reasoning, and the two failures it caused, are in ppu_pd_tb.sv.
  wire        clk_gated  = (u_top.u_dom.u_clkctrl.en_latch !== 1'b1);

  qchannel_monitor u_qmon (
    .clk(mclk), .rst_n(mrst_n),
    .crst_n(aon_rst_n), .drst_n(u_top.u_dom.dev_rst_in_n), .clk_gated(clk_gated),
    .qreqn(u_top.u_dom.dev_qreqn), .qacceptn(u_top.u_dom.dev_qacceptn),
    .qdeny(u_top.u_dom.dev_qdeny), .violations(qviol)
  );

  ppu_monitor u_umon (
    .clk(mclk), .rst_n(mrst_n), .ppu_rst_n(aon_rst_n),
    .ppuhwstat(hwstat),
    .dev_clken(u_top.u_dom.dev_clken), .dev_isolaten(u_top.dev_isolaten),
    .dev_poresetn(u_top.u_dom.dev_poresetn), .dev_warmresetn(u_top.u_dom.dev_warmresetn),
    .dev_retresetn(u_top.u_dom.dev_retresetn),
    .pcsm_pstate(u_top.u_dom.pcsm_pstate), .pcsm_preq(u_top.u_dom.pcsm_preq),
    .dev_qreqn(u_top.u_dom.dev_qreqn), .dev_qacceptn(u_top.u_dom.dev_qacceptn),
    .dev_qdeny(u_top.u_dom.dev_qdeny),
    .violations(uviol)
  );

  // ---------------------------------------------------------------------------
  // Helpers -- every budget is in aon_clk EDGES, never nanoseconds
  // ---------------------------------------------------------------------------
  task automatic check(input bit cond, input string tag);
    begin
      checks++;
      if (!cond) begin tb_errors++; $display("[%0t] FAIL %0s", $time, tag); end
      else            $display("[%0t]  ok  %0s", $time, tag);
    end
  endtask

  task automatic reg_write(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk);
      reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk);
      reg_wen = 1'b0;
    end
  endtask

  task automatic set_policy(input logic [3:0] p, input bit dyn);
    reg_write(12'h000, {23'h0, dyn, 4'h0, p});
  endtask

  // Budget generous enough for the slowest leg at any ratio: the PCSM tinit,
  // the PCSM handshake, four device-control delay steps, and a device
  // handshake that costs several DEVICE clocks -- which at a slow-PPU ratio is
  // only a fraction of an aon_clk cycle, and at a fast-PPU ratio is many.
  localparam int unsigned CYC_BUDGET = 4000;

  task automatic wait_mode(input logic [3:0] m, input string tag);
    int unsigned n;
    begin
      n = 0; checks++;
      while (((pwr_status !== m) || seq_busy) && (n < CYC_BUDGET)) begin
        @(posedge aon_clk); n++;
      end
      if ((pwr_status === m) && !seq_busy)
        $display("[%0t]  ok  %0s: reached %0s in %0d PPU cycles",
                 $time, tag, ppu_mode_name(m), n);
      else begin
        tb_errors++;
        $display("[%0t] FAIL %0s: timed out after %0d PPU cycles, stuck in %0s (busy=%0b)",
                 $time, tag, n, ppu_mode_name(pwr_status), seq_busy);
      end
      repeat (6) @(posedge aon_clk);
    end
  endtask

  task automatic wait_busy_edges(input bit val, input string tag);
    int unsigned n;
    begin
      n = 0; checks++;
      while ((busy !== val) && (n < CYC_BUDGET)) begin @(posedge aon_clk); n++; end
      if (busy === val) $display("[%0t]  ok  %0s: busy=%0b", $time, tag, val);
      else begin
        tb_errors++;
        $display("[%0t] FAIL %0s: busy stuck at %0b", $time, tag, busy);
      end
    end
  endtask

  // Enter a mode and confirm the actuation matches it. Same nine-signal vector
  // as ppu_pd_tb's P21, because the whole point is that the ratio must not
  // change WHAT the PPU drives, only when.
  task automatic visit(input logic [3:0] m, input string tag);
    logic [4:0] exp;
    begin
      set_policy(m, 1'b0);
      wait_mode(m, tag);
      exp = ppu_devctl(m);
      check({u_top.u_dom.dev_poresetn, u_top.u_dom.dev_warmresetn, u_top.u_dom.dev_retresetn,
             u_top.u_dom.dev_clken, u_top.dev_isolaten} === exp,
            {tag, ": device controls match the mode"});
      check(hwstat === ppu_hwstat(m), {tag, ": PPUHWSTAT matches the mode"});
    end
  endtask

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("ppu_clkratio_tb.vcd");
    $dumpvars(0, ppu_clkratio_tb);

    // The monitors' own reset is released once, early, and never again.
    repeat (2) @(posedge mclk);
    mrst_n = 1'b1;

    aon_rst_n = 1'b0;
    repeat (10) @(posedge aon_clk);
    @(negedge aon_clk) aon_rst_n = 1'b1;

    $display("");
    $display("[%0t] ---- reset bring-up ----", $time);
    wait_mode(PM_ON, "bringup");
    check(!irq, "default transition raised no interrupt");

    $display("");
    $display("[%0t] ---- every mode, at this ratio ----", $time);
    visit(PM_FUNC_RET, "func_ret");
    visit(PM_ON,       "on_a");
    visit(PM_MEM_OFF,  "mem_off");
    visit(PM_ON,       "on_b");
    visit(PM_FULL_RET, "full_ret");
    visit(PM_ON,       "on_c");
    visit(PM_MEM_RET,  "mem_ret");
    visit(PM_ON,       "on_d");
    visit(PM_OFF,      "off");
    visit(PM_ON,       "on_e");
    visit(PM_WARM_RST, "warm_rst");
    visit(PM_ON,       "on_f");

    $display("");
    $display("[%0t] ---- the direct OFF -> MEM_RET hop ----", $time);
    visit(PM_OFF,     "off2");
    visit(PM_MEM_RET, "mem_ret_direct");
    visit(PM_ON,      "on_g");

    $display("");
    $display("[%0t] ---- an intermediate transition through ON ----", $time);
    visit(PM_FULL_RET, "full_ret2");
    set_policy(PM_MEM_OFF, 1'b0);
    wait_mode(PM_MEM_OFF, "mem_off_via_on");
    visit(PM_ON, "on_h");

    $display("");
    $display("[%0t] ---- dynamic transitions, both directions ----", $time);
    wake = 1'b0;
    set_policy(PM_OFF, 1'b1);
    wait_mode(PM_OFF, "dynamic_off");
    @(negedge dclk) wake = 1'b1;
    wait_mode(PM_ON, "dynamic_on");
    @(negedge dclk) wake = 1'b0;
    wait_mode(PM_OFF, "dynamic_off2");
    @(negedge dclk) wake = 1'b1;
    set_policy(PM_ON, 1'b0);
    wait_mode(PM_ON, "static_on");
    @(negedge dclk) wake = 1'b0;

    $display("");
    $display("[%0t] ---- a device denial ----", $time);
    // PWR_DEVACTIVEEN cleared so the descent is committed to and can be
    // refused; see ppu_pd_tb P5 for why that is the deterministic route.
    reg_write(12'h020, 32'h0000_0001);
    @(negedge dclk); work_len = 8'd40; start = 1'b1;
    @(negedge dclk); start = 1'b0;
    wait_busy_edges(1'b1, "denial.busy");
    set_policy(PM_OFF, 1'b0);
    begin
      int unsigned n;
      n = 0;
      while (!seq_busy && (n < CYC_BUDGET)) begin @(posedge aon_clk); n++; end
      while (seq_busy && (n < CYC_BUDGET)) begin @(posedge aon_clk); n++; end
    end
    check(pwr_status === PM_ON, "denial: PPU stayed in ON");
    wait_busy_edges(1'b0, "denial.drained");
    reg_write(12'h020, 32'h0000_0101);
    set_policy(PM_ON, 1'b0);
    wait_mode(PM_ON, "on_after_denial");

    $display("");
    $display("[%0t] ---- a workload burst actually runs at this ratio ----", $time);
    @(negedge dclk); light_work = 1'b0; work_len = 8'd12; start = 1'b1;
    @(negedge dclk); start = 1'b0;
    wait_busy_edges(1'b1, "burst.busy");
    wait_busy_edges(1'b0, "burst.drained");

    // -------------------------------------------------------------------------
    repeat (40) @(posedge aon_clk);
    $display("");
    $display("==============================================================");
    $display(" ratio %0.2f  (aon %0.2f ns / dclk %0.2f ns)",
             dclk_hp / aon_hp, aon_hp * 2.0, dclk_hp * 2.0);
    $display("   checks run          : %0d", checks);
    $display("   testbench errors    : %0d", tb_errors);
    $display("   qchannel violations : %0d (0 expected)", qviol);
    $display("   ppu violations      : %0d (0 expected)", uviol);
    $display(" RESULT: %0s",
             ((tb_errors == 0) && (qviol == 0) && (uviol == 0)) ? "PASS" : "FAIL");
    $display("==============================================================");
    $display("");
    $finish;
  end

  // Watchdog in aon_clk edges, so it scales with the ratio too. A fixed
  // nanosecond budget would fire spuriously at a slow-PPU ratio, which is
  // precisely the mistake this file exists to avoid making.
  initial begin
    repeat (400000) @(posedge aon_clk);
    $display("");
    $display("[%0t] *** WATCHDOG: 400000 PPU cycles elapsed ***", $time);
    $display("     pwr_status=%0s seq_busy=%0b", ppu_mode_name(pwr_status), seq_busy);
    $finish;
  end

endmodule
