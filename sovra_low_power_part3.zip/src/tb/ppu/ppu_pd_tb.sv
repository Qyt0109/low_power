`timescale 1ns/1ps
// Testbench for the PPU-controlled power domain (ppu_pd_top).
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E). Phase goals follow rtl/ppu/README.md section 10.
//
//   P0  Reset behaviour: the PPU brings the domain up to ON by itself, and the
//       default transition is SILENT (Section 4.2.1).
//   P1  Programmer's model: identification registers describe the PPU that was
//       actually built; writable fields read back; reserved ones read as zero.
//   P2  ON <-> every non-WARM_RST mode, with device-control ORDERING checked on
//       the two hops where the controls actually move (Section 4.1.5).
//   P3  ON <-> WARM_RST with PPU_PTCR.WARM_RST_DEVREQEN both 1 and 0 (Table 4-4).
//   P4  FULL_RET -> MEM_OFF routes through ON: two device-control sequences,
//       one policy-completion interrupt (Section 3.3.2).
//   P5  Device denial: policy reverts, denial interrupt fires, no device
//       control was ever touched (Sections 4.1.1, 4.2.9).
//   P6  The PCSM handshake gates the sequence in both directions (Section 4.1.6).
//   P7  Dynamic transitions driven by DEVQACTIVE, both directions (Section 3.4.3).
//   P8  OFF -> MEM_RET direct: PCSM only, no device interface activity at all
//       (Sections 3.3.2, 4.2.6).
//   P9  Unsupported policy: PPU_PWPR does not update, UNSPT_POLICY_IRQ fires
//       (Section 4.1.1).
//   P10 Lock: a dynamic PPU that reaches OFF stays there through a DEVQACTIVE
//       wake until PPU_UNLK is written (Section 3.4.3).
//
// A Q-Channel protocol monitor runs throughout. It is expected to report
// exactly THREE violations for the whole run -- one in P3, two in P15 -- and
// each is a deliberate, measured result rather than a tolerated failure. Both
// phases baseline the count and assert their exact delta, so any additional
// violation anywhere still fails the summary. See the notes in those phases.
//
// STIMULUS TIMING CONVENTION
// Every DUT input is driven on the NEGEDGE of the clock that samples it, so the
// sampling posedge lands in the middle of the data eye rather than on its edge.
// Same convention as qchannel_pd_tb; the deliberate exception is the gated
// clock edge counter, which must stay on the posedge because counting edges is
// its whole purpose.

module ppu_pd_tb;

  import ppu_pkg::*;
  import qchannel_pkg::*;

  localparam int unsigned CNT_W = 8;

  // Iterations for the constrained-random phase. Overridable with +iters=<n>
  // so the same testbench serves both a regression run and a long soak.
  int unsigned RAND_ITERS = 30;

  // The seven modes this PPU supports, as an index-addressable list so the
  // random phase can pick one without rejection-sampling the encoding space.
  function automatic logic [3:0] rand_supported_mode(input int unsigned i);
    case (i)
      0: return PM_ON;
      1: return PM_FUNC_RET;
      2: return PM_MEM_OFF;
      3: return PM_FULL_RET;
      4: return PM_MEM_RET;
      5: return PM_OFF;
      default: return PM_WARM_RST;
    endcase
  endfunction

  // Independent clocks: PPU/PCSM (always-on) 4.3 ns, device/workload 13.7 ns,
  // monitor 1 ns. The PPU is deliberately the FASTER clock -- a power
  // controller that ran slower than the domain it sequences would make every
  // Section 4.1.5 delay unobservably coarse.
  logic dclk = 1'b0, aon_clk = 1'b0, mclk = 1'b0;
  always #6.85 dclk    = ~dclk;
  always #2.15 aon_clk = ~aon_clk;
  always #0.50 mclk    = ~mclk;

  logic aon_rst_n = 1'b0;

  // Monitor's own operating reset: released once, early, and never again, so
  // its pipeline survives (and can therefore observe) later domain resets.
  logic mrst_n = 1'b0;
  initial begin mrst_n = 1'b0; #1 mrst_n = 1'b1; end

  // Software interface
  logic [11:0] reg_waddr  = 12'h000;
  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0] reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;
  logic [31:0] reg_rdata;
  logic        irq;

  // Workload stimulus
  logic             start      = 1'b0;
  logic [CNT_W-1:0] work_len   = '0;
  logic             light_work = 1'b0;
  logic             wake       = 1'b0;
  logic             deny_enb   = 1'b1;

  int unsigned viol;
  int unsigned tb_errors = 0, checks = 0;

  // ---- Deterministic PRNG for the constrained-random phase ----
  // A hand-rolled xorshift rather than $random or $urandom: it is reproducible
  // across simulators, its whole state is one variable that can be printed and
  // replayed, and it does not depend on which $random implementation a tool
  // ships. A random test whose failing seed cannot be reproduced is not a test.
  int unsigned rseed = 32'h0BAD_C0DE;

  function automatic int unsigned rnd(input int unsigned n);
    rseed = rseed ^ (rseed << 13);
    rseed = rseed ^ (rseed >> 17);
    rseed = rseed ^ (rseed << 5);
    return (n == 0) ? 0 : (rseed % n);
  endfunction
  logic [CNT_W-1:0] frozen_count;   // work_count captured before a power-down

  // ---- Device IP command ----
  // Driven only by P23a, the phase that checks what each mode does to the IP's
  // three classes of state. Every other phase leaves it idle, so the IP behaves
  // exactly as the workload it replaced.
  logic [1:0] ip_cmd  = 2'b00;
  logic [7:0] ip_seed = 8'h00;

  // ---- DUT ----
  ppu_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),
    .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_ren(reg_ren), .reg_rdata(reg_rdata), .irq(irq),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(start), .work_len(work_len),
    .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(ip_cmd), .ip_seed(ip_seed)
  );

  // ---- Observability via hierarchical reference ----
  // ppu_pd_top exposes only real system-level ports, so everything internal is
  // read here rather than routed out as debug pins -- same convention as
  // qchannel_pd_top.
  wire [3:0]  pwr_status    = u_top.u_dom.u_ppu.u_seq.pwr_status;
  wire [15:0] hwstat        = u_top.ppuhwstat;
  wire        dev_clken      = u_top.u_dom.dev_clken;
  wire        dev_isolaten   = u_top.dev_isolaten;
  wire        dev_poresetn   = u_top.u_dom.dev_poresetn;
  wire        dev_warmresetn = u_top.u_dom.dev_warmresetn;
  wire        dev_retresetn  = u_top.u_dom.dev_retresetn;
  wire        dev_qreqn      = u_top.u_dom.dev_qreqn;
  wire        dev_qacceptn   = u_top.u_dom.dev_qacceptn;
  wire        dev_qdeny      = u_top.u_dom.dev_qdeny;
  wire        dev_qactive    = u_top.u_dom.dev_qactive;
  wire [15:0] pcsm_pstate    = u_top.u_dom.pcsm_pstate;
  wire        pcsm_preq      = u_top.u_dom.pcsm_preq;
  wire        pcsm_paccept   = u_top.u_dom.pcsm_paccept;
  // All four PCSM actuation outputs, declared explicitly. logic_ret was
  // originally left out and became an implicit wire reading z, which silently
  // disabled the entire retention model -- caught by the all-modes actuation
  // vector in P21, and a good argument for checking whole vectors rather than
  // the one or two signals a phase happens to care about.
  wire        logic_on      = u_top.logic_on;
  wire        logic_ret     = u_top.logic_ret;
  wire        ram_on        = u_top.u_dom.ram_on;
  wire        ram_ret       = u_top.u_dom.ram_ret;
  wire        busy          = u_top.busy;
  wire [CNT_W-1:0] work_count = u_top.u_ip.u_core.wcnt;
  wire        dummy_clk     = u_top.dummy_clk;
  // en_latch is the clock gate's enable latch, and u_clkctrl is in PD_DEV --
  // the SWITCHED domain. Under power-aware simulation (make ppupa) it reads X
  // the moment the supply is removed, which "~" then propagates. Two things
  // went wrong when this was a plain inversion, both observed:
  //
  //   P22   check(clk_gated) in FULL_RET failed. The gate really was closed;
  //         the probe just could not say so, because the register it reads had
  //         no supply. logic_on=0, logic_ret=1, dev_isolaten=0 -- the design was
  //         doing exactly what Table 3-1 says.
  //
  //   R10   qchannel_monitor triggers on "posedge clk_gated", and in Verilog
  //         x->1 IS a posedge. So every power-UP raised a spurious "resource
  //         gated outside Q_STOPPED", and P30's count of sanctioned violations
  //         went from 2 to 3.
  //
  // Comparing against 1 instead resolves X to "gated", which is the truthful
  // reading: a domain with no supply has no clock. In ordinary simulation
  // en_latch is only ever 0 or 1, so this is identical to ~en_latch and the
  // Icarus and xsim transcripts are unchanged.
  wire        clk_gated     = (u_top.u_dom.u_clkctrl.en_latch !== 1'b1);
  wire        wl_rst_n      = u_top.wl_rst_n;
  wire        wl_ret_rst_n  = u_top.wl_ret_rst_n;

  // ---- Device IP observability ----
  // Read hierarchically rather than through ports, which is this repository's
  // convention -- see qchannel_pd_top's header.
  wire [31:0] sig_nret    = u_top.u_ip.u_core.sig_nret;
  wire [31:0] sig_ret     = u_top.u_ip.u_ret.sig;
  wire [7:0]  ram_bank_ok = u_top.u_ip.u_core.ram_bank_ok;
  wire        dev_rst_in_n  = u_top.u_dom.dev_rst_in_n;

  // S_IDLE is the first value of ppu_seq's state enum, so it encodes as 0.
  // Polling it is what "the sequencer has finished" means; every wait_mode
  // below also requires it, because pwr_status updates on the commit edge and
  // a multi-hop policy is not finished until the FSM is idle as well.
  wire seq_busy = (u_top.u_dom.u_ppu.u_seq.state !== 4'd0);

  // ---- Coverage tally for the constrained-random phase ----
  // A random test that reports "0 errors" while never having generated an
  // interesting stimulus is exactly as worthless as a checker that never
  // fires. These counters exist so the phase can PROVE what it exercised.
  int unsigned cov_mode_sta[0:15];
  int unsigned cov_mode_dyn[0:15];
  int unsigned cov_unspt = 0, cov_lock = 0, cov_burst = 0, cov_waketog = 0;
  int unsigned deny_events = 0;
  always @(posedge dev_qdeny) deny_events = deny_events + 1;

  int unsigned dclk_edges  = 0;
  int unsigned qreqn_edges = 0;
  always @(posedge dummy_clk) dclk_edges  = dclk_edges + 1;
  always @(dev_qreqn)          qreqn_edges = qreqn_edges + 1;

  // ---- Device-control edge timestamps, for the Section 4.1.5 ordering checks ----
  time t_clken_fall, t_iso_fall, t_rst_fall;
  time t_iso_rise, t_clken_rise, t_rst_rise;
  time t_pcsm_done;

  always @(negedge dev_clken)      t_clken_fall = $time;
  always @(negedge dev_isolaten)   t_iso_fall   = $time;
  always @(negedge dev_warmresetn) t_rst_fall   = $time;
  always @(posedge dev_isolaten)   t_iso_rise   = $time;
  always @(posedge dev_clken)      t_clken_rise = $time;
  always @(posedge dev_warmresetn) t_rst_rise   = $time;
  // Taken from the PCSM controller itself: ppu_seq tracks completion through
  // pcsm_cur_state (a level) rather than this pulse, but for a timestamp the
  // pulse is exactly what is wanted.
  always @(posedge u_top.u_dom.u_ppu.u_pcsm.xfer_done) t_pcsm_done = $time;

  task automatic clear_timestamps();
    begin
      t_clken_fall = 0; t_iso_fall   = 0; t_rst_fall   = 0;
      t_iso_rise   = 0; t_clken_rise = 0; t_rst_rise   = 0;
      t_pcsm_done  = 0;
    end
  endtask

  // ---- The same edges, counted in PPU clock cycles ----
  // Timestamps prove ORDER; Table 4-5 constrains SEPARATION ("the minimum
  // number of PPU clock cycles between X and Y is <PARAM> + 1"). Only a cycle
  // count can catch an off-by-one in that "+ 1", and every device control is
  // driven from a register clocked by aon_clk, so sampling a free-running
  // cycle counter at each edge is exact rather than approximate.
  int unsigned aon_cycles = 0;
  always @(posedge aon_clk) aon_cycles = aon_cycles + 1;

  int unsigned c_clken_fall, c_iso_fall, c_rst_fall;
  int unsigned c_iso_rise, c_clken_rise, c_rst_rise;
  always @(negedge dev_clken)      c_clken_fall = aon_cycles;
  always @(negedge dev_isolaten)   c_iso_fall   = aon_cycles;
  always @(negedge dev_warmresetn) c_rst_fall   = aon_cycles;
  always @(posedge dev_isolaten)   c_iso_rise   = aon_cycles;
  always @(posedge dev_clken)      c_clken_rise = aon_cycles;
  always @(posedge dev_warmresetn) c_rst_rise   = aon_cycles;

  // S_DELAY is the second value of ppu_seq's state enum, so it encodes as 1.
  // Measuring how long the FSM occupies it is the only direct observation of
  // the power mode entry delay timer (Section 4.1.3) -- the timer has no
  // externally visible signal of its own.
  wire seq_in_delay = (u_top.u_dom.u_ppu.u_seq.state === 4'd1);
  int unsigned c_delay_enter, c_delay_exit, delay_entries = 0;
  always @(posedge seq_in_delay) begin
    c_delay_enter = aon_cycles;
    delay_entries = delay_entries + 1;
  end
  always @(negedge seq_in_delay) c_delay_exit = aon_cycles;

  // Coverage for the behaviour F7 added, which the original tally predates. A
  // random phase whose counters were written before a rule existed cannot say
  // anything about that rule -- so these measure it directly:
  //
  //   cov_stablock    a STATIC departure from ON held off because DEVQACTIVE was
  //                   HIGH (Section 3.4.2). Zero would mean the storm never
  //                   reached the rule at all.
  //   cov_delay_abort an entry delay timer that started and then abandoned its
  //                   count because the conditions stopped holding
  //                   (Section 4.1.3's "the counter is reset"). Reachable only
  //                   when a non-zero delay overlaps a wake.
  wire seq_sta_block = u_top.u_dom.u_ppu.u_seq.sta_block;
  int unsigned cov_stablock = 0, cov_delay_abort = 0;
  always @(posedge seq_sta_block) cov_stablock = cov_stablock + 1;
  always @(negedge seq_in_delay) begin
    // S_IDLE is state 0: leaving S_DELAY for it means the descent was abandoned
    // rather than started.
    if (u_top.u_dom.u_ppu.u_seq.state === 4'd0) cov_delay_abort = cov_delay_abort + 1;
  end


  // ---------------------------------------------------------------------------
  // Behavioural power intent -- what src/upf/ppu_pd_top.upf would do
  // ---------------------------------------------------------------------------
  // See ppu_power_model.sv. The model decides WHEN the domain is unpowered,
  // clamped or retained; the three procedural blocks below are what actually
  // apply those decisions to the design, because forcing and releasing must
  // happen from a testbench context.
  logic        pm_corrupt, pm_iso_clamp, pm_ret_valid, pm_save, pm_restore;
  int unsigned pm_viol;

  ppu_power_model u_pwr (
    .clk(aon_clk), .rst_n(aon_rst_n),
    .dev_clken(dev_clken), .dev_isolaten(dev_isolaten),
    .dev_poresetn(dev_poresetn), .dev_warmresetn(dev_warmresetn),
    .dev_retresetn(dev_retresetn),
    .logic_on(logic_on), .logic_ret(logic_ret),
    .ram_on(ram_on), .ram_ret(ram_ret),
    .ret_n(u_top.ret_n), .wl_rst_n(wl_rst_n),
    .corrupt(pm_corrupt), .iso_clamp(pm_iso_clamp), .ret_valid(pm_ret_valid),
    .do_save(pm_save), .do_restore(pm_restore),
    .violations(pm_viol)
  );

  // ---- -simstate CORRUPT ----
  // Every register in PD_DEV goes to X while its supply is absent. This is the
  // single most valuable thing the model adds: it is what makes "held in reset"
  // and "lost its power" different values instead of the same one, and it is
  // the reason dummy_workload.cnt's missing reset becomes visible.
  //
  // SCOPE, stated precisely rather than left to be discovered: cnt, busy and
  // done are modelled; cstate is NOT. Its type fsm_t is declared inside
  // dummy_workload, so there is no way to name an X of that type from out here
  // without a cast to a type this scope cannot see. That exclusion costs
  // nothing: every mode that corrupts also asserts the workload's reset, and
  // cstate is one of the signals dummy_workload DOES reset, so it resolves to
  // IDLE either way. cnt is the register that matters, precisely because it is
  // the one with no reset value.
  //
  // THE MODEL HAS THREE STATES, AND THE THIRD ONE IS LOAD-BEARING.
  //
  // Releasing the X the moment the supply returns is wrong, and wrong in a way
  // that wedges the design rather than merely flattering it. On the way up the
  // supply comes back while the domain is STILL IN RESET and STILL UNCLOCKED
  // -- that is the whole point of the Section 4.1.5 ordering -- so a released
  // register keeps its last forced value with nothing to re-drive it. busy
  // stayed X, the device could never report itself idle, and the next
  // quiescence request hung forever.
  //
  // Real flops do not behave that way: ppu_ip_core's are async-reset, so while
  // reset is asserted they hold their RESET value regardless of the clock.
  // PD_RESET_HELD models exactly that.
  //
  // WHAT IS CORRUPTED, AND WHAT IS NOT
  //
  // u_core is on the primary switched supply, so pm_corrupt corrupts it.
  // sig_nret is included because it is the register P23a reads to decide
  // whether the NON-retained class survived a mode, and a model that left it
  // alone would report FULL_RET and MEM_OFF as identical.
  //
  // u_ret is NOT corrupted here. It sits on the retention rail, and losing that
  // rail is a different event from losing the primary one -- SS_RET is present
  // in FULL_RET and absent in MEM_RET/OFF. The block below keys on
  // pm_ret_valid for exactly that reason; collapsing the two would make
  // FULL_RET and MEM_RET look alike again, which is the failure this whole IP
  // was built to make impossible.
  //
  // The RAM is not corrupted by anything here. It is not in the switched domain
  // at all -- see ppu_device_ip -- and its contents are decided by the
  // sleep/shutdown pins in ppu_ip_sram, which are real RTL and need no model.
  localparam int PD_NORMAL = 0, PD_CORRUPTED = 1, PD_RESET_HELD = 2;
  int pd_model_state = PD_NORMAL;

  // Internal state, which never crosses the domain boundary.
  always @(pm_corrupt, wl_rst_n) begin
    if (pm_corrupt) begin
      if (pd_model_state != PD_CORRUPTED) begin
        force u_top.u_ip.u_core.wcnt     = 'x;
        force u_top.u_ip.u_core.done     = 1'bx;
        force u_top.u_ip.u_core.sig_nret = 'x;
        pd_model_state = PD_CORRUPTED;
      end
    end else if (!wl_rst_n) begin
      if (pd_model_state != PD_RESET_HELD) begin
        // Supply back, reset still asserted: every register takes its reset
        // value. Unlike the workload this replaced, that now includes the
        // counter -- ppu_ip_core resets wcnt, which dummy_workload did not.
        force u_top.u_ip.u_core.wcnt     = '0;
        force u_top.u_ip.u_core.done     = 1'b0;
        force u_top.u_ip.u_core.sig_nret = '0;
        pd_model_state = PD_RESET_HELD;
      end
    end else begin
      if (pd_model_state != PD_NORMAL) begin
        release u_top.u_ip.u_core.wcnt;
        release u_top.u_ip.u_core.done;
        release u_top.u_ip.u_core.sig_nret;
        pd_model_state = PD_NORMAL;
      end
    end
  end

  // ---- set_isolation, clamp_value 0 ----
  // busy is the ONE signal that leaves PD_DEV, so corruption and isolation
  // both act on it and a single block has to own it -- two blocks forcing the
  // same signal would just fight.
  //
  // It is driven to what the ALWAYS-ON SIDE should see, which is what the
  // property under test is about. A UPF isolation cell sits at the PD_AON
  // boundary (-location parent), so the observable question is never "what
  // does the unpowered workload emit" but "what do dev_quiescent_busy,
  // dev_quiescent_deny and dev_wake receive":
  //
  //   unpowered + clamped    -> 0   the clamp value; the domain reads quiescent
  //   unpowered + UNCLAMPED  -> X   what escapes when isolation is missing
  //   powered, in reset      -> 0   async reset value
  //   powered, running       -> released, the RTL drives it
  //
  // iso_defeat forces the second case on demand. It exists only so P24 can
  // show the clamp is doing work rather than decorating the netlist, and it is
  // the only way to demonstrate that without deleting the strategy.
  //
  // (An earlier version clamped the three CONSUMERS instead, leaving the
  // producer at X. Icarus honours neither a force on ppu_pd_top's busy
  // variable -- it is driven by a port connection -- nor one on u_dev's input
  // ports, so the clamp silently did nothing and P24 caught that too.)
  logic iso_defeat = 1'b0;
  wire  clamp_active = pm_iso_clamp && !iso_defeat;

  localparam int BND_RELEASED = 0, BND_ZERO = 1, BND_X = 2;
  int bnd_state = BND_RELEASED;

  always @(pm_corrupt, clamp_active, wl_rst_n) begin
    if (pm_corrupt && !clamp_active) begin
      if (bnd_state != BND_X) begin
        force u_top.u_ip.u_core.busy = 1'bx;
        bnd_state = BND_X;
      end
    end else if (pm_corrupt || !wl_rst_n) begin
      if (bnd_state != BND_ZERO) begin
        force u_top.u_ip.u_core.busy = 1'b0;
        bnd_state = BND_ZERO;
      end
    end else begin
      if (bnd_state != BND_RELEASED) begin
        release u_top.u_ip.u_core.busy;
        bnd_state = BND_RELEASED;
      end
    end
  end

  // ---- set_retention ----
  // Saved on entry to the retention supply, put back when the domain's reset
  // releases. See ppu_power_model.sv for why restore is tied to reset release
  // rather than to the supply returning.
  // The element list here mirrors the UPF's: upf/ppu_pd_top.upf retains
  // u_ip/u_ret and NOTHING else, so this models u_ret and nothing else. When
  // the workload was dummy_workload the model retained its counter, because
  // that was the only state there was; ppu_device_ip has a block whose entire
  // purpose is to be the retained one, and pointing the model at anything else
  // would make plain simulation disagree with the power intent about which
  // registers survive FULL_RET -- the exact distinction both exist to draw.
  // ---- Losing the RETENTION rail ----
  // set_retention preserves state only while its retention supply is present.
  // SS_RET is on in FULL_RET and off in MEM_RET and OFF, so retained registers
  // survive the first and are destroyed by the other two. Without this block
  // plain simulation would show u_ret keeping its value through MEM_RET, and
  // FULL_RET would stop being distinguishable from it -- which is the one thing
  // ppu_device_ip exists to prevent.
  //
  // Keyed on pm_corrupt && !pm_ret_valid: the primary supply gone AND the
  // retention supply gone with it.
  localparam int RT_NORMAL = 0, RT_CORRUPTED = 1, RT_RESET_HELD = 2;
  int rt_model_state = RT_NORMAL;

  always @(pm_corrupt, pm_ret_valid, wl_ret_rst_n) begin
    if (pm_corrupt && !pm_ret_valid) begin
      if (rt_model_state != RT_CORRUPTED) begin
        force u_top.u_ip.u_ret.sig    = 'x;
        force u_top.u_ip.u_ret.seed_q = 'x;
        rt_model_state = RT_CORRUPTED;
      end
    end else if (!wl_ret_rst_n) begin
      if (rt_model_state != RT_RESET_HELD) begin
        force u_top.u_ip.u_ret.sig    = '0;
        force u_top.u_ip.u_ret.seed_q = '0;
        rt_model_state = RT_RESET_HELD;
      end
    end else begin
      if (rt_model_state != RT_NORMAL) begin
        release u_top.u_ip.u_ret.sig;
        release u_top.u_ip.u_ret.seed_q;
        rt_model_state = RT_NORMAL;
      end
    end
  end

  logic [31:0] ret_sig;
  logic [7:0]  ret_seed;
  int unsigned restores_done = 0;

  always @(posedge aon_clk) begin
    if (pm_save) begin
      ret_sig  = u_top.u_ip.u_ret.sig;
      ret_seed = u_top.u_ip.u_ret.seed_q;
    end
    if (pm_restore) begin
      force u_top.u_ip.u_ret.sig    = ret_sig;
      force u_top.u_ip.u_ret.seed_q = ret_seed;
      restores_done = restores_done + 1;
      // Held for one device clock so the restored value is what the IP sees on
      // its first live edge, then handed back to the RTL.
      @(posedge dclk);
      release u_top.u_ip.u_ret.sig;
      release u_top.u_ip.u_ret.seed_q;
    end
  end

  // ---- PPU protocol monitor ----
  // Checks the PPU's own architectural rules (Sections 3.3.2, 4.1.4, 4.1.5) on
  // every monitor edge of the whole run, not just at the moments a directed
  // phase samples. It is blind to the sequencer -- it sees only what a
  // neighbouring block sees. See ppu_monitor.sv, and ppu_monitor_negtest.sv for
  // the proof that it can fail.
  int unsigned uviol;
  ppu_monitor u_ppumon (
    .clk(mclk), .rst_n(mrst_n), .ppu_rst_n(aon_rst_n),
    .ppuhwstat(hwstat),
    .dev_clken(dev_clken), .dev_isolaten(dev_isolaten),
    .dev_poresetn(dev_poresetn), .dev_warmresetn(dev_warmresetn),
    .dev_retresetn(dev_retresetn),
    .pcsm_pstate(pcsm_pstate), .pcsm_preq(pcsm_preq),
    .dev_qreqn(dev_qreqn), .dev_qacceptn(dev_qacceptn), .dev_qdeny(dev_qdeny),
    .violations(uviol)
  );

  // ---- Q-Channel protocol monitor on the device interface ----
  // drst_n watches the reset the PPU actually drives into the domain (R8),
  // clk_gated watches the real clock gate (R10).
  // Coverage. Measures the Table 4-14 transition matrix and the Chapter 5 event
  // set over this entire run -- see ppu_coverage.sv for why a mode-entry table
  // is not the same thing as transition coverage.
  ppu_coverage u_cov (
    .clk(aon_clk), .rst_n(aon_rst_n),
    .pwr_status(u_top.u_dom.u_ppu.u_seq.pwr_status),
    .ev_sta_policy_trn(u_top.u_dom.u_ppu.ev_sta_policy_trn),
    .ev_sta_accept   (u_top.u_dom.u_ppu.ev_sta_accept),
    .ev_sta_deny     (u_top.u_dom.u_ppu.ev_sta_deny),
    .ev_locked       (u_top.u_dom.u_ppu.ev_locked),
    .ev_dyn_accept   (u_top.u_dom.u_ppu.ev_dyn_accept),
    .ev_dyn_deny     (u_top.u_dom.u_ppu.ev_dyn_deny),
    .ev_unspt_policy (u_top.u_dom.u_ppu.ev_unspt_policy)
  );

  qchannel_monitor u_mon (
    .clk(mclk), .rst_n(mrst_n),
    .crst_n(aon_rst_n), .drst_n(dev_rst_in_n), .clk_gated(clk_gated),
    .qreqn(dev_qreqn), .qacceptn(dev_qacceptn), .qdeny(dev_qdeny),
    .violations(viol)
  );

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  // P34 observer. Section 4.1.6: the PCSMPSTATE reset value must be "sampled by
  // the PCSM before any other transition is allowed on the interface", so the
  // PPU must not raise PCSMPREQ until the PCSM has finished its tinit. Counted
  // continuously because it is a one-edge event at the very start of the run,
  // long before any phase that could look for it.
  int unsigned preq_before_init = 0;
  always @(posedge pcsm_preq)
    if (!u_top.u_dom.u_ppu.pcsm_init_done) preq_before_init = preq_before_init + 1;

  // P33 observers. Both watch for something that must happen BEFORE something
  // else, which no check on the settled state can see.
  bit watch_off = 1'b0, saw_off = 1'b0;
  always @(posedge aon_clk) if (watch_off && (pwr_status === PM_OFF)) saw_off <= 1'b1;

  // A policy revert landing while the device Q-Channel has not yet recovered to
  // Q_RUN. Sampled continuously because the revert lasts one cycle.
  logic [3:0]  pol_d;
  bit          watch_revert = 1'b0;
  int unsigned early_reverts = 0;
  always @(posedge aon_clk) begin
    if (watch_revert && (u_top.u_dom.u_ppu.u_seq.pwr_policy !== pol_d)
        && !(dev_qreqn && dev_qacceptn && !dev_qdeny))
      early_reverts <= early_reverts + 1;
    pol_d <= u_top.u_dom.u_ppu.u_seq.pwr_policy;
  end

  task automatic check(input bit cond, input string tag);
    checks++;
    if (!cond) begin tb_errors++; $display("[%0t] FAIL %s", $time, tag); end
    else            $display("[%0t]  ok  %s", $time, tag);
  endtask

  // Poll for the workload's busy flag, with a timeout.
  task automatic wait_busy(input bit val, input int limit_ns, input string tag);
    time t0;
    begin
      t0 = $time; checks++;
      while ((busy !== val) && (($time - t0) <= limit_ns)) #1;
      if (busy === val) $display("[%0t]  ok  %s: busy=%0b", $time, tag, val);
      else begin
        tb_errors++;
        $display("[%0t] FAIL %s: busy stuck at %0b", $time, tag, busy);
      end
    end
  endtask

  // ---------------------------------------------------------------------------
  // Device IP helpers
  // ---------------------------------------------------------------------------
  // The signature ppu_ip_core loads into BOTH logic classes on a fill. It is a
  // pure function of the seed, so nothing has to be remembered across a power
  // cycle in order to say what should have survived. Mirrors ip_pattern(seed,
  // 7, 15) in ppu_ip_core -- kept as an independent expression rather than a
  // hierarchical read, so a testbench check cannot be satisfied by the RTL
  // simply agreeing with itself.
  function automatic logic [31:0] ip_expect(input logic [7:0] seed);
    return ({seed, 5'd0, 3'd7, 8'd0, 4'd0, 4'hF}) ^ 32'hA5A5_5A5A;
  endfunction

  // FILL writes the pattern to every word of all eight banks and captures the
  // two logic signatures at the same instant, so one command establishes all
  // three classes of state and the checks afterwards share a reference point.
  task automatic ip_fill(input logic [7:0] seed);
    begin
      @(negedge dclk); ip_seed = seed; ip_cmd = 2'b01;
      @(negedge dclk); ip_cmd = 2'b00;
      // 16 words plus a little slack for the command edge to be seen.
      repeat (20) @(negedge dclk);
    end
  endtask

  // VERIFY reads every bank back and reports per-bank survival. The seed is
  // presented again rather than taken from the IP's retained copy: a mode that
  // lost the retained seed would otherwise fail every bank for a reason that
  // has nothing to do with the RAM.
  task automatic ip_verify(input logic [7:0] seed);
    begin
      @(negedge dclk); ip_seed = seed; ip_cmd = 2'b10;
      @(negedge dclk); ip_cmd = 2'b00;
      repeat (24) @(negedge dclk);
    end
  endtask

  // One mode, one row of the table in ppu_device_ip's header: seed everything
  // in ON, visit the mode, come back, and check what each class of state did.
  //
  // Verification happens after the return to ON because that is the only mode
  // in which the RAM is accessible -- a retained bank holds its contents but
  // cannot be read, which is what "sleep" means on the macro.
  task automatic check_mode_state(input logic [3:0] mode,
                                  input bit exp_nret, input bit exp_ret,
                                  input bit exp_lo,   input bit exp_hi,
                                  input string name);
    logic [7:0] seed;
    begin
      seed = 8'h40 + mode;
      set_policy(PM_ON, 1'b0, 1'b0);
      wait_mode(PM_ON, 20000, {name, ".pre"});
      ip_fill(seed);

      set_policy(mode, 1'b0, 1'b0);
      wait_mode(mode, 20000, {name, ".enter"});
      set_policy(PM_ON, 1'b0, 1'b0);
      wait_mode(PM_ON, 20000, {name, ".exit"});

      ip_verify(seed);

      check((sig_nret === ip_expect(seed)) === exp_nret,
            $sformatf("P23a %0s: non-retained logic %0s", name,
                      exp_nret ? "survived" : "did not survive"));
      check((sig_ret === ip_expect(seed)) === exp_ret,
            $sformatf("P23a %0s: retained logic %0s", name,
                      exp_ret ? "survived" : "did not survive"));
      check((ram_bank_ok[3:0] === 4'hF) === exp_lo,
            $sformatf("P23a %0s: RAM banks 0-3 (ram_cfg set) %0s", name,
                      exp_lo ? "survived" : "did not survive"));
      check((ram_bank_ok[7:4] === 4'hF) === exp_hi,
            $sformatf("P23a %0s: RAM banks 4-7 (ram_cfg clear) %0s", name,
                      exp_hi ? "survived" : "did not survive"));
      $display("[%0t]   %0s: nret=%0b ret=%0b banks=%08b", $time, name,
               (sig_nret === ip_expect(seed)), (sig_ret === ip_expect(seed)),
               ram_bank_ok);
    end
  endtask

  task automatic check_int(input int unsigned got, input int unsigned exp,
                           input string tag);
    checks++;
    if (got !== exp) begin
      tb_errors++;
      $display("[%0t] FAIL %s: got %0d, expected %0d", $time, tag, got, exp);
    end else begin
      $display("[%0t]  ok  %s = %0d", $time, tag, got);
    end
  endtask

  task automatic reg_write(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk);
      reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk);
      reg_wen = 1'b0;
    end
  endtask

  // The read strobe is asserted for one cycle; ppu_regs captures the decode on
  // the posedge inside that cycle, so reg_rdata is valid at the next negedge.
  task automatic reg_read(input logic [11:0] a, output logic [31:0] d);
    begin
      @(negedge aon_clk);
      reg_raddr = a; reg_ren = 1'b1;
      @(negedge aon_clk);
      reg_ren = 1'b0;
      d = reg_rdata;
    end
  endtask

  task automatic check_reg(input logic [11:0] a, input logic [31:0] exp,
                           input string tag);
    logic [31:0] got;
    begin
      reg_read(a, got);
      checks++;
      if (got !== exp) begin
        tb_errors++;
        $display("[%0t] FAIL %s: read 0x%08h, expected 0x%08h", $time, tag, got, exp);
      end else begin
        $display("[%0t]  ok  %s = 0x%08h", $time, tag, got);
      end
    end
  endtask

  // ---------------------------------------------------------------------------
  // The complete actuation vector for every power mode
  // ---------------------------------------------------------------------------
  // Tables 3-1, 4-7, 4-9 and 4-11 in one place, as the testbench's INDEPENDENT
  // statement of what each mode means. It is deliberately a separate transcript
  // of the spec from ppu_pkg's ppu_devctl: if the RTL table and this one were
  // derived from each other, agreeing would prove nothing.
  //
  // Bit order: {clken, isolaten, poresetn, warmresetn, retresetn,
  //             logic_on, logic_ret, ram_on, ram_ret}
  function automatic logic [8:0] expected_actuation(input logic [3:0] m);
    case (m)
      //                    clk iso pore warm retn | lgcON lgcRET ramON ramRET
      PM_ON:       return {1'b1,1'b1,1'b1,1'b1,1'b1, 1'b1, 1'b0, 1'b1, 1'b0};
      // Table 4-9 groups WARM_RST with the emulation modes: DEVPORESETn HIGH,
      // both warm resets LOW. Table 4-8 is why -- DEVWARMRESETn is the warm
      // reset for non-retention registers and DEVRETRESETn for retention ones,
      // so a warm reset asserts both. Table 3-2 note a keeps the PCSM at ON.
      PM_WARM_RST: return {1'b1,1'b1,1'b1,1'b0,1'b0, 1'b1, 1'b0, 1'b1, 1'b0};
      PM_FUNC_RET: return {1'b1,1'b1,1'b1,1'b1,1'b1, 1'b1, 1'b0, 1'b0, 1'b1};
      PM_MEM_OFF:  return {1'b1,1'b1,1'b1,1'b1,1'b1, 1'b1, 1'b0, 1'b0, 1'b0};
      // The only row where a reset is asserted while the domain keeps a supply:
      // non-retained logic resets, retained logic lives on the retention rail.
      PM_FULL_RET: return {1'b0,1'b0,1'b1,1'b0,1'b1, 1'b0, 1'b1, 1'b0, 1'b1};
      PM_MEM_RET:  return {1'b0,1'b0,1'b0,1'b0,1'b0, 1'b0, 1'b0, 1'b0, 1'b1};
      PM_OFF:      return {1'b0,1'b0,1'b0,1'b0,1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
      default:     return 9'b0;
    endcase
  endfunction

  function automatic logic [8:0] actual_actuation();
    return {dev_clken, dev_isolaten, dev_poresetn, dev_warmresetn, dev_retresetn,
            logic_on, logic_ret, ram_on, ram_ret};
  endfunction

  function automatic string actuation_str(input logic [8:0] v);
    return $sformatf("clken=%0b iso_n=%0b pore_n=%0b warm_n=%0b ret_n=%0b | lgc_on=%0b lgc_ret=%0b ram_on=%0b ram_ret=%0b",
                     v[8], v[7], v[6], v[5], v[4], v[3], v[2], v[1], v[0]);
  endfunction

  // Enter a mode and check every power control it implies, all nine at once.
  task automatic check_mode(input logic [3:0] m, input string tag);
    logic [8:0] exp, got;
    begin
      set_policy(m, 1'b0, 1'b0);
      wait_mode(m, 20000, {tag, ".enter"});
      exp = expected_actuation(m);
      got = actual_actuation();
      checks++;
      if (got !== exp) begin
        tb_errors++;
        $display("[%0t] FAIL %s: %0s actuation mismatch", $time, tag, ppu_mode_name(m));
        $display("            expected  %0s", actuation_str(exp));
        $display("            actual    %0s", actuation_str(got));
      end else begin
        $display("[%0t]  ok  %s: %0s -> %0s", $time, tag, ppu_mode_name(m),
                 actuation_str(got));
      end
      // PPUHWSTAT must agree with the mode on every visit, not just once.
      check(hwstat === ppu_hwstat(m), {tag, ": PPUHWSTAT one-hot matches the mode"});
      check($countones(hwstat) == 1,  {tag, ": PPUHWSTAT is exactly one-hot"});
    end
  endtask

  // ---------------------------------------------------------------------------
  // Systematic register conformance sweeps
  // ---------------------------------------------------------------------------
  // Chapter 5 gives every register a Default column and a per-bit Type column.
  // Spot-checking a few of them, which is what the phases below originally did,
  // leaves most of the table unverified -- six registers were never read at all.
  // These two sweeps walk the whole map instead.

  // Every register's RESET value against its Chapter 5 Default. Must run before
  // anything has been written, so it is the first thing P1 does.
  task automatic check_reset_defaults();
    begin
      $display("[%0t]   Sweeping every register's reset value against Chapter 5.", $time);
      // Table 5-13. Reset 0x22 here: LOCKED and STA_ACCEPT masked, STA_DENY and
      // STA_POLICY_TRN enabled. Bits [4:3] are the emulation masks, which the
      // spec defaults to 1 but which are RESERVED on this PPU and so read 0.
      check_reg(A_IMR,   32'h0000_0022, "P1.reset: PPU_IMR");
      // Table 5-14, with [4:3] reserved (no operating modes -- see F2).
      check_reg(A_AIMR,  32'h0000_0006, "P1.reset: PPU_AIMR");
      check_reg(A_ISR,   32'h0000_0000, "P1.reset: PPU_ISR");
      check_reg(A_AISR,  32'h0000_0000, "P1.reset: PPU_AISR");
      check_reg(A_IESR,  32'h0000_0000, "P1.reset: PPU_IESR");
      // Tables 5-19/20/21: all three retention configs reset to 0x00.
      check_reg(A_FUNRR, 32'h0000_0000, "P1.reset: PPU_FUNRR");
      check_reg(A_FULRR, 32'h0000_0000, "P1.reset: PPU_FULRR");
      check_reg(A_MEMRR, 32'h0000_0000, "P1.reset: PPU_MEMRR");
      // Tables 5-22/23: every entry delay resets to 0x00.
      check_reg(A_EDTR0, 32'h0000_0000, "P1.reset: PPU_EDTR0");
      check_reg(A_EDTR1, 32'h0000_0000, "P1.reset: PPU_EDTR1");
      // Tables 5-24/25: these reset to their CONFIGURED defaults, not to zero,
      // so they are the two that would catch a parameter that never reached the
      // register file.
      check_reg(A_DCDR0, 32'h0002_0202, "P1.reset: PPU_DCDR0 = the *_DLY_CFG params");
      check_reg(A_DCDR1, 32'h0000_0202, "P1.reset: PPU_DCDR1 = the *_DLY_CFG params");

      $display("[%0t]   The two RO status registers reflect PINS, so their value is", $time);
      $display("[%0t]   whatever the interface is doing rather than a reset constant.", $time);
      $display("[%0t]   In ON the device sits in Q_RUN, where DEVQACCEPTn is HIGH --", $time);
      $display("[%0t]   so PPU_MISR reads bit 8 SET, and a check expecting 0 here", $time);
      $display("[%0t]   would be wrong about the interface rather than the register.", $time);
      check_reg(A_DISR,  32'h0000_0000, "P1.reset: PPU_DISR -- DEVQACTIVE idle");
      check_reg(A_MISR,  32'h0000_0100, "P1.reset: PPU_MISR -- DEVQACCEPTn HIGH in Q_RUN");
    end
  endtask

  // Every writable register's WRITABLE MASK, by writing all-ones and all-zeros
  // and reading back. This is what proves the reserved bits are genuinely
  // write-ignored rather than merely unused -- Section 5.2's WI/RAZ rule.
  // Self-restoring, so it can run mid-simulation.
  task automatic check_writable_mask(input logic [11:0] a,
                                     input logic [31:0] wmask,
                                     input string name);
    logic [31:0] saved, got;
    begin
      reg_read(a, saved);
      reg_write(a, 32'hFFFF_FFFF);
      reg_read(a, got);
      checks++;
      if (got !== wmask) begin
        tb_errors++;
        $display("[%0t] FAIL P20.mask %0s: all-ones gave 0x%08h, writable mask is 0x%08h",
                 $time, name, got, wmask);
      end else begin
        $display("[%0t]  ok  P20.mask %0s writable = 0x%08h", $time, name, wmask);
      end
      reg_write(a, 32'h0000_0000);
      reg_read(a, got);
      checks++;
      if (got !== 32'h0) begin
        tb_errors++;
        $display("[%0t] FAIL P20.mask %0s: all-zeros gave 0x%08h, expected 0",
                 $time, name, got);
      end
      reg_write(a, saved);                     // put it back
    end
  endtask

  // Program a power policy. Every write goes through PPU_PWPR as a whole
  // register, which is also how the unsupported-policy check in Section 4.1.1
  // sees it: policy and dynamic enable are admitted or refused as a pair.
  task automatic set_policy(input logic [3:0] p, input bit dyn, input bit lock);
    reg_write(A_PWPR, {19'h0, lock, 3'h0, dyn, 4'h0, p});
  endtask

  // Wait for the PPU to settle in a mode: pwr_status matching is necessary but
  // not sufficient, since a multi-hop policy passes THROUGH ON on its way.
  //
  // The settle at the end is not padding. The completion event is raised on the
  // commit edge and takes a further PPU cycle to reach PPU_ISR, so a read
  // issued the instant pwr_status changes captures the register on the very
  // edge the status bit is being written and comes back zero. Software would
  // hit the same race; waiting a few cycles is what "the transition is
  // complete" has to mean for an observer outside the block.
  task automatic wait_mode(input logic [3:0] m, input int limit_ns, input string tag);
    time t0;
    begin
      t0 = $time; checks++;
      while (((pwr_status !== m) || seq_busy) && (($time - t0) < limit_ns)) #1;
      if ((pwr_status === m) && !seq_busy)
        $display("[%0t]  ok  %s: reached %0s", $time, tag, ppu_mode_name(m));
      else begin
        tb_errors++;
        $display("[%0t] FAIL %s: timeout waiting for %0s, stuck in %0s",
                 $time, tag, ppu_mode_name(m), ppu_mode_name(pwr_status));
      end
      repeat (4) @(posedge aon_clk);
    end
  endtask

  // Wait out a transition that does NOT end in a mode change -- a denial. It
  // has to wait for the sequencer to START before waiting for it to finish:
  // polling only for idle returns immediately, because at the moment the
  // policy write lands the sequencer has not yet reacted to it.
  task automatic wait_transition_done(input int limit_ns, input string tag);
    time t0;
    begin
      t0 = $time; checks++;
      while (!seq_busy && (($time - t0) < limit_ns)) #1;
      if (!seq_busy) begin
        tb_errors++;
        $display("[%0t] FAIL %s: no transition ever started", $time, tag);
      end else begin
        while (seq_busy && (($time - t0) < limit_ns)) #1;
        if (seq_busy) begin
          tb_errors++;
          $display("[%0t] FAIL %s: transition never finished", $time, tag);
        end else begin
          $display("[%0t]  ok  %s: transition ran to completion", $time, tag);
        end
      end
      repeat (4) @(posedge aon_clk);
    end
  endtask

  // Check an interrupt status bit, then clear it write-one-to-clear so the next
  // phase starts from a known state.
  task automatic check_irq(input logic [11:0] a, input int unsigned bitno,
                           input bit exp, input string tag);
    logic [31:0] got;
    begin
      reg_read(a, got);
      checks++;
      if (got[bitno] !== exp) begin
        tb_errors++;
        $display("[%0t] FAIL %s: bit %0d = %0b, expected %0b (reg = 0x%08h)",
                 $time, tag, bitno, got[bitno], exp, got);
      end else begin
        $display("[%0t]  ok  %s: bit %0d = %0b", $time, tag, bitno, exp);
      end
      if (got[bitno]) reg_write(a, 32'b1 << bitno);
    end
  endtask

  task automatic clear_all_irq();
    begin
      reg_write(A_ISR,  32'hFFFF_FFFF);
      reg_write(A_AISR, 32'hFFFF_FFFF);
    end
  endtask

  // ---- Current test phase, as ASCII in the waveform ----
  // VCD has no string type, so the phase name lives in a packed byte vector;
  // GTKWave renders it as text once the trace's Data Format is set to ASCII.
  // set_phase truncates from the RIGHT so an over-long name never silently
  // loses the "P7"/"P8" prefix that identifies it.
  localparam int unsigned PHASE_CHARS = 56;
  reg [8*PHASE_CHARS-1:0] test_phase;

  task automatic set_phase(input string name);
    begin
      if (name.len() > PHASE_CHARS)
        $sformat(test_phase, "%-56s", name.substr(0, PHASE_CHARS-1));
      else
        $sformat(test_phase, "%-56s", name);
      $display("\n[%0t] ========== %0s ==========", $time, name);
    end
  endtask

  // ---------------------------------------------------------------------------
  // Stimulus
  // ---------------------------------------------------------------------------
  initial begin
    logic [31:0] rd;
    int unsigned e0, q0;
    int unsigned viol_base, deny_base, stablock_base, delayabort_base;
    logic [31:0] rd32;

    $dumpfile("ppu_pd_tb.vcd");
    $dumpvars(0, ppu_pd_tb);
    if ($value$plusargs("seed=%d",  rseed))      $display("[%0t] seed overridden", $time);
    if ($value$plusargs("iters=%d", RAND_ITERS)) $display("[%0t] iters overridden", $time);

    // -------------------------------------------------------------------------
    set_phase("P0: Reset and Default Transition to ON");
    $display("[%0t]   Goal: DEF_PWR_POLICY=ON, so the PPU must power the domain", $time);
    $display("[%0t]         up and release it from reset with no software help,", $time);
    $display("[%0t]         and Section 4.2.1 says that transition is silent.", $time);
    aon_rst_n = 1'b0;
    #40 @(negedge aon_clk) aon_rst_n = 1'b1;

    $display("[%0t]   Step 1: at reset the PPU reports OFF -- PCSMMODESTAT says the", $time);
    $display("[%0t]           PCSM is OFF, and the device is held quiesced so the", $time);
    $display("[%0t]           interface never claims a running domain with no supply.", $time);
    #1;
    check(pwr_status === PM_OFF,          "P0: PWR_STATUS is OFF at reset");
    check(hwstat === ppu_hwstat(PM_OFF),  "P0: PPUHWSTAT one-hot OFF at reset");
    check(dev_qreqn === 1'b0,              "P0: DEVQREQn LOW (device quiesced) at reset");

    $display("[%0t]   Step 2: the PPU sequences PCSM -> isolation -> clock -> reset.", $time);
    wait_mode(PM_ON, 5000, "P0.bringup");
    check(hwstat === ppu_hwstat(PM_ON),   "P0: PPUHWSTAT one-hot ON");
    check(dev_clken && dev_isolaten && dev_poresetn && dev_warmresetn && dev_retresetn,
                                          "P0: all device controls released in ON");
    check(logic_on,                       "P0: PCSM reports the logic supply on");
    check(dev_qreqn === 1'b1,              "P0: DEVQREQn HIGH -- device un-quiesced");

    e0 = dclk_edges; #200;
    check(dclk_edges > e0,                "P0: workload clock is toggling in ON");

    $display("[%0t]   Step 3: Section 4.2.1 -- 'This default transition does not", $time);
    $display("[%0t]           generate an interrupt event when it completes.'", $time);
    check(!irq,                           "P0: IRQ low after the default transition");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0, "P0: no policy-completion event");

    // -------------------------------------------------------------------------
    set_phase("P1: Programmers Model");
    $display("[%0t]   Goal: the identification registers describe the PPU that was", $time);
    $display("[%0t]         actually built, reserved fields read as zero, and every", $time);
    $display("[%0t]         register's reset value matches its Chapter 5 Default.", $time);

    // Must be first: once anything has been written, reset values are gone.
    check_reset_defaults();

    // Table 5-26 with this PPU's mode set: dynamic support for ON/FUNC_RET/
    // FULL_RET/MEM_OFF/MEM_RET/OFF, static support for those plus WARM_RST,
    // no operating modes, one Q-Channel. DYN_WRM_RST, DYN_LGC_RET,
    // STA_DBG_RECOV and STA_LGC_RET are all 0 -- "Always set to 0b0 for a
    // Q-Channel PPU".
    check_reg(A_IDR0, 32'h1E53_E501, "P1: PPU_IDR0");
    // Table 5-27: OFF->MEM_RET, all three retention registers, lock, software
    // device delays, entry delay timers. Bit 8 (STA_POLICY_PWR_IRQ_SPT) reads
    // 0: Section 4.1.2 makes both policy-split completion events unsupported
    // "when operating modes are not supported", and this PPU has none.
    check_reg(A_IDR1, 32'h0000_1077, "P1: PPU_IDR1");
    // Section 5.2.25: IMPLEMENTER is deliberately not Arm's 0x43B.
    check_reg(A_IIDR, 32'h50C0_1000, "P1: PPU_IIDR (non-Arm IMPLEMENTER)");
    check_reg(A_AIDR, 32'h0000_0011, "P1: PPU_AIDR (architecture v1.1)");

    // PPU_PWSR: ON, static, unlocked.
    check_reg(A_PWSR, 32'h0000_0008, "P1: PPU_PWSR reports ON");
    // Table 5-10: DEVREQEN and PWR_DEVACTIVEEN both reset to 1.
    check_reg(A_PWCR, 32'h0000_0101, "P1: PPU_PWCR enables reset HIGH");

    $display("[%0t]   Section 5.2.6/5.2.15: PPU_STSR and PPU_OPSR are reserved by", $time);
    $display("[%0t]   construction on a single-Q-Channel, no-operating-mode PPU.", $time);
    check_reg(A_STSR, 32'h0, "P1: PPU_STSR reserved, reads zero");
    check_reg(A_OPSR, 32'h0, "P1: PPU_OPSR reserved, reads zero");
    check_reg(A_PMER, 32'h0, "P1: PPU_PMER reserved (no emulation modes)");

    $display("[%0t]   Profile C registers are writable and read back.", $time);
    reg_write(A_DCDR1, 32'h0000_0304);
    check_reg(A_DCDR1, 32'h0000_0304, "P1: PPU_DCDR1 writable");
    reg_write(A_DCDR1, 32'h0000_0202);   // restore the defaults
    reg_write(A_MEMRR, 32'h0000_00A5);
    check_reg(A_MEMRR, 32'h0000_00A5, "P1: PPU_MEMRR writable (retention config)");
    // Entry delays left at zero for the whole run. No phase below exercises a
    // non-zero one, so PPU_EDTR0/1 and the S_DELAY state are built but NOT
    // verified -- recorded as an open item in CONFORMANCE.md rather than left
    // to be discovered from the absence of a check.
    reg_write(A_EDTR0, 32'h0000_0000);

    // -------------------------------------------------------------------------
    set_phase("P2: ON to each mode and back");
    $display("[%0t]   Goal: every direct ON <-> X hop completes, with the device", $time);
    $display("[%0t]         control ordering of Section 4.1.5 where it is visible.", $time);
    clear_all_irq();

    // ---- ON -> OFF: every device control moves, so the full order is checkable.
    $display("[%0t]   ON -> OFF. Departure order: quiesce, clock, isolation,", $time);
    $display("[%0t]   reset, PCSM (Figure 4-24).", $time);
    clear_timestamps();
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 8000, "P2.off");
    check(t_clken_fall != 0 && t_iso_fall > t_clken_fall,
          "P2: isolation asserted AFTER clock enable removed");
    check(t_rst_fall > t_iso_fall,
          "P2: resets asserted AFTER isolation");
    check(t_pcsm_done > t_rst_fall,
          "P2: PCSM handshake completed AFTER the resets");
    check(!dev_clken && !dev_isolaten && !dev_poresetn && !dev_warmresetn && !dev_retresetn,
          "P2: all device controls asserted in OFF (Table 4-7/4-9/4-11)");
    check(!logic_on && !ram_ret, "P2: PCSM has removed logic and RAM supply");
    check(pcsm_pstate[3:0] === PM_OFF, "P2: PCSMPSTATE[3:0] = OFF");
    check(hwstat === ppu_hwstat(PM_OFF), "P2: PPUHWSTAT one-hot OFF");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1, "P2: OFF policy-completion IRQ");

    // ---- OFF -> ON: the mirror-image order.
    $display("[%0t]   OFF -> ON. Return order: PCSM, isolation, clock, reset,", $time);
    $display("[%0t]   then release quiescence (Figure 4-22).", $time);
    clear_timestamps();
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P2.on");
    check(t_pcsm_done != 0 && t_iso_rise > t_pcsm_done,
          "P2: isolation released AFTER the PCSM handshake");
    check(t_clken_rise > t_iso_rise,
          "P2: clock enable asserted AFTER isolation released");
    check(t_rst_rise > t_clken_rise,
          "P2: resets released AFTER the clock enable");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1, "P2: ON policy-completion IRQ");

    // ---- ON -> FULL_RET: logic reset but RAM retained, DEVRETRESETn stays HIGH.
    $display("[%0t]   ON -> FULL_RET. Table 4-11's interesting row: DEVWARMRESETn", $time);
    $display("[%0t]   asserts to reset non-retained logic while DEVRETRESETn and", $time);
    $display("[%0t]   DEVPORESETn stay HIGH so retained state survives.", $time);
    clear_timestamps();
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 8000, "P2.full_ret");
    check(!dev_clken && !dev_isolaten,        "P2: FULL_RET gates the clock and isolates");
    check(!dev_warmresetn,                   "P2: FULL_RET asserts DEVWARMRESETn");
    check(dev_poresetn && dev_retresetn,      "P2: FULL_RET holds DEVPORESETn/DEVRETRESETn HIGH");
    check(ram_ret,                          "P2: PCSM retains the RAM in FULL_RET");
    check(pcsm_pstate[3:0] === PM_FULL_RET,  "P2: PCSMPSTATE[3:0] = FULL_RET");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1, "P2: FULL_RET policy-completion IRQ");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P2.on2");
    clear_all_irq();

    // ---- ON -> FUNC_RET and ON -> MEM_OFF: identical device-control rows to
    // ON, so nothing moves on those wires. What distinguishes them is the PCSM.
    $display("[%0t]   ON -> FUNC_RET. Table 4-7/4-9/4-11 give FUNC_RET the SAME", $time);
    $display("[%0t]   device-control row as ON, so the whole distinction between", $time);
    $display("[%0t]   the two modes lives on the PCSM interface.", $time);
    set_policy(PM_FUNC_RET, 1'b0, 1'b0);
    wait_mode(PM_FUNC_RET, 8000, "P2.func_ret");
    check(dev_clken && dev_isolaten && dev_poresetn && dev_warmresetn && dev_retresetn,
          "P2: FUNC_RET leaves every device control released");
    check(pcsm_pstate[3:0] === PM_FUNC_RET, "P2: PCSMPSTATE[3:0] = FUNC_RET");
    check(logic_on && ram_ret,             "P2: FUNC_RET keeps logic on, RAM retained");

    set_policy(PM_MEM_OFF, 1'b0, 1'b0);
    wait_mode(PM_MEM_OFF, 8000, "P2.mem_off");
    check(pcsm_pstate[3:0] === PM_MEM_OFF,  "P2: MEM_OFF reached via ON");
    check(logic_on && !ram_ret,            "P2: MEM_OFF keeps logic on, RAM off");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P2.on3");

    // ---- ON -> MEM_RET, with the retention configuration written in P1.
    $display("[%0t]   ON -> MEM_RET. PCSMPSTATE[15:8] carries PPU_MEMRR through", $time);
    $display("[%0t]   to the PCSM untouched -- Sections 5.2.16-18 make those bits", $time);
    $display("[%0t]   IMPLEMENTATION DEFINED, so the PPU attaches no meaning to them.", $time);
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    wait_mode(PM_MEM_RET, 8000, "P2.mem_ret");
    check(pcsm_pstate === {8'hA5, 4'h0, PM_MEM_RET},
          "P2: PCSMPSTATE = {PPU_MEMRR, 0, MEM_RET}");
    check(!logic_on && ram_ret,            "P2: MEM_RET powers logic down, retains RAM");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P2.on4");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P3: ON <-> WARM_RST, both DEVREQEN settings");
    $display("[%0t]   Goal: Table 4-4 -- WARM_RST_DEVREQEN independently enables", $time);
    $display("[%0t]         the device handshake for ON <-> WARM_RST.", $time);

    $display("[%0t]   WARM_RST_DEVREQEN=1: the handshake happens, so the device is", $time);
    $display("[%0t]   in Q_STOPPED while DEVWARMRESETn is asserted.", $time);
    check_reg(A_PTCR, 32'h0000_0001, "P3: WARM_RST_DEVREQEN defaults to 1");
    q0 = qreqn_edges;
    set_policy(PM_WARM_RST, 1'b0, 1'b0);
    wait_mode(PM_WARM_RST, 8000, "P3.warm_rst");
    check(qreqn_edges > q0,     "P3: DEVQREQn moved -- handshake performed");
    // Table 4-8: DEVWARMRESETn is the warm reset for non-retention registers
    // and DEVRETRESETn for retention ones, so a warm reset of the component
    // asserts BOTH -- Table 4-9 groups WARM_RST with the emulation modes at
    // DEVPORESETn=1, DEVWARMRESETn=0, DEVRETRESETn=0. Only FULL_RET holds
    // DEVRETRESETn HIGH, because that is the mode whose point is that retained
    // state survives.
    check(!dev_warmresetn && !dev_retresetn,
                                "P3: WARM_RST asserts BOTH warm resets");
    check(dev_poresetn,          "P3: but not DEVPORESETn -- this is not a power-on reset");
    check(dev_clken && dev_isolaten,
                                "P3: WARM_RST leaves the clock and isolation alone");
    check(pcsm_pstate[3:0] === PM_ON,
          "P3: PCSMPSTATE still ON -- Table 3-2 footnote a, the PCSM has no warm reset");
    check(dev_qacceptn === 1'b0, "P3: device is in Q_STOPPED during the warm reset");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P3.on");
    check(dev_warmresetn,        "P3: DEVWARMRESETn released on return to ON");
    clear_all_irq();

    $display("[%0t]   WARM_RST_DEVREQEN=0: Table 4-4 says NO handshake. The PPU then", $time);
    $display("[%0t]   asserts a device reset while the interface is still in Q_RUN,", $time);
    $display("[%0t]   which is a real AMBA LPI Section 2.1.2 violation ('a controller", $time);
    $display("[%0t]   must only assert a device reset when the interface is in", $time);
    $display("[%0t]   Q_STOPPED') -- and the PPU spec sanctions it anyway, precisely so", $time);
    $display("[%0t]   components with no WARM_RST support can still be warm reset.", $time);
    $display("[%0t]   The monitor is left running to PROVE that is what happens rather", $time);
    $display("[%0t]   than being muted, so the count below is the check.", $time);
    viol_base = viol;
    reg_write(A_PTCR, 32'h0000_0000);
    q0 = qreqn_edges;
    set_policy(PM_WARM_RST, 1'b0, 1'b0);
    wait_mode(PM_WARM_RST, 8000, "P3.warm_rst_nohs");
    check(qreqn_edges == q0,    "P3: DEVQREQn never moved -- handshake skipped");
    check(!dev_warmresetn,       "P3: DEVWARMRESETn still asserted without a handshake");
    check(dev_qreqn === 1'b1 && dev_qacceptn === 1'b1,
                                "P3: interface stayed in Q_RUN throughout");
    #200;
    check(viol == viol_base + 1,
          "P3: monitor saw exactly one R8 -- the sanctioned Table 4-4 exception");
    viol_base = viol;

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P3.on2");
    reg_write(A_PTCR, 32'h0000_0001);   // restore the default
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P4: Intermediate transition routes through ON");
    $display("[%0t]   Goal: Section 3.3.2 -- a Q-Channel PPU 'only transitions", $time);
    $display("[%0t]         between ON and the power mode programmed', so", $time);
    $display("[%0t]         FULL_RET -> MEM_OFF must be two hops, not one.", $time);
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 8000, "P4.full_ret");
    clear_all_irq();

    $display("[%0t]   Now program MEM_OFF from FULL_RET and count the hops.", $time);
    q0 = qreqn_edges;
    set_policy(PM_MEM_OFF, 1'b0, 1'b0);
    wait_mode(PM_MEM_OFF, 12000, "P4.mem_off");
    // FULL_RET -> ON is one exit handshake (QREQn 0->1) and ON -> MEM_OFF is
    // one entry handshake (QREQn 1->0): two edges for two hops. A single
    // direct hop could only ever produce one.
    check(qreqn_edges == q0 + 2,
          "P4: two device handshakes observed -- the hop through ON is real");
    check(pwr_status === PM_MEM_OFF, "P4: landed in MEM_OFF");

    $display("[%0t]   Section 4.1.2: the completion event fires when the mode", $time);
    $display("[%0t]   matches the programmed policy, 'even when this takes more", $time);
    $display("[%0t]   than one transition' -- so the pass through ON is silent.", $time);
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1, "P4: exactly one policy-completion IRQ");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0, "P4: and it was the only one");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P4.on");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P5: Device denial and policy reversion");
    $display("[%0t]   Goal: Sections 4.1.1 and 4.2.9 -- a denied static transition", $time);
    $display("[%0t]         reverts PPU_PWPR.PWR_POLICY to the current mode and", $time);
    $display("[%0t]         raises the denial event.", $time);
    $display("[%0t]   Step 1: clear PWR_DEVACTIVEEN, then start a burst.", $time);
    $display("[%0t]   The enable clear is what makes this DETERMINISTIC, and the", $time);
    $display("[%0t]   reason is worth understanding. Section 3.4.2 forbids the PPU", $time);
    $display("[%0t]   from beginning a departure from ON while DEVQACTIVE is HIGH,", $time);
    $display("[%0t]   and qchannel_device ORs the workload's busy into DEVQACTIVE.", $time);
    $display("[%0t]   So with the input ENABLED a busy workload is never even asked", $time);
    $display("[%0t]   to quiesce, and therefore cannot deny.", $time);
    $display("[%0t]   A denial is then reachable only through the CDC race: busy", $time);
    $display("[%0t]   rises in dclk, but DEVQACTIVE needs a dclk edge plus two", $time);
    $display("[%0t]   aon_clk sync stages to reach the PPU, so a policy write can", $time);
    $display("[%0t]   land inside that window. That race is exactly what the denial", $time);
    $display("[%0t]   mechanism exists FOR -- and far too fragile to test on.", $time);
    $display("[%0t]   Section 3.4.1 gives the deterministic route: a disabled", $time);
    $display("[%0t]   DEVACTIVE input 'is always assumed to be LOW for the purposes", $time);
    $display("[%0t]   of transition control', so the PPU commits and the device gets", $time);
    $display("[%0t]   to refuse.", $time);
    reg_write(A_PWCR, 32'h0000_0001);          // PWR_DEVACTIVEEN = 0
    deny_enb = 1'b1;
    @(negedge dclk); work_len = 8'd60; start = 1'b1;
    @(negedge dclk); start = 1'b0;
    while (!busy) @(negedge dclk);
    check(busy, "P5: workload is busy");

    $display("[%0t]   Step 2: ask for OFF. The device denies on the Q-Channel.", $time);
    clear_timestamps();
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_transition_done(12000, "P5.denial");
    check(pwr_status === PM_ON, "P5: PPU stayed in ON -- the transition was denied");

    $display("[%0t]   Section 4.1.1: 'the policy reverts to the current mode as", $time);
    $display("[%0t]   shown in the Power Status Register'.", $time);
    check_reg(A_PWPR, 32'h0000_0008, "P5: PWR_POLICY reverted to ON");

    $display("[%0t]   The denial happened during the device handshake, which on the", $time);
    $display("[%0t]   departure path runs BEFORE any device control moves -- so there", $time);
    $display("[%0t]   was never anything to reverse.", $time);
    check(t_clken_fall == 0 && t_iso_fall == 0 && t_rst_fall == 0,
          "P5: no clock, isolation or reset control was touched");
    check(dev_clken && dev_isolaten && dev_poresetn && dev_warmresetn,
          "P5: device controls all still in their ON state");
    check(pcsm_pstate[3:0] === PM_ON, "P5: PCSM was never asked to change state");
    check_irq(A_ISR, ISR_STA_DENY, 1'b1, "P5: STA_DENY_IRQ fired");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0, "P5: no completion event for a denial");

    // Let the burst drain before moving on, and restore the enable.
    while (busy) @(negedge dclk);
    reg_write(A_PWCR, 32'h0000_0101);
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P6: PCSM handshake gates the sequence");
    $display("[%0t]   Goal: Section 4.1.6 -- the PPU must wait for PCSMPACCEPT", $time);
    $display("[%0t]         before continuing, in both directions.", $time);
    $display("[%0t]   Departure: the PCSM request is the LAST step, so PCSMPACCEPT", $time);
    $display("[%0t]   arriving is what commits the mode.", $time);
    clear_timestamps();
    set_policy(PM_OFF, 1'b0, 1'b0);

    // Catch the window in which PREQ is up and the mode has not committed.
    begin
      time t0;
      t0 = $time;
      while (!pcsm_preq && ($time - t0) < 8000) #1;
      check(pcsm_preq,                "P6: PCSMPREQ asserted on the way down");
      check(pwr_status === PM_ON,    "P6: mode not committed while PCSMPREQ is outstanding");
    end
    wait_mode(PM_OFF, 8000, "P6.off");
    check(pcsm_pstate[3:0] === PM_OFF, "P6: PCSMPSTATE committed to OFF");

    $display("[%0t]   Return: the PCSM request is the FIRST step, so nothing else", $time);
    $display("[%0t]   may move until it is accepted.", $time);
    clear_timestamps();
    set_policy(PM_ON, 1'b0, 1'b0);
    begin
      time t0;
      t0 = $time;
      while (!pcsm_preq && ($time - t0) < 8000) #1;
      check(pcsm_preq,                "P6: PCSMPREQ asserted on the way up");
      check(!dev_isolaten && !dev_clken,
            "P6: isolation and clock still held while the PCSM request is outstanding");
    end
    wait_mode(PM_ON, 8000, "P6.on");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P7: Dynamic transitions via DEVQACTIVE");
    $display("[%0t]   Goal: Section 3.4.3 -- with PWR_DYN_EN=1 the policy is a", $time);
    $display("[%0t]         MINIMUM. All enabled DEVQACTIVE LOW while in ON starts", $time);
    $display("[%0t]         a move to the policy; any HIGH starts a move back to ON.", $time);
    $display("[%0t]   Note the PPU, not qchannel_controller, acts on DEVQACTIVE:", $time);
    $display("[%0t]   enb_qactive_led_quiescence_exit is tied LOW so the interface", $time);
    $display("[%0t]   cannot leave Q_STOPPED before the supply is back.", $time);
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);

    $display("[%0t]   Step 1: dynamic policy OFF with the domain idle -> descend.", $time);
    set_policy(PM_OFF, 1'b1, 1'b0);
    check_reg(A_PWSR, 32'h0000_0108, "P7: PWR_DYN_STATUS set, still in ON");
    wait_mode(PM_OFF, 8000, "P7.dynamic_off");
    check(!logic_on, "P7: domain powered down by a dynamic transition");

    $display("[%0t]   Step 2: raise wake -> DEVQACTIVE HIGH -> ascend to ON.", $time);
    $display("[%0t]   This is the case qchannel_pd_top could not do: there the", $time);
    $display("[%0t]   wrapper shares the domain reset, so DEVQACTIVE is pinned LOW", $time);
    $display("[%0t]   while the domain is down and wake is inert. Here the wrapper", $time);
    $display("[%0t]   has its own reset, which is only safe because the PPU owns", $time);
    $display("[%0t]   the ordering back up.", $time);
    @(negedge dclk) wake = 1'b1;
    begin
      time t0;
      t0 = $time;
      while (!dev_qactive && ($time - t0) < 3000) #1;
    end
    check(dev_qactive, "P7: DEVQACTIVE rose from a powered-down domain");
    wait_mode(PM_ON, 8000, "P7.dynamic_on");
    check(logic_on && dev_clken && dev_poresetn,
          "P7: domain fully restored before the wake was serviced");
    check_irq(A_AISR, AISR_DYN_ACCEPT, 1'b0,
          "P7: DYN_ACCEPT masked by default (Table 5-14)");

    $display("[%0t]   Step 3: drop wake -> descend again, proving it is a level", $time);
    $display("[%0t]   policy and not a one-shot.", $time);
    @(negedge dclk) wake = 1'b0;
    wait_mode(PM_OFF, 8000, "P7.dynamic_off2");

    $display("[%0t]   Step 4: back to a static ON policy.", $time);
    @(negedge dclk) wake = 1'b1;
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P7.static_on");
    check_reg(A_PWSR, 32'h0000_0008, "P7: PWR_DYN_STATUS cleared");
    @(negedge dclk) wake = 1'b0;
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P8: OFF to MEM_RET direct, PCSM only");
    $display("[%0t]   Goal: Sections 3.3.2 and 4.2.6 -- 'it only needs to complete", $time);
    $display("[%0t]         a PCSM handshake. There is no change in conditions of", $time);
    $display("[%0t]         the reset, isolation and clock enable and no device", $time);
    $display("[%0t]         interface handshake as the logic is off in both.'", $time);
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 8000, "P8.off");
    clear_all_irq();
    clear_timestamps();
    q0 = qreqn_edges;

    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    wait_mode(PM_MEM_RET, 8000, "P8.mem_ret_direct");
    check(qreqn_edges == q0,
          "P8: no device interface activity -- the component never learned");
    check(t_clken_fall == 0 && t_iso_fall == 0 && t_rst_fall == 0 &&
          t_clken_rise == 0 && t_iso_rise == 0 && t_rst_rise == 0,
          "P8: not one device control changed");
    check(pcsm_pstate === {8'hA5, 4'h0, PM_MEM_RET},
          "P8: the whole hop was one PCSM state change");
    check(ram_ret && !logic_on, "P8: RAM now retained, logic still off");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1, "P8: policy-completion IRQ for the direct hop");

    $display("[%0t]   The reverse is NOT direct: Table 4-14 gives MEM_RET only ON as", $time);
    $display("[%0t]   an end mode, so MEM_RET -> OFF routes through ON like anything", $time);
    $display("[%0t]   else -- which means a full device handshake either side.", $time);
    q0 = qreqn_edges;
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 12000, "P8.off_via_on");
    check(qreqn_edges == q0 + 2, "P8: MEM_RET -> OFF took two handshakes, via ON");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P8.on");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P9: Unsupported policy");
    $display("[%0t]   Goal: Section 4.1.1 -- 'the Power Policy Register is not", $time);
    $display("[%0t]         updated and, if unmasked, an unsupported policy", $time);
    $display("[%0t]         interrupt event occurs.'", $time);

    $display("[%0t]   LOGIC_RET (0b0100) is P-Channel only: Table 5-26 hard-wires", $time);
    $display("[%0t]   STA_LGC_RET_SPT to 0 for a Q-Channel PPU.", $time);
    set_policy(PM_LOGIC_RET, 1'b0, 1'b0);
    check_reg(A_PWPR, 32'h0000_0008, "P9: PPU_PWPR unchanged, still ON");
    check_irq(A_AISR, AISR_UNSPT_POLICY, 1'b1, "P9: UNSPT_POLICY_IRQ fired");
    check(pwr_status === PM_ON, "P9: no transition was started");

    $display("[%0t]   Support is a joint property of the policy AND the dynamic", $time);
    $display("[%0t]   enable: WARM_RST is a legal STATIC policy and an illegal", $time);
    $display("[%0t]   DYNAMIC one (Section 3.4.3 excludes it on a Q-Channel PPU).", $time);
    set_policy(PM_WARM_RST, 1'b1, 1'b0);
    check_reg(A_PWPR, 32'h0000_0008, "P9: dynamic WARM_RST refused, PPU_PWPR unchanged");
    check_irq(A_AISR, AISR_UNSPT_POLICY, 1'b1, "P9: UNSPT_POLICY_IRQ fired again");

    set_policy(PM_WARM_RST, 1'b0, 1'b0);
    wait_mode(PM_WARM_RST, 8000, "P9.static_warm_rst");
    check(pwr_status === PM_WARM_RST, "P9: the same value IS accepted as a static policy");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P9.on");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P10: Lock");
    $display("[%0t]   Goal: Section 3.4.3 -- with LOCK_EN and PWR_DYN_EN both set,", $time);
    $display("[%0t]         reaching a lockable mode (OFF or MEM_RET) pins the PPU", $time);
    $display("[%0t]         there 'even if the DEVACTIVE inputs... are requesting a", $time);
    $display("[%0t]         higher priority power mode'.", $time);
    reg_write(A_IMR, 32'h0000_0002);   // unmask LOCKED, keep STA_ACCEPT masked
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);

    set_policy(PM_OFF, 1'b1, 1'b1);
    wait_mode(PM_OFF, 8000, "P10.off");
    check_reg(A_PWSR, 32'h0000_1100, "P10: LOCK_STATUS and PWR_DYN_STATUS both set");
    check_irq(A_ISR, ISR_LOCKED, 1'b1, "P10: LOCKED_IRQ fired");

    $display("[%0t]   Step 2: a DEVQACTIVE wake must NOT revive a locked PPU.", $time);
    @(negedge dclk) wake = 1'b1;
    begin
      time t0;
      t0 = $time;
      while (!dev_qactive && ($time - t0) < 3000) #1;
    end
    check(dev_qactive, "P10: DEVQACTIVE is HIGH");
    #3000;
    check(pwr_status === PM_OFF, "P10: PPU stayed in OFF -- the lock held");
    check(!logic_on,             "P10: domain still powered down");

    $display("[%0t]   Step 3: PPU_UNLK.UNLOCK releases it, and the wake that was", $time);
    $display("[%0t]   held off is serviced immediately.", $time);
    reg_write(A_UNLK, 32'h0000_0001);
    wait_mode(PM_ON, 8000, "P10.unlocked");
    check_reg(A_PWSR, 32'h0000_0108, "P10: LOCK_STATUS cleared, still dynamic");

    @(negedge dclk) wake = 1'b1;
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P10.static");
    @(negedge dclk) wake = 1'b0;

    // -------------------------------------------------------------------------
    set_phase("P11: Device control delay separation");
    $display("[%0t]   Goal: Table 4-5 -- each delay is 'the minimum number of PPU", $time);
    $display("[%0t]         clock cycles between X and Y is <PARAM> + 1'. P2 proved", $time);
    $display("[%0t]         ORDER; this proves SEPARATION, which is the only way to", $time);
    $display("[%0t]         catch an off-by-one in that '+ 1'.", $time);
    $display("[%0t]   Departure delays: CLKEN_ISO_DLY = 7, ISO_RST_DLY = 3.", $time);
    reg_write(A_DCDR1, 32'h0000_0703);
    clear_timestamps();
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 12000, "P11.off");
    check_int(c_iso_fall - c_clken_fall, 8, "P11: DEVCLKEN low -> DEVISOLATEn low (CLKEN_ISO_DLY+1)");
    check_int(c_rst_fall - c_iso_fall,   4, "P11: DEVISOLATEn low -> resets low (ISO_RST_DLY+1)");

    $display("[%0t]   Return delays: ISO_CLKEN_DLY = 5, CLKEN_RST_DLY = 2.", $time);
    reg_write(A_DCDR0, 32'h0002_0502);
    clear_timestamps();
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P11.on");
    check_int(c_clken_rise - c_iso_rise, 6, "P11: DEVISOLATEn high -> DEVCLKEN high (ISO_CLKEN_DLY+1)");
    check_int(c_rst_rise - c_clken_rise, 3, "P11: DEVCLKEN high -> resets high (CLKEN_RST_DLY+1)");

    reg_write(A_DCDR0, 32'h0002_0202);   // restore the elaboration defaults
    reg_write(A_DCDR1, 32'h0000_0202);
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P12: Power mode entry delay timer");
    $display("[%0t]   Goal: Section 4.1.3 -- hysteresis before entering a lower", $time);
    $display("[%0t]         priority mode. Until now every phase ran with the delays", $time);
    $display("[%0t]         at zero, so the S_DELAY state had never executed.", $time);
    check_int(delay_entries, 0, "P12: entry delay state never used by P0-P11");

    $display("[%0t]   Step 1: OFF_DEL = 30, static policy OFF.", $time);
    reg_write(A_EDTR0, 32'h0000_001E);          // OFF_DEL = 30
    check_reg(A_EDTR0, 32'h0000_001E, "P12: PPU_EDTR0.OFF_DEL written");
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 12000, "P12.off");
    check_int(delay_entries, 1, "P12: entry delay timer ran exactly once");
    check_int(c_delay_exit - c_delay_enter, 31, "P12: timer counted OFF_DEL+1 cycles");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P12.on");
    // Section 4.1.3: "Transitions to higher priority power modes always happen
    // as soon as the conditions are met."
    check_int(delay_entries, 1, "P12: no entry delay on the way UP");

    $display("[%0t]   Step 2: the reload rule. Section 4.1.3 -- 'If, while the entry", $time);
    $display("[%0t]   delay timer is counting, conditions change such that the", $time);
    $display("[%0t]   transition being counted should no longer take place, then the", $time);
    $display("[%0t]   counter is reset.' Dynamic policy OFF, then raise wake", $time);
    $display("[%0t]   mid-count: the descent must be abandoned, not merely paused.", $time);
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    set_policy(PM_OFF, 1'b1, 1'b0);

    // Catch the timer mid-flight and break its condition.
    begin
      time t0;
      t0 = $time;
      while (!seq_in_delay && ($time - t0) < 8000) #1;
      check(seq_in_delay, "P12: entry delay timer counting");
      repeat (8) @(posedge aon_clk);        // let it get partway
      @(negedge dclk) wake = 1'b1;
      while (!dev_qactive) @(negedge dclk);
    end
    repeat (60) @(posedge aon_clk);
    check(pwr_status === PM_ON, "P12: descent abandoned -- PPU still in ON");
    check(!seq_in_delay,        "P12: timer no longer counting");

    $display("[%0t]   Step 3: drop wake again. The timer must restart from OFF_DEL,", $time);
    $display("[%0t]   not resume from where it was interrupted.", $time);
    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    wait_mode(PM_OFF, 12000, "P12.dynamic_off");
    check_int(c_delay_exit - c_delay_enter, 31, "P12: timer restarted from full count");

    reg_write(A_EDTR0, 32'h0000_0000);   // back to no hysteresis
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P12.on2");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P13: Input edge interrupt");
    $display("[%0t]   Goal: Section 5.2.14 -- PPU_IESR.DEVACTIVE00_EDGE selects which", $time);
    $display("[%0t]         DEVQACTIVE transitions raise an input edge event. Run with", $time);
    $display("[%0t]         a static ON policy so the edges themselves cause nothing.", $time);
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    clear_all_irq();

    $display("[%0t]   EDGE_NONE (the reset value): no event on either edge.", $time);
    check_reg(A_IESR, 32'h0000_0000, "P13: PPU_IESR resets to EDGE_NONE");
    @(negedge dclk) wake = 1'b1;
    while (!dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b0, "P13: EDGE_NONE, rising edge ignored");
    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b0, "P13: EDGE_NONE, falling edge ignored");

    $display("[%0t]   EDGE_RISE: rising only.", $time);
    reg_write(A_IESR, 32'h0000_0001);
    @(negedge dclk) wake = 1'b1;
    while (!dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b1, "P13: EDGE_RISE fires on the rising edge");
    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b0, "P13: EDGE_RISE ignores the falling edge");

    $display("[%0t]   EDGE_FALL: falling only.", $time);
    reg_write(A_IESR, 32'h0000_0002);
    @(negedge dclk) wake = 1'b1;
    while (!dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b0, "P13: EDGE_FALL ignores the rising edge");
    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b1, "P13: EDGE_FALL fires on the falling edge");

    $display("[%0t]   EDGE_BOTH, with PWR_DEVACTIVEEN CLEARED. Section 4.1.3: the", $time);
    $display("[%0t]   DEVACTIVE enables 'have no effect on the generation of", $time);
    $display("[%0t]   interrupts... This allows DEVACTIVE changes to be monitored by", $time);
    $display("[%0t]   software' -- so the edge event must survive the input being", $time);
    $display("[%0t]   disabled for transition control.", $time);
    reg_write(A_IESR, 32'h0000_0003);
    reg_write(A_PWCR, 32'h0000_0001);          // PWR_DEVACTIVEEN = 0, DEVREQEN = 1
    @(negedge dclk) wake = 1'b1;
    while (!dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b1, "P13: edge event fires with the input disabled");
    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    repeat (4) @(posedge aon_clk);
    check_irq(A_ISR, ISR_PWR_ACTIVE_EDGE, 1'b1, "P13: EDGE_BOTH fires on the falling edge too");

    reg_write(A_IESR, 32'h0000_0000);
    reg_write(A_PWCR, 32'h0000_0101);
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P14: DEVACTIVE enable gates transitions");
    $display("[%0t]   Goal: Section 3.4.1 -- 'Disabled power mode DEVACTIVE inputs are", $time);
    $display("[%0t]         always assumed to be LOW for the purposes of transition", $time);
    $display("[%0t]         control.' So a dynamic PPU with the input disabled must", $time);
    $display("[%0t]         descend even while DEVQACTIVE is HIGH.", $time);
    @(negedge dclk) wake = 1'b1;
    while (!dev_qactive) @(negedge dclk);
    reg_write(A_PWCR, 32'h0000_0001);          // PWR_DEVACTIVEEN = 0
    set_policy(PM_OFF, 1'b1, 1'b0);
    wait_mode(PM_OFF, 12000, "P14.off_despite_wake");
    check(dev_qactive, "P14: DEVQACTIVE was HIGH the whole time");
    check(!logic_on,  "P14: descended anyway -- the disabled input reads as LOW");

    $display("[%0t]   Re-enabling it must be seen as a wake immediately.", $time);
    reg_write(A_PWCR, 32'h0000_0101);
    wait_mode(PM_ON, 12000, "P14.on_after_reenable");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 8000, "P14.static");
    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P15: Device interface channel disabled");
    $display("[%0t]   Goal: Section 4.1.3 -- with PPU_PWCR.DEVREQEN cleared,", $time);
    $display("[%0t]         'DEVQREQn is driven permanently HIGH' and 'transitions", $time);
    $display("[%0t]         continue without issuing requests or waiting for responses", $time);
    $display("[%0t]         on the disabled channels'.", $time);
    $display("[%0t]   The spec's own ordering note is followed here: configure for", $time);
    $display("[%0t]   static transitions and reach the mode first, and be in ON before", $time);
    $display("[%0t]   re-enabling, 'otherwise behavior is UNPREDICTABLE'.", $time);
    $display("[%0t]", $time);
    $display("[%0t]   This is the SECOND sanctioned monitor exception. Removing a", $time);
    $display("[%0t]   domain's clock and asserting its reset with the interface still", $time);
    $display("[%0t]   in Q_RUN breaks AMBA LPI Section 2.1.2 -- but that is precisely", $time);
    $display("[%0t]   what disabling the channel MEANS: software opting the component", $time);
    $display("[%0t]   out of the LPI contract. Measured, not muted.", $time);
    viol_base = viol;
    q0 = qreqn_edges;
    reg_write(A_PWCR, 32'h0000_0100);          // DEVREQEN = 0
    check_reg(A_PWCR, 32'h0000_0100, "P15: DEVREQEN cleared");

    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 12000, "P15.off_no_handshake");
    check(qreqn_edges == q0,   "P15: DEVQREQn never moved");
    check(dev_qreqn === 1'b1,   "P15: DEVQREQn driven permanently HIGH");
    check(!logic_on && !dev_clken && !dev_poresetn,
          "P15: the transition completed regardless -- controls and PCSM sequenced");
    #300;
    check_int(viol - viol_base, 2,
          "P15: monitor saw exactly two -- clock gated (R10) and reset (R8) in Q_RUN");
    viol_base = viol;

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P15.on");
    check(qreqn_edges == q0, "P15: still no handshake on the way back up");
    reg_write(A_PWCR, 32'h0000_0101);          // re-enable, in ON as the spec requires
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P16: Policy written during a transition");
    $display("[%0t]   Goal: Section 4.1 -- 'Software writes to the Power Policy", $time);
    $display("[%0t]         Register (PPU_PWPR) do not interrupt mode transitions.", $time);
    $display("[%0t]         Transitions only end when: the transition completes; the", $time);
    $display("[%0t]         request is denied.'", $time);
    $display("[%0t]   Start ON -> OFF, then reprogram to FULL_RET mid-flight. The hop", $time);
    $display("[%0t]   to OFF must run to completion first, and only then may the PPU", $time);
    $display("[%0t]   set off for FULL_RET -- via ON, since neither end is ON.", $time);
    set_policy(PM_OFF, 1'b0, 1'b0);
    begin
      time t0;
      t0 = $time;
      while (!seq_busy && ($time - t0) < 8000) #1;
      check(seq_busy, "P16: transition to OFF is in flight");
      repeat (3) @(posedge aon_clk);
      set_policy(PM_FULL_RET, 1'b0, 1'b0);     // lands mid-transition
      check(pwr_status === PM_ON, "P16: still in ON when the new policy was written");

      // The in-flight hop must still land in OFF before anything else happens.
      t0 = $time;
      while ((pwr_status !== PM_OFF) && ($time - t0) < 12000) #1;
      check(pwr_status === PM_OFF, "P16: the in-flight hop completed to OFF, not abandoned");
    end
    wait_mode(PM_FULL_RET, 20000, "P16.full_ret");
    check_reg(A_PWSR, 32'h0000_0005, "P16: and then reached the newly written policy");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P16.on");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P17: Interrupt semantics");
    $display("[%0t]   Goal: the three rules of Sections 4.1.2 / 5.2.10 / 5.2.12 that", $time);
    $display("[%0t]         decide what a status bit means.", $time);

    $display("[%0t]   Rule 1 -- masking suppresses the STATUS BIT, not just the output:", $time);
    $display("[%0t]   'When an interrupt event is masked an occurrence of the event", $time);
    $display("[%0t]   does not set the corresponding bit in the interrupt status", $time);
    $display("[%0t]   register.' So unmasking afterwards must NOT reveal it.", $time);
    reg_write(A_IMR, 32'h0000_0023);           // mask STA_POLICY_TRN as well
    set_policy(PM_MEM_OFF, 1'b0, 1'b0);
    wait_mode(PM_MEM_OFF, 12000, "P17.mem_off");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0, "P17: masked event did not set the bit");
    reg_write(A_IMR, 32'h0000_0022);           // unmask again
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0, "P17: and unmasking does not resurrect it");

    $display("[%0t]   Write-one-to-clear: 'A write of 0b0 to a bit has no effect.'", $time);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P17.on");
    reg_read(A_ISR, rd);
    check(rd[ISR_STA_POLICY_TRN] === 1'b1, "P17: completion event set for the unmasked transition");
    reg_write(A_ISR, 32'h0000_0000);           // write zero everywhere
    reg_read(A_ISR, rd);
    check(rd[ISR_STA_POLICY_TRN] === 1'b1, "P17: writing 0 left it set");
    reg_write(A_ISR, 32'b1 << ISR_STA_POLICY_TRN);
    reg_read(A_ISR, rd);
    check(rd[ISR_STA_POLICY_TRN] === 1'b0, "P17: writing 1 cleared it");

    $display("[%0t]   Rule 3 -- OTHER_IRQ is a live summary of PPU_AISR and 'cannot be", $time);
    $display("[%0t]   cleared by writing to this register. It must be cleared by", $time);
    $display("[%0t]   writing to the active event in the Additional Interrupt Status", $time);
    $display("[%0t]   Register.' Raise an AISR-only event to check it.", $time);
    check(!irq, "P17: IRQ low with everything cleared");
    set_policy(PM_LOGIC_RET, 1'b0, 1'b0);      // unsupported -> AISR[0] only
    repeat (4) @(posedge aon_clk);
    reg_read(A_ISR, rd);
    check(rd[ISR_OTHER] === 1'b1, "P17: OTHER_IRQ set by an AISR event");
    check(irq,                    "P17: IRQ asserted");
    reg_write(A_ISR, 32'b1 << ISR_OTHER);      // try to clear it from the wrong register
    reg_read(A_ISR, rd);
    check(rd[ISR_OTHER] === 1'b1, "P17: OTHER_IRQ survived a write to PPU_ISR");
    check(irq,                    "P17: IRQ still asserted -- not all status bits are clear");
    reg_write(A_AISR, 32'b1 << AISR_UNSPT_POLICY);
    reg_read(A_ISR, rd);
    check(rd[ISR_OTHER] === 1'b0, "P17: clearing the AISR event cleared OTHER_IRQ");
    check(!irq,                   "P17: and dropped the interrupt output");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P18: Dynamic transition denial");
    $display("[%0t]   Goal: the dynamic counterpart of P5. Two things differ, and both", $time);
    $display("[%0t]         come from Table 4-1: the event is DYN_DENY rather than", $time);
    $display("[%0t]         STA_DENY, and with PWR_DYN_STATUS set the policy is NOT", $time);
    $display("[%0t]         reverted -- 'None' in the reversion table.", $time);
    $display("[%0t]   Getting here needs both enables in opposition: the workload's", $time);
    $display("[%0t]   busy drives DEVQACTIVE as well as the denial, so with the", $time);
    $display("[%0t]   DEVACTIVE input enabled a busy workload would ask for ON instead", $time);
    $display("[%0t]   of being denied on the way down. Clearing PWR_DEVACTIVEEN lets", $time);
    $display("[%0t]   the PPU commit to the descent and still be refused.", $time);
    reg_write(A_AIMR, 32'h0000_0002);          // unmask DYN_DENY, keep DYN_ACCEPT masked
    reg_write(A_PWCR, 32'h0000_0001);          // PWR_DEVACTIVEEN = 0, channel still enabled
    deny_enb = 1'b1;
    @(negedge dclk); work_len = 8'd12; start = 1'b1;
    @(negedge dclk); start = 1'b0;
    while (!busy) @(negedge dclk);

    set_policy(PM_OFF, 1'b1, 1'b0);
    wait_transition_done(12000, "P18.dynamic_denial");
    check(pwr_status === PM_ON, "P18: descent refused, PPU still in ON");
    check_irq(A_AISR, AISR_DYN_DENY,  1'b1, "P18: DYN_DENY_IRQ fired");
    check_irq(A_ISR,  ISR_STA_DENY,   1'b0, "P18: STA_DENY did NOT -- this was a dynamic transition");
    check_reg(A_PWPR, 32'h0000_0100,
          "P18: policy NOT reverted -- Table 4-1 reverts nothing when PWR_DYN_STATUS is set");

    $display("[%0t]   Once the workload drains the PPU gets its way without software", $time);
    $display("[%0t]   reprogramming anything, which is what makes the non-reversion", $time);
    $display("[%0t]   correct: the policy is a standing minimum, not a one-shot.", $time);
    while (busy) @(negedge dclk);
    wait_mode(PM_OFF, 20000, "P18.off_after_drain");

    reg_write(A_PWCR, 32'h0000_0101);
    reg_write(A_AIMR, 32'h0000_0006);          // restore the reset masks
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P18.on");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P19: Lock corner cases");
    $display("[%0t]   Goal: the parts of Section 3.4.3 that P10 did not reach.", $time);
    reg_write(A_IMR, 32'h0000_0002);           // LOCKED unmasked
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);

    $display("[%0t]   MEM_RET is lockable too, not just OFF.", $time);
    set_policy(PM_MEM_RET, 1'b1, 1'b1);
    wait_mode(PM_MEM_RET, 12000, "P19.mem_ret");
    check_reg(A_PWSR, 32'h0000_1102, "P19: locked in MEM_RET");

    $display("[%0t]   'The PPU is unlocked when... either the PPU_PWPR.LOCK_EN, or the", $time);
    $display("[%0t]   PPU_PWPR.PWR_DYN_EN, is set to 0b0.' Clearing LOCK_EN alone must", $time);
    $display("[%0t]   release it -- PPU_UNLK is not the only way out.", $time);
    set_policy(PM_MEM_RET, 1'b1, 1'b0);        // LOCK_EN = 0, still dynamic
    repeat (6) @(posedge aon_clk);
    check_reg(A_PWSR, 32'h0000_0102, "P19: LOCK_STATUS cleared by clearing LOCK_EN");

    $display("[%0t]   'The PPU locks again when it meets the conditions', so setting", $time);
    $display("[%0t]   LOCK_EN while already sitting in a lockable mode re-locks it", $time);
    $display("[%0t]   without any transition -- the second listed lock condition.", $time);
    clear_all_irq();
    set_policy(PM_MEM_RET, 1'b1, 1'b1);
    repeat (6) @(posedge aon_clk);
    check_reg(A_PWSR, 32'h0000_1102, "P19: re-locked in place by a PPU_PWPR write");
    check_irq(A_ISR, ISR_LOCKED, 1'b1, "P19: LOCKED_IRQ fired again");

    $display("[%0t]   Clearing PWR_DYN_EN is the other release, and it also strands", $time);
    $display("[%0t]   the PPU on a static policy of MEM_RET.", $time);
    set_policy(PM_MEM_RET, 1'b0, 1'b1);        // dynamic off, LOCK_EN still set
    repeat (6) @(posedge aon_clk);
    check_reg(A_PWSR, 32'h0000_0002, "P19: LOCK_STATUS cleared by clearing PWR_DYN_EN");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 12000, "P19.on");
    reg_write(A_IMR, 32'h0000_0022);           // restore the reset masks
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P20: Reserved and unmapped register access");
    $display("[%0t]   Goal: Section 5.2 -- 'All reserved bits are Write Ignored and", $time);
    $display("[%0t]         Read as Zero (WI/RAZ).' A reserved field that quietly", $time);
    $display("[%0t]         stores a value is a forward-compatibility trap.", $time);

    $display("[%0t]   Reserved BITS inside a live register: PPU_PWPR[7:4] and [15:13].", $time);
    reg_write(A_PWPR, 32'h0000_20F8);          // policy ON, plus two reserved fields set
    check_reg(A_PWPR, 32'h0000_0008, "P20: PPU_PWPR reserved bits ignored, policy kept");
    check(pwr_status === PM_ON, "P20: and the PPU stayed in ON");

    $display("[%0t]   Reserved BITS in the interrupt registers. Section 4.1.2 makes", $time);
    $display("[%0t]   the power-policy AND operating-policy completion events", $time);
    $display("[%0t]   unsupported 'when operating modes are not supported', so", $time);
    $display("[%0t]   PPU_AIMR[4:3] and PPU_AISR[4:3] are both reserved here -- with", $time);
    $display("[%0t]   no operating modes the power-policy event would duplicate", $time);
    $display("[%0t]   STA_POLICY_TRN exactly.", $time);
    check_reg(A_AIMR, 32'h0000_0006, "P20: PPU_AIMR resets to DYN_DENY|DYN_ACCEPT masked only");
    reg_write(A_AIMR, 32'h0000_001F);
    check_reg(A_AIMR, 32'h0000_0007, "P20: PPU_AIMR[4:3] write-ignored");
    reg_write(A_AIMR, 32'h0000_0006);          // restore
    reg_write(A_AISR, 32'h0000_0018);
    check_reg(A_AISR, 32'h0000_0000, "P20: PPU_AISR[4:3] cannot be set");

    $display("[%0t]   And the same question asked systematically of every writable", $time);
    $display("[%0t]   register: write all-ones, read back, and the result must equal", $time);
    $display("[%0t]   the writable mask exactly. That is what distinguishes a", $time);
    $display("[%0t]   reserved bit from a merely unused one.", $time);
    check_writable_mask(A_PWCR,  32'h0000_0101, "PPU_PWCR");
    check_writable_mask(A_PTCR,  32'h0000_0001, "PPU_PTCR");
    check_writable_mask(A_IMR,   32'h0000_0027, "PPU_IMR");
    check_writable_mask(A_AIMR,  32'h0000_0007, "PPU_AIMR");
    check_writable_mask(A_IESR,  32'h0000_0003, "PPU_IESR");
    check_writable_mask(A_FUNRR, 32'h0000_00FF, "PPU_FUNRR");
    check_writable_mask(A_FULRR, 32'h0000_00FF, "PPU_FULRR");
    check_writable_mask(A_MEMRR, 32'h0000_00FF, "PPU_MEMRR");
    // PPU_EDTR0[23:16] is LOGIC_RET_DEL -- reserved, no LOGIC_RET here.
    check_writable_mask(A_EDTR0, 32'hFF00_FFFF, "PPU_EDTR0");
    check_writable_mask(A_EDTR1, 32'h0000_FFFF, "PPU_EDTR1");
    check_writable_mask(A_DCDR0, 32'h00FF_FFFF, "PPU_DCDR0");
    check_writable_mask(A_DCDR1, 32'h0000_FFFF, "PPU_DCDR1");

    $display("[%0t]   Reserved REGISTERS: writes ignored, reads zero.", $time);
    reg_write(A_STSR, 32'hFFFF_FFFF);
    check_reg(A_STSR, 32'h0, "P20: PPU_STSR still reads zero after a write");
    reg_write(A_OPSR, 32'hFFFF_FFFF);
    check_reg(A_OPSR, 32'h0, "P20: PPU_OPSR still reads zero after a write");
    reg_write(A_PMER, 32'hFFFF_FFFF);
    check_reg(A_PMER, 32'h0, "P20: PPU_PMER still reads zero after a write");

    $display("[%0t]   PPU_UNLK is write-only: 'A read always returns 0b0.'", $time);
    check_reg(A_UNLK, 32'h0, "P20: PPU_UNLK reads zero");

    $display("[%0t]   Unmapped addresses, and the identification registers are RO.", $time);
    reg_write(12'h0C0, 32'hFFFF_FFFF);
    check_reg(12'h0C0, 32'h0, "P20: unmapped address reads zero");
    reg_write(A_IDR0, 32'hFFFF_FFFF);
    check_reg(A_IDR0, 32'h1E53_E501, "P20: PPU_IDR0 is read-only");
    reg_write(A_AIDR, 32'hFFFF_FFFF);
    check_reg(A_AIDR, 32'h0000_0011, "P20: PPU_AIDR is read-only");

    $display("[%0t]   Reserved bits in the delay registers too: PPU_EDTR1[31:16] and", $time);
    $display("[%0t]   PPU_EDTR0[23:16] (LOGIC_RET_DEL -- no LOGIC_RET on a Q-Channel PPU).", $time);
    reg_write(A_EDTR1, 32'hFFFF_1234);
    check_reg(A_EDTR1, 32'h0000_1234, "P20: PPU_EDTR1 upper half reserved");
    reg_write(A_EDTR0, 32'h00FF_0000);
    check_reg(A_EDTR0, 32'h0000_0000, "P20: PPU_EDTR0.LOGIC_RET_DEL reserved");
    reg_write(A_EDTR1, 32'h0000_0000);
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P21: Full actuation vector, every power mode");
    $display("[%0t]   Goal: for each of the seven modes, check ALL NINE power", $time);
    $display("[%0t]         controls at once -- clock gate, isolation, three", $time);
    $display("[%0t]         resets, both logic supplies and both RAM states --", $time);
    $display("[%0t]         against Tables 3-1, 4-7, 4-9 and 4-11.", $time);
    $display("[%0t]   Earlier phases checked these piecemeal and only on the modes", $time);
    $display("[%0t]   where a signal happened to move. This checks the whole vector", $time);
    $display("[%0t]   every time, so a control that is right by accident in one mode", $time);
    $display("[%0t]   and wrong in another cannot hide.", $time);
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);

    check_mode(PM_ON,       "P21.on");
    check_mode(PM_FUNC_RET, "P21.func_ret");
    check_mode(PM_ON,       "P21.on_a");
    check_mode(PM_MEM_OFF,  "P21.mem_off");
    check_mode(PM_ON,       "P21.on_b");
    check_mode(PM_FULL_RET, "P21.full_ret");
    check_mode(PM_ON,       "P21.on_c");
    check_mode(PM_MEM_RET,  "P21.mem_ret");
    check_mode(PM_ON,       "P21.on_d");
    check_mode(PM_OFF,      "P21.off");
    check_mode(PM_ON,       "P21.on_e");
    check_mode(PM_WARM_RST, "P21.warm_rst");
    check_mode(PM_ON,       "P21.on_f");

    $display("[%0t]   And the direct OFF -> MEM_RET hop, which reaches MEM_RET by a", $time);
    $display("[%0t]   different route and must land on the same actuation.", $time);
    check_mode(PM_OFF, "P21.off2");
    check_mode(PM_MEM_RET, "P21.mem_ret_direct");
    check_mode(PM_ON, "P21.on_g");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P22: Clock gate actually stops the clock");
    $display("[%0t]   Goal: DEVCLKEN is an intent; the workload clock is the effect.", $time);
    $display("[%0t]         Count real edges of the gated clock in every mode.", $time);

    $display("[%0t]   Modes with DEVCLKEN HIGH must keep the clock running...", $time);
    set_policy(PM_FUNC_RET, 1'b0, 1'b0);
    wait_mode(PM_FUNC_RET, 20000, "P22.func_ret");
    e0 = dclk_edges; #400;
    check(dclk_edges > e0,  "P22: FUNC_RET -- workload clock still toggling");
    check(!clk_gated,       "P22: FUNC_RET -- gate open");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P22.on");
    set_policy(PM_MEM_OFF, 1'b0, 1'b0);
    wait_mode(PM_MEM_OFF, 20000, "P22.mem_off");
    e0 = dclk_edges; #400;
    check(dclk_edges > e0,  "P22: MEM_OFF -- workload clock still toggling");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P22.on2");
    set_policy(PM_WARM_RST, 1'b0, 1'b0);
    wait_mode(PM_WARM_RST, 20000, "P22.warm_rst");
    e0 = dclk_edges; #400;
    check(dclk_edges > e0,  "P22: WARM_RST -- clock runs, only the reset asserts");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P22.on3");

    $display("[%0t]   ...and modes with DEVCLKEN LOW must stop it dead: ZERO edges,", $time);
    $display("[%0t]   not merely fewer.", $time);
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 20000, "P22.full_ret");
    check(clk_gated,        "P22: FULL_RET -- gate closed");
    e0 = dclk_edges; #400;
    check_int(dclk_edges - e0, 0, "P22: FULL_RET -- workload clock edges");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P22.on4");
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    wait_mode(PM_MEM_RET, 20000, "P22.mem_ret");
    e0 = dclk_edges; #400;
    check_int(dclk_edges - e0, 0, "P22: MEM_RET -- workload clock edges");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P22.on5");
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P22.off");
    e0 = dclk_edges; #400;
    check_int(dclk_edges - e0, 0, "P22: OFF -- workload clock edges");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P22.on6");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P23: Retention vs corruption");
    $display("[%0t]   Goal: THE test the power model exists for. Under plain", $time);
    $display("[%0t]         simulation FULL_RET, MEM_RET and OFF are", $time);
    $display("[%0t]         indistinguishable -- all three hold the workload in", $time);
    $display("[%0t]         reset, so all three read back reset values. With", $time);
    $display("[%0t]         -simstate CORRUPT and set_retention modelled, they", $time);
    $display("[%0t]         separate: FULL_RET keeps state, the other two lose it.", $time);

    $display("[%0t]   ppu_device_ip holds THREE classes of state so the modes can be", $time);
    $display("[%0t]   told apart. This phase does the two logic classes; P23a does", $time);
    $display("[%0t]   the RAM and the full mode matrix.", $time);
    $display("[%0t]     u_core  non-retained, reset by DEVPORESETn & DEVWARMRESETn", $time);
    $display("[%0t]     u_ret   retained,     reset by DEVPORESETn & DEVRETRESETn,", $time);
    $display("[%0t]             and covered by set_retention on the VDD_RET rail", $time);

    $display("[%0t]   Step 1: seed both, then FULL_RET. Table 4-11 gives FULL_RET a", $time);
    $display("[%0t]   row found in no other mode -- DEVWARMRESETn asserts while", $time);
    $display("[%0t]   DEVPORESETn and DEVRETRESETn stay HIGH -- so the non-retained", $time);
    $display("[%0t]   class must be reset and the retained class must survive. That", $time);
    $display("[%0t]   split IS the mode; without it FULL_RET is just MEM_OFF.", $time);
    q0 = restores_done;
    ip_fill(8'h3C);
    check(sig_nret === ip_expect(8'h3C), "P23: non-retained signature seeded");
    check(sig_ret  === ip_expect(8'h3C), "P23: retained signature seeded");

    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 20000, "P23.full_ret");
    check(pm_ret_valid, "P23: a retention save is being held");
    check(logic_ret && !logic_on, "P23: domain is on the retention supply, not the full one");
    check(!pm_corrupt,  "P23: retained domain is NOT corrupted");
    check(!u_top.u_dom.dev_warmresetn && u_top.u_dom.dev_poresetn && u_top.u_dom.dev_retresetn,
          "P23: FULL_RET asserts DEVWARMRESETn alone -- the Table 4-11 row");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P23.on");
    check_int(restores_done, q0 + 1, "P23: retention restore happened exactly once");
    check(sig_ret  === ip_expect(8'h3C),
          "P23: FULL_RET RETAINED the retained signature");
    check(sig_nret === 32'h0,
          "P23: and RESET the non-retained one -- DEVWARMRESETn did its job");

    $display("[%0t]   Step 2: the same seed through OFF. No retention supply, so the", $time);
    $display("[%0t]   save is invalidated and BOTH classes are genuinely lost.", $time);
    q0 = restores_done;
    ip_fill(8'h5A);
    check(sig_ret === ip_expect(8'h5A), "P23: reseeded before OFF");

    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P23.off");
    check(pm_corrupt,    "P23: unpowered domain IS corrupted");
    check(!pm_ret_valid, "P23: and the retention save was invalidated");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P23.on2");
    check_int(restores_done, q0, "P23: no restore after OFF -- nothing was retained");
    check(sig_ret  === 32'h0, "P23: retained signature did NOT survive OFF");
    check(sig_nret === 32'h0, "P23: nor did the non-retained one");

    $display("[%0t]   The counter comes back CLEAN, which is a change from the", $time);
    $display("[%0t]   workload this IP replaced. dummy_workload.cnt had no reset", $time);
    $display("[%0t]   value, so work_count read X after every power cycle -- the", $time);
    $display("[%0t]   finding upf/README.md predicted and the first power-aware run", $time);
    $display("[%0t]   confirmed. ppu_ip_core resets wcnt, so it is now a property", $time);
    $display("[%0t]   rather than an argument that the X was harmless.", $time);
    check(^work_count !== 1'bx, "P23: work_count is clean after OFF -- wcnt has a reset value");
    check(busy === 1'b0,        "P23: and busy came back clean too");

    $display("[%0t]   A fresh burst must still work from reset.", $time);
    @(negedge dclk); light_work = 1'b0; work_len = 8'd10; start = 1'b1;
    @(negedge dclk); start = 1'b0;
    wait_busy(1'b1, 3000, "P23.fresh_busy");
    wait_busy(1'b0, 8000, "P23.fresh_drained");
    check(^work_count !== 1'bx, "P23: work_count still clean after a fresh burst");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P23a: Every mode is distinguishable");
    $display("[%0t]   Goal: the reason ppu_device_ip exists. Below the PCSM, the old", $time);
    $display("[%0t]         workload made six of the seven modes identical -- it had", $time);
    $display("[%0t]         no RAM, so PPU_FUNRR/PPU_FULRR/PPU_MEMRR reached nothing,", $time);
    $display("[%0t]         and no retained state, so FULL_RET was MEM_RET.", $time);
    $display("[%0t]         Eight RAM banks with per-bank retention from", $time);
    $display("[%0t]         PCSMPSTATE[15:8], plus the two logic classes, give every", $time);
    $display("[%0t]         mode a different observable result.", $time);
    $display("[%0t]   ram_cfg = 0x0F throughout: banks 0-3 configured to retain,", $time);
    $display("[%0t]   banks 4-7 not. So in a RAM-retaining mode the low four must", $time);
    $display("[%0t]   survive and the high four must NOT -- which is what makes the", $time);
    $display("[%0t]   three RAM retention registers observable at all.", $time);
    reg_write(A_FUNRR, 32'h0000_000F);
    reg_write(A_FULRR, 32'h0000_000F);
    reg_write(A_MEMRR, 32'h0000_000F);

    //            mode          nret   ret    banks 0-3  banks 4-7
    check_mode_state(PM_WARM_RST, 1'b0, 1'b0, 1'b1, 1'b1, "WARM_RST");
    check_mode_state(PM_FUNC_RET, 1'b1, 1'b1, 1'b1, 1'b0, "FUNC_RET");
    check_mode_state(PM_MEM_OFF,  1'b1, 1'b1, 1'b0, 1'b0, "MEM_OFF");
    check_mode_state(PM_FULL_RET, 1'b0, 1'b1, 1'b1, 1'b0, "FULL_RET");
    check_mode_state(PM_MEM_RET,  1'b0, 1'b0, 1'b1, 1'b0, "MEM_RET");
    check_mode_state(PM_OFF,      1'b0, 1'b0, 1'b0, 1'b0, "OFF");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P24: Isolation is load-bearing");
    $display("[%0t]   Goal: prove the clamp does work rather than decorating the", $time);
    $display("[%0t]         netlist. This design's device wrapper is always-on AND", $time);
    $display("[%0t]         always-live, so an unpowered workload's busy reaches", $time);
    $display("[%0t]         dev_quiescent_deny and dev_wake every cycle.", $time);
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P24.off");
    check(pm_corrupt,   "P24: domain unpowered and corrupted");
    check(pm_iso_clamp, "P24: isolation cells are clamping");
    check(^u_top.u_ip.u_core.wcnt === 1'bx,  "P24: unpowered internal state IS X");
    check(u_top.busy === 1'b0,          "P24: the clamped boundary reads the clamp value");
    check(^dev_qactive !== 1'bx,         "P24: so DEVQACTIVE stays clean");
    check(^u_top.u_dom.u_dev.dev_quiescent_deny !== 1'bx,
                                        "P24: and the deny term stays clean");

    $display("[%0t]   Now defeat the clamp for a few cycles. This is safe here and", $time);
    $display("[%0t]   only here: the device is in Q_STOPPED, whose FSM arm looks at", $time);
    $display("[%0t]   DEVQREQn alone, so an X on dev_quiescent_deny cannot move it.", $time);
    iso_defeat = 1'b1;
    repeat (4) @(negedge dclk);
`ifdef PPU_PA
    // Under real power intent this negative control cannot be performed, and
    // that is the strongest available result rather than a gap.
    //
    // iso_defeat reaches only the BEHAVIOURAL clamp above, which exists so that
    // "make ppu" can approximate isolation under a simulator that does not read
    // UPF. It cannot reach ISO_DEV_BUSY, the real cell that upf/ppu_pd_top.upf
    // places at the PD_AON boundary with -location parent -- nothing in the
    // testbench can, which is precisely the property being claimed.
    //
    // Measured here with the model's clamp removed: u_ip.u_core.busy = x inside the
    // domain, u_top.busy = 0 on the always-on side. The cell is holding the
    // boundary on its own.
    check(^u_top.u_ip.u_core.busy === 1'bx,
                                  "P24: the producer inside PD_DEV is X with the model's clamp defeated");
    check(u_top.busy === 1'b0,    "P24: and the real isolation cell still holds the boundary at the clamp value");
    $display("[%0t]   So the X that would otherwise reach DEVQACTIVE is stopped", $time);
    $display("[%0t]   by ISO_DEV_BUSY, not by the model standing in for it.", $time);
`else
    check(^u_top.busy === 1'bx,   "P24: unclamped, X escapes onto an always-on net");
    check(^dev_qactive === 1'bx,   "P24: and reaches DEVQACTIVE -- the PPU's wake input");
    $display("[%0t]   That is the failure the clamp prevents: a wake request", $time);
    $display("[%0t]   fabricated by a domain that has no power to make one.", $time);
`endif
    iso_defeat = 1'b0;
    repeat (4) @(negedge dclk);
    check(u_top.busy === 1'b0,  "P24: clamp restored, boundary clean again");
    check(^dev_qactive !== 1'bx, "P24: DEVQACTIVE recovered");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P24.on");
    check(!pm_corrupt && !pm_iso_clamp, "P24: powered and un-isolated in ON");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P25: Power sequencing rules held throughout");
    $display("[%0t]   Goal: PU1-PU8 in ppu_power_model are the power-aware", $time);
    $display("[%0t]         equivalent of qchannel_monitor's R-rules, and they have", $time);
    $display("[%0t]         been checked on every edge since reset -- across every", $time);
    $display("[%0t]         mode, every denial, every dynamic transition and both", $time);
    $display("[%0t]         channel-disable phases.", $time);
    $display("[%0t]   PU1-PU3: supply removed only after isolation, clock gate and", $time);
    $display("[%0t]            reset are already applied.", $time);
    $display("[%0t]   PU4-PU6: isolation, clock and reset released only once the", $time);
    $display("[%0t]            supply is back.", $time);
    $display("[%0t]   PU7:     the retention supply leads the primary down and", $time);
    $display("[%0t]            lags it back up -- make before break.", $time);
    $display("[%0t]   PU8:     the domain is never unpowered un-isolated.", $time);
    check_int(pm_viol, 0, "P25: power sequencing violations across the whole run");

    $display("[%0t]   And the PPU protocol monitor, which has been checking the", $time);
    $display("[%0t]   PPU's own rules on every monitor edge since reset:", $time);
    $display("[%0t]     U1/U2  PPUHWSTAT always a valid one-hot mode", $time);
    $display("[%0t]     U3     settled device controls match the reported mode", $time);
    $display("[%0t]     U4-U7  Section 4.1.5 ordering, both directions", $time);
    $display("[%0t]     U8     PCSMPSTATE stable while PCSMPREQ is HIGH", $time);
    $display("[%0t]     U9     every mode pair has ON at one end, or is OFF -> MEM_RET", $time);
    check_int(uviol, 0, "P25: PPU protocol violations across the whole run");

    // -------------------------------------------------------------------------
    set_phase("P27: Completion events for a policy written mid-transition");
    $display("[%0t]   Goal: the two Section 4.1.2 full-policy-completion", $time);
    $display("[%0t]         conditions that only arise when PPU_PWPR is written", $time);
    $display("[%0t]         WHILE a transition is in flight. Both read oddly until", $time);
    $display("[%0t]         you see what they are for.", $time);
    clear_all_irq();

    $display("[%0t]   Case 1 -- a DENIED transition whose mid-flight write matches", $time);
    $display("[%0t]   the current mode. Software asks for OFF, changes its mind to", $time);
    $display("[%0t]   ON (the mode it is already in), and the OFF request is then", $time);
    $display("[%0t]   refused. The outcome IS what software last asked for, so it", $time);
    $display("[%0t]   gets a completion event -- even though the only transition", $time);
    $display("[%0t]   that ran was denied. Without this the write is acknowledged", $time);
    $display("[%0t]   by nothing at all.", $time);
    // PWR_DEVACTIVEEN cleared for the same reason as P5: with it set, a busy
    // workload asserts DEVQACTIVE, Section 3.4.2 stops the PPU asking at all,
    // and there is nothing to deny.
    reg_write(A_PWCR, 32'h0000_0001);
    deny_enb = 1'b1;
    @(negedge dclk); light_work = 1'b0; work_len = 8'd60; start = 1'b1;
    @(negedge dclk); start = 1'b0;
    wait_busy(1'b1, 3000, "P27.busy");

    set_policy(PM_OFF, 1'b0, 1'b0);
    begin
      time t0;
      t0 = $time;
      while (!seq_busy && ($time - t0) < 8000) #1;
      check(seq_busy, "P27: the doomed transition to OFF is in flight");
      repeat (3) @(posedge aon_clk);
      set_policy(PM_ON, 1'b0, 1'b0);      // lands mid-transition, matches cur_mode
    end
    wait_transition_done(12000, "P27.denied");
    check(pwr_status === PM_ON, "P27: still in ON -- the request was denied");
    check_irq(A_ISR, ISR_STA_DENY,        1'b1, "P27: STA_DENY_IRQ fired");
    check_irq(A_ISR, ISR_STA_POLICY_TRN,  1'b1,
              "P27: and the completion event fired too (Section 4.1.2 condition 3)");

    $display("[%0t]   Case 2 -- the same denial, but the mid-flight write does NOT", $time);
    $display("[%0t]   match the current mode. The condition requires 'the last", $time);
    $display("[%0t]   power... policies written match the current power... modes',", $time);
    $display("[%0t]   so this one must stay silent: software asked for FULL_RET and", $time);
    $display("[%0t]   did not get it.", $time);
    set_policy(PM_OFF, 1'b0, 1'b0);
    begin
      time t0;
      t0 = $time;
      while (!seq_busy && ($time - t0) < 8000) #1;
      check(seq_busy, "P27: second doomed transition in flight");
      repeat (3) @(posedge aon_clk);
      set_policy(PM_FULL_RET, 1'b0, 1'b0);   // does NOT match cur_mode ON
    end
    wait_transition_done(12000, "P27.denied2");
    check_irq(A_ISR, ISR_STA_DENY,       1'b1, "P27: STA_DENY_IRQ fired again");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0,
              "P27: but NO completion event -- the written policy was not reached");

    // The policy is FULL_RET now and the workload is still busy, so let it
    // drain and settle before the next case rather than fighting a denial.
    wait_busy(1'b0, 20000, "P27.drain");
    reg_write(A_PWCR, 32'h0000_0101);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P27.on");
    clear_all_irq();

    $display("[%0t]   Case 3 -- PWR_DYN_EN cleared mid-flight. Section 4.1.2's", $time);
    $display("[%0t]   fourth condition: 'any transition completes with", $time);
    $display("[%0t]   PPU_PWSR.PWR_DYN_STATUS set to 0b1, but PPU_PWPR.PWR_DYN_EN", $time);
    $display("[%0t]   is set to 0b0' -- meaning software switched back to a static", $time);
    $display("[%0t]   policy while the dynamic transition was still running. It is", $time);
    $display("[%0t]   reachable at all only because PWR_DYN_STATUS lags PWR_DYN_EN", $time);
    $display("[%0t]   until the sequencer is idle (Section 3.4.3).", $time);
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);

    set_policy(PM_OFF, 1'b1, 1'b0);        // dynamic OFF: the PPU starts down
    begin
      time t0;
      t0 = $time;
      while (!seq_busy && ($time - t0) < 8000) #1;
      check(seq_busy, "P27: dynamic transition to OFF in flight");
      check_reg(A_PWSR, 32'h0000_0108, "P27: PWR_DYN_STATUS still set mid-flight");
      set_policy(PM_OFF, 1'b0, 1'b0);      // same policy, dynamic now OFF
    end
    wait_mode(PM_OFF, 20000, "P27.dyn_cleared_off");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1,
              "P27: completion event fired (Section 4.1.2 condition 4)");
    check_reg(A_PWSR, 32'h0000_0000, "P27: PWR_DYN_STATUS cleared once idle");

    $display("[%0t]   And the contrast: a fully dynamic transition, both bits set,", $time);
    $display("[%0t]   reports through DYN_ACCEPT instead and must NOT raise the", $time);
    $display("[%0t]   static completion event (Table 4-2).", $time);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P27.on2");
    clear_all_irq();
    set_policy(PM_OFF, 1'b1, 1'b0);
    wait_mode(PM_OFF, 20000, "P27.fully_dynamic");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0,
              "P27: no static completion event for a fully dynamic transition");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P27.on3");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P28: DEVQACTIVE gates STATIC transitions too");
    $display("[%0t]   Goal: Section 3.4.2 'Static Power Mode Transitions with a", $time);
    $display("[%0t]         Q-Channel PPU' -- 'For transitions from ON, other than", $time);
    $display("[%0t]         to WARM_RST, all DEVQACTIVE inputs must be LOW to begin", $time);
    $display("[%0t]         a transition.'", $time);
    $display("[%0t]   This is a DIFFERENT rule from the dynamic one in Section 3.4.3", $time);
    $display("[%0t]   and the two look alike from a distance:", $time);
    $display("[%0t]     dynamic  DEVQACTIVE HIGH means 'climb to ON' -- sets a target", $time);
    $display("[%0t]     static   DEVQACTIVE HIGH means 'do not leave ON' -- only", $time);
    $display("[%0t]              BLOCKS, and never drags the PPU upward, because a", $time);
    $display("[%0t]              static policy is a target rather than a minimum", $time);
    wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P28.on");
    clear_all_irq();

    $display("[%0t]   Step 1: raise wake, then program a STATIC policy of OFF.", $time);
    $display("[%0t]   PWR_DYN_EN is 0 throughout, so nothing here is dynamic.", $time);
    @(negedge dclk) wake = 1'b1;
    while (!dev_qactive) @(negedge dclk);
    repeat (6) @(posedge aon_clk);
    check(dev_qactive, "P28: DEVQACTIVE is HIGH and the PPU has seen it");

    q0 = qreqn_edges;
    set_policy(PM_OFF, 1'b0, 1'b0);
    repeat (80) @(posedge aon_clk);
    check_reg(A_PWPR, 32'h0000_0000, "P28: the static policy of OFF was accepted");
    check(pwr_status === PM_ON,  "P28: but the PPU has NOT left ON");
    check(!seq_busy,             "P28: and no transition is even in flight");
    check(qreqn_edges == q0,     "P28: DEVQREQn never moved -- nothing was requested");
    check(dev_clken && dev_isolaten && dev_poresetn,
                                 "P28: every device control still in its ON state");

    $display("[%0t]   Step 2: it is BLOCKED, not retargeted. A dynamic PPU would", $time);
    $display("[%0t]   have set its target to ON; a static one just stays put with", $time);
    $display("[%0t]   the OFF policy still programmed, waiting.", $time);
    check_reg(A_PWSR, 32'h0000_0008, "P28: PWR_STATUS still ON, PWR_DYN_STATUS clear");

    $display("[%0t]   Step 3: drop wake. The transition must now proceed on its own,", $time);
    $display("[%0t]   with no further software action -- the policy was never lost.", $time);
    @(negedge dclk) wake = 1'b0;
    wait_mode(PM_OFF, 20000, "P28.off_after_wake_drops");
    check(!logic_on, "P28: domain powered down once the gate opened");
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1, "P28: completion IRQ on arrival");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P28.on2");
    clear_all_irq();

    $display("[%0t]   Step 4: WARM_RST is EXEMPT. Section 3.4.2: 'For transitions", $time);
    $display("[%0t]   between ON and WARM_RST there is no dependence on the", $time);
    $display("[%0t]   DEVQACTIVE inputs.' So the same wake that just blocked OFF", $time);
    $display("[%0t]   must NOT block WARM_RST -- in either direction.", $time);
    @(negedge dclk) wake = 1'b1;
    while (!dev_qactive) @(negedge dclk);
    repeat (6) @(posedge aon_clk);
    set_policy(PM_WARM_RST, 1'b0, 1'b0);
    wait_mode(PM_WARM_RST, 20000, "P28.warm_rst_despite_wake");
    check(dev_qactive,      "P28: DEVQACTIVE was HIGH the whole time");
    check(!dev_warmresetn && !dev_retresetn,
                           "P28: and WARM_RST was entered anyway");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P28.on_from_warm_rst");
    check(dev_qactive,      "P28: still HIGH, and the return to ON was not blocked either");

    $display("[%0t]   Step 5: a disabled input reads as LOW for transition control", $time);
    $display("[%0t]   (Section 3.4.1), so clearing PWR_DEVACTIVEEN must un-block the", $time);
    $display("[%0t]   descent even with DEVQACTIVE still HIGH. This is the same", $time);
    $display("[%0t]   mechanism P5 and P18 use to make a denial reachable at all.", $time);
    reg_write(A_PWCR, 32'h0000_0001);
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P28.off_input_disabled");
    check(dev_qactive, "P28: DEVQACTIVE still HIGH, yet the descent completed");
    reg_write(A_PWCR, 32'h0000_0101);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P28.on3");
    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P29: Entry delay reprogrammed mid-count");
    $display("[%0t]   Goal: Section 4.1.3 -- 'If the delay timer value is", $time);
    $display("[%0t]         re-programmed while the delay timer is counting... the", $time);
    $display("[%0t]         timer delay continues to use the PREVIOUS programmed", $time);
    $display("[%0t]         value until the count is restarted.'", $time);
    $display("[%0t]   Implemented by loading the counter once on entry to S_DELAY", $time);
    $display("[%0t]   rather than tracking the register -- but never tested until", $time);
    $display("[%0t]   now, so nothing distinguished it from the alternative.", $time);
    q0 = delay_entries;
    reg_write(A_EDTR0, 32'h0000_003C);          // OFF_DEL = 60
    set_policy(PM_OFF, 1'b0, 1'b0);

    begin
      time t0;
      t0 = $time;
      while (!seq_in_delay && ($time - t0) < 8000) #1;
      check(seq_in_delay, "P29: timer counting with OFF_DEL = 60");
      repeat (10) @(posedge aon_clk);
      $display("[%0t]   Now shrink OFF_DEL to 2 mid-count. The count must NOT", $time);
      $display("[%0t]   shorten -- it keeps the 60 it was loaded with.", $time);
      reg_write(A_EDTR0, 32'h0000_0002);
    end
    wait_mode(PM_OFF, 20000, "P29.off");
    check_int(delay_entries, q0 + 1, "P29: the timer ran exactly once");
    check_int(c_delay_exit - c_delay_enter, 61,
              "P29: counted the ORIGINAL 60+1 cycles, not the reprogrammed 2+1");

    $display("[%0t]   And the new value IS used on the next count, so the write was", $time);
    $display("[%0t]   accepted rather than ignored.", $time);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P29.on");
    q0 = delay_entries;
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P29.off2");
    check_int(delay_entries, q0 + 1, "P29: timer ran again");
    check_int(c_delay_exit - c_delay_enter, 3, "P29: this time using the new 2+1");

    reg_write(A_EDTR0, 32'h0000_0000);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P29.on2");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P30: Acceptance events fire per hop, at completion");
    $display("[%0t]   Goal: Section 4.1.2 'Static Transition Acceptance' -- 'This", $time);
    $display("[%0t]         event occurs when a static transition is accepted AND", $time);
    $display("[%0t]         COMPLETED. This includes the completion of intermediate", $time);
    $display("[%0t]         transitions', with the worked example spelling out that", $time);
    $display("[%0t]         FULL_RET to OFF via ON raises it TWICE.", $time);
    $display("[%0t]   Masked by default (Table 5-13), so unmask it first.", $time);
    reg_write(A_IMR, 32'h0000_0020);           // unmask STA_ACCEPT, keep LOCKED masked
    clear_all_irq();

    $display("[%0t]   Case 1: a single hop raises it once.", $time);
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P30.off");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1, "P30: one hop -> STA_ACCEPT fired");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b0, "P30: and only once");

    $display("[%0t]   Case 2: it fires at COMPLETION, not when the handshake is", $time);
    $display("[%0t]   accepted. On the departure path the handshake finishes well", $time);
    $display("[%0t]   before the controls and the PCSM do, so an early firing would", $time);
    $display("[%0t]   be visible as the event being set while the mode has not yet", $time);
    $display("[%0t]   changed. Programmed with a long ISO_RST_DLY to widen the gap.", $time);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P30.on");
    clear_all_irq();
    reg_write(A_DCDR1, 32'h0000_0230);         // ISO_RST_DLY = 48
    set_policy(PM_OFF, 1'b0, 1'b0);
    begin
      time t0;
      logic [31:0] rdv;
      t0 = $time;
      // Wait until the device has accepted (isolation asserted proves the
      // handshake completed, since it is sequenced after it) but the mode has
      // not committed yet.
      while ((dev_isolaten || (pwr_status !== PM_ON)) && ($time - t0) < 20000) #1;
      check(!dev_isolaten && (pwr_status === PM_ON),
            "P30: handshake accepted and isolation applied, mode not yet committed");
      reg_read(A_ISR, rdv);
      check(rdv[ISR_STA_ACCEPT] === 1'b0,
            "P30: STA_ACCEPT has NOT fired yet -- it waits for completion");
    end
    wait_mode(PM_OFF, 20000, "P30.off2");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1, "P30: and fires once the hop completes");
    reg_write(A_DCDR1, 32'h0000_0202);         // restore

    $display("[%0t]   Case 3: an intermediate hop raises it too, so FULL_RET to", $time);
    $display("[%0t]   MEM_OFF via ON gives TWO -- the spec's own worked example.", $time);
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 20000, "P30.full_ret");
    clear_all_irq();
    set_policy(PM_MEM_OFF, 1'b0, 1'b0);
    wait_mode(PM_MEM_OFF, 25000, "P30.mem_off_via_on");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1, "P30: STA_ACCEPT set after the two-hop journey");
    $display("[%0t]   The status bit cannot count to two, so the hop count is", $time);
    $display("[%0t]   established by clearing between hops instead.", $time);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P30.on2");
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 20000, "P30.full_ret2");
    clear_all_irq();
    set_policy(PM_MEM_OFF, 1'b0, 1'b0);
    wait_mode(PM_ON, 25000, "P30.intermediate_on");   // catch the FIRST hop
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1, "P30: hop 1 (to ON) raised it");
    wait_mode(PM_MEM_OFF, 25000, "P30.final_mem_off");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1, "P30: hop 2 (to MEM_OFF) raised it again");

    $display("[%0t]   Case 4: a hop with NO device handshake still counts. Section", $time);
    $display("[%0t]   4.1.2 says the event is for 'ALL completed static", $time);
    $display("[%0t]   transitions' -- the OFF -> MEM_RET direct path has no", $time);
    $display("[%0t]   handshake at all (Section 4.2.6) and must still raise it.", $time);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P30.on3");
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P30.off3");
    clear_all_irq();
    q0 = qreqn_edges;
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    wait_mode(PM_MEM_RET, 20000, "P30.mem_ret_direct");
    check(qreqn_edges == q0, "P30: confirmed no device handshake on that hop");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1, "P30: STA_ACCEPT fired anyway");

    $display("[%0t]   Case 5: the same point, but for a hop where the PPU's OWN", $time);
    $display("[%0t]   'is a handshake used' flag is genuinely 0 -- DEVREQEN cleared.", $time);
    $display("[%0t]   Case 4 does not cover that: the direct OFF -> MEM_RET path", $time);
    $display("[%0t]   never consults the flag, so the flag is still 1 there, and a", $time);
    $display("[%0t]   regression that re-gated the event on it would slip past.", $time);
    $display("[%0t]   Found by mutation testing exactly that regression.", $time);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P30.on_before_devreqen");
    reg_write(A_PWCR, 32'h0000_0100);          // DEVREQEN = 0
    clear_all_irq();
    viol_base = viol;                          // this window trips R8/R10 by design
    q0 = qreqn_edges;
    set_policy(PM_OFF, 1'b0, 1'b0);
    wait_mode(PM_OFF, 20000, "P30.off_no_handshake");
    check(qreqn_edges == q0, "P30: DEVREQEN=0, so no handshake at all");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1,
              "P30: STA_ACCEPT still fired -- 'ALL completed static transitions'");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P30.on_after_devreqen");
    check_irq(A_ISR, ISR_STA_ACCEPT, 1'b1, "P30: and again on the way back up");
    reg_write(A_PWCR, 32'h0000_0101);          // restore
    #300;
    check_int(viol - viol_base, 2,
              "P30: the two sanctioned R8/R10 violations from the disabled channel");
    viol_base = viol;

    reg_write(A_IMR, 32'h0000_0022);           // restore the reset masks
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 20000, "P30.on4");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P26: Constrained-random policy sequencing");
    $display("[%0t]   Goal: reach hop sequences no directed phase covers. Every", $time);
    $display("[%0t]         phase above is directed -- it programs a policy chosen", $time);
    $display("[%0t]         to demonstrate one property. This one programs policies,", $time);
    $display("[%0t]         delays, wakes and workload bursts at random and checks", $time);
    $display("[%0t]         only INVARIANTS.", $time);
    $display("[%0t]   It is cheap precisely because the three checkers already exist:", $time);
    $display("[%0t]   qchannel_monitor owns the wire protocol, ppu_monitor owns the", $time);
    $display("[%0t]   PPU's architectural rules, and ppu_power_model owns the power", $time);
    $display("[%0t]   sequencing. This phase adds no new checking logic -- it only", $time);
    $display("[%0t]   has to generate traffic and confirm nothing complained.", $time);
    $display("[%0t]   seed = 0x%08h  iterations = %0d", $time, rseed, RAND_ITERS);
    $display("[%0t]   Override with +seed=<n> +iters=<n> for a longer soak.", $time);

    // DEVREQEN and WARM_RST_DEVREQEN stay ENABLED for the whole phase. Both can
    // legitimately trip qchannel_monitor's R8/R10 (P3 and P15 measure exactly
    // that), and a random phase whose expected violation count depends on which
    // branches it happened to take cannot assert anything useful. Keeping the
    // handshake on means the expected count is simply "unchanged".
    reg_write(A_PWCR, 32'h0000_0101);
    reg_write(A_PTCR, 32'h0000_0001);
    clear_all_irq();

    viol_base = viol;
    q0        = uviol;
    e0        = pm_viol;
    deny_base       = deny_events;
    stablock_base   = cov_stablock;
    delayabort_base = cov_delay_abort;
    for (int unsigned m = 0; m < 16; m++) begin
      cov_mode_sta[m] = 0;
      cov_mode_dyn[m] = 0;
    end

    for (int unsigned it = 0; it < RAND_ITERS; it++) begin
      logic [3:0] pol;
      logic       dyn, lck;
      logic [7:0] a, b, c;

      // ---- Random device control delays, kept small so the loop stays quick.
      a = rnd(4); b = rnd(4); c = rnd(4);
      reg_write(A_DCDR0, {8'h00, a, b, c});
      a = rnd(4); b = rnd(4);
      reg_write(A_DCDR1, {16'h0000, a, b});

      // ---- Random entry delay hysteresis on three of the five modes.
      a = rnd(8); b = rnd(8); c = rnd(8);
      reg_write(A_EDTR0, {a, 8'h00, b, c});

      // ---- Random retention configuration, which must reach PCSMPSTATE[15:8].
      a = rnd(256); reg_write(A_MEMRR, {24'h0, a});
      a = rnd(256); reg_write(A_FULRR, {24'h0, a});
      a = rnd(256); reg_write(A_FUNRR, {24'h0, a});

      // ---- Policy selection: DIRECTED first, then random.
      //
      // Pure random at 30 iterations leaves a real chance of never programming
      // some mode -- (6/7)^26 is about 2% per mode, so better than 1 in 10 runs
      // would miss one, and the coverage assertions below would be flaky. So
      // the first 15 iterations are directed to guarantee the axes that matter,
      // and everything after that is free. Every other stimulus (delays,
      // retention config, bursts, wake toggles) is random from iteration 0, so
      // even the directed head explores.
      if (it < 7) begin
        pol = rand_supported_mode(it);          // all 7 modes, static
        dyn = 1'b0;
      end else if (it < 14) begin
        pol = rand_supported_mode(it - 7);      // all 7 modes, dynamic
        dyn = 1'b1;
      end else if (it == 14) begin
        pol = PM_LOGIC_RET;                     // guarantee the reject path
        dyn = 1'b0;
      end else begin
        if (rnd(8) == 0) pol = (rnd(2) != 0) ? PM_LOGIC_RET : PM_DBG_RECOV;
        else             pol = rand_supported_mode(rnd(7));
        dyn = (rnd(2) != 0);
      end
      lck = (rnd(4) == 0);

      // Randomise PWR_DEVACTIVEEN. A coverage axis in its own right, and also
      // what keeps denials reachable: with the input ENABLED, Section 3.4.2
      // stops the PPU departing ON while the workload is busy, so the device is
      // never asked and can never refuse.
      reg_write(A_PWCR, (rnd(3) == 0) ? 32'h0000_0001 : 32'h0000_0101);

      // WARM_RST is a legal static policy and an illegal dynamic one
      // (Section 3.4.3), so a dynamic WARM_RST would be rejected and the
      // iteration would test the reject path rather than the mode. Recorded as
      // static coverage only when it is actually accepted.
      if (!ppu_policy_spt(u_top.u_dom.u_ppu.STA_MASK, u_top.u_dom.u_ppu.DYN_MASK, pol, dyn))
                                          cov_unspt = cov_unspt + 1;
      else if (dyn)                        cov_mode_dyn[pol] = cov_mode_dyn[pol] + 1;
      else                                 cov_mode_sta[pol] = cov_mode_sta[pol] + 1;
      if (lck) cov_lock = cov_lock + 1;

      // ---- Random workload activity, which is what makes denials happen.
      if (rnd(3) != 0) begin
        cov_burst = cov_burst + 1;
        @(negedge dclk);
        a          = rnd(40);
        work_len   = a + 8'd4;
        light_work = (rnd(2) != 0);
        deny_enb   = (rnd(2) != 0);
        start      = 1'b1;
        @(negedge dclk) start = 1'b0;
      end

      set_policy(pol, dyn, lck);

      // ---- Random wake activity while the transition is in flight. With
      // dynamic transitions enabled this makes the PPU change its mind
      // mid-sequence, which is the case directed phases never reach.
      for (int unsigned w = 0; w < rnd(4); w++) begin
        repeat (rnd(30) + 5) @(negedge aon_clk);
        @(negedge dclk) wake = ~wake;
        cov_waketog = cov_waketog + 1;
      end

      repeat (rnd(60) + 10) @(negedge aon_clk);

      // ---- Stabilise: hold the inputs still, unlock, and go static ON.
      // The invariant being checked is that the PPU always SETTLES -- not that
      // it settles anywhere in particular, since with dynamic transitions and a
      // toggling wake the target is genuinely a moving one.
      @(negedge dclk) wake = 1'b0;
      deny_enb = 1'b1;
      reg_write(A_PWCR, 32'h0000_0101);        // restore before stabilising
      reg_write(A_UNLK, 32'h0000_0001);
      set_policy(PM_ON, 1'b0, 1'b0);

      begin
        time t0;
        t0 = $time;
        while (((pwr_status !== PM_ON) || seq_busy) && (($time - t0) < 60000)) #1;
        if ((pwr_status !== PM_ON) || seq_busy) begin
          tb_errors++;
          $display("[%0t] FAIL P26 iter %0d: did not settle in ON (status=%0s busy=%0b)",
                   $time, it, ppu_mode_name(pwr_status), seq_busy);
        end
      end
      repeat (4) @(posedge aon_clk);

      // ---- Invariants. Deliberately few: everything else is the checkers' job.
      if ($countones(hwstat) != 1) begin
        tb_errors++;
        $display("[%0t] FAIL P26 iter %0d: PPUHWSTAT not one-hot (%04h)",
                 $time, it, hwstat);
      end
      if (hwstat !== ppu_hwstat(pwr_status)) begin
        tb_errors++;
        $display("[%0t] FAIL P26 iter %0d: PPUHWSTAT %04h disagrees with PWR_STATUS %0s",
                 $time, it, hwstat, ppu_mode_name(pwr_status));
      end
      if (^work_count === 1'bx && !pm_corrupt) begin
        // Legal only if the domain lost power at some point without a fresh
        // burst since; noted rather than failed, because P23 owns that finding.
        $display("[%0t]   note P26 iter %0d: work_count still X from a power cycle",
                 $time, it);
      end
    end

    checks++;
    $display("[%0t]  ok  P26: %0d random iterations, every one settled in ON",
             $time, RAND_ITERS);

    $display("[%0t]   What the storm actually generated:", $time);
    begin
      int unsigned modes_sta, modes_dyn;
      modes_sta = 0; modes_dyn = 0;
      for (int unsigned m = 0; m < 16; m++) begin
        if (cov_mode_sta[m] != 0 || cov_mode_dyn[m] != 0)
          $display("[%0t]     %-9s static x%0d  dynamic x%0d", $time,
                   ppu_mode_name(m[3:0]), cov_mode_sta[m], cov_mode_dyn[m]);
        if (cov_mode_sta[m] != 0) modes_sta = modes_sta + 1;
        if (cov_mode_dyn[m] != 0) modes_dyn = modes_dyn + 1;
      end
      $display("[%0t]     unsupported policy attempts x%0d", $time, cov_unspt);
      $display("[%0t]     lock enabled x%0d", $time, cov_lock);
      $display("[%0t]     workload bursts x%0d", $time, cov_burst);
      $display("[%0t]     wake toggles x%0d", $time, cov_waketog);
      $display("[%0t]     device denials observed x%0d", $time,
               deny_events - deny_base);
      $display("[%0t]     static departures blocked by DEVQACTIVE x%0d  (Section 3.4.2)",
               $time, cov_stablock - stablock_base);
      $display("[%0t]     entry delay counts abandoned x%0d  (Section 4.1.3)",
               $time, cov_delay_abort - delayabort_base);

      // Guaranteed by the directed head of the loop, so these are assertions
      // rather than hopeful reports.
      check_int(modes_sta, 7, "P26 coverage: all 7 modes programmed statically");
      check(modes_dyn >= 6,
            "P26 coverage: all dynamically-supported modes programmed dynamically");
      check(cov_unspt > 0,   "P26 coverage: the unsupported-policy path was hit");
      check(cov_burst > 0,   "P26 coverage: workload bursts were generated");
      check(cov_waketog > 0, "P26 coverage: wake was toggled mid-transition");
      check(deny_events > deny_base, "P26 coverage: at least one device denial occurred");
      // The rule F7 added. If this is ever zero the storm is not reaching it,
      // and the phase would be reporting confidence it has not earned.
      check(cov_stablock > stablock_base,
            "P26 coverage: DEVQACTIVE blocked a static departure at least once");
    end

    check_int(viol - viol_base, 0, "P26: no NEW qchannel protocol violations");
    check_int(uviol - q0,       0, "P26: no PPU protocol violations");
    check_int(pm_viol - e0,     0, "P26: no power sequencing violations");

    $display("[%0t]   And the design is still functional afterwards, which a", $time);
    $display("[%0t]   random storm that quietly wedged something would not be.", $time);
    reg_write(A_EDTR0, 32'h0000_0000);
    reg_write(A_DCDR0, 32'h0002_0202);
    reg_write(A_DCDR1, 32'h0000_0202);
    // Drain any burst the storm left in flight FIRST. The stabilise step only
    // requires settling in ON, and an up-transition cannot be denied -- so a
    // long burst can still be running here, and with deny_enb set the device
    // will quite correctly refuse to quiesce for OFF. Seed 999 found exactly
    // that, and it was this check missing a drain rather than an RTL fault:
    // every other down-transition phase drains before it asks.
    if (busy) begin
      $display("[%0t]   draining a burst the storm left running (work_count=%0d)",
               $time, work_count);
      wait_busy(1'b0, 20000, "P26.drain");
    end
    check_mode(PM_OFF, "P26.post_off");
    check_mode(PM_ON,  "P26.post_on");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P31 static gating applies to the INTERMEDIATE hop (3.4.2)");
    $display("[%0t]   Section 3.4.2: 'Transitions to lower priority power modes", $time);
    $display("[%0t]   are delayed until the relevant power mode DEVACTIVE inputs", $time);
    $display("[%0t]   are LOW. This is true even if the PPU must go through an", $time);
    $display("[%0t]   intermediate power mode to reach the programmed policy...", $time);
    $display("[%0t]   all power mode DEVACTIVE inputs between FULL_RET and OFF", $time);
    $display("[%0t]   must be LOW BEFORE the PPU begins the intermediate", $time);
    $display("[%0t]   transition to ON.'", $time);
    $display("[%0t]", $time);
    $display("[%0t]   Regression test for F9. Gating only on cur_mode == ON", $time);
    $display("[%0t]   implements the last hop and lets the intermediate one", $time);
    $display("[%0t]   through, so a STATIC request for OFF from FULL_RET with", $time);
    $display("[%0t]   DEVQACTIVE HIGH climbed to ON -- powering the domain up and", $time);
    $display("[%0t]   releasing its reset -- then parked there. A static policy", $time);
    $display("[%0t]   must never leave the domain at a HIGHER mode than it", $time);
    $display("[%0t]   started in.", $time);
    $display("[%0t]", $time);
    $display("[%0t]   NOTE: every assertion here is a passive check on", $time);
    $display("[%0t]   pwr_status. check_mode() must NOT be used -- it PROGRAMS", $time);
    $display("[%0t]   the policy it then verifies, so using it to assert 'held in", $time);
    $display("[%0t]   X' silently overwrites the policy under test and passes", $time);
    $display("[%0t]   against a design that never blocked anything.", $time);

    // P31 is the only directed phase after the random one, so it inherits two
    // kinds of leftover. The registers are the obvious kind -- P26 randomises
    // PPU_DCDR0/1, PPU_EDTR0, PPU_PWCR and PPU_PTCR, which would make every
    // wait below a function of the seed. The STIMULUS is the kind that bit:
    // P26 asserts `start` inside its loop and never clears it, and a running
    // burst holds `busy`, which qchannel_device ORs into DEVQACTIVE. A phase
    // that tests DEVQACTIVE gating must own every source of DEVQACTIVE.
    start    = 1'b0;
    deny_enb = 1'b0;          // denial is not under test here
    wait_busy(1'b0, 40000, "P31.quiesce");
    reg_write(A_EDTR0, 32'h0000_0000);
    reg_write(A_EDTR1, 32'h0000_0000);
    reg_write(A_DCDR0, {8'h0, 8'd2, 8'd2, 8'd2});
    reg_write(A_DCDR1, {16'h0, 8'd2, 8'd2});
    reg_write(A_PWCR,  32'h0000_0101);   // PWR_DEVACTIVEEN=1, DEVREQEN=1
    reg_write(A_PTCR,  32'h0000_0001);   // WARM_RST_DEVREQEN=1

    // ---- Case 1: FULL_RET, static policy OFF, DEVQACTIVE HIGH ----
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P31.pre");
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 40000, "P31.full_ret");

    @(negedge dclk) wake = 1'b1;
    repeat (100) @(posedge aon_clk);
    check(pwr_status === PM_FULL_RET,
          "P31: DEVQACTIVE alone does not move a static PPU");

    set_policy(PM_OFF, 1'b0, 1'b0);
    repeat (800) @(posedge aon_clk);
    check(pwr_status === PM_FULL_RET,
          "P31: static policy OFF is HELD in FULL_RET, no climb to ON");
    check(logic_on === 1'b0,
          "P31: the domain logic supply stayed off while held");
    check(seq_busy === 1'b0,
          "P31: held means idle, not a transition stuck mid-flight");

    // Releasing DEVQACTIVE must let it through, or "held" is indistinguishable
    // from "wedged" and the checks above would pass against a dead PPU.
    @(negedge dclk) wake = 1'b0;
    wait_mode(PM_OFF, 60000, "P31.released_to_off");
    check(pwr_status === PM_OFF, "P31: proceeds to OFF once DEVQACTIVE is LOW");

    // ---- Case 2: the same rule one step up the ladder ----
    // MEM_OFF -> FULL_RET is also a downward move needing ON as an
    // intermediate, and was equally unguarded.
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P31.on_again");
    set_policy(PM_MEM_OFF, 1'b0, 1'b0);
    wait_mode(PM_MEM_OFF, 40000, "P31.mem_off");

    @(negedge dclk) wake = 1'b1;
    repeat (100) @(posedge aon_clk);
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    repeat (800) @(posedge aon_clk);
    check(pwr_status === PM_MEM_OFF,
          "P31: MEM_OFF -> FULL_RET also held, same intermediate rule");

    @(negedge dclk) wake = 1'b0;
    wait_mode(PM_FULL_RET, 60000, "P31.released_to_full_ret");

    // ---- Case 3: WARM_RST is exempt in BOTH directions ----
    // "For transitions between ON and WARM_RST there is no dependence on the
    // DEVQACTIVE inputs." The RETURN leg is the one a policy-only test misses:
    // there cur_mode is WARM_RST(9) and the policy is ON(8), a numerical
    // decrease that is not a power-down at all.
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P31.on_for_warm");
    @(negedge dclk) wake = 1'b1;
    repeat (60) @(posedge aon_clk);
    set_policy(PM_WARM_RST, 1'b0, 1'b0);
    wait_mode(PM_WARM_RST, 40000, "P31.warm_rst_with_qactive");
    check(pwr_status === PM_WARM_RST, "P31: ON -> WARM_RST ignores DEVQACTIVE");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P31.warm_return_with_qactive");
    check(pwr_status === PM_ON, "P31: WARM_RST -> ON ignores DEVQACTIVE too");
    @(negedge dclk) wake = 1'b0;
    repeat (400) @(posedge aon_clk);
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P32 lock applies ONLY to lockable modes (3.4.3)");
    rd32 = 32'h0;
    $display("[%0t]   Section 3.4.3: 'The lockable power modes are: OFF,", $time);
    $display("[%0t]   OFF_EMU, MEM_RET, MEM_RET_EMU.' FULL_RET is not one of", $time);
    $display("[%0t]   them.", $time);
    $display("[%0t]", $time);
    $display("[%0t]   P10 and P19 both prove the lock ENGAGES in OFF and", $time);
    $display("[%0t]   MEM_RET. Neither proves it stays clear anywhere else, and", $time);
    $display("[%0t]   a mutation adding FULL_RET to ppu_mode_lockable() survived", $time);
    $display("[%0t]   the entire suite. A list is only pinned down by testing", $time);
    $display("[%0t]   something that is NOT on it.", $time);

    @(negedge dclk) wake = 1'b0;
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P32.pre");

    // Dynamic + lock enabled, policy FULL_RET. With DEVQACTIVE LOW the dynamic
    // target is the policy, so it settles in FULL_RET -- a mode where the lock
    // conditions are all met EXCEPT that the mode is not lockable.
    set_policy(PM_FULL_RET, 1'b1, 1'b1);
    wait_mode(PM_FULL_RET, 40000, "P32.full_ret_dyn_lock");
    reg_read(A_PWSR, rd32);
    check(rd32[12] === 1'b0,
          "P32: LOCK_STATUS stays 0 in FULL_RET -- not a lockable mode");

    // And the behaviour the status bit stands for: an unlocked PPU follows
    // DEVQACTIVE back to ON. A locked one would sit there.
    @(negedge dclk) wake = 1'b1;
    wait_mode(PM_ON, 40000, "P32.climb_out");
    check(pwr_status === PM_ON,
          "P32: unlocked in FULL_RET, so DEVQACTIVE still raises it to ON");

    // Control: the same stimulus in a mode that IS lockable must lock, so the
    // check above cannot pass merely because lock is broken everywhere.
    @(negedge dclk) wake = 1'b0;
    set_policy(PM_OFF, 1'b1, 1'b1);
    wait_mode(PM_OFF, 40000, "P32.off_dyn_lock");
    reg_read(A_PWSR, rd32);
    check(rd32[12] === 1'b1,
          "P32: control -- LOCK_STATUS DOES set in OFF, so the check discriminates");
    @(negedge dclk) wake = 1'b1;
    repeat (400) @(posedge aon_clk);
    check(pwr_status === PM_OFF,
          "P32: control -- locked in OFF, DEVQACTIVE cannot raise it");

    reg_write(A_UNLK, 32'h1);
    @(negedge dclk) wake = 1'b0;
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P32.restore");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P33 three rules a settled-state check cannot see");

    // ---- P33a: RST_HWSTAT_DLY is actually applied (Table 4-5) ----
    $display("[%0t]   Table 4-5: 'The minimum number of PPU clock cycles between", $time);
    $display("[%0t]   DEV*RESETn de-assertion and PPUHWSTAT updating is", $time);
    $display("[%0t]   RST_HWSTAT_DLY + 1.'", $time);
    $display("[%0t]   Four of the five device-control delays were already pinned", $time);
    $display("[%0t]   down by a mutation. This one was not, and the reason is", $time);
    $display("[%0t]   instructive: commit_up waits for BOTH the delay and the", $time);
    $display("[%0t]   device handshake, and at the default clock ratio the", $time);
    $display("[%0t]   handshake is always the slower of the two -- so zeroing the", $time);
    $display("[%0t]   delay changed nothing observable. Measuring it needs a delay", $time);
    $display("[%0t]   LARGER than the handshake.", $time);

    @(negedge dclk) wake = 1'b0;
    start = 1'b0;
    wait_busy(1'b0, 40000, "P33.quiesce");
    reg_write(A_EDTR0, 32'h0);
    reg_write(A_EDTR1, 32'h0);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P33.pre");

    begin
      int unsigned t_small, t_big;
      // RST_HWSTAT_DLY is PPU_DCDR0[23:16].
      reg_write(A_DCDR0, {8'h0, 8'd2, 8'd2, 8'd2});
      set_policy(PM_OFF, 1'b0, 1'b0);
      wait_mode(PM_OFF, 40000, "P33.off_small");
      set_policy(PM_ON, 1'b0, 1'b0);
      // Measure from the last reset coming off to PPUHWSTAT reporting ON.
      @(posedge dev_poresetn);
      t_small = 0;
      while ((hwstat !== ppu_hwstat(PM_ON)) && (t_small < 4000)) begin
        @(posedge aon_clk); t_small++;
      end
      wait_mode(PM_ON, 40000, "P33.on_small");

      reg_write(A_DCDR0, {8'h0, 8'd60, 8'd2, 8'd2});   // RST_HWSTAT_DLY = 60
      set_policy(PM_OFF, 1'b0, 1'b0);
      wait_mode(PM_OFF, 40000, "P33.off_big");
      set_policy(PM_ON, 1'b0, 1'b0);
      @(posedge dev_poresetn);
      t_big = 0;
      while ((hwstat !== ppu_hwstat(PM_ON)) && (t_big < 4000)) begin
        @(posedge aon_clk); t_big++;
      end
      wait_mode(PM_ON, 40000, "P33.on_big");

      $display("[%0t]   reset release -> PPUHWSTAT: %0d cycles at DLY=2, %0d at DLY=60",
               $time, t_small, t_big);
      check(t_big >= 61,
            "P33a: PPUHWSTAT waited at least RST_HWSTAT_DLY+1 cycles");
      check(t_big > t_small,
            "P33a: and the delay register actually moves it");
      reg_write(A_DCDR0, {8'h0, 8'd2, 8'd2, 8'd2});
    end

    // ---- P33b: PWR_DYN_EN takes effect only after the in-flight transition ----
    $display("[%0t]   Section 3.4.3: 'When power mode dynamic transitions are", $time);
    $display("[%0t]   enabled or disabled, the PPU completes any ongoing", $time);
    $display("[%0t]   transition before the new setting takes effect. The", $time);
    $display("[%0t]   PPU_PWSR.PWR_DYN_STATUS bit is updated when the new setting", $time);
    $display("[%0t]   takes effect.'", $time);
    $display("[%0t]", $time);
    $display("[%0t]   Checked on PWR_DYN_STATUS, because that is what the spec", $time);
    $display("[%0t]   makes observable. An earlier attempt tried to catch it on", $time);
    $display("[%0t]   the TARGET instead, by enabling dynamic mid-flight with", $time);
    $display("[%0t]   DEVQACTIVE HIGH -- and that cannot discriminate: with the", $time);
    $display("[%0t]   3.4.2 gate in place a static downward policy and a dynamic", $time);
    $display("[%0t]   one both resolve to ON when DEVQACTIVE is HIGH. DEVQACTIVE", $time);
    $display("[%0t]   stays LOW here so the departure actually runs.", $time);

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P33b.pre");
    @(negedge dclk) wake = 1'b0;
    reg_write(A_EDTR0, 32'h0000_0064);        // OFF_DEL = 100 PPU cycles
    saw_off   = 1'b0;
    watch_off = 1'b1;
    set_policy(PM_OFF, 1'b0, 1'b0);           // static departure: enters S_DELAY
    repeat (20) @(posedge aon_clk);           // ...still counting the delay
    set_policy(PM_OFF, 1'b1, 1'b0);           // PWR_DYN_EN = 1 mid-transition
    repeat (6) @(posedge aon_clk);

    reg_read(A_PWPR, rd32);
    check(rd32[8] === 1'b1, "P33b: PPU_PWPR.PWR_DYN_EN took the write immediately");
    reg_read(A_PWSR, rd32);
    check(rd32[8] === 1'b0,
          "P33b: PPU_PWSR.PWR_DYN_STATUS still 0 -- the transition is not finished");
    check(seq_busy === 1'b1, "P33b: (and the transition really was still in flight)");

    repeat (1200) @(posedge aon_clk);
    watch_off = 1'b0;
    check(saw_off === 1'b1, "P33b: the static departure completed into OFF");
    reg_read(A_PWSR, rd32);
    check(rd32[8] === 1'b1,
          "P33b: PWR_DYN_STATUS becomes 1 only once the transition has completed");

    reg_write(A_EDTR0, 32'h0);
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P33b.restore");

    // ---- P33c: a denied transition reverts only after Q_RUN is regained ----
    $display("[%0t]   Section 4.2.9 / AMBA LPI 2.1.2: after a denial the channel", $time);
    $display("[%0t]   walks Q_DENIED -> Q_CONTINUE -> Q_RUN. Reverting the policy", $time);
    $display("[%0t]   before that recovery finishes lets the sequencer re-request", $time);
    $display("[%0t]   into the middle of it. Observed on the policy register, not", $time);
    $display("[%0t]   on the channel: the revert must land in Q_RUN.", $time);

    pol_d         = u_top.u_dom.u_ppu.u_seq.pwr_policy;
    early_reverts = 0;
    deny_enb      = 1'b1;
    work_len      = 8'd60;
    light_work    = 1'b0;
    start         = 1'b1;
    wait_busy(1'b1, 40000, "P33c.busy");
    watch_revert  = 1'b1;
    set_policy(PM_OFF, 1'b0, 1'b0);           // will be denied: the device is busy
    wait_transition_done(40000, "P33c.denied");
    repeat (400) @(posedge aon_clk);
    watch_revert  = 1'b0;
    start         = 1'b0;
    check(early_reverts == 0,
          "P33c: the policy reverted only with the Q-Channel back in Q_RUN");
    wait_busy(1'b0, 40000, "P33c.drain");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P33c.restore");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P34 PCSM interface details nothing else pins down");

    // ---- P34a: each retention register reaches its OWN mode ----
    $display("[%0t]   Sections 5.2.16-5.2.18: PPU_FUNRR, PPU_FULRR and PPU_MEMRR", $time);
    $display("[%0t]   each control PCSMPSTATE[15:8] in one specific mode.", $time);
    $display("[%0t]   Everything so far only ever checked MEM_RET -- P8 here and", $time);
    $display("[%0t]   M4 in ppu_minconfig_tb both use PPU_MEMRR. The other two are", $time);
    $display("[%0t]   written and read back as registers but never followed to the", $time);
    $display("[%0t]   PCSM, so routing FUNC_RET's field to the wrong register went", $time);
    $display("[%0t]   unnoticed. Three distinct values, three modes.", $time);

    @(negedge dclk) wake = 1'b0;
    start = 1'b0;
    wait_busy(1'b0, 40000, "P34.quiesce");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P34.pre");

    reg_write(A_FUNRR, 32'h0000_0071);
    reg_write(A_FULRR, 32'h0000_00B2);
    reg_write(A_MEMRR, 32'h0000_00E3);

    set_policy(PM_FUNC_RET, 1'b0, 1'b0);
    wait_mode(PM_FUNC_RET, 40000, "P34a.func_ret");
    check(pcsm_pstate[15:8] === 8'h71,
          "P34a: FUNC_RET carries PPU_FUNRR to the PCSM");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P34a.on1");

    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    wait_mode(PM_FULL_RET, 40000, "P34a.full_ret");
    check(pcsm_pstate[15:8] === 8'hB2,
          "P34a: FULL_RET carries PPU_FULRR to the PCSM");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P34a.on2");

    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    wait_mode(PM_MEM_RET, 40000, "P34a.mem_ret");
    check(pcsm_pstate[15:8] === 8'hE3,
          "P34a: MEM_RET carries PPU_MEMRR to the PCSM");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P34a.on3");

    // The values must be distinct AND the modes must not share a register --
    // checked by construction above, but assert it so a future edit that made
    // two of them equal cannot quietly make the phase vacuous.
    check((8'h71 !== 8'hB2) && (8'hB2 !== 8'hE3) && (8'h71 !== 8'hE3),
          "P34a: the three values are distinct, so the routing is pinned down");

    reg_write(A_FUNRR, 32'h0);
    reg_write(A_FULRR, 32'h0);
    reg_write(A_MEMRR, 32'h0);

    // ---- P34b: no PCSM request before the PCSM has initialised ----
    $display("[%0t]   Section 4.1.6 'PCSM P-Channel Reset': the reset value 'is", $time);
    $display("[%0t]   sampled by the PCSM before any other transition is allowed", $time);
    $display("[%0t]   on the interface'. So PCSMPREQ must stay LOW until tinit", $time);
    $display("[%0t]   has expired -- observed from time zero, because the only", $time);
    $display("[%0t]   opportunity to break it is the very first transition.", $time);
    check(preq_before_init == 0,
          "P34b: PCSMPREQ never rose while the PCSM was still initialising");

    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P35 STA_POLICY_TRN condition 1 reads PPU_PWPR (4.1.2)");
    $display("[%0t]   Section 4.1.2, Full Policy Transition Completion, first", $time);
    $display("[%0t]   condition: 'Following the write of a supported policy to", $time);
    $display("[%0t]   PPU_PWPR when the PPU is not in transition, and both", $time);
    $display("[%0t]   PPU_PWPR.PWR_DYN_EN and the PPU_PWPR.OP_DYN_EN are set to", $time);
    $display("[%0t]   0b0.' The register, not PWR_DYN_STATUS. On the cycle the", $time);
    $display("[%0t]   write is judged the two differ exactly when the write flips", $time);
    $display("[%0t]   the enable, and no earlier phase makes such a write at the", $time);
    $display("[%0t]   mode it is already in. Found by the SCP stress test", $time);
    $display("[%0t]   (EVT.PTRN1, pmu/README.md 10.2 finding 5).", $time);

    @(negedge dclk) wake = 1'b0;
    start = 1'b0;
    wait_busy(1'b0, 40000, "P35.quiesce");
    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P35.pre");
    reg_write(A_IMR, 32'h0000_0022);           // reset masks: STA_POLICY_TRN unmasked
    clear_all_irq();

    // Control: condition 1 in its plain form, so the two checks that expect
    // silence below cannot pass because the event is broken everywhere.
    set_policy(PM_ON, 1'b0, 1'b0);
    repeat (10) @(posedge aon_clk);
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1,
              "P35: control -- static ON written at static ON raises the event");

    // PWR_DYN_EN written as 1: condition 1 is not met, and no transition happens
    // for any other condition to complete.
    set_policy(PM_ON, 1'b1, 1'b0);
    repeat (10) @(posedge aon_clk);
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0,
              "P35: dynamic ON written at static ON raises no event");
    reg_read(A_PWSR, rd32);
    check(rd32[8] === 1'b1 && rd32[3:0] === PM_ON,
          "P35: PWR_DYN_STATUS shows the enable before the next write (4.1.1)");

    // PWR_DYN_EN written as 0, while PWR_DYN_STATUS is still 1: condition 1 is
    // met, and the mode already matches the policy.
    set_policy(PM_ON, 1'b0, 1'b0);
    repeat (10) @(posedge aon_clk);
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1,
              "P35: static ON written at dynamic ON raises the event");

    // The same pair in a mode the policy holds, not ON.
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    wait_mode(PM_MEM_RET, 40000, "P35.mem_ret");
    clear_all_irq();
    set_policy(PM_MEM_RET, 1'b1, 1'b0);
    repeat (10) @(posedge aon_clk);
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b0,
              "P35: dynamic MEM_RET written at static MEM_RET raises no event");
    reg_read(A_PWSR, rd32);
    check(rd32[8] === 1'b1 && rd32[3:0] === PM_MEM_RET,
          "P35: still MEM_RET, PWR_DYN_STATUS set");
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    repeat (10) @(posedge aon_clk);
    check_irq(A_ISR, ISR_STA_POLICY_TRN, 1'b1,
              "P35: static MEM_RET written at dynamic MEM_RET raises the event");
    check(pwr_status === PM_MEM_RET && !seq_busy,
          "P35: none of the four writes moved the PPU");

    set_policy(PM_ON, 1'b0, 1'b0);
    wait_mode(PM_ON, 40000, "P35.restore");
    clear_all_irq();

    // -------------------------------------------------------------------------
    set_phase("P36 a lock written in a lockable mode holds it (3.4.3)");
    $display("[%0t]   Section 3.4.3, Locking the PPU: the PPU is locked when 'The", $time);
    $display("[%0t]   PPU_PWPR is written with LOCK_EN and PWR_DYN_EN set to 0b1", $time);
    $display("[%0t]   and:' ... 'The PPU is in a lockable power mode.' 'LOCK_EN", $time);
    $display("[%0t]   and PWR_DYN_EN do not need to have been 0b1 before the", $time);
    $display("[%0t]   write.' Once locked, the only transitions allowed are the", $time);
    $display("[%0t]   two _EMU ones, neither built here. P19 wrote the lock with", $time);
    $display("[%0t]   the SAME target; with a different one the write also asks", $time);
    $display("[%0t]   for a hop, and the lock must win on the write's own cycle.", $time);
    $display("[%0t]   Found by the SCP stress test (LOCK.RACE, finding 1).", $time);

    @(negedge dclk) wake = 1'b0;
    while (dev_qactive) @(negedge dclk);
    begin
      logic [3:0] from_m [3];
      logic [3:0] to_m   [3];
      from_m = '{PM_MEM_RET, PM_OFF, PM_OFF};
      to_m   = '{PM_OFF,     PM_ON,  PM_MEM_RET};
      for (int v = 0; v < 3; v++) begin
        string tag;
        bit    moved;
        tag = $sformatf("P36 {%0s} in static %0s", ppu_mode_name(to_m[v]),
                        ppu_mode_name(from_m[v]));
        set_policy(from_m[v], 1'b0, 1'b0);
        wait_mode(from_m[v], 40000, {tag, ".pre"});
        reg_write(A_IMR, 32'h0000_0002);       // LOCKED unmasked
        clear_all_irq();

        set_policy(to_m[v], 1'b1, 1'b1);       // one write: new target, DYN, LOCK
        moved = 1'b0;
        repeat (300) begin
          @(posedge aon_clk);
          if (seq_busy || (pwr_status !== from_m[v])) moved = 1'b1;
        end
        check(!moved, {tag, ": no transition started"});
        check_reg(A_PWSR, 32'h0000_1100 | from_m[v],
                  {tag, ": locked in the mode it was written in"});
        check_irq(A_ISR, ISR_LOCKED, 1'b1, {tag, ": LOCKED_IRQ fired"});

        // Unlocking releases the held policy. The PPU then follows it, and
        // re-locks on arrival if the target is lockable.
        reg_write(A_UNLK, 32'h0000_0001);
        wait_mode(to_m[v], 40000, {tag, ".released"});
        check(pwr_status === to_m[v], {tag, ": PPU_UNLK releases it to the policy"});

        set_policy(PM_ON, 1'b0, 1'b0);         // clears LOCK_EN: unlocks
        wait_mode(PM_ON, 40000, {tag, ".restore"});
      end
    end
    reg_write(A_IMR, 32'h0000_0022);           // restore the reset masks
    clear_all_irq();

    // -------------------------------------------------------------------------
    #500;
    set_phase("SUMMARY");
    check(viol == viol_base,
          "Q-Channel monitor: no violations outside the two sanctioned exceptions");
    $display("[%0t] checks=%0d  errors=%0d", $time, checks, tb_errors);
    $display("[%0t]   qchannel_monitor : %0d (5 expected: 1 in P3, 2 in P15, 2 in P30)", $time, viol);
    $display("[%0t]   ppu_monitor      : %0d (0 expected)", $time, uviol);
    $display("[%0t]   power model      : %0d (0 expected)", $time, pm_viol);

    // Coverage is checked, not merely printed. An uncovered reachable pair is a
    // route nothing in 477 checks has ever taken, which is a gap no passing
    // check can speak to.
    begin
      int holes;
      u_cov.report(holes);
      check(holes == 0,
            "SUMMARY: every reachable transition pair and every event was covered");
    end

    if (tb_errors == 0) $display("\n*** PPU TESTBENCH PASSED ***\n");
    else                $display("\n*** PPU TESTBENCH FAILED: %0d error(s) ***\n", tb_errors);
    $finish;
  end

  // Global watchdog: a sequencer that deadlocks would otherwise hang the run
  // rather than reporting, and a hang is much harder to read than a failure.
  //
  // SCALED with RAND_ITERS, because a fixed budget silently turns a long soak
  // into a watchdog trip. The directed phases P0-P30 need roughly 40 us; P26
  // costs about 0.4 us per iteration. The generous multiplier means a soak fails
  // for real reasons rather than for running out of time -- and the timeout
  // message prints the iteration budget so a trip is never ambiguous about which
  // it was.
  initial begin
    #(60000 + 2000 * RAND_ITERS);
    $display("\n[%0t] *** WATCHDOG TIMEOUT -- simulation did not finish ***", $time);
    $display("[%0t]     budget was 60us + 2us x %0d iterations", $time, RAND_ITERS);
    $display("[%0t]     last phase: %0s", $time, test_phase);
    $display("[%0t]     pwr_status=%0s seq_busy=%0b", $time,
             ppu_mode_name(pwr_status), seq_busy);
    $finish;
  end

endmodule
