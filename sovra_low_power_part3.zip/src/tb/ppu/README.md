# PPU testbenches

The verification of the Arm Power Policy Unit in
[`src/rtl/ppu/`](../../rtl/ppu/README.md) (Arm PPU Architecture Specification
v1.1, ARM DEN 0051E): one main suite on a PPU-controlled domain, a set of
smaller testbenches that each hold one thing the main suite cannot reach, the
checkers they share, and the power-aware collateral. The detailed account of
every phase, the mutation campaigns and the coverage arguments is
[`TEST_MATRIX.md`](TEST_MATRIX.md); this page is the map.

## Files

Counts are from the latest regression (`build/regress_p6/`, VCS). The
power-aware targets (`*pa`) need Xcelium, whose licence has expired.

| File | Top / role | Targets | What it checks | Latest |
|---|---|---|---|---|
| `ppu_pd_tb.sv` | `ppu_pd_tb` | `ppu`, `ppulint`, `wave-ppu`, `ppupa` | The main suite on `ppu_pd_top`: 39 phases (P0-P36 with P23a; P26 constrained-random): reset and the silent default transition, the programmer's model, ON to every mode and back with device-control ordering, WARM_RST, routing through ON, denial, the PCSM handshake, dynamic transitions, OFF → MEM_RET direct, unsupported policy, lock, delays, interrupts, channel enables, register sweeps, retention against corruption, isolation, the power-sequencing rules | 617 checks, PASSED |
| `ppu_coverage.sv` | `ppu_coverage` | (in `ppu_pd_tb`) | Measures the Table 4-14 transition matrix (the 13 pairs reachable on a Q-Channel PPU: ON to each of six modes, back, and the direct OFF → MEM_RET) and the Chapter 5 events, rather than asserting them in a table | |
| `ppu_power_model.sv` | `ppu_power_model` | (in `ppu_pd_tb`, `ppu_minconfig_tb`, `ppu_rstflight_tb`, `ppu_pm_tb`, `soc4_tb`) | What `upf/ppu_pd_top.upf` would do, in SystemVerilog: supply state from the PCSM's Table 3-1 decode, `corrupt`, `iso_clamp`, `do_save`/`do_restore`; and the ordering rules PU1-PU10 (isolation before supply removal, clock off and reset asserted before removal, supply before isolation release, etc.). Simulation only | |
| `ppu_pm_tb.sv` | `ppu_pm_tb` | `ppupm` | One targeted fault per PU rule, asserting which rules fire (a dead rule otherwise hides behind its neighbours; PU8 can never fire first) | 12 checks |
| `ppu_monitor_negtest.sv` | `ppu_monitor_negtest` | `ppuneg` | No DUT: proves `ppu_monitor` fires on each rule; each sub-test asserts that the count grew | 17 checks, 60 violations flagged |
| `ppu_reset_tb.sv` | `ppu_reset_tb` | `ppurst`, `ppurstpa` | Table 4-13 (reset behaviour, Section 4.2.1, 4.1.6): `u_a`-`u_d`, one DUT per row (DEF_PWR_POLICY × PCSMMODESTAT, both elaboration-time), plus `u_e` with PCSM_TINIT_WAIT 200; one shared bus. Row 2 is the regression for F5 (PWR_POLICY set to MEM_RET) | 38 checks |
| `ppu_rstflight_tb.sv` | `ppu_rstflight_tb` | `ppurstf`, `ppurstfpa` | RESETn asserted 1-60 cycles into a transition, for three destinations, with the monitors watching across the reset: recovery to the Table 4-13 mode, PU rules held, and `qchannel_monitor` R9 predicted per iteration | 12 checks (101 R-violations, all at reset edges) |
| `ppu_clkratio_tb.sv` | `ppu_clkratio_tb` | `ppuratio`, `ppuratiopa` | Section 4.1.5 at four PPU:device clock ratios from one image (`+aonhp`, `+dclkhp`): 3.19, 10.00, 1.10 and 0.15 (the PPU slower than its device). Every wait is edge-counted | 4 × PASS |
| `ppu_minconfig_tb.sv` | `ppu_minconfig_tb` | `ppucfg`, `ppucfgpa` | Chapter 7 configuration options: `u_max` (all on), `u_min` (all five optional features off, plus OFF_MEM_RET_TRANS), `u_nolock`, `u_nofr` (FULL_RET removed), `u_mix` (Section 3.4.3's mixed dynamic/static example). Checks demand the builds disagree, so a never-decoded address cannot pass | 90 checks |
| `ppu_irq_tb.sv` | `ppu_irq_tb` | `ppuirq` | `ppu_irq` alone, Section 4.1.2: an event cleared in the cycle it re-occurs stays set; masking; IRQ = OR of both status registers; ISR.OTHER derived from AISR | 16 checks |
| `ppu_regdoc_tb.sv` | `ppu_regdoc_tb` | `ppuregdoc`, `ppuregdocpa` | Every behavioural claim of `rtl/ppu/REGISTERS.md`, organised by the document; tags carry the section number | 100 checks |
| `ppu_be_tb.sv` | `ppu_be_tb` | `ppube`, `ppubepa` | Byte-lane write strobes: only ever writes with lanes masked (PWPR's pair rule across lanes, ISR's W1C across lanes) | 38 checks |
| `ppu_deny_tb.sv` | `ppu_deny_tb` | `ppudeny` | `ppu_seq` alone: denial possible in exactly one state, nothing left to reverse; the channel model only raises DEVQDENY where LPI Table 2-1 allows it | 42 checks |
| `ppu_devif_tb.sv` | `ppu_devif_tb` | `ppudevif` | PPU ↔ device interaction, one group per normative sentence (Sections 3.4.1-3.4.3, 4.1.3, 4.1.5, Table 4-4); stimulus always conformant | 47 checks |
| `ppu_clkctrl_tb.sv` | `ppu_clkctrl_tb` | `ppuclkctrl` | `ppu_clk_ctrl` (PCK-600 CLK-CTRL) statement by statement, four `qchannel_device_comb` devices on the gated clock, a second DUT with every Table 3-7 boolean cleared, six `qchannel_monitor`s | 82 checks |
| `ppu_clkq_tb.sv` | `ppu_clkq_tb` | `ppuclkq`, `ppuclkqpa` | The PPU's own clock Q-Channel (PPUCLK*): `u_dev` (bare `ppu_pd_top`, request by hand) and `u_top` (`ppu_clkq_top`, a real CLK-CTRL gating the PPU). G3: PPUCLKQACTIVE rises with zero clock edges after a wake | 81 checks |
| `ppu_axi_lite_tb.sv` | `ppu_axi_lite_tb` | `ppuaxi`, `ppuaxipa` | `ppu_top_axi_lite` and `ppu_axi_pd_top` driven by the vendored PULP `axi_test::axi_lite_driver` (L1-L13): reset, same-cycle write and read, WSTRB, VALID holding, PWAKEUP, an access to a PPU whose clock has stopped, SLVERR instead of a hung bus, a randomised soak | 64 checks |
| `ppu_lpd_pd_tb.sv` | `ppu_lpd_pd_tb` | `lpdpd`, `lpdpdpa` | `ppu_lpd_pd_top`: a single-channel PPU taking a three-device domain down and back through an LPD-Q, expander (`u_exp`) and sequencer (`u_seq`) | not in the regression |
| `ppu_pcsm_pgood_tb.sv` | `ppu_pcsm_pgood_tb` | `ppupcsmpg` | `ppu_pcsm`'s switch and retention sequencing (Section 4.1.6) with modelled switches: directed A/R/S/B/Z/M, continuous C1-C8, a 300-hop random walk; 15 runs over PGOOD_EN, controller sync and settle/delay settings | 15 of 15 runs PASS |
| `ppu_demo_tb.sv` | `ppu_demo_tb` | `ppudemo`, `wave-ppudemo`, `ppudemopa`, `wave-ppudemopa` | Not a checker: a guided tour, every feature once, with `phase_name` (ASCII) and `demo_step` on the waveform | 17 steps |
| `ppu_demo_probe.tcl` | SimVision script | `wave-ppudemopa` | Opens an SHM database, probes the design and the UPF supply nets, and runs to the end | |
| `ppu_pa_supply.sv` | `ppu_pa_supply` (second top) | every Xcelium `*pa` target | Energises the bench rails with `$supply_on` (UPF 1.0 `supply_on` is gone from IEEE 1801-2013); the testbench top is `` `PA_TOP ``, a define because the path must be elaboration-constant; stops the run if a rail is not found | |
| `TEST_MATRIX.md` | | | The phase-by-phase account, coverage, the three sanctioned monitor violations, mutation campaigns, soak results | |

## What every PPU testbench checks, besides its own claims

Three independent checkers run in the domain testbenches: `qchannel_monitor`
on the device Q-Channel (AMBA LPI rules R1-R10), `ppu_monitor` on the device
controls (rules U1-U12: PPUHWSTAT one-hot and supported, the settled controls match the mode, isolation,
clock and reset ordering, legal transitions, PCSMPSTATE), and `ppu_power_model` (PU1-PU10).
A run passes only with every one at zero, except for exactly measured,
sanctioned violations: `ppu_pd_tb` expects three Q-Channel violations (one in
P3 from Table 4-4, two in P15 from the channel disable), baselines the count
in each phase and asserts the exact delta, so any other violation still fails
(see TEST_MATRIX.md, "The three expected monitor violations").

## Running

```
make -C src ppu    SIM=vcs        # the main suite
make -C src ppuall SIM=vcs        # ppu ppuneg ppurst ppuratio ppucfg ppurstf ppuirq ppupm
                                  # ppuregdoc ppube ppudeny ppudevif ppuclkctrl ppuclkq ppuaxi
make -C src ppupcsmpg SIM=vcs
```

- `ppuall` does not include `ppudemo`, `ppupcsmpg` or `lpdpd`; the regression
  runs the first two.
- Pass/fail: the last lines of each log. `ppu_pd_tb` prints
  `checks=<n> errors=<m>` and `*** PPU TESTBENCH PASSED ***`; the others print
  `<top>: <n> checks, <m> error(s)` (or `checks run : <n>`) and
  `RESULT: PASS`. These make targets return 0 whatever the result (many pipe
  the run through `tail`), so read the line. `ppupcsmpg` is the exception: it
  fails unless all 15 runs print `RESULT: PASS`.
- Some benches stop with a watchdog `$fatal` if a run hangs.
- `ppuaxi` compiles the vendored PULP VIP (`PULP_FLAGS`, `PULP_VIP`); under
  VCS that needs nothing more.
- The power-aware targets (`ppupaall` = `ppupa ppubepa ppuregdocpa ppurstpa
  ppurstfpa ppucfgpa ppuratiopa ppuclkqpa ppuaxipa`, plus `ppudemopa`,
  `lpdpdpa`) add `+define+PPU_PA` and the UPF wrapper `upf/<top>.upf`. Under
  `PPU_PA` one check changes behaviour (P24's negative control); the check
  count is the same either way. They need Xcelium.

## Probes into the switched domain

Most reads are of the PPU, the PCSM and the always-on side. `ppu_pd_tb` reads
a few signals inside `PD_DEV` on purpose: `clk_gated` (the clock gate's
enable latch, compared against 1 so that X under power intent reads as
"gated"), and the workload state P23 uses to tell retention from corruption.
Each is commented where it is declared; `upf/README.md` records how a plain
inversion of the latch failed under UPF. New testbenches should not add such
reads (see [`../README.md`](../README.md), Section 5).

## Adding a test

- A new claim about the domain belongs in `ppu_pd_tb.sv` as a new phase (the
  next free number), with `check()` calls, and a row in `TEST_MATRIX.md`.
  If it needs stimulus a conformant partner would never produce, or an
  elaboration-time parameter, write a unit testbench instead, as
  `ppu_deny_tb`, `ppu_irq_tb`, `ppu_reset_tb` and `ppu_minconfig_tb` do.
- A new testbench: add a target beside the others in `src/Makefile` (sources
  `$(PPU_SRCS)` plus the testbench, and `ppu_power_model.sv` if it uses it),
  add it to `ppuall` and `.PHONY`, and to `TARGETS` in
  [`scripts/run_regress.sh`](../../../scripts/run_regress.sh).
- A new monitor or PU rule needs its own negative case in
  `ppu_monitor_negtest.sv` or `ppu_pm_tb.sv`.
- If the testbench instantiates `ppu_pd_top`, a power-aware target needs a
  UPF wrapper `upf/<top>.upf` and a `pa_build`/`pa_run` target.

## References

- Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E).
- Arm CoreLink PCK-600 TRM (101150): CLK-CTRL, LPD-Q, the PPU clock interface.
- AMBA Low Power Interface Specification (ARM IHI 0068C); AMBA AXI (IHI 0022,
  not in `references/standards`, so paraphrased in `ppu_axi_lite_tb`).
- [`src/rtl/ppu/README.md`](../../rtl/ppu/README.md),
  `src/rtl/ppu/REGISTERS.md`, `src/rtl/ppu/CONFORMANCE.md`,
  [`TEST_MATRIX.md`](TEST_MATRIX.md), [`src/upf/README.md`](../../upf/README.md).
