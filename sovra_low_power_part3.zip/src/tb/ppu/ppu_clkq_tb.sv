`timescale 1ns/1ps
// The PPU's own clock Q-Channel (PPUCLK*), checked statement by statement.
//
// References, and which document owns which claim:
//
//   Arm CoreLink PCK-600 TRM (101150)
//     Section 3.6  the PPU's four interfaces, one of which is a "Clock control
//                  interface: For high-level clock control"
//     Table A-28   pwakeup_i: "The PPU uses this wakeup signal as an input for
//                  the generation of the ppuclk_qactive_o signal. This signal
//                  must be driven from a register."
//     Table A-29   ppuclk_qreqn_i / ppuclk_qacceptn_o / ppuclk_qdeny_o are
//                  clocked by clk; ppuclk_qactive_o is "Asynchronous" and
//                  "indicates when the PPU requires the clk signal"
//     Table 3-7    QCLK_SYNC_EN
//
//   AMBA Low Power Interface Specification (ARM IHI 0068C)
//     Section 2.1.1  QACTIVE's independence from the handshake
//     Section 2.1.2  the accepted and denied sequences, and device reset
//     Section 4.1.1  the clock/power interface dependency in a multi-interface
//                    device -- the paragraph this whole file is about
//
//   Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E)
//     Section 3.3.1, 3.4.2  dynamic transitions and the DEVACTIVE wake
//     Section 4.1.3         PPU_PWCR and what disabling a DEVACTIVE input means
//     Section 4.1.6         the reset-time PCSM handshake
//     Table 6-1             the PPU's clock and reset signals -- and the reason
//                           this interface is marked "not in DEN 0051E"
//                           throughout: the architecture has no clock Q-Channel
//
// WHY THERE ARE TWO DUTs
//
// u_dev is a bare ppu_pd_top with PPUCLKQREQn driven by hand and its clock left
// running. That is the only way to get a quiescence request to arrive at a
// moment a real clock controller would never choose -- in the middle of a power
// mode transition -- and denial is a claim about exactly that moment. Same
// argument as ppu_deny_tb's header: proving a NEGATIVE needs stimulus a
// conformant partner would not produce.
//
// u_top is ppu_clkq_top: a real ppu_clk_ctrl gating a real PPU's clock. Nothing
// in it is driven by hand, and that is what makes it able to catch the failure
// u_dev cannot -- a design where PPUCLKQACTIVE is registered rather than
// combinational passes every check on u_dev and DEADLOCKS on u_top, because the
// clock that would register it has stopped.
//
// THE CENTRAL CLAIM, AND HOW IT IS PROVEN
//
// Group G3 asserts a wake while the PPU's clock is stopped and requires
// PPUCLKQACTIVE to rise with ZERO intervening clock edges, counted rather than
// assumed. A flip-flop cannot do that. If the interface is ever refactored to
// register QACTIVE "for cleanliness", that check is what fails.

module ppu_clkq_tb;

  import ppu_pkg::*;
  import qchannel_pkg::*;

  localparam int unsigned CNT_W = 8;

  logic aon_clk = 1'b0, dclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;
  always #6.85 dclk    = ~dclk;

  logic aon_rst_n = 1'b0;

  // ===========================================================================
  // DUT 1: the PPU alone, with its clock Q-Channel driven by this file
  // ===========================================================================
  logic [11:0] d_waddr = 12'h000, d_raddr = 12'h000;
  logic [31:0] d_wdata = 32'h0;
  logic        d_wen = 1'b0, d_ren = 1'b0;
  logic [3:0]  d_wstrb = 4'hF;
  logic [31:0] d_rdata;
  logic        d_irq;

  logic d_qreqn = 1'b1;              // driven by this file
  logic d_qacceptn, d_qdeny, d_qactive;
  logic d_pwakeup = 1'b0;

  logic d_wake = 1'b0;

  ppu_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_dev (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(d_waddr), .reg_raddr(d_raddr), .reg_wdata(d_wdata),
    .reg_wen(d_wen), .reg_wstrb(d_wstrb), .reg_ren(d_ren),
    .reg_rdata(d_rdata), .irq(d_irq),

    .ppuclk_qreqn(d_qreqn), .ppuclk_qacceptn(d_qacceptn),
    .ppuclk_qdeny(d_qdeny), .ppuclk_qactive(d_qactive),
    .pwakeup(d_pwakeup),

    .dclk(dclk), .start(1'b0), .work_len('0),
    .light_work(1'b1), .wake(d_wake), .deny_enb(1'b0),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0] d_status = u_dev.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] d_seq_st = u_dev.u_dom.u_ppu.u_seq.state;

  // The protocol checker on the clock channel. clk_gated is tied LOW because
  // nothing gates u_dev's clock -- its whole purpose is to be driven at moments
  // a gating controller would not choose.
  int unsigned d_viol;
  qchannel_monitor u_d_mon (
    .clk(aon_clk), .rst_n(aon_rst_n), .crst_n(aon_rst_n), .drst_n(aon_rst_n),
    .clk_gated(1'b0),
    .qreqn(d_qreqn), .qacceptn(d_qacceptn), .qdeny(d_qdeny), .violations(d_viol)
  );

  // ===========================================================================
  // DUT 2: the whole loop -- CLK-CTRL, gate, PPU, power domain
  // ===========================================================================
  logic [11:0] t_waddr = 12'h000, t_raddr = 12'h000;
  logic [31:0] t_wdata = 32'h0;
  logic        t_wen = 1'b0, t_ren = 1'b0;
  logic [3:0]  t_wstrb = 4'hF;
  logic [31:0] t_rdata;
  logic        t_irq;
  logic        t_pwakeup = 1'b0;

  logic t_hc_qreqn = 1'b1, t_pwr_qreqn = 1'b1;
  logic t_hc_qacceptn, t_hc_qdeny, t_hc_qactive;
  logic t_pwr_qacceptn, t_pwr_qdeny, t_pwr_qactive;
  logic t_qonly = 1'b0;
  logic t_clk_force = 1'b0;
  logic [7:0] t_entry_delay = 8'd0;

  logic t_wake = 1'b0;

  ppu_clkq_top #(
    .SYNC_STAGES     (2),
    .CNT_W           (CNT_W),
    .NUM_QACTIVE_ONLY(1),
    .DEF_PWR_POLICY  (PM_ON)
  ) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),

    .reg_waddr(t_waddr), .reg_raddr(t_raddr), .reg_wdata(t_wdata),
    .reg_wen(t_wen), .reg_wstrb(t_wstrb), .reg_ren(t_ren),
    .reg_rdata(t_rdata), .irq(t_irq), .pwakeup(t_pwakeup),

    .hc_qreqn_i(t_hc_qreqn), .hc_qacceptn_o(t_hc_qacceptn),
    .hc_qdeny_o(t_hc_qdeny), .hc_qactive_o(t_hc_qactive),
    .pwr_qreqn_i(t_pwr_qreqn), .pwr_qacceptn_o(t_pwr_qacceptn),
    .pwr_qdeny_o(t_pwr_qdeny), .pwr_qactive_o(t_pwr_qactive),

    .qactive_only_i(t_qonly),
    .clk_force_i(t_clk_force), .entry_delay_i(t_entry_delay), .dftcgen(1'b0),

    .dclk(dclk), .start(1'b0), .work_len('0),
    .light_work(1'b1), .wake(t_wake), .deny_enb(1'b0),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0] t_status  = u_top.u_pd.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] t_seq_st  = u_top.u_pd.u_dom.u_ppu.u_seq.state;
  wire       t_clken   = u_top.ppu_clken;
  wire       t_qactive = u_top.ppuclk_qactive;
  wire       t_qreqn   = u_top.ppuclk_qreqn;
  wire       t_qacc    = u_top.ppuclk_qacceptn;
  wire       t_qdeny   = u_top.ppuclk_qdeny;

  // Compared against 1 rather than inverted -- see ppu_pd_tb for why an X on
  // en_latch would otherwise fire qchannel_monitor's R10 spuriously.
  wire       t_gated   = (u_top.u_gate.en_latch !== 1'b1);

  int unsigned t_viol;
  qchannel_monitor u_t_mon (
    .clk(aon_clk), .rst_n(aon_rst_n), .crst_n(aon_rst_n), .drst_n(aon_rst_n),
    .clk_gated(t_gated),
    .qreqn(t_qreqn), .qacceptn(t_qacc), .qdeny(t_qdeny), .violations(t_viol)
  );

  // The thing G3 counts. Every edge the PPU's own clock actually delivers.
  int unsigned ppuclk_edges = 0;
  always @(posedge u_top.ppu_clk) ppuclk_edges++;

  // ===========================================================================
  // Continuous invariants
  // ===========================================================================

  // C5 / AMBA LPI Section 4.1.1: the PPU must claim its clock for the whole of
  // any transition. "CLK must be active to perform the management actions in
  // the device that are required before the power state transition, and to
  // respond on the power control interface."
  //
  // Checked on both DUTs, because they fail it differently: u_dev would simply
  // report the wrong thing, while u_top would be gated mid-sequence and freeze.
  int active_low_in_transition = 0;
  always @(posedge aon_clk)
    if (aon_rst_n && (d_seq_st !== 4'd0) && (d_qactive !== 1'b1))
      active_low_in_transition++;

  // G4: and the consequence -- the clock is never actually removed from a PPU
  // that has work in flight. Note that if this ever failed, t_seq_st would be
  // frozen at the state it was gated in, so the count keeps rising and the
  // failure is loud rather than a single sample.
  int gated_in_transition = 0;
  always @(posedge aon_clk)
    if (aon_rst_n && (t_clken !== 1'b1) && (t_seq_st !== 4'd0))
      gated_in_transition++;

  // ===========================================================================
  // Helpers
  // ===========================================================================
  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  task automatic settle(); repeat (900) @(posedge aon_clk); endtask

  // ---- Bus access, DUT 1 ----
  logic [31:0] d_rd;
  task automatic d_wreg(input logic [11:0] a, input logic [31:0] v);
    begin
      @(negedge aon_clk); d_waddr = a; d_wdata = v; d_wstrb = 4'hF; d_wen = 1'b1;
      @(negedge aon_clk); d_wen = 1'b0;
    end
  endtask
  task automatic d_rreg(input logic [11:0] a);
    begin
      @(negedge aon_clk); d_raddr = a; d_ren = 1'b1;
      @(negedge aon_clk); d_ren = 1'b0;
      @(negedge aon_clk); d_rd = d_rdata;
    end
  endtask

  // ---- Bus access, DUT 2 ----
  //
  // PWAKEUP is raised BEFORE the strobe and dropped after, which is the whole
  // protocol Table A-28 describes. A bus adapter would do this from the APB
  // PWAKEUP signal; here the testbench plays that part. t_wreg_nowake below is
  // the same access without it, used once, as a negative control.
  logic [31:0] t_rd;
  task automatic t_wreg(input logic [11:0] a, input logic [31:0] v);
    begin
      @(negedge aon_clk); t_pwakeup = 1'b1;
      repeat (40) @(posedge aon_clk);          // let the clock controller ungate
      @(negedge aon_clk); t_waddr = a; t_wdata = v; t_wstrb = 4'hF; t_wen = 1'b1;
      @(negedge aon_clk); t_wen = 1'b0;
      repeat (4) @(posedge aon_clk);
      @(negedge aon_clk); t_pwakeup = 1'b0;
    end
  endtask
  task automatic t_wreg_nowake(input logic [11:0] a, input logic [31:0] v);
    begin
      @(negedge aon_clk); t_waddr = a; t_wdata = v; t_wstrb = 4'hF; t_wen = 1'b1;
      @(negedge aon_clk); t_wen = 1'b0;
    end
  endtask
  task automatic t_rreg(input logic [11:0] a);
    begin
      @(negedge aon_clk); t_pwakeup = 1'b1;
      repeat (40) @(posedge aon_clk);
      @(negedge aon_clk); t_raddr = a; t_ren = 1'b1;
      @(negedge aon_clk); t_ren = 1'b0;
      @(negedge aon_clk); t_rd = t_rdata;
      @(negedge aon_clk); t_pwakeup = 1'b0;
    end
  endtask

  // ===========================================================================
  int  edges_before;
  bit  saw_deny, saw_accept;
  int  wake_latency;

  initial begin
    $dumpfile("ppu_clkq_tb.vcd");
    $dumpvars(0, ppu_clkq_tb);

    $display("==============================================================");
    $display(" ppu_clkq_tb: the PPU clock Q-Channel (PPUCLK*), end to end");
    $display("==============================================================");

    // =========================================================================
    section("C1 AMBA LPI 2.1.2 \"Device reset\"");
    // =========================================================================
    // "At reset assertion a device must drive both QACCEPTn and QDENY LOW."
    // "QACTIVE can reset LOW or HIGH. If the device must perform start-up
    //  operations on exit from reset then it can reset QACTIVE HIGH."
    //
    // A PPU has start-up operations and no choice about it: Section 4.1.6 gives
    // it a PCSM handshake to complete before it may do anything, and Section
    // 4.2.1 a default power policy to reach. So HIGH is the only correct
    // answer here, and it comes out of the design for free rather than from a
    // reset-value parameter -- PPU_ACTIVE includes !pcsm_init_done.
    repeat (4) @(posedge aon_clk);
    ck(d_qacceptn === 1'b0 && d_qdeny === 1'b0,
       "PPUCLKQACCEPTn and PPUCLKQDENY are both LOW under reset");
    ck(d_qactive === 1'b1,
       "PPUCLKQACTIVE is HIGH under reset: the PPU has start-up work to do");

    aon_rst_n = 1'b1;

    // The channel starts in Q_STOPPED (all three wires LOW) and QREQn is held
    // HIGH by this file, so the first thing it does is walk Q_EXIT -> Q_RUN.
    settle();
    ck(qch_decode(d_qreqn, d_qacceptn, d_qdeny) == Q_RUN,
       "and the interface reaches Q_RUN once reset is released");
    ck(d_status === PM_ON, "with the domain brought up to ON by the default policy");

    // =========================================================================
    section("C2 Table A-29: an idle PPU accepts a clock quiescence request");
    // =========================================================================
    // "ppuclk_qacceptn_o ... indicates when the PPU accepts a quiescence
    //  request to gate its clock."
    ck(d_qactive === 1'b0,
       "setup: PPUCLKQACTIVE is LOW -- the PPU no longer needs its clock");

    @(negedge aon_clk); d_qreqn = 1'b0;
    settle();
    ck(d_qacceptn === 1'b0, "PPUCLKQACCEPTn LOW: accepted");
    ck(d_qdeny === 1'b0,    "PPUCLKQDENY stayed LOW");
    ck(qch_decode(d_qreqn, d_qacceptn, d_qdeny) == Q_STOPPED,
       "the interface is in Q_STOPPED -- the clock may now be removed");

    @(negedge aon_clk); d_qreqn = 1'b1;
    settle();
    ck(qch_decode(d_qreqn, d_qacceptn, d_qdeny) == Q_RUN,
       "and the exit handshake returns it to Q_RUN");

    // =========================================================================
    section("C3 AMBA LPI 2.1.1: a busy PPU DENIES rather than stalling");
    // =========================================================================
    // "The denial mechanism means a device can maintain an operational state
    //  while having a mechanism by which it can promptly complete the handshake
    //  of a quiescence request."
    //
    // The request is issued mid-transition, which no conformant clock
    // controller would do -- it watches QACTIVE. That is exactly why it is
    // driven by hand here: the rule is about what the PPU does when it happens
    // anyway, and Table A-29 gives it a ppuclk_qdeny_o to do it with.
    //
    // Section 4.1.5's ordered walk is what makes stalling unacceptable: a
    // departure from ON runs the device handshake, five programmable delays and
    // a PCSM handshake, and a controller parked in Q_REQUEST for all of it is
    // the "performance limitation" the denial path exists to avoid.
    saw_deny   = 1'b0;
    saw_accept = 1'b0;

    fork
      begin : watch
        forever begin
          @(posedge aon_clk);
          if (d_qdeny    === 1'b1) saw_deny   = 1'b1;
          if (d_qacceptn === 1'b0) saw_accept = 1'b1;
        end
      end
    join_none

    d_wreg(A_PWPR, {28'h0, PM_OFF});
    // Two cycles in: past the register write, well inside the descent.
    repeat (2) @(posedge aon_clk);
    ck(d_seq_st !== 4'd0, "setup: a transition really is in flight");
    ck(d_qactive === 1'b1, "and PPUCLKQACTIVE is HIGH while it runs");

    @(negedge aon_clk); d_qreqn = 1'b0;
    repeat (30) @(posedge aon_clk);
    ck(saw_deny,    "PPUCLKQDENY went HIGH: the PPU refused to be gated");
    ck(!saw_accept, "and PPUCLKQACCEPTn never fell -- it did not accept instead");
    ck(qch_decode(d_qreqn, d_qacceptn, d_qdeny) == Q_DENIED,
       "the interface is in Q_DENIED, so the PPU remains operational");

    // =========================================================================
    section("C4 AMBA LPI 2.1.2: the denied handshake completes, work survives");
    // =========================================================================
    // "At T4 the controller drives QREQn HIGH. This state is referred to as
    //  Q_CONTINUE... At T5 the device drives QDENY LOW. The interface has
    //  returned to the state Q_RUN."
    //
    // The second check is the one that matters: a denial must cost the PPU
    // nothing. The transition that was under way when the request arrived has
    // to arrive at its destination as if the request had never happened.
    @(negedge aon_clk); d_qreqn = 1'b1;
    settle();
    ck(qch_decode(d_qreqn, d_qacceptn, d_qdeny) == Q_RUN,
       "PPUCLKQDENY dropped and the interface is back in Q_RUN");
    ck(d_status === PM_OFF,
       "and the interrupted transition still completed: PWR_STATUS is OFF");

    disable watch;

    // =========================================================================
    section("C5 Table A-28: PWAKEUP raises PPUCLKQACTIVE, independent of state");
    // =========================================================================
    // "The PPU uses this wakeup signal as an input for the generation of the
    //  ppuclk_qactive_o signal."
    //
    // And Section 2.1.1: "The handshake signal states are independent of the
    // state of QACTIVE. Therefore, transitions on QACTIVE are not restricted by
    // the values on QREQn or on the QACCEPTn and QDENY output pair."
    //
    // So the interface is deliberately parked in Q_STOPPED first. QACTIVE must
    // rise anyway -- which is not a curiosity, it is the only way software will
    // ever get its clock back.
    ck(d_qactive === 1'b0, "setup: idle in OFF, PPUCLKQACTIVE LOW");
    @(negedge aon_clk); d_qreqn = 1'b0;
    settle();
    ck(qch_decode(d_qreqn, d_qacceptn, d_qdeny) == Q_STOPPED, "setup: in Q_STOPPED");

    @(negedge aon_clk); d_pwakeup = 1'b1;
    @(posedge aon_clk);
    ck(d_qactive === 1'b1,
       "PWAKEUP raised PPUCLKQACTIVE within one cycle -- too fast for a synchronizer");
    ck(qch_decode(d_qreqn, d_qacceptn, d_qdeny) == Q_STOPPED,
       "and the handshake did not move: QACTIVE is independent of it");

    @(negedge aon_clk); d_pwakeup = 1'b0;
    repeat (4) @(posedge aon_clk);
    ck(d_qactive === 1'b0, "and it falls again when PWAKEUP is released");

    @(negedge aon_clk); d_qreqn = 1'b1;
    settle();

    // =========================================================================
    section("C6 AMBA LPI 4.1.1: DEVQACTIVE is the other clock dependency");
    // =========================================================================
    // "the dependency can be resolved... by a QACTIVE contribution from the
    //  power control interface logic that is active whenever P-Channel
    //  transitions require CLK to be active."
    //
    // DEVQACTIVE is a wake REQUEST to a PPU (Section 3.3.1), and servicing it
    // takes the PPU's clock. If it did not reach PPUCLKQACTIVE, a domain that
    // went to sleep with its PPU clock-gated could never be woken by its own
    // device -- and the PPU would have no way to notice, because the
    // synchronizer that would tell it is clocked by the clock it is missing.
    d_wreg(A_PWPR, {19'h0, 1'b0, 3'h0, 1'b1, 4'h0, PM_OFF});  // dynamic OFF
    settle();
    ck(d_status === PM_OFF, "setup: dynamic policy, domain in OFF");
    ck(d_qactive === 1'b0,  "setup: PPUCLKQACTIVE LOW");

    // Waited on the DEVQACTIVE PIN, not on the `wake` input that produces it.
    // The wrapper registers its own QACTIVE on dclk -- correctly, since a
    // POWER-control Q-Channel keeps its clock in Q_STOPPED -- so `wake` to
    // DEVQACTIVE is a dclk cycle that has nothing to do with the PPU. What is
    // being measured here is the hop AFTER that one, and one aon_clk cycle is
    // already too fast for the two-flop synchronizer the PPU uses everywhere
    // else on this pin.
    @(negedge dclk); d_wake = 1'b1;
    wait (u_dev.u_dom.dev_qactive === 1'b1);
    @(posedge aon_clk);
    ck(d_qactive === 1'b1,
       "DEVQACTIVE raised PPUCLKQACTIVE within one aon_clk cycle of the pin moving");
    settle();
    ck(d_status === PM_ON, "and the PPU serviced the wake: the domain is back ON");

    @(negedge aon_clk); d_wake = 1'b0;
    settle();

    // =========================================================================
    section("C7 Section 4.1.3: PPU_PWCR.PWR_DEVACTIVEEN qualifies it");
    // =========================================================================
    // A DEVACTIVE input the PPU has been told to ignore is not a reason to keep
    // its clock. Clearing PPU_PWCR[8] disconnects DEVQACTIVE from every
    // decision the sequencer makes, so it must disconnect it from this one too
    // -- otherwise a permanently-active device would pin the PPU's clock on for
    // no reason at all.
    d_wreg(A_PWPR, {28'h0, PM_ON});
    settle();
    d_wreg(A_PWCR, 32'h0000_0001);   // PWR_DEVACTIVEEN=0, DEVREQEN=1
    settle();
    ck(d_qactive === 1'b0, "setup: idle with PWR_DEVACTIVEEN cleared");

    @(negedge aon_clk); d_wake = 1'b1;
    repeat (8) @(posedge aon_clk);
    ck(d_qactive === 1'b0,
       "DEVQACTIVE no longer raises PPUCLKQACTIVE when PPU_PWCR says to ignore it");

    @(negedge aon_clk); d_wake = 1'b0;
    d_wreg(A_PWCR, 32'h0000_0101);   // back to the reset value
    settle();

    // =========================================================================
    section("C8 Table A-29: QACCEPTn and QDENY are clk, QACTIVE is not");
    // =========================================================================
    // The table gives ppuclk_qacceptn_o and ppuclk_qdeny_o a Clock column of
    // "clk" and ppuclk_qactive_o one of "Asynchronous". C5 already showed
    // QACTIVE beating a synchronizer; this is the other half -- that the
    // acknowledges do NOT, which is what makes them safe for the far domain to
    // sample. A combinationally-decoded QACCEPTn would violate Section 2.1.2's
    // requirement that the handshake acknowledges be driven from registers.
    ck(d_qactive === 1'b0 && d_qacceptn === 1'b1, "setup: idle, in Q_RUN");
    @(negedge aon_clk); d_qreqn = 1'b0;
    @(posedge aon_clk);
    ck(d_qacceptn === 1'b1,
       "PPUCLKQACCEPTn did not answer in the same cycle: it is registered, not decoded");
    settle();
    ck(d_qacceptn === 1'b0, "and it does answer, a synchronizer and an FSM edge later");
    @(negedge aon_clk); d_qreqn = 1'b1;
    settle();

    // =========================================================================
    section("G1 PCK-600 3.6: the PPU's clock genuinely stops");
    // =========================================================================
    // Everything above is about the handshake. This is about the point of it.
    // u_top has no hand-driven wires: the CLK-CTRL watches PPUCLKQACTIVE,
    // requests, the PPU accepts, and the gate closes.
    ck(t_status === PM_ON, "setup: u_top's domain is ON under its default policy");
    settle();
    ck(t_qactive === 1'b0, "the PPU stopped asking for its clock");
    ck(t_clken === 1'b0,   "so the clock controller gated it");
    ck(qch_decode(t_qreqn, t_qacc, t_qdeny) == Q_STOPPED,
       "with the interface in Q_STOPPED, which is the only state that permits it");

    edges_before = ppuclk_edges;
    repeat (500) @(posedge aon_clk);
    ck(ppuclk_edges == edges_before,
       $sformatf("and the clock really stopped: 0 PPU clock edges in 500 aon_clk cycles (%0d)",
                 ppuclk_edges - edges_before));

    // =========================================================================
    section("G2 Table A-28: without PWAKEUP the access is lost -- with it, not");
    // =========================================================================
    // "This signal must be driven from a register."
    //
    // The negative control first, because it is what justifies the port
    // existing at all. A register write issued to a PPU whose clock is stopped
    // reaches no clock edge and simply does not happen. Nothing else in the
    // system can rescue it: REG_WEN is not part of the Q-Channel and the clock
    // controller cannot see it.
    ck(t_clken === 1'b0, "setup: still gated");
    t_wreg_nowake(A_PWPR, {28'h0, PM_OFF});
    settle();
    ck(t_status === PM_ON,
       "a write with no PWAKEUP was lost: the domain is still ON");
    ck(t_clken === 1'b0, "and the clock was never ungated -- nothing asked for it");

    // Now the same write, announced properly.
    t_wreg(A_PWPR, {28'h0, PM_OFF});
    settle();
    ck(t_status === PM_OFF,
       "the same write with PWAKEUP leading it took effect: the domain is OFF");

    // =========================================================================
    section("G3 the wake loop, with the PPU's clock stopped");
    // =========================================================================
    // The claim qchannel_device_comb's header is built on, made falsifiable.
    //
    // The domain is OFF under a dynamic policy and the PPU's clock is stopped.
    // A wake now has to travel: DEVQACTIVE -> PPUCLKQACTIVE -> the clock
    // controller -> the gate -> the PPU's first clock edge in a long while ->
    // the sequencer -> the whole climb back to ON.
    //
    // The first hop is the one that cannot be done with a flip-flop, and it is
    // measured rather than asserted: ppuclk_edges must not have moved when
    // PPUCLKQACTIVE rises. If someone registers QACTIVE, this is the check that
    // fails -- and the ones after it hang, which is the honest consequence.
    t_wreg(A_PWPR, {19'h0, 1'b0, 3'h0, 1'b1, 4'h0, PM_OFF});   // dynamic OFF
    settle();
    ck(t_status === PM_OFF, "setup: dynamic policy, domain OFF");
    ck(t_clken === 1'b0,    "setup: the PPU's clock is gated");
    ck(t_qactive === 1'b0,  "setup: PPUCLKQACTIVE LOW");

    edges_before = ppuclk_edges;
    @(negedge dclk); t_wake = 1'b1;

    // Wait for QACTIVE to rise, with no reference to any clock at all.
    wake_latency = 0;
    fork
      begin : wait_act
        wait (t_qactive === 1'b1);
      end
      begin : wake_timeout
        repeat (2000) @(posedge aon_clk);
        $display("[%0t] PPUCLKQACTIVE never rose -- a registered QACTIVE cannot rise with the clock stopped", $time);
      end
    join_any
    disable wake_timeout;
    disable wait_act;

    ck(t_qactive === 1'b1, "DEVQACTIVE raised PPUCLKQACTIVE");
    ck(ppuclk_edges == edges_before,
       $sformatf("with ZERO PPU clock edges in between (%0d) -- it cannot be a flip-flop",
                 ppuclk_edges - edges_before));

    settle();
    ck(t_clken === 1'b1, "the clock controller ungated in response");
    ck(ppuclk_edges > edges_before, "the PPU's clock is running again");
    ck(t_status === PM_ON, "and the PPU serviced the wake: the domain climbed back to ON");

    @(negedge dclk); t_wake = 1'b0;
    settle();

    // =========================================================================
    section("G4 no register content was lost across the gating");
    // =========================================================================
    // A clock gate is only transparent if the state behind it survives. The
    // domain has been gated, woken, gated again and woken again by this point;
    // these are values written before all of that.
    t_wreg(A_DCDR0, 32'h0007_0605);
    t_wreg(A_EDTR0, 32'h0000_0004);
    settle();
    t_wreg(A_PWPR, {28'h0, PM_ON});
    settle();
    ck(t_clken === 1'b0, "setup: idle in ON and gated again");

    t_rreg(A_DCDR0);
    ck(t_rd === 32'h0007_0605,
       $sformatf("PPU_DCDR0 survived the gating: 0x%08x", t_rd));
    t_rreg(A_EDTR0);
    ck(t_rd === 32'h0000_0004,
       $sformatf("PPU_EDTR0 survived the gating: 0x%08x", t_rd));
    t_rreg(A_PWSR);
    ck(t_rd[3:0] === PM_ON, "and PPU_PWSR still reports ON");

    // Put the delays back so later groups are not slowed by them.
    t_wreg(A_DCDR0, 32'h0002_0202);
    t_wreg(A_EDTR0, 32'h0000_0000);
    settle();

    // =========================================================================
    section("G5 Table A-23: a hierarchical POWER request reaches the PPU");
    // =========================================================================
    // The CLK-CTRL is a device to an upstream power controller, and what it
    // owes that controller is the whole clock domain quiescent -- which here
    // means the PPU's own clock Q-Channel in Q_STOPPED. Two channels have to
    // agree for that to be true, which is the part worth checking.
    ck(t_clken === 1'b0, "setup: idle and gated");

    @(negedge aon_clk); t_pwr_qreqn = 1'b0;
    settle();
    ck(t_pwr_qacceptn === 1'b0, "the clock controller accepted the power request");
    ck(qch_decode(t_qreqn, t_qacc, t_qdeny) == Q_STOPPED,
       "with the PPU's own channel quiescent underneath it");

    // And the upstream hold: a wake now must not restart the domain on its own.
    @(negedge dclk); t_wake = 1'b1;
    settle();
    ck(t_pwr_qactive === 1'b1,
       "a wake raises pwr_qactive_o -- the only exit request the block has");
    ck(t_clken === 1'b0,
       "but does NOT ungate: the upstream power controller still holds it");

    @(negedge aon_clk); t_pwr_qreqn = 1'b1;
    settle();
    ck(t_clken === 1'b1, "withdrawing the upstream request releases the clock");
    ck(t_status === PM_ON, "and the domain is running");

    @(negedge dclk); t_wake = 1'b0;
    settle();

    // =========================================================================
    section("G6 LPI 4.1.3: a QACTIVE-only device holds the PPU's clock on");
    // =========================================================================
    // Nothing about this device is visible to the PPU. It has no handshake, it
    // is not in any power domain the PPU controls, and the PPU is idle -- yet
    // the clock must stay. That is the whole content of a QACTIVE-only
    // interface and it is wired to a port here so it is drivable.
    ck(t_clken === 1'b0, "setup: idle and gated");

    @(negedge aon_clk); t_qonly = 1'b1;
    settle();
    ck(t_clken === 1'b1, "the QACTIVE-only device ungated the PPU's clock");
    ck(qch_decode(t_qreqn, t_qacc, t_qdeny) == Q_RUN,
       "and moved the PPU's channel back to Q_RUN");
    ck(t_qactive === 1'b0,
       "with the PPU itself still not asking for anything");

    @(negedge aon_clk); t_qonly = 1'b0;
    settle();
    ck(t_clken === 1'b0, "releasing it lets the clock gate again");

    // =========================================================================
    section("G7 Table A-25: clk_force_i and entry_delay_i reach the PPU's gate");
    // =========================================================================
    // The same two controls ppu_clkctrl_tb measures at the unit level, checked
    // here for having survived the integration -- a parameter or port left
    // unconnected between ppu_clkq_top and ppu_clk_ctrl would pass every unit
    // check and do nothing at all in the system.
    @(negedge aon_clk); t_clk_force = 1'b1;
    settle();
    ck(t_clken === 1'b1, "clk_force_i HIGH holds the PPU's clock on");
    ck(qch_decode(t_qreqn, t_qacc, t_qdeny) == Q_RUN, "with its channel released");

    @(negedge aon_clk); t_clk_force = 1'b0;
    settle();
    ck(t_clken === 1'b0, "and clearing it gates again");

    @(negedge aon_clk); t_entry_delay = 8'd200;
    // Nudge the domain so the hysteresis has something to delay.
    t_wreg(A_PWPR, {28'h0, PM_ON});
    @(negedge aon_clk); t_qonly = 1'b1;
    repeat (50) @(posedge aon_clk);
    @(negedge aon_clk); t_qonly = 1'b0;
    repeat (100) @(posedge aon_clk);
    ck(t_clken === 1'b1,
       "entry_delay_i=200 still had the clock running 100 cycles after activity stopped");
    settle();
    ck(t_clken === 1'b0, "and it gated once the hysteresis expired");
    @(negedge aon_clk); t_entry_delay = 8'd0;
    settle();

    // =========================================================================
    section("G9 DEN 0051E 4.1.3: an edge interrupt needs no enable and no bus access");
    // =========================================================================
    // Section 4.1.3, DEVACTIVE Enables: "These enables have no effect on the
    // generation of interrupts. If an interrupt for a DEVACTIVE is unmasked it
    // still generates an interrupt event when the input changes." Table 5-9 says
    // it of PPU_PWCR too: the enables control "the ability of the DEVACTIVE
    // inputs to initiate power mode transitions, but not the ability to generate
    // input edge interrupt events."
    //
    // The edge detector runs on the PPU's own clock, so with PWR_DEVACTIVEEN = 0
    // the PPU has to ask for that clock itself whenever the input differs from
    // what the detector last saw. Before it did, the event waited for an
    // unrelated register access -- 4,950 cycles in the SCP stress test
    // (pmu/README.md 10.2 finding 2).
    t_wreg(A_PWCR, 32'h0000_0001);            // PWR_DEVACTIVEEN = 0, DEVREQEN kept
    t_wreg(A_IESR, {30'h0, EDGE_RISE});
    t_wreg(A_ISR, 32'hFFFF_FFFF);
    settle();
    ck(t_status === PM_ON && t_clken === 1'b0 && t_irq === 1'b0,
       "setup: ON, the enable off, rising edges selected, PPU clock gated, nothing pending");

    @(negedge dclk); t_wake = 1'b1;
    fork
      begin : g9_wait1
        wait (t_irq === 1'b1);
      end
      begin : g9_timeout1
        repeat (600) @(posedge aon_clk);
      end
    join_any
    disable g9_timeout1;
    disable g9_wait1;
    ck(t_irq === 1'b1, "a rising DEVQACTIVE raised the interrupt, with no register access");
    settle();
    ck(t_clken === 1'b0,
       "and the PPU's clock gated again with DEVQACTIVE still HIGH: nothing left unseen");
    t_rreg(A_ISR);
    ck(t_rd[ISR_PWR_ACTIVE_EDGE] === 1'b1, "PPU_ISR records it as the edge event");
    t_wreg(A_ISR, 32'h1 << ISR_PWR_ACTIVE_EDGE);
    settle();
    ck(t_irq === 1'b0, "cleared");

    // Only rises are selected, but the detector must follow a fall made while
    // the clock is stopped too, or the next rise would look like no change.
    @(negedge dclk); t_wake = 1'b0;
    settle();
    ck(t_irq === 1'b0 && t_clken === 1'b0,
       "the fall raised nothing, and the clock gated again");
    @(negedge dclk); t_wake = 1'b1;
    fork
      begin : g9_wait2
        wait (t_irq === 1'b1);
      end
      begin : g9_timeout2
        repeat (600) @(posedge aon_clk);
      end
    join_any
    disable g9_timeout2;
    disable g9_wait2;
    ck(t_irq === 1'b1, "the next rise raised it again: the fall was tracked while gated");
    t_wreg(A_ISR, 32'h1 << ISR_PWR_ACTIVE_EDGE);
    @(negedge dclk); t_wake = 1'b0;
    settle();

    // Control: with PPU_IESR at none nothing is watching the input, and an
    // edge must cost no PPU clock at all, as before the fix.
    t_wreg(A_IESR, 32'h0);
    settle();
    ck(t_clken === 1'b0, "control setup: PPU_IESR none, clock gated");
    edges_before = ppuclk_edges;
    @(negedge dclk); t_wake = 1'b1;
    settle();
    @(negedge dclk); t_wake = 1'b0;
    settle();
    ck(ppuclk_edges == edges_before && t_irq === 1'b0,
       $sformatf("control: with PPU_IESR none an edge pair cost %0d PPU clock edges and raised nothing",
                 ppuclk_edges - edges_before));

    t_wreg(A_PWCR, 32'h0000_0101);            // back to the reset value
    settle();

    // =========================================================================
    section("G8 the continuous invariants and the protocol monitors");
    // =========================================================================
    ck(active_low_in_transition == 0,
       $sformatf("u_dev: PPUCLKQACTIVE was HIGH in every non-idle cycle (%0d violations) -- LPI 4.1.1",
                 active_low_in_transition));
    ck(gated_in_transition == 0,
       $sformatf("u_top: the PPU's clock was never removed mid-transition (%0d violations)",
                 gated_in_transition));
    ck(d_viol == 0,
       $sformatf("u_dev clock channel: %0d protocol violations", d_viol));
    ck(t_viol == 0,
       $sformatf("u_top clock channel: %0d protocol violations", t_viol));

    // =========================================================================
    $display("");
    $display("==============================================================");
    $display(" ppu_clkq_tb: %0d checks, %0d error(s)", checks, errors);
    $display(" RESULT: %0s", (errors == 0) ? "PASS" : "FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    #20000000;
    $display("RESULT: FAIL");
    $fatal(1, "ppu_clkq_tb watchdog");
  end

endmodule
