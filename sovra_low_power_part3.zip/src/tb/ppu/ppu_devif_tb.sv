`timescale 1ns/1ps
// PPU <-> device interaction, checked statement by statement against the spec.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Sections 3.4.1, 3.4.2, 3.4.3, 4.1.3, 4.1.5, Table 4-4.
//
// HOW THIS FILE IS ORGANISED, AND WHY
//
// Every other PPU suite is organised by BEHAVIOUR -- a phase drives a scenario
// and checks what happens. This one is organised by SENTENCE. Each group below
// quotes one normative statement the specification makes about how the PPU and
// the device interact, and checks that statement and nothing else.
//
// The difference matters for what it can catch. A behaviour-organised suite
// tells you the design works; it cannot tell you which of the specification's
// claims have never been exercised, because nothing in it is indexed by claim.
// After this file exists, "is statement X checked?" is answerable by grep.
//
// SCOPE
//
// The device interface only. Register behaviour is ppu_regdoc_tb, the denial
// path is ppu_deny_tb, device-control ORDERING (Section 4.1.5) is ppu_pd_tb's
// P2 and P21-P25. What is left, and what is here, is the part where DEVQACTIVE
// and the channel enables decide whether a transition happens at all.
//
// STIMULUS IS CONFORMANT, ALWAYS
//
// DEVQACTIVE is driven through the wrapper's `wake` input, which is a legal
// device behaviour at any time. Nothing here forces DEVQACCEPTn or DEVQDENY:
// AMBA LPI Table 2-1 constrains when a device may assert those, and what a PPU
// does with an illegal assertion is undefined, so a check about it would pin
// down this implementation rather than the architecture. See ppu_deny_tb's
// header for the longer version of that argument.
//
// One consequence is stated rather than checked. Section 4.1.3 says that when a
// channel is disabled "the corresponding DEVACCEPT and DEVDENY inputs are
// ignored". A conformant device never asserts them while DEVQREQn is HIGH, so
// there is no legal stimulus that distinguishes "ignored" from "never arrived".
// What IS checkable is the observable half -- that DEVQREQn stays HIGH and the
// transition proceeds without waiting -- and that is group C7.

module ppu_devif_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  logic aon_clk = 1'b0, dclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;
  always #6.85 dclk    = ~dclk;

  logic        aon_rst_n = 1'b0;
  logic [11:0] reg_waddr = 12'h000, reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen = 1'b0, reg_ren = 1'b0;
  logic [3:0]  reg_wstrb = 4'hF;
  logic [31:0] reg_rdata;
  logic        irq;

  logic             start = 1'b0;
  logic [CNT_W-1:0] work_len = '0;
  logic             light_work = 1'b1;
  logic             wake = 1'b0;      // drives DEVQACTIVE; legal at any time
  logic             deny_enb = 1'b0;

  ppu_pd_top #(.SYNC_STAGES(2), .CNT_W(CNT_W)) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_wdata(reg_wdata), .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_raddr(reg_raddr), .reg_ren(reg_ren),
    .reg_rdata(reg_rdata), .irq(irq),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(start), .work_len(work_len),
    .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0] status  = u_top.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] seq_st  = u_top.u_dom.u_ppu.u_seq.state;
  wire       dev_qreqn = u_top.u_dom.dev_qreqn;
  wire       qactive  = u_top.u_dom.dev_qactive;
  // The sequencer's ENABLED, SYNCHRONIZED view -- the thing that actually gates
  // a transition. Setting `wake` is not the same as the PPU having seen it, and
  // a check that writes the policy before this is HIGH proves nothing.
  wire       qactive_eff = u_top.u_dom.u_ppu.u_seq.qactive_eff;

  // ---- The Section 3.4.2 invariant, watched continuously ----
  //
  // "Transitions to lower priority power modes are DELAYED until the relevant
  //  power mode DEVACTIVE inputs are LOW... all power mode DEVACTIVE inputs
  //  between FULL_RET and OFF must be LOW BEFORE THE PPU BEGINS the
  //  intermediate transition to ON."
  //
  // The sentence constrains when a transition may BEGIN. It says nothing about
  // DEVACTIVE rising afterwards, and Section 3.3.1 is explicit that raising the
  // mode on hardware signalling is what DYNAMIC transitions are for -- so under
  // a static policy a late DEVACTIVE must NOT abort a departure already under
  // way, and must not bring the domain back up once it has arrived.
  //
  // So this watches the COMMIT EDGE. An end-state check would flag the correct
  // behaviour as a violation: a domain that legitimately reached OFF before
  // DEVACTIVE rose is sitting in a low-power mode with DEVACTIVE HIGH, which
  // looks wrong and is not.
  //
  // It runs for the whole file, not just the group that exercises it, so every
  // other group is silently checked against it too.
  wire [3:0] cur_mode  = u_top.u_dom.u_ppu.u_seq.cur_mode;
  wire       qeff      = u_top.u_dom.u_ppu.u_seq.qactive_eff;
  wire       dyn_st    = u_top.u_dom.u_ppu.u_seq.dyn_status_q;
  wire [3:0] seq_pol   = u_top.u_dom.u_ppu.u_seq.pwr_policy;
  wire       wrst_pair = u_top.u_dom.u_ppu.u_seq.warm_rst_pair;

  logic [3:0] st_d;
  always @(posedge aon_clk) st_d <= seq_st;

  int began_while_active = 0;
  always @(posedge aon_clk)
    if (aon_rst_n && (st_d == 4'd0) && (seq_st != 4'd0)
        && !dyn_st && qeff && (seq_pol < cur_mode) && !wrst_pair)
      began_while_active <= began_while_active + 1;

  // Was DEVQREQn ever taken LOW? Sampled continuously, because "no handshake
  // was issued" is a claim about the whole window, not about its endpoints.
  bit reqn_fell;
  always @(posedge aon_clk) if (aon_rst_n && !dev_qreqn) reqn_fell <= 1'b1;

  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  logic [31:0] rd;
  task automatic wreg(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk); reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk); reg_wen = 1'b0;
    end
  endtask
  task automatic rreg(input logic [11:0] a);
    begin
      @(negedge aon_clk); reg_raddr = a; reg_ren = 1'b1;
      @(negedge aon_clk); reg_ren = 1'b0;
      @(negedge aon_clk); rd = reg_rdata;
    end
  endtask

  task automatic settle(); repeat (900) @(posedge aon_clk); endtask

  task automatic policy(input logic [3:0] p, input bit dyn);
    begin wreg(A_PWPR, {19'h0, 1'b0, 3'h0, dyn, 4'h0, p}); settle(); end
  endtask

  task automatic clear_irqs();
    begin wreg(A_ISR, 32'hFFFF_FFFF); wreg(A_AISR, 32'hFFFF_FFFF); end
  endtask

  initial begin
    $dumpfile("ppu_devif_tb.vcd");
    $dumpvars(0, ppu_devif_tb);

    $display("==============================================================");
    $display(" ppu_devif_tb: PPU <-> device interaction, statement by statement");
    $display("==============================================================");

    repeat (8) @(posedge aon_clk);
    aon_rst_n = 1'b1;
    settle();
    ck(status === PM_ON, "setup: DEF_PWR_POLICY = ON brought the domain up");

    // =========================================================================
    section("C1 3.4.2: a departure from ON waits for DEVQACTIVE LOW");
    // =========================================================================
    // "For transitions from ON, other than to WARM_RST, all DEVQACTIVE inputs
    //  must be LOW to begin a transition."
    //
    // "to BEGIN a transition" is the operative phrase: the PPU must not even
    // issue the request. Checking only that it has not ARRIVED would be
    // satisfied by a PPU that requested and was refused.
    wake = 1'b1;
    settle();
    reqn_fell = 1'b0;
    wreg(A_PWPR, {28'h0, PM_OFF});
    settle();
    ck(status === PM_ON, "still in ON with DEVQACTIVE HIGH");
    ck(!reqn_fell,       "and DEVQREQn never fell: the transition never BEGAN");
    rreg(A_PWPR);
    ck(rd[3:0] === PM_OFF, "the policy is retained, not discarded -- it is delayed");

    wake = 1'b0;
    settle();
    ck(status === PM_OFF, "DEVQACTIVE LOW releases it and the descent completes");

    // =========================================================================
    section("C2 3.4.2: DEVQACTIVE does not delay a rise in priority");
    // =========================================================================
    // "The power mode DEVACTIVE inputs do not delay transitions to higher
    //  priority power modes."
    wake = 1'b1;
    // Wait for the PPU to have SEEN it. Without this the policy write races the
    // synchronizer and the climb starts before qactive_eff rises -- the check
    // then passes against a design that blocks rises too, which is exactly the
    // mutation it exists to catch.
    repeat (60) @(posedge aon_clk);
    ck(qactive_eff === 1'b1, "setup: the PPU's enabled view of DEVQACTIVE is HIGH");
    reqn_fell = 1'b0;
    wreg(A_PWPR, {28'h0, PM_ON});
    settle();
    ck(qactive_eff === 1'b1, "DEVQACTIVE stayed HIGH for the whole climb");
    ck(status === PM_ON, "climbed OFF -> ON with DEVQACTIVE HIGH throughout");
    wake = 1'b0;
    settle();

    // =========================================================================
    section("C3 3.4.2: the delay applies to the INTERMEDIATE hop too");
    // =========================================================================
    // "This is true even if the PPU must go through an intermediate power mode
    //  to reach the programmed policy. For example, a component in FULL_RET
    //  cannot make a direct transition to OFF, it must pass through ON.
    //  However, all power mode DEVACTIVE inputs between FULL_RET and OFF must
    //  be LOW BEFORE THE PPU BEGINS THE INTERMEDIATE TRANSITION TO ON."
    //
    // The specification's own example, run literally. This is the statement
    // defect F9 violated: the PPU climbed to ON and parked there, so a static
    // request for OFF left the domain fully powered.
    policy(PM_FULL_RET, 1'b0);
    ck(status === PM_FULL_RET, "setup: in FULL_RET");

    wake = 1'b1;
    settle();
    wreg(A_PWPR, {28'h0, PM_OFF});
    settle();
    ck(status === PM_FULL_RET,
       "with DEVQACTIVE HIGH the PPU stays in FULL_RET -- it does NOT climb to ON");

    wake = 1'b0;
    settle();
    ck(status === PM_OFF, "DEVQACTIVE LOW lets the whole route run to OFF");

    // =========================================================================
    section("C4 3.4.2: ON <-> WARM_RST has no DEVQACTIVE dependence");
    // =========================================================================
    // "For transitions between ON and WARM_RST there is no dependence on the
    //  DEVQACTIVE inputs."
    policy(PM_ON, 1'b0);
    wake = 1'b1;
    settle();
    wreg(A_PWPR, {28'h0, PM_WARM_RST});
    settle();
    ck(status === PM_WARM_RST, "ON -> WARM_RST proceeded with DEVQACTIVE HIGH");

    wreg(A_PWPR, {28'h0, PM_ON});
    settle();
    ck(status === PM_ON, "and WARM_RST -> ON did too");
    wake = 1'b0;
    settle();

    // =========================================================================
    section("C5 3.4.1: a disabled DEVACTIVE input is assumed LOW");
    // =========================================================================
    // "Disabled power mode DEVACTIVE inputs are always assumed to be LOW for
    //  the purposes of transition control."
    //
    // So with the enable cleared, C1's block must not happen even though the
    // input itself is HIGH.
    wake = 1'b1;
    settle();
    wreg(A_PWCR, 32'h0000_0001);            // PWR_DEVACTIVEEN = 0, channel on
    settle();
    wreg(A_PWPR, {28'h0, PM_OFF});
    settle();
    ck(status === PM_OFF,
       "descended with DEVQACTIVE HIGH but its enable cleared");

    wreg(A_PWCR, 32'h0000_0101);
    wake = 1'b0;
    policy(PM_ON, 1'b0);

    // =========================================================================
    section("C6 4.1.3: the enables do not affect interrupt generation");
    // =========================================================================
    // "These enables have no effect on the generation of interrupts. If an
    //  interrupt for a DEVACTIVE is unmasked it still generates an interrupt
    //  event when the input changes. This allows DEVACTIVE changes to be
    //  monitored by software."
    //
    // Easy to get wrong in the tempting direction: gate the interrupt off the
    // same enabled view the sequencer uses, and this fails while every
    // transition test still passes.
    wreg(A_PWCR, 32'h0000_0001);            // PWR_DEVACTIVEEN = 0
    wreg(A_IESR, 32'h0000_0003);            // both DEVACTIVE edges enabled
    clear_irqs();
    wake = 1'b1;  repeat (80) @(posedge aon_clk);
    wake = 1'b0;  repeat (80) @(posedge aon_clk);
    rreg(A_ISR);
    ck(rd[ISR_PWR_ACTIVE_EDGE] === 1'b1,
       "a DEVQACTIVE edge still raises PWR_ACTIVE_EDGE_IRQ with the enable OFF");
    wreg(A_PWCR, 32'h0000_0101);
    clear_irqs();

    // =========================================================================
    section("C7 4.1.3: a disabled channel drives DEVQREQn permanently HIGH");
    // =========================================================================
    // "When a device interface channel is disabled: Q-Channel: DEVQREQn is
    //  driven permanently HIGH... transitions continue without issuing requests
    //  or waiting for responses on the disabled channels."
    //
    // Two claims, both checked: DEVQREQn never falls, and the transition still
    // completes. Either alone would be satisfied by a broken design -- a PPU
    // that hung would satisfy the first, one that handshook anyway the second.
    policy(PM_ON, 1'b0);
    wreg(A_PWCR, 32'h0000_0100);            // DEVREQEN = 0, DEVACTIVEEN = 1
    settle();
    reqn_fell = 1'b0;
    wreg(A_PWPR, {28'h0, PM_OFF});
    settle();
    ck(status === PM_OFF, "the transition completed with the channel disabled");
    ck(!reqn_fell,        "and DEVQREQn stayed HIGH throughout");

    reqn_fell = 1'b0;
    wreg(A_PWPR, {28'h0, PM_ON});
    settle();
    ck(status === PM_ON, "so did the return");
    ck(!reqn_fell,       "with DEVQREQn still never falling");
    wreg(A_PWCR, 32'h0000_0101);
    settle();

    // =========================================================================
    section("C8 Table 4-4: the WARM_RST handshake needs BOTH enables");
    // =========================================================================
    //   DEVREQEN  WARM_RST_DEVREQEN   handshake
    //      0             X               No
    //      1             0               No
    //      1             1               Yes
    // All three rows, and the point of the table is that the two controls are
    // independent -- so a design honouring only one of them passes a test that
    // checks only the third row.
    wreg(A_PTCR, 32'h0000_0001);            // WARM_RST_DEVREQEN = 1
    wreg(A_PWCR, 32'h0000_0101);            // DEVREQEN = 1
    reqn_fell = 1'b0;
    wreg(A_PWPR, {28'h0, PM_WARM_RST}); settle();
    ck(reqn_fell, "row 3 (1,1): the handshake IS performed");
    wreg(A_PWPR, {28'h0, PM_ON}); settle();

    wreg(A_PTCR, 32'h0000_0000);            // WARM_RST_DEVREQEN = 0
    reqn_fell = 1'b0;
    wreg(A_PWPR, {28'h0, PM_WARM_RST}); settle();
    ck(status === PM_WARM_RST, "row 2 (1,0): the transition still happens");
    ck(!reqn_fell,             "  ...but with NO handshake");
    wreg(A_PWPR, {28'h0, PM_ON}); settle();

    wreg(A_PWCR, 32'h0000_0100);            // DEVREQEN = 0
    wreg(A_PTCR, 32'h0000_0001);            // WARM_RST_DEVREQEN = 1
    reqn_fell = 1'b0;
    wreg(A_PWPR, {28'h0, PM_WARM_RST}); settle();
    ck(status === PM_WARM_RST, "row 1 (0,X): the transition still happens");
    ck(!reqn_fell,             "  ...and still no handshake, DEVREQEN overrides");
    wreg(A_PWPR, {28'h0, PM_ON}); settle();
    wreg(A_PWCR, 32'h0000_0101);
    wreg(A_PTCR, 32'h0000_0001);
    settle();

    // =========================================================================
    section("C9 3.4.3: dynamic transitions follow DEVQACTIVE in both directions");
    // =========================================================================
    // "When in ON, all DEVQACTIVE signals set LOW starts a transition to the
    //  programmed power mode policy. When in the programmed power mode policy,
    //  a HIGH level on any DEVQACTIVE input starts a transition to ON."
    //
    // Note what is NOT required: a policy write. Under a dynamic policy the
    // device alone moves the domain, in both directions.
    wake = 1'b1;
    policy(PM_OFF, 1'b1);                   // dynamic, minimum OFF
    ck(status === PM_ON, "setup: dynamic OFF policy, held in ON by DEVQACTIVE");

    wake = 1'b0;
    settle();
    ck(status === PM_OFF, "DEVQACTIVE LOW alone took it to the policy");

    wake = 1'b1;
    settle();
    ck(status === PM_ON, "DEVQACTIVE HIGH alone brought it back to ON");

    wake = 1'b0;
    settle();
    ck(status === PM_OFF, "and LOW again sends it back down, with no writes");

    // =========================================================================
    section("C10 3.4.3: dynamic WARM_RST is not supported on a Q-Channel PPU");
    // =========================================================================
    // "The exception to this rule is WARM_RST. Dynamic transitions to and from
    //  this power mode are not supported for a Q-Channel PPU."
    //
    // Section 4.1.1 makes an unsupported policy a refusal with
    // UNSPT_POLICY_IRQ, not a silent no-op, so the refusal is what is checked.
    wake = 1'b1;
    policy(PM_ON, 1'b0);
    clear_irqs();
    rreg(A_PWPR);
    begin
      logic [31:0] before_pwpr;
      before_pwpr = rd;
      wreg(A_PWPR, {19'h0, 1'b0, 3'h0, 1'b1, 4'h0, PM_WARM_RST});  // dynamic WARM_RST
      settle();
      rreg(A_PWPR);
      ck(rd === before_pwpr, "a dynamic WARM_RST policy is refused, PPU_PWPR unchanged");
    end
    rreg(A_AISR);
    ck(rd[AISR_UNSPT_POLICY] === 1'b1, "and UNSPT_POLICY_IRQ is raised");
    clear_irqs();
    wake = 1'b0;

    // =========================================================================
    section("C11 3.4.2: DEVQACTIVE arriving mid-route, swept");
    // =========================================================================
    // The race C1 and C3 do not reach. There, DEVQACTIVE is already HIGH when
    // the policy is written. Here it rises at cycle d of a FULL_RET -> ON ->
    // OFF route, for every d across the whole route -- so it lands before the
    // climb commits, during the climb, at the arrival in ON, and after the
    // departure from ON has already begun.
    //
    // The outcome legitimately DIFFERS across that range, which is why the
    // check is the commit-edge invariant above and not the end state:
    //
    //   early d  the descent has not begun     -> the PPU parks in ON
    //   late  d  the descent is already under way -> it completes to OFF, and
    //            must, because a static policy is not raised by DEVACTIVE
    //
    // Both are correct. What must never happen at any d is a descent BEGINNING
    // while DEVQACTIVE is HIGH.
    begin
      int d, parked_on, ran_on;
      parked_on = 0; ran_on = 0;
      began_while_active = 0;

      for (d = 0; d <= 48; d = d + 4) begin
        wake = 1'b0;
        wreg(A_PWPR, {28'h0, PM_FULL_RET}); settle();
        wreg(A_PWPR, {28'h0, PM_OFF});
        repeat (d) @(posedge aon_clk);
        wake = 1'b1;
        settle();
        if (status === PM_ON)  parked_on++;
        if (status === PM_OFF) ran_on++;
        wake = 1'b0;
        settle();
        ck(status === PM_OFF,
           $sformatf("d=%0d: releasing DEVQACTIVE completes the route to OFF", d));
      end

      ck(began_while_active == 0,
         "across the whole sweep, no descent ever BEGAN with DEVQACTIVE HIGH");
      // Both outcomes must actually occur, or the sweep only covered one side
      // of the commit edge and proves half of what it claims.
      ck(parked_on > 0, $sformatf("  ...%0d arrival(s) landed early and parked in ON", parked_on));
      ck(ran_on   > 0, $sformatf("  ...%0d landed late and correctly ran on to OFF", ran_on));
    end

    ck(began_while_active == 0,
       "and the invariant held for every group in this file");

    // =========================================================================
    $display("");
    $display("==============================================================");
    $display(" ppu_devif_tb: %0d checks, %0d error(s)", checks, errors);
    $display(" RESULT: %0s", (errors == 0) ? "PASS" : "FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    #8000000;
    $display("RESULT: FAIL");
    $fatal(1, "ppu_devif_tb watchdog");
  end

endmodule
