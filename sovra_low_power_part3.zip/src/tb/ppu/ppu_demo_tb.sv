`timescale 1ns/1ps
// PPU guided tour -- built to be WATCHED, not to catch bugs.
//
// Every other testbench here is a checker: ppu_pd_tb runs 37 phases and 537
// checks, most of them register sweeps, denial corner cases and a random storm,
// because its job is to break things. That makes it the wrong thing to open in a
// waveform viewer -- the transitions worth studying are scattered among stimulus
// designed to be pathological.
//
// This file does the opposite. One DUT, no random stimulus, no negative tests,
// no corner cases. It visits each feature once, in a sensible order, with a
// visible gap between steps, and announces what it is about to do before doing
// it. It asserts almost nothing: if you want to know whether the PPU is CORRECT,
// run `make ppuall`. This answers "what does it actually do".
//
// WATCHING IT
//
//   make ppudemo              # run, print the tour, write ppu_demo_tb.vcd
//   gtkwave ../build/ppu_demo_tb.vcd &
//
// `phase_name` is the first thing to put on the waveform. It is a packed byte
// vector carrying the current step's TITLE as text -- set the trace's radix to
// ASCII (SimVision: right-click -> Radix -> ASCII; GTKWave: right-click ->
// Data Format -> ASCII) and the waveform labels itself, so you can tell what
// you are looking at without counting back to the transcript.
//
// `demo_step` is the same thing as a number, useful for navigating by value.
//
// The signals worth adding, roughly in this order:
//
//   phase_name                the step's title, in ASCII
//   demo_step                 the same step as a number
//   pwr_status                the mode the PPU is in  (4'h8 = ON, 0 = OFF, ...)
//   dev_qreqn/acceptn/deny     the device handshake
//   dev_clken dev_isolaten      device controls, in the order the PPU moves them
//   dev_poresetn/warm/ret
//   pcsm_preq pcsm_pstate       the PCSM request and what was asked for
//   logic_on logic_ret        what the PCSM actually did to the supplies
//   ram_on ram_ret
//   wake                      the wake input, for the dynamic step
//   irq                       the interrupt output
//
// And, for the device the modes are acting ON:
//
//   sig_nret                  non-retained logic -- cleared by a warm reset
//   sig_ret                   retained logic -- survives FULL_RET alone
//   ram_bank_ok               per-bank survival, after a verify
//   bank_sleep bank_sd        the SRAM macro pins, per bank
//   ret_n                     the retention save/restore strobe
//   ram_cfg                   PCSMPSTATE[15:8], which banks are configured
//
// sig_ret against sig_nret through step 6 is the single most informative pair
// on the waveform: they diverge in FULL_RET and nowhere else.
//
// WITH UPF
//
//   make ppudemopa            # needs Xcelium/VCS/Questa; see upf/README.md
//
// The DUT is instantiated as `u_top`, the same name ppu_pd_tb uses, so
// upf/ppu_demo_tb.upf is the 9-line wrapper with the design top renamed and
// nothing else changed. Under UPF the interesting extra is that PD_DEV's
// registers CORRUPT when the supply goes, so OFF and "held in reset" stop
// looking alike -- which is the whole reason the power intent exists.

module ppu_demo_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  logic aon_clk = 1'b0, dclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;   // PPU / PCSM clock
  always #6.85 dclk    = ~dclk;      // device clock, deliberately unrelated

  logic aon_rst_n = 1'b0;

  logic [11:0] reg_waddr  = 12'h000;

  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0] reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;
  logic [31:0] reg_rdata;
  logic        irq;

  logic             start      = 1'b0;
  logic [CNT_W-1:0] work_len   = 8'd0;
  logic             light_work = 1'b1;
  logic             wake       = 1'b0;
  logic             deny_enb   = 1'b0;

  // Device IP command: 00 idle, 01 fill, 10 verify. See ppu_device_ip.
  logic [1:0]       ip_cmd     = 2'b00;
  logic [7:0]       ip_seed    = 8'h00;

  // The bookmark strip. Put this on the waveform first.
  int unsigned demo_step = 0;

  // ---------------------------------------------------------------------------
  // The phase name, as a waveform signal
  // ---------------------------------------------------------------------------
  // A PACKED BYTE VECTOR, deliberately not a SystemVerilog `string`. A string is
  // a dynamically-sized type: it has no fixed bit width, so it has no VCD
  // representation at all and no waveform viewer can display it. A vector of
  // bytes does have one, and both SimVision and GTKWave render it as text once
  // the radix is set to ASCII -- so this shows the current step's title on the
  // waveform beside the signals it is describing.
  //
  //   SimVision   right-click the trace -> Radix -> ASCII
  //   GTKWave     right-click -> Data Format -> ASCII
  //
  // Fixed at PHASE_CHARS wide and space-padded rather than zero-padded: a
  // shorter title leaves blanks instead of NULs, which viewers draw as garbage.
  localparam int unsigned PHASE_CHARS = 48;
  reg [8*PHASE_CHARS-1:0] phase_name;

  // Char 0 goes in the MOST significant byte, because that is the order an
  // ASCII-radix display reads a vector in. Right-justifying (the default for a
  // plain string-to-vector assignment) would render it backwards-looking, with
  // the text jammed against the end of the field.
  function automatic logic [8*PHASE_CHARS-1:0] as_ascii(input string t);
    begin
      as_ascii = '0;
      for (int i = 0; i < PHASE_CHARS; i++)
        as_ascii[8*(PHASE_CHARS-1-i) +: 8] = (i < t.len()) ? t.getc(i) : " ";
    end
  endfunction

  // DEF_PWR_POLICY = OFF, not the module default of ON, and the choice shapes
  // the whole first step. Section 4.2.1 "Reset to OFF": the PPU "remains in OFF
  // until another policy is programmed" -- so reset and power-up become two
  // separate events you can watch happen, instead of one automatic transition
  // that is already over by the time you go looking for it.
  ppu_pd_top #(
    .SYNC_STAGES    (2),
    .CNT_W          (CNT_W),
    .DEF_PWR_POLICY (PM_OFF)
  ) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),
    .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_ren(reg_ren), .reg_rdata(reg_rdata), .irq(irq),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(start), .work_len(work_len),
    .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(ip_cmd), .ip_seed(ip_seed)
  );

  // ---------------------------------------------------------------------------
  // Everything worth watching, lifted to the top level so it is one click away
  // in a viewer instead of buried under u_top/u_dom/u_ppu/u_seq.
  // ---------------------------------------------------------------------------
  wire [3:0]  pwr_status  = u_top.u_dom.u_ppu.u_seq.pwr_status;
  wire [15:0] ppuhwstat   = u_top.ppuhwstat;

  wire dev_qreqn    = u_top.u_dom.dev_qreqn;
  wire dev_qacceptn = u_top.u_dom.dev_qacceptn;
  wire dev_qdeny    = u_top.u_dom.dev_qdeny;
  wire dev_qactive  = u_top.u_dom.dev_qactive;

  wire dev_clken     = u_top.u_dom.dev_clken;
  wire dev_isolaten  = u_top.dev_isolaten;
  wire dev_poresetn  = u_top.u_dom.dev_poresetn;
  wire dev_warmresetn= u_top.u_dom.dev_warmresetn;
  wire dev_retresetn = u_top.u_dom.dev_retresetn;

  wire        pcsm_preq    = u_top.u_dom.pcsm_preq;
  wire        pcsm_paccept = u_top.u_dom.pcsm_paccept;
  wire [15:0] pcsm_pstate  = u_top.u_dom.pcsm_pstate;

  wire logic_on  = u_top.logic_on;      // full supply present
  wire logic_ret = u_top.logic_ret;     // retention supply
  wire ram_on    = u_top.u_dom.ram_on;
  wire ram_ret   = u_top.u_dom.ram_ret;

  wire busy      = u_top.busy;          // the device is running
  wire seq_busy  = (u_top.u_dom.u_ppu.u_seq.state !== 4'd0);

  // ---- The device IP: the three classes of state the modes act on ----
  // sig_nret is reset by DEVPORESETn & DEVWARMRESETn, sig_ret by DEVPORESETn &
  // DEVRETRESETn plus a UPF retention cell on the VDD_RET rail, and the eight
  // RAM banks by their own sleep/shutdown pins. No two power modes leave the
  // three of them in the same combination -- which is the entire reason
  // ppu_device_ip replaced the counter that used to be here.
  wire [31:0] sig_nret    = u_top.u_ip.u_core.sig_nret;
  wire [31:0] sig_ret     = u_top.u_ip.u_ret.sig;
  wire [7:0]  ram_bank_ok = u_top.u_ip.u_core.ram_bank_ok;
  wire [7:0]  bank_sleep  = u_top.ram_sleep;   // per-bank: hold, no access
  wire [7:0]  bank_sd     = u_top.ram_sd;      // per-bank: power gone
  wire        ret_n       = u_top.ret_n;       // retention save/restore strobe
  wire [7:0]  ram_cfg     = u_top.u_dom.ram_cfg;     // PCSMPSTATE[15:8]

  // ---------------------------------------------------------------------------
  task automatic step(input int unsigned n, input string what);
    begin
      demo_step  = n;
      phase_name = as_ascii($sformatf("%0d. %0s", n, what));
      $display("");
      $display("--- step %0d: %0s", n, what);
    end
  endtask

  task automatic say(input string msg);
    $display("      %0s", msg);
  endtask

  task automatic reg_write(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk); reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk); reg_wen = 1'b0;
    end
  endtask

  task automatic reg_read(input logic [11:0] a);
    begin
      @(negedge aon_clk); reg_raddr = a; reg_ren = 1'b1;
      @(negedge aon_clk); reg_ren = 1'b0;
      @(negedge aon_clk);
    end
  endtask

  task automatic set_policy(input logic [3:0] m, input bit dyn, input bit lock);
    reg_write(A_PWPR, {19'h0, lock, 3'h0, dyn, 4'h0, m});
  endtask

  // Settle, then leave a visible gap so steps are separable on the waveform.
  task automatic settle();
    repeat (400) @(posedge aon_clk);
  endtask

  task automatic gap();
    repeat (120) @(posedge aon_clk);
  endtask

  // ---- Device IP helpers ----
  // The signature both logic classes take on a fill. A pure function of the
  // seed, so what SHOULD have survived can be stated without remembering
  // anything across the power cycle. Mirrors ip_pattern(seed, 7, 15) in
  // ppu_ip_core.
  function automatic logic [31:0] ip_expect(input logic [7:0] sd);
    return ({sd, 5'd0, 3'd7, 8'd0, 4'd0, 4'hF}) ^ 32'hA5A5_5A5A;
  endfunction

  // FILL writes the pattern to all sixteen words of all eight banks and
  // captures both logic signatures at the same instant, so one command
  // establishes every class of state from a single reference point.
  task automatic ip_fill(input logic [7:0] sd);
    begin
      @(negedge dclk); ip_seed = sd; ip_cmd = 2'b01;
      @(negedge dclk); ip_cmd = 2'b00;
      repeat (20) @(negedge dclk);
    end
  endtask

  // VERIFY reads every bank back and reports per-bank survival. Only ON leaves
  // the RAM accessible -- a retained bank holds its contents but cannot be
  // read, which is what sleep means on the macro -- so this always runs after
  // the return to ON.
  task automatic ip_verify(input logic [7:0] sd);
    begin
      @(negedge dclk); ip_seed = sd; ip_cmd = 2'b10;
      @(negedge dclk); ip_cmd = 2'b00;
      repeat (24) @(negedge dclk);
    end
  endtask

  // Seed everything in ON, visit a mode, come back, and report what each class
  // of state did. This is the table in ppu_device_ip's header, produced live.
  task automatic show_mode_effect(input logic [3:0] m);
    logic [7:0] sd;
    begin
      sd = 8'h40 + m;
      set_policy(PM_ON, 1'b0, 1'b0); settle();
      ip_fill(sd);
      set_policy(m, 1'b0, 1'b0);     settle();
      set_policy(PM_ON, 1'b0, 1'b0); settle();
      ip_verify(sd);
      $display("      %-9s non-retained %-4s  retained %-4s  banks %8b",
               ppu_mode_name(m),
               (sig_nret === ip_expect(sd)) ? "kept" : "LOST",
               (sig_ret  === ip_expect(sd)) ? "kept" : "LOST",
               ram_bank_ok);
      gap();
    end
  endtask

  // Go to a mode and report what the domain looks like once it arrives.
  task automatic go(input logic [3:0] m);
    begin
      set_policy(m, 1'b0, 1'b0);
      settle();
      $display("      %-9s clken=%0b iso_n=%0b pore_n=%0b warm_n=%0b ret_n=%0b  |  logic_on=%0b logic_ret=%0b ram_on=%0b ram_ret=%0b",
               ppu_mode_name(pwr_status), dev_clken, dev_isolaten, dev_poresetn,
               dev_warmresetn, dev_retresetn, logic_on, logic_ret, ram_on, ram_ret);
      gap();
    end
  endtask

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("ppu_demo_tb.vcd");
    $dumpvars(0, ppu_demo_tb);

    $display("==============================================================");
    $display(" PPU guided tour -- open ../build/ppu_demo_tb.vcd and follow");
    $display(" demo_step, which matches the step numbers printed below.");
    $display("==============================================================");

    // -----------------------------------------------------------------------
    step(1, "reset -- and the domain stays OFF");
    say("The default policy is OFF and PCSMMODESTAT reports OFF, so this is");
    say("Table 4-13 row 1: the PPU comes up in OFF and STAYS there. Nothing");
    say("moves until software asks. Watch the whole domain sit dark:");
    say("logic_on=0, ram_on=0, the clock gated, every reset asserted.");
    aon_rst_n = 1'b0;
    repeat (20) @(posedge aon_clk);
    @(negedge aon_clk) aon_rst_n = 1'b1;
    settle();
    $display("      after reset release: %0s   logic_on=%0b ram_on=%0b clken=%0b",
             ppu_mode_name(pwr_status), logic_on, ram_on, dev_clken);
    say("...and it is still there a while later, because nothing asked it");
    say("to move. Section 4.2.1: 'the PPU remains in OFF until another");
    say("policy is programmed'.");
    settle();
    $display("      still: %0s", ppu_mode_name(pwr_status));
    gap();

    // -----------------------------------------------------------------------
    step(2, "what this PPU says it can do");
    say("Before driving it, ask it. Software discovers a PPU's shape from");
    say("its identification registers, because a reduced build has a");
    say("DIFFERENT register map -- not the same map with features disabled.");
    reg_read(A_IDR0);
    $display("      PPU_IDR0 = 0x%08h   supported modes, static and dynamic", reg_rdata);
    reg_read(A_IDR1);
    $display("      PPU_IDR1 = 0x%08h   optional features: lock, delays, RAM regs", reg_rdata);
    reg_read(A_IIDR);
    $display("      PPU_IIDR = 0x%08h   implementer and product", reg_rdata);
    reg_read(A_AIDR);
    $display("      PPU_AIDR = 0x%08h   architecture version", reg_rdata);
    say("This build advertises everything, so every step below is reachable.");
    gap();

    // -----------------------------------------------------------------------
    step(3, "software powers the domain up");
    say("Now write ON. This is the first thing that moves, so the power-up");
    say("sequence is isolated and easy to read. Watch the ORDER: the PCSM");
    say("handshake completes first, then isolation releases, then the clock,");
    say("then the resets -- and PPUHWSTAT updates last of all, only once the");
    say("device has acknowledged on the Q-Channel.");
    go(PM_ON);

    // -----------------------------------------------------------------------
    step(4, "the mode ladder, highest power to lowest");
    say("Each mode changes a different combination of the nine controls.");
    say("FUNC_RET and MEM_OFF look identical at the device pins -- the whole");
    say("difference is on the PCSM, in ram_on / ram_ret.");
    go(PM_ON);
    go(PM_FUNC_RET);
    go(PM_MEM_OFF);
    go(PM_FULL_RET);
    go(PM_MEM_RET);
    go(PM_OFF);

    // -----------------------------------------------------------------------
    step(5, "the device, and the three kinds of state a mode can act on");
    say("The controls above only matter because something below them keeps");
    say("state. ppu_device_ip holds three kinds, and each survives a");
    say("different set of modes:");
    say("");
    say("  non-retained logic  reset by DEVPORESETn & DEVWARMRESETn");
    say("  retained logic      reset by DEVPORESETn & DEVRETRESETn, and");
    say("                      backed by a UPF retention cell on VDD_RET");
    say("  eight RAM banks     held or lost by their own sleep/shutdown pins");
    say("");
    say("Seed all three, then read them back. In ON nothing has happened to");
    say("them yet, so everything is intact -- this is the reference point.");
    set_policy(PM_ON, 1'b0, 1'b0); settle();
    reg_write(A_FUNRR, 32'h0000_00FF);
    reg_write(A_FULRR, 32'h0000_00FF);
    reg_write(A_MEMRR, 32'h0000_00FF);
    ip_fill(8'h5A);
    ip_verify(8'h5A);
    $display("      seeded: non-retained %08h  retained %08h  banks %8b",
             sig_nret, sig_ret, ram_bank_ok);
    gap();

    // -----------------------------------------------------------------------
    step(6, "what each mode does to that state");
    say("Every mode, one row each: seed in ON, visit the mode, come back,");
    say("read it all back. With every RAM bank configured to retain, no two");
    say("rows are alike -- and that is the point. Before this device existed");
    say("six of the seven modes were indistinguishable below the PCSM.");
    say("");
    say("Watch FULL_RET in particular: it is the ONLY mode that resets the");
    say("non-retained logic while keeping the retained logic. Table 4-9");
    say("gives it a row found nowhere else -- DEVWARMRESETn asserts while");
    say("DEVPORESETn and DEVRETRESETn stay HIGH.");
    show_mode_effect(PM_WARM_RST);
    show_mode_effect(PM_FUNC_RET);
    show_mode_effect(PM_MEM_OFF);
    show_mode_effect(PM_FULL_RET);
    show_mode_effect(PM_MEM_RET);
    show_mode_effect(PM_OFF);

    // -----------------------------------------------------------------------
    step(7, "per-bank RAM retention, from PPU_FUNRR / FULRR / MEMRR");
    say("PCSMPSTATE[15:8] is IMPLEMENTATION DEFINED. Here it is one retention");
    say("enable per bank, so those three registers choose WHICH memory");
    say("survives a RAM-retaining mode. A bank whose bit is clear is shut");
    say("down even in MEM_RET, and loses its contents.");
    say("");
    say("Write 0x0F -- retain the low four banks only -- and go through");
    say("MEM_RET.");
    reg_write(A_MEMRR, 32'h0000_000F);
    set_policy(PM_ON, 1'b0, 1'b0); settle();
    ip_fill(8'hC3);
    set_policy(PM_MEM_RET, 1'b0, 1'b0); settle();
    $display("      in MEM_RET: sleep=%8b shutdown=%8b  (ram_cfg=%02h)",
             bank_sleep, bank_sd, ram_cfg);
    set_policy(PM_ON, 1'b0, 1'b0); settle();
    ip_verify(8'hC3);
    $display("      banks surviving = %8b   <- low four kept, high four lost", ram_bank_ok);
    gap();

    say("Now the opposite half, 0xF0, to show the register really is what");
    say("selects them rather than something else being uneven.");
    reg_write(A_MEMRR, 32'h0000_00F0);
    ip_fill(8'h3C);
    set_policy(PM_MEM_RET, 1'b0, 1'b0); settle();
    $display("      in MEM_RET: sleep=%8b shutdown=%8b  (ram_cfg=%02h)",
             bank_sleep, bank_sd, ram_cfg);
    set_policy(PM_ON, 1'b0, 1'b0); settle();
    ip_verify(8'h3C);
    $display("      banks surviving = %8b   <- exactly reversed", ram_bank_ok);
    reg_write(A_MEMRR, 32'h0000_00FF);
    gap();

    // -----------------------------------------------------------------------
    step(8, "OFF -> MEM_RET, the one transition with no device handshake");
    say("The logic is off in both modes, so there is nothing to ask the");
    say("device. dev_qreqn does not move at all -- only the PCSM exchange");
    say("happens. This is the single exception to ON-anchored routing.");
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    settle();
    $display("      now %0s, and the device never noticed", ppu_mode_name(pwr_status));
    gap();

    // -----------------------------------------------------------------------
    step(9, "back up to ON -- the exit handshake");
    say("Going up is the mirror image: PCSM restores the supply, then");
    say("isolation releases, clock, resets, and only then the Q-Channel");
    say("exit handshake completes and PPUHWSTAT updates.");
    go(PM_ON);

    // -----------------------------------------------------------------------
    step(10, "WARM_RST -- a reset that keeps the power on");
    say("logic_on and ram_on stay HIGH. Only dev_warmresetn and dev_retresetn");
    say("assert. The PCSM is told ON throughout (Table 3-2 note a), so watch");
    say("pcsm_pstate stay at 8 while the device is held in reset.");
    go(PM_WARM_RST);
    go(PM_ON);

    // -----------------------------------------------------------------------
    step(11, "entry delay -- the PPU waits before acting");
    say("Program OFF_DEL = 0x40, then ask for OFF. The conditions are met");
    say("immediately but dev_qreqn stays HIGH for the delay first. Watch the");
    say("gap between the register write and the handshake starting.");
    reg_write(A_EDTR0, 32'h0000_0040);
    set_policy(PM_OFF, 1'b0, 1'b0);
    settle();
    say("arrived in OFF; clearing the delay again");
    reg_write(A_EDTR0, 32'h0000_0000);
    go(PM_ON);

    // -----------------------------------------------------------------------
    step(12, "device control delays -- the spacing between the controls");
    say("Section 4.1.5 does not just fix the ORDER of the device controls,");
    say("it lets you space them. PPU_DCDR0/1 hold five gaps, counted in PPU");
    say("clocks, and they exist because the device needs settling time");
    say("between one control moving and the next.");
    say("");
    say("Program them wide -- 0x20 each -- and take a round trip. The order");
    say("is unchanged; the gaps between dev_clken, dev_isolaten and the resets");
    say("stretch out, which is the easiest place on the whole waveform to");
    say("see that the sequence is deliberate rather than combinational.");
    reg_write(A_DCDR0, 32'h0020_2020);
    reg_write(A_DCDR1, 32'h0000_2020);
    go(PM_OFF);
    go(PM_ON);
    say("...and back to the defaults.");
    reg_write(A_DCDR0, 32'h0002_0202);
    reg_write(A_DCDR1, 32'h0000_0202);
    gap();

    // -----------------------------------------------------------------------
    step(13, "a busy device DENIES a transition");
    say("Start a long workload and ask for OFF. The device refuses:");
    say("dev_qdeny goes HIGH, no device control moves, and the PPU puts the");
    say("policy back to where it was. Nothing about the domain changes.");
    deny_enb   = 1'b1;
    light_work = 1'b0;
    work_len   = 8'd80;
    start      = 1'b1;
    repeat (60) @(posedge aon_clk);
    set_policy(PM_OFF, 1'b0, 1'b0);
    repeat (300) @(posedge aon_clk);
    $display("      after the denial the PPU is still in %0s", ppu_mode_name(pwr_status));
    start = 1'b0;
    repeat (400) @(posedge aon_clk);
    deny_enb = 1'b0; light_work = 1'b1;
    gap();

    // -----------------------------------------------------------------------
    step(14, "dynamic transitions -- the hardware drives the mode");
    say("With PWR_DYN_EN set, the policy becomes a FLOOR. The PPU drops to");
    say("it when wake is LOW and climbs back to ON when wake goes HIGH,");
    say("with no software involved. Watch wake and pwr_status together.");
    set_policy(PM_OFF, 1'b1, 1'b0);
    settle();
    say("wake LOW  -> settled at the floor, OFF");
    @(negedge dclk) wake = 1'b1;
    settle();
    say("wake HIGH -> climbed back to ON by itself");
    @(negedge dclk) wake = 1'b0;
    settle();
    say("wake LOW  -> back down to OFF again");
    gap();

    // -----------------------------------------------------------------------
    step(15, "lock -- software keeps the domain down");
    say("Lock only engages in OFF or MEM_RET, and only with dynamic mode on.");
    say("Once locked, wake is ignored: the PPU stays put. Watch wake toggle");
    say("with pwr_status flat -- that is the point of the feature.");
    set_policy(PM_OFF, 1'b1, 1'b1);
    settle();
    @(negedge dclk) wake = 1'b1;
    settle();
    $display("      wake is HIGH and the PPU is still in %0s", ppu_mode_name(pwr_status));
    say("now write PPU_UNLK -- it releases immediately and climbs");
    reg_write(A_UNLK, 32'h0000_0001);
    settle();
    $display("      after unlock: %0s", ppu_mode_name(pwr_status));
    @(negedge dclk) wake = 1'b0;
    set_policy(PM_ON, 1'b0, 1'b0);
    settle();
    gap();

    // -----------------------------------------------------------------------
    step(16, "interrupts");
    say("Every step so far has been raising interrupts and nobody cleared");
    say("them, so irq is already HIGH. Clear both status registers first --");
    say("otherwise this step would 'demonstrate' an irq that was already on.");
    reg_write(A_ISR,  32'hFFFF_FFFF);
    reg_write(A_AISR, 32'hFFFF_FFFF);
    repeat (40) @(posedge aon_clk);
    $display("      starting point: irq = %0b", irq);

    say("Now ask for an unsupported policy -- dynamic WARM_RST, which");
    say("section 3.4.3 forbids on a Q-Channel PPU. The write is ignored,");
    say("the mode does not move, and PPU_AISR[0] raises irq.");
    set_policy(PM_WARM_RST, 1'b1, 1'b0);
    repeat (40) @(posedge aon_clk);
    $display("      irq = %0b, and the mode is unchanged at %0s", irq, ppu_mode_name(pwr_status));

    say("Clear PPU_AISR[0] and it drops again. Note PPU_ISR.OTHER follows");
    say("on its own -- it is derived from PPU_AISR, not stored.");
    reg_write(A_AISR, 32'h0000_0001);
    repeat (40) @(posedge aon_clk);
    $display("      after clearing PPU_AISR: irq = %0b", irq);
    gap();

    // -----------------------------------------------------------------------
    step(17, "back to ON, and done");
    go(PM_ON);

    $display("");
    $display("==============================================================");
    $display(" tour complete -- %0d steps, waveform in ppu_demo_tb.vcd", demo_step);
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (400000) @(posedge aon_clk);
    $fatal(1, "ppu_demo_tb watchdog");
  end

endmodule
