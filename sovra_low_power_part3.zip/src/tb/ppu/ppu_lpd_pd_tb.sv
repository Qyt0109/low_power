`timescale 1ns/1ps
// ppu_lpd_pd_top -- a PPU driving THREE devices through an LPD-Q, in both modes.
//
// References:
//   Arm CoreLink PCK-600 TRM (101150 r0p5) Section 3.1.1 (expander) and 3.1.2
//     (sequencer)
//   Arm PPU Architecture Specification v1.1 (ARM DEN 0051E) Sections 4.1.3,
//     4.1.5, Table 4-9, Table 4-11
//   Arm PCSA (DEN 0050 D) Section 6.5.3
//
// WHAT THIS ADDS OVER qchannel_lpd_tb
//
// qchannel_lpd_tb drives the LPD-Q's control channel by hand and watches the
// device channels. It proves the block obeys Section 3.1. It cannot prove the
// thing SOVRA_PCSA_ARCHITECTURE.md Section 5.2 actually claims, which is that a
// REAL PPU, at its ordinary single-channel configuration, can take a
// multi-device domain all the way down and back -- and that the domain really
// loses power when it does.
//
// So the checks here are about the JOIN:
//
//   the PPU reaches OFF only after all three devices are quiescent
//   one device refusing is enough to stop the whole domain
//   the sequencer really does ask them in order, with a live PPU driving
//   under UPF, all three devices corrupt when the rail goes and the retained
//     ones survive FULL_RET
//
// Both DUTs run every group. u_exp is the expander, u_seq the sequencer, and
// several checks are deliberately run against both because the difference
// between the modes must not change the OUTCOME, only the path to it.

import ppu_pkg::*;

module ppu_lpd_pd_tb;

  localparam int unsigned NDEV  = 3;
  localparam int unsigned CNT_W = 8;

  // PGOOD_EN follows the build, because the acknowledge nets have NO RTL DRIVER
  // when it is set -- the UPF power switches drive them. In a plain run there
  // is no UPF, so enabling it would leave pg_logic at X and the PCSM would wait
  // forever.
`ifdef PPU_PA
  localparam bit PG = 1'b1;
`else
  localparam bit PG = 1'b0;
`endif

  logic aon_clk = 1'b0, dclk = 1'b0;
  logic aon_rst_n = 1'b0;
  always #5  aon_clk = ~aon_clk;
  always #7  dclk    = ~dclk;      // deliberately not a clean ratio

  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  task automatic settle(); repeat (250) @(posedge aon_clk); endtask

  // ===========================================================================
  // Two DUTs
  // ===========================================================================
  logic [11:0] e_waddr, e_raddr, s_waddr, s_raddr;
  logic [31:0] e_wdata, e_rdata, s_wdata, s_rdata;
  logic        e_wen, e_ren, s_wen, s_ren;
  logic [3:0]  e_wstrb, s_wstrb;
  logic        e_irq, s_irq;

  logic [NDEV-1:0] e_start = '0, e_light = '0, e_wake = '0, e_deny = '0;
  logic [NDEV-1:0] s_start = '0, s_light = '0, s_wake = '0, s_deny = '0;
  logic [CNT_W-1:0] e_worklen = 8'd20, s_worklen = 8'd20;
  logic [1:0]  e_cmd = 2'd0, s_cmd = 2'd0;
  logic [7:0]  e_seed = 8'h00, s_seed = 8'h00;

  logic [NDEV-1:0] e_qreqn, e_qacceptn, e_qdeny, e_qactive;
  logic [NDEV-1:0] s_qreqn, s_qacceptn, s_qdeny, s_qactive;
  logic            e_clkqa, s_clkqa;

  ppu_lpd_pd_top #(.NUM_DEV(NDEV), .SEQUENCER(1'b0), .CNT_W(CNT_W), .PGOOD_EN(PG))
    u_exp (
      .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
      .reg_waddr(e_waddr), .reg_wdata(e_wdata), .reg_wen(e_wen),
      .reg_wstrb(e_wstrb), .reg_raddr(e_raddr), .reg_ren(e_ren),
      .reg_rdata(e_rdata), .irq(e_irq),
      .dclk(dclk),
      .start(e_start), .work_len(e_worklen), .light_work(e_light),
      .wake(e_wake), .deny_enb(e_deny), .ip_cmd(e_cmd), .ip_seed(e_seed),
      .dev_qreqn_o(e_qreqn), .dev_qacceptn_o(e_qacceptn),
      .dev_qdeny_o(e_qdeny), .dev_qactive_o(e_qactive),
      .lpd_clk_qactive(e_clkqa));

  ppu_lpd_pd_top #(.NUM_DEV(NDEV), .SEQUENCER(1'b1), .CNT_W(CNT_W), .PGOOD_EN(PG))
    u_seq (
      .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
      .reg_waddr(s_waddr), .reg_wdata(s_wdata), .reg_wen(s_wen),
      .reg_wstrb(s_wstrb), .reg_raddr(s_raddr), .reg_ren(s_ren),
      .reg_rdata(s_rdata), .irq(s_irq),
      .dclk(dclk),
      .start(s_start), .work_len(s_worklen), .light_work(s_light),
      .wake(s_wake), .deny_enb(s_deny), .ip_cmd(s_cmd), .ip_seed(s_seed),
      .dev_qreqn_o(s_qreqn), .dev_qacceptn_o(s_qacceptn),
      .dev_qdeny_o(s_qdeny), .dev_qactive_o(s_qactive),
      .lpd_clk_qactive(s_clkqa));

  // ===========================================================================
  // Protocol monitors on all six device channels
  // ===========================================================================
  int unsigned e_viol [NDEV];
  int unsigned s_viol [NDEV];
  generate
    for (genvar i = 0; i < NDEV; i++) begin : g_mon
      qchannel_monitor u_me (
        .clk(dclk), .rst_n(aon_rst_n), .crst_n(aon_rst_n), .drst_n(aon_rst_n),
        .clk_gated(1'b0), .qreqn(e_qreqn[i]), .qacceptn(e_qacceptn[i]),
        .qdeny(e_qdeny[i]), .violations(e_viol[i]));
      qchannel_monitor u_ms (
        .clk(dclk), .rst_n(aon_rst_n), .crst_n(aon_rst_n), .drst_n(aon_rst_n),
        .clk_gated(1'b0), .qreqn(s_qreqn[i]), .qacceptn(s_qacceptn[i]),
        .qdeny(s_qdeny[i]), .violations(s_viol[i]));
    end
  endgenerate

  // ===========================================================================
  // THE SEQUENCER ORDERING INVARIANT, with a live PPU driving
  //
  // Section 3.1.2. Edge-triggered for the reason qchannel_lpd_tb records: a
  // level version reads a legitimate exit walk as an entry-order failure.
  // ===========================================================================
`ifdef PPU_PA
  // ===========================================================================
  // THE POWER-GOOD INVARIANT
  //
  // The hazard ack_logic_on exists to remove: the PPU releases DEVRSTn on the
  // strength of PCSMPACCEPT, so if the PCSM accepts before its rail has settled
  // the domain comes out of reset unpowered. That is corruption which looks
  // like a functional bug.
  //
  // Watched every cycle rather than sampled, because it is a race: the window
  // is the settling time and a check that looks at settled state cannot see it.
  // ===========================================================================
  // The retention half of the same idea, and the reason ack_logic_ret exists.
  // ppu_power_model PU9 asks whether the retention SUPPLY arrived after the
  // save; with a modelled switch the sharper question is whether the save
  // landed on a rail that had actually settled. Without this check, removing
  // the RET_ARM wait entirely is invisible here -- measured, it survived the
  // mutation until this invariant was added.
  int unsigned save_viol = 0;
  always @(negedge u_exp.ret_n)
    if (aon_rst_n && u_exp.logic_ret && !u_exp.pg_ret) begin
      save_viol++;
      $display("[%0t] SAVE-VIOLATION exp: ret_n fell with pg_ret still LOW", $time);
    end
  always @(negedge u_seq.ret_n)
    if (aon_rst_n && u_seq.logic_ret && !u_seq.pg_ret) begin
      save_viol++;
      $display("[%0t] SAVE-VIOLATION seq: ret_n fell with pg_ret still LOW", $time);
    end

  int unsigned pg_viol = 0;
  always @(posedge aon_clk) begin
    if (aon_rst_n) begin
      if (u_exp.dev_poresetn && u_exp.dev_warmresetn && !u_exp.pg_logic) begin
        pg_viol++;
        $display("[%0t] PGOOD-VIOLATION exp: reset released with pg_logic LOW", $time);
      end
      if (u_seq.dev_poresetn && u_seq.dev_warmresetn && !u_seq.pg_logic) begin
        pg_viol++;
        $display("[%0t] PGOOD-VIOLATION seq: reset released with pg_logic LOW", $time);
      end
    end
  end
`endif

  int unsigned order_viol = 0;
  logic [NDEV-1:0] s_qreqn_d;
  always @(posedge dclk) s_qreqn_d <= s_qreqn;

  always @(posedge dclk) begin
    if (aon_rst_n) begin
      for (int k = 0; k < NDEV-1; k++) begin
        if (s_qreqn_d[k+1] == 1'b1 && s_qreqn[k+1] == 1'b0 &&
            s_qacceptn[k] == 1'b1 && s_qdeny[k] == 1'b0) begin
          order_viol++;
          $display("[%0t] ORDER-VIOLATION: dev%0d asked before dev%0d responded",
                   $time, k+1, k);
        end
      end
    end
  end

  // ===========================================================================
  // Register access
  // ===========================================================================
  task automatic wr_e(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk);
      e_waddr = a; e_wdata = d; e_wstrb = 4'hF; e_wen = 1'b1;
      @(negedge aon_clk); e_wen = 1'b0;
    end
  endtask
  task automatic wr_s(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk);
      s_waddr = a; s_wdata = d; s_wstrb = 4'hF; s_wen = 1'b1;
      @(negedge aon_clk); s_wen = 1'b0;
    end
  endtask
  task automatic rd_e(input logic [11:0] a, output logic [31:0] d);
    begin
      @(negedge aon_clk); e_raddr = a; e_ren = 1'b1;
      @(negedge aon_clk); d = e_rdata; e_ren = 1'b0;
    end
  endtask
  task automatic rd_s(input logic [11:0] a, output logic [31:0] d);
    begin
      @(negedge aon_clk); s_raddr = a; s_ren = 1'b1;
      @(negedge aon_clk); d = s_rdata; s_ren = 1'b0;
    end
  endtask

  function automatic logic [3:0] mode_e(); return u_exp.pcsm_mode; endfunction
  function automatic logic [3:0] mode_s(); return u_seq.pcsm_mode; endfunction

  logic [31:0] rv;

  initial begin
    $dumpfile("ppu_lpd_pd_tb.vcd");
    $dumpvars(0, ppu_lpd_pd_tb);
    $display("==============================================================");
    $display(" ppu_lpd_pd_tb -- one PPU, one LPD-Q, %0d devices, both modes", NDEV);
    $display("==============================================================");

    e_waddr='0; e_wdata='0; e_wen=0; e_wstrb='0; e_raddr='0; e_ren=0;
    s_waddr='0; s_wdata='0; s_wen=0; s_wstrb='0; s_raddr='0; s_ren=0;

    repeat (10) @(posedge aon_clk);
    aon_rst_n = 1'b1;
    settle();

    // ---- D1: both come up ON with every device running ----
    section("D1 reset");
    ck(mode_e() == PM_ON, "D1 expander PPU is ON");
    ck(mode_s() == PM_ON, "D1 sequencer PPU is ON");
    ck(e_qreqn == '1, "D1 expander: no device requested");
    ck(s_qreqn == '1, "D1 sequencer: no device requested");

    // ---- D2: the join -- all three must quiesce before the domain goes ----
    // DEN 0051E Section 4.1.3: the PPU removes power only once its device
    // interface reports quiescence. With an LPD-Q that report is the AND of
    // three, which is the whole claim being tested.
    section("D2 expander OFF");
    wr_e(12'h000, {28'd0, PM_OFF});   // PPU_PWPR.PWR_POLICY
    settle();
    ck(e_qacceptn == '0,      "D2 all three devices accepted");
    ck(mode_e() == PM_OFF,    "D2 PPU reached OFF");
    ck(u_exp.logic_on == 1'b0, "D2 logic supply removed");

    section("D3 sequencer OFF");
    wr_s(12'h000, {28'd0, PM_OFF});
    settle();
    ck(s_qacceptn == '0,      "D3 all three devices accepted");
    ck(mode_s() == PM_OFF,    "D3 PPU reached OFF");
    ck(u_seq.logic_on == 1'b0, "D3 logic supply removed");
    ck(order_viol == 0,       "D3 sequencer asked them IN ORDER with a live PPU");

    // ---- D4: back ON ----
    section("D4 back ON");
    wr_e(12'h000, {28'd0, PM_ON});         // PWR_POLICY = ON
    wr_s(12'h000, {28'd0, PM_ON});
    settle();
    ck(mode_e() == PM_ON && mode_s() == PM_ON, "D4 both back ON");
    ck(e_qreqn == '1 && s_qreqn == '1,         "D4 every device released");
    ck(e_qacceptn == '1 && s_qacceptn == '1,   "D4 every device back in Q_RUN");

    // ---- D5: ONE device refusing stops the WHOLE domain ----
    // The property that makes an LPD-Q a join rather than a fan-out. Device 1
    // denies; the PPU must not remove power from any of the three.
    section("D5 one denial holds the domain up");
    // Three things the first version of this group got wrong, each of which
    // made it pass its own opposite:
    //
    //   deny_enb only bites while the device is BUSY. work_len 20 expired
    //   before the Q-Channel request arrived, so the domain went down with no
    //   denial ever having happened.
    //
    //   The start pulse was ASSUMED to land. ppu_device_ip runs on the GATED
    //   clock, so the pattern the other testbenches use is to drive on negedge
    //   dclk and then WAIT for busy rather than counting cycles.
    //
    //   PWR_DEVACTIVEEN was left set. A busy device then raises DEVQACTIVE and
    //   the PPU reads a wake request, so the domain would be held up by the
    //   wake rather than by the denial -- the right outcome for the wrong
    //   reason, and D5 would not be testing what it claims.
    wr_e(12'h020, 32'h0000_0001);        // PPU_PWCR: PWR_DEVACTIVEEN = 0
    wr_s(12'h020, 32'h0000_0001);
    e_worklen = 8'hFF; s_worklen = 8'hFF;
    e_deny[1] = 1'b1; s_deny[1] = 1'b1;
    @(negedge dclk); e_start[1] = 1'b1; s_start[1] = 1'b1;
    @(negedge dclk); e_start[1] = 1'b0; s_start[1] = 1'b0;
    while (!u_exp.busy[1] || !u_seq.busy[1]) @(negedge dclk);
    ck(u_exp.busy[1] && u_seq.busy[1], "D5 device 1 is busy on both DUTs");

    wr_e(12'h000, {28'd0, PM_OFF});
    wr_s(12'h000, {28'd0, PM_OFF});
    repeat (60) @(posedge aon_clk);
    ck(mode_e() != PM_OFF,     "D5 expander did NOT reach OFF");
    ck(mode_s() != PM_OFF,     "D5 sequencer did NOT reach OFF");
    ck(u_exp.logic_on == 1'b1, "D5 expander logic supply still present");
    ck(u_seq.logic_on == 1'b1, "D5 sequencer logic supply still present");
    ck(s_qreqn[2] == 1'b1,     "D5 sequencer never asked dev2 past the denier");

    // Release, and the domain must now be able to go down.
    //
    // The policy has to be written AGAIN. DEN 0051E Table 4-1, "Policy and
    // dynamic enable reversion on device interface denial": a denial reverts
    // PPU_PWPR.PWR_POLICY, so the OFF request issued above no longer exists by
    // the time the denial clears. Re-asserting it is what a real power
    // controller would do too.
    e_deny = '0; s_deny = '0;
    e_worklen = 8'd20; s_worklen = 8'd20;
    settle();                                   // let the burst drain
    wr_e(12'h000, {28'd0, PM_OFF});
    wr_s(12'h000, {28'd0, PM_OFF});
    settle(); settle();
    ck(mode_e() == PM_OFF, "D5 expander reached OFF once the denial cleared");
    ck(mode_s() == PM_OFF, "D5 sequencer reached OFF once the denial cleared");

    wr_e(12'h000, {28'd0, PM_ON});
    wr_s(12'h000, {28'd0, PM_ON});
    settle();

`ifdef PPU_PA
    // ---- D10: the domain really loses power, on ALL THREE devices ----
    //
    // The check the non-UPF run structurally cannot make. Passing under UPF
    // proves nothing on its own -- a power intent that fails to bind is a
    // SILENT no-op, and the run stays green. So this asserts the observable
    // consequence: with -simstate CORRUPT, every register in an unpowered
    // domain reads X.
    //
    // All three devices, because the failure this file exists to catch is one
    // device being left out of PD_DEV's element list. UPF has no loop, so that
    // list is written by hand, and a missing entry would leave that device
    // quietly powered while its neighbours corrupt.
    section("D10 corruption under UPF");
    wr_e(12'h000, {28'd0, PM_OFF});
    wr_s(12'h000, {28'd0, PM_OFF});
    settle();
    ck(mode_e() == PM_OFF, "D10 expander is OFF");
    // Unrolled: a hierarchical reference into a generate block needs a CONSTANT
    // index, so a loop variable will not do it (*E,NOTPAR).
    ck($isunknown(u_exp.g_dev[0].u_ip.u_core.wcnt), "D10 expander dev0 CORRUPTED");
    ck($isunknown(u_exp.g_dev[1].u_ip.u_core.wcnt), "D10 expander dev1 CORRUPTED");
    ck($isunknown(u_exp.g_dev[2].u_ip.u_core.wcnt), "D10 expander dev2 CORRUPTED");
    ck($isunknown(u_seq.g_dev[0].u_ip.u_core.wcnt), "D10 sequencer dev0 CORRUPTED");
    ck($isunknown(u_seq.g_dev[1].u_ip.u_core.wcnt), "D10 sequencer dev1 CORRUPTED");
    ck($isunknown(u_seq.g_dev[2].u_ip.u_core.wcnt), "D10 sequencer dev2 CORRUPTED");
    wr_e(12'h000, {28'd0, PM_ON});
    wr_s(12'h000, {28'd0, PM_ON});
    settle();
    ck(!$isunknown(u_exp.g_dev[0].u_ip.u_core.wcnt), "D10 dev0 recovered");
    ck(!$isunknown(u_exp.g_dev[1].u_ip.u_core.wcnt), "D10 dev1 recovered");
    ck(!$isunknown(u_exp.g_dev[2].u_ip.u_core.wcnt), "D10 dev2 recovered");
`endif

    // ---- D6: a wake from ANY device brings the domain back ----
    // ctrl_qactive_o is the OR of the three (Section 3.1), so DEVQACTIVE at the
    // PPU rises when any single device asks.
    section("D6 wake from one device");
    ck(e_qactive == '0, "D6 quiet to begin with");
    e_wake[2] = 1'b1; s_wake[2] = 1'b1;
    repeat (20) @(posedge dclk);
    ck(u_exp.dev_qactive == 1'b1, "D6 expander: one device's wake reached DEVQACTIVE");
    ck(u_seq.dev_qactive == 1'b1, "D6 sequencer: same");
    e_wake = '0; s_wake = '0;
    settle();

    // ---- D7: FULL_RET, the mode that needs retention to actually work ----
    section("D7 FULL_RET");
    e_cmd = 2'd1; s_cmd = 2'd1; e_seed = 8'hA5; s_seed = 8'hA5;   // fill
    @(posedge dclk); e_cmd = 2'd0; s_cmd = 2'd0;
    settle();
    wr_e(12'h000, {28'd0, PM_FULL_RET});
    wr_s(12'h000, {28'd0, PM_FULL_RET});
    settle();
    ck(mode_e() == PM_FULL_RET, "D7 expander in FULL_RET");
    ck(mode_s() == PM_FULL_RET, "D7 sequencer in FULL_RET");
    ck(u_exp.logic_on == 1'b0 && u_exp.logic_ret == 1'b1,
       "D7 expander on the retention rail, not the full one");
    ck(u_seq.logic_on == 1'b0 && u_seq.logic_ret == 1'b1,
       "D7 sequencer on the retention rail");
    wr_e(12'h000, {28'd0, PM_ON});
    wr_s(12'h000, {28'd0, PM_ON});
    settle();
    ck(mode_e() == PM_ON && mode_s() == PM_ON, "D7 both back ON from FULL_RET");

    // ---- D8: the modes differ in PATH, not in OUTCOME ----
    section("D8 expander and sequencer agree");
    rd_e(12'h008, rv);
    begin
      static logic [31:0] rv2;
      rd_s(12'h008, rv2);
      ck(rv[3:0] == rv2[3:0],
         $sformatf("D8 PPU_PWSR power state matches: exp=%01h seq=%01h",
                   rv[3:0], rv2[3:0]));
    end

    // ---- D9: protocol ----
    section("D9 protocol");
    begin
      int unsigned tot = 0;
      for (int i = 0; i < NDEV; i++) tot += e_viol[i] + s_viol[i];
      ck(tot == 0, $sformatf("D9 qchannel_monitor: %0d violation(s) on six channels", tot));
    end
    ck(order_viol == 0, $sformatf("D9 sequencer ordering: %0d violation(s)", order_viol));
`ifdef PPU_PA
    ck(pg_viol == 0,
       $sformatf("D9 reset NEVER released with the rail down: %0d violation(s)", pg_viol));
    ck(save_viol == 0,
       $sformatf("D9 save NEVER taken on an unsettled retention rail: %0d violation(s)",
                 save_viol));
`endif

    $display("");
    $display("==============================================================");
    $display(" ppu_lpd_pd_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (2000000) @(posedge aon_clk);
    $display(" RESULT: FAIL -- timeout");
    $finish;
  end

endmodule
