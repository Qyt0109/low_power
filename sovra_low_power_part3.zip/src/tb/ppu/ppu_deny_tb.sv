`timescale 1ns/1ps
// ppu_seq denial-path unit testbench.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Sections 4.1.1 and 4.2.9, Table 4-1, Figure 4-35;
// AMBA Low Power Interface Specification (ARM IHI 0068C) Table 2-1.
//
// WHY A UNIT TESTBENCH RATHER THAN ANOTHER SYSTEM PHASE
//
// ppu_pd_tb already denies transitions -- P5 and P20 -- but a denial there
// depends on a workload happening to be busy at the right moment, which makes
// the denial hard to place and impossible to hold. Driving ppu_seq directly
// puts the denial exactly where the test wants it, and lets the recovery be
// stretched so that what the sequencer does DURING it can be observed.
//
// WHAT THIS TESTBENCH WILL NOT DO
//
// It will not present the device interface with anything the Q-Channel
// specification does not define.
//
// ppu_seq consumes the DECODED channel -- dev_q_run, dev_stopped, dev_qdeny --
// so it would be trivial to raise dev_qdeny at any moment a test found
// convenient, and tempting, because that is how you would "prove" the
// sequencer ignores a denial outside S_DN_QREQ. It is not a legitimate test.
// AMBA LPI (ARM IHI 0068C) Table 2-1 reaches Q_DENIED only from Q_REQUEST, and
// qchannel_monitor already enforces what follows:
//
//   R6  QDENY 0->1 only when QREQn LOW and QACCEPTn HIGH   (i.e. Q_REQUEST)
//   R5  QDENY 1->0 only when QREQn HIGH and QACCEPTn HIGH  (request withdrawn)
//
// A denial raised outside that window is a protocol violation by the DEVICE.
// No specification defines what a PPU does in response to one, so an assertion
// about it would pin down this implementation's accidental behaviour rather
// than check a required one -- and would fail a different, equally conformant
// PPU. Protocol legality belongs to qchannel_monitor and the Q-Channel
// testbench; conformant-stimulus behaviour belongs here.
//
// So dev_qdeny is owned entirely by the channel model below. A test ARMS a
// denial and the model decides whether the protocol permits one, which also
// means a denial is held until the request is withdrawn rather than pulsed for
// a cycle -- R5 forbids the pulse.
//
// WHAT THE IMPLEMENTATION CLAIMS, AND WHERE EACH CLAIM COMES FROM
//
// The ppu_seq header makes four claims about denial:
//
//  1. Denial is only observable in S_DN_QREQ.               design ordering
//  2. No device control has moved when a denial lands.      design ordering
//  3. The policy reverts per Table 4-1.                     PPU spec 4.1.1
//  4. An up-transition cannot be denied at all.             AMBA LPI Table 2-1
//
// Claims 1 and 4 are consequences of the protocol, not properties this file can
// test by violating it. What it can do -- and D6 does -- is arm a denial across
// a path the protocol gives no denial state and observe that none appears.
//
// Claim 4 is also a PPU-spec statement, Section 4.2.9: "Q-Channel PPU
// transitions to higher priority power modes, except for those to warm reset,
// cannot be denied." The same section shows the opposite for the other channel
// type in Figure 4-36, a P-Channel PPU denied on FULL_RET -> ON.
//
// The consequence of 1, 2 and 4 together is that Section 4.2.9's "if the
// handshake is denied these actions must be reversed" has nothing to reverse in
// this design. D2 is what turns that from an assertion in a comment into a
// measurement.

module ppu_deny_tb;

  import ppu_pkg::*;

  logic clk = 1'b0;
  always #1 clk = ~clk;
  logic rst_n = 1'b0;

  // ---- Sequencer inputs, all driven directly ----
  logic [3:0] reset_mode = PM_OFF;
  logic [3:0] pwr_policy = PM_OFF;
  logic       pwr_dyn_en = 1'b0;
  logic       lock_en    = 1'b0;
  logic       unlock_wr  = 1'b0;
  logic       policy_wr  = 1'b0;
  logic       devreqen          = 1'b1;
  logic       devactiveen       = 1'b1;
  logic       warm_rst_devreqen = 1'b1;
  logic [7:0] rst_hwstat_dly = 8'd2, iso_clken_dly = 8'd2, clken_rst_dly = 8'd2;
  logic [7:0] clken_iso_dly  = 8'd2, iso_rst_dly   = 8'd2;
  logic [7:0] off_del = 8'd0, mem_ret_del = 8'd0, full_ret_del = 8'd0;
  logic [7:0] func_ret_del = 8'd0, mem_off_del = 8'd0;
  logic [7:0] funrr = 8'h71, fulrr = 8'hB2, memrr = 8'hE3;

  // dev_stopped, dev_q_run and dev_qdeny are driven ONLY by the channel model
  // below. No test writes them; see the note there.
  logic dev_stopped, dev_q_run, dev_qdeny;
  logic dev_qactive = 1'b0;

  // ---- Sequencer outputs ----
  logic [3:0] pwr_status;
  logic       pwr_dyn_status, lock_status;
  logic       revert_vld, revert_dyn_en;
  logic [3:0] revert_policy;
  logic       ev_sta_policy_trn, ev_sta_accept, ev_sta_deny;
  logic       ev_dyn_accept, ev_dyn_deny, ev_locked;
  logic       req_dev_quiescence;
  logic [15:0] pcsm_req_state;
  logic        pcsm_req_valid;
  logic [15:0] ppuhwstat;
  logic        dev_clken, dev_isolaten, dev_poresetn, dev_warmresetn, dev_retresetn;
  logic        ppu_active;

  // ---- Policy reversion model ----
  //
  // In the real design ppu_regs consumes revert_vld and writes the reverted
  // values back into PPU_PWPR. Without that here the sequencer would leave
  // S_DENIED, find the denied policy still on its input, and immediately
  // re-request it -- forever. The retry is not wrong; it is what a PPU whose
  // policy register was never reverted would actually do, which is precisely
  // why Section 4.1.1 requires the reversion.
  //
  // Driven on the POSEDGE while set_policy drives on the negedge, so the two
  // writers to pwr_policy never collide.
  always @(posedge clk) begin
    if (rst_n && revert_vld) begin
      pwr_policy <= revert_policy;
      pwr_dyn_en <= revert_dyn_en;
    end
  end

  // ---- PCSM model: accepts every request after a couple of cycles ----
  logic [15:0] pcsm_cur_state = {8'h00, 4'h0, PM_OFF};
  logic        pcsm_init_done = 1'b0;
  int          pcsm_dly = 0;

  always @(posedge clk) begin
    if (!rst_n) begin
      pcsm_cur_state <= {8'h00, 4'h0, PM_OFF};
      pcsm_init_done <= 1'b0;
      pcsm_dly       <= 0;
    end else begin
      pcsm_init_done <= 1'b1;
      if (pcsm_req_valid && (pcsm_cur_state !== pcsm_req_state)) begin
        if (pcsm_dly == 3) begin
          pcsm_cur_state <= pcsm_req_state;
          pcsm_dly       <= 0;
        end else pcsm_dly <= pcsm_dly + 1;
      end else pcsm_dly <= 0;
    end
  end

  // ---- Q-Channel device model, legal by construction ----
  //
  // ppu_seq consumes the DECODED channel (dev_q_run, dev_stopped, dev_qdeny)
  // rather than the three wires, so it would be easy to poke dev_qdeny whenever
  // the test found it convenient. That is exactly what must not happen here.
  //
  // AMBA LPI (ARM IHI 0068C) Table 2-1 reaches Q_DENIED only from Q_REQUEST,
  // and qchannel_monitor already enforces the edges that follow from it:
  //
  //   R6  QDENY 0->1 only when QREQn LOW and QACCEPTn HIGH   (i.e. Q_REQUEST)
  //   R5  QDENY 1->0 only when QREQn HIGH and QACCEPTn HIGH  (request withdrawn)
  //
  // Driving dev_qdeny outside those windows is a protocol violation, and what
  // the PPU does in response to one is not defined by any specification -- so
  // asserting anything about it would over-constrain the design rather than
  // check it. This model therefore owns dev_qdeny entirely: a test ARMS a
  // denial and the model decides whether the protocol permits one.
  //
  // The states are the decoded equivalents of Table 2-1:
  //
  //   Q_RUN      dev_q_run, no request outstanding
  //   Q_REQUEST  request outstanding, not yet answered
  //   Q_STOPPED  quiescent, the sequencer may proceed
  //   Q_DENIED   refused; dev_qdeny HIGH until the request is withdrawn
  //   Q_EXIT     coming back up -- note it has NO denial state, which is why
  //              an up-transition cannot be refused
  typedef enum logic [2:0] {Q_RUN, Q_REQUEST, Q_STOPPED, Q_DENIED, Q_EXIT} q_e;
  q_e   q_st = Q_RUN;
  int   q_lag = 0;

  bit arm_deny      = 1'b0;   // deny the next request the protocol allows
  bit hold_stop     = 1'b0;   // stay in Q_REQUEST instead of quiescing
  bit hold_recovery = 1'b0;   // stay in Q_DENIED after the request is withdrawn

  always @(posedge clk) begin
    if (!rst_n) begin
      q_st <= Q_RUN; q_lag <= 0;
      dev_q_run <= 1'b1; dev_stopped <= 1'b0; dev_qdeny <= 1'b0;
    end else begin
      case (q_st)
        Q_RUN: begin
          dev_q_run <= 1'b1; dev_stopped <= 1'b0; dev_qdeny <= 1'b0;
          if (req_dev_quiescence) begin
            q_st <= Q_REQUEST; q_lag <= 0; dev_q_run <= 1'b0;
          end
        end

        // The ONLY state a denial may be raised from (Table 2-1, monitor R6).
        Q_REQUEST: begin
          if (!req_dev_quiescence) begin
            q_st <= Q_EXIT; q_lag <= 0;
          end else if (q_lag < 3) begin
            q_lag <= q_lag + 1;
          end else if (arm_deny) begin
            dev_qdeny <= 1'b1;
            q_st     <= Q_DENIED;
          end else if (!hold_stop) begin
            dev_stopped <= 1'b1;
            q_st        <= Q_STOPPED;
          end
        end

        Q_STOPPED: begin
          if (!req_dev_quiescence) begin
            dev_stopped <= 1'b0; q_st <= Q_EXIT; q_lag <= 0;
          end
        end

        // Monitor R5: dev_qdeny may only fall once the request is withdrawn, so
        // it is held until then no matter what the test asked for.
        Q_DENIED: begin
          if (!req_dev_quiescence && !hold_recovery) begin
            dev_qdeny <= 1'b0;
            q_st     <= Q_EXIT;
            q_lag    <= 0;
          end
        end

        Q_EXIT: begin
          // No denial state on this path -- an exit handshake cannot be
          // refused, which is the whole reason an up-transition is not
          // deniable. arm_deny is deliberately not consulted here.
          if (q_lag < 3) q_lag <= q_lag + 1;
          else begin
            dev_q_run <= 1'b1;
            q_st      <= Q_RUN;
          end
        end
      endcase
    end
  end

  ppu_seq #(
    .OFF_MEM_RET_TRANS_CFG (1'b1),
    .LOCK_CFG              (1'b1),
    .PWR_MODE_ENTRY_DEL_CFG(1'b1),
    .STA_MASK              (16'h03E5)
  ) u_dut (
    .clk(clk), .rst_n(rst_n), .reset_mode(reset_mode),

    .pwr_policy(pwr_policy), .pwr_dyn_en(pwr_dyn_en), .lock_en(lock_en),
    .unlock_wr(unlock_wr), .policy_wr(policy_wr),
    .devreqen(devreqen), .devactiveen(devactiveen),
    .warm_rst_devreqen(warm_rst_devreqen),
    .rst_hwstat_dly(rst_hwstat_dly), .iso_clken_dly(iso_clken_dly),
    .clken_rst_dly(clken_rst_dly), .clken_iso_dly(clken_iso_dly),
    .iso_rst_dly(iso_rst_dly),
    .off_del(off_del), .mem_ret_del(mem_ret_del), .full_ret_del(full_ret_del),
    .func_ret_del(func_ret_del), .mem_off_del(mem_off_del),
    .funrr(funrr), .fulrr(fulrr), .memrr(memrr),

    .pwr_status(pwr_status), .pwr_dyn_status(pwr_dyn_status),
    .lock_status(lock_status),
    .revert_vld(revert_vld), .revert_policy(revert_policy),
    .revert_dyn_en(revert_dyn_en),

    .ev_sta_policy_trn(ev_sta_policy_trn), .ev_sta_accept(ev_sta_accept),
    .ev_sta_deny(ev_sta_deny), .ev_dyn_accept(ev_dyn_accept),
    .ev_dyn_deny(ev_dyn_deny), .ev_locked(ev_locked),

    .req_dev_quiescence(req_dev_quiescence), .dev_stopped(dev_stopped),
    .dev_q_run(dev_q_run), .dev_qdeny(dev_qdeny), .dev_qactive(dev_qactive),

    .pcsm_req_state(pcsm_req_state), .pcsm_req_valid(pcsm_req_valid),
    .pcsm_cur_state(pcsm_cur_state), .pcsm_init_done(pcsm_init_done),

    .ppuhwstat(ppuhwstat), .dev_clken(dev_clken), .dev_isolaten(dev_isolaten),
    .dev_poresetn(dev_poresetn), .dev_warmresetn(dev_warmresetn),
    .dev_retresetn(dev_retresetn),
    // The clock Q-Channel's device-internal condition. Not this file's subject
    // -- ppu_clkq_tb is -- but connected rather than left open, because the
    // denial path is one of the windows where the PPU must refuse to have its
    // clock taken away, and the invariant below watches it across every group
    // in this file for free.
    .ppu_active  (ppu_active)
  );

  // State probe. The enum is local to ppu_seq, so this compares the raw
  // encoding; S_DN_QREQ is 2 and S_DENIED is 12 (see the typedef there).
  wire [3:0] st = u_dut.state;
  localparam logic [3:0] ST_IDLE = 4'd0, ST_DN_QREQ = 4'd2, ST_DENIED = 4'd12;

  // ---- The clock Q-Channel invariant, watched for the whole file ----
  //
  // PPU_ACTIVE is what tells a clock controller the PPU still needs its clock,
  // and AMBA LPI Section 4.1.1 is why it has to be right: "CLK must be active
  // to perform the management actions in the device that are required before
  // the power state transition, and to respond on the power control
  // interface". A PPU that reported itself idle while a transition -- or a
  // DENIAL, which is a transition being unwound -- was still in flight would
  // let the controller gate the clock mid-sequence and freeze it there.
  //
  // Every non-idle sequencer state is a transition in flight, so the invariant
  // is exact rather than approximate, and it costs one always block to check
  // over all ten groups instead of writing a group for it.
  int stopped_while_busy = 0;
  always @(posedge clk)
    if (rst_n && (st !== ST_IDLE) && !ppu_active)
      stopped_while_busy <= stopped_while_busy + 1;

  // ---- Sticky event catchers, so a one-cycle pulse cannot be missed ----
  bit saw_sta_deny, saw_dyn_deny, saw_revert, saw_policy_trn, saw_sta_accept;
  bit saw_denied_state, saw_pcsm_req;
  logic [3:0] revert_pol_at_pulse;
  logic       revert_dyn_at_pulse;

  always @(posedge clk) if (rst_n) begin
    if (ev_sta_deny)       saw_sta_deny   <= 1'b1;
    if (ev_dyn_deny)       saw_dyn_deny   <= 1'b1;
    if (ev_sta_accept)     saw_sta_accept <= 1'b1;
    if (ev_sta_policy_trn) saw_policy_trn <= 1'b1;
    if (st == ST_DENIED)   saw_denied_state <= 1'b1;
    if (pcsm_req_valid)    saw_pcsm_req   <= 1'b1;
    // Captured on the SAME edge the strobe is high. This is the check that
    // fails if someone ever registers the reversion values alongside the
    // strobe: ppu_regs samples them exactly here.
    if (revert_vld) begin
      saw_revert          <= 1'b1;
      revert_pol_at_pulse <= revert_policy;
      revert_dyn_at_pulse <= revert_dyn_en;
    end
  end

  task automatic arm();
    begin
      saw_sta_deny = 0; saw_dyn_deny = 0; saw_revert = 0; saw_policy_trn = 0;
      saw_sta_accept = 0; saw_denied_state = 0; saw_pcsm_req = 0;
      revert_pol_at_pulse = 4'hx; revert_dyn_at_pulse = 1'bx;
    end
  endtask

  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  task automatic set_policy(input logic [3:0] p, input bit dyn);
    begin
      @(negedge clk); pwr_policy = p; pwr_dyn_en = dyn; policy_wr = 1'b1;
      @(negedge clk); policy_wr = 1'b0;
    end
  endtask

  // Trails by a few cycles on purpose. The event outputs are REGISTERED, so a
  // pulse is assigned on the same edge that enters S_IDLE and is only visible
  // to the sticky catcher on the NEXT edge. Returning the instant st changes
  // would let that pulse land after the next section's arm() had already
  // cleared the flags -- which reads as the previous section's event going
  // missing and the next section's arriving out of nowhere.
  task automatic wait_idle(input int max_cyc);
    int n; begin
      // Wait for the request to be SEEN before waiting for idle. Without this
      // the task returns immediately after set_policy, because the sequencer is
      // still sitting in S_IDLE and has not reacted yet -- so a caller that
      // then checks pwr_status reads the mode it was in before it asked.
      repeat (4) @(posedge clk);
      n = 0;
      while ((st !== ST_IDLE) && (n < max_cyc)) begin @(posedge clk); n++; end
      repeat (3) @(posedge clk);
    end
  endtask

  task automatic wait_state(input logic [3:0] s, input int max_cyc);
    int n; begin
      n = 0;
      while ((st !== s) && (n < max_cyc)) begin @(posedge clk); n++; end
    end
  endtask

  // Snapshot of every Section 6.4 device control, for the "nothing moved" check.
  typedef struct packed {
    logic [15:0] hw;
    logic        clken, iso, pore, warm, ret;
  } ctrl_t;

  function automatic ctrl_t ctrls();
    ctrl_t c;
    c.hw = ppuhwstat; c.clken = dev_clken; c.iso = dev_isolaten;
    c.pore = dev_poresetn; c.warm = dev_warmresetn; c.ret = dev_retresetn;
    return c;
  endfunction

  ctrl_t before_c, after_c;

  // Bring the sequencer to ON from its OFF reset state.
  task automatic goto_on();
    begin
      set_policy(PM_ON, 1'b0);
      wait_idle(4000);
    end
  endtask

  initial begin
    $dumpfile("ppu_deny_tb.vcd");
    $dumpvars(0, ppu_deny_tb);

    $display("==============================================================");
    $display(" ppu_deny_tb: the denial path of ppu_seq");
    $display("  Sections 4.1.1 / 4.2.9, Table 4-1, AMBA LPI Table 2-1");
    $display("==============================================================");

    repeat (8) @(posedge clk);
    rst_n = 1'b1;
    repeat (4) @(posedge clk);
    goto_on();
    ck(pwr_status === PM_ON, "setup: sequencer reached ON");

    // =========================================================================
    section("D2 a denial moves no device control and no PCSM request");
    // =========================================================================
    // Section 4.2.9: "If a transition requires the sequencing of PCSM and clock
    // enables, resets, or isolation enables BEFORE performing a device
    // interface handshake, if the handshake is denied these actions must be
    // reversed." On this design nothing precedes the handshake on a departure,
    // so there is nothing to reverse -- and Figure 4-35 shows exactly that:
    // DEV*CLKEN, DEV*ISOLATEn, DEV*RESETn, PWRPREQ and PPUHWSTAT all flat.
    //
    // This is the measurement that turns that from a claim into a fact.
    arm();
    hold_stop = 1'b1;                            // hold the sequencer in S_DN_QREQ
    set_policy(PM_OFF, 1'b0);
    wait_state(ST_DN_QREQ, 200);
    repeat (4) @(posedge clk);
    before_c = ctrls();

    arm_deny = 1'b1;
    wait_state(ST_DENIED, 80);
    arm_deny = 1'b0;
    ck(st === ST_DENIED, "DEVQDENY in S_DN_QREQ moves the sequencer to S_DENIED");
    after_c = ctrls();
    ck(after_c === before_c, "no device control moved while entering S_DENIED");

    hold_stop = 1'b0;
    wait_idle(4000);
    after_c = ctrls();
    ck(after_c === before_c, "and none moved across the whole denial (Figure 4-35)");
    ck(!saw_pcsm_req,        "PCSMPREQ was never raised");
    ck(pwr_status === PM_ON, "PWR_STATUS never left ON");

    // =========================================================================
    section("D3 Table 4-1 static reversion");
    // =========================================================================
    // Section 4.1.1: "The policy reverts to the current mode as shown in the
    // Power Status Register (PPU_PWSR)." With PWR_DYN_STATUS LOW that is the
    // top-left cell of Table 4-1 -- power mode only, so power is reverted.
    ck(saw_sta_deny,   "STA_DENY_IRQ fired (the transition was static)");
    ck(!saw_dyn_deny,  "DYN_DENY_IRQ did not");
    ck(saw_revert,     "revert_vld pulsed");
    ck(revert_pol_at_pulse === PM_ON,
       "revert_policy AT THE PULSE is cur_mode, i.e. PPU_PWSR.PWR_STATUS");
    ck(revert_dyn_at_pulse === 1'b0,
       "revert_dyn_en is the value PWR_DYN_EN had when the transition began");

    // =========================================================================
    section("D4 the sequencer waits for Q_RUN before leaving S_DENIED");
    // =========================================================================
    // qchannel_controller drives its own Q_DENIED -> Q_CONTINUE -> Q_RUN
    // recovery once the request is withdrawn. Leaving S_DENIED early would let
    // the sequencer re-request into the middle of that.
    arm();
    hold_stop = 1'b1;
    hold_recovery = 1'b1;                           // recovery not finished yet
    set_policy(PM_OFF, 1'b0);
    wait_state(ST_DN_QREQ, 200);
    repeat (4) @(posedge clk);
    arm_deny = 1'b1;
    wait_state(ST_DENIED, 80);
    arm_deny = 1'b0;
    ck(st === ST_DENIED, "in S_DENIED");

    repeat (100) @(posedge clk);
    ck(st === ST_DENIED, "still in S_DENIED 100 cycles later, Q_RUN never came");
    ck(!saw_sta_deny,    "and the denial event has NOT fired yet");
    ck(!saw_revert,      "nor has the reversion");

    // Long enough for the model's full Q_DENIED -> Q_EXIT -> Q_RUN walk, which
    // is what the sequencer is actually waiting on -- not for a fixed number of
    // cycles chosen to make the check pass.
    hold_recovery = 1'b0;                           // recovery finishes
    while (!dev_q_run) @(posedge clk);
    repeat (4) @(posedge clk);
    ck(saw_sta_deny, "Q_RUN releases it: STA_DENY_IRQ fires");
    ck(saw_revert,   "and the reversion happens");
    hold_stop = 1'b0;
    wait_idle(4000);
    ck(st === ST_IDLE, "and the sequencer returns to idle");

    // =========================================================================
    section("D5 Table 4-1 with PWR_DYN_STATUS HIGH: no reversion");
    // =========================================================================
    // "1 / 0 / None" in Table 4-1: nothing is reverted, because the policy is
    // only a minimum and the DEVACTIVE inputs, not the register, are driving
    // the transition. The event is the dynamic one instead.
    goto_on();
    set_policy(PM_ON, 1'b1);                        // dynamic enabled
    wait_idle(2000);
    ck(pwr_dyn_status === 1'b1, "setup: PWR_DYN_STATUS is HIGH");

    arm();
    hold_stop = 1'b1;
    set_policy(PM_OFF, 1'b1);
    dev_qactive = 1'b0;                              // quiet, so it descends
    wait_state(ST_DN_QREQ, 400);
    repeat (4) @(posedge clk);
    arm_deny = 1'b1;
    wait_state(ST_DENIED, 80);
    arm_deny = 1'b0;
    hold_stop = 1'b0;
    wait_idle(4000);
    ck(saw_dyn_deny,  "DYN_DENY_IRQ fired");
    ck(!saw_sta_deny, "STA_DENY_IRQ did not");
    ck(!saw_revert,   "and NOTHING was reverted (Table 4-1, PWR_DYN_STATUS = 1)");

    // =========================================================================
    section("D6 an exit handshake offers no way to refuse");
    // =========================================================================
    // AMBA LPI Table 2-1: Q_DENIED is reachable only from Q_REQUEST, and the
    // exit path Q_STOPPED -> Q_EXIT -> Q_RUN has no denial state. Every return
    // to ON is an exit handshake, so no up-transition is deniable.
    //
    // The honest test of that is to ARM a denial across the whole climb and
    // observe that none appears -- the model refuses to raise dev_qdeny on a
    // path where the protocol has no state for it. Forcing dev_qdeny HIGH
    // instead would be a monitor R6 violation, and what the PPU does with an
    // illegal input is not defined by any specification, so an assertion about
    // it would constrain this implementation rather than check it.
    //
    // Protocol legality itself belongs to qchannel_monitor (rules R5, R6, R7)
    // and the Q-Channel testbench, not here.
    set_policy(PM_OFF, 1'b0);
    wait_idle(4000);
    ck(pwr_status === PM_OFF, "setup: down in OFF");

    arm();
    arm_deny = 1'b1;                                // armed for the entire climb
    set_policy(PM_ON, 1'b0);
    wait_idle(4000);
    arm_deny = 1'b0;
    ck(pwr_status === PM_ON, "climbed to ON with a denial armed throughout");
    ck(!saw_denied_state,    "no denial was ever raised: the exit path has no Q_DENIED");
    ck(!saw_sta_deny,        "so no denial event");
    ck(!saw_revert,          "and no reversion");

    // =========================================================================
    section("D7 Section 4.1.2's third completion condition");
    // =========================================================================
    // "a denied transition completes with both PPU_PWSR.PWR_DYN_STATUS and
    // PPU_PWSR.OP_DYN_STATUS set to 0b0", "PPU_PWPR is written during the
    // transition", and "the last power and operating policies written match the
    // current power and operating modes."
    //
    // Software asked for a mode, changed its mind mid-flight to the mode the
    // PPU is already in, and the original request was then refused. The outcome
    // is exactly what software last asked for, so it is told its policy has
    // been reached -- even though the only transition that ran was denied.
    arm();
    hold_stop = 1'b1;
    set_policy(PM_OFF, 1'b0);                       // ask to leave ON
    wait_state(ST_DN_QREQ, 200);
    set_policy(PM_ON, 1'b0);                        // change of mind, mid-flight
    repeat (2) @(posedge clk);
    arm_deny = 1'b1;
    wait_state(ST_DENIED, 80);
    arm_deny = 1'b0;
    hold_stop = 1'b0;
    wait_idle(4000);
    ck(saw_sta_deny,   "the denial event still fires");
    ck(saw_policy_trn, "and STA_POLICY_TRN_IRQ fires too: the policy WAS reached");

    // The negative case, without which the check above proves nothing: no
    // mid-flight write means no completion event.
    goto_on();
    arm();
    hold_stop = 1'b1;
    set_policy(PM_OFF, 1'b0);
    wait_state(ST_DN_QREQ, 200);
    repeat (4) @(posedge clk);
    arm_deny = 1'b1;
    wait_state(ST_DENIED, 80);
    arm_deny = 1'b0;
    hold_stop = 1'b0;
    wait_idle(4000);
    ck(saw_sta_deny,    "denial with no mid-flight write: the denial event fires");
    ck(!saw_policy_trn, "  ...and STA_POLICY_TRN_IRQ does NOT");

    // =========================================================================
    section("D8 a disabled channel cannot be denied");
    // =========================================================================
    // Section 4.1.3: when a Q-Channel is disabled "DEVQREQn is driven
    // permanently HIGH", so no handshake happens and there is nothing for the
    // device to refuse. DEVQDENY becomes meaningless rather than merely unused.
    goto_on();
    arm();
    // Nothing is armed and nothing is forced: with the channel disabled there
    // is no handshake for a device to answer, so a denial is not merely unused
    // but unreachable. Asserting dev_qdeny here to "prove" it is ignored would
    // be raising QDENY with QREQn permanently HIGH -- monitor R6 again.
    devreqen = 1'b0;
    arm_deny = 1'b1;
    set_policy(PM_OFF, 1'b0);
    wait_idle(4000);
    arm_deny = 1'b0;
    devreqen = 1'b1;
    ck(pwr_status === PM_OFF, "reached OFF with the channel disabled");
    ck(!saw_denied_state,     "DEVQDENY could not deny what never handshook");
    ck(!saw_sta_deny,         "no denial event");

    // =========================================================================
    section("D9 the sequencer is usable again after a denial");
    // =========================================================================
    goto_on();
    arm();
    hold_stop = 1'b1;
    set_policy(PM_MEM_RET, 1'b0);
    wait_state(ST_DN_QREQ, 200);
    repeat (4) @(posedge clk);
    arm_deny = 1'b1;
    wait_state(ST_DENIED, 80);
    arm_deny = 1'b0;
    hold_stop = 1'b0;
    wait_idle(4000);
    ck(st === ST_IDLE,       "back to S_IDLE after the denial");
    ck(pwr_status === PM_ON, "and still in ON");

    arm();
    set_policy(PM_MEM_RET, 1'b0);                   // same request, not denied
    wait_idle(4000);
    ck(pwr_status === PM_MEM_RET, "the very next request succeeds");
    ck(saw_sta_accept,            "with an acceptance event");
    ck(!saw_sta_deny,             "and no lingering denial");

    // =========================================================================
    section("D10 the reverted policy is not re-requested");
    // =========================================================================
    // The defect this section exists for, found while writing D9.
    //
    // revert_vld is asserted on the same edge that moves S_DENIED to S_IDLE, so
    // S_IDLE next evaluates while ppu_regs is still writing the reverted value
    // into PPU_PWPR. Reading pwr_policy one cycle stale means reading the
    // policy that was just DENIED, and launching it again.
    //
    // It does not self-correct: hop_q is latched at that moment and no
    // departure state re-checks it. S_DELAY does, but use_entry_delay is false
    // whenever the entry delay is 0 -- which is its RESET value, so the
    // out-of-the-box configuration is the vulnerable one. Measured before the
    // fix, on the full stack: a single denied request for OFF produced
    // ON -> OFF -> ON, powering the domain down to a mode software had
    // explicitly had reverted out from under it, then back up.
    //
    // The check is that no transition starts AT ALL after the denial. Checking
    // the end state would pass either way, because the spurious round trip
    // returns to where it began.
    goto_on();
    arm();
    hold_stop = 1'b1;
    set_policy(PM_OFF, 1'b0);
    wait_state(ST_DN_QREQ, 200);
    repeat (4) @(posedge clk);
    arm_deny = 1'b1;
    wait_state(ST_DENIED, 80);
    arm_deny = 1'b0;

    // Let the denial resolve, then watch every cycle for a departure that
    // should never begin. q_allow_stop stays HIGH so that a spurious hop would
    // actually be able to make progress -- a check that only passes because the
    // device never quiesced would prove nothing.
    hold_stop = 1'b0;
    begin
      bit moved;
      moved = 1'b0;
      repeat (400) begin
        @(posedge clk);
        if (st !== ST_IDLE && st !== ST_DENIED) moved = 1'b1;
      end
      ck(!moved,
         "no transition starts after the reversion (the policy is ON again)");
    end
    ck(pwr_status === PM_ON, "and PWR_STATUS never left ON");

    // =========================================================================
    section("D11 PPU_ACTIVE never went LOW with a transition in flight");
    // =========================================================================
    // AMBA LPI Section 4.1.1, checked over every cycle of every group above
    // rather than in a scenario of its own. See the always block by the DUT.
    ck(stopped_while_busy == 0,
       $sformatf("PPU_ACTIVE stayed HIGH in every non-idle cycle (%0d violations)",
                 stopped_while_busy));

    // =========================================================================
    // =========================================================================
    $display("");
    $display("==============================================================");
    $display(" ppu_deny_tb: %0d checks, %0d error(s)", checks, errors);
    $display(" RESULT: %0s", (errors == 0) ? "PASS" : "FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    #200000;
    $display("RESULT: FAIL");
    $fatal(1, "ppu_deny_tb watchdog");
  end

endmodule
