`timescale 1ns/1ps
// PPU reset-behaviour testbench -- Table 4-13, all four rows.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Sections 4.2.1 "PPU Reset Behavior" and 4.1.6 "PCSMMODESTAT".
//
// WHY THIS IS A SEPARATE TESTBENCH
//
// The two inputs that decide how a PPU comes out of reset are both
// ELABORATION-TIME: DEF_PWR_POLICY is a configuration parameter (Section 7.1.3)
// and PCSMMODESTAT is sampled once, at reset release, and may not legally change
// afterwards. So they cannot be swept from inside a running simulation the way
// ppu_pd_tb sweeps everything else -- covering them needs more than one DUT.
//
// Four instances, one per row of Table 4-13:
//
//   Default Power Policy   PCSMMODESTAT        Behaviour
//   --------------------   -----------------   ----------------------------------
//   OFF                    OFF / not present   Initialises into OFF
//   OFF                    MEM_RET             Initialises into MEM_RET
//   ON                     OFF / not present   Initialises into ON
//   ON                     MEM_RET             Initialises into MEM_RET, then
//                                              transitions to ON
//
// ppu_pd_tb's phase P0 already covers the third row, which is the build every
// other phase uses. The other three have never run before this file existed.
//
// THE ROW THAT WAS A BUG
//
// Row two is the regression test for F5 in rtl/ppu/CONFORMANCE.md. Section 4.1.6
// requires that when PCSMMODESTAT reports MEM_RET and the default policy is OFF,
// the PPU "sets PPU_PWPR.PWR_POLICY to MEM_RET" -- not just PWR_STATUS. Without
// that, the PPU initialises into MEM_RET and then immediately leaves for OFF,
// where Table 4-13 says it should simply stay. The check below is on the POLICY,
// because that is the part that was wrong; checking only the status would have
// passed against the broken design.
//
// ONE BUS, FOUR DUTS
//
// All four instances share the software interface inputs and expose their own
// reg_rdata, so a single read transaction returns all four values at once. That
// keeps the register-visible checks genuinely register-visible -- rather than
// reaching into ppu_regs hierarchically -- without four copies of the bus
// driver. Writes reach all four, which is exactly what the final "they all still
// work" step wants.

module ppu_reset_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  logic aon_clk = 1'b0, dclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;
  always #6.85 dclk    = ~dclk;

  logic aon_rst_n = 1'b0;

  logic [11:0] reg_waddr  = 12'h000;

  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0] reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;

  logic [31:0] rd_a, rd_b, rd_c, rd_d;
  logic        irq_a, irq_b, irq_c, irq_d;

  int unsigned tb_errors = 0, checks = 0;

  // ---------------------------------------------------------------------------
  // Four DUTs, one per Table 4-13 row
  // ---------------------------------------------------------------------------
  // Tied-off workload stimulus: this testbench is about reset behaviour, and a
  // busy workload could deny a transition and confuse the question being asked.
  `define PPU_RST_DUT(NAME, DEFPOL, MODESTAT, RDATA, IRQ)                     \
    ppu_pd_top #(                                                             \
      .SYNC_STAGES        (2),                                                \
      .CNT_W              (CNT_W),                                            \
      .DEF_PWR_POLICY     (DEFPOL),                                           \
      .PCSM_RESET_MODESTAT(MODESTAT)                                          \
    ) NAME (                                                                  \
      .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),                               \
      .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),                             \
      .reg_wen(reg_wen), .reg_wstrb(reg_wstrb),                               \
      .reg_ren(reg_ren),                                                      \
      .reg_rdata(RDATA), .irq(IRQ),                                           \
      .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),                \
      .ppuclk_qactive(), .pwakeup(1'b0),                                      \
      .dclk(dclk), .start(1'b0), .work_len('0),                               \
      .light_work(1'b0), .wake(1'b0), .deny_enb(1'b1),                        \
      .ip_cmd(2'b00), .ip_seed(8'h00)                                         \
    )

  `PPU_RST_DUT(u_a, PM_OFF, PM_OFF,     rd_a, irq_a);   // row 1
  `PPU_RST_DUT(u_b, PM_OFF, PM_MEM_RET, rd_b, irq_b);   // row 2  <- F5
  `PPU_RST_DUT(u_c, PM_ON,  PM_OFF,     rd_c, irq_c);   // row 3
  `PPU_RST_DUT(u_d, PM_ON,  PM_MEM_RET, rd_d, irq_d);   // row 4

  // ---------------------------------------------------------------------------
  // A fifth instance, for the ordering rule Table 4-13 does not cover
  // ---------------------------------------------------------------------------
  // Section 4.1.6: the PCSMPSTATE reset value "is sampled by the PCSM before any
  // other transition is allowed on the interface", which is why ppu_seq gates
  // its first transition on pcsm_init_done.
  //
  // That gate is REDUNDANT, and it is worth being precise about why, because the
  // obvious guess is wrong. Removing it as a mutation moves the first PCSMPREQ
  // about two PPU cycles earlier and it still lands after initialisation. The
  // first explanation offered was that tinit was simply too short, so this
  // instance was built with PCSM_TINIT_WAIT = 200 to separate them.
  //
  // It does not separate them, and cannot at any value: ppu_top wires
  // pcsm_init_done straight from pchannel_controller's ctrl_init_done, which is
  // the same signal the controller uses to hold its own PREQ off. The sequencer's
  // gate and the controller's gate are one condition wearing two names, so no
  // tinit makes the sequencer's copy observable. It is defence in depth, and the
  // outer layer is unreachable.
  //
  // The instance stays, for the coverage it does provide rather than the coverage
  // it was built for: PCSM_TINIT_WAIT had only ever been elaborated at 16, and a
  // PPU that mishandled a long initialisation would show up here.
  logic [31:0] rd_e;
  logic        irq_e;

  ppu_pd_top #(
    .SYNC_STAGES        (2),
    .CNT_W              (CNT_W),
    .DEF_PWR_POLICY     (PM_ON),
    .PCSM_RESET_MODESTAT(PM_OFF),
    .PCSM_TINIT_WAIT    (200)          // ~10x the PPU's path to its first request
  ) u_e (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),
    .reg_wen(reg_wen), .reg_wstrb(reg_wstrb), .reg_ren(reg_ren),
    .reg_rdata(rd_e), .irq(irq_e),
    // Clock control interface unused here: PPUCLKQREQn HIGH parks the
    // channel in Q_RUN, so the PPU's clock is never gated and this suite
    // sees the design exactly as it was before the interface existed.
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .dclk(dclk), .start(1'b0), .work_len('0),
    .light_work(1'b0), .wake(1'b0), .deny_enb(1'b1),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0] mode_e = u_e.u_dom.u_ppu.u_seq.pwr_status;

  // The observer. One edge, at the very start of the run.
  int unsigned preq_before_init = 0;
  always @(posedge u_e.u_dom.u_ppu.pcsm_preq)
    if (!u_e.u_dom.u_ppu.pcsm_init_done) preq_before_init = preq_before_init + 1;

  // ...and the DURATION, which is a separate question from the ordering above.
  // AMBA LPI Section 2.2.2 gives the controller a tinit period after reset in
  // which it must not issue a request. The ordering check cannot see how long
  // that period is -- ppu_top wires pcsm_init_done from the same signal the
  // controller uses to gate itself, so the two agree by construction whatever
  // the value. Only counting cycles pins the value down.
  //
  // This is the third instance of the same blind spot: RST_HWSTAT_DLY (PPU) and
  // TINIT_WAIT (P-Channel controller) were both delays that every functional
  // check tolerated because nothing downstream depended on their length.
  int unsigned pcsm_tinit_cycles = 0;
  bit          pcsm_tinit_seen   = 1'b0;
  always @(posedge aon_clk) if (aon_rst_n && !pcsm_tinit_seen) begin
    if (u_e.u_dom.u_ppu.pcsm_preq) pcsm_tinit_seen   <= 1'b1;
    else                    pcsm_tinit_cycles <= pcsm_tinit_cycles + 1;
  end

  // Modes, read hierarchically for the immediate post-reset sample where a bus
  // read would take longer than the window being observed.
  wire [3:0] mode_a = u_a.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] mode_b = u_b.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] mode_c = u_c.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] mode_d = u_d.u_dom.u_ppu.u_seq.pwr_status;

  // The PCSM's own committed view, and its RAM actuation. Section 4.1.6 makes
  // these the PPU's responsibility at reset: PCSMPSTATE resets to the mode the
  // PPU believes it is in, so the value the PCSM captures during tinit AGREES
  // with PWR_STATUS. Getting that wrong is silent in every functional check
  // that only looks at the PPU side.
  wire [3:0] pcsm_a = u_a.u_dom.u_pcsm.mode;
  wire [3:0] pcsm_b = u_b.u_dom.u_pcsm.mode;
  wire [3:0] pcsm_c = u_c.u_dom.u_pcsm.mode;
  wire [3:0] pcsm_d = u_d.u_dom.u_pcsm.mode;
  wire ramret_b = u_b.u_dom.ram_ret;
  wire ramret_d = u_d.u_dom.ram_ret;

  wire busy_a = (u_a.u_dom.u_ppu.u_seq.state !== 4'd0);
  wire busy_b = (u_b.u_dom.u_ppu.u_seq.state !== 4'd0);
  wire busy_c = (u_c.u_dom.u_ppu.u_seq.state !== 4'd0);
  wire busy_d = (u_d.u_dom.u_ppu.u_seq.state !== 4'd0);

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  task automatic check(input bit cond, input string tag);
    begin
      checks++;
      if (!cond) begin tb_errors++; $display("[%0t] FAIL %0s", $time, tag); end
      else            $display("[%0t]  ok  %0s", $time, tag);
    end
  endtask

  task automatic check_mode(input logic [3:0] got, input logic [3:0] exp,
                            input string tag);
    begin
      checks++;
      if (got !== exp) begin
        tb_errors++;
        $display("[%0t] FAIL %0s: %0s, expected %0s", $time, tag,
                 ppu_mode_name(got), ppu_mode_name(exp));
      end else begin
        $display("[%0t]  ok  %0s = %0s", $time, tag, ppu_mode_name(exp));
      end
    end
  endtask

  task automatic reg_read(input logic [11:0] a);
    begin
      @(negedge aon_clk);
      reg_raddr = a; reg_ren = 1'b1;
      @(negedge aon_clk);
      reg_ren = 1'b0;
    end
  endtask

  task automatic reg_write(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk);
      reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk);
      reg_wen = 1'b0;
    end
  endtask

  task automatic settle();
    begin
      // Long enough for the slowest legal bring-up: PCSM tinit, the PCSM
      // handshake, all four device-control delay steps, and the device exit
      // handshake on the 13.7 ns device clock.
      repeat (200) @(posedge aon_clk);
    end
  endtask

  task automatic banner(input string name);
    $display("\n[%0t] ========== %0s ==========", $time, name);
  endtask

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("ppu_reset_tb.vcd");
    $dumpvars(0, ppu_reset_tb);

    banner("Reset held");
    preq_before_init = 0;
    aon_rst_n = 1'b0;
    repeat (10) @(posedge aon_clk);

    // -------------------------------------------------------------------------
    banner("Release reset, then sample BEFORE any default transition");
    $display("[%0t]   Section 4.1.6: PCSMMODESTAT 'is only sampled by the PPU at", $time);
    $display("[%0t]   reset release'. PWR_STATUS therefore has its Table 4-13", $time);
    $display("[%0t]   value immediately -- before the sequencer has done anything.", $time);
    $display("[%0t]   The window is comfortable: no transition can start until", $time);
    $display("[%0t]   the PCSM's tinit has expired (16 PPU cycles).", $time);
    @(negedge aon_clk) aon_rst_n = 1'b1;
    repeat (5) @(posedge aon_clk);

    check_mode(mode_a, PM_OFF,     "row1 DEF=OFF MODESTAT=OFF      : initial PWR_STATUS");
    check_mode(mode_b, PM_MEM_RET, "row2 DEF=OFF MODESTAT=MEM_RET  : initial PWR_STATUS");
    check_mode(mode_c, PM_OFF,     "row3 DEF=ON  MODESTAT=OFF      : initial PWR_STATUS");
    check_mode(mode_d, PM_MEM_RET, "row4 DEF=ON  MODESTAT=MEM_RET  : initial PWR_STATUS");

    // -------------------------------------------------------------------------
    banner("The PCSM captured the SAME mode the PPU thinks it is in");
    $display("[%0t]   Section 4.1.6 'PCSM P-Channel Reset': 'The PCSMPSTATE output", $time);
    $display("[%0t]   is reset to the default power mode of the PPU... This ensures", $time);
    $display("[%0t]   that the reset value is sampled by the PCSM before any other", $time);
    $display("[%0t]   transition is allowed on the interface.'", $time);
    $display("[%0t]   The PCSM captures PCSMPSTATE during its tinit and adopts it as", $time);
    $display("[%0t]   its current state. If that value disagrees with PWR_STATUS the", $time);
    $display("[%0t]   two start from different ideas of the domain -- and rows 2 and", $time);
    $display("[%0t]   4 are where it bites, because a PCSM that captured OFF instead", $time);
    $display("[%0t]   of MEM_RET drops the RAM retention it just told the PPU it was", $time);
    $display("[%0t]   holding. Worse, with policy == status no transition ever runs to", $time);
    $display("[%0t]   correct it.", $time);
    check_mode(pcsm_a, PM_OFF,     "row1: PCSM captured the same mode as the PPU");
    check_mode(pcsm_b, PM_MEM_RET, "row2: PCSM captured MEM_RET, not OFF");
    check_mode(pcsm_c, PM_OFF,     "row3: PCSM captured the same mode as the PPU");
    check_mode(pcsm_d, PM_MEM_RET, "row4: PCSM captured MEM_RET, not OFF");
    check(ramret_b, "row2: and is therefore RETAINING the RAM (ram_ret asserted)");
    check(ramret_d, "row4: and is therefore RETAINING the RAM (ram_ret asserted)");

    // -------------------------------------------------------------------------
    banner("PPU_PWPR.PWR_POLICY reset value -- the F5 regression");
    $display("[%0t]   Section 4.1.6: 'If the default power policy,", $time);
    $display("[%0t]   DEF_PWR_POLICY, is OFF, sets PPU_PWPR.PWR_POLICY to", $time);
    $display("[%0t]   MEM_RET.' Only row 2 meets that condition. Rows 3 and 4", $time);
    $display("[%0t]   keep a policy of ON, because a default of ON means the PPU", $time);
    $display("[%0t]   is supposed to climb out regardless of where it started.", $time);
    reg_read(A_PWPR);
    check(rd_a[3:0] === PM_OFF,     "row1: PWR_POLICY = OFF");
    check(rd_b[3:0] === PM_MEM_RET, "row2: PWR_POLICY = MEM_RET  <- F5");
    check(rd_c[3:0] === PM_ON,      "row3: PWR_POLICY = ON");
    check(rd_d[3:0] === PM_ON,      "row4: PWR_POLICY = ON");

    // -------------------------------------------------------------------------
    banner("Let every instance settle, then check Table 4-13's outcome");
    settle();
    check(!busy_a && !busy_b && !busy_c && !busy_d,
          "all four sequencers idle after settling");

    $display("[%0t]   Rows 1 and 2 must NOT have moved. Section 4.2.1 'Reset to", $time);
    $display("[%0t]   OFF': the PPU 'remains in OFF until another policy is", $time);
    $display("[%0t]   programmed... or dynamic transitions are enabled'. Row 2", $time);
    $display("[%0t]   stays in MEM_RET for the same reason once its policy is", $time);
    $display("[%0t]   MEM_RET rather than OFF -- which is exactly what F5 broke.", $time);
    check_mode(mode_a, PM_OFF,     "row1: settled in OFF, no transition");
    check_mode(mode_b, PM_MEM_RET, "row2: settled in MEM_RET, no transition");

    $display("[%0t]   Rows 3 and 4 must have brought the domain up unaided.", $time);
    $display("[%0t]   Section 4.2.1 'Reset to ON': 'the PPU needs to control the", $time);
    $display("[%0t]   domain power on and exit from reset. Therefore, there is a", $time);
    $display("[%0t]   transition before the domain reaches ON.'", $time);
    check_mode(mode_c, PM_ON, "row3: transitioned to ON");
    check_mode(mode_d, PM_ON, "row4: initialised into MEM_RET, then reached ON");

    // -------------------------------------------------------------------------
    banner("The default transition is SILENT in every configuration");
    $display("[%0t]   Section 4.2.1, for both defaults: 'This default transition", $time);
    $display("[%0t]   does not generate an interrupt event when it completes.'", $time);
    $display("[%0t]   Row 4 is the interesting one -- it performed a real", $time);
    $display("[%0t]   MEM_RET -> ON transition and must still be quiet.", $time);
    check(!irq_a && !irq_b && !irq_c && !irq_d, "no IRQ asserted on any instance");
    reg_read(A_ISR);
    check(rd_a === 32'h0, "row1: PPU_ISR clear");
    check(rd_b === 32'h0, "row2: PPU_ISR clear");
    check(rd_c === 32'h0, "row3: PPU_ISR clear");
    check(rd_d === 32'h0, "row4: PPU_ISR clear");

    // -------------------------------------------------------------------------
    banner("Device controls match the settled mode in every configuration");
    // OFF and MEM_RET share a device-control row (Tables 4-7/4-9/4-11): the
    // logic is unpowered in both, so they differ only in what the PCSM does to
    // the RAM. That is why rows 1 and 2 are checked with the same expectation.
    check(!u_a.u_dom.dev_clken && !u_a.dev_isolaten && !u_a.u_dom.dev_poresetn,
          "row1: OFF -- clock gated, isolated, held in reset");
    check(!u_b.u_dom.dev_clken && !u_b.dev_isolaten && !u_b.u_dom.dev_poresetn,
          "row2: MEM_RET -- clock gated, isolated, held in reset");
    check(u_c.u_dom.dev_clken && u_c.dev_isolaten && u_c.u_dom.dev_poresetn && u_c.u_dom.dev_warmresetn,
          "row3: ON -- every control released");
    check(u_d.u_dom.dev_clken && u_d.dev_isolaten && u_d.u_dom.dev_poresetn && u_d.u_dom.dev_warmresetn,
          "row4: ON -- every control released");

    // -------------------------------------------------------------------------
    banner("All four are functional afterwards");
    $display("[%0t]   A PPU that came out of reset into the right mode but could", $time);
    $display("[%0t]   not then be driven would still be broken. One shared write", $time);
    $display("[%0t]   of a policy of ON reaches all four.", $time);
    reg_write(A_PWPR, {28'h0, PM_ON});
    settle();
    check_mode(mode_a, PM_ON, "row1: driven from OFF to ON by software");
    check_mode(mode_b, PM_ON, "row2: driven from MEM_RET to ON by software");
    check_mode(mode_c, PM_ON, "row3: still ON");
    check_mode(mode_d, PM_ON, "row4: still ON");

    $display("[%0t]   And rows 1 and 2 must now raise the completion interrupt --", $time);
    $display("[%0t]   this transition is a SOFTWARE-programmed one, not the silent", $time);
    $display("[%0t]   default, so the Section 4.2.1 exemption does not apply.", $time);
    reg_read(A_ISR);
    check(rd_a[ISR_STA_POLICY_TRN] === 1'b1, "row1: completion IRQ for the software transition");
    check(rd_b[ISR_STA_POLICY_TRN] === 1'b1, "row2: completion IRQ for the software transition");

    // -------------------------------------------------------------------------
    banner("Long tinit: the PCSM samples its reset state before any request");
    $display("[%0t]   Section 4.1.6: the PCSMPSTATE reset value 'is sampled by", $time);
    $display("[%0t]   the PCSM before any other transition is allowed on the", $time);
    $display("[%0t]   interface.'", $time);
    $display("[%0t]   u_e is built with PCSM_TINIT_WAIT = 200, a value never", $time);
    $display("[%0t]   elaborated before. The check below cannot fail -- ppu_top", $time);
    $display("[%0t]   wires pcsm_init_done from the same ctrl_init_done that holds", $time);
    $display("[%0t]   the controller's own PREQ off, so the sequencer's gate is", $time);
    $display("[%0t]   unreachable defence in depth. What this instance does cover", $time);
    $display("[%0t]   is the long initialisation itself.", $time);
    check(preq_before_init == 0,
          "long tinit: PCSMPREQ never rose while the PCSM was initialising");
    check(pcsm_tinit_seen,
          "long tinit: the PPU did eventually issue a PCSM request");
    $display("[%0t]   PCSMPREQ stayed LOW for %0d PPU clocks (TINIT_WAIT = 200)",
             $time, pcsm_tinit_cycles);
    check(pcsm_tinit_cycles >= 200,
          "long tinit: PCSMPREQ held LOW for at least PCSM_TINIT_WAIT cycles");
    check_mode(mode_e, PM_ON,
               "long tinit: and the PPU still reached its default policy");

    // -------------------------------------------------------------------------
    banner("SUMMARY");
    $display(" checks run       : %0d", checks);
    $display(" testbench errors : %0d", tb_errors);
    $display(" RESULT: %0s", (tb_errors == 0) ? "PASS" : "FAIL");
    $display("");
    $finish;
  end

  initial begin
    #200000;
    $display("\n[%0t] *** WATCHDOG TIMEOUT ***", $time);
    $display("  modes: a=%0s b=%0s c=%0s d=%0s", ppu_mode_name(mode_a),
             ppu_mode_name(mode_b), ppu_mode_name(mode_c), ppu_mode_name(mode_d));
    $finish;
  end

endmodule
