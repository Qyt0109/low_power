`timescale 1ns/1ps
// Behavioural power-intent model -- what src/upf/ppu_pd_top.upf would do, in
// SystemVerilog, so that an ordinary simulator can check it.
//
// SIMULATION ONLY. This is testbench collateral, not RTL: it must never be
// synthesized and never be instantiated inside a design module.
//
// -----------------------------------------------------------------------------
// WHY THIS EXISTS
//
// Icarus and Vivado xsim have no notion of power intent, so under "make ppu"
// FULL_RET, MEM_RET and OFF are indistinguishable -- in all three the workload
// is held in reset and reads back its reset values. Every check in the
// testbench up to this point is therefore about CONTROL SIGNAL SEQUENCING, and
// says nothing about whether the sequencing has any physical effect.
//
// This model supplies the missing half. It implements, behaviourally, the four
// things the UPF file declares:
//
//   create_power_switch   -> a supply state derived from the PCSM's Table 3-1
//                            decode: FULL_ON, RETENTION, or OFF
//   -simstate CORRUPT     -> `corrupt`, which the testbench uses to force X
//                            into every register in the switched domain
//   set_isolation         -> `iso_clamp`, which the testbench uses to clamp the
//                            one off-to-on crossing
//   set_retention         -> `do_save` / `do_restore`, so state that is
//                            supposed to survive FULL_RET actually does
//
// It is a MODEL, not a second implementation of the PPU: every output below is
// derived from the PPU's own device controls and the PCSM's own actuation. It
// never predicts what those should be -- it reacts to them, and complains when
// their ORDERING is unsafe.
//
// -----------------------------------------------------------------------------
// WHAT IT CHECKS, AND WHY A STATIC CHECKER WOULD CHECK THE SAME THINGS
//
// The PU rules below are the power-aware equivalents of qchannel_monitor's
// R-rules. Each one is a property a UPF static checker would assert about the
// PD_DEV boundary, expressed as an edge condition:
//
//   PU1  the supply is removed only while isolation is already active
//   PU2  the supply is removed only while the domain's clock is already off
//   PU3  the supply is removed only while the domain is already in reset
//   PU4  isolation is released only after the supply is back
//   PU5  the clock is enabled only while the supply is present
//   PU6  reset is released only while the supply is present AND the clock runs
//   PU7  the retention supply leads the primary's removal and lags its
//        return -- make before break, never a gap
//   PU9  a retention save is taken only while the retention supply is present
//   PU10 a retention restore happens only while the primary supply is back
//   PU8  the domain is never unpowered with isolation inactive (a level rule,
//        not an edge one -- this is the window in which X escapes)
//
// PU1-PU3 are the "down" leg of the sequence every low-power methodology
// prescribes, PU4-PU6 the "up" leg. The PPU's whole reason to exist is to get
// that order right, so a violation here is a sequencing bug in ppu_seq, not a
// modelling artefact.

module ppu_power_model (
  input  logic clk,        // PPU clock -- the domain the controls are driven in
  input  logic rst_n,

  // ---- PPU device controls ----
  input  logic dev_clken,
  input  logic dev_isolaten,
  input  logic dev_poresetn,
  input  logic dev_warmresetn,
  input  logic dev_retresetn,

  // ---- PCSM actuation (its decode of PCSMPSTATE, Table 3-1) ----
  input  logic logic_on,   // full logic supply present
  input  logic logic_ret,  // logic on the retention supply
  input  logic ram_on,
  input  logic ram_ret,

  // ---- The PCSM's retention save/restore control ----
  //
  // THE SAME SIGNAL src/upf/ppu_pd_top.upf NAMES, and that is the entire point
  // of it being a port rather than something inferred here:
  //
  //   set_retention RET_DEV_LOGIC ... -save_signal    {u_pcsm/ret_n negedge}
  //                                   -restore_signal {u_pcsm/ret_n posedge}
  //
  // This model used to derive its save from logic_ret's RISING EDGE instead --
  // a different signal, one cycle apart, and always on a powered rail by
  // construction. So it could not see a save taken before the retention supply
  // arrived, which is exactly the defect ppu_pcsm had: ret_rail decoded
  // ret_state and therefore lagged it, putting the save one cycle ahead of its
  // own supply. Five cycles of P-Channel synchronizer slack hid it until
  // PCSM_SYNC_EN was cleared, and then only the POWER-AWARE run failed.
  //
  // A model that stands in for the power intent has to agree with it about
  // when things happen, or it is not standing in for anything.
  input  logic ret_n,

  // ---- The switched domain's reset, as the domain actually sees it ----
  input  logic wl_rst_n,

  // ---- Modelled power state ----
  output logic corrupt,    // PD_DEV logic has no supply: -simstate CORRUPT
  output logic iso_clamp,  // isolation cells are clamping the boundary
  output logic ret_valid,  // a retention save is being held and is still good
  output logic do_save,    // 1-cycle: capture retained state now
  output logic do_restore, // 1-cycle: put retained state back now

  output int unsigned violations
);

  // ---------------------------------------------------------------------------
  // Supply state, straight from the PCSM's actuation
  // ---------------------------------------------------------------------------
  // Table 3-1's Logic column has three values and this is all three:
  //   ON / FUNC_RET / MEM_OFF   logic_on   -> full supply
  //   FULL_RET                  logic_ret  -> retention supply only
  //   MEM_RET / OFF             neither    -> unpowered
  wire pd_unpowered = !logic_on && !logic_ret;

  // Corruption applies only when the logic has NO supply at all. On the
  // retention supply the registers keep their values -- that is the entire
  // difference between FULL_RET and MEM_RET, and modelling it any other way
  // would erase the distinction this file exists to expose.
  //
  // REGISTERED, NOT COMBINATIONAL, and that is not a stylistic preference.
  // logic_on and logic_ret are separate continuous assigns off the same PCSM
  // state, so on ON -> FULL_RET they settle in different delta cycles: for one
  // delta logic_on has already fallen while logic_ret has not yet risen, and
  // pd_unpowered pulses HIGH. Nothing in the design can see a delta-width
  // transient, but a testbench force/release block reacting to level changes
  // absolutely can -- it latched that glitch, corrupted a domain that was
  // moving to the retention supply, and left busy at X with no clock to
  // re-drive it. The device then never reported itself idle again and the next
  // quiescence request hung.
  //
  // A power switch does not respond to a delta either, so sampling on the PPU
  // clock is both the fix and the more faithful model.
  logic corrupt_q;
  always_ff @(posedge clk or negedge rst_n) begin
    // Reset value 1: the PCSM reports OFF at reset release, so the domain
    // genuinely starts with no supply.
    if (!rst_n) corrupt_q <= 1'b1;
    else        corrupt_q <= pd_unpowered;
  end
  assign corrupt = corrupt_q;

  // The isolation cell is active while DEVISOLATEn is LOW. Sense and polarity
  // match set_isolation's -isolation_signal / -isolation_sense low.
  assign iso_clamp = !dev_isolaten;

  // ---------------------------------------------------------------------------
  // Retention
  // ---------------------------------------------------------------------------
  // The save point is entry to the retention supply -- the last moment the
  // state is still valid. The restore point is the release of the domain's
  // reset, NOT the return of the supply, and that distinction is the whole
  // subtlety of modelling retention here:
  //
  //   ppu_pd_top drives the workload's reset from DEVPORESETn & DEVWARMRESETn,
  //   and FULL_RET asserts DEVWARMRESETn (Table 4-9). So on the way out of
  //   FULL_RET the workload is RESET before it runs again. Restoring when the
  //   supply returns would put the saved values back and then let the reset
  //   wipe them.
  //
  //   Real retention flops are not reset by a warm reset -- that is exactly
  //   why DEVRETRESETn exists as a separate signal (Table 4-8: "warm reset for
  //   retention registers"). Restoring on reset release models a retained flop
  //   emerging from reset still holding its value, which is what the hardware
  //   does and what set_retention describes.
  logic ret_valid_q, ret_armed_q;
  logic logic_ret_d, wl_rst_n_d, ret_n_d;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ret_valid_q <= 1'b0;
      ret_armed_q <= 1'b0;
      logic_ret_d <= 1'b0;
      ret_n_d     <= 1'b1;   // ret_n is HIGH out of reset: no save outstanding
      wl_rst_n_d  <= 1'b0;
      do_save     <= 1'b0;
      do_restore  <= 1'b0;
    end else begin
      do_save     <= 1'b0;
      do_restore  <= 1'b0;
      logic_ret_d <= logic_ret;
      wl_rst_n_d  <= wl_rst_n;

      ret_n_d <= ret_n;

      // ---- do_save fires on logic_ret's RISE, not on ret_n's fall ----
      //
      // Those are one cycle apart and the difference is deliberate, because
      // do_save and PU9 are doing different jobs.
      //
      // do_save drives a SHADOW COPY in the testbench, which reads
      // u_ip/u_ret.sig hierarchically. That read has to happen while the domain
      // is unambiguously alive. Moving it onto ret_n put it one cycle later --
      // the same edge the logic supply drops -- and under UPF it started
      // capturing a corrupted value: ppu_pd_tb P23 and P23a, with every other
      // check in the phase still passing.
      //
      // PU9 and PU10 below read ret_n directly, because THEY are about the
      // edges src/upf/ppu_pd_top.upf actually uses:
      //
      //   -save_signal {u_pcsm/ret_n negedge} -restore_signal {... posedge}
      //
      // That is the half this model was missing. It used to have no view of
      // ret_n at all, so a save taken before its own retention supply arrived
      // was invisible here and failed only in the power-aware run.
      if (logic_ret && !logic_ret_d) begin
        do_save     <= 1'b1;
        ret_valid_q <= 1'b1;
        ret_armed_q <= 1'b1;
      end

      // Losing the retention supply without going through a restore destroys
      // the saved state. This is what makes MEM_RET and OFF different from
      // FULL_RET in the model, and it is checked by the testbench: a burst
      // frozen into FULL_RET resumes, one frozen into OFF does not.
      if (pd_unpowered) begin
        ret_valid_q <= 1'b0;
        ret_armed_q <= 1'b0;
      end

      // Reset release with a live save pending: put it back.
      if (ret_armed_q && ret_valid_q && wl_rst_n && !wl_rst_n_d) begin
        do_restore  <= 1'b1;
        ret_armed_q <= 1'b0;
      end
    end
  end

  assign ret_valid = ret_valid_q;

  // ---------------------------------------------------------------------------
  // Power sequencing rules
  // ---------------------------------------------------------------------------
  int unsigned viol;
  assign violations = viol;

  logic logic_on_d, iso_d, clken_d, poresetn_d, warmresetn_d;

  // Any reset being asserted is enough to call the domain "held": FULL_RET
  // asserts DEVWARMRESETn while leaving DEVPORESETn HIGH (Table 4-9), so a
  // rule written against DEVPORESETn alone would fire spuriously there.
  wire dev_held = !dev_poresetn || !dev_warmresetn;

  // Per-rule tally. Deliberately internal rather than a port: the model is
  // instantiated in four testbenches and none of them needs this, while
  // ppu_pm_tb reads it hierarchically.
  //
  // It exists because the aggregate counter cannot show that an individual rule
  // is alive. The rules overlap heavily -- PU8's condition is not even reachable
  // without first tripping PU1 or PU4 -- so disabling one and re-running a fault
  // still produces violations from its neighbours, and a dead rule hides.
  int unsigned viol_rule [1:10];
  initial for (int i = 1; i <= 10; i++) viol_rule[i] = 0;

  task automatic flag_n(input int idx, input string rule, input string msg);
    begin
      viol_rule[idx] = viol_rule[idx] + 1;
      flag(rule, msg);
    end
  endtask

  task automatic flag(input string rule, input string msg);
    begin
      viol = viol + 1;
      $display("[%0t] PWR-VIOLATION %s: %s  {dev_clken=%0b dev_iso_n=%0b dev_pore_n=%0b dev_warm_n=%0b ret_n=%0b lgc_on=%0b lgc_ret=%0b}",
               $time, rule, msg, dev_clken, dev_isolaten, dev_poresetn,
               dev_warmresetn, dev_retresetn, logic_on, logic_ret);
    end
  endtask

  // Plain `always` rather than `always_ff`: this block reports through $display,
  // which no synthesis tool would accept inside an always_ff, and the block is
  // simulation-only collateral anyway.
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      viol         <= 0;
      logic_on_d   <= 1'b0;
      iso_d        <= 1'b0;
      clken_d      <= 1'b0;
      poresetn_d   <= 1'b0;
      warmresetn_d <= 1'b0;
    end else begin
      // ---- Removing the supply ----
      if (logic_on_d && !logic_on) begin
        if (dev_isolaten) flag_n(1, "PU1", "logic supply removed with isolation inactive");
        if (dev_clken)    flag_n(2, "PU2", "logic supply removed with the clock still enabled");
        if (!dev_held)   flag_n(3, "PU3", "logic supply removed with the domain not in reset");
      end

      // ---- Releasing isolation ----
      if (!iso_d && dev_isolaten) begin
        if (!logic_on) flag_n(4, "PU4", "isolation released before the supply returned");
      end

      // ---- Enabling the clock ----
      if (!clken_d && dev_clken) begin
        if (!logic_on) flag_n(5, "PU5", "clock enabled with no logic supply");
      end

      // ---- Releasing reset ----
      // Checked on release only. Assertion is always safe, and WARM_RST
      // legitimately asserts DEVWARMRESETn with the supply and clock both on.
      if ((!poresetn_d && dev_poresetn) || (!warmresetn_d && dev_warmresetn)) begin
        if (!logic_on) flag_n(6, "PU6", "reset released with no logic supply");
        if (!dev_clken) flag_n(6, "PU6", "reset released with the clock disabled");
      end

      // ---- PU7: the retention rail must MAKE BEFORE BREAK ----
      // This rule used to read "if (logic_on && logic_ret)" -- the two supplies
      // must never be on together. That was accidentally true rather than
      // correct: logic_on and logic_ret were mutually-exclusive decodes of the
      // same mode, so the rule restated the decode instead of checking a
      // hazard, and it never fired.
      //
      // It is also the wrong requirement. The two switches take the same VIN
      // and drive separate output nets, so both closed is electrically
      // harmless -- and an overlap is not merely allowed, it is MANDATORY.
      // Going from "primary on, retention off" to "primary off, retention on"
      // admits exactly two orderings: an overlap where both are briefly on, or
      // a gap where both are briefly off. The gap destroys the retained state,
      // because the retention cells lose their own supply in it.
      //
      // That gap is not hypothetical. It is what the design did until the PCSM
      // was changed to widen logic_ret: both controls were continuous
      // assignments off cur_state, they settled in different delta cycles, and
      // FULL_RET silently behaved exactly like MEM_RET. The old PU7 could not
      // see it -- the broken ordering is one where the two are never on
      // together, so the rule was satisfied by the bug.
      //
      // So PU7 now checks the ordering it should always have checked, and it
      // fires on the old behaviour: a retention rail that rises in the same
      // step the primary falls has not led it.
      if (logic_on_d && !logic_on && logic_ret && !logic_ret_d)
        flag_n(7, "PU7", "retention supply rose as the primary fell -- no make-before-break");
      if (!logic_on_d && logic_on && !logic_ret && logic_ret_d)
        flag_n(7, "PU7", "retention supply fell as the primary returned -- no break-after-make");
      if (pd_unpowered && dev_isolaten)
        flag_n(8, "PU8", "domain unpowered with isolation inactive -- X can escape");

      // ---- PU9 / PU10: the save and the restore need a supply too ----
      //
      // PU7 checks the retention RAIL against the primary one. These two check
      // the SAVE and RESTORE EDGES against the rails they need, which is a
      // different question and the one nothing was asking.
      //
      // PU9 is "a save with no retention supply", in full. It was narrowed once,
      // to the retention supply arriving AFTER the save, because ppu_pcsm used
      // to save on MEM_RET and OFF too and lose it with the rail: the full form
      // fired 49 times in a single ppu_pd_tb run. Table 3-1 gives both modes
      // Logic Mode OFF, and ppu_pcsm no longer saves for them (pmu/README.md
      // 10.2 finding 3), so the full rule is the right one again -- and it
      // still catches the ordering defect the narrow one was written for,
      // at the save itself instead of a cycle later.
      //
      // That defect is what ppu_pcsm had for as long as it existed. ret_rail
      // decoded ret_state and so lagged it by a cycle, putting the save one
      // cycle ahead of its own supply. It only failed once the P-Channel
      // synchronizers stopped donating five cycles of slack, and then only
      // under UPF -- because this model derived its save from logic_ret rather
      // than ret_n and structurally could not see it.
      //
      // PU10's window is wider: AMBA has nothing to say here, but a restore
      // into registers with no supply puts back a value nothing can hold.
      if (!ret_n && ret_n_d && !logic_ret)
        flag_n(9, "PU9", "retention save taken with no retention supply");
      //
      // ret_valid_q qualifies it, and it has to. ppu_rstflight_tb asserts
      // aon_rst_n mid-transition, which sends ppu_pcsm's ret_n back HIGH with
      // the domain still unpowered -- a reset, not a restore, with nothing
      // being put back because the save was abandoned with the rail. Three of
      // those in that suite, against correct RTL. A ret_n rise with no live
      // save restores nothing and is not this rule's business.
      // logic_ret narrows it to the shape that is actually a defect: a restore
      // while the domain is still on the RETENTION rail only, i.e. before the
      // main supply came back. With both rails down the domain is unpowered,
      // the save died with the rail, and a ret_n rise there is reset behaviour
      // rather than a restore -- which is exactly what ppu_rstflight_tb
      // produces three times per run against correct RTL.
      if (ret_n && !ret_n_d && ret_valid_q && !logic_on && logic_ret)
        flag_n(10, "PU10", "retention restore before the logic supply returned");

      logic_on_d   <= logic_on;
      iso_d        <= dev_isolaten;
      clken_d      <= dev_clken;
      poresetn_d   <= dev_poresetn;
      warmresetn_d <= dev_warmresetn;
    end
  end

endmodule
