`timescale 1ns/1ps
// PPU coverage collector -- Table 4-14 transition pairs and Chapter 5 events.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Section 3.3.2 "Q-Channel PPU Power Mode Transitions",
// Table 4-14 "Power mode transition types", Tables 5-15 and 5-16.
//
// WHY THIS EXISTS
//
// tb/ppu/TEST_MATRIX.md has a "Mode coverage" table asserting that all seven
// modes are entered, and P26 tallies how many times each mode was requested.
// Both are about MODES. Neither is about TRANSITIONS, and the specification
// defines transitions as a matrix -- Table 4-14 is a list of (start, end) pairs,
// not a list of destinations.
//
// The difference is not academic. "Every mode was entered" is satisfied by a
// testbench that only ever goes ON -> X -> ON, and that is exactly the shape of
// most of the phases. The direct OFF -> MEM_RET hop is a different pair with a
// different sequence -- no device handshake at all -- and a suite could enter
// both OFF and MEM_RET many times without ever taking it.
//
// So this module measures the matrix instead of asserting it in a markdown
// table that no simulation reads.
//
// WHICH PAIRS ARE REACHABLE, AND WHY THAT IS SMALLER THAN TABLE 4-14
//
// Table 4-14 covers both PPU types. Reading it alone suggests this PPU is
// missing four transitions -- OFF -> MEM_OFF, MEM_OFF -> OFF, FULL_RET ->
// FUNC_RET and FUNC_RET -> FULL_RET -- because it lists them as allowed.
//
// Section 3.3.2 is what settles it, and it is worth quoting because the
// discrepancy is the kind a reviewer will hit:
//
//   "Although multiple power modes are supported with a Q-Channel PPU it only
//    transitions between ON and the power mode programmed in the PPU_PWPR
//    register. The only exceptions to this are transitions which do not perform
//    a device interface Q-Channel handshake, these transitions are: ...
//    From OFF to MEM_RET. ..."
//
// So on a Q-Channel PPU those four pairs route through ON, and the reachable set
// is ON-anchored plus the single direct hop:
//
//   ON -> each of the six other modes          6
//   each of the six other modes -> ON          6
//   OFF -> MEM_RET, direct and one-way         1
//                                             --
//                                             13
//
// MEM_RET -> OFF is deliberately absent: Table 4-14 gives MEM_RET exactly one
// end mode, ON. The hop is one-way, and a collector that expected 14 pairs would
// be demanding a transition the specification does not allow.
//
// WHAT IT DOES NOT DO
//
// It measures reachability of pairs and events, not correctness of either -- the
// checkers do that. A pair being covered says the suite went that way, not that
// it went that way properly. Its value is the negative case: an uncovered pair
// is a route nothing has ever taken, and no amount of passing checks says
// anything about it.

module ppu_coverage #(
  parameter bit OFF_MEM_RET_TRANS = 1'b1
) (
  input logic clk,
  input logic rst_n,
  input logic [3:0] pwr_status,

  // Event pulses, taken at their source in the sequencer rather than from
  // PPU_ISR. A masked event never sets its status bit -- that is the whole point
  // of the mask -- so counting status bits would report an event as uncovered
  // precisely when the suite had deliberately masked it.
  input logic ev_sta_policy_trn,
  input logic ev_sta_accept,
  input logic ev_sta_deny,
  input logic ev_locked,
  input logic ev_dyn_accept,
  input logic ev_dyn_deny,
  input logic ev_unspt_policy
);

  import ppu_pkg::*;

  localparam int N_MODE = 7;

  // Dense index for the sparse mode encoding (0, 2, 5, 6, 7, 8, 9).
  function automatic int mode_idx(input logic [3:0] m);
    case (m)
      PM_OFF:      return 0;
      PM_MEM_RET:  return 1;
      PM_FULL_RET: return 2;
      PM_MEM_OFF:  return 3;
      PM_FUNC_RET: return 4;
      PM_ON:       return 5;
      PM_WARM_RST: return 6;
      default:     return -1;
    endcase
  endfunction

  function automatic string idx_name(input int i);
    case (i)
      0: return "OFF";
      1: return "MEM_RET";
      2: return "FULL_RET";
      3: return "MEM_OFF";
      4: return "FUNC_RET";
      5: return "ON";
      6: return "WARM_RST";
      default: return "?";
    endcase
  endfunction

  // Is (f -> t) a pair this PPU is allowed to take? Written as a rule rather
  // than a table so that it states Section 3.3.2 directly.
  function automatic bit pair_reachable(input int f, input int t);
    if (f == t) return 1'b0;
    if (f == 5 || t == 5) return 1'b1;                       // ON-anchored
    if (OFF_MEM_RET_TRANS && f == 0 && t == 1) return 1'b1;  // the one exception
    return 1'b0;
  endfunction

  int  pair_hits [N_MODE][N_MODE];
  int  ev_hits   [7];
  logic [3:0] prev_mode;
  bit   have_prev;

  localparam int EV_STA_POLICY_TRN = 0;
  localparam int EV_STA_ACCEPT     = 1;
  localparam int EV_STA_DENY       = 2;
  localparam int EV_LOCKED         = 3;
  localparam int EV_DYN_ACCEPT     = 4;
  localparam int EV_DYN_DENY       = 5;
  localparam int EV_UNSPT_POLICY   = 6;

  function automatic string ev_name(input int i);
    case (i)
      0: return "STA_POLICY_TRN";
      1: return "STA_ACCEPT";
      2: return "STA_DENY";
      3: return "LOCKED";
      4: return "DYN_ACCEPT";
      5: return "DYN_DENY";
      6: return "UNSPT_POLICY";
      default: return "?";
    endcase
  endfunction

  initial begin
    int i, j;
    for (i = 0; i < N_MODE; i++)
      for (j = 0; j < N_MODE; j++) pair_hits[i][j] = 0;
    for (i = 0; i < 7; i++) ev_hits[i] = 0;
    have_prev = 1'b0;
  end

  // A pair is recorded on every change of PWR_STATUS. Intermediate hops of an
  // ON-anchored route therefore register as two pairs -- OFF -> ON and then
  // ON -> MEM_RET -- which is correct: those are the transitions that actually
  // happened, and the route is the pair of them.
  always @(posedge clk) begin
    if (!rst_n) begin
      have_prev <= 1'b0;
    end else begin
      if (!have_prev) begin
        prev_mode <= pwr_status;
        have_prev <= 1'b1;
      end else if (pwr_status !== prev_mode) begin
        if (mode_idx(prev_mode) >= 0 && mode_idx(pwr_status) >= 0)
          pair_hits[mode_idx(prev_mode)][mode_idx(pwr_status)]++;
        prev_mode <= pwr_status;
      end

      if (ev_sta_policy_trn) ev_hits[EV_STA_POLICY_TRN]++;
      if (ev_sta_accept)     ev_hits[EV_STA_ACCEPT]++;
      if (ev_sta_deny)       ev_hits[EV_STA_DENY]++;
      if (ev_locked)         ev_hits[EV_LOCKED]++;
      if (ev_dyn_accept)     ev_hits[EV_DYN_ACCEPT]++;
      if (ev_dyn_deny)       ev_hits[EV_DYN_DENY]++;
      if (ev_unspt_policy)   ev_hits[EV_UNSPT_POLICY]++;
    end
  end

  // ---------------------------------------------------------------------------
  // Reporting
  // ---------------------------------------------------------------------------
  int n_reachable, n_covered, n_illegal, n_ev_covered;

  task automatic report(output int holes);
    int i, j;
    string row;
    begin
      n_reachable = 0; n_covered = 0; n_illegal = 0; n_ev_covered = 0;

      $display("");
      $display("==============================================================");
      $display(" Transition-pair coverage (Table 4-14 as narrowed by 3.3.2)");
      $display("==============================================================");
      $display("   rows = start mode, columns = end mode");
      $display("   .  unreachable on a Q-Channel PPU     -  reachable, NOT taken");
      $display("");

      row = "                 ";
      for (j = 0; j < N_MODE; j++) row = {row, $sformatf("%-9s", idx_name(j))};
      $display("%0s", row);

      for (i = 0; i < N_MODE; i++) begin
        row = $sformatf("   %-14s", idx_name(i));
        for (j = 0; j < N_MODE; j++) begin
          if (!pair_reachable(i, j)) begin
            // An unreachable pair that was nevertheless taken is a finding, not
            // a coverage hole -- the PPU went somewhere the spec does not allow.
            if (pair_hits[i][j] > 0) begin
              row = {row, $sformatf("%-9s", $sformatf("!%0d", pair_hits[i][j]))};
              n_illegal++;
            end else begin
              row = {row, $sformatf("%-9s", ".")};
            end
          end else begin
            n_reachable++;
            if (pair_hits[i][j] > 0) begin
              n_covered++;
              row = {row, $sformatf("%-9d", pair_hits[i][j])};
            end else begin
              row = {row, $sformatf("%-9s", "-")};
            end
          end
        end
        $display("%0s", row);
      end

      $display("");
      $display("   reachable pairs %0d, covered %0d, uncovered %0d",
               n_reachable, n_covered, n_reachable - n_covered);
      if (n_illegal > 0)
        $display("   *** %0d ILLEGAL pair(s) taken -- marked ! above ***", n_illegal);

      $display("");
      $display(" Interrupt event coverage (Tables 5-15, 5-16)");
      for (i = 0; i < 7; i++) begin
        if (ev_hits[i] > 0) n_ev_covered++;
        $display("   %-16s %0d", ev_name(i), ev_hits[i]);
      end
      $display("   events covered %0d of 7", n_ev_covered);
      $display("==============================================================");

      holes = (n_reachable - n_covered) + n_illegal + (7 - n_ev_covered);
    end
  endtask

endmodule
