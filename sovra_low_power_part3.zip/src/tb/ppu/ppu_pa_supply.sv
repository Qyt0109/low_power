//=============================================================================
// ppu_pa_supply.sv -- energises the testbench rails for power-aware simulation
//
// Compiled ONLY by the power-aware targets (make ppupa / ppupaall). It is not
// part of any "make ppu" build, and no testbench instantiates it.
//
//-----------------------------------------------------------------------------
// WHY THIS FILE EXISTS
//
// The UPF wrappers in src/upf used to end with
//
//     supply_on VDD_TB 0.90
//     supply_on VSS_TB 0.00
//
// which is an Accellera UPF 1.0 command. It is not in IEEE 1801-2013, and
// Xcelium's 1801 reader rejects it outright:
//
//     *E,UPFERRM: [LPS] IEEE 1801 parsing error during parsing command
//                 (supply_on) ([1801_LINT_CMD1]: Unknown command.)
//
// -lps_relax_1801 does not help; the command is gone, not merely strict-moded.
// In 1801-2013 a supply net's state comes from its drivers, and the rail at the
// top of the bench has none by construction -- it is the board/PMIC supply, so
// there is nothing above it in the design to drive it.
//
// Xcelium's replacement is the $supply_on system task, which the Cadence
// "Low-Power Simulation with IEEE 1801 UPF" course uses for exactly this job
// (training/LPSUPF_22_09/sources/lab03-upf/power_on.v). It takes an ABSOLUTE
// hierarchical path to a UPF supply net, so this module is elaborated as a
// SECOND TOP alongside the testbench rather than instantiated inside it:
//
//     xrun ... -top ppu_be_tb -top ppu_pa_supply +define+PA_TOP=ppu_be_tb
//
// Being a separate top is also what keeps it out of "make ppu": $supply_on is
// a Xcelium built-in, and Icarus and xsim would reject the call. No testbench
// source is touched, so every PPU testbench runs unmodified under all three
// simulators AND under power-aware simulation.
//
//-----------------------------------------------------------------------------
// WHY THE TOP NAME IS A `define AND NOT A PARAMETER OR A PLUSARG
//
// Because $supply_on's path argument has to be resolvable at elaboration.
// Both of the obvious ways to make one file serve eight testbenches were tried
// and both fail, in ways worth recording so they are not tried again:
//
//   +patop=<top> read with $value$plusargs
//       *E,SARGBAD1: [LPS] The second argument to $supply_on is not a reg or
//       a constant.
//       (The message names the wrong argument; the non-constant one is the
//       path. A string assigned a literal on the previous line works fine, so
//       the objection is specifically to a runtime-determined value.)
//
//   parameter string TOP, overridden with -defparam
//       *W,BDDSTR: Attempt to redefine value of parameter of type string
//       ppu_pa_supply.TOP - DEFPARAM ... - ignored.
//       So the override is dropped and the default silently used, which is
//       worse than failing.
//
// A macro is substituted by the preprocessor, so the path is a literal before
// the parser ever sees it. `" ... `" is the stringification operator, and it is
// legal only inside a macro DEFINITION -- hence PA_NET rather than writing it
// at the call site, which gives *E,UMINQT.
//
//-----------------------------------------------------------------------------
// WHY THE STATUS IS CHECKED
//
// $supply_on returns 1 if it found the net and 0 if it did not, and a 0 is
// otherwise SILENT -- no warning, no error. The run then proceeds with an
// unenergised rail, every domain corrupts at time zero, and the failure
// presents as hundreds of X-related check failures in the testbench rather than
// as "the supply path was wrong". That is the same class of silent-no-op the
// UPF cross-check (lint/ppu_upf_check.py) exists to catch on the UPF side, so
// it gets the same treatment here: name something real or stop.
//=============================================================================

`ifndef PA_TOP
  // Sensible default so the file is runnable standalone; every Makefile target
  // passes its own.
  `define PA_TOP ppu_pd_tb
`endif

`define PA_NET(n) `"`PA_TOP.n`"

module ppu_pa_supply;

  int ok_vdd, ok_vss;

  initial begin
    // 0.90 V is the single rail every domain in upf/ppu_pd_top.upf sits on --
    // the value its add_power_state supply expressions compare against. A
    // mismatch here does not error either; it leaves every supply set matching
    // no named state at all. These two numbers and section 6 of that file have
    // to agree.
    ok_vdd = $supply_on(`PA_NET(VDD_TB), 0.90);
    ok_vss = $supply_on(`PA_NET(VSS_TB), 0.00);

    if (ok_vdd !== 1 || ok_vss !== 1) begin
      $display("FATAL: ppu_pa_supply could not energise the bench rails.");
      $display("       %s -> %0d,  %s -> %0d  (1 = found, 0 = no such net)",
               `PA_NET(VDD_TB), ok_vdd, `PA_NET(VSS_TB), ok_vss);
      $display("       PA_TOP is `PA_TOP -- it must name the testbench module");
      $display("       whose UPF wrapper creates VDD_TB/VSS_TB at its scope.");
      $fatal(1);
    end
  end

endmodule
