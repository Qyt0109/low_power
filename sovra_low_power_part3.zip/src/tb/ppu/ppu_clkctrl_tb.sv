`timescale 1ns/1ps
// ppu_clk_ctrl, checked statement by statement against the specifications.
//
// References, and which document owns which claim:
//
//   AMBA Low Power Interface Specification (ARM IHI 0068C)
//     Section 2.1.2  Q_STOPPED "is the only state where the controller does
//                    not guarantee the availability of any clock or power
//                    supply that is managed by the interface"; Q_EXIT's
//                    "Any clock or power supply managed by the interface is
//                    guaranteed after an implementation-dependent delay";
//                    the device-reset values of QACCEPTn and QDENY
//     Section 3.1    "Only remove clock or power when the interface is in the
//                    Q_STOPPED state"
//     Section 4.1.2  "the solution must retain dedicated and independent
//                    handshake interfaces between each device and the
//                    controller or combining functional block"
//     Section 4.1.3  the QACTIVE-only device
//
//   Arm CoreLink PCK-600 TRM (101150)
//     Section 3.5    "uses the Q-Channels to ensure that the devices are in a
//                    quiescent state before it gates the clock"; "ensures that
//                    the clock is running, before it allows a device to exit
//                    the quiescent state"; "When all the Q-Channels are in the
//                    quiescent state, the CLK-CTRL sets clken_o LOW"; "When
//                    any clk_qactive_i goes HIGH, the CLK-CTRL enables the
//                    clock and moves all the device Q-Channels to the running
//                    state"; the 0-255 cycle entry hysteresis; clk_force_i
//     Table 3-7      the configuration parameters
//     Tables A-22..A-26  the signals
//
// ORGANISED BY STATEMENT, NOT BY SCENARIO
//
// Same convention as ppu_devif_tb: each group below quotes one normative
// sentence and checks that sentence. "Is claim X covered?" is then answerable
// by grep, which a scenario-organised file cannot answer at all.
//
// THE DEVICE MODELS ARE qchannel_device_comb, AND THAT IS NOT LAZINESS
//
// A clock-control Q-Channel device CANNOT have a registered QACTIVE: the clock
// that would register it is the clock it is asking for, so once the controller
// gates, a flopped QACTIVE is frozen LOW forever and the domain never wakes.
// qchannel_device -- this repository's general-purpose device FSM -- registers
// QACTIVE, correctly, because it was written for power control where the clock
// survives Q_STOPPED. Using it here would deadlock every wake test in this
// file, which is why qchannel_device_comb exists and why it is what hangs off these
// four channels.
//
// The devices run on the GATED clock, not on clk. That is the whole point:
// a testbench whose device models keep clocking while the DUT thinks it has
// stopped them proves nothing about the ordering rules in K2 and K3.
//
// TWO DUTs
//
// u_dut is the interesting configuration: four handshaking devices, two
// QACTIVE-only devices, every synchronizer present, ACTIVE_DENY_EN set.
//
// u_min is every Table 3-7 boolean CLEARED and the array parameters at their
// minimum -- one channel, no QACTIVE-only device, no synchronizers anywhere,
// ACTIVE_DENY_EN off. Without it the false arm of six parameters would be dead
// code that elaborates and is never executed, which is the gap ppu_minconfig_tb
// exists to close on the PPU side. Group M1 is the one place the two DUTs are
// given identical stimulus and are REQUIRED to disagree.

module ppu_clkctrl_tb;

  import qchannel_pkg::*;

  localparam int unsigned NCH  = 4;             // NUM_Q_CHL
  localparam int unsigned NAO  = 2;             // NUM_QACTIVE_ONLY
  localparam int unsigned NACT = NCH + NAO;

  logic clk = 1'b0;
  always #5 clk = ~clk;

  logic reset_n = 1'b0;

  // ---- Upstream channels, driven by this file ----
  logic hc_qreqn  = 1'b1, pwr_qreqn = 1'b1;
  logic hc_qacceptn, hc_qdeny, hc_qactive;
  logic pwr_qacceptn, pwr_qdeny, pwr_qactive;

  // ---- Downstream channels, between the DUT and the device models ----
  logic [NCH-1:0] qreqn, qacceptn, qdeny, dev_qactive;

  // ---- Device-internal stimulus, one set per device model ----
  logic [NCH-1:0] need     = '0;   // "this device needs the clock" -> QACTIVE
  logic [NCH-1:0] dev_deny = '0;   // "refuse the next request"
  logic [NCH-1:0] dev_busy = '0;   // "will accept, but not yet"

  // ---- The QACTIVE-only devices (LPI Section 4.1.3): a veto, no handshake ----
  logic [NAO-1:0] qonly = '0;

  wire [NACT-1:0] qactive = {qonly, dev_qactive};

  // ---- Table A-25 / A-26 ----
  logic       clken;
  logic       clk_force = 1'b0;
  logic       dftcgen   = 1'b0;
  logic [7:0] entry_delay = 8'h00;

  // ---------------------------------------------------------------------------
  // The gate, and the clock the devices actually run on
  // ---------------------------------------------------------------------------
  logic dev_clk;

  clk_gate u_gate (
    .clk      (clk),
    .clk_en   (clken),
    .gated_clk(dev_clk)
  );

  // Compared against 1 rather than inverted, for the reason recorded in
  // ppu_pd_tb and qchannel_pd_tb: an X on en_latch inverts to X, and in Verilog
  // x->1 is a posedge, which fires qchannel_monitor's R10 spuriously. Resolving
  // X to "gated" is the truthful reading.
  wire clk_is_gated = (u_gate.en_latch !== 1'b1);

  // ---------------------------------------------------------------------------
  // The DUT
  // ---------------------------------------------------------------------------
  ppu_clk_ctrl #(
    .NUM_Q_CHL       (NCH),
    .NUM_QACTIVE_ONLY(NAO),
    .HC_Q_CH_SYNC    (1'b1),
    .PWR_Q_CH_SYNC   (1'b1),
    .CLK_Q_CH_SYNC   (1'b1),
    .ACTIVE_DENY_EN  (1'b1),
    .CLK_QACTIVE_SYNC(1'b1),
    .SYNC_STAGES     (2)
  ) u_dut (
    .clk    (clk),
    .reset_n(reset_n),

    .hc_qreqn_i    (hc_qreqn),
    .hc_qacceptn_o (hc_qacceptn),
    .hc_qdeny_o    (hc_qdeny),
    .hc_qactive_o  (hc_qactive),

    .pwr_qreqn_i   (pwr_qreqn),
    .pwr_qacceptn_o(pwr_qacceptn),
    .pwr_qdeny_o   (pwr_qdeny),
    .pwr_qactive_o (pwr_qactive),

    .clk_qreqn_o   (qreqn),
    .clk_qacceptn_i(qacceptn),
    .clk_qdeny_i   (qdeny),
    .clk_qactive_i (qactive),

    .clken_o      (clken),
    .clk_force_i  (clk_force),
    .entry_delay_i(entry_delay),
    .dftcgen      (dftcgen)
  );

  // ---------------------------------------------------------------------------
  // The devices
  // ---------------------------------------------------------------------------
  generate
    for (genvar i = 0; i < NCH; i++) begin : g_dev
      qchannel_device_comb #(.Q_CH_SYNC(1'b1), .SYNC_STAGES(2)) u_d (
        .clk  (dev_clk),
        .rst_n(reset_n),

        .qreqn   (qreqn[i]),
        .qacceptn(qacceptn[i]),
        .qdeny   (qdeny[i]),
        .qactive (dev_qactive[i]),

        .dev_active(need[i]),
        .dev_deny  (dev_deny[i]),
        .dev_busy  (dev_busy[i]),

        .dev_quiescent_ok(),
        .q_requested     ()
      );
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Protocol monitors, one per channel
  //
  // Six of them, because the DUT owns six independent Q-Channels and the
  // handshake rules apply to each separately. All are clocked from the
  // free-running clk and reset from reset_n, per qchannel_monitor's own
  // requirement that its operating reset must not be gated by the domain it
  // watches -- otherwise the events R8/R9/R10 exist to see would wipe the
  // monitor's pipeline in the same instant.
  //
  // clk_gated is wired only on the four device channels: those are the ones
  // whose clock this block actually removes, and R10 is the executable form of
  // "only remove clock or power when the interface is in the Q_STOPPED state".
  // The two hierarchical channels manage the CLK-CTRL's own clk, which nothing
  // in this testbench gates, so theirs is tied LOW.
  // ---------------------------------------------------------------------------
  int unsigned viol [NCH];
  int unsigned viol_hc, viol_pwr;

  generate
    for (genvar m = 0; m < NCH; m++) begin : g_mon
      qchannel_monitor u_mon (
        .clk      (clk),
        .rst_n    (reset_n),
        .crst_n   (reset_n),
        .drst_n   (reset_n),
        .clk_gated(clk_is_gated),
        .qreqn    (qreqn[m]),
        .qacceptn (qacceptn[m]),
        .qdeny    (qdeny[m]),
        .violations(viol[m])
      );
    end
  endgenerate

  qchannel_monitor u_mon_hc (
    .clk(clk), .rst_n(reset_n), .crst_n(reset_n), .drst_n(reset_n),
    .clk_gated(1'b0),
    .qreqn(hc_qreqn), .qacceptn(hc_qacceptn), .qdeny(hc_qdeny),
    .violations(viol_hc)
  );

  qchannel_monitor u_mon_pwr (
    .clk(clk), .rst_n(reset_n), .crst_n(reset_n), .drst_n(reset_n),
    .clk_gated(1'b0),
    .qreqn(pwr_qreqn), .qacceptn(pwr_qacceptn), .qdeny(pwr_qdeny),
    .violations(viol_pwr)
  );

  // ---------------------------------------------------------------------------
  // The two continuous invariants
  //
  // These are the block's reason to exist, so they are watched on every cycle
  // of every group rather than demonstrated once in a scenario. A scenario can
  // only show that the ordering held in the case it drove; these hold the DUT
  // to it everywhere, including in the groups written to test something else.
  // ---------------------------------------------------------------------------

  // Two-deep pipelines, so a transition can be located BETWEEN two samples and
  // the companion signal read at the sample BEFORE it. One-deep would only
  // show that clken was HIGH by the time QREQn had risen, which a design that
  // moved both on the same edge would also satisfy.
  logic [NCH-1:0] qreqn_d1, qreqn_d2;
  logic           clken_d1, clken_d2;

  always @(posedge clk) begin
    qreqn_d1 <= qreqn;    qreqn_d2 <= qreqn_d1;
    clken_d1 <= clken;    clken_d2 <= clken_d1;
  end

  // K1. LPI Section 2.1.2 / 3.1: the clock may only be absent in Q_STOPPED.
  int gated_outside_stopped = 0;
  always @(posedge clk)
    if (reset_n && !clken)
      for (int i = 0; i < NCH; i++)
        if (qch_decode(qreqn[i], qacceptn[i], qdeny[i]) != Q_STOPPED)
          gated_outside_stopped++;

  // K2. LPI Section 2.1.2 Q_EXIT / PCK-600 Section 3.5: the clock is running
  // BEFORE a device is allowed to leave quiescence.
  int exit_before_clock = 0;
  always @(posedge clk)
    if (reset_n)
      for (int i = 0; i < NCH; i++)
        if (!qreqn_d2[i] && qreqn_d1[i] && !clken_d2)
          exit_before_clock++;

  // ---------------------------------------------------------------------------
  // The minimum configuration: every Table 3-7 boolean cleared
  // ---------------------------------------------------------------------------
  logic       min_qreqn, min_qacceptn, min_qdeny, min_qactive;
  logic       min_clken;
  logic       min_hc_qreqn = 1'b1;
  logic       min_hc_qacceptn, min_hc_qdeny, min_hc_qactive;
  logic       min_need = 1'b0;
  logic [7:0] min_entry_delay = 8'h00;

  ppu_clk_ctrl #(
    .NUM_Q_CHL       (1),
    .NUM_QACTIVE_ONLY(0),      // the minimum: no QACTIVE-only devices at all
    .HC_Q_CH_SYNC    (1'b0),
    .PWR_Q_CH_SYNC   (1'b0),
    .CLK_Q_CH_SYNC   (1'b0),
    .ACTIVE_DENY_EN  (1'b0),
    .CLK_QACTIVE_SYNC(1'b0),
    .SYNC_STAGES     (2)
  ) u_min (
    .clk    (clk),
    .reset_n(reset_n),

    .hc_qreqn_i    (min_hc_qreqn),
    .hc_qacceptn_o (min_hc_qacceptn),
    .hc_qdeny_o    (min_hc_qdeny),
    .hc_qactive_o  (min_hc_qactive),

    .pwr_qreqn_i   (1'b1),
    .pwr_qacceptn_o(),
    .pwr_qdeny_o   (),
    .pwr_qactive_o (),

    .clk_qreqn_o   (min_qreqn),
    .clk_qacceptn_i(min_qacceptn),
    .clk_qdeny_i   (min_qdeny),
    .clk_qactive_i (min_qactive),

    .clken_o      (min_clken),
    .clk_force_i  (1'b0),
    .entry_delay_i(min_entry_delay),
    .dftcgen      (1'b0)
  );

  // Its device runs on the free-running clock. With every synchronizer removed
  // the whole point of the configuration is that everything is synchronous to
  // clk, and gating this one would only re-introduce the crossing.
  qchannel_device_comb #(.Q_CH_SYNC(1'b0)) u_min_dev (
    .clk  (clk),
    .rst_n(reset_n),

    .qreqn   (min_qreqn),
    .qacceptn(min_qacceptn),
    .qdeny   (min_qdeny),
    .qactive (min_qactive),

    .dev_active(min_need),
    .dev_deny  (1'b0),        // never refuses: QACTIVE is its only voice
    .dev_busy  (1'b0),

    .dev_quiescent_ok(),
    .q_requested     ()
  );

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  function automatic qch_state_e ch(input int i);
    return qch_decode(qreqn[i], qacceptn[i], qdeny[i]);
  endfunction

  function automatic bit all_in(input qch_state_e s);
    all_in = 1'b1;
    for (int i = 0; i < NCH; i++) if (ch(i) != s) all_in = 1'b0;
  endfunction

  function automatic int count_in(input qch_state_e s);
    count_in = 0;
    for (int i = 0; i < NCH; i++) if (ch(i) == s) count_in++;
  endfunction

  task automatic settle(); repeat (400) @(posedge clk); endtask

  // A free-running cycle count, for the hysteresis measurements.
  int unsigned cyc = 0;
  always @(posedge clk) cyc++;

  // Bring everything to a known running state: no activity anywhere, no
  // upstream request, gating disabled. Used between groups so that one group's
  // leftovers cannot make the next one pass.
  task automatic quiesce_bench();
    begin
      hc_qreqn  = 1'b1;
      pwr_qreqn = 1'b1;
      clk_force = 1'b1;      // hold the clock on while things settle
      dftcgen   = 1'b0;
      need      = '1;        // everything active -> everything back to Q_RUN
      qonly     = '1;
      dev_deny  = '0;
      dev_busy  = '0;
      settle();
      clk_force = 1'b0;
      need      = '1;
      qonly     = '1;
      settle();
    end
  endtask

  // ---------------------------------------------------------------------------
  int  d0, d5, d20;
  int  qreqn_falls;
  bit  saw_denied;
  int  t0;

  initial begin
    $dumpfile("ppu_clkctrl_tb.vcd");
    $dumpvars(0, ppu_clkctrl_tb);

    $display("==============================================================");
    $display(" ppu_clkctrl_tb: CLK-CTRL, statement by statement");
    $display("   NUM_Q_CHL=%0d NUM_QACTIVE_ONLY=%0d, plus a minimum-config DUT",
             NCH, NAO);
    $display("==============================================================");

    // =========================================================================
    section("K0 reset (AMBA LPI Section 2.1.2 \"Device reset\")");
    // =========================================================================
    // "At reset assertion a device must drive both QACCEPTn and QDENY LOW."
    // The CLK-CTRL is a device on hc_* and pwr_*, so the rule applies to it.
    //
    // clken_o resets HIGH for the opposite reason: as a CONTROLLER it owes its
    // devices a clock, and Section 2.1.2's permitted reset exits both assume
    // the controller is in a position to honour the supply guarantee.
    repeat (4) @(posedge clk);
    ck(hc_qacceptn === 1'b0 && hc_qdeny === 1'b0,
       "hc_qacceptn_o and hc_qdeny_o are both LOW under reset");
    ck(pwr_qacceptn === 1'b0 && pwr_qdeny === 1'b0,
       "pwr_qacceptn_o and pwr_qdeny_o are both LOW under reset");
    ck(clken === 1'b1, "clken_o is HIGH under reset -- the clock is guaranteed");

    // The other half of the same paragraph, about the device channels this
    // block CONTROLS: "A controller can release a device from reset with
    // either: QREQn LOW, with the interface in Q_STOPPED state. QREQn HIGH,
    // with the interface in Q_EXIT state, provided any clock or power supply
    // guarantee is met." This block takes the first form, which is why every
    // clk_qreqn_o resets LOW.
    ck(qreqn === {NCH{1'b0}},
       "every clk_qreqn_o is LOW under reset -- reset is exited via Q_STOPPED");

    reset_n = 1'b1;
    settle();

    // And with nothing asking for the clock, the correct thing to do on the
    // first cycle out of reset is nothing: stay quiescent and stay gated. An
    // earlier version of this check expected Q_RUN and was simply wrong about
    // what a CLK-CTRL should do with an idle domain.
    ck(all_in(Q_STOPPED) && clken === 1'b0,
       "with no device asking, it stays quiescent out of reset rather than starting the clock");

    need[0] = 1'b1;
    settle();
    ck(clken === 1'b1 && all_in(Q_RUN),
       "and the first device to ask brings the whole domain up to Q_RUN");
    need[0] = 1'b0;

    // =========================================================================
    section("K1 PCK-600 3.5: all Q-Channels quiescent -> clken_o LOW");
    // =========================================================================
    // "When all the Q-Channels are in the quiescent state, the CLK-CTRL sets
    //  clken_o LOW, to stop the clock."
    need  = '0;
    qonly = '0;
    settle();
    ck(all_in(Q_STOPPED), "every device channel reached Q_STOPPED");
    ck(clken === 1'b0,    "and clken_o went LOW");
    ck(clk_is_gated,      "the gate is actually closed -- the devices' clock has stopped");

    // =========================================================================
    section("K2 PCK-600 3.5: any clk_qactive_i HIGH -> clock on, ALL running");
    // =========================================================================
    // "When any clk_qactive_i goes HIGH, the CLK-CTRL enables the clock and
    //  moves all the device Q-Channels to the running state."
    //
    // ONE device is made active. The claim is about ALL of them -- so a design
    // that woke only the channel that asked would fail here, and only here.
    need[2] = 1'b1;
    settle();
    ck(clken === 1'b1, "one device asking is enough to enable the clock");
    ck(all_in(Q_RUN),  "and ALL FOUR device channels returned to the running state");
    ck(count_in(Q_RUN) == NCH, "  ...none was left behind in Q_STOPPED");

    // =========================================================================
    section("K3 LPI 4.1.3: a QACTIVE-only device vetoes with no handshake");
    // =========================================================================
    // "One application for a device with only QACTIVE is in combination with
    //  the QACTIVE of another device that supports the handshake signals, to
    //  form an interface to a controller."
    //
    // Table A-24 makes clk_qactive_i NUM_Q_CHL + NUM_QACTIVE_ONLY bits wide for
    // this. The veto is the whole capability such a device has: it cannot be
    // requested, cannot accept and cannot deny.
    need  = '0;
    qonly = '0;
    settle();
    ck(clken === 1'b0, "setup: everything idle, the clock is gated");

    qonly[1] = 1'b1;     // the SECOND QACTIVE-only device, bit [NCH+1]
    settle();
    ck(clken === 1'b1,
       "a QACTIVE-only device raising QACTIVE ungated the clock on its own");
    ck(all_in(Q_RUN),
       "and moved every handshaking channel back to Q_RUN");

    qonly[1] = 1'b0;
    settle();
    ck(clken === 1'b0 && all_in(Q_STOPPED),
       "releasing it lets the domain gate again");

    // =========================================================================
    section("K4 Table A-25: 0-255 clk cycles of entry hysteresis");
    // =========================================================================
    // "You can apply 0-255 clk cycles of hysteresis to the quiescence entry, by
    //  altering the state of the entry_delay_i[7:0] configuration input."
    //
    // Measured as a DIFFERENCE, not an absolute. The absolute latency from
    // activity falling to QREQn falling also contains the QACTIVE synchronizer
    // and two registered outputs, none of which entry_delay_i controls; the
    // difference between two settings is exactly the hysteresis and nothing
    // else, so this holds the DUT to the spec's number rather than to this
    // implementation's pipeline.
    quiesce_bench();

    entry_delay = 8'd0;
    @(negedge clk); need = '0; qonly = '0; t0 = cyc;
    @(negedge qreqn[0]);  d0 = cyc - t0;
    settle();

    quiesce_bench();
    entry_delay = 8'd5;
    @(negedge clk); need = '0; qonly = '0; t0 = cyc;
    @(negedge qreqn[0]);  d5 = cyc - t0;
    settle();

    quiesce_bench();
    entry_delay = 8'd20;
    @(negedge clk); need = '0; qonly = '0; t0 = cyc;
    @(negedge qreqn[0]);  d20 = cyc - t0;
    settle();

    $display("      entry_delay 0 -> %0d cycles, 5 -> %0d, 20 -> %0d", d0, d5, d20);
    ck(d5  - d0 == 5,  $sformatf("entry_delay_i=5 adds exactly 5 clk cycles (%0d)",  d5  - d0));
    ck(d20 - d0 == 20, $sformatf("entry_delay_i=20 adds exactly 20 clk cycles (%0d)", d20 - d0));
    ck(d0 > 0, "and entry_delay_i=0 still takes a nonzero, bounded time (no zero-cycle path)");

    entry_delay = 8'd0;
    quiesce_bench();

    // =========================================================================
    section("K5 Table A-25: clk_force_i HIGH disables the gating mechanism");
    // =========================================================================
    // "You can disable the clock gating feature by setting clk_force_i HIGH."
    need  = '0;
    qonly = '0;
    settle();
    ck(clken === 1'b0, "setup: idle and gated");

    clk_force = 1'b1;
    settle();
    ck(clken === 1'b1, "clk_force_i HIGH re-enabled the clock");
    ck(all_in(Q_RUN),
       "and released the devices, rather than leaving them quiesced under a clock");

    clk_force = 1'b0;
    settle();
    ck(clken === 1'b0, "dropping clk_force_i lets it gate again");

    // =========================================================================
    section("K6 Table A-26: dftcgen holds the architectural gates open");
    // =========================================================================
    // "This signal enables the architectural clock gates, and ensures that the
    //  clk logic is active during DFT shift mode."
    //
    // It acts on the GATE only, not on the handshake: the interface staying in
    // Q_STOPPED while the clock runs is entirely legal -- Section 2.1.2 says
    // Q_STOPPED is where the clock is not GUARANTEED, not where it is
    // forbidden. That asymmetry is what distinguishes it from clk_force_i above
    // and is the reason both signals exist.
    ck(clken === 1'b0 && all_in(Q_STOPPED), "setup: idle, gated, all quiescent");
    dftcgen = 1'b1;
    settle();
    ck(clken === 1'b1,      "dftcgen HIGH forced clken_o HIGH");
    ck(all_in(Q_STOPPED),   "and left the handshake alone -- still Q_STOPPED");
    dftcgen = 1'b0;
    settle();
    ck(clken === 1'b0, "and clearing it gates again");

    // =========================================================================
    section("K7 LPI 4.1.2: dedicated, independent handshakes per device");
    // =========================================================================
    // "In all cases the solution must retain dedicated and independent
    //  handshake interfaces between each device and the controller or combining
    //  functional block. This is important as it ensures that performance
    //  limitations or potential deadlock scenarios can be avoided in cases
    //  where there are interdependencies between devices with a shared clock."
    //
    // Device 1 refuses; devices 0, 2 and 3 accept. Three things have to be true
    // at once, and each would fail a different wrong implementation:
    //
    //   * 0, 2 and 3 reach Q_STOPPED           -- one device's refusal must not
    //                                             stall the others' handshakes
    //   * 1 ends in Q_RUN, having gone through -- its own handshake completed
    //     Q_DENIED                                rather than being abandoned
    //   * clken_o stays HIGH                   -- LPI 2.1.2: a denied device
    //                                             "remains operational and the
    //                                             controller must guarantee any
    //                                             clock ... managed by the
    //                                             interface"
    quiesce_bench();
    dev_deny[1] = 1'b1;

    saw_denied  = 1'b0;
    fork
      begin : watch_deny
        forever begin
          @(posedge clk);
          if (ch(1) == Q_DENIED) saw_denied = 1'b1;
        end
      end
    join_none

    need  = '0;
    qonly = '0;
    settle();

    ck(ch(0) == Q_STOPPED && ch(2) == Q_STOPPED && ch(3) == Q_STOPPED,
       "devices 0, 2 and 3 completed their handshakes into Q_STOPPED");
    ck(saw_denied, "device 1's channel actually passed through Q_DENIED");
    ck(ch(1) == Q_RUN,
       "and finished the denied handshake back in Q_RUN, not stuck in Q_DENIED");
    ck(clken === 1'b1,
       "clken_o stayed HIGH: one refusal is enough to keep the whole domain clocked");

    // The denial latch and its backoff, checked by their observable consequence.
    //
    // BOTH BOUNDS MATTER, and this check originally had only one of them. It
    // asserted zero further requests -- "never re-ask" -- which is what the
    // block did before DENY_RETRY_DLY existed, and which is a LOCKOUT: a device
    // that refuses once and then becomes willing would never be asked again and
    // the clock gating would be silently dead. K15 catches that directly; this
    // group now brackets the retry RATE instead.
    //
    //   lower bound   it must retry at all, or K15's scenario cannot recover
    //   upper bound   it must not retry continuously, which is the thrash LPI
    //                 Section 4.1.2 calls a "performance limitation"
    //
    // With DENY_RETRY_DLY = 255 and roughly eight cycles of handshake, 2000
    // cycles allows about 2000/263 = 7 attempts. Unbounded thrash would be
    // nearer 250.
    qreqn_falls = 0;
    fork
      begin : count_falls
        forever begin
          @(negedge qreqn[1]);
          qreqn_falls++;
        end
      end
    join_none
    repeat (2000) @(posedge clk);
    ck(qreqn_falls > 0,
       $sformatf("it is asked again after the backoff (%0d attempts in 2000 cycles)",
                 qreqn_falls));
    ck(qreqn_falls <= 15,
       $sformatf("  ...but not continuously: %0d attempts, thrash would be ~250",
                 qreqn_falls));

    disable watch_deny;
    disable count_falls;

    dev_deny[1] = 1'b0;
    quiesce_bench();

    // =========================================================================
    section("K8 Table A-22: the hierarchical CLOCK control channel");
    // =========================================================================
    // "hc_qreqn_i ... indicates when the controller issues a quiescence entry
    //  or exit request to the CLK-CTRL."
    // "hc_qacceptn_o ... indicates when the CLK-CTRL accepts the quiescence
    //  request."
    //
    // The CLK-CTRL is the DEVICE here, and it may only accept once it has made
    // the statement true for the whole clock domain it owns. Checking that the
    // device channels are ALL quiescent AT THE MOMENT hc_qacceptn_o falls is
    // the part that matters: a design that accepted first and quiesced
    // afterwards would report the domain quiet while it was still running.
    need  = '0;
    qonly = '0;
    settle();
    ck(all_in(Q_STOPPED) && clken === 1'b0,
       "setup: the domain is idle and already gated");

    hc_qreqn = 1'b0;
    settle();
    ck(hc_qacceptn === 1'b0, "hc_qacceptn_o LOW: the CLK-CTRL accepted");
    ck(hc_qdeny === 1'b0,    "and did not deny");
    ck(all_in(Q_STOPPED),    "with every device channel quiescent at that point");

    hc_qreqn = 1'b1;
    settle();
    ck(hc_qacceptn === 1'b1, "hc_qacceptn_o HIGH completes the exit handshake");

    // ---- The same request, but arriving while the devices are RUNNING ----
    //
    // The case above starts from an already-gated domain, so the CLK-CTRL has
    // nothing to do before answering and a design that answered immediately
    // would look correct. This one gives it work first.
    //
    // clk_force_i is held HIGH for the whole sub-test, and it does two things
    // at once that make this the isolating case:
    //
    //   * it holds the devices in Q_RUN with no activity keeping them there,
    //     which is exactly the state in which "accept now, quiesce later" is
    //     possible and wrong
    //   * it suppresses the LOCAL entry policy, so the only thing that can push
    //     these devices down is the hierarchical request. Without that, an idle
    //     domain would gate itself and the group would pass without hc_* having
    //     done anything at all
    //
    // The clock stays on throughout, and that is not a flaw in the test: Table
    // A-25 makes clk_force_i disable the GATING MECHANISM, while what the
    // upstream controller asked for is QUIESCENCE. Section 2.1.2 lets those
    // differ -- Q_STOPPED is where the clock is not guaranteed, not where it is
    // forbidden.
    //
    // Checked on the EDGE, not after settling: a design that accepted early and
    // quiesced afterwards would satisfy any check taken once the dust settled.
    clk_force = 1'b1;
    need      = '0;
    qonly     = '0;
    settle();
    ck(all_in(Q_RUN) && clken === 1'b1,
       "setup: clk_force_i holds all four devices in Q_RUN with no activity");

    hc_qreqn = 1'b0;
    @(negedge hc_qacceptn);
    ck(all_in(Q_STOPPED),
       "at the instant hc_qacceptn_o fell, every device was ALREADY in Q_STOPPED");
    ck(clken === 1'b1,
       "and clk_force_i still held the clock on -- quiescence and gating are separate");

    // Withdrawing on the same delta as the acceptance would be an R2 violation
    // by the TESTBENCH: Section 2.1.2 only permits QREQn to rise out of
    // Q_STOPPED or Q_DENIED, and at that instant qchannel_monitor's registered
    // view of the interface is still Q_REQUEST. Let it land first.
    settle();
    hc_qreqn = 1'b1;
    settle();
    ck(hc_qacceptn === 1'b1, "and the exit handshake completes as before");
    ck(all_in(Q_RUN), "with every device released back to Q_RUN");
    clk_force = 1'b0;

    // =========================================================================
    section("K9 Table A-22: hc_qactive_o reports downstream activity");
    // =========================================================================
    // "hc_qactive_o ... indicates when one or more CLK-CTRL devices are active
    //  or they are requesting to exit from quiescence."
    //
    // Asynchronous, per the same table, and Table 3-7's note under
    // ACTIVE_DENY_EN puts it beyond doubt: "The path from a device to the
    // controller QACTIVE is combinatorial, irrespective of whether
    // synchronizers are present." So it must follow within the same cycle, not
    // after a synchronizer -- which is checked here by sampling it one cycle
    // after the stimulus, a window a two-flop synchronizer cannot meet.
    need  = '0;
    qonly = '0;
    settle();
    ck(hc_qactive === 1'b0 && pwr_qactive === 1'b0,
       "setup: no device active, both hierarchical QACTIVEs LOW");

    @(negedge clk);
    need[3] = 1'b1;
    @(posedge clk);
    ck(hc_qactive === 1'b1,
       "hc_qactive_o followed a device QACTIVE combinationally, within one cycle");
    ck(pwr_qactive === 1'b1, "and so did pwr_qactive_o");

    need[3] = 1'b0;
    settle();

    // =========================================================================
    section("K10 the upstream hold: an accepted request is not undone locally");
    // =========================================================================
    // Not a quoted sentence -- it is the consequence of two of them. Section
    // 2.1.2 says the controller drives the exit ("At T4 the controller drives
    // QREQn HIGH"), and Table A-22 gives the CLK-CTRL exactly one way to ask
    // for that exit: hc_qactive_o.
    //
    // So once the CLK-CTRL has told an upstream controller "quiescent", a
    // device going active must NOT unilaterally restart the domain -- the
    // upstream controller may already have acted on the acceptance, and in the
    // pwr_ case that means the power is going away. It raises QACTIVE and
    // waits. This is the group that would catch a CLK-CTRL that treated its
    // local activity policy as overriding.
    need  = '0;
    qonly = '0;
    settle();
    hc_qreqn = 1'b0;
    settle();
    ck(hc_qacceptn === 1'b0 && all_in(Q_STOPPED), "setup: accepted upstream, all quiescent");

    need[0] = 1'b1;
    settle();
    ck(all_in(Q_STOPPED),
       "a device going active did NOT release the device channels");
    ck(clken === 1'b0,
       "and did not ungate the clock: the upstream controller still holds it");
    ck(hc_qactive === 1'b1,
       "what it did instead is raise hc_qactive_o -- the only exit request it has");

    hc_qreqn = 1'b1;
    settle();
    ck(hc_qacceptn === 1'b1, "the upstream controller withdrawing completes the exit");
    ck(clken === 1'b1 && all_in(Q_RUN),
       "and only THEN does the domain restart");

    need[0] = 1'b0;
    quiesce_bench();

    // =========================================================================
    section("K11 Table A-22: a downstream refusal becomes hc_qdeny_o");
    // =========================================================================
    // "hc_qdeny_o ... indicates when the CLK-CTRL denies the quiescence
    //  request."
    //
    // The CLK-CTRL has no reason of its own to refuse -- it holds no state a
    // clock stop would damage. Every denial it issues is a device's denial
    // relayed upward, which is what makes this the interesting case: the
    // refusal has to survive being translated across two channels.
    dev_deny[2] = 1'b1;
    need  = '0;
    qonly = '0;
    settle();

    hc_qreqn = 1'b0;
    settle();
    ck(hc_qdeny === 1'b1,    "hc_qdeny_o HIGH: device 2's refusal reached the upstream channel");
    ck(hc_qacceptn === 1'b1, "and hc_qacceptn_o stayed HIGH -- Table 2-1 forbids both at once");
    ck(clken === 1'b1,       "with the clock still guaranteed throughout");

    hc_qreqn = 1'b1;
    settle();
    ck(hc_qdeny === 1'b0, "raising hc_qreqn_i completes the denied handshake (Q_CONTINUE -> Q_RUN)");

    dev_deny[2] = 1'b0;
    quiesce_bench();

    // =========================================================================
    section("K12 Table A-23: the hierarchical POWER control channel");
    // =========================================================================
    // Tables A-22 and A-23 are the same four signals with a different prefix,
    // and PCK-600 Section 3.5 lists them as two separate optional interfaces.
    // Two channels that were accidentally the same net, or one that was wired
    // and one that was not, would pass every group above; this runs the whole
    // sequence on pwr_* alone, with hc_* left parked in Q_RUN.
    need  = '0;
    qonly = '0;
    settle();
    ck(hc_qreqn === 1'b1, "setup: the clock channel is parked in Q_RUN");

    pwr_qreqn = 1'b0;
    settle();
    ck(pwr_qacceptn === 1'b0, "pwr_qacceptn_o LOW: accepted on the power channel");
    ck(hc_qacceptn === 1'b1,  "and the clock channel was not disturbed");
    ck(all_in(Q_STOPPED),     "with the whole domain quiescent");

    need[1] = 1'b1;
    settle();
    ck(all_in(Q_STOPPED) && pwr_qactive === 1'b1,
       "the same upstream hold applies: activity raises pwr_qactive_o and waits");

    pwr_qreqn = 1'b1;
    settle();
    ck(pwr_qacceptn === 1'b1 && clken === 1'b1,
       "and withdrawing the power request restarts the domain");

    need[1] = 1'b0;
    quiesce_bench();

    // =========================================================================
    section("M1 Table 3-7 ACTIVE_DENY_EN: the two DUTs must DISAGREE");
    // =========================================================================
    // "0 = Support for denying a quiescence request by using QACTIVE is not
    //  included.  1 = Support for denying a quiescence request using QACTIVE is
    //  included."
    //
    // Identical stimulus to both DUTs: a device holding QACTIVE HIGH, and an
    // upstream clock controller asking for quiescence. The device itself never
    // refuses -- QACTIVE is its only voice.
    //
    //   ACTIVE_DENY_EN=1 (u_dut)  QACTIVE alone is a refusal -> hc_qdeny_o
    //   ACTIVE_DENY_EN=0 (u_min)  QACTIVE alone is not -> the request is pushed
    //                             to the device, which accepts, and the domain
    //                             is quiesced despite being "active"
    //
    // If the two agreed, the parameter would be doing nothing and its false arm
    // would be dead code -- which is the whole reason u_min is elaborated.
    need     = '0;
    qonly    = '0;
    min_need = 1'b0;
    settle();

    need[0]  = 1'b1;
    min_need = 1'b1;
    settle();

    hc_qreqn     = 1'b0;
    min_hc_qreqn = 1'b0;
    settle();

    ck(hc_qdeny === 1'b1,
       "ACTIVE_DENY_EN=1: QACTIVE alone denied the hierarchical request");
    ck(min_hc_qdeny === 1'b0 && min_hc_qacceptn === 1'b0,
       "ACTIVE_DENY_EN=0: the same stimulus was ACCEPTED instead");
    ck(qch_decode(min_qreqn, min_qacceptn, min_qdeny) == Q_STOPPED,
       "  ...and the device was genuinely quiesced, QACTIVE notwithstanding");
    ck(min_clken === 1'b0,
       "  ...and its clock gated, which is what ACTIVE_DENY_EN=0 means");

    hc_qreqn     = 1'b1;
    min_hc_qreqn = 1'b1;
    settle();

    // =========================================================================
    section("M2 ACTIVE_DENY_EN=0 still respects QACTIVE for LOCAL entry");
    // =========================================================================
    // The parameter names one thing: denying a REQUEST. It says nothing about
    // the block's own activity-led gating policy, and PCK-600 Section 3.5
    // states that one unconditionally -- "When all the Q-Channels are in the
    // quiescent state, the CLK-CTRL sets clken_o LOW" and "When any
    // clk_qactive_i goes HIGH, the CLK-CTRL enables the clock".
    //
    // So with no upstream controller in the picture, u_min must behave exactly
    // like u_dut. Without this group, M1 would be equally satisfied by a DUT
    // that ignored QACTIVE altogether.
    ck(min_need === 1'b1, "setup: the minimum DUT's device is still active");
    ck(min_clken === 1'b1 && qch_decode(min_qreqn, min_qacceptn, min_qdeny) == Q_RUN,
       "with hc_qreqn_i withdrawn it runs, because its device says it is active");

    min_need = 1'b0;
    settle();
    ck(min_clken === 1'b0, "and gates the moment that activity stops");

    min_need = 1'b1;
    settle();
    ck(min_clken === 1'b1,
       "and ungates again on QACTIVE, with ACTIVE_DENY_EN=0 and no synchronizers anywhere");

    need = '0;
    min_need = 1'b0;
    quiesce_bench();

    // =========================================================================
    section("K15 a device that refuses and then relents is asked again");
    // =========================================================================
    // The defect DENY_RETRY_DLY exists to fix, as a scenario.
    //
    // deny_seen used to clear only when base_req fell, and base_req stays HIGH
    // for as long as the domain is idle -- which is exactly when gating is
    // wanted. So a device that denied once and then became willing was never
    // asked again: the channel stayed in Q_RUN, all_stopped was never true, and
    // clken_o stayed HIGH forever. No error, no violation, no symptom; the
    // clock gating simply stopped working.
    //
    // The crucial part of the stimulus is what is NOT touched. need and qonly
    // stay LOW throughout, so base_req never falls and nothing clears the latch
    // as a side effect. That is what let the old behaviour survive K7, whose
    // cleanup toggled activity and cleared deny_seen incidentally.
    quiesce_bench();
    dev_deny[2] = 1'b1;
    need        = '0;
    qonly       = '0;
    settle();
    ck(clken === 1'b1,
       "setup: device 2 is refusing, so the domain is idle but still clocked");
    ck(ch(2) != Q_STOPPED, "setup: and its channel is not quiescent");

    // It relents. Nothing else changes -- no activity, no upstream request.
    dev_deny[2] = 1'b0;
    settle();
    settle();

    ck(all_in(Q_STOPPED),
       "after the retry backoff every channel reached Q_STOPPED");
    ck(clken === 1'b0,
       "and the clock gated -- with the old latch this stayed HIGH forever");

    quiesce_bench();

    // =========================================================================
    section("K13 the two continuous invariants, over the whole run");
    // =========================================================================
    ck(gated_outside_stopped == 0,
       $sformatf("clken_o was never LOW with a channel outside Q_STOPPED (%0d violations) -- LPI 3.1",
                 gated_outside_stopped));
    ck(exit_before_clock == 0,
       $sformatf("no device was released before the clock was already running (%0d violations) -- LPI 2.1.2 Q_EXIT",
                 exit_before_clock));

    // =========================================================================
    section("K14 protocol conformance on all six channels");
    // =========================================================================
    // qchannel_monitor is the executable form of Section 2.1.2's six signalling
    // rules plus Table 2-1's illegal state. It has its own negative test
    // ("make ppuneg"), so a zero here is a result rather than an absence.
    for (int i = 0; i < NCH; i++)
      ck(viol[i] == 0,
         $sformatf("device channel %0d: %0d protocol violations", i, viol[i]));
    ck(viol_hc  == 0, $sformatf("hierarchical clock channel: %0d violations",  viol_hc));
    ck(viol_pwr == 0, $sformatf("hierarchical power channel: %0d violations", viol_pwr));

    // =========================================================================
    $display("");
    $display("==============================================================");
    $display(" ppu_clkctrl_tb: %0d checks, %0d error(s)", checks, errors);
    $display(" RESULT: %0s", (errors == 0) ? "PASS" : "FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    #4000000;
    $display("RESULT: FAIL");
    $fatal(1, "ppu_clkctrl_tb watchdog");
  end

endmodule
