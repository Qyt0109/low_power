`timescale 1ns/1ps
// ppu_pcsm_pgood_tb -- ppu_pcsm's switch and retention sequencing, against
// DEN 0051E Section 4.1.6, with modelled power switches.
//
// ppu_pcsm is driven by the PPU's own P-Channel controller in the
// configuration ppu_top uses inside ppu_pd_top (PCSM_SYNC_EN = 0, no
// synchronizers on the PCSM channel), or with +define+CTRL_SYNC2 the two
// stages ppu_lpd_pd_top keeps. Each of the two power switches is a delay line:
// its acknowledge, which is also its rail, follows its control d cycles later.
//
// The requirement is Section 4.1.6: "The power transition in the PCSM must
// happen between t1 and t4 in Figure 4-15, before the P-Channel transition is
// completed by the PCSM." Figure 4-15 puts t1 at PCSMPREQ rising and t4 at
// PCSMPACCEPT falling. For FULL_RET the transition includes retention: Table
// 3-1 gives FULL_RET Logic Mode RET, so the save is taken while the logic
// supply is on, onto a powered retention cell, and the restore after the
// logic supply is back.
//
// DIRECTED
//   A  ON -> FULL_RET: the save (ret_n falling) comes before the logic supply
//      goes and before the handshake completes (PCSMPACCEPT falling).
//   R  ...and after the retention switch has acknowledged.
//   S  FULL_RET -> ON: the restore (ret_n rising) comes after the logic switch
//      has acknowledged.
//   B  ON -> FULL_RET -> ON with no gap: the machine ends idle, ret_n HIGH, the
//      retention rail off.
//   Z  a reset with the domain ON, then ON at once: the power-up is not
//      accepted on the acknowledge of a switch still turning off (C4).
//   M  ON -> OFF -> ON and ON -> MEM_RET -> ON: Table 3-1 gives both Logic Mode
//      OFF, so no save, no restore and no retention rail.
//
// CONTINUOUS, every cycle of every scenario, including a random walk of the
// hops ppu_seq makes (ON <-> any mode, and the direct OFF -> MEM_RET)
//   C1 SAVE     ret_n falls only with both rails up
//   C2 HOLD     while ret_n is LOW the retention rail stays up
//   C3 RESTORE  ret_n rises only with both rails up
//   C4 LIVE     a completed handshake into a mode that keeps logic has the
//               logic rail up, and it stays up until the next request
//   C5 STRUCT   RET_ARM only while its retaining request is still pending, and
//               RET_SAVED never with a logic-keeping request pending
// and at PGOOD_EN = 1, where the PCSM has acknowledges to go by:
//   C6 DOWN     a completed handshake into a mode without logic has the logic
//               rail down
//   C7 RETOFF   a completed handshake into a mode without logic retention has
//               the retention rail down
// and one design invariant, stricter than Section 4.1.6:
//   C8 ORDER    the save and the restore are both done before PCSMPACCEPT
//               RISES. Section 4.1.6 only needs them before it falls, and
//               without the accept holds they still make that by the one
//               cycle the controller takes to react -- the kind of margin
//               finding 4(a) was. C8 pins the holds, so removing one is a
//               decision rather than an accident.
//
// At PGOOD_EN = 0 the PCSM has no acknowledge to wait for. It is correct for
// switches no slower than one cycle, or with RET_SETTLE / LOGIC_SETTLE at
// least as long as its switches. C6 and C7 need an acknowledge and are not
// checked there.
//
//   make ppupcsmpg SIM=vcs      every configuration, over a matrix of delays
//
// Plusargs: +d_on=<n> +d_ret=<n>, the switch delays in cycles (0 = the
// acknowledge is the control itself, as ppu_pd_top ties it when PGOOD_EN = 0);
// +iters=<n> random hops (default 300); +seed=<n>.
// Defines: +define+PGOOD0 builds PGOOD_EN = 0; +define+CTRL_SYNC2 the LPD
// channel; +define+RSET=<n> / +define+LSET=<n> set RET_SETTLE / LOGIC_SETTLE.
//
// It prints RESULT: PASS or RESULT: FAIL.

module ppu_pcsm_pgood_tb;
  import ppu_pkg::*;

`ifdef PGOOD0
  localparam bit PG = 1'b0;
`else
  localparam bit PG = 1'b1;
`endif
`ifdef CTRL_SYNC2
  localparam int unsigned CTRL_SYNC = 2;
`else
  localparam int unsigned CTRL_SYNC = 0;
`endif
`ifdef RSET
  localparam int unsigned RS = `RSET;
`else
  localparam int unsigned RS = 0;
`endif
`ifdef LSET
  localparam int unsigned LS = `LSET;
`else
  localparam int unsigned LS = 0;
`endif

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  int unsigned d_on = 4, d_ret = 30, iters = 300, seed = 1;

  // ---- The PPU's P-Channel controller, as ppu_top configures it ----
  logic [15:0] req_state = {8'h00, 4'h0, PM_OFF};
  logic        req_valid = 1'b0;
  logic [15:0] cur_state, pstate;
  logic        preq, paccept, init_done;

  pchannel_controller #(
    .PSTATE_W(16), .PACTIVE_W(1), .SYNC_STAGES(CTRL_SYNC), .PSTATE_LEAD_CYCLES(0),
    .RESET_STATE({8'h00, 4'h0, PM_OFF}), .TINIT_WAIT(16)
  ) u_ctrl (
    .clk(clk), .rst_n(rst_n),
    .pstate(pstate), .preq(preq), .paccept(paccept), .pdeny(1'b0), .pactive(1'b0),
    .req_state(req_state), .req_valid(req_valid), .enb_pactive_led_transition(1'b0),
    .cur_state(cur_state), .pactive_floor_state(), .dev_stable(),
    .ctrl_init_done(init_done), .xfer_done(), .xfer_denied()
  );

  // ---- The PCSM under test ----
  logic       ack_on, ack_ret, logic_on, logic_ret, ram_on, ram_ret, ret_n;
  logic [7:0] ram_cfg, ram_sleep, ram_sd, modestat;
  logic [3:0] pcsm_mode;

  ppu_pcsm #(
    .SYNC_STAGES(0), .TINIT(4), .RESET_MODESTAT(PM_OFF), .PGOOD_EN(PG),
    .RET_SETTLE(RS), .LOGIC_SETTLE(LS)
  ) u_pcsm (
    .clk(clk), .rst_n(rst_n),
    .pcsm_pstate(pstate), .pcsm_preq(preq), .pcsm_paccept(paccept),
    .ack_logic_on(ack_on), .ack_logic_ret(ack_ret),
    .logic_on(logic_on), .logic_ret(logic_ret), .ram_on(ram_on), .ram_ret(ram_ret),
    .ram_cfg(ram_cfg), .pcsm_mode(pcsm_mode), .ram_sleep(ram_sleep), .ram_sd(ram_sd),
    .ret_n(ret_n), .pcsm_modestat(modestat)
  );

  // ---- Two switches: each acknowledge -- and rail -- follows its control ----
  logic [127:0] on_h = '0, ret_h = '0;
  always @(posedge clk) begin
    on_h  <= {on_h[126:0], logic_on};
    ret_h <= {ret_h[126:0], logic_ret};
  end
  assign ack_on  = (d_on  == 0) ? logic_on  : on_h[d_on - 1];
  assign ack_ret = (d_ret == 0) ? logic_ret : ret_h[d_ret - 1];
  wire rail_logic = ack_on;
  wire rail_ret   = ack_ret;

  function automatic bit keeps_logic(input logic [3:0] m);
    return (m == PM_ON) || (m == PM_FUNC_RET) || (m == PM_MEM_OFF);
  endfunction
  function automatic bit retains_logic(input logic [3:0] m);   // Table 3-1 Logic Mode RET
    return (m == PM_FULL_RET) || (m == PM_LOGIC_RET);
  endfunction

  // ---- Event times for the directed checks, sampled on one edge ----
  longint unsigned cyc = 0;
  longint unsigned t_acc_fall, t_logic_off, t_save, t_ret_ack, t_restore, t_on_ack;
  logic pacc_d = 1'b0, lon_d = 1'b0, retn_d = 1'b1, aret_d = 1'b0, aon_d = 1'b0;
  always @(posedge clk) begin
    if (!paccept  &&  pacc_d) t_acc_fall  = cyc;
    if (!logic_on &&  lon_d)  t_logic_off = cyc;
    if (!ret_n    &&  retn_d) t_save      = cyc;
    if ( ret_n    && !retn_d) t_restore   = cyc;
    if ( ack_ret  && !aret_d) t_ret_ack   = cyc;
    if ( ack_on   && !aon_d)  t_on_ack    = cyc;
    pacc_d = paccept; lon_d = logic_on; retn_d = ret_n; aret_d = ack_ret; aon_d = ack_on;
    cyc++;
  end

  // ---- Continuous checks C1-C7 ----
  int unsigned c_viol [1:8];
  string       c_name [1:8] = '{"C1 SAVE", "C2 HOLD", "C3 RESTORE", "C4 LIVE",
                                "C5 STRUCT", "C6 DOWN", "C7 RETOFF", "C8 ORDER"};
  task automatic flag(input int k, input string what);
    c_viol[k]++;
    if (c_viol[k] <= 3) $display("[%0t] %0s: %0s", $time, c_name[k], what);
  endtask

  logic retn_c = 1'b1, pacc_c = 1'b0;
  // C4, C6 and C7 judge a COMPLETED handshake. After a reset the interface
  // is idle in the reset state without one, while the rails still decay.
  // Set by the checker below, from the same post-edge samples it judges.
  bit hs_done = 1'b0;
  always @(negedge rst_n) hs_done = 1'b0;
  always @(posedge clk) if (rst_n && init_done) begin
    // Sampled after the edge's updates have settled, as a checker would.
    #1;
    if (!ret_n && retn_c && !(rail_logic && rail_ret))
      flag(1, $sformatf("save with logic rail %0b, retention rail %0b", rail_logic, rail_ret));
    if (!ret_n && !rail_ret)
      flag(2, "retention rail down while the save is held");
    if (ret_n && !retn_c && !(rail_logic && rail_ret))
      flag(3, $sformatf("restore with logic rail %0b, retention rail %0b", rail_logic, rail_ret));
    if (hs_done && !preq && !paccept && keeps_logic(pcsm_mode) && !rail_logic)
      flag(4, $sformatf("handshake complete in %0s with the logic rail down", ppu_mode_name(pcsm_mode)));
    if ((u_pcsm.ret_state.name() == "RET_ARM")
        && !(u_pcsm.dev_req_valid && retains_logic(u_pcsm.dev_req_state[3:0])))
      flag(5, "RET_ARM with no retaining request pending");
    if ((u_pcsm.ret_state.name() == "RET_SAVED")
        && u_pcsm.dev_req_valid && keeps_logic(u_pcsm.dev_req_state[3:0]))
      flag(5, "RET_SAVED with a logic-keeping request pending");
    if (PG && hs_done && !preq && !paccept && !keeps_logic(pcsm_mode) && rail_logic)
      flag(6, $sformatf("handshake complete in %0s with the logic rail up", ppu_mode_name(pcsm_mode)));
    if (PG && hs_done && !preq && !paccept && !retains_logic(pcsm_mode) && rail_ret)
      flag(7, $sformatf("handshake complete in %0s with the retention rail up", ppu_mode_name(pcsm_mode)));
    // PACCEPT rose on this edge: judge ret_n as it was BEFORE the edge, so a
    // save or restore on the same edge as the accept counts as late.
    if (paccept && !pacc_c) begin
      if (retains_logic(pstate[3:0]) && retn_c)
        flag(8, $sformatf("accepted %0s before the save", ppu_mode_name(pstate[3:0])));
      if (keeps_logic(pstate[3:0]) && retains_logic(pcsm_mode) && !retn_c)
        flag(8, $sformatf("accepted %0s out of %0s before the restore",
                          ppu_mode_name(pstate[3:0]), ppu_mode_name(pcsm_mode)));
    end
    if (pacc_c && !paccept) hs_done = 1'b1;
    retn_c = ret_n;
    pacc_c = paccept;
  end

  // Request a PCSM state and hold the request until the controller reports
  // the device there -- what ppu_seq does in its PCSM states.
  task automatic go(input logic [3:0] m);
    @(negedge clk);
    req_state = {(m == PM_FULL_RET) ? 8'hFF : 8'h00, 4'h0, m};
    req_valid = 1'b1;
    wait (cur_state == req_state);
    @(negedge clk);
    req_valid = 1'b0;
  endtask

  int unsigned fails = 0;
  task automatic result(input string id, input bit ok, input string msg);
    if (ok) $display("  RESULT %0s PASS: %0s", id, msg);
    else begin fails++; $display("  RESULT %0s FAIL: %0s", id, msg); end
  endtask

  initial begin
    int unsigned saves_m, restores_m, rail_m;
    void'($value$plusargs("d_on=%d", d_on));
    void'($value$plusargs("d_ret=%d", d_ret));
    void'($value$plusargs("iters=%d", iters));
    void'($value$plusargs("seed=%d", seed));
    void'($urandom(seed));
    for (int k = 1; k <= 8; k++) c_viol[k] = 0;
    $display("ppu_pcsm_pgood_tb: PGOOD_EN = %0d, controller sync %0d, RET_SETTLE %0d, LOGIC_SETTLE %0d, logic switch %0d, retention switch %0d cycles",
             PG, CTRL_SYNC, RS, LS, d_on, d_ret);
    repeat (5) @(negedge clk);
    rst_n = 1'b1;
    wait (init_done);
    go(PM_ON);
    repeat (d_on + d_ret + 40) @(posedge clk);

    // ---- A and R ----
    t_save = 0; t_logic_off = 0; t_acc_fall = 0; t_ret_ack = 0;
    go(PM_FULL_RET);
    repeat (d_on + d_ret + 40) @(posedge clk);
    $display("  A  ON -> FULL_RET: handshake complete at %0d, logic supply off at %0d, retention ack at %0d, save at %0d",
             t_acc_fall, t_logic_off, t_ret_ack, t_save);
    result("A", t_save != 0 && t_save < t_logic_off && t_save <= t_acc_fall,
           $sformatf("save %0d cycle(s) before the logic supply went and %0d before the handshake completed",
                     longint'(t_logic_off) - longint'(t_save), longint'(t_acc_fall) - longint'(t_save)));
    result("R", t_save != 0 && t_ret_ack != 0 && t_ret_ack <= t_save,
           $sformatf("save %0d cycle(s) after the retention switch acknowledged",
                     longint'(t_save) - longint'(t_ret_ack)));

    // ---- S ----
    t_restore = 0; t_on_ack = 0; t_acc_fall = 0;
    go(PM_ON);
    repeat (d_on + d_ret + 60) @(posedge clk);
    $display("  S  FULL_RET -> ON: logic switch acknowledged at %0d, restore at %0d, handshake complete at %0d",
             t_on_ack, t_restore, t_acc_fall);
    result("S", t_restore != 0 && t_on_ack != 0 && t_on_ack <= t_restore && t_restore <= t_acc_fall,
           $sformatf("restore %0d cycle(s) after the logic switch acknowledged, %0d before the handshake completed",
                     longint'(t_restore) - longint'(t_on_ack), longint'(t_acc_fall) - longint'(t_restore)));

    // ---- B ----
    go(PM_FULL_RET);
    go(PM_ON);
    repeat (d_on + d_ret + 80) @(posedge clk);
    $display("  B  ON -> FULL_RET -> ON: logic_on %0b, ret_n %0b, retention rail %0b, retention state %s",
             logic_on, ret_n, logic_ret, u_pcsm.ret_state.name());
    result("B", logic_on && ret_n && !logic_ret && u_pcsm.ret_state.name() == "RET_IDLE",
           "the domain is ON and the retention machine is idle");

    // ---- M: Logic Mode OFF retains nothing ----
    saves_m = 0; restores_m = 0; rail_m = 0;
    fork
      begin : m_watch
        forever @(posedge clk) begin
          if (!ret_n && retn_d) saves_m++;
          if (logic_ret) rail_m++;
        end
      end
      begin
        go(PM_OFF);     repeat (d_on + 20) @(posedge clk);
        go(PM_ON);      repeat (d_on + 20) @(posedge clk);
        go(PM_MEM_RET); repeat (d_on + 20) @(posedge clk);
        go(PM_ON);      repeat (d_on + 20) @(posedge clk);
        go(PM_OFF);     go(PM_MEM_RET); repeat (d_on + 20) @(posedge clk);
        go(PM_ON);      repeat (d_on + 20) @(posedge clk);
      end
    join_any
    disable m_watch;
    result("M", saves_m == 0 && rail_m == 0 && ret_n,
           $sformatf("OFF and MEM_RET: %0d save(s), %0d cycle(s) of retention rail", saves_m, rail_m));

    // ---- Random walk over the hops ppu_seq makes ----
    for (int i = 0; i < iters; i++) begin
      logic [3:0] nxt;
      if (pcsm_mode == PM_ON) begin
        case ($urandom_range(0, 5))
          0: nxt = PM_FUNC_RET;
          1: nxt = PM_MEM_OFF;
          2, 3: nxt = PM_FULL_RET;
          4: nxt = PM_MEM_RET;
          default: nxt = PM_OFF;
        endcase
      end else if (pcsm_mode == PM_OFF && $urandom_range(0, 2) == 0) begin
        nxt = PM_MEM_RET;
      end else begin
        nxt = PM_ON;
      end
      go(nxt);
      repeat ($urandom_range(0, 12)) @(posedge clk);
    end
    go(PM_ON);
    repeat (d_on + d_ret + 80) @(posedge clk);
    $display("  random walk: %0d hops", iters);

    // ---- Z: a reset with the domain ON, then an immediate power-up ----
    // Reset drops logic_on at once, but a slow switch's acknowledge stays HIGH
    // for its off-delay. The first power-up must not be accepted on it.
    @(negedge clk) rst_n = 1'b0;
    repeat (2) @(negedge clk);
    rst_n = 1'b1;
    req_state = {8'h00, 4'h0, PM_OFF};
    wait (init_done);
    go(PM_ON);
    repeat (d_on + d_ret + 40) @(posedge clk);
    $display("  Z  reset while ON, then ON: logic rail %0b", rail_logic);

    for (int k = 1; k <= 8; k++)
      result(c_name[k].substr(0, 1), c_viol[k] == 0,
             $sformatf("%0s: %0d violation(s)", c_name[k], c_viol[k]));

    $display("ppu_pcsm_pgood_tb: %0d failure(s)", fails);
    $display("RESULT: %0s", (fails == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #5ms;
    $display("ppu_pcsm_pgood_tb: TIMEOUT");
    $display("RESULT: FAIL");
    $finish;
  end

endmodule
