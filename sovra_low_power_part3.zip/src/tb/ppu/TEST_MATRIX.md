# PPU testbench — phase matrix

What each phase of [`ppu_pd_tb.sv`](ppu_pd_tb.sv) programs, and what that
combination is meant to prove. Phase names match the `test_phase` signal in the
waveform and the `========== ... ==========` banners in the log.

DUT is [`ppu_pd_top`](../../rtl/ppu/ppu_pd_top.sv). See
[the PPU README](../../rtl/ppu/README.md) for the architecture and
[ARM DEN 0051E](../../../references/standards/arm-power-policy-unit-architecture-spec-v1.1.pdf)
for the specification. Section references below are to that document.

## What the PPU is actually being driven with

Unlike the Q-Channel and P-Channel testbenches, which drive the DUT through
dedicated stimulus pins, almost everything here goes through **one register
write**: `PPU_PWPR`, carrying `PWR_POLICY[3:0]`, `PWR_DYN_EN[8]` and
`LOCK_EN[12]` together. That is not a testbench convenience — it is how the
architecture works, and it is why the unsupported-policy check in Section 4.1.1
has to look at the policy and the dynamic enable *as a pair*.

The remaining stimulus is the workload (`start`/`work_len`/`deny_enb`, which
decide whether the device denies) and `wake` (which drives `DEVQACTIVE`, the
only hardware input that can start a transition on its own).

| Input | Reaches the PPU as | Decides |
|---|---|---|
| `PPU_PWPR.PWR_POLICY` | the target, or the minimum if dynamic | which mode |
| `PPU_PWPR.PWR_DYN_EN` | `PWR_DYN_STATUS` | whether `DEVQACTIVE` may start transitions |
| `PPU_PWPR.LOCK_EN` | `LOCK_STATUS` once a lockable mode is reached | whether the PPU may leave `OFF`/`MEM_RET` |
| `PPU_PTCR.WARM_RST_DEVREQEN` | per-transition channel enable | whether `ON ↔ WARM_RST` handshakes |
| `deny_enb && busy` | `DEVQDENY` | whether a departure from `ON` is refused |
| `wake \| busy` | `DEVQACTIVE` | dynamic transitions, and the wake in P7/P10 |

## Phases

| Phase | Policy programmed | Other stimulus | Proves |
|---|---|---|---|
| **P0** | none (reset default `ON`) | — | Section 4.2.1: with `DEF_PWR_POLICY = ON` the PPU powers the domain up and releases it from reset unaided, and that transition raises **no** interrupt |
| **P1** | — | register reads/writes | A sweep of **every** register's reset value against its Chapter 5 Default; `PPU_IDR0`/`IDR1`/`IIDR`/`AIDR` describe the PPU that was built; `PPU_STSR`/`PPU_OPSR`/`PPU_PMER` reserved and read zero |
| **P2** | `OFF`, `ON`, `FULL_RET`, `FUNC_RET`, `MEM_OFF`, `MEM_RET` | — | every direct `ON ↔ X` hop, with Section 4.1.5 ordering checked on the two hops where the controls move |
| **P3** | `WARM_RST`, `ON` | `WARM_RST_DEVREQEN` = 1 then 0 | Table 4-4: the device handshake for `ON ↔ WARM_RST` is independently switchable |
| **P4** | `FULL_RET` then `MEM_OFF` | — | Section 3.3.2: a Q-Channel PPU only moves between `ON` and the policy, so this is two hops and **one** completion interrupt |
| **P5** | `OFF` | burst running, `deny_enb=1` | Sections 4.1.1/4.2.9: denial reverts `PWR_POLICY`, raises `STA_DENY_IRQ`, and touches no device control |
| **P6** | `OFF` then `ON` | — | Section 4.1.6: the PCSM handshake gates the sequence in both directions |
| **P7** | `OFF` dynamic, then `ON` static | `wake` toggled | Section 3.4.3: `DEVQACTIVE` drives the transition in both directions |
| **P8** | `MEM_RET` from `OFF`, then `OFF` | — | Sections 3.3.2/4.2.6: `OFF → MEM_RET` is PCSM-only; the reverse is not, and routes through `ON` |
| **P9** | `LOGIC_RET`; dynamic `WARM_RST`; static `WARM_RST` | — | Section 4.1.1: unsupported policies are refused with `UNSPT_POLICY_IRQ`, and support depends on the policy **and** the dynamic enable |
| **P10** | `OFF` dynamic + `LOCK_EN` | `wake` raised | Section 3.4.3: a locked PPU ignores `DEVQACTIVE` until `PPU_UNLK` is written |
| **P11** | `OFF`, `ON` | `PPU_DCDR0/1` reprogrammed | Table 4-5: each delay is *separated* by exactly `N+1` PPU cycles, not merely ordered |
| **P12** | `OFF` static then dynamic | `PPU_EDTR0.OFF_DEL`, `wake` toggled mid-count | Section 4.1.3: the entry delay timer counts `N+1`, applies only downward, and **resets** rather than pausing when conditions change |
| **P13** | `ON` (static) | all four `PPU_IESR` encodings, `PWR_DEVACTIVEEN` cleared | Section 5.2.14 edge selection, and Section 4.1.3's rule that the enables *"have no effect on the generation of interrupts"* |
| **P14** | `OFF` dynamic | `PWR_DEVACTIVEEN=0`, `wake` held HIGH | Section 3.4.1: a disabled `DEVACTIVE` input *"is always assumed to be LOW for the purposes of transition control"* |
| **P15** | `OFF`, `ON` | `DEVREQEN=0` | Section 4.1.3: `DEVQREQn` driven permanently HIGH, transition proceeds with no handshake |
| **P16** | `OFF`, then `FULL_RET` written mid-flight | — | Section 4.1: *"Software writes to PPU_PWPR do not interrupt mode transitions"* |
| **P17** | `MEM_OFF`, `ON`, `LOGIC_RET` | `PPU_IMR` masked/unmasked | The three interrupt rules: masking suppresses the *status bit*, write-one-to-clear, and `OTHER_IRQ` is derived |
| **P18** | `OFF` dynamic | busy workload + `PWR_DEVACTIVEEN=0` | Table 4-1: `DYN_DENY` fires and the policy is **not** reverted when `PWR_DYN_STATUS` is set |
| **P19** | `MEM_RET` dynamic + `LOCK_EN` | — | Section 3.4.3 corners: `MEM_RET` is lockable, `LOCK_EN`/`PWR_DYN_EN` release the lock, and it re-locks in place |
| **P20** | `ON` | all-ones / all-zeros to every writable register, plus reserved/unmapped/RO addresses | Section 5.2 WI/RAZ, asked **systematically**: the read-back after all-ones must equal the writable mask exactly, for all 12 writable registers |
| **P21** | all seven modes, plus the direct `OFF → MEM_RET` route | — | The **complete nine-signal actuation vector** per mode against Tables 3-1/4-7/4-9/4-11, plus `PPUHWSTAT` one-hot on every visit |
| **P22** | every mode | — | `DEVCLKEN` is an intent; the gated clock is the effect. **Zero** edges in `FULL_RET`/`MEM_RET`/`OFF`, still running in `ON`/`FUNC_RET`/`MEM_OFF`/`WARM_RST` |
| **P23** | `FULL_RET`, then `OFF` | light-work burst frozen mid-count | Retention vs corruption: `FULL_RET` keeps the count, `OFF` loses it |
| **P24** | `OFF` | isolation defeated for 4 cycles | The clamp is load-bearing — X escapes to `DEVQACTIVE` without it |
| **P25** | — | — | `PU1`–`PU8` power sequencing **and** `ppu_monitor`'s `U1`–`U9` held across the whole run |
| **P27** | `OFF` then a mid-flight rewrite; dynamic `OFF` with `PWR_DYN_EN` cleared mid-flight | busy workload for the denials | §4.1.2 completion conditions 3 and 4 — the two that only arise when `PPU_PWPR` is written during a transition |
| **P28** | `OFF` then `WARM_RST`, all static | `wake` held HIGH | §3.4.2: `DEVQACTIVE` blocks a **static** departure from `ON` without retargeting it; `WARM_RST` exempt; a disabled input un-blocks it |
| **P29** | `OFF` | `PPU_EDTR0.OFF_DEL` shrunk mid-count | §4.1.3: the timer keeps the value it was loaded with, and uses the new one next time |
| **P30** | `OFF`, `FULL_RET`→`MEM_OFF`, `OFF`→`MEM_RET`, `DEVREQEN=0` | long `ISO_RST_DLY` to widen the window | §4.1.2: acceptance fires per hop **at completion**, not at handshake accept, and fires even with no handshake |
| **P31** | static gating on the **intermediate** hop (§3.4.2) | `FULL_RET`+policy `OFF`, `MEM_OFF`+policy `FULL_RET`, both with `DEVQACTIVE` HIGH; `ON`↔`WARM_RST` exempt both ways | Regression for **F9**. Asserts the mode is **HELD** — the broken design still reached `OFF` eventually, so any end-state check passed against it |
| **P32** | lock applies only to **lockable** modes (§3.4.3) | `FULL_RET` with `LOCK_EN`+`PWR_DYN_EN`, plus an `OFF` control | A list is only pinned down by testing something *not* on it — a mutation adding `FULL_RET` to `ppu_mode_lockable()` had survived the whole suite |
| **P33** | three rules a settled-state check cannot see | `RST_HWSTAT_DLY` measured at 2 vs 60; `PWR_DYN_STATUS` read mid-transition; the Q-state at a denial revert | All three were surviving mutants in wave 2 |
| **P34** | PCSM interface details nothing else pins down | all three retention registers followed to `PCSMPSTATE[15:8]` in their own modes; `PCSMPREQ` never rises during PCSM init | Only `MEM_RET`'s routing had ever been checked |
| **P35** | `ON` and `MEM_RET`, each written static→dynamic and dynamic→static at the mode it is in | — | §4.1.2 completion condition 1 names `PPU_PWPR.PWR_DYN_EN`, not the status: a same-mode write that sets the enable raises no event, one that clears it raises one. Regression for SCP finding 5 |
| **P36** | `{OFF}` in static `MEM_RET`, `{ON}` and `{MEM_RET}` in static `OFF`, each one write with `PWR_DYN_EN`+`LOCK_EN` | — | §3.4.3: a lock written in a lockable mode holds the PPU there from the write itself, even when the same write asks for another mode; `PPU_UNLK` then releases it to the policy. Regression for SCP finding 1 |
| **P26** | random, 30 iterations | random delays, retention config, bursts, wake toggles | Constrained-random exploration: every iteration settles, all three checkers stay at their expected counts, and a coverage tally proves what was generated |

## Two traps this suite sets for its own author

Both were hit while writing P31, and both produce a **passing** test.

**`check_mode()` programs the policy it verifies.** It means "go to mode X and
check the actuation", not "assert we are in X". Using it to assert "held in
`FULL_RET`" silently overwrites the policy under test, so the phase passes
against a design that blocks nothing. Assertions about *not moving* must be
passive — `check(pwr_status === PM_X, ...)`.

**P31 is the only directed phase after the random one**, so it inherits P26's
leftovers. Two kinds: the *registers* (`PPU_DCDR0/1`, `PPU_EDTR0`, `PPU_PWCR`,
`PPU_PTCR` are all randomised, making every wait a function of the seed) and the
*stimulus* — P26 asserts `start` inside its loop and never clears it, and a
running burst holds `busy`, which `qchannel_device` ORs into `DEVQACTIVE`. A
phase that tests DEVQACTIVE gating must own every source of DEVQACTIVE.

## Transition-pair coverage — measured, not asserted

The table below this one lists which *modes* are entered. That is not the same
question as which *transitions* occurred, and §4 defines transitions as a matrix.
"Every mode was entered" is satisfied by a suite that only ever goes
`ON → X → ON` — the shape of most phases here — while the direct `OFF → MEM_RET`
hop is a structurally different sequence with no device handshake at all.

[`ppu_coverage.sv`](ppu_coverage.sv) measures it inside `make ppu`:

```
                 OFF      MEM_RET  FULL_RET MEM_OFF  FUNC_RET ON       WARM_RST
   OFF           .        3        .        .        .        30       .
   MEM_RET       .        .        .        .        .        12       .
   FULL_RET      .        .        .        .        .        12       .
   MEM_OFF       .        .        .        .        .        11       .
   FUNC_RET      .        .        .        .        .        10       .
   ON            32       9        12       11       10       .        7
   WARM_RST      .        .        .        .        .        7        .

   reachable pairs 13, covered 13, uncovered 0
   events covered 7 of 7
```

The shape is the ON-anchoring of §3.3.2 made visible: the only off-diagonal
non-`ON` cell is the sanctioned `OFF → MEM_RET` direct hop. `MEM_RET → OFF` is
`.` rather than `-` because Table 4-14 gives `MEM_RET` exactly one end mode —
the hop is one-way, and a collector expecting 14 pairs would be demanding a
transition the spec forbids.

Two things make this a check rather than a printout:

- **An uncovered reachable pair fails the run.** Mutating the direct hop away
  drops coverage to 12/13 and the summary check fails.
- **An *illegal* pair taken is flagged separately**, as `!n` in the matrix. That
  makes the collector a conformance check as well as a coverage meter: if the PPU
  ever reached a mode the spec does not allow it to reach from where it was, the
  matrix says so even if every other check passes.

Events are taken at their source in the sequencer, not from `PPU_ISR` — a masked
event never sets its status bit, so counting status bits would report an event as
uncovered exactly when the suite had deliberately masked it.

## Mode coverage

All seven supported modes are entered. `WARM_RST` is entered twice, once with
each `WARM_RST_DEVREQEN` setting, because those are structurally different
sequences rather than the same sequence with a different delay.

| Mode | Entered in | Distinguishing check |
|---|---|---|
| `ON` | P0 and throughout | every device control released, PCSM reports the logic supply on |
| `WARM_RST` | P3 | `DEVWARMRESETn` alone asserts; `PCSMPSTATE` stays `ON` (Table 3-2 note a) |
| `FUNC_RET` | P2 | device controls identical to `ON`; the whole difference is on the PCSM |
| `MEM_OFF` | P2, P4 | logic on, RAM off |
| `FULL_RET` | P2, P4 | `DEVWARMRESETn` asserts while `DEVPORESETn`/`DEVRETRESETn` stay HIGH |
| `MEM_RET` | P2, P8 | `PCSMPSTATE[15:8]` carries `PPU_MEMRR` through untouched |
| `OFF` | P2, P5–P10 | every device control asserted, logic and RAM both down |

## The three expected monitor violations

`qchannel_monitor` runs across the whole simulation and reports **exactly
three** violations: one in P3 and two in P15. Both phases check the count
rather than ignoring it, and both are cases where the PPU specification
deliberately overrides AMBA LPI Section 2.1.2 — *"a controller must only assert
a device reset when the interface is in the `Q_STOPPED` state."*

### P3 — one violation, from Table 4-4

> `ON to WARM_RST` / `WARM_RST to ON`, `DEVREQEN[x]` = 1,
> `WARM_RST_DEVREQEN` = 0 → Device Interface Handshake: **No**

With the handshake switched off, the PPU asserts `DEVWARMRESETn` while the
interface is still in `Q_RUN`. That is the entire point of the option: it exists
so a component with no `WARM_RST` support can still be warm reset by the PPU,
and the component is not consulted.

### P15 — two violations, from the channel disable

Clearing `PPU_PWCR.DEVREQEN` is software explicitly opting the component out of
the LPI contract: Section 4.1.3 says `DEVQREQn` is then *"driven permanently
HIGH"* and *"transitions continue without issuing requests or waiting for
responses on the disabled channels."* So the PPU gates the clock and asserts
the resets with the interface still in `Q_RUN` — two violations on the way
down (R10 for the clock gate, R8 for the reset), none coming back up, because
the monitor only checks assertion.

### Why they are measured rather than muted

A sanctioned protocol exception that nothing measures is indistinguishable from
a bug; one that is measured is a documented result. Both phases baseline the
count, assert the exact delta, and re-baseline — so any *additional* violation
anywhere in the run still fails the summary check.

## Confidence in the timing checks

P11 and P12 measure separation in PPU clock cycles rather than comparing
timestamps, because Table 4-5 constrains a *minimum number of cycles* and only
a cycle count can catch an off-by-one in its `+ 1`.

That infrastructure has been mutation-tested: injecting `cnt <= clken_iso_dly +
1` into `ppu_seq` makes P11 fail with *"got 9, expected 8"*. A timing check
that cannot fail is worse than no check, so this is worth re-running after any
change to the delay counters.

## P26: the constrained-random phase

Every other phase is *directed* — it programs a policy chosen to demonstrate one
property. P26 programs policies, device-control delays, entry delays, retention
configuration, workload bursts and wake toggles at random, and checks only
invariants: that the sequencer always settles, that `PPUHWSTAT` stays one-hot and
agrees with `PWR_STATUS`, and that none of the three checkers fires.

It adds **no new checking logic**. That is the whole reason it was cheap to
write, and the reason it belonged after the monitor rather than before it: the
checkers already own the properties, so a random phase only has to generate
traffic.

```sh
make ppu                        # 30 iterations, seed 0x0BADC0DE
vvp ppu_pd_tb +seed=999         # replay a specific seed
vvp ppu_pd_tb +iters=500        # long soak
```

The PRNG is a hand-rolled xorshift rather than `$random`/`$urandom`: its whole
state is one printable variable, so any failure is reproducible with `+seed=`,
and it behaves identically across simulators. **A random test whose failing seed
cannot be reproduced is not a test.**

### Directed head, random tail

Pure random at 30 iterations leaves about a 2% chance per mode of never
programming it — better than 1 run in 10 would miss one, which would make the
coverage assertions flaky. So iterations 0–6 walk all seven modes statically,
7–13 walk them dynamically, and 14 forces an unsupported policy; everything from
15 on is free. Every *other* stimulus is random from iteration 0, so even the
directed head explores.

### Coverage is asserted, not hoped for

A random phase reporting "0 errors" is worthless if it never generated anything
interesting — the same failure mode as a checker that never fires. So P26 tallies
what it produced and asserts the floor:

```
OFF       static x1  dynamic x2      unsupported policy attempts x4
MEM_RET   static x2  dynamic x1      lock enabled x5
FULL_RET  static x4  dynamic x2      workload bursts x17
MEM_OFF   static x1  dynamic x2      wake toggles x26
FUNC_RET  static x3  dynamic x1      device denials observed x8
ON        static x2  dynamic x2
WARM_RST  static x3  dynamic x0   <- correctly zero: static-only, Section 3.4.3
```

`WARM_RST` showing `dynamic x0` is a result rather than a gap: Section 3.4.3
excludes it from dynamic transitions on a Q-Channel PPU, so a dynamic `WARM_RST`
is counted as an unsupported-policy attempt instead. That is why the dynamic
coverage assertion requires six modes rather than seven.

### It found a bug — in the testbench

Seed 999 failed the post-storm functional check: programming `OFF` timed out,
stuck in `ON`. Probing showed `busy=1, deny_enb=1, work_count=18` — a burst the
storm had left running, which the device quite correctly refused to quiesce for.

The RTL was right; the check was missing a drain that every other
down-transition phase already does. Worth recording for two reasons: it is what
a seed sweep is *for*, and it is a reminder that the first suspect for a random
failure is the generator, not the design.

Seeds 1, 7, 42, 999, 31337, 8675309 and 2147483647 all pass, as does a
500-iteration soak (102 denials, 123 locked iterations).

## Three independent checkers run throughout

| Checker | Owns | Expected | Proven non-vacuous by |
|---|---|---|---|
| [`qchannel_monitor`](../../rtl/qchannel/qchannel_monitor.sv) | the AMBA Q-Channel wire protocol (`R1`–`R10`) | **3** violations, all sanctioned | its own design; the two exceptions are measured, not muted |
| [`ppu_monitor`](../../rtl/ppu/ppu_monitor.sv) | the PPU's architectural rules (`U1`–`U11`) | 0 | [`ppu_monitor_negtest.sv`](ppu_monitor_negtest.sv), `make ppuneg` |
| [`ppu_power_model`](ppu_power_model.sv) | power sequencing (`PU1`–`PU8`) | 0 | mutation test — see below |

The same two monitors are also attached in
[`ppu_clkratio_tb.sv`](ppu_clkratio_tb.sv), which reruns a full mode sweep at
four PPU:device clock ratios (10× faster down to 6.7× slower) and requires both
at zero in every one, and in [`ppu_minconfig_tb.sv`](ppu_minconfig_tb.sv), where
all three checkers run against the **reduced** build — Chapter 7 configures what
a PPU offers, never how it behaves once it acts, so a reduced build must satisfy
the same rules.

## Reset in flight — `ppu_rstflight_tb.sv` (`make ppurstf`)

180 iterations: `RESETn` asserted 1–60 cycles into `ON→OFF`, `ON→MEM_RET` and
`ON→FULL_RET`, with all three checkers watching across the reset. Every
iteration checks recovery to the Table 4-13 mode, PPU/PCSM agreement, the
actuation at the pins, and a full round trip afterwards.

Q-Channel violations are **classified, not muted** — the counter is sampled
around each reset and each recovery:

| Channel state at the reset edge | Required delta | Cases |
|---|---|---|
| `Q_STOPPED` | 0 — a parked reset must stay silent | 142 |
| anything else | non-zero — a torn handshake must be noticed | 38 |
| after recovery, normal running | 0 — the interface must be left usable | 180 |

Two notes worth keeping:

- **Classification reads the monitor's registered channel state, not the raw
  pins.** R9 evaluates `{c_req, c_acc, c_den}` when `crst_n` falls; those are up
  to one monitor clock stale. Reading the pins directly disagreed for exactly one
  sample, and the sweep found it — one iteration in 180 landed on the instant the
  channel was parking, so the testbench called it parked and the monitor called
  it live. Both readings were defensible, which is what made it a testbench bug
  rather than a design bug. Fixing it at the source moved that iteration between
  buckets (143/37 → 142/38) rather than widening a tolerance until the failure
  stopped appearing.
- **`R8` firing alongside `R9` is the topology.** Both channel ends share
  `aon_rst_n` deliberately, so an interrupted handshake shows up on both — which
  is the AMBA LPI-legal way to interrupt one.

Mutating the sequencer's isolation reset value (`dev_isolaten` released instead of
active) fails exactly the two checks the header says have no topology excuse:
`ppu_power_model` (PU8 6507×, PU4, PU1) and `ppu_monitor`.

## Reduced configurations — `ppu_minconfig_tb.sv` (`make ppucfg`)

76 checks across three DUTs sharing one register bus: `u_max` (every option
built), `u_min` (all five optional features plus `OFF_MEM_RET_TRANS` cleared) and
`u_nlk` (`LOCK_SPT` cleared alone, dynamic retained to isolate it).

| Phase | Covers |
|---|---|
| **M1** | `PPU_IDR0`/`IDR1` describe the build; `PPU_AIDR`/`IIDR` must *not* differ |
| **M2** | Lock removed: `PPU_UNLK`, `LOCK_EN`, `LOCK_STATUS`, the `PPU_IMR` reset shape — and a functional lock test where only `LOCK_SPT` differs |
| **M3** | Dynamic removed: `PWR_DYN_EN` write-ignored, `PWR_DYN_STATUS` pinned low, static policy still works |
| **M4** | Retention-RAM registers removed — checked at `PCSMPSTATE[15:8]`, where they reach hardware |
| **M5** | Entry-delay timer removed, timed on `DEVQREQn` |
| **M6** | Device-control delays **read-only, not reserved**: values still read back, delays still applied |
| **M7** | `OFF → MEM_RET` direct hop removed — observed as a transient visit to `ON` |
| **M8** | Full mode sweep on the reduced build under all three checkers |

Every check compares the two builds in one transaction and requires them to
disagree; `check_pair` refuses identical expectations rather than reporting a
pass. Two measurement notes worth keeping:

- **M5 times `DEVQREQn`, not the sequencer's busy flag.** The entry delay is a
  *state* of the sequencer, so busy rises when the PPU starts **waiting**. Timing
  against busy reports the same three cycles whether the timer exists or not — a
  check that silently cannot fail. That was a real bug in the first draft.
- **M6 times a transition as well as reading registers.** Deleting the
  `SW_DEV_DEL_SPT` write guard breaks three checks: both register reads *and* the
  timed transition. The timing check is what proves the fixed delays are still
  being applied rather than merely still being readable.

The point of three is that they are independent: `qchannel_monitor` would not
notice a `PPUHWSTAT` that disagreed with the device controls, `ppu_monitor`
would not notice the supply being removed before isolation engaged, and the
power model would not notice an illegal mode pair.

### A note on the negative test's own bugs

`ppu_monitor_negtest` failed three "legal sequence" checks on its first run, and
both causes were in the test rather than the monitor — worth recording because
both are easy to repeat:

1. **It stepped on the posedge**, the same edge the monitor samples on, so
   stimulus and sampling landed at the same simulation time and the result
   depended on Icarus's event ordering. It steps on the negedge now, which is
   the convention the functional testbenches already document.
2. **Its `idle_on`/`idle_off` helpers teleport** between modes, and jumping from
   `OFF` to `ON` in one step asserts the clock and releases the resets
   simultaneously — a genuine `U5`/`U6` violation, correctly flagged. They now
   bracket the jump with `ppu_rst_n` LOW, which is how the monitor is documented
   to be told "these outputs are not the result of a transition".

## The power-intent model

Phases P21–P25 rely on [`ppu_power_model.sv`](ppu_power_model.sv), a
behavioural stand-in for [`src/upf/ppu_pd_top.upf`](../../upf/ppu_pd_top.upf).
Icarus has no notion of power intent, so without it `FULL_RET`, `MEM_RET` and
`OFF` are indistinguishable — all three hold the workload in reset, so all three
read back reset values, and no functional check can tell "lost its supply" from
"was reset".

The model implements the four things the UPF file declares:

| UPF construct | Modelled as |
|---|---|
| `create_power_switch` | a supply state decoded from the PCSM's Table 3-1 actuation |
| `-simstate CORRUPT` | `pm_corrupt`, which forces X into the switched domain's registers |
| `set_isolation` | the boundary driver: clamp value 0 while isolated, X when not |
| `set_retention` | `do_save`/`do_restore` around the retention supply |

plus eight continuous sequencing rules, `PU1`–`PU8`, which are the power-aware
counterpart of `qchannel_monitor`'s `R`-rules: the supply may only be removed
after isolation, clock gating and reset are applied, and may only be restored
before they are released. P25 asserts zero violations across the entire run.

### Three modelling traps, all of which bit

Recorded because each produced a confusing failure rather than an obvious one:

1. **`logic_ret` was an undeclared implicit wire**, so it read `z`, `pm_corrupt`
   evaluated to `x`, and the entire model was silently inert. Caught by P21's
   whole-vector check — no single-signal check would have looked at it.
2. **`pm_corrupt` glitched for one delta cycle** on `ON → FULL_RET`, because
   `logic_on` and `logic_ret` are separate continuous assigns that settle in
   different deltas. A level-sensitive force block latched the transient,
   corrupted a domain that was moving to the retention supply, and hung the
   design. The model now registers `corrupt` on the PPU clock — which is also
   what a real power switch does.
3. **Releasing a force is not the same as restoring a value.** On the way up the
   supply returns while the domain is still in reset and still unclocked, so a
   released register keeps its last forced value with nothing to re-drive it.
   The model has a third state, `PD_RESET_HELD`, that applies reset values —
   which is exactly how an async-reset flop behaves, and it leaves `cnt` X
   because `cnt` is the one register with no reset value.

### Two findings it surfaced

- **`WARM_RST` drove `DEVRETRESETn` HIGH** where Table 4-9 requires LOW. Caught
  by P21 on its first run. See F1 in [`CONFORMANCE.md`](../../rtl/ppu/CONFORMANCE.md).
- **`dummy_workload.cnt` has no reset**, so `work_count` comes back X after any
  power cycle — exactly the finding `src/upf/README.md` predicted for the first
  power-aware run. P23 asserts it rather than working around it.

### Mutation-tested

Moving the isolation release ahead of the PCSM restore in `ppu_seq` makes the
model report `PU4` and a stream of `PU8` violations. Worth re-running after any
change to the sequencer's ordering.

## What this still cannot show

The model is a stand-in, not a substitute. It corrupts what a testbench can
reach by hierarchical force — `cnt`, `busy`, `done` — not every net in the
domain, and it cannot check the power intent file itself for internal
consistency. A UPF-aware simulator (`make ppupa`) does both, and remains the
authority; see [`src/upf/README.md`](../../upf/README.md).


---

## Soak results

`make ppu` runs 30 random iterations. The generator has been soaked well past
that, and the coverage tally is what makes a long run worth more than a fast one:

| Iterations | Seed | Sim time | Result |
|---|---|---|---|
| 500 | 3 | 281 µs | PASS |
| 1000 | 7 | 525 µs | PASS |
| 1000 | 20250815 | 526 µs | PASS |
| 3000 | 99 | 1.50 ms | PASS |

At 3000 iterations every mode is programmed 170–220 times statically and a
similar number dynamically (`WARM_RST` dynamic stays at 0, correctly — §3.4.3
excludes it), with 576 unsupported-policy attempts, 753 locked iterations, 2016
workload bursts, 3654 wake toggles and 448 device denials.

The watchdog scales with the iteration count (`60 µs + 2 µs × iters`) so a soak
fails for a real reason rather than for running out of time, and the timeout
message prints the budget so a trip is never ambiguous about which it was.

### Coverage that was added because the rules changed

Counters written before a rule exists cannot say anything about that rule. When
F7 added the §3.4.2 static gating, P26's tally predated it — so two counters were
added to measure the new behaviour directly:

| Counter | What it proves | At 30 iters | At 3000 |
|---|---|---:|---:|
| static departures blocked by `DEVQACTIVE` | the §3.4.2 rule is reached at all | 16 | 2034 |
| entry delay counts abandoned | §4.1.3's "the counter is reset" path | 2 | 270 |

The first is **asserted** non-zero, not merely reported: if the storm ever stops
reaching the rule, the phase should fail rather than quietly report confidence it
has not earned.


---

## The register-map sweeps

Chapter 5 gives every register a **Default** column and a per-bit **Type**
column. The phases originally spot-checked a handful; an audit found **six
registers that were never read at all** — `PPU_DISR`, `PPU_MISR`, `PPU_IMR`,
`PPU_ISR`, `PPU_FUNRR` and `PPU_DCDR0`. Two sweeps now walk the whole map.

**Reset values** (`check_reset_defaults`, first thing P1 does, because once
anything has been written the reset values are gone). Fourteen registers. The two
worth singling out:

- `PPU_DCDR0`/`DCDR1` reset to their **configured** defaults rather than to zero,
  so they are the pair that catches a `*_DLY_CFG` parameter that never reached
  the register file.
- `PPU_MISR` reads `0x0000_0100`, not zero. It reflects **pins**, and in `ON` the
  device sits in `Q_RUN` where `DEVQACCEPTn` is HIGH. A check expecting zero here
  would be wrong about the interface, not about the register.

**Writable masks** (`check_writable_mask`, in P20). For each of the 12 writable
registers: write all-ones, read back, and the result must equal the writable mask
**exactly**; then all-zeros must read back zero; then the original value is
restored so the sweep can run mid-simulation. This is what distinguishes a
reserved bit from a merely unused one — Section 5.2's WI/RAZ rule.

Both sweeps are mutation-tested:

| Injected fault | Caught by |
|---|---|
| widened `PPU_IESR` writable mask to `0x0F` | `P20.mask PPU_IESR: all-ones gave 0x0000000f, writable mask is 0x00000003` |
| corrupted `PPU_IMR` reset value | `P1.reset: PPU_IMR: read 0x0000002a, expected 0x00000022` |
| `RST_HWSTAT_DLY_CFG` never reaching the register | `P1.reset: PPU_DCDR0: read 0x00000202, expected 0x00020202` |


## Mutation campaign — what the suite can and cannot see

Reading a testbench cannot tell you whether a check is capable of failing. The
only way to find out is to break the design on purpose and see whether anything
notices. Fourteen mutations, each a deliberate violation of one specification
rule verified in `rtl/ppu/CONFORMANCE.md`:

| | Rule broken | Killed by |
|---|---|---|
| M1 | §3.4.1 disabled DEVACTIVE assumed LOW | `ppu` |
| M2 | §3.4.2 gating covers the intermediate hop (F9) | `ppu` |
| M3 | §3.4.2 WARM_RST exempt from gating | `ppu` |
| M4 | §3.4.2 static gating exists at all | `ppu` |
| M5 | §3.4.3 lockable modes are exactly OFF+MEM_RET | `ppu` (**P32, new**) |
| M6 | §3.4.3 no dynamic transitions to WARM_RST | `ppu` |
| M7 | §4.1.5 ISO_RST_DLY applied | `ppu` |
| M8 | §4.1.5 PPUHWSTAT waits for the device interface | `ppu` (**U12, new**) |
| M9 | §4.1.3 DEVREQEN gates the handshake | `ppu` |
| M10 | §4.1.2 set beats clear in the same cycle | `ppuirq` (**new**) |
| M11 | §4.1.2 masking suppresses the status bit | `ppu` |
| M12 | §4.1.4 PPUHWSTAT is one-hot | `ppu` |
| M13 | §4.1.5 CLKEN_ISO_DLY applied | `ppu` |
| M14 | §3.3.2 OFF → MEM_RET direct hop exists | `ppu` |

**14 of 14 killed.** Three of them only after the checks below were added; the
first run scored 8/14.

### Wave two: thirteen more, aimed at rules verified only by reading

Wave one sampled fourteen rules. Wave two targets the ones the cross-check
confirmed by *inspection* and no mutant had ever tested:

| | Rule broken | Killed by |
|---|---|---|
| W1 | §4.1.3 enables must **not** affect interrupts | `ppu` |
| W2 | §3.4.3 dyn enable waits for the in-flight transition | *equivalent — see below* |
| W3 | §3.4.3 unlock when `PWR_DYN_EN` is cleared | `ppu` |
| W5 | §4.1.5 `ISO_CLKEN_DLY` applied | `ppu` |
| W6 | §4.1.5 `CLKEN_RST_DLY` applied | `ppu` |
| W7 | §4.1.5 `RST_HWSTAT_DLY` applied | `ppu` (**P33a, new**) |
| W8 | §4.1.5 down order: isolation before resets | `ppu` |
| W9 | §4.1.5 up order: isolation released before clocks | `ppu` |
| W10 | Table 3-2a: the PCSM sees `WARM_RST` as `ON` | `ppu` |
| W11 | §4.1.6 `PCSMPSTATE[7:4]` is zero | `ppu` |
| W12 | §4.1.6 `PPU_PWPR` reset honours `PCSMMODESTAT` (F5) | `ppurst` |
| W13 | §4.2.9 denial waits for `Q_RUN` before reverting | `ppu` (**P33c, new**) |
| W14 | §4.1.4 `PPUHWSTAT` bit position per mode | `ppu` |

**Across four waves: 51 mutations, 49 killed, 2 equivalent.**

### Wave four: twelve more, on interrupt sources, the PCSM decode and reset

Aimed at the areas no earlier mutant had touched — including the two defects
(F4, F6) that were found by reading and fixed by hand, with no mutant behind them
until now.

| | Rule broken | Killed by |
|---|---|---|
| Y1 | Table 4-2 static vs dynamic acceptance event | `ppu` |
| Y2 | §4.2.1 the default reset transition is silent | `ppurst` |
| Y3 | §4.1.2 completion needs mode == programmed policy (F4) | `ppurst` |
| Y4 | §4.1.2 completion on a write with no transition (F4) | `ppurst` |
| Y5 | Table 3-1 PCSM logic supply: `MEM_OFF` is powered | `ppu` |
| Y6 | Table 3-1 PCSM logic retention is `FULL_RET` only | `ppu` |
| Y7 | Table 3-1 PCSM RAM on only in `ON` | `ppu` |
| Y8 | Table 3-1 PCSM RAM retention includes `MEM_RET` | `ppu` |
| Y9 | reset release is synchronized (two stages) | `ppurst` |
| Y10 | reset assertion is asynchronous | `ppurst` |
| Y11 | §5.2.14 `PPU_IESR` reserved bits | `ppu` |
| Y12 | §4.1.2 `PPU_AISR[3]` reserved (no operating modes) | `ppu` |

**12 of 12 killed, no new gaps.** Two things worth noting: the F4 and F6 fixes,
which had been verified only by re-reading the specification, now have mutants
behind them; and `ppu_pcsm`'s Table 3-1 actuation decode turned out to be fully
covered — the power model checks the *ordering* of those four signals and the
per-mode actuation checks in `check_mode()` pin down their *values*.

### The campaign's restore can revert real work

`ppu_reset_tb` broke after this wave: the campaign restores `rtl/ppu` from a
snapshot, and the snapshot predated the `PCSM_TINIT_WAIT` plumbing added earlier
the same session, so the restore silently reverted it and the testbench no longer
elaborated. It was caught only because the campaign's own closing line reported
2 clean suites instead of 10.

Worth recording as a working practice: **the snapshot must be refreshed
immediately after any RTL change**, and the campaign's closing count is not
decoration — it is the check that the tree was left as it was found. These files
are untracked, so `git checkout` is not a safety net here.

### Wave three: twelve more, aimed at tables and interface details

| | Rule broken | Killed by |
|---|---|---|
| X1 | Table 3-1 mode priority encoding | `ppu` |
| X2 | Table 4-9 `FULL_RET` device controls | `ppu` |
| X3 | Table 4-9 `MEM_OFF` device controls | `ppu` |
| X4 | §5.2.16–18 retention register routing | `ppu` (**P34a, new**) |
| X5 | §3.3.2 transitions are ON-anchored | `ppu` |
| X6 | Table 4-4 `WARM_RST_DEVREQEN` is a separate enable | `ppu` |
| X7 | §4.1.6 no transition before PCSM init | *equivalent at the built TINIT — see below* |
| X8 | §5.2.14 IESR edge encoding | `ppu` |
| X9 | §4.1.6 PCSM request only when the state changes | `ppu` |
| X10 | §3.4.3 lock only in a lockable mode on a PWPR write | `ppu` |
| X11 | §5.2.10 `PPU_PWCR` writable mask | `ppu` |
| X12 | Table 4-13 reset mode from `PCSMMODESTAT` | `ppurst` |

#### X4 — two of three retention registers were never followed to the PCSM

`PPU_FUNRR`, `PPU_FULRR` and `PPU_MEMRR` each drive `PCSMPSTATE[15:8]` in one
specific mode. Both places that checked this — P8 here and M4 in
`ppu_minconfig_tb` — used `PPU_MEMRR`, so routing `FUNC_RET`'s field to the wrong
register went unnoticed. **P34a** writes three distinct values and visits all
three modes, and asserts the values are distinct so a later edit cannot quietly
make the phase vacuous.

#### X7 — redundant protection, and a parameter that has only one value

Removing the `pcsm_init_done` gate lets the sequencer start a transition during
the PCSM's `tinit`. Measured directly, `PCSMPREQ` then rises **9 ns earlier — and
still after `pcsm_init_done`**, because `pchannel_controller` independently
refuses to issue during its own initialisation. So the mutation is not observable
and **P34b** cannot fail today.

The first explanation was that `tinit` was simply too short — `PCSM_TINIT_WAIT`
had only ever been elaborated at 16 — so `ppu_reset_tb` gained a fifth DUT built
at 200. **It made no difference, and cannot at any value.** `ppu_top` wires
`pcsm_init_done` straight from `pchannel_controller`'s `ctrl_init_done`, which is
the same signal the controller uses to hold its own `PREQ` off. The sequencer's
gate and the controller's gate are one condition wearing two names.

So X7 is a *permanently* equivalent mutant: real defence in depth whose outer
layer is unreachable. The long-`tinit` DUT stays for the coverage it does provide
— a `PCSM_TINIT_WAIT` value never previously built — rather than the coverage it
was written for.

#### W7 — the delay that hid behind another condition

Four of the five device-control delays were already pinned down. `RST_HWSTAT_DLY`
was not, and the reason is worth keeping: `commit_up` waits for **both** the delay
and the device handshake, and at the default clock ratio the handshake is always
the slower of the two — so zeroing the delay changed nothing observable. **P33a**
measures it with a delay *larger* than the handshake (60 cycles against 2) and
compares the two.

#### W2 — an equivalent mutant, and the F9 fix is why

Using the live `PWR_DYN_EN` instead of the latched `dyn_status_q` for target
selection looks like a clear violation of *"the PPU completes any ongoing
transition before the new setting takes effect"*. It is not observable here.

The target is re-evaluated in exactly two places: `S_IDLE`, where `dyn_status_q`
has just been assigned `pwr_dyn_en` anyway, and `S_DELAY`, which re-checks every
cycle so it can abandon a delay whose conditions have gone away. `S_DELAY` looked
like the discriminating window — but with the §3.4.2 gate in place a static
downward policy and a dynamic one **both resolve to `ON`** whenever `DEVQACTIVE`
is HIGH, and with it LOW both resolve to the policy. The F9 fix is what made them
agree.

So the first version of P33b, which drove `DEVQACTIVE` HIGH during the delay and
expected the departure to complete, failed against *correct* RTL — the gate was
abandoning the departure exactly as §3.4.2 requires. **P33b** now checks the
observable the spec actually names, `PPU_PWSR.PWR_DYN_STATUS`, which reads 0
mid-transition while `PPU_PWPR.PWR_DYN_EN` already reads 1. Sourcing that bit from
the raw enable fails it.

### The campaign's own scoring was wrong first

The initial run reported six survivors by grepping the output for `RESULT: FAIL`.
Three of those "survivors" actually *hung* the simulation — the mutation
deadlocked a transition, a watchdog fired, and no summary line was ever printed,
so the grep matched nothing and scored a pass. **A checker whose failure
condition cannot be reached is the exact bug the campaign exists to find, and the
campaign had it.** Scoring now requires each suite to emit its full complement of
success markers, so silence counts as a kill.

### Two "survivors" were equivalent mutants, not gaps

- Removing `&& devreqen` from `req_dev_quiescence` changed nothing observable:
  `req_quiesce_q <= dev_hs_for_hop` already gates it, so the term is redundant.
  Mutating the load-bearing gate instead is killed.
- Removing the device-interface wait from the `S_UP_RST` **state exit** left
  `commit_up`'s own copy of the same condition intact, so `PPUHWSTAT` still
  waited. The real target is the commit expression.

Both matter for reading a campaign honestly: a surviving mutant is only a test
gap once you have shown it changes behaviour at all.

### The three real gaps, and what closed them

**M5 — nothing tested a mode that must *not* lock.** P10 and P19 both prove the
lock engages in `OFF` and `MEM_RET`. Neither pins down the *list*, so adding
`FULL_RET` to it went unnoticed. **P32** enters `FULL_RET` with both enables set
and checks `LOCK_STATUS` stays clear *and* that `DEVQACTIVE` can still raise the
mode, with an `OFF` control so the check cannot pass by lock being broken
everywhere.

**M8 — nothing tested that `PPUHWSTAT` waits for the device interface.** Table
4-5's *"This delay is also dependant on the completion of the device interface"*
had no checker. Timing the delay cannot see it, because both conditions are
normally satisfied together — they separate only when the handshake is slower
than the delay. **`ppu_monitor` U12** states it on the transition pair instead:
leaving a mode whose device controls stop the clock (`OFF`, `MEM_RET`,
`FULL_RET`) for `ON` means the device has been restarted, so the Q-Channel must
be in `Q_RUN` when the mode commits.

> U12's first formulation watched for `Q_EXIT` and caught nothing — at commit
> time `DEVQREQn` has not yet risen, so the channel is still in `Q_STOPPED`. Its
> second used "higher priority" and fired on `ON → WARM_RST`, which is encoded
> *above* `ON` yet quiesces the device. Neither wrong version failed on clean
> RTL, which is why a new checker is worth nothing until a mutant proves it bites.

**M10 — nothing collided a clear with a re-occurrence.** §4.1.2's *"If an event
is cleared in the same cycle that it re-occurs the interrupt status stays HIGH"*
is unreachable from `ppu_pd_tb`: the clear is a register write, every event that
sets a bit is itself a register write, and the bus is single-ported.
[`ppu_irq_tb.sv`](ppu_irq_tb.sv) drives `ppu_irq` directly, where the collision
is one line of stimulus.


## Auditing the checkers that decide pass/fail (wave seven)

Every earlier wave mutated the *design*. These components are testbench code that
returns a verdict, so a defect in them shows up as a green run.

### `ppu_coverage` — proven in three directions

The collector's `pair_reachable()` encodes §3.3.2 and decides what "full
coverage" even means, and nothing had ever tested it.

| Mutation | Caught as |
|---|---|
| RTL drops ON-anchoring, so illegal pairs are taken | `*** 6 ILLEGAL pair(s) taken ***` |
| `pair_reachable` too **restrictive** — `t == 5` removed from the ON-anchor rule | 6 pairs reclassified illegal, run fails |
| `pair_reachable` too **permissive** — `MEM_RET → OFF` allowed, which §3.3.2 forbids | `reachable 14, covered 13, uncovered 1` |
| an `ev_*` input disconnected at the instantiation | `events covered 6 of 7` |

Both error directions are caught, which is the property that matters: a
reachability rule that is too tight silently shrinks the target, and one that is
too loose demands a transition the specification forbids. With all 13 pairs
actually covered, any wrong exclusion lands on a pair that *was* taken and
surfaces as an illegal-pair report rather than as quiet success.

### PU9 and PU10 — the rules that were missing

`ppu_power_model` stands in for the power intent in every non-UPF run, so when
it and `src/upf/ppu_pd_top.upf` disagree about *when* something happens, the
non-UPF runs are checking a different design.

They disagreed about retention. `set_retention` uses
`-save_signal {u_pcsm/ret_n negedge}`; the model had no view of `ret_n` at all
and inferred its save from `logic_ret` rising — a different signal, one cycle
apart, and on a powered rail **by construction**. So a save taken *before* its
own retention supply arrived was structurally invisible, which is why
`ppu_pcsm`'s `ret_rail` lag survived for as long as it did and then failed only
under UPF.

| | |
|---|---|
| **PU9** | the retention supply arrived **after** the save was taken |
| **PU10** | a live save was restored **before** the logic supply returned |

Both took two attempts, and both first drafts were wrong in the same way —
too broad, firing on correct RTL:

- PU9 as *"a save with no retention supply"* fires **49 times** in one
  `ppu_pd_tb` run. `MEM_RET` and `OFF` take a save and deliberately lose it
  with the rail — that is what makes them different modes from `FULL_RET`. The
  defect is narrower and it is an **ordering** one.
- PU10 as *"a restore with no logic supply"* fires **3 times** in
  `ppu_rstflight_tb`. Asserting `aon_rst_n` mid-transition sends `ret_n` back
  HIGH with the domain unpowered — a reset, not a restore, with nothing to put
  back. Qualified with a live save and `logic_ret`.

**`do_save` deliberately still fires on `logic_ret` rising, not on `ret_n`.**
It drives a shadow copy that reads `u_ip/u_ret.sig` hierarchically, and that
read has to land while the domain is unambiguously alive. Moving it onto
`ret_n` put it on the same edge the supply drops, and under UPF it began
capturing a corrupted value — P23 and P23a failing with every other check in
the phase still green. The rules read `ret_n`; the shadow does not.

**Non-vacuity:** restoring `ppu_pcsm`'s original `ret_rail` decode makes PU9
fire **17 times in a plain, non-power-aware run** — the bug that previously
needed UPF to show at all.

### `ppu_power_model` — now proven rule by rule

PU1–PU8 were proven **as a set** by an early mutation (isolation released ahead
of the PCSM restore). They have never been proven **individually**, and this wave
showed why that distinction matters: disabling PU1 outright and re-applying the
fault that trips it, the fault is still caught — by PU8, whose condition
overlaps.

That redundancy is a good property for catching real bugs and a bad one for
verifying the checker: **a dead rule would hide behind its neighbours.**

[`ppu_pm_tb.sv`](ppu_pm_tb.sv) (`make ppupm`) closes it. The model gained an
internal per-rule tally — deliberately not a port, since none of the four
testbenches that instantiate it needs one — and the unit test drives its inputs
directly with nine targeted faults, asserting for each **exactly which rules
fire**, not merely that the total went up.

Isolating a rule is mostly a matter of keeping the neighbours' conditions false:
dropping the supply while the retention supply rises keeps `pd_unpowered` false
so PU8 stays out, holding the clock on keeps PU6's second arm out, and so on.

**PU8 cannot be isolated, and that is a property of the rule rather than a
limitation of the test.** It is a level rule — *the domain is unpowered with
isolation inactive* — and the only ways into that state are dropping the supply
with isolation inactive (PU1) or releasing isolation while unpowered (PU4). There
is no third entry, so PU8 can never be the first rule to fire. The test reaches
it through PU1, snapshots the tally afterwards, and then removes the retention
supply so PU8 fires on the level with no new edge.

Verified the only way that counts: **each of the eight rules was disabled in turn,
and the unit test failed every time.**

| rule | disabled → | rule | disabled → |
|---|---|---|---|
| PU1 | FAIL | PU5 | FAIL |
| PU2 | FAIL | PU6 | FAIL |
| PU3 | FAIL | PU7 | FAIL |
| PU4 | FAIL | PU8 | FAIL |

### Where the other checkers stand

| Checker | Proven by |
|---|---|
| `qchannel_monitor` | its negative test, plus 5 sanctioned violations counted rather than muted |
| `ppu_monitor` | `ppu_monitor_negtest` (17 checks); U12 additionally by mutation M8b |
| `pchannel_monitor` | `pchneg` — wave six broke PR3, PR4 and PR8 and all three were caught |
| `ppu_coverage` | this wave, three directions |
| `ppu_power_model` | `ppu_pm_tb` — all eight rules individually, each proven by disabling it |


## Timing-parameter sweep — every duration, measured or explicitly not

Three separate waves turned up the same shape of bug: a delay that every
functional check tolerates because nothing downstream depends on its length, so
shortening it to nothing passes the whole suite. `RST_HWSTAT_DLY` (PPU, wave two),
`TINIT_WAIT` (P-Channel controller, wave six), and the PPU's `PCSM_TINIT_WAIT`.

Rather than wait for a fourth, this is the full enumeration. A duration is only
"measured" if some named check counts cycles and would fail if the value were
collapsed.

| Parameter | Layer | Values built | Status |
|---|---|---|---|
| `ISO_CLKEN_DLY` | PPU | 2, 6 | **measured** — wave two W5 |
| `CLKEN_RST_DLY` | PPU | 2, 7 | **measured** — wave two W6 |
| `RST_HWSTAT_DLY` | PPU | 2, 5, 60 | **measured** — P33a *(was a gap)* |
| `CLKEN_ISO_DLY` | PPU | 2, 3 | **measured** — wave one M13 |
| `ISO_RST_DLY` | PPU | 2, 4 | **measured** — wave one M7 |
| `PPU_EDTR0/1` entry delays | PPU | 0, 0x60, 0x64 | **measured** — `ppucfg` M5 times `DEVQREQn`; P33b |
| `PCSM_TINIT_WAIT` | PPU | 16, 200 | **measured** — `ppurst` *(was a gap)* |
| `TINIT_WAIT` | P-Channel ctrl | 16, 32 | **measured** — B0 *(was a gap)* |
| `TINIT` | P-Channel device | 4 | **behaviourally bounded** — B1 proves denial is suppressed *during* tinit and honoured *after*, so both boundaries are pinned; the count itself is not timed |
| `TINIT` | `ppu_pcsm` | 4 | **unmeasured** — one value only. The PCSM's capture of `PCSMPSTATE` during tinit *is* covered (the F8 regression in `ppurst`); the duration is not |
| `PSTATE_LEAD_CYCLES` | P-Channel ctrl | 0, 5 | **measured** — `pch` B-1 *(was a gap)* |
| `PRE_SETTLE` / `POST_SETTLE` | P-Channel example | 8 / 4 | **unmeasured** — actuator pacing in the example layer, not a specification duration |
| `SYNC_STAGES` / `STAGES` | all three | 2 only | **not measurable in simulation.** Depth guards against metastability, which RTL simulation does not model, so changing it only shifts arrival by a cycle — wave five Q11 confirmed a one-stage synchronizer passes everything. The property is structural and its checker is `qchannel_lpi_check.tcl` / `ppu_lpi_check.tcl`'s `ASYNC_REG` counts, which need synthesis and have never run here |
| `SETTLE_CYCLES` | `ppu_monitor` | 16 | n/a — a checker tolerance, not a design duration |
| `CNT_W` | testbench workload | 8 | n/a — a width |

**Eight of the nine real durations are now measured.** The single remaining gap
is `ppu_pcsm`'s device-side `TINIT`, named above with its reason: the PCSM's
*capture* of `PCSMPSTATE` during tinit is covered by the F8 regression in
`ppurst`, only the length is not.

Four of those eight were gaps this audit found and closed — `RST_HWSTAT_DLY`,
`PCSM_TINIT_WAIT`, the P-Channel controller's `TINIT_WAIT`, and
`PSTATE_LEAD_CYCLES`.

### B-1, and an observer that measured the wrong thing first

`PSTATE_LEAD_CYCLES` needed its own controller/device pair rather than a
parameter change on the existing one, since altering the lead would shift the
timing of every other phase. The pair carries its own monitor too: a lead that
moved `PSTATE` outside `P_STABLE` would break rule PR3, and that has to be caught
rather than merely mis-timed.

The measurement was wrong on the first run — it reported **153 cycles instead of
6**. The observer armed on the first `PSTATE` change of the run, which is the
settle out of reset while its own delayed copy is still X, and then counted right
through tinit to the eventual request. It now stays clear until the testbench
baselines it immediately before issuing the request. Making the controller ignore
its lead parameter drops the measurement to 1 and fails the check.


## Re-soak after the audit

Every earlier soak in this project predates the audit: they ran before F9 was
fixed and before `ppu_monitor` U12, phases P31–P34 and the coverage collector
existed. A newly added always-on monitor rule is exactly the kind of thing that
passes the directed tests and then fires spuriously on random stimulus — U12 in
particular went through three wrong formulations before one bit — so the suite was
re-soaked with all of it in place.

| seed | iters | checks | errors | qchannel_monitor | ppu_monitor | power model | coverage |
|---|---|---|---|---|---|---|---|
| 3 | 300 | 537 | 0 | 5 | 0 | 0 | 0 gaps, 7/7 events |
| 7 | 300 | 537 | 0 | 5 | 0 | 0 | 0 gaps, 7/7 events |
| 99 | 500 | 538 | 0 | 5 | 0 | 0 | 0 gaps, 7/7 events |
| 20250815 | 500 | 537 | 0 | 5 | 0 | 0 | 0 gaps, 7/7 events |
| 1234 | 800 | 537 | 0 | 5 | 0 | 0 | 0 gaps, 7/7 events |
| 999 | 800 | 538 | 0 | 5 | 0 | 0 | 0 gaps, 7/7 events |

**3,200 random iterations, no failures.** Three things worth reading off it:

- **U12 raises no false positives.** It is a level-triggered rule on a mode
  transition pair, and the randomised phase drives policy, dynamic mode, lock,
  wake and workload bursts against each other. That is the stimulus most likely to
  find a wrong window, and it found none.
- **`qchannel_monitor` stays at exactly 5** in every run — the sanctioned
  violations (1 in P3, 2 in P15, 2 in P30), each covered by its own `check_int`.
  Not "about five"; the same five.
- **Coverage closes in every seed.** 13/13 transition pairs and 7/7 interrupt
  events regardless of the random sequence, which says the directed phases carry
  the coverage rather than the random one happening to stumble into it.

The check count moves between 537 and 538 because P26's drain is conditional on
whether a burst was left running — a real difference in what was generated, not
flakiness.

## Byte-lane write strobes (`ppube`)

`reg_wstrb[3:0]` is an extension: §6.2.1 makes the bus IMPLEMENTATION DEFINED and
its APB3 example carries no strobe, so nothing in the specification constrains
this and the suite is the only definition of correct.

Every other suite in this matrix drives `4'hF`. That proves the addition is
backward compatible, but it also means all of them would keep passing if the
strobe were dropped on the floor. `ppu_be_tb` therefore never writes a whole
word — every write in it masks at least one lane.

| Group | Register | Proves |
|---|---|---|
| **B1** | `PPU_PWPR`, `PPU_AISR`, `PPU_ISR` | `wstrb == 0` is not a write: no field moves, no W1C bit clears, and neither `UNSPT_POLICY_IRQ` nor `STA_POLICY_TRN_IRQ` fires |
| **B2** | `PPU_DCDR0` | three delays in three lanes, each moved alone; lane 3 is reserved and moves nothing; two lanes at once |
| **B3** | `PPU_EDTR0` | `FULL_RET_DEL` [31:24] — the only field in the top lane, so without this lane 3 is never proven to do anything |
| **B4** | `PPU_PWPR` | §4.1.1 admission across lanes: a lane-0 write is validated against the **held** `PWR_DYN_EN`, an unsupported policy in a masked lane is ignored, rejection still works through one lane, and `LOCK_EN` [12] rides with lane 1 |
| **B5** | `PPU_IMR` | ordinary read-write: a masked lane keeps its bits rather than being zeroed |
| **B6** | `PPU_ISR` | write-1-to-clear per lane: the events [3:0] and `PWR_ACTIVE_EDGE` [8] clear independently, which a merge implementation cannot do |
| **B7** | `PPU_UNLK` | the key is [0]; a write with lane 0 masked carries no key and does not unlock |
| **B8** | `PPU_PWCR` | `DEVREQEN` [0] and `PWR_DEVACTIVEEN` [8] clear independently |

### Non-vacuity

Eleven mutations, all killed:

| Mutation | Caught by |
|---|---|
| strobe never wired (tied `4'hF` at both sinks) | 17 checks across **all eight** groups |
| `wstrb == 0` still counts as a write | B1 |
| `PPU_PWPR` admitted on raw `wdata` rather than the merge | B4 (×3) |
| `PWR_DYN_EN` taken from `wdata` regardless of lane 1 | B4 |
| `PPU_IMR` overwrites masked lanes with zero | B5 |
| `PPU_ISR` W1C done as a read-modify-write merge | B6 |
| `PPU_DCDR0` lane-2 gate removed | B2 (×3) |
| `PPU_EDTR0` lane-3 gate removed | B3 |
| `PPU_UNLK` key accepted without lane 0 | B7 |
| `PPU_PWCR` lane-1 gate removed | B8 |
| `PPU_PWPR` `LOCK_EN` lane-1 gate removed | B4 |

## The denial path (`ppudeny`)

A `ppu_seq` **unit** testbench, and the only PPU suite that drives the sequencer
directly. A denial in `ppu_pd_tb` depends on a workload happening to be busy at
the right moment, which makes it hard to place and impossible to hold; here the
denial goes exactly where the test wants it and the recovery can be stretched so
that what the sequencer does *during* it is observable.

**It presents nothing the Q-Channel specification does not define.** `ppu_seq`
consumes the decoded channel, so raising `dev_qdeny` at any convenient moment
would be trivial — and is not a legitimate test. AMBA LPI Table 2-1 reaches
`Q_DENIED` only from `Q_REQUEST`, and `qchannel_monitor` already enforces what
follows (**R6** `QDENY 0→1` only in `Q_REQUEST`, **R5** `QDENY 1→0` only once
the request is withdrawn). A denial outside that window is a protocol violation
by the *device*, and no specification says what a PPU does in response, so an
assertion about it would pin down this implementation's accidental behaviour
rather than check a required one — and would fail a different, equally
conformant PPU.

So `dev_qdeny` is owned by a channel model that follows Table 2-1. A test **arms**
a denial; the model decides whether the protocol permits one, and holds it until
the request is withdrawn rather than pulsing it for a cycle, which R5 forbids.

| Group | Proves |
|---|---|
| **D2** | a denial moves **no** device control and raises no `PCSMPREQ` — the measurement behind §4.2.9's "nothing to reverse" (Figure 4-35) |
| **D3** | Table 4-1 static reversion: `revert_policy` **at the pulse** is `cur_mode`, `revert_dyn_en` is the value from transition start |
| **D4** | the sequencer stays in `S_DENIED` until `Q_RUN`, so it cannot re-request into the middle of the channel's own `Q_DENIED → Q_CONTINUE → Q_RUN` recovery |
| **D5** | Table 4-1 with `PWR_DYN_STATUS` HIGH: `DYN_DENY_IRQ` instead of `STA_DENY_IRQ`, and **nothing** reverted |
| **D6** | a denial armed across an entire climb never fires — the exit path `Q_STOPPED → Q_EXIT → Q_RUN` has no `Q_DENIED` state (AMBA LPI Table 2-1) |
| **D7** | §4.1.2's third completion condition: a denied transition still raises `STA_POLICY_TRN_IRQ` when `PPU_PWPR` was written mid-flight to the current mode — with the negative case alongside it |
| **D8** | a disabled channel (§4.1.3, `DEVQREQn` permanently HIGH) cannot be denied at all |
| **D9** | the sequencer is usable immediately after a denial |
| **D10** | **the reverted policy is not re-requested** — the F10 regression |

### F10, found while writing D9

D9 was written to check something mundane — that the next request works — and
would not go idle. The cause was a real defect: after a denial the sequencer read
`pwr_policy` one cycle stale and re-launched the transition §4.1.1 had just
reverted. On the full stack a single denied request for `OFF` produced
`ON → OFF → ON`.

Two things are worth recording.

**The whole existing suite passes with the defect present.** Reintroducing it
leaves all 17 other suites green. The spurious round trip returns to where it
started, so every check that asserts an end state is satisfied by it — the same
blind spot that hid F9.

**D10 therefore checks that no transition STARTS**, not where the PPU ends up.
Checking the end state would pass either way. Reintroducing the defect fails 11
checks across D2, D4, D9 and D10.

## PPU ↔ device interaction (`ppudevif`)

Every other PPU suite is organised by **behaviour** — a phase drives a scenario
and checks what happens. This one is organised by **sentence**: each group quotes
one normative statement the specification makes about how the PPU and the device
interact, and checks that statement and nothing else.

The difference is what it can catch. A behaviour-organised suite tells you the
design works; it cannot tell you which of the specification's claims have never
been exercised, because nothing in it is indexed by claim. With this file,
"is statement X checked?" is answerable by grep.

| Group | Statement |
|---|---|
| **C1** | §3.4.2 *"For transitions from ON, other than to WARM_RST, all DEVQACTIVE inputs must be LOW to **begin** a transition"* — checked as `DEVQREQn` never falling, not merely as not arriving |
| **C2** | §3.4.2 *"The power mode DEVACTIVE inputs do not delay transitions to higher priority power modes"* |
| **C3** | §3.4.2 *"…even if the PPU must go through an intermediate power mode"* — the spec's own `FULL_RET → OFF` example, run literally. The statement **F9** violated |
| **C4** | §3.4.2 *"For transitions between ON and WARM_RST there is no dependence on the DEVQACTIVE inputs"* — both directions |
| **C5** | §3.4.1 *"Disabled power mode DEVACTIVE inputs are always assumed to be LOW for the purposes of transition control"* |
| **C6** | §4.1.3 *"These enables have no effect on the generation of interrupts"* |
| **C7** | §4.1.3 *"Q-Channel: DEVQREQn is driven permanently HIGH… transitions continue without issuing requests or waiting for responses"* — both halves |
| **C8** | Table 4-4, **all three rows**: the handshake happens only when `DEVREQEN` **and** `WARM_RST_DEVREQEN` are both set |
| **C9** | §3.4.3 *"When in ON, all DEVQACTIVE signals set LOW starts a transition to the programmed power mode policy. When in the programmed power mode policy, a HIGH level on any DEVQACTIVE input starts a transition to ON"* — with no policy write in either direction |
| **C10** | §3.4.3 *"Dynamic transitions to and from this power mode are not supported for a Q-Channel PPU"* — refused with `UNSPT_POLICY_IRQ`, not silently ignored |
| **C11** | §3.4.2 again, but with `DEVQACTIVE` arriving **mid-route**: swept across the whole `FULL_RET → ON → OFF` sequence |

### Non-vacuity

Eleven mutations, each caught by the group that owns its statement:

| Mutation | Caught by |
|---|---|
| departures never wait for `DEVQACTIVE` | C1, C3 |
| intermediate hop unguarded (the **F9** defect) | C3 |
| `DEVQACTIVE` wrongly delays a **rise** too | C2 |
| `WARM_RST` not exempt from `DEVQACTIVE` | C4 |
| disabled `DEVACTIVE` not assumed LOW | C5 |
| the enable wrongly gates the interrupt too | C6 |
| channel disable ignored | C7, C8 |
| `WARM_RST_DEVREQEN` ignored | C8 |
| `DEVREQEN` ignored on the `WARM_RST` row | C8 |
| dynamic never rises on `DEVQACTIVE` | C9 |
| dynamic `WARM_RST` wrongly supported | C10 |

**C2 was vacuous when first written** and the campaign is what found it. It set
`wake` and wrote the policy immediately, so the climb began before `DEVQACTIVE`
had propagated through the synchronizer — the check passed against a design that
blocked rises too. It now waits for the sequencer's own `qactive_eff` to be HIGH
before writing, and confirms it is still HIGH afterwards.

### C11 and the commit-edge invariant

C1 and C3 have `DEVQACTIVE` already HIGH when the policy is written. C11 covers
the race they cannot reach: it rises at cycle *d* of the route, for every *d*, so
it lands before the climb commits, during the climb, at the arrival in `ON`, and
after the departure from `ON` has already begun.

**The correct outcome differs across that range**, which is the point:

| when `DEVQACTIVE` rises | result |
|---|---|
| before the descent commits | the PPU parks in `ON` and waits |
| after the descent is under way | it completes to `OFF` — and must, because §3.3.1 makes raising the mode on hardware signalling a *dynamic* behaviour, so a static policy is never raised by `DEVACTIVE` |

The measured sweep hits both sides (9 early, 4 late) and the group asserts that
it does — a sweep that only reached one side would prove half of what it claims.

So the check is **not** the end state. §3.4.2 constrains when a transition may
*begin*; an end-state check would flag the second row above as a violation. The
first version of this probe did exactly that and reported 24 false anomalies.

What is checked instead is a **commit-edge invariant**, watched continuously for
the whole file rather than only inside C11: at the moment the sequencer leaves
`S_IDLE` for any hop, a static descent must never begin with `DEVQACTIVE` HIGH.
Removing `sta_block` fires it directly, on top of failing C1, C3 and C11.

### Deliberately not checked

§4.1.3 also says that when a channel is disabled *"the corresponding DEVACCEPT
and DEVDENY inputs are ignored"*. A conformant device never asserts those while
`DEVQREQn` is HIGH, so no legal stimulus distinguishes "ignored" from "never
arrived". The observable half — `DEVQREQn` stays HIGH and the transition proceeds
without waiting — is C7.

Emulation-mode `DEVACTIVE` effects (§3.4.1, §3.4.2, §3.4.3) and every P-Channel
rule are out of scope for this configuration. Device-control **ordering**
(§4.1.5) belongs to `ppu_pd_tb` P2 and P21–P25; denial belongs to `ppu_deny_tb`.

## The clock controller (`ppuclkctrl`)

DUT is [`ppu_clk_ctrl`](../../rtl/ppu/ppu_clk_ctrl.sv), driven directly. It has
no power domain of its own — it is the block that removes a clock, not one that
loses a supply — so there is no power-aware counterpart, for the same reason as
`ppuirq`, `ppupm` and `ppuneg`.

Organised by **sentence**, like `ppudevif`. The statements come from three
documents and the table says which:

| Group | Statement |
|---|---|
| **K0** | LPI §2.1.2 *"At reset assertion a device must drive both QACCEPTn and QDENY LOW"* — the CLK-CTRL is a device on `hc_*`/`pwr_*`. Plus `clken_o` resetting HIGH, and reset exited via `Q_STOPPED` with `QREQn` LOW |
| **K1** | PCK-600 §3.5 *"When all the Q-Channels are in the quiescent state, the CLK‑CTRL sets clken_o LOW, to stop the clock"* |
| **K2** | PCK-600 §3.5 *"When any clk_qactive_i goes HIGH, the CLK‑CTRL enables the clock and moves **all** the device Q-Channels to the running state"* — one device asks, all four must move |
| **K3** | LPI §4.1.3, the QACTIVE-only device: a veto with no handshake, on `clk_qactive_i[NUM_Q_CHL+]` |
| **K4** | Table A-25 *"0-255 clk cycles of hysteresis to the quiescence entry"* — measured as a **difference** between settings, so the fixed pipeline latency cannot flatter it |
| **K5** | Table A-25 *"You can disable the clock gating feature by setting clk_force_i HIGH"* |
| **K6** | Table A-26 `dftcgen` — acts on the gate only, leaving the handshake in `Q_STOPPED`, which is what distinguishes it from `clk_force_i` |
| **K7** | LPI §4.1.2 *"the solution must retain dedicated and independent handshake interfaces between each device and the controller"* — device 1 refuses while 0, 2 and 3 accept; its retry **rate** is bracketed from both sides |
| **K8** | Table A-22 `hc_qreqn_i`/`hc_qacceptn_o`, including the case where the request arrives while the devices are still **running**, checked on the edge `hc_qacceptn_o` falls |
| **K9** | Table A-22 `hc_qactive_o` *"when one or more CLK‑CTRL devices are active"*, and Table 3-7's *"The path from a device to the controller QACTIVE is combinatorial"* |
| **K10** | The upstream hold: once accepted, local activity raises `hc_qactive_o` and waits, rather than restarting the domain behind the upstream controller's back |
| **K11** | Table A-22 `hc_qdeny_o` — a downstream device's refusal relayed across two channels |
| **K12** | Table A-23, the whole sequence again on `pwr_*` alone, with `hc_*` parked in `Q_RUN` |
| **K13** | The two continuous invariants, over every cycle of every group: LPI §3.1 *"Only remove clock or power when the interface is in the Q_STOPPED state"*, and LPI §2.1.2's `Q_EXIT` guarantee |
| **K15** | A device that refuses and then **relents** is asked again — the retry backoff. See the defect note below |
| **K14** | `qchannel_monitor` on all six Q-Channels |
| **M1** | Table 3-7 `ACTIVE_DENY_EN` — the two DUTs given identical stimulus and **required to disagree** |
| **M2** | …and required to agree on the local activity-led policy, which the parameter does not name |

`u_min` is a second DUT with every Table 3-7 boolean **cleared** and both array
parameters at their minimum (`NUM_Q_CHL=1`, `NUM_QACTIVE_ONLY=0`). Without it
the false arm of six parameters would elaborate and never execute, which is the
gap `ppucfg` exists to close on the PPU side.

### The defect K15 exists for, and what K7 got wrong

`deny_seen` latches a device's refusal so the controller stops asking — LPI
§4.1.2's *"performance limitations"*. It used to clear only when `base_req`
fell. But `base_req` stays HIGH for as long as the domain is **idle**, which is
exactly when gating is wanted, so a device that refused once and then became
willing was **never asked again**: the channel stayed in `Q_RUN`, `all_stopped`
was never true, and `clken_o` stayed HIGH forever. No error, no protocol
violation, no symptom — the clock gating simply stopped working.

It hid because a device that denies usually *also* asserts `QACTIVE`, which
drops `base_req` and clears the latch as a side effect. That is a habit of
device design, not a guarantee, and `qchannel_device_comb` deliberately separates
`dev_deny` from `dev_active`.

**K7 was asserting the bug.** Its check read `qreqn_falls == 0` — "never
re-asked" — so it would have failed against a correct design. It now brackets
the retry rate from both sides: at least one attempt (no lockout) and at most 15
in 2000 cycles (no thrash; unbounded would be ~250). The fix is
`DENY_RETRY_DLY`, a parameter Table 3-7 does not have and the TRM gives no
guidance on.

### The device models are `qchannel_device_comb`, and they run on the gated clock

Both facts are load-bearing. `qchannel_device` registers `QACTIVE`, correctly,
because it was written for power control where the clock survives `Q_STOPPED`;
on a clock channel that is a deadlock, and every wake group here would hang.
And a testbench whose device models keep clocking while the DUT believes it has
stopped them proves nothing about K1 or K13.

### Non-vacuity

Three mutations of `ppu_clk_ctrl`, each caught:

| Mutation | Caught by |
|---|---|
| drop the exit interlock, so a device may leave `Q_STOPPED` before `clken_o` returns | K13, 28 violations |
| tie the hierarchical `dev_busy` LOW, so `hc_qacceptn_o` falls before the devices are quiescent | K8's edge check |
| drop `!all_stopped` from `clk_running`, so the gate closes before the devices have accepted | K13 (43144 violations), K10, K11, K12 and every `qchannel_monitor` |
| remove the `retry_now` re-arm from `deny_seen`, restoring the lockout | K15, both checks |

## The PPU clock Q-Channel (`ppuclkq`, `ppuclkqpa`)

Two DUTs, because the two halves of the claim need opposite kinds of stimulus.

`u_dev` is a bare [`ppu_pd_top`](../../rtl/ppu/ppu_pd_top.sv) with `PPUCLKQREQn`
driven by hand and its clock left running — the only way to put a quiescence
request in the middle of a power mode transition, which no conformant clock
controller would ever do and which denial is a claim about. Same argument as
`ppudeny`'s.

`u_top` is [`ppu_clkq_top`](../../rtl/ppu/ppu_clkq_top.sv): a real
`ppu_clk_ctrl` gating a real PPU's clock, with nothing driven by hand.

| Group | DUT | Statement |
|---|---|---|
| **C1** | `u_dev` | LPI §2.1.2 *"At reset assertion a device must drive both QACCEPTn and QDENY LOW"*, and *"If the device must perform start-up operations on exit from reset then it can reset QACTIVE HIGH"* — a PPU has §4.1.6's PCSM handshake and §4.2.1's default policy, so HIGH is the only correct answer |
| **C2** | `u_dev` | Table A-29 *"ppuclk_qacceptn_o … indicates when the PPU accepts a quiescence request to gate its clock"* |
| **C3** | `u_dev` | LPI §2.1.1 *"The denial mechanism means a device can maintain an operational state while having a mechanism by which it can promptly complete the handshake"* — requested mid-transition, `PPUCLKQDENY` HIGH, `PPUCLKQACCEPTn` never falls |
| **C4** | `u_dev` | LPI §2.1.2's `Q_CONTINUE` → `Q_RUN`, **and** that the interrupted transition still reached its destination |
| **C5** | `u_dev` | Table A-28 *"The PPU uses this wakeup signal as an input for the generation of the ppuclk_qactive_o signal"*, with the interface parked in `Q_STOPPED` — LPI §2.1.1's independence, made concrete |
| **C6** | `u_dev` | LPI §4.1.1 *"a QACTIVE contribution from the power control interface logic that is active whenever … transitions require CLK to be active"* — `DEVQACTIVE` reaching `PPUCLKQACTIVE` |
| **C7** | `u_dev` | §4.1.3: `PPU_PWCR.PWR_DEVACTIVEEN` cleared disconnects `DEVQACTIVE` from this decision too |
| **C8** | `u_dev` | Table A-29's Clock column: `PPUCLKQACCEPTn` is `clk` and does **not** answer in the same cycle |
| **G1** | `u_top` | The point of all of it: 0 PPU clock edges in 500 `aon_clk` cycles once the domain settles |
| **G2** | `u_top` | Table A-28's negative control — a register write with **no** `PWAKEUP` reaches no clock edge and is lost; the same write with `PWAKEUP` leading it takes effect |
| **G3** | `u_top` | **The central claim.** A wake with the PPU's clock stopped, requiring `PPUCLKQACTIVE` to rise with **zero** intervening clock edges, counted rather than assumed |
| **G4** | `u_top` | Register contents survive being gated, woken and gated again |
| **G5** | `u_top` | Table A-23: a hierarchical power request quiesces the PPU's own channel underneath it, and holds it there |
| **G6** | `u_top` | LPI §4.1.3: a QACTIVE-only device holds the PPU's clock on, invisibly to the PPU |
| **G7** | `u_top` | `clk_force_i` and `entry_delay_i` survived the integration — an unconnected port would pass every unit check and do nothing in the system |
| **G8** | both | Continuous invariants: `PPUCLKQACTIVE` HIGH in every non-idle cycle (LPI §4.1.1), the clock never removed mid-transition, and `qchannel_monitor` on both channels |

### Non-vacuity

The mutation that matters is one line: register `PPUCLKQACTIVE` in
`qchannel_device_comb` instead of driving it as a wire. Every check on `u_dev` still
passes. On `u_top`, G3's zero-edge count fails, the wake never happens, and G2,
G4 and G5 fail behind it — which is the honest consequence, because a PPU that
cannot be woken is a domain that never comes back.

`ppu_deny_tb` D11 carries the same invariant from the other side: `PPU_ACTIVE`
was HIGH in every non-idle sequencer cycle across all ten of its groups.

### Under power intent

`make ppuclkqpa` runs the whole file with `src/upf` applied. Two `ppu_pd_top`
instances get their own `PD_AON`/`PD_DEV` pair, one of them at the hierarchical
path `u_top/u_pd` — the first time the power intent is bound below the top
level. What it adds is G3's wake: with UPF, `DEVQACTIVE` genuinely leaves an
**unpowered** `PD_DEV` through the isolation clamp on its way to
`PPUCLKQACTIVE`. Without it, "domain OFF" is a domain held in reset and the
clamp is never exercised. Same 72 checks, same result.

## AXI4-Lite software interface (`ppuaxi`)

DUT is [`ppu_top_axi_lite`](../../rtl/ppu/ppu_top_axi_lite.sv) —
[`ppu_axi_lite_adapter`](../../rtl/ppu/ppu_axi_lite_adapter.sv) plus `ppu_top`,
with the testbench supplying what `ppu_pd_top` normally would (a PCSM and a
Q-Channel device) **and** a `ppu_clk_ctrl` gating the PPU's clock. That last
part is why the file exists in this form: groups L7 and L8 are about a bus
access arriving at a PPU whose clock has stopped, and nothing else in the suite
can reach that.

### The stimulus is not ours

Every AXI beat is driven by `axi_test::axi_lite_driver` from
[pulp-platform/axi](https://github.com/pulp-platform/axi), vendored verbatim
under [src/vendor/pulp/](../../vendor/pulp/). The bugs a bus bridge has are
handshake bugs, and a driver written by whoever wrote the bridge tends to drive
the handshake the way the bridge expects. This one applies stimulus at `TA` and
samples at `TT` rather than on the clock edge, which is what catches a design
that only works when everything moves together.

`make ppuaxi` is the only target that compiles third-party code, and the only
one that needs Xcelium for a reason other than UPF — the VIP is class-based
SystemVerilog. The **adapter** is plain RTL, is in `PPU_SRCS`, and elaborates
everywhere.

| Group | Statement |
|---|---|
| **L1** | IHI 0022 §A3.1.2: a subordinate must not drive `BVALID` or `RVALID` HIGH during reset. `READY` is unconstrained — see the note below |
| **L2** | A write and a read complete with `RESP_OKAY`; an **unmapped** address reads as zero with `OKAY`, because DEN 0051E §5.2 makes reserved space WI/RAZ rather than an error |
| **L3** | `reg_wen` and `reg_ren` HIGH in the **same cycle**. `ppu_top`'s port comment says the split bus exists "so an AXI4-Lite bridge can have one of each outstanding without arbitrating between them"; PULP's `axi_lite_to_reg` *must* arbitrate because a `reg_bus` has one address. This is the check that says we don't |
| **L4** | `WSTRB` reaches the register file — a bridge that tied it to `4'hF` would pass every other group |
| **L5** | §A3.2.1: `VALID` holds until the handshake, and `RDATA`/`BRESP` do not move while it waits |
| **L6** | PCK-600 Table A-28, both halves: `PWAKEUP` rises **before** `reg_wen`, and is still HIGH with the register access done and `B` outstanding |
| **L7** | **The point of the bridge.** An access to a PPU the clock controller has genuinely gated. Nothing driven by hand; `PWAKEUP` is the only thing that can bring the clock back |
| **L8** | A hierarchical power controller holds the domain quiescent, so the wake never comes → `RESP_SLVERR` rather than a hung system bus, with `RDATA` zeroed rather than the read latch's stale value |
| **L9** | 200 randomised transactions against three scratch registers with a shadow model, gating and ungating underneath |
| **L11** | **AXI + gated clock + a domain that really loses power.** On a second DUT, `ppu_axi_pd_top` — see below |
| **L12** | A clock that is **present but not guaranteed**: `clk_force_i` HIGH under an upstream hold. The bridge refuses. See below — this is the only group that distinguishes the two plausible definitions of `ppu_clk_ok` |
| **L13** | DEN 0051E Table 4-7: `DEVCLKEN` reaches a gate and actually stops the device clock — counted over a window, with every mode change commanded over AXI4-Lite through a clock-gated PPU |
| **L10** | Continuous: `VALID` never dropped without a handshake, payload never moved, and **no register strobe was ever issued with `ppu_clk_ok` or `PWAKEUP` LOW** |

### `DEVCLKEN` had nowhere to go

DUT 1 is `ppu_top_axi_lite`, which contains `ppu_top` and nothing else, so the
device side `ppu_pd_top` normally supplies has to be built in the testbench.
`DEVCLKEN` was left **dangling** — this file drove a PPU through every power
mode without its clock enable reaching anything.

It is now `dclk` + `dev_clken` → `cdc_sync` → `clk_gate` → `dev_clk`, with an
edge counter on the far side. The `cdc_sync` is not decoration: `DEVCLKEN` is
driven in the `aclk` domain and gates a `dclk`-domain clock, and the two are
asynchronous here (10 ns against 14 ns) — the case §4.1.5 warns about when
choosing `CLKEN_RST_DLY`.

The Q-Channel wrapper stays on **ungated** `dclk`, matching `ppu_pd_top`'s
deliberate choice: it has to survive the domain going down or `DEVQACTIVE` is
stuck LOW and a wake can never revive it. Moving it onto `dev_clk` would look
tidier and would break that.

Non-vacuity: tying the gate open (`clk_en = 1'b1`, i.e. the old dangling
behaviour) fails L13 with 357 edges where 0 are expected, and fails nothing else.

### Two DUTs, and why the second one had to be written

`u_dut` is `ppu_top_axi_lite` — the adapter over `ppu_top`. That is the shape
asked for and the right one for integration, and it has one consequence that
only appears when you try to run it under IEEE 1801: **`ppu_top` has no power
domain.** `ppu_pd_top.upf` creates `PD_AON`/`PD_DEV` inside `ppu_pd_top`, so
there is nothing to bind to, and L1–L10 can only ever run with the intent
absent.

That left a three-way gap:

| | gated clock | `PD_DEV` really unpowered | software interface |
|---|---|---|---|
| `ppuclkqpa` | yes | **yes** | generic strobe |
| `ppuaxi` L1–L10 | yes | no domain at all | **AXI4-Lite** |
| `ppuaxipa` L11 | yes | **yes** | **AXI4-Lite** |

Only the third has all three, and all three at once is the ordinary condition of
a real SoC: software reaching a PPU over AXI, the PPU's own clock stopped, and
the domain it manages with its supply removed. `u_pd_dut` is
[`ppu_axi_pd_top`](../../rtl/ppu/ppu_axi_pd_top.sv) — the same adapter over
`ppu_pd_top`, adding no logic beyond the same `Q_RUN` decode.

L11 walks `ON → OFF → MEM_RET → ON → FULL_RET → ON` entirely over AXI4-Lite,
with the PPU's clock stopping between every access, and reads `PPU_PWSR` back
each time. Under `make ppuaxipa` those three low-power modes are physically
distinct instead of three names for "held in reset".

**The expected result is that the power intent changes nothing** — the adapter,
the PPU and the PCSM are all in `PD_AON`, which never loses power, so the count
is 51 checks either way. That is the point rather than a weakness, and it is the
same argument `ppu_be_tb.upf`'s header makes: a bus bridge whose behaviour
changed when a domain *below* it was power-gated would be a real finding, and
nothing else in the suite is positioned to notice.

### L1 was wrong first, and the reason is worth keeping

Its first version asserted that no channel was `READY` under reset. That is a
rule AXI does not have — §A3.1.2 constrains only `BVALID` and `RVALID` — and it
failed against correct RTL. `ARREADY` **is** HIGH under reset here, because
`R_IDLE` is the reset state and `ARREADY` is decoded from it, and that is
harmless because the master is required to hold `ARVALID` LOW through reset.

It looked plausible because `AWREADY` and `WREADY` *are* LOW, being qualified by
their `VALID`s, so only `ARREADY` ever shows the difference.

This also forced a correction elsewhere: **IHI 0022 is not in
`references/standards`.** Every AXI clause cited in the adapter and this
testbench is therefore given by section and paraphrased, never quoted — unlike
the LPI, PPU and PCK-600 quotations elsewhere in this repository, which were
read out of the documents.

### `ppu_clk_ok` — `Q_RUN`, not `clken_o`, and L12 is why

Driving `ppu_clk_ok` from `ppu_clk_ctrl`'s `clken_o` is the obvious
simplification: the gate enable is right there in `ppu_axi_pd_top` and it says
whether the clock is *running*. It was tried, and **it passed all 51 other
checks in this file.**

The two come apart in exactly one state. `clk_running` is

```
clk_force_i | dftcgen | !base_req | !all_stopped
```

so with an upstream controller holding the domain quiescent (`up_hold` pinning
`base_req` HIGH) *and* `clk_force_i` asserted, `clken_o` is HIGH while the PPU's
channel sits in `Q_STOPPED`. The clock is **present**. It is not **guaranteed**.

The bridge refuses, because Table A-25 makes `clk_force_i` asynchronous and
nothing coordinates it with an access in flight — it can deassert
mid-transaction and the clock vanishes with no handshake. `Q_RUN` cannot do
that: removing the clock needs a `Q_REQUEST`, and the PPU denies that while
`PWAKEUP` is HIGH, so the bridge holds a veto over its own clock. The cost is
that `Q_RUN` lags `clken_o` by the exit handshake, so every access to a gated
PPU pays a few extra cycles.

L12 asserts the refusal. With `ppu_clk_ok = clken` it fails and nothing else
does, which is the whole point of having it.

### Non-vacuity

One mutation, on the line the whole bridge is about: send the captured
transaction straight to `W_ACCESS`/`R_ACCESS` instead of through `W_WAIT`/`R_WAIT`,
removing the clock interlock. Caught five ways:

| | |
|---|---|
| **L10** | 78 register strobes issued with `ppu_clk_ok` LOW |
| **L9** | 16 of 200 randomised transactions returned wrong data |
| **L7** | the gated write silently landed the *previous* group's value, `0x33` |
| **L8** | no timeout, so no `SLVERR` — the bus would have hung |
| **L6** | `PWAKEUP` and `reg_wen` rose in the same instant instead of in order |
