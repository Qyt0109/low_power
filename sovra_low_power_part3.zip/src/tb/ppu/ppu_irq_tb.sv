`timescale 1ns/1ps
// ppu_irq unit testbench -- the interrupt rules that need cycle-exact stimulus.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Section 4.1.2 "PPU Interrupt".
//
// WHY A UNIT TEST RATHER THAN ANOTHER PHASE IN ppu_pd_tb
//
// Section 4.1.2 ends with a rule that the system testbench structurally cannot
// exercise:
//
//   "If an event is cleared in the same cycle that it re-occurs the interrupt
//    status stays HIGH, so the re-occurrence is observed."
//
// Clearing a status bit is a register write. In ppu_pd_tb every event that can
// set a bit is itself produced by a register write -- programming a policy,
// requesting an unsupported mode -- and the bus is single-ported, so the clear
// and the event can never land on the same edge. The one event with an
// independent source, the DEVQACTIVE edge, arrives through two synchronizers
// and the device's own clock, so its timing relative to a bus write is not
// controllable to a cycle.
//
// A mutation swapping the set and clear order --
//
//   isr_q <= (isr_q & ~clear) | isr_set;   ->   isr_q <= (isr_q | isr_set) & ~clear;
//
// therefore survived the entire suite. It is a real defect: an event that
// arrives on the same edge as its own clear would be silently dropped, and the
// software that cleared it would never learn the event re-occurred.
//
// Driving ppu_irq directly makes the collision trivial to produce, because
// ev_* and wr_isr are both just inputs.
//
// WHAT ELSE IS HERE
//
// The other Section 4.1.2 rules, checked at the unit level where each one is a
// single stimulus rather than a system-level scenario: masking suppresses the
// status bit rather than only the output, the IRQ output is the OR of both
// status registers, and PPU_ISR.OTHER is derived from PPU_AISR rather than
// stored.

module ppu_irq_tb;

  import ppu_pkg::*;

  logic clk = 1'b0;
  always #5 clk = ~clk;

  logic rst_n = 1'b0;
  logic wr_imr = 0, wr_aimr = 0, wr_isr = 0, wr_aisr = 0, wr_iesr = 0;
  logic [31:0] wdata = 32'h0;
  logic [3:0]  wstrb = 4'hF;   // whole-word writes; byte lanes are ppu_be_tb's job
  logic [31:0] imr, aimr, isr, aisr, iesr;
  logic ev_sta_policy_trn = 0, ev_sta_accept = 0, ev_sta_deny = 0;
  logic ev_locked = 0, ev_dyn_accept = 0, ev_dyn_deny = 0, ev_unspt_policy = 0;
  logic dev_qactive = 0;
  logic irq;

  int unsigned checks = 0, errors = 0;

  ppu_irq u_dut (
    .clk(clk), .rst_n(rst_n),
    .wr_imr(wr_imr), .wr_aimr(wr_aimr), .wr_isr(wr_isr),
    .wr_aisr(wr_aisr), .wr_iesr(wr_iesr), .wdata(wdata), .wstrb(wstrb),
    .imr(imr), .aimr(aimr), .isr(isr), .aisr(aisr), .iesr(iesr),
    .ev_sta_policy_trn(ev_sta_policy_trn), .ev_sta_accept(ev_sta_accept),
    .ev_sta_deny(ev_sta_deny), .ev_locked(ev_locked),
    .ev_dyn_accept(ev_dyn_accept), .ev_dyn_deny(ev_dyn_deny),
    .ev_unspt_policy(ev_unspt_policy), .dev_qactive(dev_qactive),
    .irq(irq)
  );

  task automatic check(input bit cond, input string tag);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s", $time, tag); end
      else            $display("[%0t]  ok  %0s", $time, tag);
    end
  endtask

  // One clocked write, with the event lines held at whatever the caller set.
  task automatic wr(input logic [11:0] which, input logic [31:0] d);
    begin
      @(negedge clk);
      wdata  = d;
      wr_imr = which[0]; wr_aimr = which[1]; wr_isr = which[2];
      wr_aisr = which[3]; wr_iesr = which[4];
      @(negedge clk);
      wr_imr = 0; wr_aimr = 0; wr_isr = 0; wr_aisr = 0; wr_iesr = 0;
    end
  endtask

  initial begin
    $dumpfile("ppu_irq_tb.vcd");
    $dumpvars(0, ppu_irq_tb);
    $display("==============================================================");
    $display(" ppu_irq unit test (Section 4.1.2)");
    $display("==============================================================");

    repeat (4) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    repeat (2) @(posedge clk);

    // Unmask everything writable so the events reach the status registers.
    wr(12'h001, 32'h0000_0000);   // PPU_IMR  = 0
    wr(12'h002, 32'h0000_0000);   // PPU_AIMR = 0

    // ---- Baseline: an ordinary event sets its bit, a write clears it ----
    @(negedge clk) ev_sta_deny = 1'b1;
    @(negedge clk) ev_sta_deny = 1'b0;
    repeat (2) @(posedge clk);
    check(isr[ISR_STA_DENY] === 1'b1, "STA_DENY sets PPU_ISR[2]");
    check(irq === 1'b1,               "IRQ follows PPU_ISR");
    wr(12'h004, 32'b1 << ISR_STA_DENY);
    repeat (2) @(posedge clk);
    check(isr[ISR_STA_DENY] === 1'b0, "write-1-to-clear clears PPU_ISR[2]");
    check(irq === 1'b0,               "IRQ drops when both status registers are empty");

    // ---- THE RULE: clear and re-occurrence on the same edge ----
    $display("");
    $display("[%0t] Section 4.1.2: 'If an event is cleared in the same cycle", $time);
    $display("[%0t] that it re-occurs the interrupt status stays HIGH, so the", $time);
    $display("[%0t] re-occurrence is observed.'", $time);
    $display("[%0t] Set the bit, then drive the event and its clear on the SAME", $time);
    $display("[%0t] edge. The bit must survive.", $time);

    @(negedge clk) ev_sta_deny = 1'b1;
    @(negedge clk) ev_sta_deny = 1'b0;
    repeat (2) @(posedge clk);
    check(isr[ISR_STA_DENY] === 1'b1, "collision setup: PPU_ISR[2] is set");

    @(negedge clk);
    ev_sta_deny = 1'b1;                       // event and
    wdata       = 32'b1 << ISR_STA_DENY;      // clear
    wr_isr      = 1'b1;                       // on the same edge
    @(negedge clk);
    ev_sta_deny = 1'b0; wr_isr = 1'b0;
    repeat (2) @(posedge clk);
    check(isr[ISR_STA_DENY] === 1'b1,
          "PPU_ISR[2] stays SET when the clear collides with a re-occurrence");
    check(irq === 1'b1, "IRQ stays HIGH through the collision");

    wr(12'h004, 32'b1 << ISR_STA_DENY);
    repeat (2) @(posedge clk);
    check(isr[ISR_STA_DENY] === 1'b0, "and a clear with no collision still works");

    // Same rule on the additional status register, which has its own assignment.
    @(negedge clk) ev_dyn_deny = 1'b1;
    @(negedge clk) ev_dyn_deny = 1'b0;
    repeat (2) @(posedge clk);
    check(aisr[AISR_DYN_DENY] === 1'b1, "collision setup: PPU_AISR[2] is set");
    @(negedge clk);
    ev_dyn_deny = 1'b1;
    wdata       = 32'b1 << AISR_DYN_DENY;
    wr_aisr     = 1'b1;
    @(negedge clk);
    ev_dyn_deny = 1'b0; wr_aisr = 1'b0;
    repeat (2) @(posedge clk);
    check(aisr[AISR_DYN_DENY] === 1'b1,
          "PPU_AISR[2] stays SET when the clear collides with a re-occurrence");

    // ---- OTHER is derived from PPU_AISR, not stored ----
    check(isr[ISR_OTHER] === 1'b1, "PPU_ISR.OTHER reflects a set PPU_AISR bit");
    wr(12'h004, 32'b1 << ISR_OTHER);
    repeat (2) @(posedge clk);
    check(isr[ISR_OTHER] === 1'b1,
          "PPU_ISR.OTHER is derived, so writing 1 to it does not clear it");
    wr(12'h008, 32'b1 << AISR_DYN_DENY);
    repeat (2) @(posedge clk);
    check(isr[ISR_OTHER] === 1'b0, "clearing the PPU_AISR bit clears OTHER");
    check(irq === 1'b0,             "and the IRQ drops with it");

    // ---- Masking suppresses the STATUS BIT, not just the output ----
    wr(12'h001, 32'b1 << ISR_STA_DENY);      // mask STA_DENY
    @(negedge clk) ev_sta_deny = 1'b1;
    @(negedge clk) ev_sta_deny = 1'b0;
    repeat (2) @(posedge clk);
    check(isr[ISR_STA_DENY] === 1'b0,
          "a masked event does not set its status bit at all");
    check(irq === 1'b0, "and raises no interrupt");

    $display("");
    $display("==============================================================");
    $display(" ppu_irq_tb: %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    repeat (100000) @(posedge clk);
    $display(" RESULT: FAIL");
    $fatal(1, "ppu_irq_tb watchdog");
  end

endmodule
