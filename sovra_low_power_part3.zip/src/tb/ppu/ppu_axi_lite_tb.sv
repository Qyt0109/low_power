`timescale 1ns/1ps
// ppu_top_axi_lite, driven by an independent AXI4-Lite VIP.
//
// References:
//   AMBA AXI and ACE Protocol Specification (ARM IHI 0022)
//     Section A3.1.2  reset: a subordinate must not drive BVALID or RVALID HIGH
//     Section A3.2.1  VALID, once asserted, holds until the handshake, and its
//                     payload does not change while it waits
//     Section A3.3.1  handshake dependencies -- a subordinate may wait for
//                     AWVALID, WVALID or both before asserting AWREADY
//     Table A3-4      RESP encodings
//
// UNLIKE EVERY OTHER SPECIFICATION THIS REPOSITORY CITES, IHI 0022 IS NOT IN
// references/standards. The AXI clauses above are therefore cited by section
// and PARAPHRASED, never quoted -- the LPI, PPU and PCK-600 quotations
// elsewhere in this repository were read out of the documents, and it would be
// dishonest for these to look the same. Group L1 below is what that distinction
// already cost: its first version checked a reset rule AXI does not have.
//   Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E)
//     Section 5.2     reserved and unmapped registers are WI/RAZ
//     Section 6.2     "The type of bus interface used is IMPLEMENTATION DEFINED"
//   Arm CoreLink PCK-600 TRM (101150) Tables A-28, A-29
//   AMBA Low Power Interface Specification (ARM IHI 0068C) Section 2.1.2
//
// THE STIMULUS IS NOT MINE
//
// Everything on the AXI side is driven by axi_test::axi_lite_driver from
// pulp-platform/axi, vendored under src/vendor/pulp (see the README there for
// provenance and licence). That is a deliberate choice rather than a
// convenience: the bugs a bus bridge has are handshake bugs, and a driver
// written by the same person who wrote the bridge tends to drive the handshake
// the way the bridge expects. This one has been run against a great many AXI
// slaves that were not this one, and it inserts its stimulus at TA and samples
// at TT rather than at the clock edge, which is what catches a design that only
// works when everything moves together.
//
// THE DUT IS THE WHOLE LOOP, NOT JUST THE BRIDGE
//
// ppu_top_axi_lite contains ppu_top, so the testbench has to supply what
// ppu_pd_top normally would -- a PCSM and a Q-Channel device -- and it also
// supplies a ppu_clk_ctrl gating the PPU's clock. That last one is the reason
// this file exists in the form it does: groups L7 and L8 are about a bus access
// arriving at a PPU whose clock has stopped, which is the case the bridge is
// built for and the only one a plain register testbench cannot reach.
//
//   aclk (free-running) ──┬──► ppu_axi_lite_adapter ─┐  inside the DUT
//                         │                          │
//                         └──► ppu_clk_ctrl ──► gate ┴──► clk ──► ppu_top
//                                    ▲                              │
//                                    └────────── PPUCLK* ───────────┘

module ppu_axi_lite_tb;

  import ppu_pkg::*;
  import qchannel_pkg::*;
  import axi_pkg::*;

  localparam int unsigned AW = 32;
  localparam int unsigned DW = 32;

  // Stimulus application and sampling times, offset from the clock edge in both
  // directions. The driver applies at TA and samples at TT; edge-aligned
  // stimulus would hide exactly the races this VIP exists to find.
  localparam time TCLK = 10ns;
  localparam time TA   = 2ns;
  localparam time TT   = 8ns;

  // Small on purpose. The real wake takes about four cycles, so 64 is ~16x
  // margin for the ordinary path while keeping group L8 short.
  localparam int unsigned WAKE_TIMEOUT = 64;

  logic aclk = 1'b0;
  always #(TCLK/2) aclk = ~aclk;

  logic dclk = 1'b0;
  always #7 dclk = ~dclk;

  logic aresetn = 1'b0;

  // ===========================================================================
  // The AXI4-Lite link
  // ===========================================================================
  AXI_LITE_DV #(.AXI_ADDR_WIDTH(AW), .AXI_DATA_WIDTH(DW)) axi (aclk);

  typedef axi_test::axi_lite_driver #(.AW(AW), .DW(DW), .TA(TA), .TT(TT)) drv_t;
  drv_t drv = new(axi);

  // ===========================================================================
  // The clock controller, gating the PPU's clock
  // ===========================================================================
  logic ppuclk_qreqn, ppuclk_qacceptn, ppuclk_qdeny, ppuclk_qactive;
  logic ppu_clken, ppu_clk;

  logic hc_qreqn = 1'b1;
  logic hc_qacceptn, hc_qdeny, hc_qactive;
  logic clk_force = 1'b0;

  ppu_clk_ctrl #(
    .NUM_Q_CHL       (1),
    .NUM_QACTIVE_ONLY(0),
    .SYNC_STAGES     (2)
  ) u_clkctrl (
    .clk    (aclk),
    .reset_n(aresetn),

    .hc_qreqn_i    (hc_qreqn),
    .hc_qacceptn_o (hc_qacceptn),
    .hc_qdeny_o    (hc_qdeny),
    .hc_qactive_o  (hc_qactive),

    .pwr_qreqn_i   (1'b1),
    .pwr_qacceptn_o(),
    .pwr_qdeny_o   (),
    .pwr_qactive_o (),

    .clk_qreqn_o   (ppuclk_qreqn),
    .clk_qacceptn_i(ppuclk_qacceptn),
    .clk_qdeny_i   (ppuclk_qdeny),
    .clk_qactive_i (ppuclk_qactive),

    .clken_o      (ppu_clken),
    .clk_force_i  (clk_force),
    .entry_delay_i(8'd0),
    .dftcgen      (1'b0)
  );

  clk_gate u_gate (
    .clk      (aclk),
    .clk_en   (ppu_clken),
    .gated_clk(ppu_clk)
  );

  // ===========================================================================
  // The DUT
  // ===========================================================================
  logic [15:0] ppuhwstat, pcsm_pstate;
  logic        dev_clken, dev_poresetn, dev_retresetn, dev_warmresetn, dev_isolaten;
  logic        pcsm_preq, pcsm_paccept;
  logic [7:0]  pcsm_modestat;
  logic        dev_qreqn, dev_qacceptn, dev_qdeny, dev_qactive;
  logic        irq;

  ppu_top_axi_lite #(
    .DEF_PWR_POLICY(PM_ON),
    .SYNC_STAGES   (2),
    .AXI_ADDR_W    (AW),
    .WAKE_TIMEOUT  (WAKE_TIMEOUT)
  ) u_dut (
    .aclk   (aclk),
    .aresetn(aresetn),
    // The gated leaf. aclk is the ungated leaf of the same tree; see
    // ppu_top_axi_lite's header on why these are two ports and one clock.
    .clk    (ppu_clk),
    .rst_n  (aresetn),

    .s_axi_awaddr (axi.aw_addr ),
    .s_axi_awprot (axi.aw_prot ),
    .s_axi_awvalid(axi.aw_valid),
    .s_axi_awready(axi.aw_ready),
    .s_axi_wdata  (axi.w_data  ),
    .s_axi_wstrb  (axi.w_strb  ),
    .s_axi_wvalid (axi.w_valid ),
    .s_axi_wready (axi.w_ready ),
    .s_axi_bresp  (axi.b_resp  ),
    .s_axi_bvalid (axi.b_valid ),
    .s_axi_bready (axi.b_ready ),
    .s_axi_araddr (axi.ar_addr ),
    .s_axi_arprot (axi.ar_prot ),
    .s_axi_arvalid(axi.ar_valid),
    .s_axi_arready(axi.ar_ready),
    .s_axi_rdata  (axi.r_data  ),
    .s_axi_rresp  (axi.r_resp  ),
    .s_axi_rvalid (axi.r_valid ),
    .s_axi_rready (axi.r_ready ),

    .irq(irq),

    .ppuclk_qreqn   (ppuclk_qreqn),
    .ppuclk_qacceptn(ppuclk_qacceptn),
    .ppuclk_qdeny   (ppuclk_qdeny),
    .ppuclk_qactive (ppuclk_qactive),

    .dev_qreqn   (dev_qreqn),
    .dev_qacceptn(dev_qacceptn),
    .dev_qdeny   (dev_qdeny),
    .dev_qactive (dev_qactive),

    .ppuhwstat     (ppuhwstat),
    .dev_clken     (dev_clken),
    .dev_poresetn  (dev_poresetn),
    .dev_retresetn (dev_retresetn),
    .dev_warmresetn(dev_warmresetn),
    .dev_isolaten  (dev_isolaten),

    .pcsm_pstate  (pcsm_pstate),
    .pcsm_preq    (pcsm_preq),
    .pcsm_paccept (pcsm_paccept),
    .pcsm_modestat(pcsm_modestat)
  );

  // ---- The PCSM, on the same (gated) clock as the PPU ----
  // Sharing the gate is right rather than convenient: the P-Channel between
  // them is synchronous, and gating one side only would skew it. The PPU never
  // accepts quiescence with a PCSM handshake in flight, so there is nothing for
  // the PCSM to be doing while the clock is away.
  ppu_pcsm #(.SYNC_STAGES(2), .TINIT(4), .RESET_MODESTAT(PM_OFF)) u_pcsm (
    .clk          (ppu_clk),
    .rst_n        (aresetn),
    .pcsm_pstate  (pcsm_pstate),
    .pcsm_preq    (pcsm_preq),
    .pcsm_paccept (pcsm_paccept),
    .logic_on     (),
    .logic_ret    (),
    .ram_on       (),
    .ram_ret      (),
    .ram_cfg      (),
    .ram_sleep    (),
    .ram_sd       (),
    .ret_n        (),
    .pcsm_mode    (),
    .pcsm_modestat(pcsm_modestat)
  );

  // ---- The device domain's clock, gated by DEVCLKEN ----
  //
  //   dclk + dev_clken --[cdc_sync]--> clk_gate --> dev_clk
  //
  // DUT 1 is ppu_top_axi_lite, which contains ppu_top and nothing else, so the
  // device side that ppu_pd_top would normally supply has to be built here.
  // DEVCLKEN was previously left dangling, which meant this file drove a PPU
  // through every power mode without the clock enable it produces reaching
  // anything at all.
  //
  // The cdc_sync is not optional. DEVCLKEN is driven in the aclk domain and
  // gates a dclk-domain clock, and aclk and dclk are asynchronous here (10 ns
  // against 14 ns). DEN 0051E Section 4.1.5 warns about exactly this when
  // choosing CLKEN_RST_DLY: "if the clock enable is re-synchronized the clock
  // might not be running as soon as the clock enable is asserted from the PPU,
  // so a larger delay period might need to be used". ppu_pd_top does the same
  // thing for the same reason.
  logic sync_dev_clken, dev_clk;

  cdc_sync #(.STAGES(2), .RESET_VAL(1'b0))
  u_dev_clken_sync (.clk(dclk), .rst_n(aresetn), .d(dev_clken), .q(sync_dev_clken));

  clk_gate u_dev_gate (
    .clk      (dclk),
    .clk_en   (sync_dev_clken),
    .gated_clk(dev_clk)
  );

  // Something for the gate to act on, so it is not decorative. Counted rather
  // than inspected: "the clock stopped" is a claim about a window, and a level
  // check at the end of one cannot make it.
  int unsigned dev_clk_edges = 0;
  always @(posedge dev_clk) dev_clk_edges = dev_clk_edges + 1;

  // ---- A Q-Channel device, on the UNGATED clock ----
  //
  // dclk, deliberately, and NOT dev_clk. ppu_pd_top makes the same choice and
  // its header argues it at length: the Q-Channel wrapper has to stay alive
  // while the domain is down, or DEVQACTIVE is stuck LOW and a wake can never
  // revive it. Moving it onto the gated clock would look tidier and would break
  // that.
  logic dev_wake = 1'b0;

  qchannel_device #(.SYNC_STAGES(2)) u_dev (
    .clk     (dclk),
    .rst_n   (aresetn),
    .qreqn   (dev_qreqn),
    .qacceptn(dev_qacceptn),
    .qdeny   (dev_qdeny),
    .qactive (dev_qactive),
    .dev_quiescent_busy(1'b0),
    .dev_quiescent_deny(1'b0),
    .dev_wake          (dev_wake),
    .dev_quiescent_ok  ()
  );

  // ===========================================================================
  // DUT 2: the same bridge over a REAL POWER DOMAIN
  //
  // ppu_top_axi_lite above contains ppu_top, which has no power domain -- so
  // src/upf has nothing to bind to it and groups L1-L10 can only ever run with
  // the power intent absent. ppu_axi_pd_top is the same adapter over
  // ppu_pd_top, and it is here so that "make ppuaxipa" has a PD_AON/PD_DEV pair
  // to apply the intent to.
  //
  // The gap it closes is a three-way one. ppu_clkq_tb covers a gated clock with
  // a genuinely unpowered PD_DEV, but over the generic strobe. L1-L10 cover AXI
  // with a gated clock, but with no domain. Only this DUT has all three at
  // once, which is the combination a real SoC runs in constantly: software
  // reaching a PPU over AXI, the PPU's clock stopped, and the domain it manages
  // with its supply removed.
  // ===========================================================================
  AXI_LITE_DV #(.AXI_ADDR_WIDTH(AW), .AXI_DATA_WIDTH(DW)) axi_pd (aclk);
  drv_t drv_pd = new(axi_pd);

  logic pd_hc_qreqn = 1'b1;
  logic pd_clk_force = 1'b0;
  logic pd_hc_qacceptn, pd_hc_qdeny, pd_hc_qactive;
  logic pd_irq;

  ppu_axi_pd_top #(
    .DEF_PWR_POLICY  (PM_ON),
    .SYNC_STAGES     (2),
    .NUM_QACTIVE_ONLY(1),
    .AXI_ADDR_W      (AW),
    .WAKE_TIMEOUT    (WAKE_TIMEOUT)
  ) u_pd_dut (
    .aclk   (aclk),
    .aresetn(aresetn),

    .s_axi_awaddr (axi_pd.aw_addr ),
    .s_axi_awprot (axi_pd.aw_prot ),
    .s_axi_awvalid(axi_pd.aw_valid),
    .s_axi_awready(axi_pd.aw_ready),
    .s_axi_wdata  (axi_pd.w_data  ),
    .s_axi_wstrb  (axi_pd.w_strb  ),
    .s_axi_wvalid (axi_pd.w_valid ),
    .s_axi_wready (axi_pd.w_ready ),
    .s_axi_bresp  (axi_pd.b_resp  ),
    .s_axi_bvalid (axi_pd.b_valid ),
    .s_axi_bready (axi_pd.b_ready ),
    .s_axi_araddr (axi_pd.ar_addr ),
    .s_axi_arprot (axi_pd.ar_prot ),
    .s_axi_arvalid(axi_pd.ar_valid),
    .s_axi_arready(axi_pd.ar_ready),
    .s_axi_rdata  (axi_pd.r_data  ),
    .s_axi_rresp  (axi_pd.r_resp  ),
    .s_axi_rvalid (axi_pd.r_valid ),
    .s_axi_rready (axi_pd.r_ready ),

    .irq(pd_irq),

    .hc_qreqn_i   (pd_hc_qreqn),
    .hc_qacceptn_o(pd_hc_qacceptn),
    .hc_qdeny_o   (pd_hc_qdeny),
    .hc_qactive_o (pd_hc_qactive),

    .qactive_only_i(1'b0),
    .clk_force_i   (pd_clk_force),
    .entry_delay_i (8'd0),

    .dclk      (dclk),
    .start     (1'b0),
    .work_len  ('0),
    .light_work(1'b1),
    .wake      (1'b0),
    .deny_enb  (1'b0),
    .ip_cmd    (2'b00),
    .ip_seed   (8'h00)
  );

  wire [3:0] pd_mode  = u_pd_dut.u_dom.u_pd.u_ppu.u_seq.pwr_status;
  wire       pd_clken = u_pd_dut.u_dom.ppu_clken;

  // Probes into the bridge, for the groups that are about its internals.
  wire       pwakeup   = u_dut.pwakeup;
  wire       clk_ok    = u_dut.ppu_clk_ok;
  wire       reg_wen   = u_dut.reg_wen;
  wire       reg_ren   = u_dut.reg_ren;
  wire [3:0] ppu_mode  = u_dut.u_ppu.u_seq.pwr_status;

  // ===========================================================================
  // Continuous AXI protocol invariants
  //
  // IHI 0022 Section A3.2.1: "once VALID is asserted it must remain asserted
  // until the handshake occurs", and the information carried with it must not
  // change. These are the rules a bridge breaks when a state machine takes a
  // shortcut, and they are checked on every cycle of every group rather than in
  // a group of their own -- including the randomised soak, where the driver is
  // producing handshake timing nobody wrote down.
  // ===========================================================================
  logic       bvalid_d, bready_d, rvalid_d, rready_d;
  logic [1:0] bresp_d, rresp_d;
  logic [31:0] rdata_d;

  always_ff @(posedge aclk) begin
    bvalid_d <= axi.b_valid; bready_d <= axi.b_ready; bresp_d <= axi.b_resp;
    rvalid_d <= axi.r_valid; rready_d <= axi.r_ready; rresp_d <= axi.r_resp;
    rdata_d  <= axi.r_data;
  end

  int valid_dropped = 0;   // VALID deasserted without a handshake
  int payload_moved = 0;   // payload changed while VALID && !READY

  always @(posedge aclk) begin
    if (aresetn) begin
      if (bvalid_d && !bready_d) begin
        if (!axi.b_valid)             valid_dropped = valid_dropped + 1;
        if (axi.b_resp !== bresp_d)   payload_moved = payload_moved + 1;
      end
      if (rvalid_d && !rready_d) begin
        if (!axi.r_valid)             valid_dropped = valid_dropped + 1;
        if (axi.r_resp  !== rresp_d)  payload_moved = payload_moved + 1;
        if (axi.r_data  !== rdata_d)  payload_moved = payload_moved + 1;
      end
    end
  end

  // The bridge's own invariant, and the reason it exists: a register strobe
  // must never be issued at a PPU whose clock is not guaranteed. Both halves
  // are sampled on aclk, which is the clock the strobe is launched from.
  int strobe_without_clock = 0;
  always @(posedge aclk)
    if (aresetn && (reg_wen || reg_ren) && !clk_ok)
      strobe_without_clock = strobe_without_clock + 1;

  // DUT 2 has a real gate, so the same claim can be made against the PHYSICAL
  // clock rather than against the decode the bridge used to decide. This is the
  // check that a wrong choice of ppu_clk_ok would have to survive: it reads
  // en_latch, the ICG's own state, and owes nothing to ppu_clk_ok's definition.
  //
  // Compared against 1 for the reason recorded in ppu_pd_tb -- an X inverts to
  // X, and x->1 is a posedge.
  int pd_strobe_gated = 0;
  always @(posedge aclk)
    if (aresetn && (u_pd_dut.u_dom.u_axi.reg_wen || u_pd_dut.u_dom.u_axi.reg_ren)
        && (u_pd_dut.u_dom.u_gate.en_latch !== 1'b1))
      pd_strobe_gated = pd_strobe_gated + 1;

  // And PWAKEUP must be HIGH whenever a strobe goes out, or the clock
  // controller could be counting entry_delay_i underneath it.
  int strobe_without_wakeup = 0;
  always @(posedge aclk)
    if (aresetn && (reg_wen || reg_ren) && !pwakeup)
      strobe_without_wakeup = strobe_without_wakeup + 1;

  // ===========================================================================
  // Helpers
  // ===========================================================================
  int unsigned checks = 0, errors = 0;
  string sect = "";

  task automatic section(input string s);
    begin sect = s; $display("\n---- %0s ----", s); end
  endtask

  task automatic ck(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; $display("[%0t] FAIL %0s: %0s", $time, sect, what); end
      else            $display("[%0t]  ok  %0s: %0s", $time, sect, what);
    end
  endtask

  // AW and W are forked because the bridge accepts them together -- see
  // ppu_axi_lite_adapter's note on IHI 0022 Section A3.3.1. Calling send_aw on
  // its own would hang, correctly.
  resp_t       last_bresp;
  resp_t       last_rresp;
  logic [31:0] last_rdata;

  task automatic axi_write(input logic [31:0] a, input logic [31:0] d,
                           input logic [3:0] s = 4'hF);
    begin
      fork
        drv.send_aw(a, 3'b000);
        drv.send_w(d, s);
      join
      drv.recv_b(last_bresp);
    end
  endtask

  task automatic axi_read(input logic [31:0] a);
    begin
      drv.send_ar(a, 3'b000);
      drv.recv_r(last_rdata, last_rresp);
    end
  endtask

  // The same two tasks against DUT 2. Duplicated rather than parameterised
  // because a SystemVerilog task cannot take a virtual interface handle chosen
  // at the call site without turning the whole file into classes, and two
  // six-line tasks are a smaller price than that.
  resp_t       pd_bresp, pd_rresp;
  logic [31:0] pd_rdata;

  task automatic pd_write(input logic [31:0] a, input logic [31:0] d,
                          input logic [3:0] s = 4'hF);
    begin
      fork
        drv_pd.send_aw(a, 3'b000);
        drv_pd.send_w(d, s);
      join
      drv_pd.recv_b(pd_bresp);
    end
  endtask

  task automatic pd_read(input logic [31:0] a);
    begin
      drv_pd.send_ar(a, 3'b000);
      drv_pd.recv_r(pd_rdata, pd_rresp);
    end
  endtask

  task automatic settle(); repeat (400) @(posedge aclk); endtask

  // ===========================================================================
  int  t_wake, t_strobe, i;
  int unsigned edges_before;
  int  soak_errors;
  logic [31:0] shadow [3];
  logic [11:0] scratch [3];
  logic [31:0] v;
  int  idx;
  bit  saw_both;

  initial begin
    $dumpfile("ppu_axi_lite_tb.vcd");
    $dumpvars(0, ppu_axi_lite_tb);

    $display("==============================================================");
    $display(" ppu_axi_lite_tb: AXI4-Lite -> PPU, driven by pulp-platform VIP");
    $display("==============================================================");

    drv.reset_master();
    drv_pd.reset_master();

    // =========================================================================
    section("L1 reset");
    // =========================================================================
    // Section A3.1.2 constrains exactly two things on a subordinate during
    // reset: BVALID and RVALID must not be HIGH. READY is unconstrained, and
    // this bridge does leave ARREADY HIGH -- R_IDLE is its reset state and
    // ARREADY is decoded from it. That is harmless because the master is
    // required to hold ARVALID LOW through reset, so the handshake cannot
    // complete against nobody.
    //
    // The first version of this group asserted that no channel was READY, which
    // is a rule AXI does not have, and it failed against correct RTL. Left
    // recorded rather than quietly deleted: the check was wrong, the design was
    // not, and the reason it looked plausible is that AWREADY and WREADY ARE
    // LOW here -- they are qualified by AWVALID and WVALID, so only ARREADY
    // ever shows the difference.
    repeat (4) @(posedge aclk);
    ck(axi.b_valid === 1'b0 && axi.r_valid === 1'b0,
       "BVALID and RVALID are LOW under reset -- the one thing A3.1.2 requires");
    ck(axi.aw_ready === 1'b0 && axi.w_ready === 1'b0,
       "AWREADY and WREADY are LOW too, being qualified by their VALIDs");
    ck(pwakeup === 1'b0, "PWAKEUP is LOW under reset");

    aresetn = 1'b1;
    settle();
    ck(ppu_mode === PM_ON, "after reset the PPU reached its default policy, ON");

    // =========================================================================
    section("L2 a write and a read, over AXI4-Lite");
    // =========================================================================
    // PPU_MEMRR is the scratch register of choice throughout this file: it is
    // R/W with a writable mask of 0x000000FF, it is pure storage forwarded into
    // PCSMPSTATE, and writing it has no effect on the sequencer. A test that
    // used PPU_PWPR would be exercising the PPU, not the bridge.
    axi_write(32'h0000_0058, 32'h0000_005A);      // PPU_MEMRR
    ck(last_bresp === RESP_OKAY, "the write answered RESP_OKAY on B");

    axi_read(32'h0000_0058);
    ck(last_rresp === RESP_OKAY,        "the read answered RESP_OKAY on R");
    ck(last_rdata === 32'h0000_005A,
       $sformatf("and returned what was written: 0x%08x", last_rdata));

    // DEN 0051E Section 5.2 makes reserved and unmapped addresses WI/RAZ rather
    // than errors, so the bridge has nothing to report for them. This is the
    // check that says so, rather than leaving it as an assumption.
    axi_read(32'h0000_0FFC);
    ck(last_rresp === RESP_OKAY && last_rdata === 32'h0,
       "an unmapped address reads as zero with OKAY, not SLVERR (Section 5.2 WI/RAZ)");

    // =========================================================================
    section("L3 a write and a read IN THE SAME CYCLE");
    // =========================================================================
    // ppu_top's software interface has independent write and read address
    // buses, and its port comment says why: "so an AXI4-Lite bridge can have
    // one of each outstanding without arbitrating between them". PULP's
    // axi_lite_to_reg cannot do this -- a reg_bus has one address and one
    // valid, so it arbitrates. This bridge has two independent state machines
    // instead, and the observable difference is reg_wen and reg_ren HIGH
    // together.
    //
    // Watched rather than inferred from latency: a design that serialised them
    // would still complete both, just a few cycles apart.
    saw_both = 1'b0;
    fork
      begin : watch_both
        forever begin
          @(posedge aclk);
          if (reg_wen && reg_ren) saw_both = 1'b1;
        end
      end
      begin : traffic
        fork
          axi_write(32'h0000_0050, 32'h0000_0011);   // PPU_FUNRR
          axi_read (32'h0000_0058);                  // PPU_MEMRR
        join
      end
    join_any
    disable watch_both;

    ck(last_bresp === RESP_OKAY && last_rresp === RESP_OKAY,
       "both transactions completed with OKAY");
    ck(last_rdata === 32'h0000_005A, "the read returned the earlier PPU_MEMRR value");
    ck(saw_both,
       "reg_wen and reg_ren were HIGH in the SAME cycle -- no arbitration");

    axi_read(32'h0000_0050);
    ck(last_rdata === 32'h0000_0011, "and the concurrent write landed too");

    // =========================================================================
    section("L4 WSTRB is carried through to the register file");
    // =========================================================================
    // Every byte lane of a 32-bit AXI write reaches ppu_regs, which honours it
    // per Section 5.2. A bridge that tied wstrb to 4'hF would pass every other
    // group in this file.
    axi_write(32'h0000_0054, 32'h0000_00FF);           // PPU_FULRR = 0xFF
    axi_read (32'h0000_0054);
    ck(last_rdata === 32'h0000_00FF, "setup: PPU_FULRR = 0xFF");

    axi_write(32'h0000_0054, 32'h0000_0000, 4'b0010);  // lane 1 only; field is [7:0]
    axi_read (32'h0000_0054);
    ck(last_rdata === 32'h0000_00FF,
       "a write with lane 0 masked left the field alone");

    axi_write(32'h0000_0054, 32'h0000_0000, 4'b0001);  // lane 0
    axi_read (32'h0000_0054);
    ck(last_rdata === 32'h0000_0000, "and a write with lane 0 enabled cleared it");

    // =========================================================================
    section("L5 IHI 0022 A3.2.1: VALID holds until the handshake");
    // =========================================================================
    // VALID, once asserted, holds until the handshake. The driver's recv_b and
    // recv_r assert READY immediately, so the back-pressure has to come from
    // NOT calling them.
    fork
      drv.send_aw(32'h0000_0058, 3'b000);
      drv.send_w(32'h0000_0033, 4'hF);
    join
    repeat (30) @(posedge aclk);
    ck(axi.b_valid === 1'b1,
       "BVALID was still asserted 30 cycles after the write, with BREADY LOW");
    drv.recv_b(last_bresp);
    ck(last_bresp === RESP_OKAY, "and the response was accepted when BREADY came");

    drv.send_ar(32'h0000_0058, 3'b000);
    repeat (30) @(posedge aclk);
    ck(axi.r_valid === 1'b1,
       "RVALID was still asserted 30 cycles after the read, with RREADY LOW");
    ck(axi.r_data === 32'h0000_0033, "with RDATA held stable across the wait");
    drv.recv_r(last_rdata, last_rresp);
    ck(last_rdata === 32'h0000_0033, "and the same data came out on the handshake");

    // =========================================================================
    section("L6 Table A-28: PWAKEUP leads the access and outlasts it");
    // =========================================================================
    // Two separate obligations, and a bridge can get either one wrong on its
    // own. Asserting PWAKEUP late loses the access; dropping it early lets the
    // clock controller start counting entry_delay_i while the response is still
    // outstanding.
    settle();
    ck(pwakeup === 1'b0, "setup: idle, PWAKEUP LOW");

    t_wake = -1; t_strobe = -1;
    fork
      begin : watch_order
        forever begin
          @(posedge aclk);
          if (pwakeup && t_wake   < 0) t_wake   = $time;
          if (reg_wen && t_strobe < 0) t_strobe = $time;
        end
      end
      begin
        fork
          drv.send_aw(32'h0000_0058, 3'b000);
          drv.send_w(32'h0000_0044, 4'hF);
        join
        // Deliberately hold B off, so the "outlasts it" half has a window.
        repeat (20) @(posedge aclk);
        ck(pwakeup === 1'b1,
           "PWAKEUP is still HIGH with the register access done and B outstanding");
        drv.recv_b(last_bresp);
      end
    join_any
    disable watch_order;

    ck(t_wake > 0 && t_strobe > 0 && t_wake < t_strobe,
       $sformatf("PWAKEUP rose at %0t, before reg_wen at %0t", t_wake, t_strobe));

    settle();
    ck(pwakeup === 1'b0, "and it dropped once the response had been accepted");

    // =========================================================================
    section("L7 an access to a PPU whose clock has STOPPED");
    // =========================================================================
    // The case the bridge exists for. Nothing here is driven by hand: the
    // clock controller gated the PPU because it went idle, and the only thing
    // that can bring it back is the bridge's own PWAKEUP.
    ck(ppu_clken === 1'b0, "setup: the PPU's clock is gated");
    ck(clk_ok === 1'b0, "setup: and the Q-Channel is not in Q_RUN, so ppu_clk_ok is LOW");

    axi_write(32'h0000_0058, 32'h0000_0077);
    ck(last_bresp === RESP_OKAY, "the write completed with OKAY");

    settle();
    ck(ppu_clken === 1'b0, "the clock gated again afterwards");
    axi_read(32'h0000_0058);
    ck(last_rresp === RESP_OKAY, "and the read from a re-gated PPU completed");
    ck(last_rdata === 32'h0000_0077,
       $sformatf("with the value the gated write had landed: 0x%08x", last_rdata));

    // The negative control lives in ppu_clkq_tb group G2, which issues the same
    // write with no PWAKEUP at all and watches it vanish. Here PWAKEUP is not
    // optional -- the bridge always drives it -- so what is checked instead is
    // that it was sufficient.

    // =========================================================================
    section("L8 the wake never comes: SLVERR rather than a hung bus");
    // =========================================================================
    // A hierarchical power controller holding the domain quiescent is a state
    // no amount of PWAKEUP escapes -- ppu_clk_ctrl's up_hold is deliberate, and
    // the way out is the upstream controller releasing, which may be a software
    // decision arbitrarily far away. A bridge that waits for that has hung the
    // system bus.
    //
    // This is the "error" response model of PCSA 7.2.8 rather than
    // "stall and wake". WAKE_TIMEOUT = 0 selects the other one.
    settle();
    @(negedge aclk); hc_qreqn = 1'b0;
    settle();
    ck(hc_qacceptn === 1'b0, "setup: the upstream controller has quiesced the domain");
    ck(ppu_clken === 1'b0,       "setup: with the clock gated and held");

    axi_write(32'h0000_0058, 32'h0000_0099);
    ck(last_bresp === RESP_SLVERR,
       "the write timed out and answered RESP_SLVERR instead of hanging");
    ck(ppu_clken === 1'b0, "the clock never came back -- the hold really did hold");

    axi_read(32'h0000_0058);
    ck(last_rresp === RESP_SLVERR, "and so did the read");
    ck(last_rdata === 32'h0,
       "returning zero rather than the read latch's stale value, which would look valid");

    @(negedge aclk); hc_qreqn = 1'b1;
    settle();
    axi_read(32'h0000_0058);
    ck(last_rresp === RESP_OKAY && last_rdata === 32'h0000_0077,
       "once released, the same read succeeds and the timed-out write never happened");

    // =========================================================================
    section("L9 randomised soak with the VIP");
    // =========================================================================
    // 200 transactions against three scratch registers with a shadow model,
    // interleaved with the clock gating and ungating underneath. The point is
    // not the data -- L2 covered that -- it is the handshake timing, which is
    // the driver's to choose and not this file's.
    scratch[0] = 12'h050; scratch[1] = 12'h054; scratch[2] = 12'h058;
    shadow[0] = 32'h0; shadow[1] = 32'h0; shadow[2] = 32'h0;

    // Known starting point.
    for (i = 0; i < 3; i++) axi_write({20'h0, scratch[i]}, 32'h0);

    soak_errors = 0;
    for (i = 0; i < 200; i++) begin
      idx = $urandom_range(0, 2);
      if ($urandom_range(0, 1)) begin
        v = $urandom();
        axi_write({20'h0, scratch[idx]}, v);
        // Writable mask is 0x000000FF for all three (ppu_pd_tb P20).
        shadow[idx] = v & 32'h0000_00FF;
        if (last_bresp !== RESP_OKAY) soak_errors++;
      end else begin
        axi_read({20'h0, scratch[idx]});
        if (last_rresp !== RESP_OKAY || last_rdata !== shadow[idx]) begin
          soak_errors++;
          $display("[%0t]   soak mismatch at 0x%03x: got 0x%08x resp %0d, expected 0x%08x",
                   $time, scratch[idx], last_rdata, last_rresp, shadow[idx]);
        end
      end
      // Let the clock gate every so often, so the soak crosses the boundary
      // instead of running entirely awake.
      if ($urandom_range(0, 7) == 0) settle();
    end
    ck(soak_errors == 0,
       $sformatf("200 randomised transactions, %0d mismatch(es)", soak_errors));

    // =========================================================================
    section("L11 AXI + gated clock + a domain that really loses power");
    // =========================================================================
    // The three-way case, on DUT 2. Every access below goes over AXI4-Lite to a
    // PPU whose clock the controller has stopped, and under "make ppuaxipa"
    // PD_DEV genuinely loses its supply in the modes that remove it -- rather
    // than merely being held in reset, which is what a run without the power
    // intent shows and what makes OFF, MEM_RET and FULL_RET look identical.
    //
    // What it is really asking is whether the BRIDGE is affected by any of it.
    // The adapter, the PPU and the PCSM are all in PD_AON, which never loses
    // power, so the correct answer is that the power intent is invisible here
    // and every check below passes identically with and without it. The same
    // argument ppu_be_tb.upf's header makes: a register interface whose
    // behaviour changed when a domain BELOW it was power-gated would be a real
    // finding, and nothing else is positioned to notice.
    settle();
    ck(pd_mode === PM_ON, "setup: DUT 2 came up in ON under its default policy");
    ck(pd_clken === 1'b0, "setup: and its PPU clock has gated, the PPU being idle");

    // ON -> OFF, entirely over AXI, starting from a stopped clock.
    pd_write(32'h0000_0000, {28'h0, PM_OFF});          // PPU_PWPR
    ck(pd_bresp === RESP_OKAY, "the policy write reached a clock-gated PPU");
    settle();
    pd_read(32'h0000_0008);                            // PPU_PWSR
    ck(pd_rresp === RESP_OKAY && pd_rdata[3:0] === PM_OFF,
       $sformatf("PPU_PWSR read back OFF over AXI: 0x%08x", pd_rdata));
    // After the read, not during it: PWAKEUP is still HIGH while the response
    // is outstanding (L6's other half), and the entry hysteresis has to run
    // again after it drops. Checking on the same delta as recv_r would be
    // checking that the bridge had ALREADY let go, which it correctly had not.
    settle();
    ck(pd_clken === 1'b0, "and the PPU clock gated again once the bridge let go");

    // The two modes the power intent separates from OFF, each reached and
    // reported over AXI with the clock stopping in between.
    pd_write(32'h0000_0000, {28'h0, PM_MEM_RET});
    settle();
    pd_read(32'h0000_0008);
    ck(pd_rdata[3:0] === PM_MEM_RET, "MEM_RET reached and reported over AXI");

    pd_write(32'h0000_0000, {28'h0, PM_ON});
    settle();
    pd_write(32'h0000_0000, {28'h0, PM_FULL_RET});
    settle();
    pd_read(32'h0000_0008);
    ck(pd_rdata[3:0] === PM_FULL_RET, "FULL_RET reached and reported over AXI");

    // And back up, which is the direction that needs the supply restored,
    // isolation released and the resets sequenced before the PPU can answer.
    pd_write(32'h0000_0000, {28'h0, PM_ON});
    settle();
    pd_read(32'h0000_0008);
    ck(pd_rdata[3:0] === PM_ON, "and the climb back to ON, reported over AXI");

    // A scratch register written before all of that, read after it. In PD_AON,
    // so it must survive every one of those supply removals.
    pd_write(32'h0000_0058, 32'h0000_00C3);            // PPU_MEMRR
    pd_write(32'h0000_0000, {28'h0, PM_OFF});
    settle();
    pd_write(32'h0000_0000, {28'h0, PM_ON});
    settle();
    pd_read(32'h0000_0058);
    ck(pd_rdata === 32'h0000_00C3,
       $sformatf("PPU_MEMRR survived OFF and back: 0x%08x", pd_rdata));

    // =========================================================================
    section("L12 a clock that is PRESENT but not GUARANTEED");
    // =========================================================================
    // The one state where the two plausible definitions of ppu_clk_ok disagree,
    // pinned down so the choice between them is not a matter of taste.
    //
    //   ppu_clk_ok = Q_RUN      what ppu_axi_pd_top does
    //   ppu_clk_ok = clken_o    the clock controller's own gate enable
    //
    // ppu_clk_ctrl's clk_running is
    //     clk_force_i | dftcgen | !base_req | !all_stopped
    // so with an upstream controller holding the domain quiescent (up_hold
    // pinning base_req HIGH) AND clk_force_i asserted, clken_o is HIGH while
    // the PPU's channel sits in Q_STOPPED. The clock is running. The handshake
    // says it is not guaranteed.
    //
    // This bridge refuses, and the reason is not conservatism for its own sake:
    // Table A-25 makes clk_force_i ASYNCHRONOUS and nothing coordinates it with
    // an access in flight. It can deassert mid-transaction and the clock
    // disappears with no handshake and no warning. In Q_RUN that cannot happen
    // -- taking the clock away requires Q_REQUEST, and the PPU denies that
    // while PWAKEUP is HIGH, so the bridge holds a veto over its own clock.
    //
    // Without this group the two definitions are indistinguishable: both were
    // tried against the other 51 checks and both passed.
    settle();
    @(negedge aclk); pd_hc_qreqn = 1'b0;
    settle();
    ck(pd_hc_qacceptn === 1'b0, "setup: an upstream controller has quiesced the domain");
    ck(pd_clken === 1'b0,       "setup: and the clock is gated");

    @(negedge aclk); pd_clk_force = 1'b1;
    settle();
    ck(pd_clken === 1'b1,
       "clk_force_i turned the clock back ON while the channel stays quiesced");
    ck(qch_decode(u_pd_dut.u_dom.ppuclk_qreqn, u_pd_dut.u_dom.ppuclk_qacceptn,
                  u_pd_dut.u_dom.ppuclk_qdeny) == Q_STOPPED,
       "  ...the PPU's clock channel is in Q_STOPPED with its clock running");

    pd_read(32'h0000_0008);
    ck(pd_rresp === RESP_SLVERR,
       "and the bridge REFUSED anyway: present is not the same as guaranteed");

    @(negedge aclk); pd_clk_force = 1'b0;
    @(negedge aclk); pd_hc_qreqn  = 1'b1;
    settle();
    pd_read(32'h0000_0008);
    ck(pd_rresp === RESP_OKAY,
       "once the handshake really reaches Q_RUN, the same read succeeds");

    // =========================================================================
    section("L13 DEVCLKEN reaches a gate and actually stops a clock");
    // =========================================================================
    // DEN 0051E Table 4-7 gives DEVCLKEN 1 in ON and 0 in FULL_RET, MEM_RET and
    // OFF. ppu_pd_tb P22 proves the PPU drives it that way; what this proves is
    // that it reaches a gate in THIS integration, where the device side comes
    // from the testbench rather than from ppu_pd_top -- and every mode change
    // below is commanded over AXI4-Lite through a clock-gated PPU.
    //
    // Counted over a window, because "the clock stopped" is not a claim a level
    // check can make.
    axi_write(32'h0000_0000, {28'h0, PM_ON});
    settle();
    ck(u_dut.u_ppu.u_seq.pwr_status === PM_ON, "setup: DUT 1's domain is in ON");

    edges_before = dev_clk_edges;
    repeat (200) @(posedge aclk);
    ck(dev_clk_edges > edges_before,
       $sformatf("in ON the device clock runs (%0d edges in 200 cycles)",
                 dev_clk_edges - edges_before));

    axi_write(32'h0000_0000, {28'h0, PM_OFF});
    settle();
    ck(u_dut.u_ppu.u_seq.pwr_status === PM_OFF, "commanded to OFF over AXI4-Lite");
    ck(dev_clken === 1'b0, "DEVCLKEN is LOW, per Table 4-7");

    edges_before = dev_clk_edges;
    repeat (500) @(posedge aclk);
    ck(dev_clk_edges == edges_before,
       $sformatf("and the device clock is stopped: %0d edges in 500 cycles",
                 dev_clk_edges - edges_before));

    axi_write(32'h0000_0000, {28'h0, PM_ON});
    settle();
    edges_before = dev_clk_edges;
    repeat (200) @(posedge aclk);
    ck(dev_clk_edges > edges_before, "and back in ON it runs again");

    // =========================================================================
    section("L10 the continuous invariants");
    // =========================================================================
    ck(valid_dropped == 0,
       $sformatf("BVALID/RVALID were never deasserted without a handshake (%0d) -- IHI 0022 A3.2.1",
                 valid_dropped));
    ck(payload_moved == 0,
       $sformatf("BRESP/RDATA/RRESP never changed while VALID was waiting (%0d)",
                 payload_moved));
    ck(strobe_without_clock == 0,
       $sformatf("no reg_wen/reg_ren was ever issued with ppu_clk_ok LOW (%0d)",
                 strobe_without_clock));
    ck(strobe_without_wakeup == 0,
       $sformatf("and none was issued with PWAKEUP LOW (%0d)", strobe_without_wakeup));
    ck(pd_strobe_gated == 0,
       $sformatf("and on DUT 2, none was issued while the ICG was actually closed (%0d)",
                 pd_strobe_gated));

    // =========================================================================
    $display("");
    $display("==============================================================");
    $display(" ppu_axi_lite_tb: %0d checks, %0d error(s)", checks, errors);
    $display(" RESULT: %0s", (errors == 0) ? "PASS" : "FAIL");
    $display("==============================================================");
    $finish;
  end

  initial begin
    #40000000;
    $display("RESULT: FAIL");
    $fatal(1, "ppu_axi_lite_tb watchdog");
  end

endmodule
