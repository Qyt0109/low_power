`timescale 1ns/1ps
// PPU reduced-configuration testbench -- Section 7 configuration options.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Chapter 7 "Configuration Options", and the per-register
// "when X is not supported this register is reserved" notes in Chapter 5.
//
// WHY THIS EXISTS
//
// The PPU has seven optional-feature parameters. Until this file, FIVE of them
// had never been elaborated to anything but 1:
//
//     LOCK_SPT   SW_DEV_DEL_SPT   PWR_MODE_ENTRY_DEL_SPT   DYN_SPT
//     RET_RAM_REGS
//
// Seventeen guards in the synthesizable RTL depend on those parameters, and the
// false arm of every one of them was dead code -- present, reviewed, never
// simulated. That is the same category of gap as the clock ratio in
// ppu_clkratio_tb: not "the spec says X and we do Y", but "we have only ever
// built one point in a space the spec says is configurable".
//
// It matters more here than it looks. A reduced PPU is not a PPU with a feature
// switched off at runtime -- it is a DIFFERENT PPU, one whose register map has
// changed shape. Software discovers that shape by reading PPU_IDR0/IDR1, so the
// identification registers and the actual behaviour must agree. A build that
// advertises a feature it does not have, or hides one it does, is broken in a
// way no amount of testing the full build can reveal.
//
// THE COMPARATIVE STRUCTURE, AND WHY IT IS THE POINT
//
// Three DUTs on one shared register bus:
//
//   u_max      every option enabled -- the build every other testbench uses
//   u_min      all five cleared, plus OFF_MEM_RET_TRANS
//   u_nolock   LOCK_SPT=0 alone, DYN_SPT still 1
//
// Every check below is made against BOTH u_min and u_max, and demands they
// DISAGREE. That is what makes this file self-proving: a check that reads zero
// from the reduced build proves nothing on its own, because an address that was
// never decoded also reads zero, and so does a testbench whose bus is broken.
// Reading 0xA5 from u_max through the same transaction at the same instant
// proves the read worked and the difference is the parameter. It is the
// non-vacuity argument built into the structure instead of bolted on as a
// separate mutation run.
//
// u_nolock exists for one specific reason. In u_min, lock is unsupported AND
// dynamic transitions are unsupported -- and Section 3.4.3 says the lock
// releases whenever PWR_DYN_EN is 0. So "u_min never locks" is true for two
// independent reasons and tests neither. u_nolock has dynamic enabled and lock
// removed, which isolates LOCK_SPT as the only remaining cause.
//
// WHAT THE SPEC MAKES DIFFERENT BETWEEN TWO SIMILAR-LOOKING OPTIONS
//
// The pair that is easiest to get wrong, and the reason phase M6 is separate:
//
//   PWR_MODE_ENTRY_DEL_SPT=0  ->  PPU_EDTR0/1 are RESERVED   (WI, read 0)
//   SW_DEV_DEL_SPT=0          ->  PPU_DCDR0/1 are READ ONLY  (WI, read the
//                                 configured values, and those delays still
//                                 apply to every transition)
//
// Section 5.2.21 says "this register is read only"; Section 7.1.4 says the
// parameters are then "the fixed values for the device control delays". So the
// wrong implementation -- treating both as reserved -- would read zero from
// PPU_DCDR0 and, worse, could look correct while silently running with no
// device-control spacing at all. M6 checks the read values AND times a real
// transition to show the fixed delays are still being applied.

module ppu_minconfig_tb;

  import ppu_pkg::*;

  localparam int unsigned CNT_W = 8;

  // Deliberately non-default device-control delays. Distinct values, one per
  // field, so a read of PPU_DCDR0/1 has a signature that cannot be produced by
  // accident: a reset value, a stuck bus and a mis-ordered field assignment all
  // look different from 0x00050607.
  localparam logic [7:0] P_RST_HWSTAT = 8'd5;
  localparam logic [7:0] P_ISO_CLKEN  = 8'd6;
  localparam logic [7:0] P_CLKEN_RST  = 8'd7;
  localparam logic [7:0] P_CLKEN_ISO  = 8'd3;
  localparam logic [7:0] P_ISO_RST    = 8'd4;

  localparam logic [31:0] DCDR0_FIXED = {8'h0, P_RST_HWSTAT, P_ISO_CLKEN, P_CLKEN_RST};
  localparam logic [31:0] DCDR1_FIXED = {16'h0, P_CLKEN_ISO, P_ISO_RST};

  // Expected identification words, derived by hand from Tables 5-26 and 5-27 so
  // that they are an independent statement of intent rather than a copy of what
  // ppu_regs computes.
  //
  //   IDR0 full = 0x1E53E501. The dynamic-support bits are 28, 27, 26, 25, 22
  //   and 20 (DYN_ON, DYN_FUNC_RET, DYN_FULL_RET, DYN_MEM_OFF, DYN_MEM_RET,
  //   DYN_OFF), which together are 0x1E500000.
  localparam logic [31:0] IDR0_FULL = 32'h1E53_E501;
  localparam logic [31:0] IDR0_NODYN = IDR0_FULL & ~32'h1E50_0000;

  //   IDR1 full = 0x00001077: bit 12 OFF_MEM_RET_TRANS, bits 6:4 the three
  //   retention-RAM registers, bit 2 LOCK_SPT, bit 1 SW_DEV_DEL_SPT, bit 0
  //   PWR_MODE_ENTRY_DEL_SPT. Clearing all of them leaves a PPU that advertises
  //   no optional features at all.
  localparam logic [31:0] IDR1_FULL   = 32'h0000_1077;
  localparam logic [31:0] IDR1_MIN    = 32'h0000_0000;
  localparam logic [31:0] IDR1_NOLOCK = IDR1_FULL & ~32'h0000_0004;

  // ---------------------------------------------------------------------------
  logic aon_clk = 1'b0, dclk = 1'b0, mclk = 1'b0;
  always #2.15 aon_clk = ~aon_clk;
  always #6.85 dclk    = ~dclk;
  always #0.5  mclk    = ~mclk;

  logic aon_rst_n = 1'b0;
  logic mrst_n    = 1'b0;

  logic [11:0] reg_waddr  = 12'h000;

  logic [11:0] reg_raddr = 12'h000;
  logic [31:0] reg_wdata = 32'h0;
  logic        reg_wen   = 1'b0;
  logic [3:0] reg_wstrb = 4'hF;
  logic        reg_ren   = 1'b0;

  logic             start = 1'b0;
  logic [CNT_W-1:0] work_len = '0;
  logic             light_work = 1'b1;
  logic             wake = 1'b0;
  logic             deny_enb = 1'b0;

  logic [31:0] rd_min, rd_max, rd_nlk;
  logic        irq_min, irq_max, irq_nlk;

  int unsigned tb_errors = 0, checks = 0;

  // ---------------------------------------------------------------------------
  // Three builds of the same PPU
  // ---------------------------------------------------------------------------
  `define PPU_CFG_DUT(NAME, LK, SWD, EDT, DYN, RRR, OMR, RDATA, IRQ)          \
    ppu_pd_top #(                                                             \
      .SYNC_STAGES           (2),                                             \
      .CNT_W                 (CNT_W),                                         \
      .DEF_PWR_POLICY        (PM_ON),                                         \
      .OFF_MEM_RET_TRANS_CFG (OMR),                                           \
      .LOCK_CFG              (LK),                                            \
      .SW_DEV_DEL_CFG        (SWD),                                           \
      .PWR_MODE_ENTRY_DEL_CFG(EDT),                                           \
      .DYN_ON_SPT_CFG        (DYN),                                           \
      .DYN_FUNC_RET_SPT_CFG  (DYN),                                           \
      .DYN_MEM_OFF_SPT_CFG   (DYN),                                           \
      .DYN_FULL_RET_SPT_CFG  (DYN),                                           \
      .DYN_MEM_RET_SPT_CFG   (DYN),                                           \
      .DYN_OFF_SPT_CFG       (DYN),                                           \
      .FUNC_RET_RAM_REG_CFG  (RRR),                                           \
      .FULL_RET_RAM_REG_CFG  (RRR),                                           \
      .MEM_RET_RAM_REG_CFG   (RRR),                                           \
      .RST_HWSTAT_DLY_CFG    (P_RST_HWSTAT),                                  \
      .ISO_CLKEN_DLY_CFG     (P_ISO_CLKEN),                                   \
      .CLKEN_RST_DLY_CFG     (P_CLKEN_RST),                                   \
      .CLKEN_ISO_DLY_CFG     (P_CLKEN_ISO),                                   \
      .ISO_RST_DLY_CFG       (P_ISO_RST)                                      \
    ) NAME (                                                                  \
      .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),                               \
      .reg_waddr(reg_waddr), .reg_raddr(reg_raddr), .reg_wdata(reg_wdata),                             \
      .reg_wen(reg_wen), .reg_wstrb(reg_wstrb),                               \
      .reg_ren(reg_ren),                                                      \
      .reg_rdata(RDATA), .irq(IRQ),                                           \
      .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),                \
      .ppuclk_qactive(), .pwakeup(1'b0),                                      \
      .dclk(dclk), .start(start), .work_len(work_len),                        \
      .light_work(light_work), .wake(wake), .deny_enb(deny_enb),              \
      .ip_cmd(2'b00), .ip_seed(8'h00)                                         \
    )

  //                LOCK  SWDEL  EDT   DYN   RAMR  OFF->MEM_RET
  `PPU_CFG_DUT(u_max, 1'b1, 1'b1, 1'b1, 1'b1, 1'b1, 1'b1, rd_max, irq_max);
  `PPU_CFG_DUT(u_min, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, rd_min, irq_min);
  `PPU_CFG_DUT(u_nlk, 1'b0, 1'b1, 1'b1, 1'b1, 1'b1, 1'b1, rd_nlk, irq_nlk);

  // ---------------------------------------------------------------------------
  // Two builds that were not expressible before the Section 7 parameters landed
  // ---------------------------------------------------------------------------
  // u_nofr drops a MODE. Table 7-1 makes FULL_RET optional, and until the
  // per-mode parameters existed the seven-mode set was hardwired.
  logic [31:0] rd_nofr; logic irq_nofr;
  ppu_pd_top #(
    .SYNC_STAGES(2), .CNT_W(CNT_W), .DEF_PWR_POLICY(PM_ON),
    .STA_FULL_RET_SPT_CFG (1'b0),
    .DYN_FULL_RET_SPT_CFG (1'b0),   // dynamic requires static
    .FULL_RET_RAM_REG_CFG (1'b0)    // Section 7.1.5: mode gone, register reserved
  ) u_nofr (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n), .reg_waddr(reg_waddr), .reg_raddr(reg_raddr),
    .reg_wdata(reg_wdata), .reg_wen(reg_wen), .reg_wstrb(reg_wstrb), .reg_ren(reg_ren),
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .reg_rdata(rd_nofr), .irq(irq_nofr), .dclk(dclk), .start(start),
    .work_len(work_len), .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  // u_mixdyn is the specification's OWN example of a mixed configuration,
  // Section 3.4.3: "a domain might support dynamic and static transitions to
  // FUNC_RET but only static transitions to OFF". With one DYN_SPT switch this
  // could not be built at all.
  logic [31:0] rd_mix; logic irq_mix;
  ppu_pd_top #(
    .SYNC_STAGES(2), .CNT_W(CNT_W), .DEF_PWR_POLICY(PM_ON),
    .DYN_OFF_SPT_CFG (1'b0)         // static OFF only; FUNC_RET keeps both
  ) u_mix (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n), .reg_waddr(reg_waddr), .reg_raddr(reg_raddr),
    .reg_wdata(reg_wdata), .reg_wen(reg_wen), .reg_wstrb(reg_wstrb), .reg_ren(reg_ren),
    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(),
    .ppuclk_qactive(), .pwakeup(1'b0),
    .reg_rdata(rd_mix), .irq(irq_mix), .dclk(dclk), .start(start),
    .work_len(work_len), .light_work(light_work), .wake(wake), .deny_enb(deny_enb),
    .ip_cmd(2'b00), .ip_seed(8'h00)
  );

  wire [3:0] mode_nofr = u_nofr.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] mode_mix  = u_mix.u_dom.u_ppu.u_seq.pwr_status;

  wire [3:0] mode_min = u_min.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] mode_max = u_max.u_dom.u_ppu.u_seq.pwr_status;
  wire [3:0] mode_nlk = u_nlk.u_dom.u_ppu.u_seq.pwr_status;

  wire busy_min = (u_min.u_dom.u_ppu.u_seq.state !== 4'd0);
  wire busy_max = (u_max.u_dom.u_ppu.u_seq.state !== 4'd0);

  // PCSMPSTATE[15:8] is the RAM configuration the PCSM is told to apply. It is
  // the only place the retention-RAM registers reach hardware, so it is where
  // RET_RAM_REGS=0 has to be observed rather than merely read back.
  wire [7:0] ramcfg_min = u_min.u_dom.u_ppu.pcsm_pstate[15:8];
  wire [7:0] ramcfg_max = u_max.u_dom.u_ppu.pcsm_pstate[15:8];

  // ---------------------------------------------------------------------------
  // The reduced build is still a PPU: the same monitors, the same rules
  // ---------------------------------------------------------------------------
  // Attached to u_min specifically. Removing optional features must not change
  // the device-control sequence, the Q-Channel protocol or the power ordering --
  // Section 7 configures what the PPU OFFERS, never how it behaves when it acts.
  // If clearing a parameter perturbed the sequencing, these would catch it, and
  // nothing else in this file would.
  int unsigned qviol, uviol, pmviol;

  // Compared against 1 rather than inverted so that an unpowered PD_DEV reads
  // as "gated" instead of X under "make ppucfgpa" -- u_clkctrl is in the
  // switched domain. Identical to ~en_latch in ordinary simulation. The full
  // reasoning, and the two failures it caused, are in ppu_pd_tb.sv.
  wire clk_gated_min = (u_min.u_dom.u_clkctrl.en_latch !== 1'b1);

  qchannel_monitor u_qmon (
    .clk(mclk), .rst_n(mrst_n),
    .crst_n(aon_rst_n), .drst_n(u_min.u_dom.dev_rst_in_n), .clk_gated(clk_gated_min),
    .qreqn(u_min.u_dom.dev_qreqn), .qacceptn(u_min.u_dom.dev_qacceptn),
    .qdeny(u_min.u_dom.dev_qdeny), .violations(qviol)
  );

  ppu_monitor u_umon (
    .clk(mclk), .rst_n(mrst_n), .ppu_rst_n(aon_rst_n),
    .ppuhwstat(u_min.ppuhwstat),
    .dev_clken(u_min.u_dom.dev_clken), .dev_isolaten(u_min.dev_isolaten),
    .dev_poresetn(u_min.u_dom.dev_poresetn), .dev_warmresetn(u_min.u_dom.dev_warmresetn),
    .dev_retresetn(u_min.u_dom.dev_retresetn),
    .pcsm_pstate(u_min.u_dom.pcsm_pstate), .pcsm_preq(u_min.u_dom.pcsm_preq),
    .dev_qreqn(u_min.u_dom.dev_qreqn), .dev_qacceptn(u_min.u_dom.dev_qacceptn),
    .dev_qdeny(u_min.u_dom.dev_qdeny),
    .violations(uviol)
  );

  ppu_power_model u_pwr (
    .clk(aon_clk), .rst_n(aon_rst_n),
    .dev_clken(u_min.u_dom.dev_clken), .dev_isolaten(u_min.dev_isolaten),
    .dev_poresetn(u_min.u_dom.dev_poresetn), .dev_warmresetn(u_min.u_dom.dev_warmresetn),
    .dev_retresetn(u_min.u_dom.dev_retresetn),
    .logic_on(u_min.logic_on), .logic_ret(u_min.logic_ret),
    .ram_on(u_min.u_dom.ram_on), .ram_ret(u_min.u_dom.ram_ret),
    .ret_n(u_min.ret_n), .wl_rst_n(u_min.wl_rst_n),
    .corrupt(), .iso_clamp(), .ret_valid(),
    .do_save(), .do_restore(),
    .violations(pmviol)
  );

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  task automatic check(input bit cond, input string tag);
    begin
      checks++;
      if (!cond) begin tb_errors++; $display("[%0t] FAIL %0s", $time, tag); end
      else            $display("[%0t]  ok  %0s", $time, tag);
    end
  endtask

  task automatic check_hex(input logic [31:0] got, input logic [31:0] exp,
                           input string tag);
    begin
      checks++;
      if (got !== exp) begin
        tb_errors++;
        $display("[%0t] FAIL %0s: read 0x%08h, expected 0x%08h", $time, tag, got, exp);
      end else begin
        $display("[%0t]  ok  %0s = 0x%08h", $time, tag, exp);
      end
    end
  endtask

  task automatic check_mode(input logic [3:0] got, input logic [3:0] exp,
                            input string tag);
    begin
      checks++;
      if (got !== exp) begin
        tb_errors++;
        $display("[%0t] FAIL %0s: %0s, expected %0s", $time, tag,
                 ppu_mode_name(got), ppu_mode_name(exp));
      end else begin
        $display("[%0t]  ok  %0s = %0s", $time, tag, ppu_mode_name(exp));
      end
    end
  endtask

  // One read transaction, three answers. The builds are compared at the same
  // instant on the same bus, so a difference is a difference in the DUTs and
  // cannot be a difference in how they were driven.
  task automatic reg_read(input logic [11:0] a);
    begin
      @(negedge aon_clk);
      reg_raddr = a; reg_ren = 1'b1;
      @(negedge aon_clk);
      reg_ren = 1'b0;
      @(negedge aon_clk);   // registered read data
    end
  endtask

  task automatic reg_write(input logic [11:0] a, input logic [31:0] d);
    begin
      @(negedge aon_clk);
      reg_waddr = a; reg_wdata = d; reg_wstrb = 4'hF; reg_wen = 1'b1;
      @(negedge aon_clk);
      reg_wen = 1'b0;
    end
  endtask

  // Compare one register across the reduced and full builds in a single
  // transaction. Both expectations are supplied by the caller, and they must
  // differ -- passing the same value twice is a check that cannot discriminate,
  // so the task refuses it rather than reporting a pass.
  task automatic check_pair(input logic [11:0] a,
                            input logic [31:0] exp_min,
                            input logic [31:0] exp_max,
                            input string tag);
    begin
      reg_read(a);
      if (exp_min === exp_max) begin
        tb_errors++;
        checks++;
        $display("[%0t] FAIL %0s: check_pair called with identical expectations",
                 $time, tag);
      end else begin
        check_hex(rd_min, exp_min, {tag, " [min]"});
        check_hex(rd_max, exp_max, {tag, " [max]"});
      end
    end
  endtask

  task automatic set_policy(input logic [3:0] m, input bit dyn, input bit lock);
    reg_write(A_PWPR, {19'h0, lock, 3'h0, dyn, 4'h0, m});
  endtask

  task automatic settle();
    repeat (400) @(posedge aon_clk);
  endtask

  task automatic banner(input string name);
    $display("\n[%0t] ========== %0s ==========", $time, name);
  endtask

  // Cycles from now until the departure request appears on the device
  // interface, capped.
  //
  // Measured on DEVQREQn rather than on the sequencer's busy flag, and the
  // difference is the whole measurement: the entry-delay timer is a STATE of
  // the sequencer, so busy rises when the PPU starts WAITING, not when it
  // starts acting. Timing against busy reports the same three cycles whether
  // the timer is present or absent, which is a check that silently cannot fail.
  // DEVQREQn falling is the first externally visible thing a departure does,
  // and it is what the delay actually delays.
  task automatic time_to_qreq(input bit use_min, output int unsigned n);
    begin
      n = 0;
      while (n < 4000) begin
        @(posedge aon_clk);
        if (!(use_min ? u_min.u_dom.dev_qreqn : u_max.u_dom.dev_qreqn)) return;
        n++;
      end
    end
  endtask

  // Cycles a whole transition occupies: wait for it to begin, then time it to
  // completion. The initial wait is not optional -- sampling busy immediately
  // after a policy write finds it still LOW and reports a one-cycle transition.
  task automatic time_transition(input bit use_min, output int unsigned n);
    begin
      n = 0;
      while (n < 4000) begin
        @(posedge aon_clk);
        n++;
        if (use_min ? busy_min : busy_max) break;
      end
      while (n < 4000) begin
        @(posedge aon_clk);
        n++;
        if (!(use_min ? busy_min : busy_max)) return;
      end
    end
  endtask

  // Did this build pass through ON on its way somewhere? Sampled continuously,
  // because the visit is transient -- pwr_status holds ON only between two
  // hops of an ON-anchored route.
  bit watch_on = 1'b0;
  bit saw_on_min = 1'b0, saw_on_max = 1'b0;
  always @(posedge aon_clk) begin
    if (watch_on) begin
      if (mode_min === PM_ON) saw_on_min <= 1'b1;
      if (mode_max === PM_ON) saw_on_max <= 1'b1;
    end
  end

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("ppu_minconfig_tb.vcd");
    $dumpvars(0, ppu_minconfig_tb);

    $display("==============================================================");
    $display(" PPU reduced-configuration run (Chapter 7)");
    $display("   u_max : every optional feature built");
    $display("   u_min : LOCK, SW_DEV_DEL, ENTRY_DEL, DYN, RET_RAM_REGS and");
    $display("           OFF_MEM_RET_TRANS all cleared");
    $display("   u_nlk : LOCK_SPT cleared alone, dynamic still supported");
    $display("==============================================================");

    aon_rst_n = 1'b0; mrst_n = 1'b0;
    repeat (10) @(posedge aon_clk);
    @(negedge aon_clk) aon_rst_n = 1'b1;
    repeat (4) @(posedge aon_clk);
    mrst_n = 1'b1;
    settle();

    // =========================================================================
    banner("M1  Identification: the build describes itself");
    // =========================================================================
    $display("[%0t]   Section 5.2.23/5.2.24. This is the contract that makes", $time);
    $display("[%0t]   every other check in this file meaningful: software has no", $time);
    $display("[%0t]   way to discover the register map except by reading these", $time);
    $display("[%0t]   two words, so a build whose PPU_IDR disagrees with its own", $time);
    $display("[%0t]   behaviour is unusable even though every register works.", $time);

    check_pair(A_IDR0, IDR0_NODYN, IDR0_FULL, "M1 PPU_IDR0");
    check_pair(A_IDR1, IDR1_MIN,   IDR1_FULL, "M1 PPU_IDR1");

    reg_read(A_IDR1);
    check_hex(rd_nlk, IDR1_NOLOCK, "M1 PPU_IDR1 [nolock] only LOCK_SPT cleared");

    check(rd_min[0] === 1'b0 && rd_max[0] === 1'b1,
          "M1 IDR1[0] PWR_MODE_ENTRY_DEL_SPT differs between builds");
    check(rd_min[1] === 1'b0 && rd_max[1] === 1'b1,
          "M1 IDR1[1] SW_DEV_DEL_SPT differs between builds");
    check(rd_min[2] === 1'b0 && rd_max[2] === 1'b1,
          "M1 IDR1[2] LOCK_SPT differs between builds");
    check(rd_min[6:4] === 3'b000 && rd_max[6:4] === 3'b111,
          "M1 IDR1[6:4] retention-RAM registers differ between builds");
    check(rd_min[12] === 1'b0 && rd_max[12] === 1'b1,
          "M1 IDR1[12] OFF_MEM_RET_TRANS differs between builds");

    // Not every register may move. AIDR is the architecture version, IIDR the
    // part number: both must be identical across builds, because a reduced
    // configuration is the same PPU architecture and the same product.
    reg_read(A_AIDR);
    check(rd_min === rd_max && rd_min === 32'h0000_0011,
          "M1 PPU_AIDR identical across builds (architecture v1.1)");
    reg_read(A_IIDR);
    check(rd_min === rd_max, "M1 PPU_IIDR identical across builds");

    // =========================================================================
    banner("M2  Lock removed: PPU_UNLK, LOCK_EN, LOCK_STATUS, PPU_IMR[5]");
    // =========================================================================
    $display("[%0t]   Sections 5.2.1, 5.2.4, 5.2.7 and 5.2.11: with lock", $time);
    $display("[%0t]   unsupported, PPU_PWPR.LOCK_EN, PPU_PWSR.LOCK_STATUS,", $time);
    $display("[%0t]   PPU_UNLK and the PPU_IMR/ISR LOCKED bit are all reserved,", $time);
    $display("[%0t]   and Section 5.2 makes every reserved bit WI/RAZ.", $time);

    // The interrupt mask's RESET value changes shape, not just its writability:
    // Table 5-13's default masks the LOCKED event, and a bit that does not
    // exist cannot be masked.
    reg_read(A_IMR);
    check_hex(rd_max, 32'h0000_0022, "M2 PPU_IMR reset [max] LOCKED+STA_ACCEPT masked");
    check_hex(rd_min, 32'h0000_0002, "M2 PPU_IMR reset [min] LOCKED bit absent");
    check_hex(rd_nlk, 32'h0000_0002, "M2 PPU_IMR reset [nolock] LOCKED bit absent");

    reg_write(A_IMR, 32'hFFFF_FFFF);
    check_pair(A_IMR, 32'h0000_0007, 32'h0000_0027, "M2 PPU_IMR writable mask");
    reg_write(A_IMR, 32'h0000_0022);

    reg_write(A_PWPR, 32'h0000_1108);   // LOCK_EN(12)=1, PWR_DYN_EN(8)=1, policy=ON
    check_pair(A_PWPR, 32'h0000_0008, 32'h0000_1108, "M2 PPU_PWPR.LOCK_EN write");

    reg_read(A_UNLK);
    check(rd_min === 32'h0 && rd_max === 32'h0,
          "M2 PPU_UNLK reads zero in both builds (WO, Table 5-8)");

    // Functional lock, isolated. u_nlk has dynamic enabled, so the only reason
    // it can fail to lock is that lock was not built.
    banner("M2b Functional lock, with dynamic held constant");
    set_policy(PM_OFF, 1'b1, 1'b1);
    settle();
    check_mode(mode_max, PM_OFF, "M2b [max] reached OFF");
    check_mode(mode_nlk, PM_OFF, "M2b [nolock] reached OFF");

    reg_read(A_PWSR);
    check(rd_max[12] === 1'b1, "M2b [max] PPU_PWSR.LOCK_STATUS set on arriving in OFF");
    check(rd_nlk[12] === 1'b0, "M2b [nolock] LOCK_STATUS stays 0 -- lock not built");

    // The behaviour the lock exists to produce: a dynamic PPU parked in OFF
    // climbs back out on DEVQACTIVE unless it is locked. Same wake, same
    // policy, same dynamic enable -- only LOCK_SPT differs.
    $display("[%0t]   Section 3.4.3: a locked PPU ignores DEVQACTIVE. Asserting", $time);
    $display("[%0t]   wake now separates the two builds by BEHAVIOUR, not just by", $time);
    $display("[%0t]   a status bit -- u_nlk must climb to ON, u_max must not move.", $time);
    wake = 1'b1;
    settle();
    check_mode(mode_max, PM_OFF, "M2b [max] locked: stayed in OFF despite DEVQACTIVE");
    check_mode(mode_nlk, PM_ON,  "M2b [nolock] unlocked: climbed to ON on DEVQACTIVE");
    wake = 1'b0;

    // Release the lock the supported way, so later phases start from a clean
    // state in every build.
    reg_write(A_UNLK, 32'h1);
    set_policy(PM_ON, 1'b0, 1'b0);
    settle();
    check_mode(mode_max, PM_ON, "M2b [max] unlocked via PPU_UNLK and returned to ON");

    // =========================================================================
    banner("M3  Dynamic transitions removed");
    // =========================================================================
    $display("[%0t]   Section 5.2.1: 'If dynamic modes are not supported this bit", $time);
    $display("[%0t]   is reserved.' PPU_PWPR.PWR_DYN_EN is write-ignored, so", $time);
    $display("[%0t]   PPU_PWSR.PWR_DYN_STATUS can never report dynamic operation.", $time);

    set_policy(PM_ON, 1'b1, 1'b0);   // ask for dynamic in both builds
    settle();
    check_pair(A_PWPR, 32'h0000_0008, 32'h0000_0108, "M3 PPU_PWPR.PWR_DYN_EN write");

    reg_read(A_PWSR);
    check(rd_min[8] === 1'b0, "M3 [min] PWR_DYN_STATUS stays 0 -- dynamic not built");
    check(rd_max[8] === 1'b1, "M3 [max] PWR_DYN_STATUS follows the enable");

    // The reduced build must still be a working static PPU. A parameter that
    // removes a feature and also breaks the remaining one is the failure this
    // guards against.
    set_policy(PM_MEM_OFF, 1'b1, 1'b0);
    settle();
    check_mode(mode_min, PM_MEM_OFF, "M3 [min] static policy still takes effect");
    set_policy(PM_ON, 1'b0, 1'b0);
    settle();

    // =========================================================================
    banner("M4  Retention-RAM configuration registers removed");
    // =========================================================================
    $display("[%0t]   Sections 5.2.16-5.2.18 and 7.1.5: with the register", $time);
    $display("[%0t]   reserved, PCSMPSTATE[15:8] -- the RAM configuration the", $time);
    $display("[%0t]   PCSM actually applies -- has no software input and must be 0.", $time);

    reg_write(A_FUNRR, 32'h0000_005A);
    reg_write(A_FULRR, 32'h0000_00C3);
    reg_write(A_MEMRR, 32'h0000_00A5);

    check_pair(A_FUNRR, 32'h0, 32'h0000_005A, "M4 PPU_FUNRR");
    check_pair(A_FULRR, 32'h0, 32'h0000_00C3, "M4 PPU_FULRR");
    check_pair(A_MEMRR, 32'h0, 32'h0000_00A5, "M4 PPU_MEMRR");

    // Reaching hardware: the register is only interesting because of what it
    // drives, and this is the check that a reserved register drives nothing.
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    settle();
    check_mode(mode_min, PM_MEM_RET, "M4 [min] reached MEM_RET");
    check_mode(mode_max, PM_MEM_RET, "M4 [max] reached MEM_RET");
    check(ramcfg_max === 8'hA5,
          "M4 [max] PCSMPSTATE[15:8] carries PPU_MEMRR to the PCSM");
    check(ramcfg_min === 8'h00,
          "M4 [min] PCSMPSTATE[15:8] is zero -- no register to carry");

    set_policy(PM_ON, 1'b0, 1'b0);
    settle();

    // =========================================================================
    banner("M5  Power-mode entry delay removed");
    // =========================================================================
    $display("[%0t]   Section 5.2.19: 'When it is not supported, this register", $time);
    $display("[%0t]   is reserved.' Reserved means the timer is gone, so the", $time);
    $display("[%0t]   transition must start without waiting.", $time);

    reg_write(A_EDTR0, 32'h0000_0060);   // OFF_DEL = 0x60
    reg_write(A_EDTR1, 32'h0000_0000);
    check_pair(A_EDTR0, 32'h0, 32'h0000_0060, "M5 PPU_EDTR0");

    begin
      int unsigned t_min, t_max;
      fork
        time_to_qreq(1'b1, t_min);
        time_to_qreq(1'b0, t_max);
        begin
          @(negedge aon_clk);
          reg_waddr = A_PWPR; reg_wdata = {28'h0, PM_OFF}; reg_wstrb = 4'hF; reg_wen = 1'b1;
          @(negedge aon_clk);
          reg_wen = 1'b0;
        end
      join
      $display("[%0t]   cycles from policy write to DEVQREQn asserting:", $time);
      $display("[%0t]     min build %0d, max build %0d (OFF_DEL programmed 0x60)",
               $time, t_min, t_max);
      check(t_max >= 8'h60,
            "M5 [max] entry delay timer held the transition off for OFF_DEL cycles");
      check(t_min < 8'h60,
            "M5 [min] transition started without waiting -- no timer built");
    end
    settle();
    check_mode(mode_min, PM_OFF, "M5 [min] still arrived in OFF");
    check_mode(mode_max, PM_OFF, "M5 [max] still arrived in OFF");

    reg_write(A_EDTR0, 32'h0000_0000);
    set_policy(PM_ON, 1'b0, 1'b0);
    settle();

    // =========================================================================
    banner("M6  Device-control delays: READ ONLY, not reserved");
    // =========================================================================
    $display("[%0t]   The distinction this phase exists for. Section 5.2.21:", $time);
    $display("[%0t]   'When device control delay configuration functionality is", $time);
    $display("[%0t]   not supported this register is read only' -- and Section", $time);
    $display("[%0t]   7.1.4: the parameters are then 'the fixed values for the", $time);
    $display("[%0t]   device control delays'. So PPU_DCDR0/1 keep reading their", $time);
    $display("[%0t]   configured contents, and those delays still apply.", $time);

    reg_read(A_DCDR0);
    check_hex(rd_min, DCDR0_FIXED, "M6 PPU_DCDR0 [min] reads the configured values");
    check_hex(rd_max, DCDR0_FIXED, "M6 PPU_DCDR0 [max] same before any write");
    reg_read(A_DCDR1);
    check_hex(rd_min, DCDR1_FIXED, "M6 PPU_DCDR1 [min] reads the configured values");

    // Now write zeros to both builds. The max build takes them; the min build
    // ignores them and keeps its fixed spacing.
    reg_write(A_DCDR0, 32'h0000_0000);
    reg_write(A_DCDR1, 32'h0000_0000);
    check_pair(A_DCDR0, DCDR0_FIXED, 32'h0, "M6 PPU_DCDR0 after writing zero");
    check_pair(A_DCDR1, DCDR1_FIXED, 32'h0, "M6 PPU_DCDR1 after writing zero");

    begin
      int unsigned d_min, d_max;
      set_policy(PM_OFF, 1'b0, 1'b0);
      fork
        time_transition(1'b1, d_min);
        time_transition(1'b0, d_max);
      join
      $display("[%0t]   ON->OFF duration after writing DCDR=0:", $time);
      $display("[%0t]     min build %0d cycles, max build %0d cycles", $time, d_min, d_max);
      check(d_min > d_max,
            "M6 [min] fixed device-control delays still applied despite the write");
    end
    settle();
    check_mode(mode_min, PM_OFF, "M6 [min] arrived in OFF");

    // =========================================================================
    banner("M7  OFF -> MEM_RET direct transition removed");
    // =========================================================================
    $display("[%0t]   Section 3.3.2 and Table 4-14. With OFF_MEM_RET_TRANS", $time);
    $display("[%0t]   cleared the direct hop does not exist, so the request must", $time);
    $display("[%0t]   fall back to the ON-anchored route -- OFF, ON, MEM_RET --", $time);
    $display("[%0t]   which is observable as a transient visit to ON.", $time);

    // Both builds are in OFF: min from M6, max needs taking there.
    set_policy(PM_OFF, 1'b0, 1'b0);
    settle();
    check_mode(mode_max, PM_OFF, "M7 [max] parked in OFF");
    check_mode(mode_min, PM_OFF, "M7 [min] parked in OFF");

    saw_on_min = 1'b0; saw_on_max = 1'b0;
    watch_on   = 1'b1;
    set_policy(PM_MEM_RET, 1'b0, 1'b0);
    settle();
    watch_on = 1'b0;

    check_mode(mode_min, PM_MEM_RET, "M7 [min] reached MEM_RET");
    check_mode(mode_max, PM_MEM_RET, "M7 [max] reached MEM_RET");
    check(saw_on_max === 1'b0, "M7 [max] took the direct hop -- never visited ON");
    check(saw_on_min === 1'b1, "M7 [min] routed through ON -- no direct hop built");

    set_policy(PM_ON, 1'b0, 1'b0);
    settle();

    // =========================================================================
    banner("M8  The reduced build is still a conforming PPU");
    // =========================================================================
    $display("[%0t]   Chapter 7 configures what the PPU OFFERS. None of it may", $time);
    $display("[%0t]   change how the PPU BEHAVES when it acts, so the reduced", $time);
    $display("[%0t]   build runs the full mode sweep under the same three", $time);
    $display("[%0t]   checkers every other testbench uses.", $time);

    begin
      logic [3:0] sweep [0:6];
      int i;
      sweep[0] = PM_FUNC_RET; sweep[1] = PM_MEM_OFF; sweep[2] = PM_FULL_RET;
      sweep[3] = PM_MEM_RET;  sweep[4] = PM_ON;      sweep[5] = PM_OFF;
      sweep[6] = PM_ON;
      for (i = 0; i < 7; i++) begin
        set_policy(sweep[i], 1'b0, 1'b0);
        settle();
        check_mode(mode_min, sweep[i], "M8 [min] reached the requested mode");
      end
    end

    // WARM_RST is a RESTING power mode, not a pulse. Table 3-1 gives it its own
    // encoding and Table 4-9 its own device-control row, and the PPU holds the
    // device there until software asks for something else -- so the check is
    // that it arrives and STAYS, and that it can then be left again.
    set_policy(PM_WARM_RST, 1'b0, 1'b0);
    settle();
    check_mode(mode_min, PM_WARM_RST, "M8 [min] entered WARM_RST");
    settle();
    check_mode(mode_min, PM_WARM_RST, "M8 [min] WARM_RST is a resting mode -- still there");
    set_policy(PM_ON, 1'b0, 1'b0);
    settle();
    check_mode(mode_min, PM_ON, "M8 [min] left WARM_RST for ON");

    // =========================================================================
    banner("M9  behaviour follows the per-mode Section 7 parameters");
    // =========================================================================
    $display("[%0t]   The point of replacing DYN_SPT and the hardwired mode set", $time);
    $display("[%0t]   with Table 7-1 and 7-4 parameters: a build can now drop one", $time);
    $display("[%0t]   MODE, and can support dynamic transitions to some modes and", $time);
    $display("[%0t]   not others. Neither was expressible before, and IDR bits", $time);
    $display("[%0t]   alone would not prove it -- the POLICY has to be refused.", $time);

    // ---- u_nofr: FULL_RET dropped entirely ----
    reg_read(A_IDR0);
    check(rd_nofr[14] === 1'b0, "M9 [nofr] PPU_IDR0.STA_FULL_RET_SPT reads 0");
    check(rd_max[14]  === 1'b1, "M9 [max]  ...and 1 in the full build");
    reg_read(A_IDR1);
    check(rd_nofr[5] === 1'b0, "M9 [nofr] PPU_IDR1.FULL_RET_RAM_REG reads 0");
    reg_write(A_FULRR, 32'h0000_00C3);
    reg_read(A_FULRR);
    check(rd_nofr === 32'h0, "M9 [nofr] PPU_FULRR reserved -- mode gone, register gone");

    reg_write(A_ISR, 32'hFFFF_FFFF); reg_write(A_AISR, 32'hFFFF_FFFF);
    set_policy(PM_FULL_RET, 1'b0, 1'b0);
    repeat (400) @(posedge aon_clk);
    check_mode(mode_nofr, PM_ON, "M9 [nofr] FULL_RET policy refused, stayed in ON");
    check_mode(mode_max, PM_FULL_RET, "M9 [max]  ...while the full build went there");
    reg_read(A_AISR);
    check(rd_nofr[0] === 1'b1, "M9 [nofr] and it raised UNSPT_POLICY_IRQ");
    check(rd_max[0]  === 1'b0, "M9 [max]  ...which the full build did not");
    set_policy(PM_ON, 1'b0, 1'b0);
    settle();
    reg_write(A_ISR, 32'hFFFF_FFFF); reg_write(A_AISR, 32'hFFFF_FFFF);

    // ---- u_mix: the specification's own mixed example ----
    reg_read(A_IDR0);
    check(rd_mix[27] === 1'b1, "M9 [mix] PPU_IDR0.DYN_FUNC_RET_SPT reads 1");
    check(rd_mix[20] === 1'b0, "M9 [mix] PPU_IDR0.DYN_OFF_SPT reads 0");

    set_policy(PM_FUNC_RET, 1'b1, 1'b0);          // dynamic FUNC_RET: allowed
    repeat (60) @(posedge aon_clk);
    reg_read(A_PWPR);
    check(rd_mix[3:0] === PM_FUNC_RET && rd_mix[8] === 1'b1,
          "M9 [mix] dynamic FUNC_RET accepted");
    settle();
    set_policy(PM_ON, 1'b0, 1'b0); settle();
    reg_write(A_ISR, 32'hFFFF_FFFF); reg_write(A_AISR, 32'hFFFF_FFFF);

    set_policy(PM_OFF, 1'b1, 1'b0);               // dynamic OFF: refused
    repeat (60) @(posedge aon_clk);
    reg_read(A_PWPR);
    check(rd_mix[3:0] === PM_ON, "M9 [mix] dynamic OFF refused");
    reg_read(A_AISR);
    check(rd_mix[0] === 1'b1, "M9 [mix] ...raising UNSPT_POLICY_IRQ");
    reg_write(A_ISR, 32'hFFFF_FFFF); reg_write(A_AISR, 32'hFFFF_FFFF);

    set_policy(PM_OFF, 1'b0, 1'b0);               // static OFF: still allowed
    repeat (400) @(posedge aon_clk);
    check_mode(mode_mix, PM_OFF, "M9 [mix] static OFF still accepted -- the same mode, both ways");
    set_policy(PM_ON, 1'b0, 1'b0); settle();
    reg_write(A_ISR, 32'hFFFF_FFFF); reg_write(A_AISR, 32'hFFFF_FFFF);

    check(qviol == 0, "M8 [min] qchannel_monitor: no protocol violations");
    check(uviol == 0, "M8 [min] ppu_monitor: no device-control violations");
    check(pmviol == 0, "M8 [min] ppu_power_model: no power-sequencing violations");

    // =========================================================================
    $display("\n==============================================================");
    $display(" ppu_minconfig_tb: %0d checks, %0d error(s)", checks, tb_errors);
    $display("   qchannel_monitor %0d, ppu_monitor %0d, ppu_power_model %0d",
             qviol, uviol, pmviol);
    if (tb_errors == 0 && qviol == 0 && uviol == 0 && pmviol == 0)
      $display(" RESULT: PASS");
    else
      $display(" RESULT: FAIL");
    $display("==============================================================\n");
    $finish;
  end

  // Edge-counted, for the same reason ppu_clkratio_tb counts edges: a timeout
  // in nanoseconds is an assumption about the clock, and this file changes the
  // DUT rather than the clock only because nothing here needed to change it.
  initial begin
    repeat (600000) @(posedge aon_clk);
    $display("\n[%0t] ppu_minconfig_tb: WATCHDOG -- simulation did not finish", $time);
    $display(" RESULT: FAIL");
    $fatal(1, "watchdog");
  end

endmodule
