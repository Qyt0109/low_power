# Testbenches

Every simulation testbench in the repository, one folder per block. Each
folder has its own README with the file table and the check groups; this page
is the index, the regression, and the rules every testbench follows.

The checkers that sit beside the testbenches are in two places: the protocol
monitors (`qchannel_monitor`, `pchannel_monitor`, `ppu_monitor`) are RTL-side
files in `src/rtl/<block>/`, and the behavioural power-intent model
(`ppu_power_model.sv`) is in [`ppu/`](ppu/). Formal properties are not here;
they are in [`src/formal/`](../formal/README.md).

---

## 1. Folders

| Folder | What it verifies | Make targets (`src/Makefile`) |
|---|---|---|
| [`acg/`](acg/README.md) | The access control gates: TL-UL `acg_tlul` (PCSA 7.2.8), the same gate in front of a PPU domain, and the TL-UH `acg_tluh` with the SCP wake line | `acg`, `acgpd`, `acgpdpa`, `acgtluh` |
| [`adp/`](adp/README.md) | `hart_ready_adp`, the READY-bit Q-Channel adapter for CVA6/Rocket harts, and its TL-UL READY registers | `readyadp` |
| [`ckrst/`](ckrst/README.md) | `ckrst_bridge`, the clock/reset request bridge, on a real PPU domain against a model of the SoC's clkgate/tilereset | `ckrst` (the model is also used by `soc4_tb`) |
| [`pchannel/`](pchannel/README.md) | The P-Channel controller/device pair, its monitor, and the ON/RETENTION/OFF example domain | `pch`, `pchneg`, `pchpd`, `pchall`, `pchlint`, `wave-pch` |
| [`pmu/`](pmu/README.md) | `scp_sim_ctrl.sv`: the SCP firmware's simulation-control peripheral (console, HALT, CHECK, device stimulus). No testbench of its own; `soc4_tb` instantiates it twice | (used by every `soc4*` target) |
| [`ppu/`](ppu/README.md) | The Arm PPU (DEN 0051E): the main domain suite, unit tests of its blocks, reset, clock-ratio, reduced-configuration, clock Q-Channel, AXI4-Lite, PCSM switch sequencing, and the power-intent model | `ppu`, `ppuall`, `ppuneg`, `ppurst`, `ppuratio`, `ppucfg`, `ppurstf`, `ppuirq`, `ppupm`, `ppuregdoc`, `ppube`, `ppudeny`, `ppudevif`, `ppuclkctrl`, `ppuclkq`, `ppuaxi`, `ppudemo`, `ppupcsmpg`, `lpdpd`, and the Xcelium `*pa` targets |
| [`qchannel/`](qchannel/README.md) | The Q-Channel gate-able domain and the LPD-Q expander/sequencer | `pd`, `lint`, `pa`, `wave-pd`, `lpdq` |
| [`soc4/`](soc4/README.md) | `soc4_tb`: the SCP on Ibex with four PPU domains, the always-on AP, the two-agent TL-UL RPMI mailbox, the watchdog and the clock/reset bridges; nine planted mutants; power-aware supply checks | `soc4`, `soc4bfm`, `soc4stress`, `soc4wdog`, `soc4ckrst`, `soc4neg`, `soc4pa`, `soc4bfmpa`, `soc4stresspa` |

---

## 2. Simulator

**VCS.** `SIM=vcs` is the Makefile's default, and every regression target
runs under it:

```
make -C src ppu
```

- The Makefile also has `xcelium` and `icarus` branches; its header says which
  targets each can run. The `soc4*` targets refuse any simulator but VCS
  (`soc4simcheck`), and `ppuaxi` needs a class-capable simulator
  (`vipcheck`). The Vivado `xsim` branch was removed on 2026-10-06.
- **`-licqueue`** is in the Makefile's default `VCSFLAGS`
  (`-full64 -sverilog -timescale=1ns/1ps -q -nc -licqueue`), so a run waits
  for a free licence instead of failing at once.
- A build goes to `build/vcs/<top>/` (`simv`, `vcs.log`, and the run's log or
  VCD); the soc4 power-aware build goes to `build/vcs_pa/soc4_tb/`. `build` is
  a symlink to `/sim/sovra/quyetdv/pmu/build`.
- **Power-aware simulation has two flows.** The soc4 targets (`soc4pa`,
  `soc4bfmpa`, `soc4stresspa`) use VCS native low power (`-upf
  upf/soc4_tb_vcs.upf`, `+define+SOC4_PA`, second top
  [`soc4/soc4_pa_supply_vcs.sv`](soc4/soc4_pa_supply_vcs.sv)). The older PPU,
  Q-Channel and ACG power-aware targets (`ppupa`, `ppupaall` and its nine
  members, `ppudemopa`, `wave-ppudemopa`, `lpdpdpa`, `acgpdpa`, `pa`) call
  Xcelium directly (`-lps_1801`, second top
  [`ppu/ppu_pa_supply.sv`](ppu/ppu_pa_supply.sv)), whatever `SIM` says. They
  run under Xcelium 25.09 (`/system/EDA/Cadence/xcelium/25.09.001`), which ran
  again on 2026-10-06 after the licence lapse of 2026-09-15;
  `scripts/run_regress.sh` puts it on `PATH`.

---

## 3. The regression

[`scripts/run_regress.sh`](../../scripts/run_regress.sh) (until 2026-10-06
`build/regress/run_regress.sh`, outside git) runs the regression, one log per
target. Its header gives the usage:

```
scripts/run_regress.sh <repo>/src <log dir> [make VAR=value ...]
TARGETS="ppu soc4" scripts/run_regress.sh <repo>/src <log dir>    # a subset
```

It appends `<target> rc=<n> <seconds>s` per target to `<log dir>/summary.txt`
and ends with `DONE`. A licence failure is retried after 180 s, at most three
times. The default list is the 31 VCS targets of the phase 6 regression:

```
ppu ppuneg ppurst ppuratio ppucfg ppurstf ppuirq ppupm ppuregdoc ppube ppudeny
ppudevif ppuclkctrl ppuclkq ppuaxi ppudemo ppupcsmpg acg acgpd soc4 soc4bfm
soc4stress soc4wdog soc4neg soc4pa soc4bfmpa soc4stresspa acgtluh readyadp ckrst
soc4ckrst
```

followed, since 2026-10-06, by the 13 Xcelium power-aware targets in
`XC_TARGETS` (`pa`, `ppupa`, `ppubepa`, `ppuregdocpa`, `ppurstpa`,
`ppurstfpa`, `ppucfgpa`, `ppuratiopa`, `ppuclkqpa`, `ppuaxipa`, `lpdpdpa`,
`acgpdpa`, `ppudemopa`), run under `SIM=xcelium`. Their results are not in
the table below, which is the phase 6 run.

Not in the regression: `pd`, `pch`, `pchneg`, `pchpd`, `lpdq`, `lpdpd`,
`ppuvlint` and `soc4elab`. (`ibexlint`, which
elaborated `scp_core` alone under Xcelium, was removed on 2026-10-06;
`soc4elab` elaborates it with the rest of `soc4_top`.)

### Latest results

From `build/regress_p6/` (2026-10-06, HEAD 732b7c7). The three power-aware
soc4 targets failed there (rc=2: Ibex `IbexInstrRValidX` /
`IbexInstrRPayloadXKnownEnable` `[ASSERT FAILED]` at 4,413,145 ns, on the UPF
before its final fix) and were re-run on the final UPF into
`build/regress_p6_pa/`; their rows below are from that run.

| Target | Testbench | Result (from the log) |
|---|---|---|
| `ppu` | `ppu_pd_tb` | `checks=617 errors=0`, `*** PPU TESTBENCH PASSED ***` |
| `ppuneg` | `ppu_monitor_negtest` | 17 checks, 60 violations flagged by the monitor, PASS |
| `ppurst` | `ppu_reset_tb` | 38 checks, PASS |
| `ppuratio` | `ppu_clkratio_tb` | 4 ratios (3.19, 10.00, 1.10, 0.15), each `RESULT: PASS` (the target filters out the counts) |
| `ppucfg` | `ppu_minconfig_tb` | 90 checks, PASS |
| `ppurstf` | `ppu_rstflight_tb` | 12 checks, PASS (101 `qchannel_monitor` violations, all at reset edges, as designed) |
| `ppuirq` | `ppu_irq_tb` | 16 checks, PASS |
| `ppupm` | `ppu_pm_tb` | 12 checks, PASS |
| `ppuregdoc` | `ppu_regdoc_tb` | 100 checks, PASS |
| `ppube` | `ppu_be_tb` | 38 checks, PASS |
| `ppudeny` | `ppu_deny_tb` | 42 checks, PASS |
| `ppudevif` | `ppu_devif_tb` | 47 checks, PASS |
| `ppuclkctrl` | `ppu_clkctrl_tb` | 82 checks, PASS |
| `ppuclkq` | `ppu_clkq_tb` | 81 checks, PASS |
| `ppuaxi` | `ppu_axi_lite_tb` | 64 checks, PASS |
| `ppudemo` | `ppu_demo_tb` | not a checker: tour complete, 17 steps |
| `ppupcsmpg` | `ppu_pcsm_pgood_tb` | 15 of 15 runs PASS |
| `acg` | `acg_tlul_tb` | 78 checks, PASS |
| `acgpd` | `ppu_acg_pd_tb` | 27 checks, PASS |
| `acgtluh` | `acg_tluh_tb` | 26 checks, PASS; 4 of 4 mutants fail at their own tag |
| `readyadp` | `hart_ready_adp_tb` | 35 checks, PASS; 2 of 2 mutants fail at their own tag |
| `ckrst` | `ckrst_bridge_tb` | 18 checks, PASS; 1 of 1 mutant fails at its own tag |
| `soc4` | `soc4_tb` (AP mode) | AP 76 checks, 0 fails; testbench 372 checks, PASS |
| `soc4bfm` | `soc4_tb` (BFM mode) | BFM 78,606 checks; testbench 79,491 checks, PASS |
| `soc4stress` | `soc4_tb` (SCP mode) | 34 features: 34 PASS, 0 DEVIATION, 0 FAIL; 1,812 firmware checks; testbench 7,621, PASS |
| `soc4wdog` | `soc4_tb` (SCP mode) | firmware 24 + 11 + 9 checks; 2 watchdog resets, 2 expected; testbench 18, PASS |
| `soc4ckrst` | `soc4_tb` (BFM, K1) | BFM 1,463 checks; testbench 1,545, PASS |
| `soc4neg` | `soc4_tb` + mutants | all nine mutants fail at their own checks |
| `soc4pa` | `soc4_tb` + UPF | testbench 404, 31 supply-net checks; LP ERROR 0, FATAL 0 |
| `soc4bfmpa` | `soc4_tb` + UPF | BFM 78,606; testbench 79,563, 71 supply-net checks; LP ERROR 0, FATAL 0 |
| `soc4stresspa` | `soc4_tb` + UPF | 34 PASS; testbench 7,875, 253 supply-net checks; LP ERROR 0, FATAL 0 |

The `pd`, `pch`, `pchneg`, `pchpd`, `lpdq` and `lpdpd` targets have no VCS log
(no `build/vcs/<top>` exists for them). The figures their RTL READMEs quote
are Icarus runs.

---

## 4. How a pass or fail is decided

Every testbench counts its checks and failures and ends with one line:
`RESULT: PASS` or `RESULT: FAIL` (`ppu_pd_tb` prints
`*** PPU TESTBENCH PASSED ***` / `FAILED`; `ppu_demo_tb` checks nothing). What
the make target does with it depends on the target:

| Targets | The make verdict |
|---|---|
| `acgtluh`, `readyadp`, `ckrst` (`unit_run`, `unit_neg`) | Fails unless the log has `RESULT: PASS`; then rebuilds once per mutant define and fails unless each mutant run ends `RESULT: FAIL` with at least one `ERROR: [chk:<tag>]` of its own tag |
| `soc4`, `soc4bfm`, `soc4wdog`, `soc4ckrst` (`scp_verdict`) | Fails unless `RESULT: PASS` and no `ASSERT FAILED` (Ibex, prim and `tlul_assert` report through `$error` without stopping the run) |
| `soc4stress`, `soc4stresspa` | As above, plus every `fw\| RESULT` feature line PASS or DEVIATION, and none FAIL |
| `soc4neg` | Each mutant run must end `RESULT: FAIL`, with its own `[chk:<tag>]` error, and without its forbidden line ([soc4/README.md](soc4/README.md)) |
| `soc4pa`, `soc4bfmpa`, `soc4stresspa` | Also: VCS's Low Power Message Summary with `ERROR = 0, FATAL = 0`, no `[ERROR] [LP_*]` line, each `SW_LOGIC_n` switching `VDD_LOGIC_n` FULL_ON to OFF at least once, and `power intent APPLIED (SOC4_PA)` in the report |
| `ppupcsmpg` | 15 runs, all `RESULT: PASS` |
| Every other target (`ppu*`, `acg`, `acgpd`, `pd`, `pch*`, `lpdq`, `lpdpd`, and the Xcelium `*pa` forms) (`tb_verdict`) | The run goes into a log kept in full, and the target fails unless the log has the testbench's pass line (`RESULT: PASS`, `TESTBENCH PASSED`, or `tour complete` for `ppudemo`), no failure line or non-zero error count, and no `[ASSERT FAILED]` or simulator error outside the Makefile's allow-list (`ASSERT_ALLOW_ACG`: OpenTitan's `prim_sparse_fsm_flop` check at time 0 in `acg`, `acgpd`, `acgpdpa`). The Makefile's "Pass/fail" section has the rules |

This verdict for the last row is new in the Makefile of 2026-10-06. The
phase 6 regression above ran before it, when those targets exited 0 after
`$finish` whatever the result, so their result column was read from each
log.

---

## 5. Rules every testbench follows

- **Checks are counted and tagged.** A check task (`ck`, `check`, `tck`)
  increments `checks`, and on failure `errors` and prints the time and the
  claim. The newer benches tag each check: a failure prints
  `tb| ERROR: [chk:<TAG>] ...`, and the negative controls (`unit_neg`,
  `soc4neg`) grep for the tag, so a mutant has to fail at the check written
  for it, not anywhere.
- **The probe rule.** A testbench never reads a register inside a switched
  domain. Under power intent such a register reads X, and a probe that
  reads it either fails for the wrong reason or, worse, passes (in Verilog
  `x -> 1` is a posedge). `soc4_tb` holds to it strictly (its header lists
  every place it reads: the PPU and PCSM, the always-on RAM arrays, the
  isolated outputs on the always-on side, `soc4_ctrl`/`soc4_mbx`, the SCP's
  interrupt block, watchdog and RAM; a supply net is not a register). The
  older PPU benches read a few `PD_DEV` signals on purpose (`ppu_pd_tb`'s
  `clk_gated` and P23's corruption check); each is documented where it is
  read, and `upf/README.md` ("Four testbench probes read registers inside
  the switched domain") records why `clk_gated` compares against 1 instead
  of inverting.
- **X-tolerant compares.** Every compare against a value that can be X uses
  `===` or `!==`, so an X never passes a check by accident.
- **Stimulus on the negedge.** Inputs are driven, and outputs sampled, on the
  negedge of the clock that samples them; the exceptions (edge counters,
  P7 of `pchannel_pd_tb` with its clock stopped) are commented.
- **Checkers are proven able to fail.** Each monitor has a negative test
  (`pchneg`, `ppuneg`, `ppupm`), and each new block has planted mutants.
- **Timeouts.** Every wait is bounded; a hang becomes a counted error or a
  watchdog `$fatal`, never a run that does not end.

---

## 6. Adding a testbench

1. Put it in `src/tb/<block>/`, named `<block>_tb.sv`, one top module of the
   same name (the top name is the build directory and the VCD name).
2. Use a tagged check task and end with
   `$display("<top>: %0d checks, %0d error(s)", checks, errors)` and
   `RESULT: PASS` / `RESULT: FAIL`. Add a cycle limit that prints
   `RESULT: FAIL`.
3. Add a target to `src/Makefile`. For a unit test with mutants, follow
   `acgtluh`/`readyadp`/`ckrst`: a source list, `$(call unit_run,<top>,<srcs>,<log>)`,
   then one `$(call unit_neg,<top>,<srcs>,<DEFINE>,<TAG>)` per mutant, the
   mutant being an `` `ifdef <DEFINE> `` in the RTL with a `NEGATIVE CONTROL`
   comment. Otherwise run it with `$(call tb_run,<top>,<log name>,<plusargs>,<display>)`.
   `unit_run` and `tb_run` give the target a real verdict; plain `sim_run`
   does not (Section 4).
4. Add the target to `.PHONY` and to the header comment of the Makefile, and
   to `TARGETS` in `scripts/run_regress.sh`.
5. Write the folder's README entry: what it checks, the tags, the count.

---

## 7. References

- `src/Makefile`: every target named above, with its header comment.
- [`scripts/run_regress.sh`](../../scripts/run_regress.sh); the phase 6 logs
  are in `build/regress_p6/` and `build/regress_p6_pa/`.
- [`src/upf/README.md`](../upf/README.md): the power intent, both
  power-aware flows, and what the first power-aware runs found.
- [`src/signoff/SIGNOFF_REPORT.md`](../signoff/SIGNOFF_REPORT.md) Section 7:
  the phase 6 regression.
- [`docs/SOC4_DESIGN.md`](../../docs/SOC4_DESIGN.md) Sections 10 and 11: the soc4 testbench
  and tests.
