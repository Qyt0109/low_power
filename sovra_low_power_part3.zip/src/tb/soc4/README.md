# soc4 testbench

`soc4_tb` is the testbench of soc4 (`src/soc4/`): the SCP on Ibex with four
PPU domains (CPU0 and CPU1, two Ibex CPUs; ACC0 and ACC1, two stand-in
accelerators built on `ppu_device_ip`), the always-on AP, and the TL-UL RPMI
mailbox with two agents (the AP on port 0, an RPU stand-in on port 1). It runs
the real SCP firmware and checks, from the always-on side, that every power
transition the firmware makes is what DEN 0051E requires and that each
domain's state (RAM, registers, boot) is what the mode promises. The design
is [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md); this testbench is its
Section 10, the tests its Section 11.

## Files

| File | Top | Role |
|---|---|---|
| `soc4_tb.sv` | `soc4_tb` | The testbench (all targets `soc4*`) |
| `soc4_pa_supply_vcs.sv` | `soc4_pa_supply_vcs` | Second elaboration top for the power-aware runs: energises `VDD` (0.90 V) and `VSS` with the IEEE 1801 UPF package's `supply_on()` (names relative to the UPF design top `soc4_tb/u_dut`), and `$fatal`s if either net is not found, since an unpowered design would make every check meaningless |

Also compiled in: [`../pmu/scp_sim_ctrl.sv`](../pmu/README.md),
[`../ppu/ppu_power_model.sv`](../ppu/README.md),
[`../ckrst/soc_ckrst_model.sv`](../ckrst/README.md), and OpenTitan's
`tlul_assert` (`vendor/opentitan/dv_utils`).

## Structure

```
soc4_tb
  u_dut     soc4_top (SCP, four PPU domains, AP, mailbox, soc4_ctrl)
  u_sim     scp_sim_ctrl TAG "fw" on the SCP's sim_* port   (console, HALT, CHECK, stimulus, OBS)
  u_apsim   scp_sim_ctrl TAG "ap" on the AP's ap_ext_* port
  tl_bfm    TL-UL BFM on mailbox port 0 (plays the AP when +bfm; bfm_sel strap selects it)
  rpu       TL-UL BFM on mailbox port 1 (the second agent, the RPU)
  g_soc_ckrst[0..3]  soc_ckrst_model per domain, latencies CKRST_LAT = {2, 2, 2, 6}
  g_obs[0..3]        per domain: ppu_monitor (on a 400 MHz mclk), ppu_power_model,
                     traffic and IRQ counts, the settle check, the observation window,
                     the spec tables at every committed hop, the hop log
  tlul_assert        bound in every soc4_tl_bound (Device) and in soc4_ap (Host)
```

- Clock `clk` 100 MHz; `rst_n` after 8 cycles; `scp_rst_n` with it, or
  `+scp_hold` cycles later.
- Device stimulus for the accelerators (start, light, wake, deny, work length,
  IP command and seed) is the OR of three sources: the SCP's `scp_sim_ctrl`,
  the AP's, and the BFM's own `tb_stim`. `hold_busy` is the BFM's mask OR the
  SCP's `AP_CMD 'H'`; the ACC deny also takes `AP_CMD 'D'`.
- The SCP's interrupt and wake inputs 5-13 (PLIC output, PLIC per-hart
  pending, RTC, GPIO, BBRX, debug, two access-gate wakes) are driven by the
  testbench (`t_irq`); inputs 0-4 are the PPUs and the doorbell.

### The two TL-UL BFMs

Both drive on negedges and sample on posedges, one TL-UL transaction at a time
(`a_size` 2, `d_ready` 1). Port 0's host sends `TL_A_USER_DEFAULT`; port 1's,
the RPU stand-in, sends `a_user` 0, as a TileLink host has none, and its
boundary adapter (`soc4_tl_bound`) supplies the default (H13). On top of the
transaction tasks (`tl_wr`, `tl_rd`, `tl_wr_err`, `tl_rd_err`) are the RPMI
tasks (`rpmi_send`, `rpmi_ack`, `rpmi_call`, `dp_set`, `dp_get`,
`dp_expect`), with the encodings of librpmi v1.0.0 cited by line and the queue
geometry of `scp_rpmi.h`: 64-byte slots, 8 per queue, A2P requests at +0x000
and P2A ACKs at +0x200, head in slot 0, tail in slot 1. Agent k's window is
`0x2000_0000 + k * 0x2000`, its doorbell at window + 0x1000. The AP's source
is 0x10; the RPU's sources are 0x20-0x23 (FW_VAL 0x20, FW_MASK 0xFC). Every
wait has a timeout that counts a `[bfm-timeout]` error and returns, so a run
never hangs.

## Modes and plusargs

| Plusarg / define | Effect |
|---|---|
| (none) | **ap** mode (`soc4`): the AP runs `+ap_firmware`, the run ends at the AP's HALT |
| `+bfm` | **bfm** mode (`soc4bfm`): the BFM plays the AP; the run ends when the BFM is done |
| `+bfm +bfm_only=none` | **scp** mode (`soc4stress`, `soc4wdog`): the SCP image is the test; the run ends at the SCP's HALT |
| `+bfm_only=B0,B4,...` | Run a subset of the BFM steps (`all` or empty: the default list); K1 runs only when named |
| `+scp_hold=<n>` | Hold the SCP in reset for n cycles after `rst_n` (`soc4bfm`: 3000, so B0 and R0 meet a firewall that denies everything) |
| `+firmware=<vmem>`, `+ap_firmware=<vmem>` | The SCP and AP RAM images (read by `scp_ram`), from `build/fw/soc4/` |
| `+quiet` | No line per committed hop |
| `+wdog_resets=<n>` | Watchdog resets the run must see (default 0; `soc4wdog` 2; W1 adds one) |
| `+max_cycles=<n>` | Cycle limit (default 20,000,000; the Makefile passes 20,000,000); reaching it is an error and ends the run with the report |
| `+define+SOC4_PCSM_RET_SETTLE=<n>`, `..._LOGIC_SETTLE=<n>` | PCSM switch settling for all four domains (default 0); `make soc4pa SIM=vcs PCSM_RET_SETTLE=30 PCSM_LOGIC_SETTLE=20` sets them |
| `+define+SOC4_PA` | The power-aware build: supply-net checks on |
| `+define+SOC4_MUT_*` | A planted mutant (soc4neg) |

## What is checked

### Continuously, per domain, in every mode

| Check | Source |
|---|---|
| `ppu_monitor` (U1-U12) and `ppu_power_model` (PU1-PU10) on each domain's PPU pins | `rtl/ppu/ppu_monitor.sv`, `tb/ppu/ppu_power_model.sv` |
| At every committed hop: the hop has ON at one end or is OFF → MEM_RET (Section 3.3.2); the device controls `{PORESETn, WARMRESETn, RETRESETn, CLKEN, ISOLATEn}` match Tables 4-7/4-9/4-11; PPUHWSTAT matches Table 3-2; PCSMPSTATE matches Table 4-12 (RAM byte of the retention mode entered) | the testbench's own transcription of the tables, not `ppu_pkg` |
| Table 4-5 device-control spacings, measured on every power-up and power-down against the programmed DCDR values | |
| Settling: no WARMRESETn release less than 20 cycles (`PD_SWITCH_SETTLE`) after the logic rail came on | |
| AXI4-Lite VALID/payload rules on the SCP's manager port | |
| `tlul_assert` on both mailbox ports and the AP (reports `[ASSERT FAILED]`) | OpenTitan |
| Every clock/reset bridge request equals its PPU control, every cycle | `ckrst_bridge` |
| Each watchdog reset: began with the AXI manager idle unless CAUSE.DRAINTO (`WDOG_DRAIN`), lasted 16 cycles (`WDOG_RESET`), reset the SCP subsystem only, not the domains, `soc4_ctrl` or the firewall (`WDOG_SCOPE`), left CAUSE WDOG set, POR clear and RESETS counting (`WDOG_CAUSE`) | `scp_wdog` |

`TB_ERRORS` (read by the firmware) is the failed checks plus every monitor,
power-model, AXI and settle violation.

### The PPU-level CHECK (Section 10.3)

Whenever firmware writes `CHECK` (domain, mode), or the BFM calls `ck_mode`,
the testbench checks: the PPU's committed mode, the PCSM's committed mode
(WARM_RST → ON), PPUHWSTAT, the five device controls, PCSMPSTATE[7:0] and
[15:8], the logic rail (`on` iff the mode keeps logic, `ret` iff FULL_RET),
the RAM rail (`on` in ON/WARM_RST, `ret` in FUNC_RET/FULL_RET/MEM_RET), and
under `SOC4_PA` the supply nets.

### The IP-state rules (Section 10.4)

After the PPU-level check of an AP checkpoint (ap mode) or a BFM `ck_mode`,
the rule for (domain, mode) runs in its own process; a rule may wait up to
20,000 cycles for the domain to get there. In scp mode only the PPU-level
check runs.

| Domain, mode | Tag | Checked, from the always-on side |
|---|---|---|
| CPU0, ON after a cold ON | `CPU0_BOOT` | RAM MARKER 0xC0DE0000, BOOT_COUNT 1, first fetch after the reset release at CPU0_BOOT + 0x80, TRAP 0; once in WFI, a snapshot of the RAM |
| CPU0, FULL_RET | `FULLRET_RAM` | RAM pins sleep 1, shutdown 0; all 1024 words equal the snapshot, none X |
| CPU0, ON after FULL_RET (no WARM_RST between) | `FULLRET_REGS` | WAKE_COUNT + 1, s0-s11 dumped equal to their signatures (the core's registers survived), BOOT_COUNT unchanged, the reset vector not fetched, TRAP 0 |
| CPU1, ON | `CPU1_RESTART` | first fetch at CPU1_BOOT + 0x80, MARKER 0xC0DE0001, BOOT_COUNT 1, COUNT rising over 1000 cycles, TRAP 0 |
| CPU1, OFF after a power-off | `CPU1_OFF` | RAM shut down, all words X; RETRY_CAP + 1 = 4 denials and requests, 0 accepts (denied, then forced) |
| CPU0 or CPU1, OFF otherwise | `OFF_RAM` | RAM shutdown pin 1, all 1024 words X |
| ACC, ON | `FILL`, `MEMRET_RAM`, `OFF_RAM` | after a fill: the 128 bank words equal the pattern of its seed; from MEM_RET: the pattern kept; from OFF: all X |
| ACC, MEM_RET | `MEMRET_RAM` | bank pins sleep 0xFF, shutdown 0x00; the pattern kept |
| ACC, OFF | `OFF_RAM` | all 128 words X |
| a domain in OFF or MEM_RET after a down-hop | `LOGIC_LOSS` | both device resets asserted and the clock off, held since the down-hop (and `VDD_LOGIC_n` OFF under `SOC4_PA`); after the next ON an ACC is idle from reset (busy 0, done 0) |

Logic loss is checked without a probe inside the domain: by the resets and
clock the PPU holds, and under UPF by the supply net.

### The BFM steps (soc4bfm, soc4ckrst; Section 11.2)

The default order is B0, R0, B1-B12, R1, W1. B1 runs before any step after R0
(it waits for the SCP and its queues). Each line the testbench prints for a
step names its tag.

| Step | Tags | What it does |
|---|---|---|
| B0 | `FW_RESET_DENY` | SCP held in reset: every TL-UL access is denied by the firewall |
| R0 | `AG_RESET_DENY` | The RPU's window is denied too (sources 0x20, 0x23, 0x10): DENY_CNT, FW_LAST, no ring, window unchanged |
| B1 | `INIT` | SCP released; AP_RUN set; queue heads and tails 0 |
| B2 | `FW_SRC_DENY`, `FW_ADMIT` | An unlisted `a_source` denied with no side effect; the AP's source admitted |
| B3 | `DISCOVER` | BASE v1.0, DEVICE_POWER present, SYSTEM_RESET absent; 4 domains, all OFF |
| B4 | `ONOFF` | ON and OFF on each domain (OFF lands in FULL_RET for CPU0, MEM_RET for ACC0, OFF otherwise), with IP-state rules |
| B5 | `CANCEL` | OFF then ON inside the hysteresis window: both SUCCESS, no PPU access, no hop |
| B6 | `DENY_FORCE` | A busy, denying ACC0: denied 1 + RETRY_CAP times, then forced to MEM_RET |
| B7 | `FAULT`, `FAULT_SETTLE`, `RECOVER` | ACC1's power-off misses its deadline (hold_busy): FAULT, an ON answered HW_FAULT (-8), the hop settles, then the WARM_RST recovery |
| B8 | `BAD_ID` | Out-of-range DOMAIN_ID and a state neither ON nor OFF: INVALID_PARAM, no PPU access |
| B9 | `NO_GROUP` | A request to an unregistered group: consumed, never answered; the BFM's wait times out cleanly and the next request works |
| B10 | `TLUL_MAP` | The TL-UL map: doorbell page offsets, another window, `d_error` where required |
| B11 | `CPU_FAULT`, `CPU_FAULT_SETTLE`, `CPU_RECOVER` | CPU1's power-off misses its deadline; released, the recovery powers it off; the next ON reloads its image (1024 words, CPU1_BOOT, FETCH_EN) |
| B12 | `WAKE_PLIC`, `WAKE_VOTE`, `WAKE_EDGE`, `IRQ_W1C`, `WAKE_LEVEL`, `WAKE_ACG`, `WAKE_REASON`, `NOTIFY`, `IGNORE`, `IRQ_MASK`, `IRQ_PPU` | Every SCP interrupt input type and its table action (`soc4_plat.h` SCP_PLAT_INPUTS): PLIC per-hart pending wakes CPU0 from FULL_RET and CPU1 from OFF (level), GPIO wakes ACC0 and an access-gate wake ACC1 (edge), RTC/BBRX recorded as wake reasons, the PLIC output notified, debug ignored, a masked input inert, level against edge across an OFF vote, the W1C, the PPU and doorbell deliveries through the block, Ibex's fast lines never HIGH |
| R1 | `AG_DISCOVER`, `FW_AGENT`, `FW_MASK`, `PERM`, `VOTE`, `WAKE_OWNER`, `AG_CONCURRENT` | Two agents: discovery on each transport; the firewall per transport and its value + mask; the RPU refused CPU0/CPU1 with RPMI_ERR_DENIED; votes that combine; GET_STATE per caller; the wake vote's owner; both agents at once |
| W1 | `WDOG_ARMED`, `WDOG_EXPIRE`, `WDOG_SCOPE`, `WDOG_REBOOT`, `WDOG_KEEP`, `WDOG_LOG`, `WDOG_LOST`, `WDOG_RPMI` | The SCP hung (its interrupt lines forced LOW): the watchdog resets the SCP subsystem alone; the firmware reboots and takes the domains over with no PPU transition; the fault log survives; RPMI served again with the votes kept |
| K1 | `CKRST_DCDR`, `CKRST_LATE`, `CKRST_LOG`, `CKRST_RECOVER` | soc4ckrst only. ACC1's DCDR fields are the table's (latency 6); the SoC's clkgate answers in 30: LATE, CLKRST and FAULT logged, the vote dropped, ACC1 recovered; back at 6, ON and OFF raise no fault |

### At the end of every run (Section 10.8)

`WDOG_COUNT` (exactly the expected watchdog resets); for the product image
once booted, `WDOG_ARMED` (EN, LOCK, TIMEOUT 0x0020_0000), `CKRST_NONE` (no
bridge fault except those a step makes) and `CKRST_DCDR` (every PPU's DCDR
fields are `pd_dev_delays_of`'s); `CKRST_FWD`; not timed out; every monitor,
power-model, AXI and settle count zero; no IP-state rule still waiting; the
run ended the way its mode ends (AP HALT 0, BFM done, or SCP HALT 0) and, in
ap and bfm modes, the SCP server did not halt; no `scp: FATAL` line. Then the report (hops,
denials, forced, AXI traffic, IRQs, handshakes, violations per domain; the
shortest spacings; watchdog; bridges) and `RESULT: PASS` if `errors` is 0.

## Negative controls (soc4neg)

Each mutant is a define, rebuilt into `build/vcs/soc4_tb`; each run must end
`RESULT: FAIL`, with at least one `tb| ERROR: ... [chk:<TAG>]`, and without
its forbidden line (SOC4_DESIGN.md Section 10.6).

| | Define | Where | The fault | Run | Must trip | Forbidden | Latest |
|---|---|---|---|---|---|---|---|
| M1 | `SOC4_MUT_CPU0_NRET` | `soc4/rtl/soc4_cpu_dom.sv` | CPU0's core on `dev_nret_rst_n` | soc4 (AP) | `FULLRET_REGS` | `[bfm-timeout]` (cannot occur in AP mode, where no BFM runs) | 15 of 16 errors |
| M2 | `SOC4_MUT_FW_OPEN` | `soc4/rtl/soc4_mbx.sv` | FW_EN resets to 1: source 0 in | soc4bfm, `+bfm_only=B0` | `FW_RESET_DENY` | none | 7 of 7 |
| M3 | `SOC4_MUT_ACC0_NORET` | `soc4/rtl/soc4_acc_dom.sv` | ACC0's retention acts as OFF | soc4 (AP) | `MEMRET_RAM` | `scp: FATAL` | 3 of 4 |
| M4 | `SOC4_MUT_IRQ_SYNC0` | `pmu/rtl/scp_irq.sv` | the synchroniser output tied LOW | soc4bfm, `+bfm_only=B12` | `WAKE_PLIC` | `scp: FATAL` | 2 of 71 |
| M5 | `SOC4_MUT_FW_NOMASK` | `soc4/rtl/soc4_mbx.sv` | the firewall ignores FW_MASK: `a_source` must equal FW_VAL | soc4bfm, `+bfm_only=R1` | `FW_MASK` | `scp: FATAL` | 6 of 6 |
| M6 | `SCP_MUT_PERM_OPEN` | `pmu/fw/rpmi/scp_rpmi.c` (firmware, image `soc4_scp_m6`) | the per-domain permission check skipped | soc4bfm, `+bfm_only=R1` | `PERM` | `scp: FATAL` | 6 of 6 |
| M7 | `SOC4_MUT_WDOG_PPU` | `soc4/rtl/soc4_top.sv` | the watchdog's reset also reaches the four domains, PPUs included | soc4bfm, `+bfm_only=W1` | `WDOG_KEEP` | `scp: FATAL` | 4 of 18 |
| M8 | `SOC4_MUT_WDOG_CAUSE_SUB` | `pmu/rtl/scp_wdog.sv` | CAUSE on the SCP subsystem's reset, so the watchdog's own reset clears it | soc4bfm, `+bfm_only=W1` | `WDOG_CAUSE` | `scp: FATAL` | 1 of 27 |
| M9 | `SOC4_MUT_CKRST_IRQ` | `soc4/rtl/soc4_top.sv` | the bridges' faults never reach the SCP | soc4ckrst (K1) | `CKRST_LOG` | `scp: FATAL` | 5 of 13 |

"Latest" is `[chk:<TAG>]` errors of all testbench errors in
`build/regress_p6/soc4neg.log`. M4 and M8 are also VC Formal mutants
([`src/formal/scp_irq/`](../../formal/scp_irq/README.md),
[`src/formal/scp_wdog/`](../../formal/scp_wdog/README.md)), as are M2 and M5
([`src/formal/soc4_mbx/`](../../formal/soc4_mbx/README.md)).

## Power-aware runs (soc4pa, soc4bfmpa, soc4stresspa)

VCS native low power: `-upf upf/soc4_tb_vcs.upf` (which binds
`upf/soc4_top.upf` at `soc4_tb/u_dut`), `+define+SOC4_PA`, and
`soc4_pa_supply_vcs` as a second top. Under `SOC4_PA` the testbench reads the
supply nets through the UPF package (`UPF::get_supply_value`), which does not
break the probe rule (a supply net is not a register):

- at every PPU-level CHECK, `VDD_LOGIC_n` must be FULL_ON exactly when the
  mode keeps logic (ON, WARM_RST, FUNC_RET, MEM_OFF) and OFF otherwise, and
  `VDD_RET_0` FULL_ON exactly in CPU0's FULL_RET (tag `SUPPLY`);
- in each LOGIC_LOSS rule, `VDD_LOGIC_n` must be OFF;
- a state must be exactly FULL_ON or OFF: a net name the power intent does not
  have reads UNDETERMINED and fails both ways;
- at the end, the checks must have seen a rail both OFF and FULL_ON.

The report prints `power intent APPLIED (SOC4_PA)` and the supply-net count
(latest: 31, 71 and 253 checks, 0 failed). The make target then gates on VCS's
low-power checker (Section 4 of [`../README.md`](../README.md)).

## Running

```
make -C src soc4fw SIM=vcs            # the firmware images (also a dependency of every run)
make -C src soc4 SIM=vcs              # AP mode
make -C src soc4bfm SIM=vcs           # B0, R0, B1-B12, R1, W1
make -C src soc4stress SIM=vcs        # soc4/fw/test/soc4_stress.c, one RESULT per feature
make -C src soc4wdog SIM=vcs          # soc4/fw/test/soc4_wdog.c, two watchdog resets
make -C src soc4ckrst SIM=vcs         # K1
make -C src soc4neg SIM=vcs           # M1-M9
make -C src soc4pa soc4bfmpa soc4stresspa SIM=vcs
```

- VCS only (`soc4simcheck`). Every run rebuilds `soc4_tb`, so a mutant build
  left by `soc4neg` is never reused.
- Logs: `build/vcs/soc4_tb/<run>.log` (`soc4`, `soc4bfm`, `soc4stress`,
  `soc4wdog`, `soc4ckrst`, `soc4neg_m<n>`); power-aware:
  `build/vcs_pa/soc4_tb/<run>.log`. The target prints the progress lines and
  the report.
- Pass: `RESULT: PASS` and no `ASSERT FAILED` (`scp_verdict`); soc4stress also
  needs every feature PASS or DEVIATION.
- Running one step: `+bfm_only=B7` (B1 runs first automatically). Run the
  simv by hand from `build/vcs/soc4_tb` with the plusargs the Makefile's
  `SOC4_BFM` uses.

## Adding a test

- **A BFM step.** Write `task automatic <step>()` beside the others, set
  `bfm_step`, check with `bck("<TAG>", cond, msg)` (counted in the BFM total
  and the testbench total), use `ck_mode(d, m)` for a checkpoint with its
  IP-state rule, and print one `tb| <STEP> [chk:<TAG>] ...` line per claim.
  Add it to the step sequence in the `bfm` initial block (and to the default
  list printed there), and to the Makefile comment of `soc4bfm`.
- **An IP-state rule.** Add a task `r_<name>()` using `tck` and `rule_line`,
  and dispatch it in `rule_run` for its (domain, mode). Read only always-on
  state (the probe rule, header of `soc4_tb.sv`), and compare with `===` /
  `!==`.
- **A firmware test.** Add a program under `src/soc4/fw/test/`, build it in
  `soc4fw`, and run it in scp mode (`+bfm +bfm_only=none`), like `soc4stress`.
- **A mutant.** Add `` `ifdef SOC4_MUT_<X> `` in the RTL with a comment, a build
  and run line in the `soc4neg` target, and a `soc4neg_chk` call naming the
  tag it must trip and the line it must not print; add the row above.

## References

- [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md) Sections 4, 6, 8, 10, 11.
- [`src/soc4/README.md`](../../soc4/README.md), `src/soc4/fw/soc4_plat.h`
  (domain table, inputs, latencies), `src/pmu/fw/hal/sim.h`.
- Arm DEN 0051E Tables 3-1, 3-2, 4-5, 4-7, 4-9, 4-11, 4-12, Section 3.3.2.
- librpmi v1.0.0 (`src/pmu/fw/vendor/librpmi/include/librpmi.h`).
- [`src/upf/README.md`](../../upf/README.md); `upf/soc4_top.upf`,
  `upf/soc4_tb_vcs.upf`.
