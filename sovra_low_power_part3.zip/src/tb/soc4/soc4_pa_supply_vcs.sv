`timescale 1ns/1ps
// The board rails for soc4_tb under VCS native low power.
//
// SOC4_DESIGN.md 8.1 (it began as the retired pmu_tb's rails file, with the
// module renamed). VCS energises a rail
// with the IEEE 1801 UPF package's supply_on(), whose net names are relative
// to the UPF design top -- soc4_tb/u_dut, per src/upf/soc4_tb_vcs.upf -- so
// "VDD" here is soc4_top's supply port.
//
// A second elaboration top, so soc4_tb itself carries nothing
// simulator-specific beyond its SOC4_PA supply-net checks. supply_on()
// returns 1 when it found the net; a 0 would leave the whole design unpowered
// and every check meaningless, so it stops the run instead.
module soc4_pa_supply_vcs;
  import UPF::*;
  initial begin
    bit ok_vdd, ok_vss;
    ok_vdd = supply_on("VDD", 0.90);
    ok_vss = supply_on("VSS", 0.00);
    if (!ok_vdd || !ok_vss) begin
      $display("FATAL: soc4_pa_supply_vcs could not energise the rails (VDD %0d, VSS %0d)",
               ok_vdd, ok_vss);
      $fatal(1);
    end
  end
endmodule
