`timescale 1ns/1ps
// soc4_tb -- the testbench of soc4: the SCP with four PPU domains (two Ibex
// CPUs, two stand-in accelerators), the always-on AP and the TL-UL RPMI
// mailbox with two agents (the AP on port 0, an RPU stand-in on port 1).
//
// References: docs/SOC4_DESIGN.md Sections 10 (this testbench)
// and 11 (the tests); its checks, observation window and summary began as
// those of the 12-domain pmu_tb (retired 2026-10-02); Arm Power Policy Unit
// Architecture Specification v1.1 (ARM DEN 0051E) Tables 3-1, 3-2, 4-5, 4-7,
// 4-9, 4-11 and 4-12.
//
//   ┌─ soc4_tb ──────────────────────────────────────────────────────────────┐
//   │  u_sim (scp_sim_ctrl, "fw") ◄── sim_*     u_apsim ("ap") ◄── ap_ext_*  │
//   │  tl_bfm (TL-UL BFM, +bfm)  ───► tl_bfm_i   (mailbox port 0, the AP)    │
//   │  rpu    (TL-UL BFM, +bfm)  ───► tl_rpu_i   (mailbox port 1, the RPU)   │
//   │  tb_stim (BFM) | SCP TB commands (AP_CMD 'H'/'D') ──► hold_busy, deny  │
//   │                         u_dut (soc4_top)                               │
//   │  per domain, always-on probes only: ppu_monitor, ppu_power_model, the  │
//   │  spec tables at every hop, settling, the observation window, the hop   │
//   │  log; the always-on RAM arrays; the CPU RAM wrappers' request inputs;  │
//   │  tlul_assert bound at each mailbox port (Device) and the AP (Host)     │
//   └────────────────────────────────────────────────────────────────────────┘
//
// THREE MODES, chosen by plusargs (Section 10.7):
//   ap   (default)               soc4: the AP runs +ap_firmware; the run ends
//                                at the AP's HALT. Its CHECKs get the PPU-level
//                                check (10.3) and the IP-state rule (10.4).
//   bfm  (+bfm)                  soc4bfm: the TL-UL BFM below plays the AP,
//                                steps B0-B12 (11.2); +bfm_only=B0,B4 runs a
//                                subset. The run ends when the BFM is done.
//                                B12 also drives the SCP's interrupt and wake
//                                inputs (platform plan H7-H9, F10). R0 (just
//                                after B0) and R1 (after B12) add the second
//                                agent, the RPU, on its own port (platform
//                                plan H11-H13, F6, V3). W1 (after R1) hangs
//                                the SCP and checks the watchdog's reset, the
//                                takeover and the fault log (platform plan
//                                H18, F12). K1 (soc4ckrst; only when named in
//                                +bfm_only) makes the SoC's clkgate slower
//                                than ACC1's table latency: the bridge's
//                                fault, logged and FAULTed (H16, F11, V5).
//   scp  (+bfm +bfm_only=none)   soc4stress, soc4wdog: the SCP image is the
//                                test; it ends at the SCP's HALT. Its CHECKs get the
//                                PPU-level check; it drives hold_busy and the
//                                ACC deny through AP_CMD, echoed on AP_STAT.
//
// THE PROBE RULE (decision 14, Section 10.1). Nothing here reads a register
// inside a switched domain. The reads are the PPU and PCSM (u_*/u_dom/u_pd/...,
// never u_pd/u_clkctrl, which is in PD_DEV), the always-on RAM arrays
// (u_cpuN/u_ram/u_sram.sram, u_accK/u_ip/g_bank[b].u_bank.mem), the isolated
// outputs on the always-on side (core_sleep, the CPU RAM wrapper's request
// inputs, ppu_device_ip's busy/done after an ON), soc4_ctrl/soc4_mbx, and the
// SCP's interrupt block, watchdog and RAM (u_scp/u_irq, u_wdog, u_ram;
// PD_TOP).
//
// THE CLOCK/RESET BRIDGES (platform plan H16, F11, V5): soc_ckrst_model
// plays the SoC's clkgate / tilereset for each domain, answering in
// CKRST_LAT[d] cycles (soc4_plat.h .ckrst_lat). Every run checks that every
// request equals its PPU control in every cycle; the runs of the product
// image also that each PPU's DCDR fields are the table's (pd_dev_delays_of)
// and that no bridge flagged a fault except where a step makes one (K1).
//
// THE WATCHDOG (platform plan H18): every run counts the watchdog's resets and
// must see exactly +wdog_resets=N of them (default 0; soc4wdog 2), plus one
// if W1 runs. Each one is checked for its length, its scope (the SCP
// subsystem only) and the CAUSE it leaves; a run with the product image ends,
// once that has booted, with the watchdog armed and locked.
// Every compare against a value that can be X is === or !==, so an X never
// passes a check by accident.
//
// THE VERDICT (10.8): PASS only if the run ended the way its mode ends (AP
// HALT 0 / BFM done / SCP HALT 0), every check here held, every monitor is
// clean, and no IP-state rule is still waiting. scp_verdict also fails on any
// [ASSERT FAILED] (tlul_assert, Ibex, prim).

`ifndef SOC4_PCSM_RET_SETTLE
  `define SOC4_PCSM_RET_SETTLE 0
`endif
`ifndef SOC4_PCSM_LOGIC_SETTLE
  `define SOC4_PCSM_LOGIC_SETTLE 0
`endif

module soc4_tb;
  import ppu_pkg::*;

  localparam int unsigned NUM_PD        = 4;
  localparam int unsigned SETTLE_CYCLES = 20;          // PD_SWITCH_SETTLE (mod/pd.c)
  localparam time         TCLK          = 10ns;
  localparam int unsigned DEV_CNT_W     = 12;          // sim.h SIM_WORK_LEN width
  localparam logic [7:0]  AP_SOURCE     = 8'h10;       // soc4_regs.h SOC4_AP_SOURCE
  localparam int unsigned RETRY_CAP     = 3;           // policy_cfg_default
  localparam int unsigned TICKS_MS      = 100_000;     // S4_TICKS_PER_MS: 1 ms, one tick a cycle
  localparam int unsigned RULE_WAIT     = 20_000;      // IP-state rules that wait (10.4)

  // The CPU RAM layout (Section 4.7, soc4_regs.h), in words
  localparam int unsigned W_MARKER = 32'hC00 / 4, W_BOOTS = 32'hC04 / 4, W_WAKES = 32'hC08 / 4,
                          W_TRAP   = 32'hC0C / 4, W_DUMP  = 32'hC10 / 4, W_COUNT = 32'hC80 / 4;
  localparam int unsigned W_IMAGE  = 32'hC00 / 4;      // 0x000-0xBFF: written by the load port only

  // ===========================================================================
  // Clocks and resets
  // ===========================================================================
  logic clk  = 1'b0;
  logic mclk = 1'b0;
  always #5    clk  = ~clk;
  always #1.25 mclk = ~mclk;

  logic        rst_n     = 1'b0;
  logic        mrst_n    = 1'b0;
  logic        scp_rst_n = 1'b0;
  logic        bfm_sel   = 1'b0;          // static strap: set at time 0, never changed
  int unsigned scp_hold  = 0;
  string       bfm_only  = "";
  bit          quiet     = 1'b0;
  string       mode      = "ap";

  initial begin
    bfm_sel = $test$plusargs("bfm");
    void'($value$plusargs("scp_hold=%d", scp_hold));
    void'($value$plusargs("bfm_only=%s", bfm_only));
    quiet = $test$plusargs("quiet");
    mode  = !bfm_sel ? "ap" : (bfm_only == "none") ? "scp" : "bfm";
    if (scp_hold == 0) scp_rst_n = 1'b1;       // released together with rst_n
    #1 mrst_n = 1'b1;
    repeat (8) @(negedge clk);
    rst_n = 1'b1;
    if (scp_hold != 0) begin
      repeat (scp_hold) @(negedge clk);
      scp_rst_n = 1'b1;
    end
  end

  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ===========================================================================
  // DUT, the two simulation controls and the stimulus
  // ===========================================================================
  logic        s_req, s_we, s_rv, s_err;  logic [3:0] s_be;  logic [31:0] s_addr, s_wd, s_rd;
  logic        a_req, a_we, a_rv, a_err;  logic [3:0] a_be;  logic [31:0] a_addr, a_wd, a_rd;

  logic        s_halt, a_halt, s_chk, a_chk;
  logic [31:0] s_code, a_code;
  logic [7:0]  s_dom, a_dom;
  logic [3:0]  s_md, a_md;
  logic [NUM_PD-1:0]      s_wake, s_deny, s_light, s_start, a_wake, a_deny, a_light, a_start;
  logic [15:0]            s_wl, a_wl;
  logic [NUM_PD-1:0][1:0] s_ipc, a_ipc;
  logic [7:0]             s_seed, a_seed;
  logic [31:0]            s_apcmd;
  logic [7:0]             s_obs_dom, a_obs_dom;
  logic [4:0]             s_obs_idx, a_obs_idx;
  logic [31:0]            s_obs_val, a_obs_val;

  // The testbench's own stimulus (tb_stim, 10.1): driven by the BFM tasks.
  logic [1:0]           t_start = '0, t_light = '0, t_wake = '0, t_deny = '0;
  logic [DEV_CNT_W-1:0] t_wl    = '0;
  logic [1:0][1:0]      t_ipc   = '0;
  logic [7:0]           t_seed  = '0;
  logic [3:0]           t_hold  = '0;
  // The SCP's interrupt and wake inputs, by input index of the block (B12):
  // [5] PLIC [7:6] PLIC per-hart pending [8] RTC [9] GPIO [10] BBRX [11] DBG
  // [13:12] access-gate wake. Inputs 0-4 are the PPUs and the doorbell.
  logic [13:5]          t_irq   = '0;
  // ...and the SCP's testbench commands on AP_CMD (soc4stress): 'H' hold_busy
  // mask, 'D' ACC deny mask; each echoed on AP_STAT once applied.
  logic [3:0]           c_hold  = '0;
  logic [1:0]           c_deny  = '0;
  logic [31:0]          cmd_echo = '0;
  bit                   cmd_seen = 1'b0;
  logic [31:0]          bfm_stat = '0;
  logic [31:0]          ap_stat;

  always @(posedge clk)
    if (rst_n) begin
      if (s_apcmd[31:24] == 8'h48) c_hold <= s_apcmd[3:0];
      if (s_apcmd[31:24] == 8'h44) c_deny <= s_apcmd[1:0];
      if (s_apcmd[31:24] == 8'h48 || s_apcmd[31:24] == 8'h44) begin
        cmd_echo <= s_apcmd;
        cmd_seen <= 1'b1;
      end
    end
  assign ap_stat = cmd_seen ? cmd_echo : bfm_stat;

  // Three stimulus sources, ORed per domain (10.1); bits 0-1 of the sim
  // controls (the CPU domains) are unused.
  logic [1:0]           acc_start, acc_light, acc_wake, acc_deny;
  logic [DEV_CNT_W-1:0] acc_wl;
  logic [1:0][1:0]      acc_ipc;
  logic [7:0]           acc_seed;
  logic [3:0]           hold_busy;
  assign acc_start  = s_start[3:2] | a_start[3:2] | t_start;
  assign acc_light  = s_light[3:2] | a_light[3:2] | t_light;
  assign acc_wake   = s_wake[3:2]  | a_wake[3:2]  | t_wake;
  assign acc_deny   = s_deny[3:2]  | a_deny[3:2]  | t_deny | c_deny;
  assign acc_wl     = s_wl[DEV_CNT_W-1:0] | a_wl[DEV_CNT_W-1:0] | t_wl;
  assign acc_ipc[0] = s_ipc[2] | a_ipc[2] | t_ipc[0];
  assign acc_ipc[1] = s_ipc[3] | a_ipc[3] | t_ipc[1];
  assign acc_seed   = s_seed | a_seed | t_seed;
  assign hold_busy  = t_hold | c_hold;

  tlul_pkg::tl_h2d_t bfm_h = tlul_pkg::TL_H2D_DEFAULT;   // mailbox port 0 (the AP's)
  tlul_pkg::tl_d2h_t bfm_d;
  tlul_pkg::tl_h2d_t rpu_h = tlul_pkg::TL_H2D_DEFAULT;   // mailbox port 1 (the RPU's)
  tlul_pkg::tl_d2h_t rpu_d;
  logic              scp_sleep, ap_sleep;

  // The SoC's clkgate / tilereset (platform plan H16): one model per domain
  localparam int unsigned CKRST_LAT [NUM_PD] = '{2, 2, 2, 6};   // soc4_plat.h .ckrst_lat
  logic [NUM_PD-1:0]      tile_clk_req, tile_clk_ack;
  logic [NUM_PD-1:0][1:0] tile_rst_req_n, tile_rst_ack_n;
  int unsigned            ck_lat_clk [NUM_PD] = CKRST_LAT;
  int unsigned            ck_lat_rst [NUM_PD] = CKRST_LAT;

  soc4_top #(
    .AP_SOURCE        (AP_SOURCE),
    .PCSM_RET_SETTLE  (`SOC4_PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE(`SOC4_PCSM_LOGIC_SETTLE),
    .DEV_CNT_W        (DEV_CNT_W)
  ) u_dut (
    .clk_i          (clk),
    .rst_ni         (rst_n),
    .scp_rst_ni     (scp_rst_n),
    .scp_fetch_en_i (1'b1),
    .bfm_sel_i      (bfm_sel),
    .sim_req_o      (s_req),   .sim_we_o   (s_we),   .sim_be_o  (s_be),
    .sim_addr_o     (s_addr),  .sim_wdata_o(s_wd),
    .sim_rvalid_i   (s_rv),    .sim_rdata_i(s_rd),   .sim_err_i (s_err),
    .ap_ext_req_o   (a_req),   .ap_ext_we_o(a_we),   .ap_ext_be_o(a_be),
    .ap_ext_addr_o  (a_addr),  .ap_ext_wdata_o(a_wd),
    .ap_ext_rvalid_i(a_rv),    .ap_ext_rdata_i(a_rd), .ap_ext_err_i(a_err),
    .tl_bfm_i       (bfm_h),
    .tl_bfm_o       (bfm_d),
    .tl_rpu_i       (rpu_h),
    .tl_rpu_o       (rpu_d),
    .acc_start_i    (acc_start),
    .acc_work_len_i (acc_wl),
    .acc_light_i    (acc_light),
    .acc_wake_i     (acc_wake),
    .acc_deny_i     (acc_deny),
    .acc_ip_cmd_i   (acc_ipc),
    .acc_ip_seed_i  (acc_seed),
    .hold_busy_i    (hold_busy),
    .plic_irq_i     (t_irq[5]),
    .plic_pend_i    (t_irq[7:6]),
    .rtc_wake_i     (t_irq[8]),
    .gpio_wake_i    (t_irq[9]),
    .bbrx_det_i     (t_irq[10]),
    .dbg_pwrreq_i   (t_irq[11]),
    .acg_wake_i     (t_irq[13:12]),
    .tile_clk_req_o (tile_clk_req),
    .tile_clk_ack_i (tile_clk_ack),
    .tile_rst_req_no(tile_rst_req_n),
    .tile_rst_ack_ni(tile_rst_ack_n),
    .scp_sleep_o    (scp_sleep),
    .ap_sleep_o     (ap_sleep)
  );

  for (genvar d = 0; d < NUM_PD; d++) begin : g_soc_ckrst
    soc_ckrst_model #(.NUM_RST(2)) u_soc (
      .clk(clk), .rst_n(rst_n), .clk_req(tile_clk_req[d]), .clk_ack(tile_clk_ack[d]),
      .rst_req_n(tile_rst_req_n[d]), .rst_ack_n(tile_rst_ack_n[d]),
      .lat_clk(ck_lat_clk[d]), .lat_rst(ck_lat_rst[d]),
      .hold_clk(1'b0), .hold_rst(1'b0), .flip_clk(1'b0));
  end

  int unsigned checks = 0, errors = 0;
  int unsigned tb_bad;                  // errors + every violation counter (TB_ERRORS)

  scp_sim_ctrl #(.NUM_PD(NUM_PD), .TAG("fw")) u_sim (
    .clk_i(clk), .rst_ni(rst_n),
    .req_i(s_req), .we_i(s_we), .be_i(s_be), .addr_i(s_addr), .wdata_i(s_wd),
    .rvalid_o(s_rv), .rdata_o(s_rd), .err_o(s_err),
    .halt_o(s_halt), .halt_code_o(s_code),
    .check_o(s_chk), .check_dom_o(s_dom), .check_mode_o(s_md),
    .tb_checks_i(32'(checks)), .tb_errors_i(32'(tb_bad)),
    .wake_o(s_wake), .deny_o(s_deny), .light_o(s_light), .start_o(s_start),
    .work_len_o(s_wl), .ip_cmd_o(s_ipc), .ip_seed_o(s_seed),
    .ap_cmd_o(s_apcmd), .ap_stat_i(ap_stat),
    .obs_dom_o(s_obs_dom), .obs_idx_o(s_obs_idx), .obs_val_i(s_obs_val)
  );

  scp_sim_ctrl #(.NUM_PD(NUM_PD), .TAG("ap")) u_apsim (
    .clk_i(clk), .rst_ni(rst_n),
    .req_i(a_req), .we_i(a_we), .be_i(a_be), .addr_i(a_addr), .wdata_i(a_wd),
    .rvalid_o(a_rv), .rdata_o(a_rd), .err_o(a_err),
    .halt_o(a_halt), .halt_code_o(a_code),
    .check_o(a_chk), .check_dom_o(a_dom), .check_mode_o(a_md),
    .tb_checks_i(32'(checks)), .tb_errors_i(32'(tb_bad)),
    .wake_o(a_wake), .deny_o(a_deny), .light_o(a_light), .start_o(a_start),
    .work_len_o(a_wl), .ip_cmd_o(a_ipc), .ip_seed_o(a_seed),
    .ap_cmd_o(), .ap_stat_i(32'd0),
    .obs_dom_o(a_obs_dom), .obs_idx_o(a_obs_idx), .obs_val_i(a_obs_val)
  );

  // OpenTitan's TL-UL protocol checker, bound as its mbx_bind.sv does (7.1):
  // at each mailbox port's socket side (after the boundary adapter, so a_user
  // is defined), and at the AP adapter's output.
  bind soc4_tl_bound tlul_assert #(.EndpointType("Device")) u_tlul_assert_dev (
    .clk_i(clk_i), .rst_ni(rst_ni), .h2d(tl_d_o), .d2h(tl_d_i));
  bind soc4_ap  tlul_assert #(.EndpointType("Host"))   u_tlul_assert_host (
    .clk_i(clk_i), .rst_ni(rst_ni), .h2d(tl_o), .d2h(tl_i));

  // ===========================================================================
  // Names and the spec's tables (transcribed from DEN 0051E, and deliberately
  // not taken from ppu_pkg)
  // ===========================================================================
  function automatic string mode_name(input logic [3:0] m);
    case (m)
      PM_OFF:      return "OFF";
      PM_MEM_RET:  return "MEM_RET";
      PM_FULL_RET: return "FULL_RET";
      PM_MEM_OFF:  return "MEM_OFF";
      PM_FUNC_RET: return "FUNC_RET";
      PM_ON:       return "ON";
      PM_WARM_RST: return "WARM_RST";
      default:     return $sformatf("?%0h", m);
    endcase
  endfunction

  function automatic string pd_name(input int unsigned i);
    case (i)
      0:       return "CPU0";
      1:       return "CPU1";
      2:       return "ACC0";
      3:       return "ACC1";
      default: return $sformatf("?%0d", i);
    endcase
  endfunction

  function automatic bit keeps_logic(input logic [3:0] m);
    return (m == PM_ON) || (m == PM_WARM_RST) || (m == PM_FUNC_RET) || (m == PM_MEM_OFF);
  endfunction
  function automatic bit ram_full(input logic [3:0] m);
    return (m == PM_ON) || (m == PM_WARM_RST);
  endfunction
  function automatic bit ram_kept(input logic [3:0] m);
    return (m == PM_FUNC_RET) || (m == PM_FULL_RET) || (m == PM_MEM_RET);
  endfunction
  function automatic logic [3:0] pcsm_of(input logic [3:0] m);
    return (m == PM_WARM_RST) ? PM_ON : m;
  endfunction
  // Tables 4-7, 4-9, 4-11: {PORESETn, WARMRESETn, RETRESETn, CLKEN, ISOLATEn}
  function automatic logic [4:0] spec_devctl(input logic [3:0] m);
    case (m)
      PM_WARM_RST: return 5'b1_0_0_1_1;
      PM_ON,
      PM_FUNC_RET,
      PM_MEM_OFF:  return 5'b1_1_1_1_1;
      PM_FULL_RET: return 5'b1_0_1_0_0;
      PM_MEM_RET,
      PM_OFF:      return 5'b0_0_0_0_0;
      default:     return 5'bxxxxx;
    endcase
  endfunction
  // Table 3-2
  function automatic logic [15:0] spec_hwstat(input logic [3:0] m);
    return 16'(1) << m;
  endfunction
  // Section 3.3.2
  function automatic bit spec_hop_ok(input logic [3:0] from, input logic [3:0] to);
    return (from == PM_ON) || (to == PM_ON) || (from == PM_OFF && to == PM_MEM_RET);
  endfunction

  // ppu_device_ip's RAM pattern (ppu_ip_core.sv:104-107), a pure function of
  // (seed, bank, addr)
  function automatic logic [31:0] ip_pattern(input logic [7:0] seed, input int unsigned b,
                                             input int unsigned a);
    return ({seed, 5'd0, 3'(b), 8'd0, 4'd0, 4'(a)}) ^ 32'hA5A5_5A5A;
  endfunction

  // CPU0's signature registers (cpu/cpu.S, soc4_regs.h SOC4_CPU_SIG)
  function automatic logic [31:0] cpu_sig(input int unsigned i);
    return 32'h5100_0000 | (32'(i) << 8);
  endfunction

  // ===========================================================================
  // Probes, per domain: PD_AON only (see the header)
  // ===========================================================================
  logic [3:0]  pb_status   [NUM_PD];
  logic [3:0]  pb_pcsm     [NUM_PD];
  logic [15:0] pb_hwstat   [NUM_PD];
  logic        pb_lon      [NUM_PD];
  logic        pb_lret     [NUM_PD];
  logic        pb_ron      [NUM_PD];
  logic        pb_rret     [NUM_PD];
  logic        pb_irq      [NUM_PD];
  logic        pb_clken    [NUM_PD];
  logic        pb_isoln    [NUM_PD];
  logic        pb_por      [NUM_PD];
  logic        pb_warm     [NUM_PD];
  logic        pb_ret      [NUM_PD];
  logic        pb_retn     [NUM_PD];
  logic        pb_nret_rst [NUM_PD];      // dev_nret_rst_n
  logic        pb_ret_rst  [NUM_PD];      // dev_ret_rst_n
  logic [15:0] pb_pstate   [NUM_PD];
  logic        pb_preq     [NUM_PD];
  logic        pb_pacc     [NUM_PD];
  logic        pb_qreqn    [NUM_PD];
  logic        pb_qaccn    [NUM_PD];
  logic        pb_qdeny    [NUM_PD];
  logic        pb_qact     [NUM_PD];
  logic        pb_pclken   [NUM_PD];
  logic        pb_polwr    [NUM_PD];
  logic [5:0]  pb_ev       [NUM_PD];
  logic        pb_unspt    [NUM_PD];
  logic        pb_edge     [NUM_PD];
  logic        pb_devreqen [NUM_PD];
  logic [7:0]  pb_d_ic     [NUM_PD];      // ISO_CLKEN_DLY
  logic [7:0]  pb_d_cr     [NUM_PD];      // CLKEN_RST_DLY
  logic [7:0]  pb_d_rh     [NUM_PD];      // RST_HWSTAT_DLY
  logic [7:0]  pb_d_ci     [NUM_PD];      // CLKEN_ISO_DLY
  logic [7:0]  pb_d_ir     [NUM_PD];      // ISO_RST_DLY
  logic [7:0]  pb_rr_fun   [NUM_PD];
  logic [7:0]  pb_rr_ful   [NUM_PD];
  logic [7:0]  pb_rr_mem   [NUM_PD];
  logic [7:0]  pb_ram_sleep[NUM_PD];
  logic [7:0]  pb_ram_sd   [NUM_PD];

`define SOC4_PROBE(I, P) \
  assign pb_status[I]    = P.u_dom.u_pd.u_ppu.u_seq.pwr_status; \
  assign pb_pcsm[I]      = P.u_dom.u_pd.pcsm_mode; \
  assign pb_hwstat[I]    = P.u_dom.u_pd.ppuhwstat; \
  assign pb_lon[I]       = P.u_dom.u_pd.logic_on; \
  assign pb_lret[I]      = P.u_dom.u_pd.logic_ret; \
  assign pb_ron[I]       = P.u_dom.u_pd.ram_on; \
  assign pb_rret[I]      = P.u_dom.u_pd.ram_ret; \
  assign pb_irq[I]       = u_dut.ppu_irq[I]; \
  assign pb_clken[I]     = P.u_dom.u_pd.dev_clken; \
  assign pb_isoln[I]     = P.u_dom.u_pd.dev_isolaten; \
  assign pb_por[I]       = P.u_dom.u_pd.dev_poresetn; \
  assign pb_warm[I]      = P.u_dom.u_pd.dev_warmresetn; \
  assign pb_ret[I]       = P.u_dom.u_pd.dev_retresetn; \
  assign pb_retn[I]      = P.u_dom.u_pd.ret_n; \
  assign pb_nret_rst[I]  = P.u_dom.u_pd.dev_nret_rst_n; \
  assign pb_ret_rst[I]   = P.u_dom.u_pd.dev_ret_rst_n; \
  assign pb_pstate[I]    = P.u_dom.u_pd.pcsm_pstate; \
  assign pb_preq[I]      = P.u_dom.u_pd.pcsm_preq; \
  assign pb_pacc[I]      = P.u_dom.u_pd.pcsm_paccept; \
  assign pb_qreqn[I]     = P.u_dom.u_pd.dev_qreqn; \
  assign pb_qaccn[I]     = P.u_dom.u_pd.dev_qacceptn; \
  assign pb_qdeny[I]     = P.u_dom.u_pd.dev_qdeny; \
  assign pb_qact[I]      = P.u_dom.u_pd.dev_qactive; \
  assign pb_pclken[I]    = P.u_dom.ppu_clken; \
  assign pb_polwr[I]     = P.u_dom.u_pd.u_ppu.policy_wr; \
  assign pb_ev[I]        = {P.u_dom.u_pd.u_ppu.ev_locked,     P.u_dom.u_pd.u_ppu.ev_dyn_deny, \
                            P.u_dom.u_pd.u_ppu.ev_dyn_accept, P.u_dom.u_pd.u_ppu.ev_sta_deny, \
                            P.u_dom.u_pd.u_ppu.ev_sta_accept, P.u_dom.u_pd.u_ppu.ev_sta_policy_trn}; \
  assign pb_unspt[I]     = P.u_dom.u_pd.u_ppu.ev_unspt_policy; \
  assign pb_edge[I]      = P.u_dom.u_pd.u_ppu.u_irq.edge_event; \
  assign pb_devreqen[I]  = P.u_dom.u_pd.u_ppu.devreqen; \
  assign pb_d_ic[I]      = P.u_dom.u_pd.u_ppu.iso_clken_dly; \
  assign pb_d_cr[I]      = P.u_dom.u_pd.u_ppu.clken_rst_dly; \
  assign pb_d_rh[I]      = P.u_dom.u_pd.u_ppu.rst_hwstat_dly; \
  assign pb_d_ci[I]      = P.u_dom.u_pd.u_ppu.clken_iso_dly; \
  assign pb_d_ir[I]      = P.u_dom.u_pd.u_ppu.iso_rst_dly; \
  assign pb_rr_fun[I]    = P.u_dom.u_pd.u_ppu.funrr; \
  assign pb_rr_ful[I]    = P.u_dom.u_pd.u_ppu.fulrr; \
  assign pb_rr_mem[I]    = P.u_dom.u_pd.u_ppu.memrr; \
  assign pb_ram_sleep[I] = P.u_dom.ram_sleep; \
  assign pb_ram_sd[I]    = P.u_dom.ram_sd;

  `SOC4_PROBE(0, u_dut.u_cpu0)
  `SOC4_PROBE(1, u_dut.u_cpu1)
  `SOC4_PROBE(2, u_dut.u_acc0)
  `SOC4_PROBE(3, u_dut.u_acc1)
`undef SOC4_PROBE

  function automatic logic [4:0] devctl(input int unsigned d);
    return {pb_por[d], pb_warm[d], pb_ret[d], pb_clken[d], pb_isoln[d]};
  endfunction

  // Table 4-12: PCSMPSTATE[15:8] the RAM configuration of a retention mode
  // being entered, else 0; [7:4] 0; [3:0] the PCSM mode.
  function automatic logic [15:0] spec_pstate(input int unsigned d, input logic [3:0] m);
    logic [7:0] rr;
    rr = (m == PM_FUNC_RET) ? pb_rr_fun[d] :
         (m == PM_FULL_RET) ? pb_rr_ful[d] :
         (m == PM_MEM_RET)  ? pb_rr_mem[d] : 8'h00;
    return {rr, 4'h0, pcsm_of(m)};
  endfunction

  // The always-on RAM arrays. A generate block is indexed by a constant, so
  // the accelerator banks are spelled out.
  function automatic logic [31:0] cram(input int unsigned n, input int unsigned w);
    return (n == 0) ? u_dut.u_cpu0.u_ram.u_sram.sram[w] : u_dut.u_cpu1.u_ram.u_sram.sram[w];
  endfunction

  function automatic logic [31:0] aram(input int unsigned k, input int unsigned b,
                                       input int unsigned a);
    if (k == 0)
      case (b)
        0: return u_dut.u_acc0.u_ip.g_bank[0].u_bank.mem[a];
        1: return u_dut.u_acc0.u_ip.g_bank[1].u_bank.mem[a];
        2: return u_dut.u_acc0.u_ip.g_bank[2].u_bank.mem[a];
        3: return u_dut.u_acc0.u_ip.g_bank[3].u_bank.mem[a];
        4: return u_dut.u_acc0.u_ip.g_bank[4].u_bank.mem[a];
        5: return u_dut.u_acc0.u_ip.g_bank[5].u_bank.mem[a];
        6: return u_dut.u_acc0.u_ip.g_bank[6].u_bank.mem[a];
        default: return u_dut.u_acc0.u_ip.g_bank[7].u_bank.mem[a];
      endcase
    else
      case (b)
        0: return u_dut.u_acc1.u_ip.g_bank[0].u_bank.mem[a];
        1: return u_dut.u_acc1.u_ip.g_bank[1].u_bank.mem[a];
        2: return u_dut.u_acc1.u_ip.g_bank[2].u_bank.mem[a];
        3: return u_dut.u_acc1.u_ip.g_bank[3].u_bank.mem[a];
        4: return u_dut.u_acc1.u_ip.g_bank[4].u_bank.mem[a];
        5: return u_dut.u_acc1.u_ip.g_bank[5].u_bank.mem[a];
        6: return u_dut.u_acc1.u_ip.g_bank[6].u_bank.mem[a];
        default: return u_dut.u_acc1.u_ip.g_bank[7].u_bank.mem[a];
      endcase
  endfunction

  // The isolated outputs and always-on glue nets of the CPU domains
  logic [1:0]       cpu_core_rst, cpu_ireq, cpu_sleep, ld_req, ld_we, ld_open;
  logic [1:0][31:0] cpu_iaddr, ld_addr, ld_wdata, cpu_boot;
  logic [1:0][3:0]  ld_be;
  logic [1:0]       cpu_fetch;
  assign cpu_core_rst = {u_dut.u_cpu1.core_rst_n,    u_dut.u_cpu0.core_rst_n};
  assign cpu_ireq     = {u_dut.u_cpu1.u_ram.i_req_i, u_dut.u_cpu0.u_ram.i_req_i};
  assign cpu_iaddr    = {u_dut.u_cpu1.u_ram.i_addr_i, u_dut.u_cpu0.u_ram.i_addr_i};
  assign cpu_sleep    = {u_dut.u_cpu1.core_sleep_o,  u_dut.u_cpu0.core_sleep_o};
  assign ld_req       = {u_dut.u_cpu1.ld_req_i,      u_dut.u_cpu0.ld_req_i};
  assign ld_we        = {u_dut.u_cpu1.ld_we_i,       u_dut.u_cpu0.ld_we_i};
  assign ld_be        = {u_dut.u_cpu1.ld_be_i,       u_dut.u_cpu0.ld_be_i};
  assign ld_addr      = {u_dut.u_cpu1.ld_addr_i,     u_dut.u_cpu0.ld_addr_i};
  assign ld_wdata     = {u_dut.u_cpu1.ld_wdata_i,    u_dut.u_cpu0.ld_wdata_i};
  assign ld_open      = {u_dut.u_cpu1.ld_open_o,     u_dut.u_cpu0.ld_open_o};
  assign cpu_boot     = u_dut.cpu_boot;
  assign cpu_fetch    = u_dut.cpu_fetch_en;

  // ===========================================================================
  // Checks
  // ===========================================================================
  task automatic ck(input bit cond, input string msg);
    checks++;
    if (!cond) begin
      errors++;
      $display("[%0t] tb| ERROR: %s", $time, msg);
    end
  endtask

  // A check with a tag (10.4): soc4neg greps the tags.
  task automatic tck(input string tag, input bit cond, input string msg);
    checks++;
    if (!cond) begin
      errors++;
      $display("[%0t] tb| ERROR: [chk:%s] %s", $time, tag, msg);
    end
  endtask

  // ===========================================================================
  // Per-domain observers, the observation window and the spec rules at every
  // committed hop
  // ===========================================================================
  localparam int OB_QREQ_FALLS = 0,  OB_PREQ_RISES = 1,  OB_HOPS      = 2,
                 OB_LIVE       = 3,  OB_EV_TRN     = 4,  OB_EV_SACC   = 5,
                 OB_EV_SDENY   = 6,  OB_EV_DACC    = 7,  OB_EV_DDENY  = 8,
                 OB_EV_LOCKED  = 9,  OB_UP_LAST    = 10, OB_DN_LAST   = 11,
                 OB_LAT_WR     = 12, OB_LAT_ACT    = 13, OB_DC_EDGES  = 14,
                 OB_CLK_GATES  = 15, OB_EV_UNSPT   = 16, OB_PCSM_REQ  = 17,
                 OB_UP_MIN     = 18, OB_DN_MIN     = 19, OB_SPACINGS  = 20,
                 OB_HWSTAT     = 21, OB_QREQ_RISES = 22, OB_RAM       = 23,
                 OB_EV_EDGE    = 24, OB_ACT_EDGES  = 25, OB_ERRS      = 26,
                 OB_N          = 32;

  int unsigned ob       [NUM_PD][OB_N];
  logic [31:0] ob_live  [NUM_PD];
  int unsigned n_trans  [NUM_PD];
  int unsigned n_axi_wr [NUM_PD];
  int unsigned n_axi_rd [NUM_PD];
  int unsigned n_irq    [NUM_PD];
  int unsigned n_qdeny  [NUM_PD];          // DEVQDENY rises
  int unsigned n_qacc   [NUM_PD];          // DEVQACCEPTn falls (accepts)
  int unsigned n_polwr  [NUM_PD];          // PPU_PWPR writes
  int unsigned n_forced [NUM_PD];          // hops from ON down with no accept since the last hop
  int unsigned mon_viol [NUM_PD];
  int unsigned pm_viol  [NUM_PD];
  int unsigned n_rail_ups [NUM_PD];
  int unsigned settle_min  = 32'hFFFF_FFFF;
  int unsigned settle_viol = 0;
  bit          ll_ok    [NUM_PD];          // logic-loss evidence held since the down-hop
  logic [3:0]  hop_log  [NUM_PD][$];       // every committed mode, in order

  initial
    for (int d = 0; d < NUM_PD; d++) begin
      for (int k = 0; k < OB_N; k++)
        ob[d][k] = (k == OB_UP_MIN || k == OB_DN_MIN || k == OB_LAT_WR || k == OB_LAT_ACT)
                 ? 32'hFFFF_FFFF : 32'h0;
      n_trans[d] = 0; n_axi_wr[d] = 0; n_axi_rd[d] = 0; n_irq[d] = 0; n_qdeny[d] = 0;
      n_qacc[d] = 0; n_polwr[d] = 0; n_forced[d] = 0; n_rail_ups[d] = 0; ll_ok[d] = 1'b1;
    end

  task automatic ck_dom(input int unsigned d, input bit cond, input string msg);
    checks++;
    if (!cond) begin
      errors++;
      ob[d][OB_ERRS]++;
      $display("[%0t] tb| ERROR: %s", $time, msg);
    end
  endtask

  function automatic string sp_name(input int unsigned k);
    case (k)
      0:       return "isolation release -> clock enable (ISO_CLKEN_DLY)";
      1:       return "clock enable -> reset release (CLKEN_RST_DLY)";
      2:       return "reset release -> PPUHWSTAT (RST_HWSTAT_DLY)";
      3:       return "clock disable -> isolation (CLKEN_ISO_DLY)";
      default: return "isolation -> reset (ISO_RST_DLY)";
    endcase
  endfunction

  task automatic spacing_chk(input int unsigned d, input int unsigned k,
                             input longint unsigned gap, input logic [7:0] dly);
    int unsigned g8, wi, mi, sh;
    g8 = (gap > 255) ? 255 : int'(gap);
    wi = (k < 3) ? OB_UP_LAST : OB_DN_LAST;
    mi = (k < 3) ? OB_UP_MIN  : OB_DN_MIN;
    sh = 8 * ((k < 3) ? k : k - 3);
    ob[d][wi] = (ob[d][wi] & ~(32'hFF << sh)) | (g8 << sh);
    if (((ob[d][mi] >> sh) & 32'hFF) > g8)
      ob[d][mi] = (ob[d][mi] & ~(32'hFF << sh)) | (g8 << sh);
    ob[d][OB_SPACINGS]++;
    ck_dom(d, gap >= longint'(dly) + 1,
           $sformatf("%s: %s took %0d cycles, Table 4-5 requires at least %0d",
                     pd_name(d), sp_name(k), gap, int'(dly) + 1));
  endtask

  for (genvar i = 0; i < NUM_PD; i++) begin : g_obs
    // ---- The PPU's architectural rules, continuously ----
    ppu_monitor u_mon (
      .clk           (mclk),
      .rst_n         (mrst_n),
      .ppu_rst_n     (rst_n),
      .ppuhwstat     (pb_hwstat[i]),
      .dev_clken     (pb_clken[i]),
      .dev_isolaten  (pb_isoln[i]),
      .dev_poresetn  (pb_por[i]),
      .dev_warmresetn(pb_warm[i]),
      .dev_retresetn (pb_ret[i]),
      .pcsm_pstate   (pb_pstate[i]),
      .pcsm_preq     (pb_preq[i]),
      .dev_qreqn     (pb_qreqn[i]),
      .dev_qacceptn  (pb_qaccn[i]),
      .dev_qdeny     (pb_qdeny[i]),
      .violations    (mon_viol[i])
    );

    // ---- The power-ordering rules PU1-PU10, continuously ----
    ppu_power_model u_pm (
      .clk           (clk),
      .rst_n         (rst_n),
      .dev_clken     (pb_clken[i]),
      .dev_isolaten  (pb_isoln[i]),
      .dev_poresetn  (pb_por[i]),
      .dev_warmresetn(pb_warm[i]),
      .dev_retresetn (pb_ret[i]),
      .logic_on      (pb_lon[i]),
      .logic_ret     (pb_lret[i]),
      .ram_on        (pb_ron[i]),
      .ram_ret       (pb_rret[i]),
      .ret_n         (pb_retn[i]),
      .wl_rst_n      (pb_nret_rst[i]),
      .corrupt       (),
      .iso_clamp     (),
      .ret_valid     (),
      .do_save       (),
      .do_restore    (),
      .violations    (pm_viol[i])
    );

    // ---- Traffic per PPU, and its interrupt line ----
    logic irq_d = 1'b0;
    always @(posedge clk) begin
      if (rst_n) begin
        if (u_dut.bvalid[i] && u_dut.bready[i]) n_axi_wr[i]++;
        if (u_dut.rvalid[i] && u_dut.rready[i]) n_axi_rd[i]++;
        if (pb_irq[i] && !irq_d) n_irq[i]++;
      end
      irq_d <= pb_irq[i];
    end

    // ---- Settling: no reset release before the rail has had its budget ----
    time t_rail  = 0;
    bit  rail_up = 1'b0;
    always @(posedge pb_lon[i]) begin
      t_rail  = $time;
      rail_up = 1'b1;
    end
    always @(posedge pb_warm[i])
      if (rst_n && rail_up) begin
        automatic int unsigned gap = int'(($time - t_rail) / TCLK);
        rail_up = 1'b0;
        n_rail_ups[i]++;
        if (gap < settle_min) settle_min = gap;
        if (gap < SETTLE_CYCLES) begin
          settle_viol++;
          $display("[%0t] tb| ERROR: %s reset released %0d cycles after its rail came on; the budget is %0d",
                   $time, pd_name(i), gap, SETTLE_CYCLES);
        end
      end

    // ---- Observation window, and the spec rules at every commit ----
    wire [4:0] o_dc = {pb_por[i], pb_warm[i], pb_ret[i], pb_clken[i], pb_isoln[i]};

    // [3:0] PWR_STATUS  [8:4] {PORESETn, WARMRESETn, RETRESETn, CLKEN, ISOLATEn}
    // [9] DEVQREQn [10] DEVQACCEPTn [11] DEVQDENY [12] DEVQACTIVE
    // [13] PCSMPREQ [14] PCSMPACCEPT [15] IRQ  [31:16] PCSMPSTATE
    assign ob_live[i] = {pb_pstate[i], pb_irq[i], pb_pacc[i], pb_preq[i], pb_qact[i],
                         pb_qdeny[i], pb_qaccn[i], pb_qreqn[i], o_dc, pb_status[i]};

    logic [4:0]  s_dc;
    logic [15:0] s_hw;
    logic [3:0]  s_st;
    logic        s_qreqn, s_qaccn, s_qdeny, s_preq, s_qact, s_pclken, s_edge, s_unspt, s_polwr;
    bit          acc_seen = 1'b0;          // a device accept since the last committed hop
    logic [5:0]  s_ev;
    longint unsigned t_iso_rel, t_clk_on, t_rst_rel, t_clk_off, t_iso_on, t_wr, t_act;
    bit          v_iso_rel, v_clk_on, v_rst_rel, v_clk_off, v_iso_on, v_wr, v_act;

    always @(posedge clk) begin
      if (!rst_n) begin
        v_iso_rel = 0; v_clk_on = 0; v_rst_rel = 0; v_clk_off = 0; v_iso_on = 0;
        v_wr = 0; v_act = 0;
      end else begin
        // ---- Counts ----
        if (!pb_qreqn[i] && s_qreqn) ob[i][OB_QREQ_FALLS]++;
        if ( pb_qreqn[i] && !s_qreqn) ob[i][OB_QREQ_RISES]++;
        if ( pb_qdeny[i] && !s_qdeny) n_qdeny[i]++;
        if (!pb_qaccn[i] && s_qaccn) begin n_qacc[i]++; acc_seen = 1'b1; end
        if ( pb_polwr[i] && !s_polwr) n_polwr[i]++;
        if ( pb_preq[i] && !s_preq) begin
          ob[i][OB_PREQ_RISES]++;
          ob[i][OB_PCSM_REQ] = 32'(pb_pstate[i]);
        end
        for (int k = 0; k < 6; k++)
          if (pb_ev[i][k] && !s_ev[k]) ob[i][OB_EV_TRN + k]++;
        if (pb_unspt[i] && !s_unspt) ob[i][OB_EV_UNSPT]++;
        if (pb_edge[i]  && !s_edge)  ob[i][OB_EV_EDGE]++;
        if (pb_qact[i]  != s_qact)   ob[i][OB_ACT_EDGES]++;
        if (!pb_pclken[i] && s_pclken) ob[i][OB_CLK_GATES]++;
        if (o_dc != s_dc)            ob[i][OB_DC_EDGES]++;

        // ---- Start latency: from the policy write, and from DEVQACTIVE
        //      falling, to the device being asked ----
        if (pb_polwr[i]) begin t_wr = cyc; v_wr = 1; end
        if (!pb_qact[i] && s_qact) begin t_act = cyc; v_act = 1; end
        if (!pb_qreqn[i] && s_qreqn) begin
          ob[i][OB_LAT_WR]  = v_wr  ? int'(cyc - t_wr)  : 32'hFFFF_FFFF;
          ob[i][OB_LAT_ACT] = v_act ? int'(cyc - t_act) : 32'hFFFF_FFFF;
          v_wr = 0; v_act = 0;
        end

        // ---- Table 4-5 spacings, power-up side ----
        if (o_dc[0] && !s_dc[0]) begin t_iso_rel = cyc; v_iso_rel = 1; end
        if (o_dc[1] && !s_dc[1]) begin
          if (v_iso_rel) spacing_chk(i, 0, cyc - t_iso_rel, pb_d_ic[i]);
          t_clk_on = cyc; v_clk_on = 1;
        end
        if (|(o_dc[4:2] & ~s_dc[4:2])) begin
          if (v_clk_on) spacing_chk(i, 1, cyc - t_clk_on, pb_d_cr[i]);
          t_rst_rel = cyc; v_rst_rel = 1;
        end
        // ---- ...and power-down side ----
        if (!o_dc[1] && s_dc[1]) begin t_clk_off = cyc; v_clk_off = 1; end
        if (!o_dc[0] && s_dc[0]) begin
          if (v_clk_off) spacing_chk(i, 3, cyc - t_clk_off, pb_d_ci[i]);
          t_iso_on = cyc; v_iso_on = 1;
        end
        if (|(~o_dc[4:2] & s_dc[4:2]))
          if (v_iso_on) spacing_chk(i, 4, cyc - t_iso_on, pb_d_ir[i]);
        if (pb_hwstat[i] !== s_hw) begin
          if (v_rst_rel) spacing_chk(i, 2, cyc - t_rst_rel, pb_d_rh[i]);
          v_iso_rel = 0; v_clk_on = 0; v_rst_rel = 0; v_clk_off = 0; v_iso_on = 0;
        end

        // ---- Every committed hop, against the spec's tables ----
        if (pb_status[i] !== s_st) begin
          ck_dom(i, spec_hop_ok(s_st, pb_status[i]),
                 $sformatf("%s: hop %s -> %s has ON at neither end and is not OFF -> MEM_RET (Section 3.3.2)",
                           pd_name(i), mode_name(s_st), mode_name(pb_status[i])));
          ck_dom(i, o_dc === spec_devctl(pb_status[i]),
                 $sformatf("%s: entered %s with {PORESETn,WARMRESETn,RETRESETn,CLKEN,ISOLATEn} = %05b, Tables 4-7/4-9/4-11 give %05b",
                           pd_name(i), mode_name(pb_status[i]), o_dc, spec_devctl(pb_status[i])));
          ck_dom(i, pb_hwstat[i] === spec_hwstat(pb_status[i]),
                 $sformatf("%s: entered %s with PPUHWSTAT 0x%04h, Table 3-2 gives 0x%04h",
                           pd_name(i), mode_name(pb_status[i]), pb_hwstat[i], spec_hwstat(pb_status[i])));
          ck_dom(i, pb_pstate[i] === spec_pstate(i, pb_status[i]),
                 $sformatf("%s: entered %s with PCSMPSTATE 0x%04h, Table 4-12 gives 0x%04h",
                           pd_name(i), mode_name(pb_status[i]), pb_pstate[i], spec_pstate(i, pb_status[i])));
          n_trans[i]++;
          if (s_st == PM_ON && pb_status[i] != PM_WARM_RST && !acc_seen) n_forced[i]++;
          acc_seen = 1'b0;
          hop_log[i].push_back(pb_status[i]);
          if (pb_status[i] == PM_OFF || pb_status[i] == PM_MEM_RET) ll_ok[i] = 1'b1;
          if (!quiet)
            $display("[%0t] tb| %-4s %-8s -> %s", $time, pd_name(i), mode_name(s_st),
                     mode_name(pb_status[i]));
        end else if ((pb_status[i] == PM_OFF || pb_status[i] == PM_MEM_RET) &&
                     (pb_nret_rst[i] !== 1'b0 || pb_ret_rst[i] !== 1'b0 || pb_clken[i] !== 1'b0)) begin
          // Logic loss without a probe inside the domain (10.4, LOGIC_LOSS):
          // both device resets asserted and the clock off, for as long as the
          // PPU stays in the mode
          ll_ok[i] = 1'b0;
        end
      end
      s_dc = o_dc; s_hw = pb_hwstat[i]; s_st = pb_status[i];
      s_qreqn = pb_qreqn[i]; s_qaccn = pb_qaccn[i]; s_qdeny = pb_qdeny[i]; s_preq = pb_preq[i];
      s_qact = pb_qact[i]; s_pclken = pb_pclken[i]; s_edge = pb_edge[i]; s_unspt = pb_unspt[i];
      s_ev = pb_ev[i]; s_polwr = pb_polwr[i];
    end
  end

  // ===========================================================================
  // The CPU domains, from the always-on side: the first instruction fetch
  // after each core reset release, fetches of the reset vector, the load
  // port's writes (and a shadow of what it wrote), CPUn_BOOT writes
  // ===========================================================================
  bit          ff_armed  [2] = '{0, 0};
  bit          ff_valid  [2] = '{0, 0};
  logic [31:0] ff_addr   [2];
  int unsigned n_vecf    [2] = '{0, 0};     // fetches of CPUn_BOOT + 0x80
  int unsigned n_ldwr    [2] = '{0, 0};     // load-port writes accepted
  int unsigned n_bootwr  [2] = '{0, 0};     // soc4_ctrl CPUn_BOOT writes
  bit          fetch_off [2] = '{0, 0};     // FETCH_EN seen 0 (cleared by the BFM)
  logic [31:0] ld_shadow [2][W_IMAGE];      // 0x000-0xBFF as the load port last wrote it
  logic [1:0]  core_rst_q = '0;

  initial
    for (int n = 0; n < 2; n++)
      for (int w = 0; w < W_IMAGE; w++) ld_shadow[n][w] = 'x;

  always @(posedge clk) begin
    for (int n = 0; n < 2; n++) begin
      if (rst_n) begin
        if (cpu_core_rst[n] === 1'b1 && core_rst_q[n] !== 1'b1) begin
          ff_armed[n] = 1'b1;
          ff_valid[n] = 1'b0;
        end
        if (cpu_ireq[n] === 1'b1) begin
          if (ff_armed[n]) begin
            ff_addr[n]  = cpu_iaddr[n];
            ff_valid[n] = 1'b1;
            ff_armed[n] = 1'b0;
          end
          if (cpu_iaddr[n] === cpu_boot[n] + 32'h80) n_vecf[n]++;
        end
        if (ld_req[n] === 1'b1 && ld_we[n] === 1'b1 && ld_open[n] === 1'b1) begin
          automatic int unsigned w = ld_addr[n][11:2];
          n_ldwr[n]++;
          if (w < W_IMAGE)
            for (int b = 0; b < 4; b++)
              if (ld_be[n][b]) ld_shadow[n][w][8*b +: 8] = ld_wdata[n][8*b +: 8];
        end
        if (u_dut.u_ctrl.req_i && u_dut.u_ctrl.we_i && u_dut.u_ctrl.addr_i[11:0] == 12'h000 + 4 * n)
          n_bootwr[n]++;
        if (cpu_fetch[n] === 1'b0) fetch_off[n] = 1'b1;
      end
      core_rst_q[n] = cpu_core_rst[n];
    end
  end

  // ===========================================================================
  // The accelerators' fills: the seed of each ACC's last fill (IP_CMD 01 while
  // the domain is ON), which the RAM checks and OBS_RAM compare against
  // ===========================================================================
  logic [7:0] fill_seed  [2];
  bit         fill_valid [2] = '{0, 0};
  bit         fill_since [2] = '{0, 0};     // a fill since the domain's last checkpoint

  always @(posedge clk)
    if (rst_n)
      for (int k = 0; k < 2; k++)
        if (acc_ipc[k] === 2'b01 && pb_hwstat[2 + k] === spec_hwstat(PM_ON)) begin
          fill_seed[k]  = acc_seed;
          fill_valid[k] = 1'b1;
          fill_since[k] = 1'b1;
        end

  // ===========================================================================
  // OBS_RAM (index 23), soc4's own: read from the always-on arrays (the
  // firmware's soc4_stress.c header). [7:0] bank b intact -- an ACC: every
  // word === the pattern of its last fill; a CPU, bank 0 only: every word of
  // 0x000-0xBFF as the load port last wrote it. [15:8] bank b lost: every word
  // X. [16] valid: there is something to compare against.
  // ===========================================================================
  function automatic logic [31:0] obs_ram(input int unsigned d);
    logic [7:0] ok, lost;
    bit         v;
    ok = '0; lost = '0;
    if (d < 2) begin
      bit good = 1'b1, gone = 1'b1;
      v = 1'b0;
      for (int w = 0; w < W_IMAGE; w++) begin
        if (!$isunknown(ld_shadow[d][w])) v = 1'b1;
        if (cram(d, w) !== ld_shadow[d][w]) good = 1'b0;
      end
      for (int w = 0; w < 1024; w++)
        if (!$isunknown(cram(d, w))) gone = 1'b0;
      ok[0] = good && v; lost[0] = gone;
    end else if (d < NUM_PD) begin
      v = fill_valid[d - 2];
      for (int b = 0; b < 8; b++) begin
        bit good = 1'b1, gone = 1'b1;
        for (int a = 0; a < 16; a++) begin
          logic [31:0] x;
          x = aram(d - 2, b, a);
          if (!v || x !== ip_pattern(fill_seed[d - 2], b, a)) good = 1'b0;
          if (!$isunknown(x)) gone = 1'b0;
        end
        ok[b] = good; lost[b] = gone;
      end
    end else
      return 32'hDEAD_0B5E;
    return {15'd0, v, lost, ok};
  endfunction

  // Computed in the middle of the cycle of the read: scp_sim_ctrl takes
  // obs_val_i at the next edge.
  logic [31:0] s_obs_ram = '0, a_obs_ram = '0;
  always @(negedge clk) begin
    if (s_req && !s_we && s_addr[11:0] == 12'h040 + 4 * OB_RAM) s_obs_ram = obs_ram(s_obs_dom);
    if (a_req && !a_we && a_addr[11:0] == 12'h040 + 4 * OB_RAM) a_obs_ram = obs_ram(a_obs_dom);
  end

  function automatic logic [31:0] obs_value(input logic [7:0] d, input logic [4:0] k,
                                            input logic [31:0] ram);
    if (d >= NUM_PD) return 32'hDEAD_0B5E;
    case (int'(k))
      OB_LIVE:   return ob_live[d];
      OB_RAM:    return ram;
      OB_HOPS:   return n_trans[d];
      OB_HWSTAT: return 32'(pb_hwstat[d]);
      default:   return ob[d][k];
    endcase
  endfunction
  always_comb s_obs_val = obs_value(s_obs_dom, s_obs_idx, s_obs_ram);
  always_comb a_obs_val = obs_value(a_obs_dom, a_obs_idx, a_obs_ram);

  // ===========================================================================
  // The SCP's console, read as it is written: the policy's FAULT, recovery and
  // give-up lines are evidence for soc4bfm (11.2)
  // ===========================================================================
  int unsigned n_fault_log [NUM_PD] = '{default: 0};
  int unsigned n_recov_log [NUM_PD] = '{default: 0};
  int unsigned n_gaveup_log[NUM_PD] = '{default: 0};
  bit          scp_fatal = 1'b0;
  string       con_line = "";

  // The input table (soc4_plat.h SCP_PLAT_INPUTS, soc4_top's irq_in), and the
  // policy's line per input action (mod/policy.c, "scp: in <i> <name>: ...")
  localparam int unsigned NUM_IN  = 16;
  localparam int unsigned IN_DB   = 4,  IN_PLIC = 5,  IN_H0   = 6,  IN_H1   = 7,
                          IN_RTC  = 8,  IN_GPIO = 9,  IN_BBRX = 10, IN_DBG  = 11,
                          IN_ACG0 = 12, IN_ACG1 = 13, IN_DB1  = 14, IN_CKRST = 15;
  int unsigned n_in_line   [NUM_IN] = '{default: 0};
  int unsigned n_in_up     [NUM_IN] = '{default: 0};   // "power up DOMAIN_ID d: SUCCESS"
  int unsigned n_in_notify [NUM_IN] = '{default: 0};
  int unsigned n_in_reason [NUM_IN] = '{default: 0};
  int unsigned n_in_ignored[NUM_IN] = '{default: 0};
  string       in_last     [NUM_IN];
  // The boot's lines (scp/main.c): "scp: ready" and, after a reset of the SCP
  // alone, "scp: took over: <n> domain(s) not in low power, <m> PPU(s)
  // reprogrammed" (W1)
  int unsigned n_ready = 0, n_took = 0, took_up = 0, took_rw = 0;

  function automatic bit has(input string s, input string sub);
    if (sub.len() > s.len()) return 1'b0;
    for (int p = 0; p + sub.len() <= s.len(); p++)
      if (s.substr(p, p + sub.len() - 1) == sub) return 1'b1;
    return 1'b0;
  endfunction

  always @(posedge clk)
    if (rst_n && s_req && s_we && s_addr[11:0] == 12'h000 && s_be[0]) begin
      if (s_wd[7:0] == 8'h0A) begin
        int id;
        if ($sscanf(con_line, "scp: FAULT: DOMAIN_ID %d", id) == 1 && id >= 0 && id < NUM_PD) begin
          if (has(con_line, "gave up")) n_gaveup_log[id]++;
          else                          n_fault_log[id]++;
        end
        if ($sscanf(con_line, "scp: DOMAIN_ID %d recovered", id) == 1 && id >= 0 && id < NUM_PD &&
            has(con_line, "recovered"))
          n_recov_log[id]++;
        if (has(con_line, "FATAL")) scp_fatal = 1'b1;
        if (has(con_line, "scp: ready")) n_ready++;
        begin
          int a, b;
          if ($sscanf(con_line, "scp: took over: %d domain(s) not in low power, %d PPU(s) reprogrammed",
                      a, b) == 2) begin
            n_took++; took_up = a; took_rw = b;
          end
        end
        if ($sscanf(con_line, "scp: in %d", id) == 1 && id >= 0 && id < NUM_IN) begin
          n_in_line[id]++;
          in_last[id] = con_line;
          if (has(con_line, ": power up DOMAIN_ID") && has(con_line, ": SUCCESS")) n_in_up[id]++;
          if (has(con_line, ": policy notified")) n_in_notify[id]++;
          if (has(con_line, ": wake reason"))     n_in_reason[id]++;
          if (has(con_line, ": ignored"))         n_in_ignored[id]++;
        end
        con_line = "";
      end else if (s_wd[7:0] != 8'h0D) begin
        con_line = $sformatf("%s%c", con_line, s_wd[7:0]);
      end
    end

  // ===========================================================================
  // AXI4-Lite VALID/payload rules on the SCP's manager port
  // ===========================================================================
  int unsigned axi_viol = 0;
  logic        aw_w, w_w, ar_w, b_w, r_w;
  logic [31:0] awaddr_d, wdata_d, araddr_d, rdata_d;
  logic [1:0]  bresp_d, rresp_d;

  always @(posedge clk) begin
    if (rst_n && scp_rst_n) begin
      if (aw_w && (!u_dut.u_scp.b_awvalid || u_dut.u_scp.b_awaddr !== awaddr_d)) axi_viol++;
      if (w_w  && (!u_dut.u_scp.b_wvalid  || u_dut.u_scp.b_wdata  !== wdata_d )) axi_viol++;
      if (ar_w && (!u_dut.u_scp.b_arvalid || u_dut.u_scp.b_araddr !== araddr_d)) axi_viol++;
      if (b_w  && (!u_dut.u_scp.b_bvalid  || u_dut.u_scp.b_bresp  !== bresp_d )) axi_viol++;
      if (r_w  && (!u_dut.u_scp.b_rvalid  || u_dut.u_scp.b_rresp  !== rresp_d
                                          || u_dut.u_scp.b_rdata  !== rdata_d )) axi_viol++;
    end
    aw_w     <= rst_n && scp_rst_n && u_dut.u_scp.b_awvalid && !u_dut.u_scp.b_awready;
    w_w      <= rst_n && scp_rst_n && u_dut.u_scp.b_wvalid  && !u_dut.u_scp.b_wready;
    ar_w     <= rst_n && scp_rst_n && u_dut.u_scp.b_arvalid && !u_dut.u_scp.b_arready;
    b_w      <= rst_n && scp_rst_n && u_dut.u_scp.b_bvalid  && !u_dut.u_scp.b_bready;
    r_w      <= rst_n && scp_rst_n && u_dut.u_scp.b_rvalid  && !u_dut.u_scp.b_rready;
    awaddr_d <= u_dut.u_scp.b_awaddr;
    wdata_d  <= u_dut.u_scp.b_wdata;
    araddr_d <= u_dut.u_scp.b_araddr;
    bresp_d  <= u_dut.u_scp.b_bresp;
    rresp_d  <= u_dut.u_scp.b_rresp;
    rdata_d  <= u_dut.u_scp.b_rdata;
  end

  // ===========================================================================
  // The SCP's interrupt block (scp_irq.sv, always-on in PD_TOP): per input,
  // PENDING rises and falls and RAW (synchronised) rises; the block's line
  // into Ibex; and Ibex's fast lines, which nothing may raise any more
  // ===========================================================================
  logic [NUM_IN-1:0] blk_pend, blk_raw, blk_en, blk_pend_d = '0, blk_raw_d = '0;
  logic              blk_line, blk_line_d = 1'b0;
  int unsigned       in_set  [NUM_IN] = '{default: 0};
  int unsigned       in_clr  [NUM_IN] = '{default: 0};
  int unsigned       in_rise [NUM_IN] = '{default: 0};
  int unsigned       n_line = 0, n_fast_hi = 0;
  assign blk_pend = u_dut.u_scp.u_irq.pend_q;
  assign blk_raw  = u_dut.u_scp.u_irq.in_s;
  assign blk_en   = u_dut.u_scp.u_irq.en_q;
  assign blk_line = u_dut.u_scp.u_irq.irq_o;

  always @(posedge clk) begin
    if (rst_n && scp_rst_n) begin
      for (int i = 0; i < NUM_IN; i++) begin
        if (blk_pend[i] === 1'b1 && blk_pend_d[i] !== 1'b1) in_set[i]++;
        if (blk_pend[i] === 1'b0 && blk_pend_d[i] === 1'b1) in_clr[i]++;
        if (blk_raw[i]  === 1'b1 && blk_raw_d[i]  !== 1'b1) in_rise[i]++;
      end
      if (blk_line === 1'b1 && blk_line_d !== 1'b1) n_line++;
      if (u_dut.u_scp.irq_fast !== 15'd0) n_fast_hi++;
    end
    blk_pend_d = blk_pend;
    blk_raw_d  = blk_raw;
    blk_line_d = blk_line;
  end

  // ===========================================================================
  // The clock/reset bridges (ckrst_bridge.sv in each domain's always-on part;
  // platform plan H16): every request equal to its PPU control, every cycle;
  // per domain the request edges, the fault rises and every status bit seen
  // (the firmware clears them within microseconds, so K1 reads ck_seen)
  // ===========================================================================
  int unsigned ck_fwd_bad = 0, ck_edges = 0;
  int unsigned ck_rise  [NUM_PD] = '{default: 0};
  int unsigned ck_expect[NUM_PD] = '{default: 0};
  logic [7:0]  ck_seen  [NUM_PD] = '{default: '0};
  logic [NUM_PD-1:0] ck_fault_d = '0;
  logic [NUM_PD-1:0] ck_req_d   = '0;
  logic [NUM_PD-1:0] ck_ppu_clken;
  logic [NUM_PD-1:0][1:0] ck_ppu_rst;
  assign ck_ppu_clken = {u_dut.u_acc1.u_dom.dev_clken_req, u_dut.u_acc0.u_dom.dev_clken_req,
                         u_dut.u_cpu1.u_dom.dev_clken_req, u_dut.u_cpu0.u_dom.dev_clken_req};
  for (genvar d = 0; d < NUM_PD; d++) begin : g_ck_rst
    assign ck_ppu_rst[d] = {pb_ret_rst[d], pb_nret_rst[d]};
  end

  always @(posedge clk)
    if (rst_n) begin
      for (int d = 0; d < NUM_PD; d++) begin
        if (tile_clk_req[d] !== ck_ppu_clken[d] || tile_rst_req_n[d] !== ck_ppu_rst[d]) ck_fwd_bad++;
        if (tile_clk_req[d] !== ck_req_d[d]) ck_edges++;
        if (u_dut.ckrst_fault[d] === 1'b1 && ck_fault_d[d] !== 1'b1) ck_rise[d]++;
        ck_seen[d] |= u_dut.ckrst_stat[d];
      end
      ck_req_d   <= tile_clk_req;
      ck_fault_d <= u_dut.ckrst_fault;
    end

  // What pd_init programs (mod/pd.c pd_dev_delays_of): the build's delays
  // (rst_hwstat 2, iso_clken 20, clken_rst 4, clken_iso 2, iso_rst 2) with
  // CLKEN_RST, CLKEN_ISO and RST_HWSTAT raised to the domain's latency.
  function automatic logic [7:0] ck_cover(input logic [7:0] dflt, input int unsigned lat);
    return (lat > dflt) ? 8'(lat) : dflt;
  endfunction
  function automatic bit ck_dcdr_ok(input int unsigned d);
    return pb_d_rh[d] === ck_cover(8'd2, CKRST_LAT[d]) && pb_d_ic[d] === 8'd20 &&
           pb_d_cr[d] === ck_cover(8'd4, CKRST_LAT[d]) && pb_d_ci[d] === ck_cover(8'd2, CKRST_LAT[d]) &&
           pb_d_ir[d] === 8'd2;
  endfunction

  // ===========================================================================
  // The SCP watchdog (scp_wdog.sv inside scp_top, PD_TOP; platform plan H18).
  // Sampled on the negedge, away from the edge its flops change on. Per reset:
  // the AXI manager idle when it begins (the drain) unless CAUSE.DRAINTO; the
  // SCP subsystem reset and nothing else (the domains' reset, soc4_ctrl, the
  // mailbox's firewall untouched) while it lasts; RST_CYCLES long; and CAUSE
  // WDOG, not POR, with RESETS counting, when it ends -- before the firmware
  // can clear it. wd_min_left: the closest a kicked watchdog came to expiry.
  // ===========================================================================
  localparam int unsigned WD_RST_CYCLES = 16;            // scp_wdog.sv RST_CYCLES
  localparam int unsigned WD_TIMEOUT    = 32'h0020_0000; // soc4_plat.h SCP_PLAT_WDOG_TIMEOUT
  int unsigned     wdog_expect = 0, n_wdog_rst = 0, wd_len = 0, wd_scope_bad = 0;
  longint unsigned wd_min_left = 64'hFFFF_FFFF;
  bit              wd_hang  = 1'b0;                      // W1's deliberate hang: COUNT may run out
  logic            wd_req_d = 1'b0;
  logic [1:0]      wd_fw_en0;
  initial void'($value$plusargs("wdog_resets=%d", wdog_expect));

  always @(negedge clk) begin
    if (rst_n) begin
      if (u_dut.u_scp.u_wdog.en_q === 1'b1 && !wd_hang && u_dut.u_scp.u_wdog.cnt_q < wd_min_left)
        wd_min_left = u_dut.u_scp.u_wdog.cnt_q;
      if (u_dut.u_scp.wdog_rst_o === 1'b1) begin
        if (wd_req_d !== 1'b1) begin
          n_wdog_rst++;
          wd_len = 0;
          wd_fw_en0 = u_dut.u_mbx.fw_en_q;
          tck("WDOG_DRAIN", (u_dut.u_scp.b_bready === 1'b0 && u_dut.u_scp.b_rready === 1'b0) ||
                            u_dut.u_scp.u_wdog.cause_q[3] === 1'b1,
              $sformatf("watchdog reset %0d began with the AXI manager busy (bready %b rready %b) and no DRAINTO",
                        n_wdog_rst, u_dut.u_scp.b_bready, u_dut.u_scp.b_rready));
        end
        wd_len++;
        if (u_dut.u_scp.rst_sub_n !== 1'b0 || u_dut.scp_sub_rst_n !== 1'b0 || u_dut.dom_rst_n !== 1'b1 ||
            u_dut.u_mbx.fw_en_q !== wd_fw_en0 || u_dut.u_ctrl.rst_ni !== 1'b1)
          wd_scope_bad++;
      end else if (wd_req_d === 1'b1) begin
        tck("WDOG_RESET", wd_len == WD_RST_CYCLES,
            $sformatf("watchdog reset %0d lasted %0d cycles, expected %0d", n_wdog_rst, wd_len, WD_RST_CYCLES));
        tck("WDOG_SCOPE", wd_scope_bad == 0,
            $sformatf("watchdog reset %0d: %0d cycle(s) in which the SCP subsystem was not in reset, or the domains, soc4_ctrl or the firewall were",
                      n_wdog_rst, wd_scope_bad));
        tck("WDOG_CAUSE", u_dut.u_scp.u_wdog.cause_q[1:0] === 2'b10 &&
                          u_dut.u_scp.u_wdog.resets_q === 8'(n_wdog_rst),
            $sformatf("CAUSE after watchdog reset %0d: [3:0] %b, RESETS %0d; expected WDOG set, POR clear, RESETS %0d",
                      n_wdog_rst, u_dut.u_scp.u_wdog.cause_q, u_dut.u_scp.u_wdog.resets_q, n_wdog_rst));
        $display("[%0t] tb| watchdog reset %0d: %0d cycles, the SCP subsystem only; CAUSE [3:0] %b, RESETS %0d",
                 $time, n_wdog_rst, wd_len, u_dut.u_scp.u_wdog.cause_q, u_dut.u_scp.u_wdog.resets_q);
        wd_scope_bad = 0;
      end
    end
    wd_req_d = u_dut.u_scp.wdog_rst_o;
  end

  // TB_ERRORS: failed checks plus every monitor, power-model, AXI and settle
  // violation, so a program can tell which of its steps the hardware objected
  // to.
  always_comb begin
    tb_bad = errors + axi_viol + settle_viol;
    for (int i = 0; i < NUM_PD; i++) tb_bad += mon_viol[i] + pm_viol[i];
  end

`ifdef SOC4_PA
  // ===========================================================================
  // Supply nets through the IEEE 1801 UPF package (Section 8.4-2). A supply
  // net is not a register inside the domain, so decision 14 holds. Net names
  // are relative to the UPF design top, soc4_tb/u_dut (upf/soc4_tb_vcs.upf).
  // The state must be exactly FULL_ON or OFF: a name the power intent does not
  // have reads UNDETERMINED, and fails both ways rather than passing as "off".
  // ===========================================================================
  int unsigned n_supply = 0, n_supply_bad = 0, n_supply_off = 0;

  task automatic supply_ck(input string tag, input int unsigned d, input string net, input bit want);
    UPF::supply_net_type v;
    bit on, ok;
    v  = UPF::get_supply_value(net);
    on = UPF::get_supply_on_state(v);
    ok = (on == want) && (v.state == (want ? UPF::FULL_ON : UPF::OFF));
    n_supply++;
    if (!want) n_supply_off++;
    if (!ok) n_supply_bad++;
    tck(tag, ok, $sformatf("%s in %s: supply net %s is %s (on %0b, %0d uV), the mode needs it %s",
                           pd_name(d), mode_name(pb_status[d]), net, v.state.name(), on, v.voltage,
                           want ? "FULL_ON" : "OFF"));
  endtask
`endif

  // ===========================================================================
  // The PPU-level CHECK (10.3), from either sim control and from the BFM
  // ===========================================================================
  task automatic ppu_check(input string who, input int unsigned d, input logic [3:0] m);
    if (d >= NUM_PD) begin
      ck(1'b0, $sformatf("%s CHECK names domain %0d; there are %0d", who, d, NUM_PD));
      return;
    end
    ck(pb_status[d] === m,
       $sformatf("%s: %s says %s, the PPU's committed mode is %s",
                 pd_name(d), who, mode_name(m), mode_name(pb_status[d])));
    ck(pb_pcsm[d] === pcsm_of(m),
       $sformatf("%s: the PCSM committed %s, %s needs %s", pd_name(d),
                 mode_name(pb_pcsm[d]), mode_name(m), mode_name(pcsm_of(m))));
    ck(pb_hwstat[d] === spec_hwstat(m),
       $sformatf("%s: PPUHWSTAT = 0x%04h, %s is 0x%04h", pd_name(d),
                 pb_hwstat[d], mode_name(m), spec_hwstat(m)));
    ck(devctl(d) === spec_devctl(m),
       $sformatf("%s in %s: {PORESETn,WARMRESETn,RETRESETn,CLKEN,ISOLATEn} = %05b, Tables 4-7/4-9/4-11 give %05b",
                 pd_name(d), mode_name(m), devctl(d), spec_devctl(m)));
    ck(pb_pstate[d][7:0] === {4'h0, pcsm_of(m)},
       $sformatf("%s in %s: PCSMPSTATE[7:0] = 0x%02h, Table 4-12 gives 0x%02h",
                 pd_name(d), mode_name(m), pb_pstate[d][7:0], {4'h0, pcsm_of(m)}));
    ck(pb_pstate[d][15:8] === spec_pstate(d, m)[15:8],
       $sformatf("%s in %s: PCSMPSTATE[15:8] = 0x%02h, Table 4-12 gives the RAM byte 0x%02h",
                 pd_name(d), mode_name(m), pb_pstate[d][15:8], spec_pstate(d, m)[15:8]));
    ck(pb_lon[d] === keeps_logic(m) && pb_lret[d] === (m == PM_FULL_RET),
       $sformatf("%s in %s: logic rail on=%0b ret=%0b, expected on=%0b ret=%0b",
                 pd_name(d), mode_name(m), pb_lon[d], pb_lret[d], keeps_logic(m),
                 (m == PM_FULL_RET)));
    ck(pb_ron[d] === ram_full(m) && pb_rret[d] === ram_kept(m),
       $sformatf("%s in %s: RAM on=%0b ret=%0b, expected on=%0b ret=%0b",
                 pd_name(d), mode_name(m), pb_ron[d], pb_rret[d], ram_full(m), ram_kept(m)));
    // Under SOC4_PA the supply-net rule of Section 8.4-2: VDD_LOGIC_n off
    // exactly in the modes that remove logic power (OFF, MEM_RET, FULL_RET),
    // and VDD_RET_0 on exactly in CPU0's FULL_RET (logic_ret, checked above).
`ifdef SOC4_PA
    supply_ck("SUPPLY", d, $sformatf("VDD_LOGIC_%0d", d), keeps_logic(m));
    if (d == 0) supply_ck("SUPPLY", d, "VDD_RET_0", m == PM_FULL_RET);
`endif
  endtask

  always @(posedge clk)
    if (rst_n && s_chk) ppu_check("the SCP", s_dom, s_md);

  // ===========================================================================
  // Checkpoints: the PPU-level CHECK, counted at once (the AP waits for
  // TB_CHECKS to move), then the IP-state rule for (dom, mode) (10.4), which
  // may wait up to RULE_WAIT cycles and so runs in its own process.
  //
  // What a rule needs to know about the domain since its previous checkpoint
  // is kept here: the previous checkpoint's mode, whether a fill happened,
  // whether a WARM_RST or a down-hop was committed, and the device-channel
  // counts.
  // ===========================================================================
  logic [3:0]  ck_prev  [NUM_PD] = '{default: 4'hF};   // 4'hF: none yet
  int unsigned hl_base  [NUM_PD] = '{default: 0};
  int unsigned b_qdeny  [NUM_PD] = '{default: 0};
  int unsigned b_qfall  [NUM_PD] = '{default: 0};
  int unsigned b_qacc   [NUM_PD] = '{default: 0};
  bit          ll_pend  [NUM_PD] = '{default: 0};      // a logic-losing mode was checked: test the next ON
  int unsigned rules_pending = 0;

  // CPU0's state at its last checkpoints (FULLRET_RAM, FULLRET_REGS)
  logic [31:0] c0_snap [1024];
  bit          c0_snap_valid = 1'b0;
  logic [31:0] c0_wakes, c0_boots;
  int unsigned c0_vecf;

  task automatic rule_line(input string tag, input int unsigned d, input string what);
    $display("[%0t] tb| [chk:%s] %s: %s", $time, tag, pd_name(d), what);
  endtask

  task automatic c0_take_snap();
    for (int w = 0; w < 1024; w++) c0_snap[w] = cram(0, w);
    c0_snap_valid = 1'b1;
  endtask

  // ---- (0, ON) after a cold ON ----
  task automatic r_cpu0_boot();
    int unsigned t = 0;
    while (t < RULE_WAIT && !(cram(0, W_MARKER) === 32'hC0DE_0000 && cram(0, W_BOOTS) === 32'd1)) begin
      repeat (16) @(posedge clk); t += 16;
    end
    tck("CPU0_BOOT", cram(0, W_MARKER) === 32'hC0DE_0000,
        $sformatf("CPU0 MARKER 0x%08h after %0d cycles, expected 0xC0DE0000", cram(0, W_MARKER), t));
    tck("CPU0_BOOT", cram(0, W_BOOTS) === 32'd1,
        $sformatf("CPU0 BOOT_COUNT %0d, expected 1 (a fresh image)", cram(0, W_BOOTS)));
    tck("CPU0_BOOT", ff_valid[0] && ff_addr[0] === cpu_boot[0] + 32'h80,
        $sformatf("CPU0's first fetch after its reset release at 0x%08h (valid %0b), expected CPU0_BOOT + 0x80 = 0x%08h",
                  ff_addr[0], ff_valid[0], cpu_boot[0] + 32'h80));
    tck("CPU0_BOOT", cram(0, W_TRAP) === 32'd0,
        $sformatf("CPU0 TRAP 0x%08h", cram(0, W_TRAP)));
    // back in WFI: then nothing in its RAM moves until it is woken
    t = 0;
    while (t < 4000 && cpu_sleep[0] !== 1'b1) begin @(posedge clk); t++; end
    repeat (20) @(posedge clk);
    c0_take_snap();
    rule_line("CPU0_BOOT", 0, $sformatf("booted at 0x%08h, MARKER 0x%08h, BOOT_COUNT %0d",
                                        ff_addr[0], cram(0, W_MARKER), cram(0, W_BOOTS)));
  endtask

  // ---- (0, FULL_RET) ----
  task automatic r_cpu0_fullret();
    int unsigned diff = 0, xs = 0;
    tck("FULLRET_RAM", pb_ram_sleep[0][0] === 1'b1 && pb_ram_sd[0][0] === 1'b0,
        $sformatf("CPU0 RAM pins in FULL_RET: sleep %b sd %b, expected 1 0",
                  pb_ram_sleep[0][0], pb_ram_sd[0][0]));
    for (int w = 0; w < 1024; w++) begin
      if ($isunknown(cram(0, w))) xs++;
      else if (c0_snap_valid && cram(0, w) !== c0_snap[w]) diff++;
    end
    tck("FULLRET_RAM", c0_snap_valid && diff == 0 && xs == 0,
        $sformatf("CPU0 RAM against its snapshot at the last ON checkpoint: %0d word(s) differ, %0d X (snapshot %0s)",
                  diff, xs, c0_snap_valid ? "taken" : "MISSING"));
    c0_wakes = cram(0, W_WAKES);
    c0_boots = cram(0, W_BOOTS);
    c0_vecf  = n_vecf[0];
    rule_line("FULLRET_RAM", 0, $sformatf("RAM retained (%0d words compared), WAKE_COUNT %0d",
                                          1024, c0_wakes));
  endtask

  // ---- (0, ON) after FULL_RET: the core's registers survived ----
  task automatic r_cpu0_warm();
    int unsigned t = 0;
    bit dump_ok;
    forever begin
      dump_ok = 1'b1;
      for (int i = 0; i < 12; i++) if (cram(0, W_DUMP + i) !== cpu_sig(i)) dump_ok = 1'b0;
      if ((cram(0, W_WAKES) === c0_wakes + 1 && dump_ok) || t >= RULE_WAIT) break;
      repeat (16) @(posedge clk); t += 16;
    end
    tck("FULLRET_REGS", cram(0, W_WAKES) === c0_wakes + 1,
        $sformatf("CPU0 WAKE_COUNT %0d after %0d cycles, expected %0d (one wake from WFI)",
                  cram(0, W_WAKES), t, c0_wakes + 1));
    for (int i = 0; i < 12; i++)
      tck("FULLRET_REGS", cram(0, W_DUMP + i) === cpu_sig(i),
          $sformatf("CPU0 s%0d dumped after the wake 0x%08h, expected 0x%08h (retained through FULL_RET)",
                    i, cram(0, W_DUMP + i), cpu_sig(i)));
    tck("FULLRET_REGS", cram(0, W_BOOTS) === c0_boots,
        $sformatf("CPU0 BOOT_COUNT %0d, was %0d at FULL_RET: it rebooted", cram(0, W_BOOTS), c0_boots));
    tck("FULLRET_REGS", n_vecf[0] == c0_vecf,
        $sformatf("CPU0 fetched its reset vector %0d time(s) since the FULL_RET checkpoint",
                  n_vecf[0] - c0_vecf));
    tck("FULLRET_REGS", cram(0, W_TRAP) === 32'd0, $sformatf("CPU0 TRAP 0x%08h", cram(0, W_TRAP)));
    t = 0;
    while (t < 4000 && cpu_sleep[0] !== 1'b1) begin @(posedge clk); t++; end
    repeat (20) @(posedge clk);
    c0_take_snap();
    rule_line("FULLRET_REGS", 0, $sformatf("woke without a reboot: WAKE_COUNT %0d, s0-s11 intact",
                                           cram(0, W_WAKES)));
  endtask

  // ---- (1, ON) ----
  task automatic r_cpu1_restart();
    int unsigned t = 0;
    logic [31:0] c1, c2;
    while (t < RULE_WAIT && !(cram(1, W_MARKER) === 32'hC0DE_0001 && cram(1, W_BOOTS) === 32'd1)) begin
      repeat (16) @(posedge clk); t += 16;
    end
    tck("CPU1_RESTART", ff_valid[1] && ff_addr[1] === cpu_boot[1] + 32'h80,
        $sformatf("CPU1's first fetch after its reset release at 0x%08h (valid %0b), expected CPU1_BOOT + 0x80 = 0x%08h",
                  ff_addr[1], ff_valid[1], cpu_boot[1] + 32'h80));
    tck("CPU1_RESTART", cram(1, W_MARKER) === 32'hC0DE_0001,
        $sformatf("CPU1 MARKER 0x%08h after %0d cycles, expected 0xC0DE0001", cram(1, W_MARKER), t));
    tck("CPU1_RESTART", cram(1, W_BOOTS) === 32'd1,
        $sformatf("CPU1 BOOT_COUNT %0d, expected 1 (a fresh image)", cram(1, W_BOOTS)));
    c1 = cram(1, W_COUNT);
    repeat (1000) @(posedge clk);
    c2 = cram(1, W_COUNT);
    tck("CPU1_RESTART", !$isunknown(c1) && !$isunknown(c2) && c2 > c1,
        $sformatf("CPU1 COUNT %0d then %0d 1000 cycles later: not running", c1, c2));
    tck("CPU1_RESTART", cram(1, W_TRAP) === 32'd0, $sformatf("CPU1 TRAP 0x%08h", cram(1, W_TRAP)));
    rule_line("CPU1_RESTART", 1, $sformatf("restarted at 0x%08h, BOOT_COUNT %0d, COUNT %0d -> %0d",
                                           ff_addr[1], cram(1, W_BOOTS), c1, c2));
  endtask

  // A CPU RAM lost: its shutdown pin up and every word X
  task automatic r_cpu_ram_lost(input string tag, input int unsigned n);
    int unsigned known = 0;
    for (int w = 0; w < 1024; w++) if (!$isunknown(cram(n, w))) known++;
    tck(tag, pb_ram_sd[n][0] === 1'b1,
        $sformatf("%s RAM shutdown pin %b in %s, expected 1", pd_name(n), pb_ram_sd[n][0],
                  mode_name(pb_status[n])));
    tck(tag, known == 0, $sformatf("%s RAM: %0d of 1024 words still known after OFF", pd_name(n), known));
    rule_line(tag, n, "RAM shut down, all 1024 words lost");
  endtask

  // Logic loss without a probe inside the domain (10.4)
  task automatic r_logic_loss(input int unsigned d);
    tck("LOGIC_LOSS", ll_ok[d] && pb_ret_rst[d] === 1'b0 && pb_nret_rst[d] === 1'b0 &&
                      pb_clken[d] === 1'b0,
        $sformatf("%s in %s: dev_ret_rst_n %b dev_nret_rst_n %b CLKEN %b, held since the down-hop %0b; all must be 0",
                  pd_name(d), mode_name(pb_status[d]), pb_ret_rst[d], pb_nret_rst[d], pb_clken[d],
                  ll_ok[d]));
`ifdef SOC4_PA
    supply_ck("LOGIC_LOSS", d, $sformatf("VDD_LOGIC_%0d", d), 1'b0);
`endif
    rule_line("LOGIC_LOSS", d, $sformatf("in %s both device resets asserted and the clock off since the down-hop",
                                         mode_name(pb_status[d])));
  endtask

  // ---- (1, OFF) after a power-off ----
  task automatic r_cpu1_off(input int unsigned dq, input int unsigned df, input int unsigned da);
    r_cpu_ram_lost("CPU1_OFF", 1);
    tck("CPU1_OFF", dq == RETRY_CAP + 1 && df == RETRY_CAP + 1 && da == 0,
        $sformatf("CPU1 power-off: %0d denial(s), %0d request(s), %0d accept(s); expected %0d denied, then forced (no request)",
                  dq, df, da, RETRY_CAP + 1));
    r_logic_loss(1);
    rule_line("CPU1_OFF", 1, $sformatf("denied %0d times, forced; RAM lost", dq));
  endtask

  // ---- The accelerator banks ----
  function automatic int unsigned acc_bad(input int unsigned k, input logic [7:0] seed);
    int unsigned bad = 0;
    for (int b = 0; b < 8; b++)
      for (int a = 0; a < 16; a++)
        if (aram(k, b, a) !== ip_pattern(seed, b, a)) bad++;
    return bad;
  endfunction
  function automatic int unsigned acc_known(input int unsigned k);
    int unsigned n = 0;
    for (int b = 0; b < 8; b++)
      for (int a = 0; a < 16; a++)
        if (!$isunknown(aram(k, b, a))) n++;
    return n;
  endfunction

  task automatic r_acc_pattern(input string tag, input int unsigned k, input int unsigned wait_max);
    int unsigned t = 0, bad;
    bad = fill_valid[k] ? acc_bad(k, fill_seed[k]) : 128;
    while (bad != 0 && t < wait_max) begin
      repeat (8) @(posedge clk); t += 8;
      bad = fill_valid[k] ? acc_bad(k, fill_seed[k]) : 128;
    end
    tck(tag, fill_valid[k] && bad == 0,
        $sformatf("%s banks against the pattern of seed 0x%02h: %0d of 128 words differ (a fill recorded: %0b)",
                  pd_name(2 + k), fill_seed[k], bad, fill_valid[k]));
    rule_line(tag, 2 + k, $sformatf("128 words === the pattern of seed 0x%02h", fill_seed[k]));
  endtask

  task automatic r_acc_lost(input int unsigned k);
    int unsigned n;
    n = acc_known(k);
    tck("OFF_RAM", n == 0, $sformatf("%s banks: %0d of 128 words known, all must be X (lost)",
                                     pd_name(2 + k), n));
    rule_line("OFF_RAM", 2 + k, "all 128 words lost");
  endtask

  // After the next ON, ppu_device_ip came up from reset, idle
  task automatic r_acc_idle(input int unsigned k);
    logic busy, done;
    busy = (k == 0) ? u_dut.u_acc0.u_ip.busy : u_dut.u_acc1.u_ip.busy;
    done = (k == 0) ? u_dut.u_acc0.u_ip.done : u_dut.u_acc1.u_ip.done;
    tck("LOGIC_LOSS", busy === 1'b0 && done === 1'b0,
        $sformatf("%s after ON from a logic-losing mode: busy %b done %b, expected 0 0 (reset)",
                  pd_name(2 + k), busy, done));
    rule_line("LOGIC_LOSS", 2 + k, "after ON the device came up idle from reset (busy 0, done 0)");
  endtask

  task automatic rule_run(input int unsigned d, input logic [3:0] m, input logic [3:0] prev,
                          input bit fill, input bit warm_hop, input bit down_hop, input bit llp,
                          input int unsigned dq, input int unsigned df, input int unsigned da);
    rules_pending++;
    case (d)
      0: begin
        if (m == PM_ON) begin
          if (prev == PM_FULL_RET && !warm_hop) r_cpu0_warm();
          else                                  r_cpu0_boot();
        end else if (m == PM_FULL_RET) r_cpu0_fullret();
        else if (m == PM_OFF && !down_hop) r_cpu_ram_lost("OFF_RAM", 0);
      end
      1: begin
        if (m == PM_ON) r_cpu1_restart();
        else if (m == PM_OFF) begin
          if (down_hop) r_cpu1_off(dq, df, da);
          else          r_cpu_ram_lost("OFF_RAM", 1);
        end
      end
      default: begin
        automatic int unsigned k = d - 2;
        if (m == PM_ON) begin
          if (fill)                        r_acc_pattern("FILL", k, 2000);
          else if (prev == PM_MEM_RET)     r_acc_pattern("MEMRET_RAM", k, 0);
          else if (prev == PM_OFF)         r_acc_lost(k);
          if (llp && !fill)                r_acc_idle(k);
        end else if (m == PM_MEM_RET) begin
          tck("MEMRET_RAM", pb_ram_sleep[d] === 8'hFF && pb_ram_sd[d] === 8'h00,
              $sformatf("%s bank pins in MEM_RET: sleep %02h sd %02h, expected FF 00",
                        pd_name(d), pb_ram_sleep[d], pb_ram_sd[d]));
          r_acc_pattern("MEMRET_RAM", k, 0);
          if (down_hop) r_logic_loss(d);
        end else if (m == PM_OFF) begin
          r_acc_lost(k);
          if (down_hop) r_logic_loss(d);
        end
      end
    endcase
    rules_pending--;
  endtask

  // who: "the AP" or "the BFM". rules = 0: the PPU-level CHECK only, with the
  // history still advanced (the BFM's own checks stand in for the rule).
  task automatic checkpoint(input string who, input int unsigned d, input logic [3:0] m,
                            input bit rules = 1'b1);
    logic [3:0]  prev;
    bit          fill, warm_hop, down_hop, llp;
    int unsigned dq, df, da;
    ppu_check(who, d, m);
    if (d >= NUM_PD) return;
    prev = ck_prev[d];
    fill = (d >= 2) ? fill_since[d - 2] : 1'b0;
    warm_hop = 1'b0; down_hop = 1'b0;
    for (int j = hl_base[d]; j < hop_log[d].size(); j++) begin
      if (hop_log[d][j] == PM_WARM_RST) warm_hop = 1'b1;
      if (hop_log[d][j] == PM_OFF || hop_log[d][j] == PM_MEM_RET || hop_log[d][j] == PM_FULL_RET)
        down_hop = 1'b1;
    end
    dq  = n_qdeny[d] - b_qdeny[d];
    df  = ob[d][OB_QREQ_FALLS] - b_qfall[d];
    da  = n_qacc[d] - b_qacc[d];
    llp = ll_pend[d];
    // the next checkpoint's history starts here
    ck_prev[d] = m;
    hl_base[d] = hop_log[d].size();
    b_qdeny[d] = n_qdeny[d];
    b_qfall[d] = ob[d][OB_QREQ_FALLS];
    b_qacc[d]  = n_qacc[d];
    if (d >= 2) fill_since[d - 2] = 1'b0;
    ll_pend[d] = down_hop && (m == PM_OFF || m == PM_MEM_RET);
    if (rules)
      fork
        rule_run(d, m, prev, fill, warm_hop, down_hop, llp, dq, df, da);
      join_none
  endtask

  always @(posedge clk)
    if (rst_n && a_chk) checkpoint("the AP", a_dom, a_md);

  // ===========================================================================
  // The TL-UL BFM (10.2): plays the AP on the socket when +bfm (soc4bfm).
  // Drives on negedges, samples on posedges; every wait has a timeout that
  // counts a [bfm-timeout] error and returns, so a run never hangs.
  //
  // The RPMI encodings are librpmi v1.0.0's (src/pmu/fw/vendor/librpmi,
  // include/librpmi.h, cited by line); the queue geometry is scp_rpmi.h's:
  // 64-byte slots, 8 per queue, A2P requests at +0x000 and P2A ACKs at +0x200;
  // head index in slot 0, tail in slot 1, message i in slot i + 2, 6 messages
  // (lib/rpmi_transport_shmem.c:38-53, 236-249).
  // ===========================================================================
  localparam logic [31:0] TL_QMEM = 32'h2000_0000;     // 4.6
  localparam logic [31:0] TL_DB   = 32'h2000_1000;
  localparam logic [31:0] TL_WIN  = 32'h0000_2000;     // agent k's window: TL_QMEM + k * TL_WIN
  localparam logic [7:0]  RPU_SOURCE = 8'h20;          // soc4_regs.h SOC4_RPU_SOURCE
  localparam logic [7:0]  RPU_MASK   = 8'hFC;          // SOC4_RPU_SRC_MASK: sources 0x20-0x23
  localparam int unsigned TL_TMO  = 200;
  localparam int unsigned RP_SLOT = 64, RP_QSIZE = 8 * RP_SLOT, RP_NDATA = 6;
  localparam logic [15:0] G_BASE   = 16'h0001;   // librpmi.h:188
  localparam logic [15:0] G_SYSRST = 16'h0003;   // :190
  localparam logic [15:0] G_DPWR   = 16'h0009;   // :196
  localparam logic [7:0]  S_IVER   = 8'h02;      // :219
  localparam logic [7:0]  S_IIDN   = 8'h03;      // :220
  localparam logic [7:0]  S_SPEC   = 8'h04;      // :221
  localparam logic [7:0]  S_PROBE  = 8'h06;      // :223
  localparam logic [7:0]  S_BATTR  = 8'h07;      // :224
  localparam logic [7:0]  S_NDOM   = 8'h02;      // :329 RPMI_DPWR_SRV_GET_NUM_DOMAINS
  localparam logic [7:0]  S_DATTR  = 8'h03;      // :330 RPMI_DPWR_SRV_GET_ATTRIBUTES
  localparam logic [7:0]  S_SET    = 8'h04;      // :331 RPMI_DPWR_SRV_SET_DPWR_STATE
  localparam logic [7:0]  S_GET    = 8'h05;      // :332 RPMI_DPWR_SRV_GET_DPWR_STATE
  localparam logic [7:0]  T_NORMAL = 8'h00;      // :88
  localparam logic [7:0]  T_ACK    = 8'h02;      // :92
  localparam logic [31:0] ST_OK    = 32'd0;      // :115 RPMI_SUCCESS
  localparam logic [31:0] ST_INVAL = 32'hFFFF_FFFD;  // :121 RPMI_ERR_INVALID_PARAM (-3)
  localparam logic [31:0] ST_DENY  = 32'hFFFF_FFFC;  // :126 RPMI_ERR_DENIED (-4)
  localparam logic [31:0] ST_HWF   = 32'hFFFF_FFF8;  // :141 RPMI_ERR_HW_FAULT (-8)
  localparam logic [31:0] DP_ON    = 32'd0;      // :1622 RPMI_DPWR_STATE_ON
  localparam logic [31:0] DP_OFF   = 32'd3;      // :1623 RPMI_DPWR_STATE_OFF
  localparam logic [31:0] VER_1_0  = {16'd1, 16'd0};  // RPMI_BASE_VERSION(1, 0), :20-24, :228-236, :384-385
  localparam logic [31:0] F0_PRIV  = 32'h2;      // :238 RPMI_BASE_FLAGS_F0_PRIVILEGE

  bit          bfm_on = 1'b0, bfm_done = 1'b0;
  int unsigned bfm_checks = 0, bfm_errs = 0;
  logic [7:0]  bfm_step = '0;
  // Per agent k (0 the AP, 1 the RPU): its A2P tail and P2A head as it last
  // wrote them, its token, and whether a request of its is in flight
  logic [31:0] ag_tail [2] = '{default: '0};
  logic [31:0] ag_head [2] = '{default: '0};
  logic [15:0] ag_tok  [2] = '{16'h0100, 16'h0800};
  bit          ag_busy [2] = '{default: 1'b0};

  task automatic bck(input string tag, input bit cond, input string msg);
    bfm_checks++;
    if (!cond) bfm_errs++;
    tck(tag, cond, msg);
    bfm_stat = {16'd0, 8'(bfm_errs > 255 ? 255 : bfm_errs), bfm_step};
  endtask

  task automatic bfm_timeout(input string msg);
    bfm_checks++;
    bfm_errs++;
    checks++;
    errors++;
    $display("[%0t] tb| ERROR: [bfm-timeout] %s", $time, msg);
  endtask

  function automatic bit step_on(input string s);
    if (bfm_only == "" || bfm_only == "all") return 1'b1;
    return has({",", bfm_only, ","}, {",", s, ","});
  endfunction

  // Port p's request side, as the BFM drives it
  function automatic void tl_drive(input int unsigned p, input tlul_pkg::tl_h2d_t h);
    if (p == 0) bfm_h = h;
    else        rpu_h = h;
  endfunction
  function automatic tlul_pkg::tl_d2h_t tl_resp(input int unsigned p);
    return (p == 0) ? bfm_d : rpu_d;
  endfunction

  // One TL-UL transaction on mailbox port p: a_size 2, d_ready 1. Port 0's
  // host sends a_user TL_A_USER_DEFAULT; port 1's, the RPU stand-in, sends
  // a_user 0, as a TileLink host has none, and its boundary adapter supplies
  // the default (H13, soc4_tl_bound.sv).
  task automatic tl_req(input logic [7:0] src, input bit wr, input logic [31:0] addr,
                        input logic [31:0] data, input logic [3:0] mask,
                        output logic [31:0] rdata, output bit derr, output bit done,
                        input int unsigned p = 0);
    int unsigned n;
    tlul_pkg::tl_h2d_t h;
    tlul_pkg::tl_d2h_t d;
    done = 1'b0; derr = 1'b0; rdata = 'x;
    @(negedge clk);
    h           = tlul_pkg::TL_H2D_DEFAULT;
    h.a_valid   = 1'b1;
    h.a_opcode  = !wr ? tlul_pkg::Get :
                  (mask == 4'hF) ? tlul_pkg::PutFullData : tlul_pkg::PutPartialData;
    h.a_size    = 2'd2;
    h.a_source  = src;
    h.a_address = addr;
    h.a_mask    = wr ? mask : 4'hF;
    h.a_data    = wr ? data : 32'h0;
    h.a_user    = (p == 0) ? tlul_pkg::TL_A_USER_DEFAULT : '0;
    h.d_ready   = 1'b1;
    tl_drive(p, h);
    n = 0;
    forever begin
      @(posedge clk);
      if (tl_resp(p).a_ready === 1'b1) break;
      if (++n >= TL_TMO) begin
        @(negedge clk) tl_drive(p, tlul_pkg::TL_H2D_DEFAULT);
        bfm_timeout($sformatf("TL-UL %s 0x%08h source 0x%02h port %0d: no a_ready in %0d cycles",
                              wr ? "write" : "read", addr, src, p, TL_TMO));
        return;
      end
    end
    @(negedge clk) begin h.a_valid = 1'b0; tl_drive(p, h); end
    n = 0;
    forever begin
      @(posedge clk);
      if (tl_resp(p).d_valid === 1'b1) break;
      if (++n >= TL_TMO) begin
        bfm_timeout($sformatf("TL-UL %s 0x%08h source 0x%02h port %0d: no response in %0d cycles",
                              wr ? "write" : "read", addr, src, p, TL_TMO));
        return;
      end
    end
    d     = tl_resp(p);
    rdata = d.d_data;
    derr  = d.d_error;
    done  = 1'b1;
    bck("TLUL", d.d_source === src && d.d_opcode === (wr ? tlul_pkg::AccessAck
                                                         : tlul_pkg::AccessAckData),
        $sformatf("TL-UL %s 0x%08h: d_source 0x%02h d_opcode %0d, expected 0x%02h %0d",
                  wr ? "write" : "read", addr, d.d_source, d.d_opcode, src, wr ? 0 : 1));
  endtask

  task automatic tl_wr(input string tag, input logic [7:0] src, input logic [31:0] addr,
                       input logic [31:0] data, input logic [3:0] mask = 4'hF,
                       input int unsigned p = 0);
    logic [31:0] r; bit e, ok;
    tl_req(src, 1'b1, addr, data, mask, r, e, ok, p);
    if (ok) bck(tag, !e, $sformatf("TL-UL write 0x%08h from source 0x%02h answered d_error", addr, src));
  endtask

  task automatic tl_rd(input string tag, input logic [7:0] src, input logic [31:0] addr,
                       output logic [31:0] data, input int unsigned p = 0);
    bit e, ok;
    tl_req(src, 1'b0, addr, 32'h0, 4'hF, data, e, ok, p);
    if (ok) bck(tag, !e, $sformatf("TL-UL read 0x%08h from source 0x%02h answered d_error", addr, src));
  endtask

  task automatic tl_wr_err(input string tag, input logic [7:0] src, input logic [31:0] addr,
                           input logic [31:0] data, input int unsigned p = 0);
    logic [31:0] r; bit e, ok;
    tl_req(src, 1'b1, addr, data, 4'hF, r, e, ok, p);
    if (ok) bck(tag, e, $sformatf("TL-UL write 0x%08h from source 0x%02h was not refused (no d_error)", addr, src));
  endtask

  task automatic tl_rd_err(input string tag, input logic [7:0] src, input logic [31:0] addr,
                           input int unsigned p = 0);
    logic [31:0] r; bit e, ok;
    tl_req(src, 1'b0, addr, 32'h0, 4'hF, r, e, ok, p);
    if (ok) bck(tag, e, $sformatf("TL-UL read 0x%08h from source 0x%02h was not refused (no d_error)", addr, src));
  endtask

  // Agent k: its window's base on its own port (soc4: port k), its source
  function automatic logic [31:0] ag_win(input int unsigned k);
    return TL_QMEM + k * TL_WIN;
  endfunction
  function automatic logic [7:0] ag_src(input int unsigned k);
    return (k == 0) ? AP_SOURCE : RPU_SOURCE;
  endfunction

  function automatic logic [31:0] q_slot(input int q, input logic [31:0] i, input int unsigned k = 0);
    return ag_win(k) + q * RP_QSIZE + (i + 2) * RP_SLOT;
  endfunction

  // One request of agent k into its A2P queue, the tail, then its doorbell
  // (OpenSBI's order). Header: group [15:0], service [23:16], flags [31:24]
  // (type in [2:0]); data length [15:0], token [31:16] (librpmi.h:26-110).
  task automatic rpmi_send(input logic [15:0] grp, input logic [7:0] srv, input logic [15:0] tok,
                           input int unsigned n, input logic [31:0] dw [4], input int unsigned k = 0);
    logic [31:0] s;
    s = q_slot(0, ag_tail[k], k);
    tl_wr("RPMI", ag_src(k), s + 0, {T_NORMAL, srv, grp}, 4'hF, k);
    tl_wr("RPMI", ag_src(k), s + 4, {tok, 16'(4 * n)}, 4'hF, k);
    for (int i = 0; i < n; i++) tl_wr("RPMI", ag_src(k), s + 8 + 4 * i, dw[i], 4'hF, k);
    ag_tail[k] = (ag_tail[k] + 1) % RP_NDATA;
    tl_wr("RPMI", ag_src(k), ag_win(k) + RP_SLOT, ag_tail[k], 4'hF, k);
    tl_wr("RPMI", ag_src(k), ag_win(k) + 32'h1000, 32'h1, 4'hF, k);
  endtask

  // Wait up to tmo cycles for agent k's next ACK; got = 0 on timeout, no error
  // (the caller decides). Up to 8 data words.
  task automatic rpmi_ack(input int unsigned tmo, output bit got, output logic [31:0] h0,
                          output logic [31:0] h1, output logic [31:0] r [8], input int unsigned k = 0);
    logic [31:0] tail, s;
    int unsigned waited = 0;
    got = 1'b0; h0 = '0; h1 = '0;
    for (int i = 0; i < 8; i++) r[i] = '0;
    forever begin
      tl_rd("RPMI", ag_src(k), ag_win(k) + RP_QSIZE + RP_SLOT, tail, k);
      if (tail !== ag_head[k] || waited >= tmo) break;
      repeat (32) @(posedge clk);
      waited += 32;
    end
    if (tail === ag_head[k]) return;
    s = q_slot(1, ag_head[k], k);
    tl_rd("RPMI", ag_src(k), s + 0, h0, k);
    tl_rd("RPMI", ag_src(k), s + 4, h1, k);
    for (int i = 0; i < 8 && 4 * i < h1[15:0]; i++) tl_rd("RPMI", ag_src(k), s + 8 + 4 * i, r[i], k);
    ag_head[k] = (ag_head[k] + 1) % RP_NDATA;
    tl_wr("RPMI", ag_src(k), ag_win(k) + RP_QSIZE, ag_head[k], 4'hF, k);
    got = 1'b1;
  endtask

  // A request of agent k and its acknowledgement (200 000-cycle timeout), the
  // header checked: type ACKNOWLEDGEMENT, the same group, service and token
  // (rpmi_context.c:339-343). lat: cycles from the doorbell to the ACK seen.
  task automatic rpmi_call(input string tag, input logic [15:0] grp, input logic [7:0] srv,
                           input int unsigned n, input logic [31:0] d0, input logic [31:0] d1,
                           output bit got, output logic [31:0] r [8], output int unsigned rlen,
                           output longint unsigned lat, input int unsigned k = 0);
    logic [31:0] dw [4], h0, h1;
    logic [15:0] tok;
    longint unsigned t0;
    dw = '{d0, d1, 32'h0, 32'h0};
    ag_tok[k]++;
    tok = ag_tok[k];
    ag_busy[k] = 1'b1;
    rpmi_send(grp, srv, tok, n, dw, k);
    t0 = cyc;
    rpmi_ack(200_000, got, h0, h1, r, k);
    ag_busy[k] = 1'b0;
    lat  = cyc - t0;
    rlen = h1[15:0];
    if (!got) begin
      bfm_timeout($sformatf("RPMI agent %0d group 0x%04h service 0x%02h token 0x%04h: no ACK in 200000 cycles",
                            k, grp, srv, tok));
      return;
    end
    bck(tag, h0 === {T_ACK, srv, grp} && h1[31:16] === tok,
        $sformatf("RPMI ACK header 0x%08h 0x%08h, expected 0x%08h, token 0x%04h",
                  h0, h1, {T_ACK, srv, grp}, tok));
  endtask

  // SET_DPWR_STATE from agent k, its status returned
  task automatic dp_set(input string tag, input logic [31:0] id, input logic [31:0] st,
                        output logic [31:0] status, output longint unsigned lat,
                        input int unsigned k = 0);
    bit got; logic [31:0] r [8]; int unsigned rl;
    rpmi_call(tag, G_DPWR, S_SET, 2, id, st, got, r, rl, lat, k);
    status = got ? r[0] : 32'hDEAD_DEAD;
  endtask

  task automatic dp_expect(input string tag, input logic [31:0] id, input logic [31:0] st,
                           input logic [31:0] want, input string what, input int unsigned k = 0);
    logic [31:0] status; longint unsigned lat;
    dp_set(tag, id, st, status, lat, k);
    bck(tag, status === want, $sformatf("%s: SET_DPWR_STATE(%0d, %0d) status %0d, expected %0d",
                                        what, id, st, $signed(status), $signed(want)));
  endtask

  task automatic dp_get(input string tag, input logic [31:0] id, input logic [31:0] want_state,
                        input int unsigned k = 0);
    bit got; logic [31:0] r [8]; int unsigned rl; longint unsigned lat;
    rpmi_call(tag, G_DPWR, S_GET, 1, id, 32'h0, got, r, rl, lat, k);
    bck(tag, got && rl == 8 && r[0] === ST_OK && r[1] === want_state,
        $sformatf("GET_DPWR_STATE(%0d) from agent %0d: length %0d status %0d state %0d, expected 8 0 %0d",
                  id, k, rl, $signed(r[0]), r[1], want_state));
  endtask

  task automatic cyc_wait(input int unsigned n);
    repeat (n) @(posedge clk);
  endtask

  // Wait until cycle t0 + dt; at once if that has passed already
  task automatic wait_until(input longint unsigned t0, input longint unsigned dt);
    while (cyc < t0 + dt) @(posedge clk);
  endtask

  task automatic hold(input int unsigned d, input bit on);
    @(negedge clk) t_hold[d] = on;
  endtask
  task automatic deny(input int unsigned k, input bit on);
    @(negedge clk) t_deny[k] = on;
  endtask

  // The accelerator's software, as the AP plays it: fill its banks
  task automatic acc_fill(input int unsigned k, input logic [7:0] seed);
    @(negedge clk) begin t_seed = seed; t_ipc[k] = 2'b01; end
    cyc_wait(100);
    @(negedge clk) begin t_ipc[k] = 2'b00; t_seed = '0; end
  endtask

  // The BFM's checkpoint: the PPU-level CHECK and the IP-state rule, run to
  // completion before the next step
  task automatic ck_mode(input int unsigned d, input logic [3:0] m, input bit rules = 1'b1);
    checkpoint("the BFM", d, m, rules);
    #1;
    wait (rules_pending == 0);
  endtask

  function automatic string hops_since(input int unsigned d, input int unsigned from);
    string s = "";
    for (int j = from; j < hop_log[d].size(); j++)
      s = {s, (j == from) ? "" : " -> ", mode_name(hop_log[d][j])};
    return (s == "") ? "(none)" : s;
  endfunction

  function automatic logic [3:0] lp_of(input int unsigned d);
    case (d)
      0:       return PM_FULL_RET;
      2:       return PM_MEM_RET;
      default: return PM_OFF;
    endcase
  endfunction

  function automatic int unsigned axi_n(input int unsigned d);
    return n_axi_wr[d] + n_axi_rd[d];
  endfunction

  function automatic logic [31:0] qmem(input int unsigned w);
    return u_dut.u_mbx.u_qmem.sram[w];
  endfunction

  // ---------------------------------------------------------------------------
  // B0: the SCP held in reset -- the firewall denies everything
  // ---------------------------------------------------------------------------
  task automatic b0();
    logic [31:0] qm [256];
    int unsigned changed = 0;
    logic [7:0] srcs [3];
    srcs = '{AP_SOURCE, 8'h00, 8'hFF};
    bfm_step = 8'd0;
    $display("[%0t] tb| B0: the SCP held in reset (+scp_hold=%0d): every TL-UL access must be denied",
             $time, scp_hold);
    bck("FW_RESET_DENY", scp_rst_n === 1'b0, "the SCP is not held in reset at B0 (+scp_hold)");
    for (int w = 0; w < 256; w++) qm[w] = qmem(w);
    foreach (srcs[i]) begin
      tl_wr_err("FW_RESET_DENY", srcs[i], TL_DB, 32'h1);
      tl_wr_err("FW_RESET_DENY", srcs[i], TL_QMEM, 32'hA5A5_0000 | srcs[i]);
      tl_rd_err("FW_RESET_DENY", srcs[i], TL_QMEM + 32'h40);
    end
    cyc_wait(4);
    for (int w = 0; w < 256; w++) if (qmem(w) !== qm[w]) changed++;
    bck("FW_RESET_DENY", u_dut.u_mbx.ring_q[0] === 1'b0 && u_dut.db_irq[0] === 1'b0 &&
                         u_dut.u_mbx.ring_cnt_q[0] === 32'd0,
        $sformatf("a denied access rang: DB_STATUS %b irq_ext %b DB_RING_CNT %0d",
                  u_dut.u_mbx.ring_q[0], u_dut.db_irq[0], u_dut.u_mbx.ring_cnt_q[0]));
    bck("FW_RESET_DENY", changed == 0,
        $sformatf("%0d queue-memory word(s) changed by denied accesses", changed));
    bck("FW_RESET_DENY", u_dut.u_mbx.deny_cnt_q[0] === 32'd9,
        $sformatf("FW_DENY_CNT %0d, expected 9", u_dut.u_mbx.deny_cnt_q[0]));
    bck("FW_RESET_DENY", u_dut.u_mbx.fw_last_q[9] === 1'b1 && u_dut.u_mbx.fw_last_q[8] === 1'b1,
        $sformatf("FW_LAST 0x%03h: [9] (FW_EN was 0) and [8] must be 1", u_dut.u_mbx.fw_last_q[9:0]));
    bck("FW_RESET_DENY", scp_rst_n === 1'b0, "the SCP left reset during B0: +scp_hold too short");
    $display("[%0t] tb| [chk:FW_RESET_DENY] 9 accesses (sources 0x%02h, 0x00, 0xFF) denied; FW_DENY_CNT %0d, FW_LAST 0x%03h, no ring, memory unchanged",
             $time, AP_SOURCE, u_dut.u_mbx.deny_cnt_q[0], u_dut.u_mbx.fw_last_q[9:0]);
  endtask

  // ---------------------------------------------------------------------------
  // B1: the SCP released; librpmi has initialised the queues
  // ---------------------------------------------------------------------------
  task automatic b1();
    logic [31:0] v [4];
    int unsigned t = 0;
    bfm_step = 8'd1;
    wait (scp_rst_n === 1'b1);
    while (u_dut.u_ctrl.ap_run_q !== 1'b1 && t < 400_000) begin @(posedge clk); t++; end
    bck("INIT", u_dut.u_ctrl.ap_run_q === 1'b1,
        $sformatf("AP_RUN not set %0d cycles after the SCP left reset", t));
    cyc_wait(2000);
    tl_rd("INIT", AP_SOURCE, TL_QMEM + 32'h000, v[0]);
    tl_rd("INIT", AP_SOURCE, TL_QMEM + 32'h040, v[1]);
    tl_rd("INIT", AP_SOURCE, TL_QMEM + 32'h200, v[2]);
    tl_rd("INIT", AP_SOURCE, TL_QMEM + 32'h240, v[3]);
    bck("INIT", v[0] === 0 && v[1] === 0 && v[2] === 0 && v[3] === 0,
        $sformatf("A2P head/tail %0d/%0d, P2A head/tail %0d/%0d, all must be 0", v[0], v[1], v[2], v[3]));
    ag_tail[0] = '0; ag_head[0] = '0;
    $display("[%0t] tb| B1 [chk:INIT]: AP_RUN set; queue heads and tails 0", $time);
  endtask

  // ---------------------------------------------------------------------------
  // B2: an unlisted a_source denied with no side effect; the AP's admitted
  // ---------------------------------------------------------------------------
  task automatic b2();
    localparam logic [31:0] A = TL_QMEM + 32'h1C0;     // A2P slot 7, not in use
    logic [31:0] w0, r, dc0;
    logic [31:0] rc0;
    bfm_step = 8'd2;
    w0  = qmem(A[9:2]);
    dc0 = u_dut.u_mbx.deny_cnt_q[0];
    rc0 = u_dut.u_mbx.ring_cnt_q[0];
    tl_wr_err("FW_SRC_DENY", 8'h02, TL_DB, 32'h1);
    tl_wr_err("FW_SRC_DENY", 8'h02, A, 32'hBAD0_0002);
    tl_rd_err("FW_SRC_DENY", 8'h02, A);
    cyc_wait(4);
    bck("FW_SRC_DENY", u_dut.u_mbx.ring_q[0] === 1'b0 && u_dut.u_mbx.ring_cnt_q[0] === rc0,
        $sformatf("source 0x02 rang the doorbell: DB_STATUS %b DB_RING_CNT %0d (was %0d)",
                  u_dut.u_mbx.ring_q[0], u_dut.u_mbx.ring_cnt_q[0], rc0));
    bck("FW_SRC_DENY", qmem(A[9:2]) === w0,
        $sformatf("source 0x02 changed queue word 0x%08h: 0x%08h, was 0x%08h", A, qmem(A[9:2]), w0));
    bck("FW_SRC_DENY", u_dut.u_mbx.fw_last_q === {1'b0, 1'b1, 8'h02},
        $sformatf("FW_LAST 0x%05h, expected 0x00102 (transport 0, source 0x02, FW_EN was 1)", u_dut.u_mbx.fw_last_q));
    bck("FW_SRC_DENY", u_dut.u_mbx.deny_cnt_q[0] === dc0 + 3,
        $sformatf("FW_DENY_CNT %0d, expected %0d + 3", u_dut.u_mbx.deny_cnt_q[0], dc0));
    tl_wr("FW_ADMIT", AP_SOURCE, A, 32'h600D_0010);
    tl_rd("FW_ADMIT", AP_SOURCE, A, r);
    bck("FW_ADMIT", r === 32'h600D_0010 && qmem(A[9:2]) === 32'h600D_0010,
        $sformatf("the AP's write did not land: read 0x%08h, array 0x%08h", r, qmem(A[9:2])));
    tl_wr("FW_ADMIT", AP_SOURCE, A, w0);
    $display("[%0t] tb| B2 [chk:FW_SRC_DENY] source 0x02: 3 accesses denied, no ring, memory unchanged, FW_LAST 0x%03h; [chk:FW_ADMIT] source 0x%02h: write and read back OK",
             $time, u_dut.u_mbx.fw_last_q[9:0], AP_SOURCE);
  endtask

  // ---------------------------------------------------------------------------
  // B3: BASE and DEVICE_POWER discovery (as A1, A2)
  // ---------------------------------------------------------------------------
  task automatic b3();
    bit got; logic [31:0] r [8]; int unsigned rl; longint unsigned lat;
    string names [4];
    names = '{"CPU0", "CPU1", "ACC0", "ACC1"};
    bfm_step = 8'd3;
    rpmi_call("DISCOVER", G_BASE, S_SPEC, 0, 0, 0, got, r, rl, lat);
    bck("DISCOVER", got && rl == 8 && r[0] === ST_OK && r[1] === VER_1_0,
        $sformatf("GET_SPEC_VERSION: length %0d status %0d version 0x%08h", rl, $signed(r[0]), r[1]));
    rpmi_call("DISCOVER", G_BASE, S_IVER, 0, 0, 0, got, r, rl, lat);
    bck("DISCOVER", got && rl == 8 && r[0] === ST_OK && r[1] === VER_1_0,
        $sformatf("GET_IMPLEMENTATION_VERSION: length %0d status %0d 0x%08h", rl, $signed(r[0]), r[1]));
    rpmi_call("DISCOVER", G_BASE, S_IIDN, 0, 0, 0, got, r, rl, lat);
    bck("DISCOVER", got && rl == 8 && r[0] === ST_OK && r[1] === 32'd0,
        $sformatf("GET_IMPLEMENTATION_IDN: length %0d status %0d 0x%08h", rl, $signed(r[0]), r[1]));
    rpmi_call("DISCOVER", G_BASE, S_PROBE, 1, G_BASE, 0, got, r, rl, lat);
    bck("DISCOVER", got && r[0] === ST_OK && r[1] !== 32'd0,
        $sformatf("PROBE_SERVICE_GROUP(BASE): status %0d version 0x%08h", $signed(r[0]), r[1]));
    rpmi_call("DISCOVER", G_BASE, S_PROBE, 1, G_DPWR, 0, got, r, rl, lat);
    bck("DISCOVER", got && r[0] === ST_OK && r[1] !== 32'd0,
        $sformatf("PROBE_SERVICE_GROUP(DEVICE_POWER): status %0d version 0x%08h", $signed(r[0]), r[1]));
    rpmi_call("DISCOVER", G_BASE, S_PROBE, 1, G_SYSRST, 0, got, r, rl, lat);
    bck("DISCOVER", got && r[0] === ST_OK && r[1] === 32'd0,
        $sformatf("PROBE_SERVICE_GROUP(SYSTEM_RESET): status %0d version 0x%08h, expected absent (0)",
                  $signed(r[0]), r[1]));
    rpmi_call("DISCOVER", G_BASE, S_BATTR, 0, 0, 0, got, r, rl, lat);
    bck("DISCOVER", got && rl == 20 && r[0] === ST_OK && (r[1] & F0_PRIV) != 0,
        $sformatf("BASE GET_ATTRIBUTES: length %0d status %0d flags 0x%08h (M-mode context)",
                  rl, $signed(r[0]), r[1]));
    rpmi_call("DISCOVER", G_DPWR, S_NDOM, 0, 0, 0, got, r, rl, lat);
    bck("DISCOVER", got && rl == 8 && r[0] === ST_OK && r[1] === 32'd4,
        $sformatf("GET_NUM_DOMAINS: length %0d status %0d count %0d", rl, $signed(r[0]), r[1]));
    for (int id = 0; id < 4; id++) begin
      string nm;
      rpmi_call("DISCOVER", G_DPWR, S_DATTR, 1, id, 0, got, r, rl, lat);
      nm = "";
      for (int b = 0; b < 4; b++) nm = {nm, string'(r[3][8*b +: 8])};
      bck("DISCOVER", got && rl == 28 && r[0] === ST_OK && r[1] === 0 && r[2] === 0 &&
                      nm == names[id] && r[4][7:0] === 8'h00,
          $sformatf("GET_ATTRIBUTES(%0d): length %0d status %0d flags %0d latency %0d name \"%s\", expected \"%s\"",
                    id, rl, $signed(r[0]), r[1], r[2], nm, names[id]));
    end
    for (int id = 0; id < 4; id++) dp_get("DISCOVER", id, DP_OFF);
    $display("[%0t] tb| B3 [chk:DISCOVER]: BASE v1.0, DEVICE_POWER present, SYSTEM_RESET absent; 4 domains CPU0 CPU1 ACC0 ACC1, all OFF",
             $time);
  endtask

  // ---------------------------------------------------------------------------
  // B4: ON and OFF on each domain
  // ---------------------------------------------------------------------------
  task automatic onoff_on(input int unsigned d);
    logic [31:0] st; longint unsigned lat;
    dp_set("ONOFF", d, DP_ON, st, lat);
    bck("ONOFF", st === ST_OK, $sformatf("%s ON: status %0d", pd_name(d), $signed(st)));
    if (d >= 2) acc_fill(d - 2, (d == 2) ? 8'h5A : 8'hC3);
    ck_mode(d, PM_ON);
    $display("[%0t] tb| B4 [chk:ONOFF] %s ON: SUCCESS after %0d cycles; PPU in ON", $time, pd_name(d), lat);
  endtask

  task automatic onoff_off(input int unsigned d);
    logic [31:0] st; longint unsigned lat;
    dp_set("ONOFF", d, DP_OFF, st, lat);
    bck("ONOFF", st === ST_OK, $sformatf("%s OFF: status %0d", pd_name(d), $signed(st)));
    cyc_wait((d == 1) ? 220_000 : 150_000);
    ck_mode(d, lp_of(d));
    $display("[%0t] tb| B4 [chk:ONOFF] %s OFF: SUCCESS after %0d cycles; PPU in %s", $time, pd_name(d),
             lat, mode_name(lp_of(d)));
  endtask

  task automatic b4();
    bfm_step = 8'd4;
    for (int d = 0; d < 4; d++) begin
      onoff_on(d);
      onoff_off(d);
    end
    onoff_on(1);                           // CPU1 runs on, for B11
  endtask

  // ---------------------------------------------------------------------------
  // B5: OFF then ON inside the hysteresis window: cancelled, no PPU access
  // ---------------------------------------------------------------------------
  task automatic b5();
    logic [31:0] st; longint unsigned lat;
    int unsigned ax0, h0;
    bit left_on = 1'b0;
    bfm_step = 8'd5;
    dp_expect("CANCEL", 3, DP_ON, ST_OK, "ACC1 ON");
    // The ON's own events (STA_ACCEPT, STA_POLICY_TRN) are serviced by the
    // SCP's interrupt path after it has answered (pd_poll: read ISR and AISR,
    // clear ISR): let that happen before the window opens.
    cyc_wait(5000);
    dp_set("CANCEL", 3, DP_OFF, st, lat);
    bck("CANCEL", st === ST_OK, $sformatf("ACC1 OFF: status %0d", $signed(st)));
    ax0 = axi_n(3); h0 = n_trans[3];
    fork
      begin : watch
        forever begin @(posedge clk); if (pb_status[3] !== PM_ON) left_on = 1'b1; end
      end
      begin
        cyc_wait(20_000);
        dp_set("CANCEL", 3, DP_ON, st, lat);
      end
    join_any
    disable fork;
    bck("CANCEL", st === ST_OK, $sformatf("ACC1 ON inside the hysteresis: status %0d", $signed(st)));
    bck("CANCEL", axi_n(3) == ax0 && n_trans[3] == h0 && !left_on,
        $sformatf("between the OFF ACK and the ON ACK: %0d AXI handshake(s) to PPU 3, %0d hop(s), left ON %0b; expected none",
                  axi_n(3) - ax0, n_trans[3] - h0, left_on));
    $display("[%0t] tb| B5 [chk:CANCEL] ACC1 OFF then ON 20000 cycles later: both SUCCESS; %0d PPU 3 accesses, %0d hops in between",
             $time, axi_n(3) - ax0, n_trans[3] - h0);
    dp_expect("CANCEL", 3, DP_OFF, ST_OK, "ACC1 OFF");
    cyc_wait(150_000);
    ck_mode(3, PM_OFF);
  endtask

  // ---------------------------------------------------------------------------
  // B6: a busy, denying ACC0: denied 1 + retry_cap times, then forced
  // ---------------------------------------------------------------------------
  task automatic b6();
    int unsigned q0, f0, a0, h0;
    bfm_step = 8'd6;
    dp_expect("DENY_FORCE", 2, DP_ON, ST_OK, "ACC0 ON");
    ck_mode(2, PM_ON);
    hold(2, 1'b1); deny(0, 1'b1);
    q0 = n_qdeny[2]; f0 = ob[2][OB_QREQ_FALLS]; a0 = n_qacc[2]; h0 = hop_log[2].size();
    dp_expect("DENY_FORCE", 2, DP_OFF, ST_OK, "ACC0 OFF");
    cyc_wait(TICKS_MS + 70_000 + 50_000);
    bck("DENY_FORCE", n_qdeny[2] - q0 == RETRY_CAP + 1,
        $sformatf("ACC0: %0d denial(s), expected %0d (1 + retry_cap)", n_qdeny[2] - q0, RETRY_CAP + 1));
    bck("DENY_FORCE", pb_status[2] === PM_MEM_RET && ob[2][OB_QREQ_FALLS] - f0 == RETRY_CAP + 1 &&
                      n_qacc[2] - a0 == 0,
        $sformatf("ACC0 final hop: %s, %0d request(s), %0d accept(s); expected MEM_RET forced (no request after the last denial)",
                  mode_name(pb_status[2]), ob[2][OB_QREQ_FALLS] - f0, n_qacc[2] - a0));
    bck("DENY_FORCE", pb_devreqen[2] === 1'b0,
        $sformatf("ACC0 PPU_PWCR.DEVREQEN0 %b after the forced entry, expected 0", pb_devreqen[2]));
    $display("[%0t] tb| B6 [chk:DENY_FORCE] ACC0 held busy with deny: %0d denials, then forced to %s; hops %s; DEVREQEN0 %b",
             $time, n_qdeny[2] - q0, mode_name(pb_status[2]), hops_since(2, h0), pb_devreqen[2]);
    ck_mode(2, PM_MEM_RET);
    hold(2, 1'b0); deny(0, 1'b0);
    dp_expect("DENY_FORCE", 2, DP_ON, ST_OK, "ACC0 ON after the forced entry");
    bck("DENY_FORCE", pb_devreqen[2] === 1'b1 && pb_status[2] === PM_ON,
        $sformatf("ACC0 after ON: %s, DEVREQEN0 %b; expected ON, 1", mode_name(pb_status[2]),
                  pb_devreqen[2]));
    ck_mode(2, PM_ON);
    q0 = n_qdeny[2]; f0 = ob[2][OB_QREQ_FALLS]; a0 = n_qacc[2];
    dp_expect("DENY_FORCE", 2, DP_OFF, ST_OK, "ACC0 OFF, idle");
    cyc_wait(150_000);
    bck("DENY_FORCE", pb_status[2] === PM_MEM_RET && ob[2][OB_QREQ_FALLS] - f0 == 1 &&
                      n_qacc[2] - a0 == 1 && n_qdeny[2] - q0 == 0,
        $sformatf("ACC0 idle OFF: %s, %0d request(s), %0d accept(s), %0d denial(s); expected MEM_RET with one handshake",
                  mode_name(pb_status[2]), ob[2][OB_QREQ_FALLS] - f0, n_qacc[2] - a0, n_qdeny[2] - q0));
    $display("[%0t] tb| B6 [chk:DENY_FORCE] released: ON SUCCESS, DEVREQEN0 back to 1; the idle OFF handshook once (QREQn fall, QACCEPTn) to %s",
             $time, mode_name(pb_status[2]));
    ck_mode(2, PM_MEM_RET);
  endtask

  // ---------------------------------------------------------------------------
  // B7: ACC1's power-off misses its step deadline (hold_busy): FAULT, an ON
  // answered HW_FAULT, the hop settles, then the WARM_RST recovery
  // ---------------------------------------------------------------------------
  task automatic b7();
    logic [31:0] st; longint unsigned lat, t0;
    int unsigned f0, pw0, aw0, h0, rv0;
    bfm_step = 8'd7;
    dp_expect("FAULT", 3, DP_ON, ST_OK, "ACC1 ON");
    ck_mode(3, PM_ON);
    hold(3, 1'b1);
    f0 = n_fault_log[3];
    t0 = cyc;
    dp_set("FAULT", 3, DP_OFF, st, lat);
    bck("FAULT", st === ST_OK && lat < 20_000,
        $sformatf("ACC1 OFF held busy: status %0d after %0d cycles, expected SUCCESS at once", $signed(st), lat));
    wait_until(t0, 220_000);
    dp_set("FAULT", 3, DP_ON, st, lat);
    bck("FAULT", st === ST_HWF,
        $sformatf("ACC1 ON while its power-off is stuck: status %0d, expected RPMI_ERR_HW_FAULT (-8)", $signed(st)));
    bck("FAULT", lat >= TICKS_MS - 10_000 && lat < TICKS_MS + 50_000,
        $sformatf("the HW_FAULT came %0d cycles after the request, expected about on_ticks (%0d)", lat, TICKS_MS));
    dp_get("FAULT", 3, DP_OFF);
    bck("FAULT", n_fault_log[3] > f0, "the SCP logged no FAULT for DOMAIN_ID 3");
    bck("FAULT", pb_status[3] === PM_ON && pb_qreqn[3] === 1'b0,
        $sformatf("ACC1 %s, DEVQREQn %b: expected still ON with the request waiting", mode_name(pb_status[3]),
                  pb_qreqn[3]));
    $display("[%0t] tb| B7 [chk:FAULT] ACC1 OFF stuck (hold_busy): OFF SUCCESS at once; ON at +2.2 ms answered %0d after %0d cycles; GET_STATE OFF; SCP FAULT lines %0d",
             $time, $signed(st), lat, n_fault_log[3] - f0);
    wait_until(t0, 330_000);
    bck("FAULT_SETTLE", cyc < t0 + 410_000,
        $sformatf("the release came %0d cycles after the OFF, after the policy's next recovery attempt (+4.2 ms)",
                  cyc - t0));
    pw0 = n_polwr[3]; aw0 = n_axi_wr[3]; h0 = hop_log[3].size(); rv0 = n_recov_log[3];
    hold(3, 1'b0);
    cyc_wait(150_000);
    bck("FAULT_SETTLE", pb_status[3] === PM_OFF && hops_since(3, h0) == "OFF",
        $sformatf("ACC1 after the release: %s, hops %s; expected the stuck hop to OFF", mode_name(pb_status[3]),
                  hops_since(3, h0)));
    bck("FAULT_SETTLE", n_polwr[3] == pw0,
        $sformatf("%0d PPU_PWPR write(s) to PPU 3 after the release; the recovery should find PWPR == PWSR == OFF and write none",
                  n_polwr[3] - pw0));
    bck("FAULT_SETTLE", n_recov_log[3] > rv0, "the SCP logged no recovery for DOMAIN_ID 3");
    $display("[%0t] tb| B7 [chk:FAULT_SETTLE] released at +3.3 ms: hop to OFF; %0d PWPR writes, %0d AXI writes (event clears) since; SCP recovered lines %0d",
             $time, n_polwr[3] - pw0, n_axi_wr[3] - aw0, n_recov_log[3] - rv0);
    ck_mode(3, PM_OFF, 1'b0);
    h0 = hop_log[3].size();
    dp_expect("RECOVER", 3, DP_ON, ST_OK, "ACC1 ON after the fault");
    bck("RECOVER", hops_since(3, h0) == "ON -> WARM_RST -> ON",
        $sformatf("ACC1 hops for the ON after the fault: %s, expected ON -> WARM_RST -> ON", hops_since(3, h0)));
    $display("[%0t] tb| B7 [chk:RECOVER] ACC1 ON after the fault: SUCCESS, hops OFF -> %s (WARM_RST recovery)",
             $time, hops_since(3, h0));
    ck_mode(3, PM_ON, 1'b0);
    dp_expect("RECOVER", 3, DP_OFF, ST_OK, "ACC1 OFF");
    cyc_wait(150_000);
    ck_mode(3, PM_OFF);
  endtask

  // ---------------------------------------------------------------------------
  // B8: out-of-range DOMAIN_ID, and a state that is neither ON nor OFF
  // ---------------------------------------------------------------------------
  task automatic b8();
    int unsigned ax0 = 0, ax1 = 0;
    bit got; logic [31:0] r [8]; int unsigned rl; longint unsigned lat;
    bfm_step = 8'd8;
    for (int d = 0; d < 4; d++) ax0 += axi_n(d);
    dp_expect("BAD_ID", 4, DP_ON, ST_INVAL, "id 4");
    dp_expect("BAD_ID", 32'hFFFF_FFFF, DP_ON, ST_INVAL, "id 0xFFFFFFFF");
    rpmi_call("BAD_ID", G_DPWR, S_GET, 1, 4, 0, got, r, rl, lat);
    bck("BAD_ID", got && r[0] === ST_INVAL,
        $sformatf("GET_DPWR_STATE(4): status %0d, expected INVALID_PARAM (-3)", $signed(r[0])));
    rpmi_call("BAD_ID", G_DPWR, S_DATTR, 1, 4, 0, got, r, rl, lat);
    bck("BAD_ID", got && r[0] === ST_INVAL,
        $sformatf("GET_ATTRIBUTES(4): status %0d, expected INVALID_PARAM (-3)", $signed(r[0])));
    dp_expect("BAD_ID", 0, 32'd1, ST_INVAL, "id 0 state 1");
    for (int d = 0; d < 4; d++) ax1 += axi_n(d);
    bck("BAD_ID", ax1 == ax0, $sformatf("%0d PPU access(es) during the invalid requests", ax1 - ax0));
    $display("[%0t] tb| B8 [chk:BAD_ID] SET id 4, id 0xFFFFFFFF, GET id 4, GET_ATTRIBUTES id 4, SET id 0 state 1: INVALID_PARAM each; %0d PPU accesses",
             $time, ax1 - ax0);
  endtask

  // ---------------------------------------------------------------------------
  // B9: a request to a group that is not registered: consumed, never
  // answered; the BFM's wait times out cleanly and the next request works
  // ---------------------------------------------------------------------------
  task automatic b9();
    bit got; logic [31:0] r [8], h0, h1, head, dw [4]; int unsigned rl; longint unsigned lat;
    logic [15:0] grps [2];
    grps = '{G_SYSRST, 16'h00FF};
    dw = '{32'h0, 32'h0, 32'h0, 32'h0};
    bfm_step = 8'd9;
    foreach (grps[i]) begin
      int unsigned t = 0;
      ag_tok[0]++;
      rpmi_send(grps[i], 8'h01, ag_tok[0], 1, dw);
      forever begin
        tl_rd("NO_GROUP", AP_SOURCE, TL_QMEM, head);
        if (head === ag_tail[0] || t >= 200_000) break;
        cyc_wait(32); t += 32;
      end
      bck("NO_GROUP", head === ag_tail[0],
          $sformatf("the request to group 0x%04h was not consumed: head %0d tail %0d", grps[i], head, ag_tail[0]));
      rpmi_ack(20_000, got, h0, h1, r);
      bck("NO_GROUP", !got,
          $sformatf("group 0x%04h answered (header 0x%08h 0x%08h); expected no reply", grps[i], h0, h1));
      $display("[%0t] tb| B9 [chk:NO_GROUP] group 0x%04h: consumed (head = tail = %0d); no ACK in 20000 cycles, a clean timeout",
               $time, grps[i], head);
    end
    rpmi_call("NO_GROUP", G_DPWR, S_NDOM, 0, 0, 0, got, r, rl, lat);
    bck("NO_GROUP", got && r[0] === ST_OK && r[1] === 32'd4,
        $sformatf("GET_NUM_DOMAINS after the unanswered requests: status %0d count %0d", $signed(r[0]), r[1]));
    $display("[%0t] tb| B9 [chk:NO_GROUP] the next request (GET_NUM_DOMAINS) answered: %0d domains", $time, r[1]);
  endtask

  // ---------------------------------------------------------------------------
  // B10: the TL-UL map
  // ---------------------------------------------------------------------------
  task automatic b10();
    logic [31:0] r, rc0;
    bfm_step = 8'd10;
    rc0 = u_dut.u_mbx.ring_cnt_q[0];
    tl_wr_err("TLUL_MAP", AP_SOURCE, TL_DB + 32'h4, 32'h1);
    tl_rd("TLUL_MAP", AP_SOURCE, TL_DB, r);
    bck("TLUL_MAP", r === 32'h0, $sformatf("the doorbell reads 0x%08h, expected 0", r));
    cyc_wait(4);
    bck("TLUL_MAP", u_dut.u_mbx.ring_cnt_q[0] === rc0 && u_dut.u_mbx.ring_q[0] === 1'b0,
        $sformatf("a doorbell read or a write to +4 rang: DB_RING_CNT %0d (was %0d)", u_dut.u_mbx.ring_cnt_q[0], rc0));
    tl_rd_err("TLUL_MAP", AP_SOURCE, 32'h2000_2000);
    $display("[%0t] tb| B10 [chk:TLUL_MAP] 0x2000_1004 write: d_error; 0x2000_1000 read: 0, no ring; 0x2000_2000 read: d_error",
             $time);
  endtask

  // ---------------------------------------------------------------------------
  // B11: CPU1's power-off misses its deadline (hold_busy, deny suppressed);
  // released, the policy's recovery powers it off; the next ON reloads it
  // ---------------------------------------------------------------------------
  task automatic b11();
    logic [31:0] st; longint unsigned lat, t1;
    int unsigned h0, q0, f0, a0, fl0, rv0, ld0, bw0;
    bfm_step = 8'd11;
    bck("CPU_FAULT", pb_status[1] === PM_ON, $sformatf("CPU1 is %s at B11, expected ON (from B4)",
                                                      mode_name(pb_status[1])));
    hold(1, 1'b1);
    h0 = hop_log[1].size(); q0 = n_qdeny[1]; fl0 = n_fault_log[1];
    t1 = cyc;
    dp_expect("CPU_FAULT", 1, DP_OFF, ST_OK, "CPU1 OFF");
    wait_until(t1, 250_000);
    bck("CPU_FAULT", hop_log[1].size() == h0 && pb_status[1] === PM_ON &&
                     pb_hwstat[1] === spec_hwstat(PM_ON),
        $sformatf("CPU1 while held: hops %s, %s, PPUHWSTAT 0x%04h; expected no hop, still ON",
                  hops_since(1, h0), mode_name(pb_status[1]), pb_hwstat[1]));
    bck("CPU_FAULT", pb_qreqn[1] === 1'b0 && pb_qaccn[1] === 1'b1 && n_qdeny[1] == q0,
        $sformatf("CPU1 request: DEVQREQn %b DEVQACCEPTn %b, %0d denial(s); expected waiting in Q_REQUEST, none",
                  pb_qreqn[1], pb_qaccn[1], n_qdeny[1] - q0));
    bck("CPU_FAULT", n_fault_log[1] > fl0, "the SCP logged no FAULT for DOMAIN_ID 1");
    $display("[%0t] tb| B11 [chk:CPU_FAULT] CPU1 OFF held busy: 2.5 ms later no hop, still ON, request waiting; SCP FAULT lines %0d",
             $time, n_fault_log[1] - fl0);
    q0 = n_qdeny[1]; f0 = ob[1][OB_QREQ_FALLS]; a0 = n_qacc[1]; rv0 = n_recov_log[1];
    hold(1, 1'b0);
    cyc_wait(200_000);
    bck("CPU_FAULT_SETTLE", pb_status[1] === PM_OFF && hops_since(1, h0) == "OFF",
        $sformatf("CPU1 after the release: %s, hops %s; expected OFF", mode_name(pb_status[1]), hops_since(1, h0)));
    bck("CPU_FAULT_SETTLE", n_qdeny[1] - q0 == 1 + RETRY_CAP + 1 && n_qacc[1] - a0 == 0 &&
                            ob[1][OB_QREQ_FALLS] - f0 == RETRY_CAP + 1,
        $sformatf("CPU1 after the release: %0d denial(s), %0d new request(s), %0d accept(s); expected the stuck request denied, then %0d denied and forced",
                  n_qdeny[1] - q0, ob[1][OB_QREQ_FALLS] - f0, n_qacc[1] - a0, RETRY_CAP + 1));
    bck("CPU_FAULT_SETTLE", n_recov_log[1] > rv0, "the SCP logged no recovery for DOMAIN_ID 1");
    $display("[%0t] tb| B11 [chk:CPU_FAULT_SETTLE] released: the stuck request denied, then %0d denials and a forced power-off to %s; SCP recovered lines %0d",
             $time, n_qdeny[1] - q0 - 1, mode_name(pb_status[1]), n_recov_log[1] - rv0);
    ck_mode(1, PM_OFF, 1'b0);
    r_cpu_ram_lost("CPU_FAULT_SETTLE", 1);
    r_logic_loss(1);
    h0 = hop_log[1].size(); ld0 = n_ldwr[1]; bw0 = n_bootwr[1];
    fetch_off[1] = 1'b0;
    dp_expect("CPU_RECOVER", 1, DP_ON, ST_OK, "CPU1 ON after the fault");
    bck("CPU_RECOVER", hops_since(1, h0) == "ON -> WARM_RST -> ON",
        $sformatf("CPU1 hops for the ON: %s, expected ON -> WARM_RST -> ON (the cold path)", hops_since(1, h0)));
    bck("CPU_RECOVER", n_ldwr[1] - ld0 == 1024 && n_bootwr[1] - bw0 >= 1 && fetch_off[1] && cpu_fetch[1] === 1'b1,
        $sformatf("CPU1 reload: %0d load-port write(s), %0d CPU1_BOOT write(s), FETCH_EN went 0 %0b and is %b; expected 1024, >= 1, 1, 1",
                  n_ldwr[1] - ld0, n_bootwr[1] - bw0, fetch_off[1], cpu_fetch[1]));
    $display("[%0t] tb| B11 [chk:CPU_RECOVER] CPU1 ON: SUCCESS; hops OFF -> %s; %0d words reloaded, CPU1_BOOT written, fetch re-enabled",
             $time, hops_since(1, h0), n_ldwr[1] - ld0);
    ck_mode(1, PM_ON);                     // CPU1_RESTART: BOOT_COUNT 1, first fetch at CPU1_BOOT + 0x80
  endtask

  // ---------------------------------------------------------------------------
  // B12: the SCP's interrupt inputs (platform plan H7-H9, F10). Every input
  // type is driven and produces its table action (soc4_plat.h
  // SCP_PLAT_INPUTS): a CPU in FULL_RET and a CPU in OFF powered up by their
  // PLIC per-hart pending (level), ACC0 in MEM_RET by the GPIO wake line and
  // ACC1 in OFF by an access-gate wake (edge), RTC and BBRX recorded as wake
  // reasons, the PLIC's output notified to the policy, the debug request
  // ignored, a masked input doing nothing; level against edge held across an
  // OFF vote; the firmware's W1C; GET_STATE and librpmi's vote rule around a
  // wake vote; and the four PPUs and the doorbell delivered through the block
  // ---------------------------------------------------------------------------
  localparam int unsigned WAKE_TMO = 300_000;

  task automatic irq_drive(input int unsigned i, input bit v);
    @(negedge clk) t_irq[i] = v;
  endtask

  // HIGH for 4 cycles: two for the synchroniser and margin (scp_irq.sv)
  task automatic irq_pulse(input int unsigned i);
    irq_drive(i, 1'b1);
    repeat (3) @(negedge clk);
    t_irq[i] = 1'b0;
  endtask

  // Domain d ON and one more successful power-up logged for input i
  task automatic wake_wait(input string tag, input int unsigned d, input int unsigned i,
                           input int unsigned up0, input string what);
    int unsigned t = 0;
    while (t < WAKE_TMO && !(pb_status[d] === PM_ON && n_in_up[i] > up0)) begin
      @(posedge clk); t++;
    end
    bck(tag, pb_status[d] === PM_ON && n_in_up[i] == up0 + 1,
        $sformatf("%s: %s is %s, and the SCP logged %0d power-up(s) from input %0d after %0d cycles; expected ON and 1",
                  what, pd_name(d), mode_name(pb_status[d]), n_in_up[i] - up0, i, t));
  endtask

  // One more line of the given kind for input i, within tmo cycles
  task automatic in_wait(input int unsigned i, input int unsigned tmo,
                         ref int unsigned cnt [NUM_IN], input int unsigned c0);
    int unsigned t = 0;
    while (t < tmo && cnt[i] == c0) begin @(posedge clk); t++; end
  endtask

  function automatic int unsigned hops_all();
    int unsigned n = 0;
    for (int d = 0; d < NUM_PD; d++) n += hop_log[d].size();
    return n;
  endfunction

  task automatic b12();
    int unsigned h0, up0, s0, c0, r0, l0, ax0, hs0;
    bfm_step = 8'd12;
    $display("[%0t] tb| B12: the SCP's interrupt inputs (%0d inputs, one line into Ibex); before it: %0d BFM checks, %0d testbench checks",
             $time, NUM_IN, bfm_checks, checks);

    // ---- Where B12 starts: CPU0 FULL_RET, CPU1 OFF, ACC0 MEM_RET, ACC1 OFF.
    //      After B0-B11 only CPU1 needs moving; alone (+bfm_only=B12), all do ----
    if (pb_status[0] !== PM_FULL_RET) begin
      dp_expect("WAKE_PREP", 0, DP_ON, ST_OK, "CPU0 ON");
      ck_mode(0, PM_ON);
      dp_expect("WAKE_PREP", 0, DP_OFF, ST_OK, "CPU0 OFF");
      cyc_wait(150_000);
      ck_mode(0, PM_FULL_RET);
    end
    if (pb_status[2] !== PM_MEM_RET) begin
      dp_expect("WAKE_PREP", 2, DP_ON, ST_OK, "ACC0 ON");
      acc_fill(0, 8'h5A);
      ck_mode(2, PM_ON);
      dp_expect("WAKE_PREP", 2, DP_OFF, ST_OK, "ACC0 OFF");
      cyc_wait(150_000);
      ck_mode(2, PM_MEM_RET);
    end
    if (pb_status[1] !== PM_OFF) begin
      dp_expect("WAKE_PREP", 1, DP_OFF, ST_OK, "CPU1 OFF");
      cyc_wait(220_000);
      ck_mode(1, PM_OFF);
    end
    if (pb_status[3] !== PM_OFF) begin
      dp_expect("WAKE_PREP", 3, DP_OFF, ST_OK, "ACC1 OFF");
      cyc_wait(150_000);
      ck_mode(3, PM_OFF);
    end

    // ---- (a) A CPU in its low-power mode powered up by a PLIC per-hart
    //      pending input; GET_STATE and librpmi's vote rule around the wake vote ----
    h0 = hop_log[0].size(); up0 = n_in_up[IN_H0]; s0 = in_set[IN_H0];
    irq_drive(IN_H0, 1'b1);
    wake_wait("WAKE_PLIC", 0, IN_H0, up0, "PLIC hart-0 pending (level)");
    bck("WAKE_PLIC", hops_since(0, h0) == "ON" && in_set[IN_H0] - s0 == 1,
        $sformatf("CPU0 hops %s, input %0d set PENDING %0d time(s); expected FULL_RET -> ON, once",
                  hops_since(0, h0), IN_H0, in_set[IN_H0] - s0));
    ck_mode(0, PM_ON);                     // FULLRET_REGS: resumed, not rebooted
    $display("[%0t] tb| B12 [chk:WAKE_PLIC] PLIC hart-0 pending: CPU0 FULL_RET -> ON (warm resume): \"%s\"",
             $time, in_last[IN_H0]);
    irq_drive(IN_H0, 1'b0);                // the hart has claimed its interrupt
    cyc_wait(5000);
    dp_get("WAKE_VOTE", 0, DP_ON);
    ax0 = axi_n(0);
    dp_expect("WAKE_VOTE", 0, DP_ON, ST_OK, "CPU0 ON while the wake vote holds");
    bck("WAKE_VOTE", axi_n(0) == ax0,
        $sformatf("the agent's ON matching GET_STATE made %0d PPU 0 access(es); librpmi should answer it alone",
                  axi_n(0) - ax0));
    dp_expect("WAKE_VOTE", 0, DP_OFF, ST_OK, "CPU0 OFF ends the wake vote");
    cyc_wait(150_000);
    ck_mode(0, PM_FULL_RET);
    dp_get("WAKE_VOTE", 0, DP_OFF);
    $display("[%0t] tb| B12 [chk:WAKE_VOTE] after the wake GET_STATE(0) = ON; the agent's ON answered with no PPU access; its OFF taken: FULL_RET, GET_STATE OFF",
             $time);

    // ---- (b) A wake line (edge) powers ACC0 up from MEM_RET; held HIGH across
    //      the OFF it does nothing more; the W1C cleared PENDING with it HIGH ----
    h0 = hop_log[2].size(); up0 = n_in_up[IN_GPIO]; s0 = in_set[IN_GPIO]; c0 = in_clr[IN_GPIO];
    irq_drive(IN_GPIO, 1'b1);              // and held
    wake_wait("WAKE_EDGE", 2, IN_GPIO, up0, "GPIO wake (edge)");
    ck_mode(2, PM_ON);                     // MEMRET_RAM: the banks kept
    bck("IRQ_W1C", blk_raw[IN_GPIO] === 1'b1 && blk_pend[IN_GPIO] === 1'b0 &&
                   in_set[IN_GPIO] - s0 == 1 && in_clr[IN_GPIO] - c0 == 1,
        $sformatf("GPIO input: RAW %b PENDING %b, set %0d cleared %0d; expected the edge's PENDING cleared once by the W1C while the line is HIGH",
                  blk_raw[IN_GPIO], blk_pend[IN_GPIO], in_set[IN_GPIO] - s0, in_clr[IN_GPIO] - c0));
    dp_get("WAKE_VOTE", 2, DP_ON);
    dp_expect("WAKE_EDGE", 2, DP_OFF, ST_OK, "ACC0 OFF with GPIO still HIGH");
    cyc_wait(150_000);
    bck("WAKE_EDGE", pb_status[2] === PM_MEM_RET && blk_raw[IN_GPIO] === 1'b1 &&
                     n_in_up[IN_GPIO] - up0 == 1 && in_set[IN_GPIO] - s0 == 1,
        $sformatf("GPIO held HIGH across the OFF: ACC0 %s, %0d power-up(s), PENDING set %0d time(s); expected MEM_RET, 1, 1 (edge)",
                  mode_name(pb_status[2]), n_in_up[IN_GPIO] - up0, in_set[IN_GPIO] - s0));
    ck_mode(2, PM_MEM_RET);
    irq_drive(IN_GPIO, 1'b0);
    $display("[%0t] tb| B12 [chk:WAKE_EDGE] GPIO (edge): ACC0 MEM_RET -> ON, hops %s; held HIGH across the OFF: MEM_RET, no second event; [chk:IRQ_W1C] PENDING cleared with the line HIGH",
             $time, hops_since(2, h0));

    // ---- (c) Level: CPU1 in OFF powered up by its PLIC pending; held HIGH
    //      across the OFF vote, the re-armed level powers it straight back ----
    up0 = n_in_up[IN_H1]; s0 = in_set[IN_H1]; r0 = in_rise[IN_H1];
    irq_drive(IN_H1, 1'b1);                // and held
    wake_wait("WAKE_LEVEL", 1, IN_H1, up0, "PLIC hart-1 pending (level)");
    ck_mode(1, PM_ON);                     // CPU1_RESTART: the cold boot
    h0 = hop_log[1].size();
    dp_get("WAKE_VOTE", 1, DP_ON);
    dp_expect("WAKE_LEVEL", 1, DP_OFF, ST_OK, "CPU1 OFF with its pending still HIGH");
    cyc_wait(250_000);
    bck("WAKE_LEVEL", pb_status[1] === PM_ON && hop_log[1].size() == h0 &&
                      n_in_up[IN_H1] - up0 == 2 && in_set[IN_H1] - s0 == 2 && in_rise[IN_H1] - r0 == 1,
        $sformatf("PLIC hart-1 held HIGH across the OFF: CPU1 %s, hops %s, %0d power-up(s), PENDING set %0d time(s) for %0d rising edge(s); expected ON, none, 2, 2, 1 (level)",
                  mode_name(pb_status[1]), hops_since(1, h0), n_in_up[IN_H1] - up0, in_set[IN_H1] - s0,
                  in_rise[IN_H1] - r0));
    dp_get("WAKE_VOTE", 1, DP_ON);
    irq_drive(IN_H1, 1'b0);
    dp_expect("WAKE_LEVEL", 1, DP_OFF, ST_OK, "CPU1 OFF, its pending LOW");
    cyc_wait(220_000);
    ck_mode(1, PM_OFF);
    $display("[%0t] tb| B12 [chk:WAKE_LEVEL] PLIC hart-1 (level): CPU1 OFF -> ON (cold boot); held HIGH, the OFF vote re-armed it and it powered CPU1 back (2 power-ups, 1 edge); LOW: OFF",
             $time);

    // ---- (d) An access gate's wake request (edge pulse) powers ACC1 up ----
    up0 = n_in_up[IN_ACG0];
    irq_pulse(IN_ACG0);
    wake_wait("WAKE_ACG", 3, IN_ACG0, up0, "access-gate wake (edge pulse)");
    ck_mode(3, PM_ON);
    dp_get("WAKE_VOTE", 3, DP_ON);
    dp_expect("WAKE_ACG", 3, DP_OFF, ST_OK, "ACC1 OFF");
    cyc_wait(150_000);
    ck_mode(3, PM_OFF);
    $display("[%0t] tb| B12 [chk:WAKE_ACG] access-gate wake: ACC1 OFF -> ON: \"%s\"", $time, in_last[IN_ACG0]);

    // ---- (e) RTC and BBRX (edge): wake reasons 1 and 2, nothing powered ----
    for (int k = 0; k < 2; k++) begin
      automatic int unsigned i = (k == 0) ? IN_RTC : IN_BBRX;
      r0 = n_in_reason[i]; hs0 = hops_all(); s0 = in_set[i];
      irq_pulse(i);
      in_wait(i, 50_000, n_in_reason, r0);
      bck("WAKE_REASON", n_in_reason[i] - r0 == 1 && has(in_last[i], $sformatf("wake reason %0d recorded", k + 1)) &&
                         hops_all() == hs0 && in_set[i] - s0 == 1 && blk_pend[i] === 1'b0,
          $sformatf("input %0d: %0d reason line(s) (last \"%s\"), %0d hop(s), PENDING set %0d now %b; expected 1 with reason %0d, no hop, 1, 0",
                    i, n_in_reason[i] - r0, in_last[i], hops_all() - hs0, in_set[i] - s0, blk_pend[i], k + 1));
    end
    $display("[%0t] tb| B12 [chk:WAKE_REASON] RTC: \"%s\"; BBRX: \"%s\"; no domain moved", $time,
             in_last[IN_RTC], in_last[IN_BBRX]);

    // ---- (f) The SoC PLIC's output (level): the policy notified once while
    //      HIGH, re-armed once seen LOW, notified again ----
    r0 = n_in_notify[IN_PLIC]; s0 = in_set[IN_PLIC]; hs0 = hops_all();
    irq_drive(IN_PLIC, 1'b1);
    in_wait(IN_PLIC, 50_000, n_in_notify, r0);
    cyc_wait(30_000);
    bck("NOTIFY", n_in_notify[IN_PLIC] - r0 == 1 && in_set[IN_PLIC] - s0 == 1 && blk_en[IN_PLIC] === 1'b0,
        $sformatf("PLIC held HIGH 30000 cycles: %0d notification(s), PENDING set %0d, ENABLE %b; expected 1, 1, 0 (masked until LOW)",
                  n_in_notify[IN_PLIC] - r0, in_set[IN_PLIC] - s0, blk_en[IN_PLIC]));
    irq_drive(IN_PLIC, 1'b0);
    cyc_wait(5000);
    bck("NOTIFY", blk_en[IN_PLIC] === 1'b1, "the PLIC input was not re-armed 5000 cycles after going LOW");
    irq_drive(IN_PLIC, 1'b1);
    in_wait(IN_PLIC, 50_000, n_in_notify, r0 + 1);
    irq_drive(IN_PLIC, 1'b0);
    bck("NOTIFY", n_in_notify[IN_PLIC] - r0 == 2 && hops_all() == hs0,
        $sformatf("PLIC raised again: %0d notification(s) in all, %0d hop(s); expected 2, none",
                  n_in_notify[IN_PLIC] - r0, hops_all() - hs0));
    $display("[%0t] tb| B12 [chk:NOTIFY] SoC PLIC output: notified once while HIGH, re-armed when LOW, notified again: \"%s\"",
             $time, in_last[IN_PLIC]);

    // ---- (g) The debug power request (level): ignored ----
    r0 = n_in_ignored[IN_DBG]; hs0 = hops_all();
    irq_drive(IN_DBG, 1'b1);
    in_wait(IN_DBG, 50_000, n_in_ignored, r0);
    irq_drive(IN_DBG, 1'b0);
    cyc_wait(5000);
    bck("IGNORE", n_in_ignored[IN_DBG] - r0 == 1 && hops_all() == hs0 && blk_en[IN_DBG] === 1'b1,
        $sformatf("debug request: %0d ignored line(s), %0d hop(s), ENABLE %b after LOW; expected 1, none, 1",
                  n_in_ignored[IN_DBG] - r0, hops_all() - hs0, blk_en[IN_DBG]));
    $display("[%0t] tb| B12 [chk:IGNORE] debug power request: \"%s\"; re-armed when LOW", $time, in_last[IN_DBG]);

    // ---- (h) A masked input does nothing: ACG1 (en = 0), whose action would
    //      power CPU1 up ----
    r0 = in_rise[IN_ACG1]; s0 = in_set[IN_ACG1]; l0 = n_in_line[IN_ACG1]; h0 = hop_log[1].size();
    irq_pulse(IN_ACG1);
    cyc_wait(50_000);
    bck("IRQ_MASK", in_rise[IN_ACG1] - r0 == 1 && in_set[IN_ACG1] == s0 && blk_en[IN_ACG1] === 1'b0 &&
                    n_in_line[IN_ACG1] == l0 && pb_status[1] === PM_OFF && hop_log[1].size() == h0,
        $sformatf("masked ACG1 pulsed: RAW rose %0d, PENDING set %0d, ENABLE %b, %0d SCP line(s), CPU1 %s, hops %s; expected 1, 0, 0, 0, OFF, none",
                  in_rise[IN_ACG1] - r0, in_set[IN_ACG1] - s0, blk_en[IN_ACG1], n_in_line[IN_ACG1] - l0,
                  mode_name(pb_status[1]), hops_since(1, h0)));
    $display("[%0t] tb| B12 [chk:IRQ_MASK] masked ACG1: seen at RAW, no PENDING, no action, CPU1 still OFF", $time);

    // ---- (i) The four PPUs' interrupts and the doorbell came through the
    //      block, every one serviced; no Ibex fast line ever moved ----
    cyc_wait(5000);
    for (int d = 0; d < NUM_PD; d++)
      bck("IRQ_PPU", in_set[d] > 0 && pb_irq[d] === 1'b0 && blk_pend[d] === 1'b0 && blk_en[d] === 1'b1,
          $sformatf("%s's interrupt: PENDING set %0d time(s) for %0d IRQ rise(s); now IRQ %b PENDING %b ENABLE %b; expected > 0, serviced, re-armed",
                    pd_name(d), in_set[d], n_irq[d], pb_irq[d], blk_pend[d], blk_en[d]));
    bck("IRQ_PPU", in_set[IN_DB] > 0 && n_fast_hi == 0 && n_line > 0,
        $sformatf("doorbell PENDING set %0d time(s); Ibex fast lines HIGH for %0d cycle(s); block line rose %0d time(s)",
                  in_set[IN_DB], n_fast_hi, n_line));
    $display("[%0t] tb| B12 [chk:IRQ_PPU] through the block: PPU inputs set %0d %0d %0d %0d times (IRQ rises %0d %0d %0d %0d), doorbell %0d; line into Ibex rose %0d times; fast lines never HIGH",
             $time, in_set[0], in_set[1], in_set[2], in_set[3], n_irq[0], n_irq[1], n_irq[2], n_irq[3],
             in_set[IN_DB], n_line);
  endtask

  // ---------------------------------------------------------------------------
  // R0 and R1: the second agent (platform plan PD6, H11-H13, F6; V3). The RPU
  // stand-in is the BFM on mailbox port 1, agent 1: its window at 0x2000_2000,
  // its doorbell at 0x2000_3000 (RING[1], SCP input 14), its source IDs
  // 0x20-0x23 (FW_VAL 0x20, FW_MASK 0xFC). The domain table lets it vote for
  // ACC0 and ACC1 only (soc4_plat.h).
  // ---------------------------------------------------------------------------
  function automatic logic [31:0] qmem_k(input int unsigned k, input int unsigned w);
    return u_dut.u_mbx.u_qmem.sram[k * 256 + w];
  endfunction

  function automatic int unsigned axi_all();
    int unsigned n = 0;
    for (int d = 0; d < NUM_PD; d++) n += axi_n(d);
    return n;
  endfunction

  // Cycles in which both agents had a request in flight (R1's concurrency)
  int unsigned n_both = 0;
  always @(posedge clk) if (ag_busy[0] && ag_busy[1]) n_both++;

  // R0: the SCP held in reset -- the RPU's window denies everything too
  task automatic r0();
    logic [31:0] qm [256];
    int unsigned changed = 0;
    logic [31:0] dc0;
    logic [7:0] srcs [3];
    srcs = '{RPU_SOURCE, RPU_SOURCE | 8'h03, AP_SOURCE};
    bfm_step = 8'h20;
    $display("[%0t] tb| R0: the SCP held in reset: every access to the RPU's window (port 1) must be denied too",
             $time);
    bck("AG_RESET_DENY", scp_rst_n === 1'b0, "the SCP is not held in reset at R0 (+scp_hold)");
    for (int w = 0; w < 256; w++) qm[w] = qmem_k(1, w);
    dc0 = u_dut.u_mbx.deny_cnt_q[0];
    foreach (srcs[i]) begin
      tl_wr_err("AG_RESET_DENY", srcs[i], ag_win(1) + 32'h1000, 32'h1, 1);
      tl_wr_err("AG_RESET_DENY", srcs[i], ag_win(1), 32'hA5A5_0100 | srcs[i], 1);
      tl_rd_err("AG_RESET_DENY", srcs[i], ag_win(1) + 32'h40, 1);
    end
    cyc_wait(4);
    for (int w = 0; w < 256; w++) if (qmem_k(1, w) !== qm[w]) changed++;
    bck("AG_RESET_DENY", u_dut.u_mbx.ring_q === 2'b00 && u_dut.db_irq === 2'b00 &&
                         u_dut.u_mbx.ring_cnt_q[1] === 32'd0,
        $sformatf("a denied access rang: RING %b, doorbell inputs %b, RING_CNT[1] %0d",
                  u_dut.u_mbx.ring_q, u_dut.db_irq, u_dut.u_mbx.ring_cnt_q[1]));
    bck("AG_RESET_DENY", changed == 0,
        $sformatf("%0d word(s) of window 1 changed by denied accesses", changed));
    bck("AG_RESET_DENY", u_dut.u_mbx.deny_cnt_q[1] === 32'd9 && u_dut.u_mbx.deny_cnt_q[0] === dc0,
        $sformatf("DENY_CNT[1] %0d, expected 9; DENY_CNT[0] %0d, was %0d", u_dut.u_mbx.deny_cnt_q[1],
                  u_dut.u_mbx.deny_cnt_q[0], dc0));
    bck("AG_RESET_DENY", u_dut.u_mbx.fw_last_q === {4'd1, 6'd0, 1'b1, 1'b1, AP_SOURCE} &&
                         u_dut.u_mbx.fw_en_q === 2'b00,
        $sformatf("FW_LAST 0x%05h, expected 0x%05h (transport 1, FW_EN was 0, source 0x%02h); FW_EN %b",
                  u_dut.u_mbx.fw_last_q, {4'd1, 6'd0, 1'b1, 1'b1, AP_SOURCE}, AP_SOURCE, u_dut.u_mbx.fw_en_q));
    bck("AG_RESET_DENY", scp_rst_n === 1'b0, "the SCP left reset during R0: +scp_hold too short");
    $display("[%0t] tb| R0 [chk:AG_RESET_DENY] 9 accesses to window 1 (sources 0x%02h, 0x%02h, 0x%02h) denied; DENY_CNT[1] %0d, FW_LAST 0x%05h, no ring, window 1 unchanged",
             $time, srcs[0], srcs[1], srcs[2], u_dut.u_mbx.deny_cnt_q[1], u_dut.u_mbx.fw_last_q);
  endtask

  // R1's discovery on agent k's own transport
  task automatic ag_discover(input int unsigned k);
    bit got; logic [31:0] r [8]; int unsigned rl; longint unsigned lat;
    string names [4];
    names = '{"CPU0", "CPU1", "ACC0", "ACC1"};
    rpmi_call("AG_DISCOVER", G_BASE, S_SPEC, 0, 0, 0, got, r, rl, lat, k);
    bck("AG_DISCOVER", got && rl == 8 && r[0] === ST_OK && r[1] === VER_1_0,
        $sformatf("agent %0d GET_SPEC_VERSION: length %0d status %0d version 0x%08h", k, rl, $signed(r[0]), r[1]));
    rpmi_call("AG_DISCOVER", G_BASE, S_IVER, 0, 0, 0, got, r, rl, lat, k);
    bck("AG_DISCOVER", got && rl == 8 && r[0] === ST_OK && r[1] === VER_1_0,
        $sformatf("agent %0d GET_IMPLEMENTATION_VERSION: length %0d status %0d 0x%08h", k, rl, $signed(r[0]), r[1]));
    rpmi_call("AG_DISCOVER", G_BASE, S_PROBE, 1, G_BASE, 0, got, r, rl, lat, k);
    bck("AG_DISCOVER", got && r[0] === ST_OK && r[1] !== 32'd0,
        $sformatf("agent %0d PROBE_SERVICE_GROUP(BASE): status %0d version 0x%08h", k, $signed(r[0]), r[1]));
    rpmi_call("AG_DISCOVER", G_BASE, S_PROBE, 1, G_DPWR, 0, got, r, rl, lat, k);
    bck("AG_DISCOVER", got && r[0] === ST_OK && r[1] !== 32'd0,
        $sformatf("agent %0d PROBE_SERVICE_GROUP(DEVICE_POWER): status %0d version 0x%08h", k, $signed(r[0]), r[1]));
    rpmi_call("AG_DISCOVER", G_BASE, S_PROBE, 1, G_SYSRST, 0, got, r, rl, lat, k);
    bck("AG_DISCOVER", got && r[0] === ST_OK && r[1] === 32'd0,
        $sformatf("agent %0d PROBE_SERVICE_GROUP(SYSTEM_RESET): status %0d version 0x%08h, expected absent (0)",
                  k, $signed(r[0]), r[1]));
    rpmi_call("AG_DISCOVER", G_BASE, S_BATTR, 0, 0, 0, got, r, rl, lat, k);
    bck("AG_DISCOVER", got && rl == 20 && r[0] === ST_OK && (r[1] & F0_PRIV) != 0,
        $sformatf("agent %0d BASE GET_ATTRIBUTES: length %0d status %0d flags 0x%08h (M-mode context)",
                  k, rl, $signed(r[0]), r[1]));
    rpmi_call("AG_DISCOVER", G_DPWR, S_NDOM, 0, 0, 0, got, r, rl, lat, k);
    bck("AG_DISCOVER", got && rl == 8 && r[0] === ST_OK && r[1] === 32'd4,
        $sformatf("agent %0d GET_NUM_DOMAINS: length %0d status %0d count %0d", k, rl, $signed(r[0]), r[1]));
    for (int id = 0; id < 4; id++) begin
      string nm;
      rpmi_call("AG_DISCOVER", G_DPWR, S_DATTR, 1, id, 0, got, r, rl, lat, k);
      nm = "";
      for (int b = 0; b < 4; b++) nm = {nm, string'(r[3][8*b +: 8])};
      bck("AG_DISCOVER", got && rl == 28 && r[0] === ST_OK && nm == names[id],
          $sformatf("agent %0d GET_ATTRIBUTES(%0d): length %0d status %0d name \"%s\", expected \"%s\"",
                    k, id, rl, $signed(r[0]), nm, names[id]));
    end
  endtask

  // GET_DPWR_STATE refused: status only
  task automatic dp_get_err(input string tag, input logic [31:0] id, input logic [31:0] want,
                            input int unsigned k);
    bit got; logic [31:0] r [8]; int unsigned rl; longint unsigned lat;
    rpmi_call(tag, G_DPWR, S_GET, 1, id, 32'h0, got, r, rl, lat, k);
    bck(tag, got && r[0] === want,
        $sformatf("GET_DPWR_STATE(%0d) from agent %0d: status %0d, expected %0d", id, k,
                  $signed(r[0]), $signed(want)));
  endtask

  // One agent's share of R1's concurrent traffic: n rounds of reads, each
  // answer checked against what that agent alone may see
  task automatic ag_traffic(input int unsigned k, input int unsigned n, input int unsigned own);
    bit got; logic [31:0] r [8]; int unsigned rl; longint unsigned lat;
    string names [4];
    names = '{"CPU0", "CPU1", "ACC0", "ACC1"};
    for (int i = 0; i < n; i++) begin
      automatic int unsigned id = (i + k) % 4;
      string nm;
      rpmi_call("AG_CONCURRENT", G_DPWR, S_DATTR, 1, id, 0, got, r, rl, lat, k);
      nm = "";
      for (int b = 0; b < 4; b++) nm = {nm, string'(r[3][8*b +: 8])};
      bck("AG_CONCURRENT", got && rl == 28 && r[0] === ST_OK && nm == names[id],
          $sformatf("agent %0d round %0d GET_ATTRIBUTES(%0d): status %0d name \"%s\"", k, i, id,
                    $signed(r[0]), nm));
      rpmi_call("AG_CONCURRENT", G_DPWR, S_GET, 1, own, 0, got, r, rl, lat, k);
      bck("AG_CONCURRENT", got && rl == 8 && r[0] === ST_OK && r[1] === DP_ON,
          $sformatf("agent %0d round %0d GET_DPWR_STATE(%0d): length %0d status %0d state %0d, expected its own ON",
                    k, i, own, rl, $signed(r[0]), r[1]));
      rpmi_call("AG_CONCURRENT", G_DPWR, S_GET, 1, (own == 2) ? 3 : 2, 0, got, r, rl, lat, k);
      bck("AG_CONCURRENT", got && rl == 8 && r[0] === ST_OK && r[1] === DP_OFF,
          $sformatf("agent %0d round %0d GET_DPWR_STATE(%0d): length %0d status %0d state %0d, expected its own OFF",
                    k, i, (own == 2) ? 3 : 2, rl, $signed(r[0]), r[1]));
    end
  endtask

  // R1: two agents
  task automatic r1();
    logic [31:0] v [4], r, w0, w1, dc0, dc1, rc0, rc1;
    logic [31:0] st;
    longint unsigned lat;
    int unsigned ax0, h0, h1, up0, s0, both0;
    localparam logic [31:0] SPARE = 32'h1C0;         // A2P slot 7, never used (6 messages)
    bfm_step = 8'h21;
    $display("[%0t] tb| R1: two agents, the AP (port 0) and the RPU (port 1); before it: %0d BFM checks, %0d testbench checks",
             $time, bfm_checks, checks);

    // ---- (a) The RPU's transport is initialised; both agents discover BASE
    //      and DEVICE_POWER, each on its own transport ----
    s0 = in_set[IN_DB1];
    tl_rd("AG_DISCOVER", RPU_SOURCE, ag_win(1) + 32'h000, v[0], 1);
    tl_rd("AG_DISCOVER", RPU_SOURCE, ag_win(1) + 32'h040, v[1], 1);
    tl_rd("AG_DISCOVER", RPU_SOURCE, ag_win(1) + 32'h200, v[2], 1);
    tl_rd("AG_DISCOVER", RPU_SOURCE, ag_win(1) + 32'h240, v[3], 1);
    bck("AG_DISCOVER", v[0] === 0 && v[1] === 0 && v[2] === 0 && v[3] === 0,
        $sformatf("window 1: A2P head/tail %0d/%0d, P2A head/tail %0d/%0d, all must be 0", v[0], v[1], v[2], v[3]));
    ag_tail[1] = '0; ag_head[1] = '0;
    ag_discover(1);
    ag_discover(0);
    bck("AG_DISCOVER", in_set[IN_DB1] > s0 && blk_pend[IN_DB1] === 1'b0,
        $sformatf("the RPU's doorbell (input %0d): PENDING set %0d time(s), now %b; expected > 0, serviced",
                  IN_DB1, in_set[IN_DB1] - s0, blk_pend[IN_DB1]));
    $display("[%0t] tb| R1 [chk:AG_DISCOVER] each agent on its own transport: BASE v1.0, DEVICE_POWER present, SYSTEM_RESET absent, 4 domains; the RPU's doorbell through input %0d (%0d times)",
             $time, IN_DB1, in_set[IN_DB1] - s0);

    // ---- (b) The firewall per transport: one agent's source never reaches
    //      the other's window; a port decodes only its own agents' windows;
    //      no TL-UL path reaches the SCP's registers ----
    w0 = qmem_k(0, SPARE / 4); w1 = qmem_k(1, SPARE / 4);
    dc0 = u_dut.u_mbx.deny_cnt_q[0]; dc1 = u_dut.u_mbx.deny_cnt_q[1];
    rc0 = u_dut.u_mbx.ring_cnt_q[0]; rc1 = u_dut.u_mbx.ring_cnt_q[1];
    tl_wr_err("FW_AGENT", RPU_SOURCE, TL_DB, 32'h1, 0);               // the RPU's source on the AP's window
    tl_wr_err("FW_AGENT", RPU_SOURCE, ag_win(0) + SPARE, 32'hBAD0_0020, 0);
    tl_rd_err("FW_AGENT", RPU_SOURCE, ag_win(0) + SPARE, 0);
    cyc_wait(4);
    bck("FW_AGENT", u_dut.u_mbx.deny_cnt_q[0] === dc0 + 3 &&
                    u_dut.u_mbx.fw_last_q === {4'd0, 6'd0, 1'b0, 1'b1, RPU_SOURCE},
        $sformatf("the RPU's source on window 0: DENY_CNT[0] %0d (was %0d), FW_LAST 0x%05h; expected +3 and 0x001%02h",
                  u_dut.u_mbx.deny_cnt_q[0], dc0, u_dut.u_mbx.fw_last_q, RPU_SOURCE));
    tl_wr_err("FW_AGENT", AP_SOURCE, ag_win(1) + 32'h1000, 32'h1, 1); // the AP's source on the RPU's window
    tl_wr_err("FW_AGENT", AP_SOURCE, ag_win(1) + SPARE, 32'hBAD0_0010, 1);
    tl_rd_err("FW_AGENT", AP_SOURCE, ag_win(1) + SPARE, 1);
    cyc_wait(4);
    bck("FW_AGENT", u_dut.u_mbx.deny_cnt_q[1] === dc1 + 3 &&
                    u_dut.u_mbx.fw_last_q === {4'd1, 6'd0, 1'b0, 1'b1, AP_SOURCE},
        $sformatf("the AP's source on window 1: DENY_CNT[1] %0d (was %0d), FW_LAST 0x%05h; expected +3 and 0x101%02h",
                  u_dut.u_mbx.deny_cnt_q[1], dc1, u_dut.u_mbx.fw_last_q, AP_SOURCE));
    // Through the wrong port, with the right source: no such window there
    tl_wr_err("FW_AGENT", RPU_SOURCE, ag_win(0) + SPARE, 32'hBAD1_0020, 1);
    tl_wr_err("FW_AGENT", RPU_SOURCE, TL_DB, 32'h1, 1);
    tl_wr_err("FW_AGENT", AP_SOURCE, ag_win(1) + SPARE, 32'hBAD1_0010, 0);
    tl_wr_err("FW_AGENT", AP_SOURCE, ag_win(1) + 32'h1000, 32'h1, 0);
    // The SCP's mailbox registers and queue memory have no TL-UL address
    tl_rd_err("FW_AGENT", RPU_SOURCE, 32'h0002_2000, 1);
    tl_wr_err("FW_AGENT", RPU_SOURCE, 32'h0002_2100, 32'h0, 1);
    tl_rd_err("FW_AGENT", AP_SOURCE, 32'h0002_4000, 0);
    cyc_wait(4);
    // RING_CNT counts every accepted doorbell write; RING itself may still
    // hold the last legitimate ring, which the SCP clears on its next pass.
    bck("FW_AGENT", qmem_k(0, SPARE / 4) === w0 && qmem_k(1, SPARE / 4) === w1 &&
                    u_dut.u_mbx.ring_cnt_q[0] === rc0 && u_dut.u_mbx.ring_cnt_q[1] === rc1,
        $sformatf("refused accesses had an effect: spare words 0x%08h 0x%08h (were 0x%08h 0x%08h), RING_CNT %0d %0d (were %0d %0d)",
                  qmem_k(0, SPARE / 4), qmem_k(1, SPARE / 4), w0, w1,
                  u_dut.u_mbx.ring_cnt_q[0], u_dut.u_mbx.ring_cnt_q[1], rc0, rc1));
    bck("FW_AGENT", u_dut.u_mbx.deny_cnt_q[0] === dc0 + 3 && u_dut.u_mbx.deny_cnt_q[1] === dc1 + 3,
        $sformatf("DENY_CNT %0d %0d: the wrong-port and SCP-address accesses are decode errors, not denials (expected %0d %0d)",
                  u_dut.u_mbx.deny_cnt_q[0], u_dut.u_mbx.deny_cnt_q[1], dc0 + 3, dc1 + 3));
    $display("[%0t] tb| R1 [chk:FW_AGENT] RPU source on window 0 and AP source on window 1: 3 + 3 denied, counted per transport (FW_LAST names it); the other agent's window through either port and the SCP's addresses: d_error; no ring, no write",
             $time);

    // ---- (c) Value + mask (H12): the RPU's range 0x20-0x23 admitted,
    //      neighbours outside the mask denied ----
    bck("FW_MASK", u_dut.u_mbx.fw_en_q === 2'b11 &&
                   u_dut.u_mbx.fw_val_q[0] === AP_SOURCE  && u_dut.u_mbx.fw_mask_q[0] === 8'hFF &&
                   u_dut.u_mbx.fw_val_q[1] === RPU_SOURCE && u_dut.u_mbx.fw_mask_q[1] === RPU_MASK,
        $sformatf("firewall entries: FW_EN %b, agent 0 0x%02h/0x%02h, agent 1 0x%02h/0x%02h; expected 11, 0x%02h/0xFF, 0x%02h/0x%02h",
                  u_dut.u_mbx.fw_en_q, u_dut.u_mbx.fw_val_q[0], u_dut.u_mbx.fw_mask_q[0],
                  u_dut.u_mbx.fw_val_q[1], u_dut.u_mbx.fw_mask_q[1], AP_SOURCE, RPU_SOURCE, RPU_MASK));
    for (int i = 0; i < 2; i++) begin
      automatic logic [7:0] src = (i == 0) ? 8'h21 : 8'h23;
      tl_wr("FW_MASK", src, ag_win(1) + SPARE, {24'h600D_00, src}, 4'hF, 1);
      tl_rd("FW_MASK", src, ag_win(1) + SPARE, r, 1);
      bck("FW_MASK", r === {24'h600D_00, src} && qmem_k(1, SPARE / 4) === {24'h600D_00, src},
          $sformatf("source 0x%02h (inside 0x20/0xFC): read 0x%08h, array 0x%08h", src, r, qmem_k(1, SPARE / 4)));
    end
    w1 = qmem_k(1, SPARE / 4); dc1 = u_dut.u_mbx.deny_cnt_q[1];
    for (int i = 0; i < 3; i++) begin
      automatic logic [7:0] src = (i == 0) ? 8'h24 : (i == 1) ? 8'h1F : 8'hA0;
      tl_wr_err("FW_MASK", src, ag_win(1) + SPARE, 32'hBAD2_0000 | src, 1);
      tl_rd_err("FW_MASK", src, ag_win(1) + SPARE, 1);
    end
    cyc_wait(4);
    bck("FW_MASK", qmem_k(1, SPARE / 4) === w1 && u_dut.u_mbx.deny_cnt_q[1] === dc1 + 6,
        $sformatf("sources 0x24, 0x1F, 0xA0 (outside): array 0x%08h (was 0x%08h), DENY_CNT[1] %0d, expected %0d",
                  qmem_k(1, SPARE / 4), w1, u_dut.u_mbx.deny_cnt_q[1], dc1 + 6));
    tl_wr("FW_MASK", RPU_SOURCE, ag_win(1) + SPARE, 32'h0, 4'hF, 1);
    $display("[%0t] tb| R1 [chk:FW_MASK] window 1 (0x%02h/0x%02h): sources 0x21, 0x23 admitted (write, read back); 0x24, 0x1F, 0xA0 denied, no write, 6 counted",
             $time, RPU_SOURCE, RPU_MASK);

    // ---- (d) Permissions (F6): the RPU may not vote for CPU0 or CPU1 ----
    ax0 = axi_all(); h0 = hops_all();
    dp_expect("PERM", 0, DP_ON,  ST_DENY, "the RPU asks CPU0 ON", 1);
    dp_expect("PERM", 1, DP_ON,  ST_DENY, "the RPU asks CPU1 ON", 1);
    dp_expect("PERM", 0, DP_OFF, ST_DENY, "the RPU asks CPU0 OFF", 1);
    dp_get_err("PERM", 0, ST_DENY, 1);
    dp_get_err("PERM", 1, ST_DENY, 1);
    bck("PERM", axi_all() == ax0 && hops_all() == h0,
        $sformatf("the refused requests made %0d PPU access(es) and %0d hop(s); expected none",
                  axi_all() - ax0, hops_all() - h0));
    dp_get("PERM", 0, DP_OFF, 0);                // the AP's vote is its own, untouched
    dp_get("PERM", 1, DP_OFF, 0);
    $display("[%0t] tb| R1 [chk:PERM] the RPU's SET CPU0 ON, CPU1 ON, CPU0 OFF and GET CPU0, CPU1: RPMI_ERR_DENIED (-4) each; %0d PPU accesses, %0d hops",
             $time, axi_all() - ax0, hops_all() - h0);

    // ---- (e) Votes combine (F6): ON while either agent votes ON, the
    //      low-power mode only when both vote OFF; GET_STATE is the caller's
    //      own vote. ACC0: the RPU first; ACC1: the AP first ----
    for (int j = 0; j < 2; j++) begin
      automatic int unsigned d = 2 + j;
      automatic int unsigned a = (j == 0) ? 1 : 0;      // first to vote ON
      automatic int unsigned b = 1 - a;
      dp_expect("VOTE", d, DP_ON, ST_OK, $sformatf("%s ON from agent %0d", pd_name(d), a), a);
      acc_fill(j, (j == 0) ? 8'h3C : 8'h96);
      ck_mode(d, PM_ON);
      dp_get("VOTE", d, DP_ON, a);
      dp_get("VOTE", d, DP_OFF, b);
      ax0 = axi_n(d);
      dp_expect("VOTE", d, DP_ON, ST_OK, $sformatf("%s ON from agent %0d too", pd_name(d), b), b);
      bck("VOTE", axi_n(d) == ax0,
          $sformatf("%s: agent %0d's ON while agent %0d holds it ON made %0d PPU access(es); expected none",
                    pd_name(d), b, a, axi_n(d) - ax0));
      dp_get("VOTE", d, DP_ON, b);
      h0 = hop_log[d].size();
      dp_expect("VOTE", d, DP_OFF, ST_OK, $sformatf("%s OFF from agent %0d", pd_name(d), a), a);
      cyc_wait(150_000);
      bck("VOTE", pb_status[d] === PM_ON && hop_log[d].size() == h0,
          $sformatf("%s 150000 cycles after agent %0d's OFF, agent %0d still ON: %s, hops %s; expected ON, none",
                    pd_name(d), a, b, mode_name(pb_status[d]), hops_since(d, h0)));
      dp_get("VOTE", d, DP_OFF, a);
      dp_get("VOTE", d, DP_ON, b);
      dp_expect("VOTE", d, DP_OFF, ST_OK, $sformatf("%s OFF from agent %0d", pd_name(d), b), b);
      cyc_wait(150_000);
      ck_mode(d, lp_of(d));
      dp_get("VOTE", d, DP_OFF, 0);
      dp_get("VOTE", d, DP_OFF, 1);
      $display("[%0t] tb| R1 [chk:VOTE] %s: agent %0d ON, agent %0d ON (no PPU access), agent %0d OFF: still ON after 150000 cycles; agent %0d OFF: %s; GET_STATE the caller's own vote throughout",
               $time, pd_name(d), a, b, a, b, mode_name(lp_of(d)));
    end

    // ---- (f) The wake vote's owner: the domain's first permitted agent, the
    //      AP (soc4_plat.h). A GPIO wake powers ACC0 up: the AP's vote is ON,
    //      the RPU's still OFF; the RPU's OFF changes nothing, the AP's ends it ----
    h1 = hop_log[2].size(); up0 = n_in_up[IN_GPIO];
    irq_pulse(IN_GPIO);
    wake_wait("WAKE_OWNER", 2, IN_GPIO, up0, "GPIO wake (edge pulse)");
    ck_mode(2, PM_ON);
    cyc_wait(5000);                              // the ON's PPU events serviced (as B5, B12)
    dp_get("WAKE_OWNER", 2, DP_ON, 0);
    dp_get("WAKE_OWNER", 2, DP_OFF, 1);
    ax0 = axi_n(2);
    dp_expect("WAKE_OWNER", 2, DP_OFF, ST_OK, "ACC0 OFF from the RPU, not the owner", 1);
    cyc_wait(150_000);
    bck("WAKE_OWNER", pb_status[2] === PM_ON && axi_n(2) == ax0,
        $sformatf("ACC0 after the RPU's OFF: %s, %0d PPU access(es); expected ON, none (librpmi answers it alone)",
                  mode_name(pb_status[2]), axi_n(2) - ax0));
    dp_expect("WAKE_OWNER", 2, DP_OFF, ST_OK, "ACC0 OFF from the AP, the owner", 0);
    cyc_wait(150_000);
    ck_mode(2, PM_MEM_RET);
    $display("[%0t] tb| R1 [chk:WAKE_OWNER] GPIO wake: ACC0 ON, hops %s; GET_STATE AP ON, RPU OFF; the RPU's OFF: still ON; the AP's OFF: MEM_RET",
             $time, hops_since(2, h1));

    // ---- (g) Both agents at once: each votes for its own accelerator, then
    //      keeps its transport busy, while the other does the same ----
    dc0 = u_dut.u_mbx.deny_cnt_q[0]; dc1 = u_dut.u_mbx.deny_cnt_q[1];
    rc0 = u_dut.u_mbx.ring_cnt_q[0]; rc1 = u_dut.u_mbx.ring_cnt_q[1];
    both0 = n_both;
    fork
      begin
        dp_expect("AG_CONCURRENT", 3, DP_ON, ST_OK, "ACC1 ON from the AP, concurrently", 0);
        ag_traffic(0, 6, 3);
      end
      begin
        dp_expect("AG_CONCURRENT", 2, DP_ON, ST_OK, "ACC0 ON from the RPU, concurrently", 1);
        ag_traffic(1, 6, 2);
      end
    join
    ck_mode(2, PM_ON);
    ck_mode(3, PM_ON);
    fork
      dp_expect("AG_CONCURRENT", 3, DP_OFF, ST_OK, "ACC1 OFF from the AP, concurrently", 0);
      dp_expect("AG_CONCURRENT", 2, DP_OFF, ST_OK, "ACC0 OFF from the RPU, concurrently", 1);
    join
    cyc_wait(150_000);
    ck_mode(2, PM_MEM_RET);
    ck_mode(3, PM_OFF);
    bck("AG_CONCURRENT", n_both - both0 > 1000,
        $sformatf("both agents had a request in flight for %0d cycle(s); expected the traffic to overlap",
                  n_both - both0));
    bck("AG_CONCURRENT", qmem_k(0, 0) === ag_tail[0] && qmem_k(0, 16) === ag_tail[0] &&
                         qmem_k(0, 128) === ag_head[0] && qmem_k(0, 144) === ag_head[0] &&
                         qmem_k(1, 0) === ag_tail[1] && qmem_k(1, 16) === ag_tail[1] &&
                         qmem_k(1, 128) === ag_head[1] && qmem_k(1, 144) === ag_head[1],
        $sformatf("queue indices (A2P head/tail, P2A head/tail): window 0 %0d/%0d %0d/%0d, expected %0d/%0d %0d/%0d; window 1 %0d/%0d %0d/%0d, expected %0d/%0d %0d/%0d",
                  qmem_k(0, 0), qmem_k(0, 16), qmem_k(0, 128), qmem_k(0, 144), ag_tail[0], ag_tail[0], ag_head[0], ag_head[0],
                  qmem_k(1, 0), qmem_k(1, 16), qmem_k(1, 128), qmem_k(1, 144), ag_tail[1], ag_tail[1], ag_head[1], ag_head[1]));
    bck("AG_CONCURRENT", u_dut.u_mbx.deny_cnt_q[0] === dc0 && u_dut.u_mbx.deny_cnt_q[1] === dc1 &&
                         u_dut.u_mbx.ring_cnt_q[0] - rc0 == 20 && u_dut.u_mbx.ring_cnt_q[1] - rc1 == 20,
        $sformatf("during the concurrent traffic: DENY_CNT +%0d +%0d, RING_CNT +%0d +%0d; expected 0, 0, 20, 20",
                  u_dut.u_mbx.deny_cnt_q[0] - dc0, u_dut.u_mbx.deny_cnt_q[1] - dc1,
                  u_dut.u_mbx.ring_cnt_q[0] - rc0, u_dut.u_mbx.ring_cnt_q[1] - rc1));
    $display("[%0t] tb| R1 [chk:AG_CONCURRENT] both agents at once: 20 requests each (ON, 6 x 3 reads, OFF), every ACK its own (token, data); %0d cycles overlapping; indices consistent in both windows; no denial",
             $time, n_both - both0);
  endtask

  // ---------------------------------------------------------------------------
  // W1: the SCP watchdog (platform plan H18, F12). The steady state is CPU0 ON
  // for the AP and ACC1 ON for the RPU (ACC0 and CPU1 where the earlier steps
  // left them). The testbench then HANGS the SCP: it forces the core's two
  // interrupt lines LOW, so the main loop's next WFI never returns and the
  // kicks stop (a TB-only hook; the image is the product's). The RPU sends a
  // request into the hung SCP. Then:
  //   WDOG_EXPIRE  the watchdog resets the SCP within its timeout of the hang
  //   WDOG_SCOPE   the SCP subsystem alone (and the per-reset monitor's checks)
  //   WDOG_REBOOT  the firmware boots again, takes over with no PPU
  //                reprogrammed and two domains up, and re-arms the watchdog
  //   WDOG_KEEP    300 000 cycles later (past the hysteresis): no PPU hop, no
  //                PPUHWSTAT change, no PPU_PWPR write, at most the two
  //                interrupt-status clears per PPU; the CPUs' fetch unchanged
  //   WDOG_LOG     the fault log (mod/flog.h, SCP RAM 0xFC00) survived: every
  //                entry from before is where it was, one WDOG entry added,
  //                and it holds the earlier steps' deadline FAULTs, forced
  //                power-downs and firewall denials
  //   WDOG_LOST    the request sent into the hung SCP got no ACK, and every
  //                queue index reads 0 after the reboot (librpmi's zeroing):
  //                what an agent sees (rpmi/scp_rpmi.h)
  //   WDOG_RPMI    RPMI is served again with the votes kept: GET_STATE per
  //                caller as before; the RPU's OFF takes ACC1 down; CPU0's OFF
  //                and ON are a FULL_RET and a WARM resume (no reboot of CPU0)
  // ---------------------------------------------------------------------------
  localparam int unsigned KEEP_W     = 32'hFC00 / 4;     // link.ld .persist (mod/flog.h)
  localparam int unsigned FLOG_N     = 32;
  localparam logic [31:0] KEEP_MAGIC = 32'h504B_4353;    // SCP_KEEP_MAGIC

  function automatic logic [31:0] keep_w(input int unsigned w);
    return u_dut.u_scp.u_ram.mem[KEEP_W + w];
  endfunction

  // Is there an entry (code, domain) whose detail matches (detail & mask) == val?
  function automatic bit log_has(input int unsigned code, input int unsigned dom,
                                 input logic [31:0] mask, input logic [31:0] val);
    int unsigned n, head, slot;
    logic [31:0] w2;
    n    = keep_w(1) >> 24;
    head = (keep_w(1) >> 16) & 32'hFF;
    for (int i = 0; i < n; i++) begin
      slot = (head + FLOG_N - n + i) % FLOG_N;
      w2 = keep_w(4 + 4 * slot + 2);
      if (w2[7:0] == code && w2[15:8] == dom && (keep_w(4 + 4 * slot + 3) & mask) == val) return 1'b1;
    end
    return 1'b0;
  endfunction

  task automatic w1();
    logic [31:0] snap [4 + 4 * FLOG_N];
    logic [15:0] hw0 [NUM_PD];
    logic [3:0]  st0 [NUM_PD];
    int unsigned tr0 [NUM_PD], pw0 [NUM_PD], aw0 [NUM_PD];
    logic [1:0]  fe0;
    logic [31:0] v [8], dw [4], w2, boots0;
    int unsigned r0, rdy0, took0, cnt0, head0, seq0, t, moved, changed, e;
    longint unsigned t_hang, t_exp;
    bfm_step = 8'h30;
    $display("[%0t] tb| W1: the SCP watchdog: hang, reset, takeover, fault log; before it: %0d BFM checks, %0d testbench checks",
             $time, bfm_checks, checks);

    // ---- (a) The steady state ----
    dp_expect("WDOG_SETUP", 0, DP_ON, ST_OK, "CPU0 ON from the AP", 0);
    dp_expect("WDOG_SETUP", 3, DP_ON, ST_OK, "ACC1 ON from the RPU", 1);
    acc_fill(1, 8'h3C);
    ck_mode(0, PM_ON);
    ck_mode(3, PM_ON);
    cyc_wait(5000);                              // their PPU events serviced
    bck("WDOG_ARMED", u_dut.u_scp.u_wdog.en_q === 1'b1 && u_dut.u_scp.u_wdog.lock_q === 1'b1,
        "the product firmware has not armed and locked the watchdog");

    // ---- (b) Snapshot: the domains, the PPUs' accesses, the fault log ----
    for (int d = 0; d < NUM_PD; d++) begin
      hw0[d] = pb_hwstat[d]; st0[d] = pb_status[d]; tr0[d] = n_trans[d];
      pw0[d] = n_polwr[d];   aw0[d] = n_axi_wr[d];
    end
    fe0 = cpu_fetch;
    foreach (snap[w]) snap[w] = keep_w(w);
    cnt0 = snap[1] >> 24; head0 = (snap[1] >> 16) & 32'hFF; seq0 = snap[2];
    r0 = n_wdog_rst; rdy0 = n_ready; took0 = n_took;
    bck("WDOG_LOG", snap[0] === KEEP_MAGIC, $sformatf("the persistent block's magic is 0x%08h before the hang", snap[0]));

    // ---- (c) The hang, and a request into it ----
    wd_hang = 1'b1;
    force u_dut.u_scp.irq_timer = 1'b0;
    force u_dut.u_scp.irq_ext   = 1'b0;
    t = 0;
    while (scp_sleep !== 1'b1 && t < 400_000) begin @(posedge clk); t++; end
    bck("WDOG_EXPIRE", scp_sleep === 1'b1, "the SCP never reached WFI with its interrupt lines held LOW");
    t_hang = cyc;
    ag_tok[1]++;
    dw = '{32'd3, 32'h0, 32'h0, 32'h0};
    rpmi_send(G_DPWR, S_GET, ag_tok[1], 1, dw, 1);

    // ---- (d) Expiry ----
    t = 0;
    while (n_wdog_rst == r0 && t < WD_TIMEOUT + 100_000) begin @(posedge clk); t++; end
    t_exp = cyc;
    release u_dut.u_scp.irq_timer;
    release u_dut.u_scp.irq_ext;
    wdog_expect++;
    bck("WDOG_EXPIRE", n_wdog_rst == r0 + 1 && t_exp - t_hang <= WD_TIMEOUT,
        $sformatf("watchdog resets %0d -> %0d, %0d cycles after the SCP hung; expected one, within the timeout %0d",
                  r0, n_wdog_rst, t_exp - t_hang, WD_TIMEOUT));
    bck("WDOG_SCOPE", u_dut.u_scp.rst_sub_n === 1'b0 && u_dut.dom_rst_n === 1'b1 &&
                      u_dut.u_ctrl.ap_run_q === 1'b1 && cpu_fetch === fe0 && u_dut.u_mbx.fw_en_q === 2'b11,
        $sformatf("in the reset: SCP subsystem reset %b (want 0), domains' reset %b (want 1), AP_RUN %b, FETCH_EN %b (was %b), FW_EN %b",
                  u_dut.u_scp.rst_sub_n, u_dut.dom_rst_n, u_dut.u_ctrl.ap_run_q, cpu_fetch, fe0, u_dut.u_mbx.fw_en_q));
    $display("[%0t] tb| W1 [chk:WDOG_EXPIRE] SCP hung (interrupt lines held LOW) at cycle %0d; the watchdog reset it %0d cycles later (timeout %0d)",
             $time, t_hang, t_exp - t_hang, WD_TIMEOUT);

    // ---- (e) The reboot and the takeover ----
    t = 0;
    while (n_ready == rdy0 && t < 1_000_000) begin @(posedge clk); t++; end
    wd_hang = 1'b0;
    bck("WDOG_REBOOT", n_ready == rdy0 + 1 && n_took == took0 + 1 && took_up == 2 && took_rw == 0,
        $sformatf("after the reset: %0d ready line(s), %0d takeover line(s), %0d domain(s) up, %0d PPU(s) reprogrammed; expected 1, 1, 2 (CPU0, ACC1), 0",
                  n_ready - rdy0, n_took - took0, took_up, took_rw));
    bck("WDOG_REBOOT", u_dut.u_scp.u_wdog.en_q === 1'b1 && u_dut.u_scp.u_wdog.lock_q === 1'b1 &&
                       u_dut.u_scp.u_wdog.tmo_q === WD_TIMEOUT,
        "the rebooted firmware has not re-armed and locked the watchdog");
    $display("[%0t] tb| W1 [chk:WDOG_REBOOT] the firmware was ready again %0d cycles after the reset: took over %0d domain(s) up, %0d PPU(s) reprogrammed; watchdog re-armed",
             $time, cyc - t_exp, took_up, took_rw);

    // ---- (f) Nothing moved ----
    cyc_wait(300_000);
    moved = 0;
    for (int d = 0; d < NUM_PD; d++) begin
      bck("WDOG_KEEP", pb_hwstat[d] === hw0[d] && pb_status[d] === st0[d] && n_trans[d] == tr0[d] &&
                       n_polwr[d] == pw0[d] && n_axi_wr[d] - aw0[d] <= 2,
          $sformatf("%s across the watchdog reset: PPUHWSTAT 0x%04h -> 0x%04h, mode %s -> %s, %0d hop(s), %0d PWPR write(s), %0d AXI write(s); expected unchanged, none, none, at most 2 (ISR, AISR clears)",
                    pd_name(d), hw0[d], pb_hwstat[d], mode_name(st0[d]), mode_name(pb_status[d]),
                    n_trans[d] - tr0[d], n_polwr[d] - pw0[d], n_axi_wr[d] - aw0[d]));
      moved += n_trans[d] - tr0[d];
    end
    bck("WDOG_KEEP", cpu_fetch === fe0, $sformatf("FETCH_EN %b after the reset, was %b", cpu_fetch, fe0));
    $display("[%0t] tb| W1 [chk:WDOG_KEEP] 300000 cycles after the reset: CPU0 %s, CPU1 %s, ACC0 %s, ACC1 %s as before, %0d hop(s), PPUHWSTAT unchanged, no PWPR write",
             $time, mode_name(pb_status[0]), mode_name(pb_status[1]), mode_name(pb_status[2]),
             mode_name(pb_status[3]), moved);

    // ---- (g) The fault log ----
    changed = 0;                                 // every slot but the one written now
    for (int sl = 0; sl < FLOG_N; sl++)
      for (int i = 0; i < 4; i++)
        if (sl != head0 && keep_w(4 + 4 * sl + i) !== snap[4 + 4 * sl + i]) changed++;
    e  = 4 + 4 * head0;
    w2 = keep_w(e + 2);
    bck("WDOG_LOG", keep_w(0) === KEEP_MAGIC && keep_w(2) == seq0 + 1 && keep_w(3) == snap[3] + 1 &&
                    (keep_w(1) >> 24) == ((cnt0 < FLOG_N) ? cnt0 + 1 : FLOG_N) &&
                    ((keep_w(1) >> 16) & 32'hFF) == (head0 + 1) % FLOG_N,
        $sformatf("the block after the reset: magic 0x%08h, %0d entries (were %0d), seq %0d (was %0d), watchdog resets %0d (were %0d)",
                  keep_w(0), keep_w(1) >> 24, cnt0, keep_w(2), seq0, keep_w(3), snap[3]));
    bck("WDOG_LOG", changed == 0, $sformatf("%0d word(s) of the entries from before the reset changed", changed));
    bck("WDOG_LOG", w2[7:0] == 8'd5 && w2[15:8] == 8'hFF && w2[31:16] == seq0[15:0] &&
                    keep_w(e + 3) === {16'd0, 8'(r0 + 1), 8'h02},
        $sformatf("the new entry: code %0d dom 0x%02h seq %0d detail 0x%08h; expected WDOG (5), 0xFF, %0d, CAUSE 0x%04h",
                  w2[7:0], w2[15:8], w2[31:16], keep_w(e + 3), seq0, {8'(r0 + 1), 8'h02}));
    if (step_on("B0"))  bck("WDOG_LOG", log_has(3, 0, 32'h0, 32'h0), "no FW_DENY entry for the AP's transport (B0)");
    if (step_on("R0"))  bck("WDOG_LOG", log_has(3, 1, 32'h0, 32'h0), "no FW_DENY entry for the RPU's transport (R0)");
    if (step_on("B6"))  bck("WDOG_LOG", log_has(2, 2, 32'h0, 32'h0), "no FORCED entry for ACC0 (B6)");
    if (step_on("B7"))  bck("WDOG_LOG", log_has(1, 3, 32'hFF, 32'hF1), "no deadline FAULT entry (PD_E_TIMEOUT) for ACC1 (B7)");
    if (step_on("B11")) bck("WDOG_LOG", log_has(1, 1, 32'hFF, 32'hF1) && log_has(2, 1, 32'h0, 32'h0),
                            "no deadline FAULT and FORCED entries for CPU1 (B11)");
    $display("[%0t] tb| W1 [chk:WDOG_LOG] the fault log survived: %0d entries kept unchanged, WDOG entry #%0d added (CAUSE 0x%08h); deadline FAULTs, forced power-downs, firewall denials present",
             $time, cnt0, seq0, keep_w(e + 3));

    // ---- (h) The lost request; RPMI again, with the votes kept ----
    for (int k = 0; k < 2; k++) begin
      tl_rd("WDOG_LOST", ag_src(k), ag_win(k) + 32'h000, v[4 * k + 0], k);
      tl_rd("WDOG_LOST", ag_src(k), ag_win(k) + 32'h040, v[4 * k + 1], k);
      tl_rd("WDOG_LOST", ag_src(k), ag_win(k) + 32'h200, v[4 * k + 2], k);
      tl_rd("WDOG_LOST", ag_src(k), ag_win(k) + 32'h240, v[4 * k + 3], k);
    end
    bck("WDOG_LOST", v[0] === 0 && v[1] === 0 && v[2] === 0 && v[3] === 0 &&
                     v[4] === 0 && v[5] === 0 && v[6] === 0 && v[7] === 0,
        $sformatf("queue indices after the reboot (A2P head/tail, P2A head/tail): AP %0d/%0d %0d/%0d, RPU %0d/%0d %0d/%0d; all must be 0",
                  v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7]));
    ag_tail[0] = '0; ag_head[0] = '0; ag_tail[1] = '0; ag_head[1] = '0;
    $display("[%0t] tb| W1 [chk:WDOG_LOST] the RPU's request into the hung SCP got no ACK; every queue index reads 0 after the reboot",
             $time);
    dp_get("WDOG_RPMI", 0, DP_ON, 0);
    dp_get("WDOG_RPMI", 3, DP_ON, 1);
    dp_get("WDOG_RPMI", 3, DP_OFF, 0);
    dp_expect("WDOG_RPMI", 3, DP_OFF, ST_OK, "ACC1 OFF from the RPU after the takeover", 1);
    cyc_wait(150_000);
    ck_mode(3, PM_OFF);
    dp_expect("WDOG_RPMI", 0, DP_OFF, ST_OK, "CPU0 OFF from the AP after the takeover", 0);
    cyc_wait(150_000);
    ck_mode(0, PM_FULL_RET);
    boots0 = cram(0, W_BOOTS);
    dp_expect("WDOG_RPMI", 0, DP_ON, ST_OK, "CPU0 ON from the AP after the takeover", 0);
    ck_mode(0, PM_ON);
    bck("WDOG_RPMI", cram(0, W_BOOTS) === boots0,
        $sformatf("CPU0's boot count %0d -> %0d: its ON after the takeover rebooted it; expected a warm resume",
                  boots0, cram(0, W_BOOTS)));
    dp_expect("WDOG_RPMI", 0, DP_OFF, ST_OK, "CPU0 OFF from the AP", 0);
    cyc_wait(150_000);
    ck_mode(0, PM_FULL_RET);
    $display("[%0t] tb| W1 [chk:WDOG_RPMI] served again with the votes kept: GET_STATE CPU0 (AP) ON, ACC1 (RPU) ON, ACC1 (AP) OFF; ACC1 OFF; CPU0 FULL_RET, then a warm resume (boot count %0d)",
             $time, boots0);
  endtask

  // ---------------------------------------------------------------------------
  // K1: the clock/reset bridge against a SoC slower than the table says
  // (platform plan H16, F11, V5). soc4ckrst only: run when named in
  // +bfm_only, never in the default list.
  //   (a) ACC1's DCDR fields are the table's (latency 6)
  //   (b) the SoC's clkgate for ACC1 answers in 30: the AP's ON succeeds (the
  //       PPU cannot know), the bridge flags LATE on the clock, the firmware
  //       logs CLKRST and a FAULT (PD_E_CLKRST), clears the status, drops the
  //       vote, and its recovery takes ACC1 down
  //   (c) the SoC back to 6: ON recovers ACC1 (WARM_RST) with no new fault
  // ---------------------------------------------------------------------------
  task automatic k1();
    int unsigned t, f0, r0, l0;
    bfm_step = 8'h40;
    $display("[%0t] tb| K1: the clock/reset bridge against a slow SoC clkgate", $time);
    bck("CKRST_DCDR", ck_dcdr_ok(3),
        $sformatf("ACC1 DCDR: CLKEN_RST %0d CLKEN_ISO %0d RST_HWSTAT %0d, expected 6 6 6 (ckrst_lat 6)",
                  pb_d_cr[3], pb_d_ci[3], pb_d_rh[3]));
    f0 = n_fault_log[3]; r0 = n_recov_log[3]; l0 = n_in_line[IN_CKRST];
    ck_seen[3] = '0;
    ck_lat_clk[3] = 30;
    ck_expect[3]++;
    dp_expect("CKRST_LATE", 3, DP_ON, ST_OK, "ACC1 ON from the AP with its clkgate answering in 30", 0);
    t = 0;
    while (n_in_line[IN_CKRST] == l0 && t < 200_000) begin @(posedge clk); t++; end
    ck_lat_clk[3] = CKRST_LAT[3];
    bck("CKRST_LOG", n_in_line[IN_CKRST] == l0 + 1 && has(in_last[IN_CKRST], "DOMAIN_ID 3 status 0x11"),
        $sformatf("the firmware's bridge line: %0d new, last \"%s\"; expected one, DOMAIN_ID 3 status 0x11 (LATE, clock)",
                  n_in_line[IN_CKRST] - l0, in_last[IN_CKRST]));
    bck("CKRST_LATE", ck_seen[3] === 8'h11,
        $sformatf("ACC1's bridge status seen 0x%02h, expected 0x11: LATE on the clock", ck_seen[3]));
    t = 0;                                       // the console is slow: wait for the FAULT line
    while (n_fault_log[3] == f0 && t < 200_000) begin @(posedge clk); t++; end
    cyc_wait(200);
    bck("CKRST_LOG", log_has(4, 3, 32'hFF, 32'h11) && log_has(1, 3, 32'hFF, 32'hEF),
        "the fault log must hold CLKRST (ACC1, status 0x11) and FAULT (ACC1, PD_E_CLKRST -17)");
    bck("CKRST_LOG", n_fault_log[3] == f0 + 1 && u_dut.ckrst_stat[3] === 8'h00 && u_dut.ckrst_irq === 1'b0,
        $sformatf("FAULT lines %0d (were %0d), status 0x%02h, input %b after the handling; expected one more, 0, 0",
                  n_fault_log[3], f0, u_dut.ckrst_stat[3], u_dut.ckrst_irq));
    dp_get("CKRST_LOG", 3, DP_OFF, 0);
    t = 0;
    while (n_recov_log[3] == r0 && t < 1_000_000) begin @(posedge clk); t++; end
    ck_mode(3, PM_OFF);
    bck("CKRST_LOG", n_recov_log[3] == r0 + 1, "the FAULT's power-off retry never took ACC1 down");
    $display("[%0t] tb| K1 [chk:CKRST_LATE] the clock acknowledged in 30 > CLKEN_RST_DLY 6: LATE flagged, CLKRST and FAULT logged, the vote dropped, ACC1 recovered to OFF",
             $time);
    dp_expect("CKRST_RECOVER", 3, DP_ON, ST_OK, "ACC1 ON again with the SoC at its table latency", 0);
    ck_mode(3, PM_ON);
    dp_expect("CKRST_RECOVER", 3, DP_OFF, ST_OK, "ACC1 OFF", 0);
    cyc_wait(150_000);
    ck_mode(3, PM_OFF);
    bck("CKRST_RECOVER", ck_rise[3] == ck_expect[3] && n_fault_log[3] == f0 + 1,
        $sformatf("ACC1 ON and OFF at latency 6 after the fault: %0d bridge fault(s), expected %0d", ck_rise[3], ck_expect[3]));
    $display("[%0t] tb| K1 [chk:CKRST_RECOVER] ACC1 ON (WARM_RST recovery) and OFF with the SoC back at 6: no new fault", $time);
  endtask

  initial begin : bfm
    bfm_on = bfm_sel && (mode == "bfm");
    if (bfm_on) begin
      wait (rst_n === 1'b1);
      repeat (4) @(posedge clk);
      $display("[%0t] tb| BFM: steps %s", $time, (bfm_only == "") ? "B0, R0, B1-B12, R1, W1" : bfm_only);
      if (step_on("B0")) b0();
      if (step_on("R0")) r0();
      if (step_on("B1") || step_on("B2") || step_on("B3") || step_on("B4") || step_on("B5") ||
          step_on("B6") || step_on("B7") || step_on("B8") || step_on("B9") || step_on("B10") ||
          step_on("B11") || step_on("B12") || step_on("R1") || step_on("W1") ||
          (bfm_only != "" && step_on("K1")))
        b1();
      if (step_on("B2"))  b2();
      if (step_on("B3"))  b3();
      if (step_on("B4"))  b4();
      if (step_on("B5"))  b5();
      if (step_on("B6"))  b6();
      if (step_on("B7"))  b7();
      if (step_on("B8"))  b8();
      if (step_on("B9"))  b9();
      if (step_on("B10")) b10();
      if (step_on("B11")) b11();
      if (step_on("B12")) b12();
      if (step_on("R1"))  r1();
      if (step_on("W1"))  w1();
      if (bfm_only != "" && step_on("K1")) k1();
      #1;
      wait (rules_pending == 0);
      $display("[%0t] tb| BFM: done; %0d checks, %0d error(s)", $time, bfm_checks, bfm_errs);
      bfm_step = 8'hFF;
      bfm_stat = {16'd0, 8'(bfm_errs > 255 ? 255 : bfm_errs), bfm_step};
      bfm_done = 1'b1;
    end
  end

  // ===========================================================================
  // The end (10.8)
  // ===========================================================================
  longint unsigned n_cycles = 0, n_sleep = 0;
  always @(posedge clk)
    if (rst_n) begin
      n_cycles++;
      if (scp_sleep) n_sleep++;
    end

  function automatic string sp_str(input int unsigned v);
    return (v == 255) ? "-" : $sformatf("%0d", v);
  endfunction

  bit reported = 1'b0;

  task automatic report(input bit timed_out);
    int unsigned mon_total = 0, pm_total = 0, ups = 0;
    if (reported) return;
    reported = 1'b1;
    $display("");
    $display("==== soc4_tb report ====");
    $display(" domain  hops  denies  forced  last_mode   AXI wr  AXI rd  IRQs  dev-hs  PCSM-hs  monitor  power");
    for (int i = 0; i < NUM_PD; i++) begin
      mon_total += mon_viol[i];
      pm_total  += pm_viol[i];
      $display("  %-4s  %5d  %6d  %6d  %-9s  %6d  %6d  %4d  %6d  %7d  %7d  %5d", pd_name(i), n_trans[i],
               n_qdeny[i], n_forced[i], mode_name(pb_status[i]), n_axi_wr[i], n_axi_rd[i], n_irq[i],
               ob[i][OB_QREQ_FALLS], ob[i][OB_PREQ_RISES], mon_viol[i], pm_viol[i]);
    end
    $display(" shortest Table 4-5 spacings (cycles; '-' never measured)");
    $display("  dom   spacings  up: iso>clk clk>rst rst>hw  dn: clk>iso iso>rst  PPU-clk-gates  tb-errs");
    for (int i = 0; i < NUM_PD; i++) begin
      automatic int unsigned up = ob[i][OB_UP_MIN], dn = ob[i][OB_DN_MIN];
      $display("  %-4s  %8d      %7s %7s %6s      %7s %7s  %13d  %7d", pd_name(i), ob[i][OB_SPACINGS],
               sp_str(up & 32'hFF), sp_str((up >> 8) & 32'hFF), sp_str((up >> 16) & 32'hFF),
               sp_str(dn & 32'hFF), sp_str((dn >> 8) & 32'hFF), ob[i][OB_CLK_GATES], ob[i][OB_ERRS]);
    end
    for (int i = 0; i < NUM_PD; i++) ups += n_rail_ups[i];
    $display(" ppu_monitor violations: %0d  power_model violations: %0d  settle violations: %0d  AXI violations: %0d",
             mon_total, pm_total, settle_viol, axi_viol);
    if (ups != 0)
      $display(" %0d power-ups; the shortest rail-on -> reset release was %0d cycles (budget %0d)",
               ups, settle_min, SETTLE_CYCLES);
    if (`SOC4_PCSM_RET_SETTLE != 0 || `SOC4_PCSM_LOGIC_SETTLE != 0)
      $display(" PCSM switch settling: retention %0d, logic %0d PPU cycles, in every domain",
               `SOC4_PCSM_RET_SETTLE, `SOC4_PCSM_LOGIC_SETTLE);
    $display(" cycles %0d, SCP asleep in WFI for %0d (%0d%%)", n_cycles, n_sleep,
             (n_cycles == 0) ? 0 : (100 * n_sleep) / n_cycles);
`ifdef SOC4_PA
    $display(" power intent APPLIED (SOC4_PA)");
    $display(" supply-net checks (8.4-2): %0d (%0d of a rail OFF), %0d failed", n_supply, n_supply_off,
             n_supply_bad);
    ck(n_supply_off > 0 && n_supply > n_supply_off,
       $sformatf("the supply-net checks saw a rail both OFF and FULL_ON (%0d OFF of %0d)",
                 n_supply_off, n_supply));
`else
    $display(" power intent absent: domains are held in reset, not unpowered");
`endif
    $display(" watchdog: %0d reset(s), %0d expected; CTRL EN %b LOCK %b; closest to expiry while kicked: %0d of %0d cycles left",
             n_wdog_rst, wdog_expect, u_dut.u_scp.u_wdog.en_q, u_dut.u_scp.u_wdog.lock_q,
             (wd_min_left == 64'hFFFF_FFFF) ? 0 : wd_min_left, u_dut.u_scp.u_wdog.tmo_q);
    tck("WDOG_COUNT", n_wdog_rst == wdog_expect,
        $sformatf("%0d watchdog reset(s), expected %0d: a run that kicks it must never see it expire",
                  n_wdog_rst, wdog_expect));
    if (mode != "scp" && n_ready > 0)              // the product firmware has booted
      tck("WDOG_ARMED", u_dut.u_scp.u_wdog.en_q === 1'b1 && u_dut.u_scp.u_wdog.lock_q === 1'b1 &&
                        u_dut.u_scp.u_wdog.tmo_q === WD_TIMEOUT,
          $sformatf("the product firmware left the watchdog EN %b LOCK %b TIMEOUT 0x%08h; expected armed, locked, 0x%08h",
                    u_dut.u_scp.u_wdog.en_q, u_dut.u_scp.u_wdog.lock_q, u_dut.u_scp.u_wdog.tmo_q, WD_TIMEOUT));
    $display(" clock/reset bridges: %0d clock request edges, %0d forwarding mismatch(es); faults per domain %0d %0d %0d %0d (expected %0d %0d %0d %0d)",
             ck_edges, ck_fwd_bad, ck_rise[0], ck_rise[1], ck_rise[2], ck_rise[3],
             ck_expect[0], ck_expect[1], ck_expect[2], ck_expect[3]);
    tck("CKRST_FWD", ck_fwd_bad == 0 && (ck_edges > 0 || hops_all() == 0),
        $sformatf("the bridges' requests differed from the PPUs' controls in %0d cycle(s) (%0d edges)",
                  ck_fwd_bad, ck_edges));
    if (mode != "scp" && n_ready > 0) begin       // the product firmware: pd_init's delays
      tck("CKRST_NONE", ck_rise[0] == ck_expect[0] && ck_rise[1] == ck_expect[1] &&
                        ck_rise[2] == ck_expect[2] && ck_rise[3] == ck_expect[3],
          "a clock/reset bridge fault where none was expected: the table's delays must cover the SoC");
      for (int d = 0; d < NUM_PD; d++)
        tck("CKRST_DCDR", ck_dcdr_ok(d),
            $sformatf("%s DCDR: RST_HWSTAT %0d ISO_CLKEN %0d CLKEN_RST %0d CLKEN_ISO %0d ISO_RST %0d; expected the table's (latency %0d)",
                      pd_name(d), pb_d_rh[d], pb_d_ic[d], pb_d_cr[d], pb_d_ci[d], pb_d_ir[d], CKRST_LAT[d]));
    end
    ck(!timed_out, "the run ended before the cycle limit");
    ck(mon_total == 0, $sformatf("ppu_monitor: %0d violation(s) across all domains", mon_total));
    ck(pm_total  == 0, $sformatf("ppu_power_model: %0d violation(s) across all domains", pm_total));
    ck(axi_viol  == 0, $sformatf("AXI4-Lite VALID/payload rules: %0d violation(s)", axi_viol));
    ck(settle_viol == 0, $sformatf("reset released within %0d cycles of the rail coming on: %0d time(s)",
                                   SETTLE_CYCLES, settle_viol));
    ck(rules_pending == 0, $sformatf("%0d IP-state rule(s) still waiting at the end", rules_pending));
    if (mode == "ap") begin
      ck(a_halt === 1'b1 && a_code === 32'h0, $sformatf("the AP's verdict: HALT code 0x%08h", a_code));
      ck(s_halt !== 1'b1, $sformatf("the SCP server halted (code 0x%08h)", s_code));
    end else if (mode == "bfm") begin
      ck(bfm_done, "the BFM ran its steps to the end");
      ck(s_halt !== 1'b1, $sformatf("the SCP server halted (code 0x%08h)", s_code));
    end else begin
      ck(s_halt === 1'b1 && s_code === 32'h0, $sformatf("the SCP test's verdict: HALT code 0x%08h", s_code));
    end
    ck(!scp_fatal, "the SCP printed a FATAL line");
    $display(" mode=%s  SCP %s  AP %s", mode,
             (s_halt === 1'b1) ? $sformatf("halt 0x%08h", s_code) : "server, not halted",
             (a_halt === 1'b1) ? $sformatf("halt 0x%08h", a_code) : "-");
    if (mode == "bfm") $display(" BFM: %0d checks, %0d error(s)", bfm_checks, bfm_errs);
    $display(" testbench %0d checks, %0d error(s)", checks, errors);
    if (errors == 0) $display(" RESULT: PASS");
    else             $display(" RESULT: FAIL");
    $display("==============================================================================");
    $finish;
  endtask

  initial begin : finish_ctl
    wait (rst_n === 1'b1);
    if (mode == "ap")       wait (a_halt === 1'b1 || s_halt === 1'b1);
    else if (mode == "bfm") wait (bfm_done || s_halt === 1'b1);
    else                    wait (s_halt === 1'b1);
    #1;
    wait (rules_pending == 0);
    repeat (4) @(posedge clk);
    report(1'b0);
  end

  initial begin : cycle_limit
    int unsigned max_cycles;
    max_cycles = 20_000_000;
    void'($value$plusargs("max_cycles=%d", max_cycles));
    wait (rst_n === 1'b1);
    repeat (max_cycles) @(posedge clk);
    $display("[%0t] tb| ERROR: the run did not end after %0d cycles (mode %s)", $time, max_cycles, mode);
    report(1'b1);
  end

endmodule
