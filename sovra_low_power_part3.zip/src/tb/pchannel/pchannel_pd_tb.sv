`timescale 1ns/1ps
// Integration testbench for the P-Channel managed power domain (pchannel_pd_top).
//
// Exercises the Section 4.2.2 ON / RETENTION / OFF example end to end, and
// proves the thing that actually distinguishes a P-Channel from a Q-Channel:
// two different non-running states with different consequences.
//
//   RETENTION  workload frozen, state PRESERVED, resumes where it left off
//   OFF        workload reset,  state LOST
//
//   P0  Reset and bring-up: boots into ON, device captures PSTATE during tinit.
//   P1  Work burst runs; busy asserted, work_count decrements.
//   P2  Request RETENTION while busy with denial enabled -> P_DENIED, and the
//       controller restores PSTATE to the current state (Figure 2-11 T4).
//   P3  RETENTION PRESERVES STATE: freeze a burst mid-flight, check the
//       retention actuation, hold, verify work_count is unchanged, return to ON
//       and let it finish.
//   P4  OFF LOSES STATE: drop a burst to OFF, verify the workload is reset.
//   P5  Unsupported transition OFF -> RETENTION is denied and flagged
//       (Table 4-1: from OFF the only supported transition is to ON).
//   P6  PACTIVE-led wake from OFF (Section 2.2.3 minimum-state rule), including
//       the pre-transition actions that make the request answerable.
//   P7  Late device clock: the domain is released from reset with dclk STOPPED
//       and a request already outstanding. Proves tinit is counted in device
//       clocks that have actually happened, and that a request sampled inside
//       the window is force-accepted (Section 2.2.2).
//
// An earlier revision had two more phases -- "accepted RETENTION once idle" and
// "back to ON" -- which performed the same ON -> RET -> ON transition pair that
// P3 already needs in order to freeze and thaw a burst. Only their actuation
// checks were unique, so those were folded into P3 rather than run twice.
//
// STIMULUS TIMING CONVENTION
// Every DUT input is driven, and every DUT output sampled, on the NEGEDGE of
// the relevant clock, so the sampling posedge lands in the middle of the data
// eye. Driving on the posedge would put the input transition and the sampling
// edge at the same simulation time, leaving the outcome dependent on
// event-ordering inside the simulator and making waveforms unreadable.
//
// P7 is the deliberate exception: it drives with raw delays while dclk is
// STOPPED, because there are no edges to align to. That is the point of the
// test.

module pchannel_pd_tb;

  import pchannel_pkg::*;
  import pch_example_pkg::*;

  localparam int unsigned CNT_W = 8;

  // ---- Clocks. dclk is gateable so P7 can start it late. ----
  logic aon_clk = 1'b0, mclk = 1'b0;
  logic dclk    = 1'b0;
  logic dclk_en = 1'b1;
  always #2.15 aon_clk = ~aon_clk;
  always #0.50 mclk    = ~mclk;
  always #6.85 if (dclk_en) dclk = ~dclk;

  logic aon_rst_n = 1'b0;
  logic drst_n    = 1'b0;
  logic mrst_n    = 1'b0;
  initial begin mrst_n = 1'b0; #1 mrst_n = 1'b1; end

  // ---- Stimulus ----
  logic [1:0]       pm_req_state = EX_ON;
  logic             pm_req_valid = 1'b0;
  logic             enb_pactive  = 1'b0;
  logic             deny_enb     = 1'b1;
  logic             start        = 1'b0;
  logic [CNT_W-1:0] work_len     = '0;
  logic             wake         = 1'b0;

  int unsigned tb_errors = 0, checks = 0;
  int unsigned viol;

  pchannel_pd_top #(
    .SYNC_STAGES(2), .CNT_W(CNT_W), .TINIT(4), .TINIT_WAIT(32),
    .PRE_SETTLE(8), .POST_SETTLE(4)
  ) u_top (
    .aon_clk(aon_clk), .aon_rst_n(aon_rst_n),
    .dclk(dclk), .drst_n(drst_n),
    .pm_req_state(pm_req_state), .pm_req_valid(pm_req_valid),
    .enb_pactive_led_transition(enb_pactive),
    .policy_deny_enb(deny_enb),
    .start(start), .work_len(work_len), .wake(wake)
  );

  // ---- Observability via hierarchical reference (the DUT has no debug ports) ----
  wire [1:0]        ctrl_cur   = u_top.ctrl_cur_state;
  wire [1:0]        dev_cur    = u_top.dev_cur_state;
  wire              dev_init   = u_top.dev_init_done;
  wire              ctrl_init  = u_top.ctrl_init_done;
  wire              act_busy   = u_top.act_busy;
  wire              act_denied = u_top.act_denied;
  wire              pwr_on     = u_top.pwr_on;
  wire              iso_en     = u_top.iso_en;
  wire              wl_retain  = u_top.wl_retain;
  wire              wl_rst_n   = u_top.wl_rst_n;
  wire              busy       = u_top.busy;
  wire [CNT_W-1:0]  work_count = u_top.work_count;
  wire [1:0]        pstate     = u_top.pstate;
  wire              preq       = u_top.preq;
  wire              paccept    = u_top.paccept;
  wire              pdeny      = u_top.pdeny;
  wire [1:0]        floor_st   = u_top.pactive_floor_state;

  // dev_unsupported is a single-cycle combinational flag; latch it so a test
  // can assert it was seen. Sampled on the negedge like everything else here --
  // the flag is valid across the whole dclk cycle in which dev_req_valid is
  // HIGH, so the negedge lands in the middle of it.
  logic unsup_seen = 1'b0;
  always @(negedge dclk) if (u_top.dev_unsupported) unsup_seen <= 1'b1;

  pchannel_monitor #(.PSTATE_W(2)) u_mon (
    .clk(mclk), .rst_n(mrst_n), .crst_n(aon_rst_n), .drst_n(drst_n),
    .preq(preq), .paccept(paccept), .pdeny(pdeny), .pstate(pstate),
    .violations(viol)
  );

  // ---- Current test phase, as ASCII in the waveform ----
  // VCD has no string type, so the phase name lives in a packed byte vector:
  // dumpers emit that as an ordinary reg, and GTKWave renders it as text once
  // the trace's Data Format is set to ASCII. A SystemVerilog `string` will not
  // survive the dump -- Icarus will not even cast one into a packed vector.
  //
  // Sized to hold the longest phase name below without truncation. That matters:
  // an over-long name assigned straight through $sformat would overflow and keep
  // the RIGHTMOST characters, silently dropping the "P7"/"P9" prefix that
  // identifies the test. set_phase truncates from the right instead.
  localparam int unsigned PHASE_CHARS = 56;
  reg [8*PHASE_CHARS-1:0] test_phase;

  // Single source of truth for the phase: drives the waveform signal and prints
  // the log banner together, so the two can never disagree.
  task automatic set_phase(input string name);
    begin
      if (name.len() > PHASE_CHARS)
        $sformat(test_phase, "%-56s", name.substr(0, PHASE_CHARS-1));
      else
        $sformat(test_phase, "%-56s", name);
      $display("\n[%0t] ========== %0s ==========", $time, name);
    end
  endtask

  // ---- Helpers ----
  task automatic chk(input bit cond, input string tag);
    begin
      checks++;
      if (cond) $display("[%0t]  ok  %s", $time, tag);
      else begin
        tb_errors++;
        $display("[%0t] ERR  %s", $time, tag);
      end
    end
  endtask

  task automatic wait_act_start(input int limit_ns, input string tag);
    time t0; bit hit;
    begin
      t0 = $time; hit = 1'b0;
      while (!hit) begin
        @(negedge aon_clk);
        if (act_busy) hit = 1'b1;
        else if (($time - t0) > limit_ns * 1000) begin
          hit = 1'b1; tb_errors++;
          $display("[%0t] ERR  %s: actuator never started", $time, tag);
        end
      end
    end
  endtask

  task automatic wait_act_done(input int limit_ns, input string tag);
    time t0; bit hit;
    begin
      t0 = $time; hit = 1'b0;
      while (!hit) begin
        @(negedge aon_clk);
        if (!act_busy) hit = 1'b1;
        else if (($time - t0) > limit_ns * 1000) begin
          hit = 1'b1; tb_errors++;
          $display("[%0t] ERR  %s: actuator never finished", $time, tag);
        end
      end
    end
  endtask

  // Pulse the PM request and run the whole pre/handshake/post sequence out.
  task automatic pm_request(input logic [1:0] s, input int limit_ns, input string tag);
    begin
      @(negedge aon_clk); pm_req_state <= s; pm_req_valid <= 1'b1;
      wait_act_start(limit_ns, tag);
      wait_act_done(limit_ns, tag);
      @(negedge aon_clk); pm_req_valid <= 1'b0;
      @(negedge aon_clk);
      checks++;
      $display("[%0t]  ok  %s: sequence complete (state=%s, denied=%0b)",
               $time, tag, ex_state_name(ctrl_cur), act_denied);
    end
  endtask

  task automatic run_burst(input logic [CNT_W-1:0] len);
    begin
      @(negedge dclk); work_len <= len; start <= 1'b1;
      @(negedge dclk); start <= 1'b0;
    end
  endtask

  task automatic wait_busy_low(input int limit_ns, input string tag);
    time t0; bit hit;
    begin
      t0 = $time; hit = 1'b0;
      while (!hit) begin
        @(negedge dclk);
        if (!busy) hit = 1'b1;
        else if (($time - t0) > limit_ns * 1000) begin
          hit = 1'b1; tb_errors++;
          $display("[%0t] ERR  %s: workload never went idle", $time, tag);
        end
      end
    end
  endtask

  logic [CNT_W-1:0] frozen_count;

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("pchannel_pd_tb.vcd");
    $dumpvars(0, pchannel_pd_tb);

    // =========================================================================
    set_phase("P0: Reset and Bring-Up");
    $display("[%0t]   The controller holds PSTATE=ON through reset; the device", $time);
    $display("[%0t]   must capture it within tinit (Section 3.2.2 recommends a", $time);
    $display("[%0t]   reset value that exits directly into a functional state).", $time);
    aon_rst_n = 1'b0; drst_n = 1'b0;
    #60;
    chk(paccept === 1'b0 && pdeny === 1'b0, "P0.reset: PACCEPT & PDENY LOW in reset");
    @(negedge aon_clk); aon_rst_n = 1'b1;
    @(negedge dclk);    drst_n    = 1'b1;
    wait (ctrl_init === 1'b1 && dev_init === 1'b1);
    chk(dev_cur  === EX_ON, "P0.init: device captured PSTATE=ON");
    chk(ctrl_cur === EX_ON, "P0.init: controller current state is ON");
    chk(pwr_on === 1'b1 && iso_en === 1'b0 && wl_rst_n === 1'b1,
        "P0: ON actuation (powered, not isolated, workload out of reset)");

    // =========================================================================
    set_phase("P1: Work Burst");
    run_burst(8'd40);
    repeat (4) @(negedge dclk);
    chk(busy === 1'b1, "P1.busy: workload is busy");
    repeat (6) @(negedge dclk);
    chk(work_count < 8'd40, "P1: work is counting down");

    // =========================================================================
    set_phase("P2: Denied While Busy");
    $display("[%0t]   Table 4-1: ON -> RETENTION supports denial. The device is", $time);
    $display("[%0t]   busy, so it refuses and stays fully operational.", $time);
    deny_enb = 1'b1;
    pm_request(EX_RET, 800, "P2.deny");
    chk(act_denied === 1'b1, "P2: the request was denied");
    chk(ctrl_cur === EX_ON && dev_cur === EX_ON, "P2: device remained in ON");
    chk(pstate === EX_ON, "P2: PSTATE restored to the current state (rule 3)");
    chk(pwr_on === 1'b1 && iso_en === 1'b0, "P2: pre-transition actions reversed");
    chk(busy === 1'b1, "P2: workload kept running throughout the denial");

    // =========================================================================
    // This phase absorbs what used to be two separate ones ("accepted RETENTION
    // once idle" and "back to ON"). Those performed the identical ON -> RET ->
    // ON transition pair this phase already needs in order to freeze and thaw a
    // burst; only their actuation checks were unique, so those moved here.
    set_phase("P3: RETENTION PRESERVES STATE");
    $display("[%0t]   Denial disabled so the burst can be frozen mid-flight.", $time);
    // P1's burst is still in flight -- P2 deliberately left it running to prove
    // a denial does not disturb the workload. The workload only samples `start`
    // while IDLE, so drain it first or the burst below never launches and the
    // freeze checks measure a work_count of zero.
    wait_busy_low(2000, "P3.drain-prior-burst");
    deny_enb = 1'b0;
    run_burst(8'd80);
    repeat (10) @(negedge dclk);
    chk(busy === 1'b1 && work_count > 8'd0, "P3: burst is mid-flight");
    pm_request(EX_RET, 800, "P3.freeze");
    chk(act_denied === 1'b0, "P3: accepted with denial disabled");
    chk(ctrl_cur === EX_RET && dev_cur === EX_RET, "P3: both sides agree on RETENTION");
    chk(wl_retain === 1'b1, "P3: retention hold asserted");
    chk(pwr_on === 1'b1, "P3: retention keeps the domain powered (unlike OFF)");
    chk(iso_en === 1'b1, "P3: isolation asserted in RETENTION");
    frozen_count = work_count;
    chk(frozen_count > 8'd0, "P3: captured a non-zero frozen work_count");
    repeat (40) @(negedge dclk);
    chk(work_count === frozen_count, "P3: work_count FROZEN across the retention window");
    chk(busy === 1'b1, "P3: the frozen burst is still outstanding");
    pm_request(EX_ON, 800, "P3.thaw");
    chk(ctrl_cur === EX_ON, "P3: returned to ON");
    chk(wl_retain === 1'b0 && iso_en === 1'b0, "P3: retention and isolation released");
    repeat (4) @(negedge dclk);
    chk(work_count < frozen_count, "P3: burst RESUMED from the frozen count, not restarted");
    wait_busy_low(3000, "P3.finish");
    chk(busy === 1'b0, "P3: the preserved burst ran to completion");

    // =========================================================================
    set_phase("P4: OFF LOSES STATE");
    run_burst(8'd80);
    repeat (10) @(negedge dclk);
    chk(busy === 1'b1 && work_count > 8'd0, "P4: burst is mid-flight");
    pm_request(EX_OFF, 800, "P4.off");
    chk(ctrl_cur === EX_OFF && dev_cur === EX_OFF, "P4: both sides agree on OFF");
    chk(pwr_on === 1'b0, "P4: domain power removed");
    chk(wl_rst_n === 1'b0, "P4: workload held in reset");
    chk(iso_en === 1'b1, "P4: isolation asserted");
    chk(work_count === 8'd0 && busy === 1'b0, "P4: workload state LOST (unlike RETENTION)");

    // =========================================================================
    set_phase("P5: Unsupported Transition OFF -> RETENTION");
    $display("[%0t]   Table 4-1: from OFF the only supported transition is to ON --", $time);
    $display("[%0t]   there is no operable logic to save into retention. Section", $time);
    $display("[%0t]   4.2.1 requires passing through the operable state instead.", $time);
    unsup_seen = 1'b0;
    pm_request(EX_RET, 800, "P5.unsupported");
    chk(act_denied === 1'b1, "P5: unsupported transition was denied");
    chk(unsup_seen === 1'b1, "P5: policy flagged it as unsupported");
    chk(ctrl_cur === EX_OFF, "P5: device stayed in OFF");
    chk(pwr_on === 1'b0, "P5: pre-transition actions reversed after the denial");

    // =========================================================================
    set_phase("P6: PACTIVE-Led Wake from OFF");
    $display("[%0t]   Section 2.2.3: the most significant PACTIVE bit HIGH is the", $time);
    $display("[%0t]   minimum state required. The actuator owns this trigger so the", $time);
    $display("[%0t]   domain is powered up BEFORE the request is issued.", $time);
    chk(floor_st === EX_OFF, "P6: PACTIVE floor is OFF while nothing is requested");
    enb_pactive = 1'b1;
    @(negedge dclk); wake <= 1'b1;      // -> PACTIVE[2] -> floor becomes ON
    wait_act_start(800, "P6.wake");
    wait_act_done(800, "P6.wake");
    @(negedge aon_clk);
    chk(floor_st === EX_ON, "P6: floor rose to ON");
    chk(ctrl_cur === EX_ON && dev_cur === EX_ON, "P6: domain woke to ON without a PM request");
    chk(pwr_on === 1'b1 && wl_rst_n === 1'b1, "P6: powered up and released from reset");
    @(negedge dclk); wake <= 1'b0;
    enb_pactive = 1'b0;

    // =========================================================================
    set_phase("P7: Late Device Clock (tinit with no clock edges)");
    $display("[%0t]   The domain is released from reset with dclk STOPPED and a", $time);
    $display("[%0t]   request already outstanding. tinit is counted in DEVICE clock", $time);
    $display("[%0t]   cycles, so none of it elapses until the clock arrives -- this", $time);
    $display("[%0t]   is the clock-availability term that dominates tinit sizing", $time);
    $display("[%0t]   (Section 2.2.4) and the reason the controller's TINIT_WAIT is", $time);
    $display("[%0t]   in controller cycles, not device cycles.", $time);
    // Park the interface in P_STABLE before touching the device reset (PR9).
    repeat (10) @(negedge aon_clk);
    chk(preq === 1'b0 && paccept === 1'b0 && pdeny === 1'b0,
        "P7: interface is in P_STABLE before asserting device reset");
    @(negedge dclk);
    drst_n  = 1'b0;
    dclk_en = 1'b0;                     // stop the device clock entirely
    #100;
    drst_n = 1'b1;                      // release reset with NO clock running
    #200;
    chk(dev_init === 1'b0, "P7: tinit has NOT elapsed -- no device clock edges yet");
    dclk_en = 1'b1;                     // clock finally arrives
    wait (dev_init === 1'b1);
    chk(dev_cur === EX_ON, "P7: device captured PSTATE once the clock started");
    // And a real transition still works afterwards.
    deny_enb = 1'b1;
    pm_request(EX_OFF, 1500, "P7.transition");
    chk(ctrl_cur === EX_OFF && dev_cur === EX_OFF, "P7: transition completed after the late start");
    // The workload is idle here, so with denial ENABLED the policy still has no
    // reason to refuse. This is the only remaining check of the
    // deny_enb=1 + idle -> accept path (P2 covers deny_enb=1 + busy -> deny,
    // P3 covers deny_enb=0 + busy -> accept), so it is asserted explicitly
    // rather than left implied by the state having changed.
    chk(act_denied === 1'b0, "P7: accepted with denial enabled and the workload idle");

    #200;
    chk(viol == 0, "MONITOR: zero protocol-rule violations");

    // =========================================================================
    $display("\n==================== P-CHANNEL PD SUMMARY ====================");
    $display(" checks run        : %0d", checks);
    $display(" testbench errors  : %0d", tb_errors);
    $display(" monitor violations: %0d", viol);
    $display(" RESULT: %s", (tb_errors == 0 && viol == 0) ? "PASS" : "FAIL");
    $display("==============================================================\n");
    $finish;
  end

  initial begin
    #20_000_000;
    $display("GLOBAL TIMEOUT");
    $finish;
  end

endmodule
