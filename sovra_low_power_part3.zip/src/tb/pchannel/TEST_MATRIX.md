# P-Channel testbench — control-signal matrix

Which DUT control inputs each phase of the three P-Channel testbenches drives,
and what that combination is meant to prove. Phase names match the `test_phase`
signal in the waveform and the banners in the log.

See [the P-Channel README](../../rtl/pchannel/README.md) for the protocol itself.

---

## 1. `pchannel_pd_tb.sv` — ON / RETENTION / OFF integration

DUT is [`pchannel_pd_top`](../../rtl/pchannel/pchannel_pd_top.sv).

### The knobs that decide the outcome

| Signal | Meaning |
|---|---|
| `pm_req_state` | requested state: `EX_OFF` (0), `EX_RET` (1), `EX_ON` (2) |
| `pm_req_valid` | **rising edge** launches; level-triggering would re-issue a denied request forever |
| `deny_enb` | gates the policy's `busy` input — 1 = may deny while the workload is busy |
| `enb_pactive` | 1 = the actuator honours the §2.2.3 PACTIVE floor and wakes autonomously |
| `wake` | drives `PACTIVE[2]`, i.e. "ON required" |
| `start` / `work_len` | workload burst |
| `dclk_en` / `drst_n` | device clock and reset, driven directly only by P7 |

Denial is decided by [`pchannel_state_policy`](../../rtl/pchannel/pchannel_state_policy.sv)
from Table 4-1, and has two independent causes:

```
deny = req_valid && ( (deniable && busy) || !supported )
```

so a request is refused either because the device is **busy** (and the current
state supports denial) or because the transition is **unsupported** — the second
being a controller bug the policy flags on `unsupported`.

| `deny_enb` | current → requested | `busy` | Response | Phase |
|:---:|---|:---:|---|---|
| 1 | ON → RETENTION | 1 | **`P_DENIED`** — refuses, device stays fully operational | P2 |
| 1 | ON → OFF | 0 | Accepts — denial enabled but nothing to object to | P7 |
| 0 | ON → RETENTION | 1 | Accepts **mid-burst**; workload frozen, state preserved | P3 |
| 0 | ON → OFF | 1 | Accepts **mid-burst**; workload reset, state lost | P4 |
| 0 | OFF → RETENTION | 0 | **`P_DENIED`** + `unsupported` — not in Table 4-1 at all | P5 |

### Per-phase matrix

`—` means the phase does not touch that signal.

| Phase | `pm_req_state` | `work_len` | `deny_enb` | `enb_pactive` | `wake` | What it proves |
|---|:---:|:---:|:---:|:---:|:---:|---|
| **P0** Reset and Bring-Up | — (holds `EX_ON`) | 0 | 1 | 0 | 0 | Boots into ON; the device captures `PSTATE=ON` within `tinit`; ON actuation applied (powered, not isolated, workload out of reset). |
| **P1** Work Burst | — | 40 | 1 | 0 | 0 | `busy` asserted, `work_count` decrements. Sets up the busy state P2 needs. |
| **P2** Denied While Busy | `EX_RET` | — | **1** | 0 | 0 | Denial supported from ON → **`P_DENIED`**. `PSTATE` is **restored to the current state** (rule PR3 / Figure 2-11 T4), pre-transition actions reversed, and the workload runs on undisturbed. |
| **P3** RETENTION PRESERVES STATE | `EX_RET` → `EX_ON` | 80 | **0** | 0 | 0 | Burst frozen mid-flight. Checks the **retention actuation** (retain asserted, isolation asserted, **power kept on** — what distinguishes RETENTION from OFF), that `work_count` is **unchanged** across a 40-cycle hold, that the thaw **releases** retention and isolation, and that the burst **resumes rather than restarts**. |
| **P4** OFF LOSES STATE | `EX_OFF` | 80 | 0 | 0 | 0 | An identical burst dropped to OFF: power removed, workload held in reset, `work_count` and `busy` back to 0. **The contrast with P3 is the entire argument for using a P-Channel.** |
| **P5** Unsupported Transition | `EX_RET` (from OFF) | — | 0 | 0 | 0 | Table 4-1 has no OFF → RETENTION: denied, `unsupported` raised, device stays in OFF, pre-transition actions reversed. |
| **P6** PACTIVE-Led Wake from OFF | *(none — device-led)* | — | 0 | **1** | **0→1→0** | `wake` raises `PACTIVE[2]`, the floor becomes ON, and the **actuator** (not the controller) launches the request — so the domain is powered and released from reset *before* the request is issued. |
| **P7** Late Device Clock | `EX_OFF` | — | **1** | 0 | 0 | `drst_n` released with `dclk_en=0`: `dev_init_done` provably stays LOW for the whole window because `tinit` is counted in **device clock cycles that actually happen**. A transition still completes once the clock arrives, and — with the workload idle — is accepted **with denial enabled**. |

### Phases removed as redundant

An earlier revision ran ten phases. Two were dropped — "accepted RETENTION once
idle" and "back to ON" — because between them they performed the same
ON → RET → ON transition pair that P3 already needs in order to freeze and thaw
a burst. Only their actuation checks were unique, so those moved into P3.

That left one condition covered only implicitly: **denial enabled with the
workload idle**. P7 exercises it, and now asserts `act_denied == 0` explicitly
rather than leaving it implied by the state having changed.

> Removing those two phases surfaced a latent sequencing dependency: P1's burst
> was being drained by the "once idle" phase, and P2 deliberately leaves it
> running. Since the workload only samples `start` while IDLE, P3's own burst
> silently failed to launch and the freeze checks measured a `work_count` of
> zero. P3 now drains explicitly first. Worth noting because the phase had been
> passing on a side effect of a phase that tested something else.

---

## 2. `pchannel_tb.sv` — core protocol

Two independent sections. Part A is a real controller/device pair; Part B drives
a second device instance with scripted stimulus, because the three §2.2.2
initialization behaviours cannot all be produced by `pchannel_controller`.

### Part A — controller + device pair

| Phase | `req_state` | `tb_deny` | `enb_pactive` | `dev_pactive` | What it proves |
|---|:---:|:---:|:---:|:---:|---|
| **T0** Reset and Bring-Up | — (`S_ON` held) | 0 | 0 | `000` | `PSTATE` captured at reset deassertion; both sides agree on ON. |
| **T1** Accepted Transition ON → RET | `S_RET` | **0** | 0 | `000` | The Figure 2-10 accepted handshake; both sides commit. |
| **T2** Denied Transition | `S_OFF` | **1** | 0 | `000` | Figure 2-11 denial; state unchanged on both sides; **`PSTATE` restored** to the current state. |
| **T3** Multiple Transitions | `S_OFF` then `S_ON` | 0 | 0 | `000` | Figure 2-15: RET → OFF → ON with no return to a common state in between. |
| **T4** PACTIVE-Led Transition | `S_OFF` (setup) | 0 | **1** | **`100`** | The §2.2.3 floor: `PACTIVE[2]` HIGH makes ON the minimum, and the controller moves up to it with no explicit request. |
| **T5** Explicit Request Below the Floor | `S_RET` | 0 | **0** | `100` (still) | The controller may request *below* the floor — the spec lets it make any policy decision irrespective of `PACTIVE`; denying inappropriate requests is the **device's** job. |

### Part B — device alone, scripted controller

Covers the three §2.2.2 initialization behaviours. `b_deny` is asserted in B2 and
B3 specifically to prove it is **ignored**: "the device must accept any request
made at reset exit or during `tinit`".

| Phase | `b_pstate` | `b_preq` raised | `b_deny` | What it proves |
|---|:---:|---|:---:|---|
| **B1** Init Behaviour 1 | `S_ON` | *after* `tinit` expires | 0, then **1** | `PREQ` LOW at reset exit (the controller waits out `tinit`). Once `tinit` has passed, denial is **live again** and the request is refused. |
| **B2** Init Behaviour 2 | `S_RET` | **before** reset deassertion | **1** | Request outstanding across reset release → **accepted despite `b_deny=1`**. Completing it also ends the init period. |
| **B3** Init Behaviour 3 | `S_OFF` | **during** `tinit` | **1** | Sampled inside the window → force-accepted. This device treats it as a second transition (IMPLEMENTATION DEFINED per §2.2.2). |

> B's device instance is parameterized `TINIT(8)` rather than Part A's `TINIT(4)`:
> behaviour 3 needs `PREQ` **sampled** inside the window, and with
> `TINIT == SYNC_STAGES + 1` there is no room to raise it after reset release and
> still be observed in time. Devices publish their own `tinit`, so two instances
> differing here is exactly what the spec expects.

---

## 3. `pchannel_monitor_negtest.sv` — monitor non-vacuity

No DUT. The "control signals" here *are* the protocol wires, driven directly to
construct one deliberate violation of each rule. The phase name is the rule under
test; each phase returns to a legal idle first so violations stay isolated.

| Phase | Illegal edge constructed | Rule |
|---|---|:---:|
| Legal sequences | full accepted and denied handshakes | *(must stay silent)* |
| PR1 | `PREQ` rises from `P_COMPLETE` (`PACCEPT` HIGH) | PR1 |
| PR2 | `PREQ` falls with both acknowledges LOW | PR2 |
| PR3 | `PSTATE` changes mid-request (`P_REQUEST`) | PR3 |
| PR4 | `PACCEPT` rises with `PREQ` LOW | PR4 |
| PR5 | `PACCEPT` falls with `PREQ` still HIGH | PR5 |
| PR6 | `PDENY` rises with `PREQ` LOW | PR6 |
| PR7 | `PDENY` falls with `PREQ` still HIGH | PR7 |
| PR8 | `PACCEPT` and `PDENY` both HIGH | PR8 |
| PR9 | `drst_n` asserted from `P_REQUEST` | PR9 |
| PR10 | `crst_n` asserted from `P_REQUEST` | PR10 |
| PR11 | `PACCEPT` HIGH while held in device reset | PR11 |
| Legal afterwards | a clean handshake again | *(must stay silent)* |

Each phase asserts only that the violation count **grew**. Some illegal wire
states inherently trip more than one rule at once — `PACCEPT` HIGH during reset
violates PR11 and PR4 together — so demanding an exact delta would assert an
implementation detail of the monitor rather than its behaviour.
