`timescale 1ns/1ps
// Core P-Channel protocol testbench.
//
// Two independent sections, both watched by a bound pchannel_monitor:
//
//   Part A -- a real pchannel_controller / pchannel_device pair on unrelated
//   clocks (10.0 ns controller, 13.7 ns device). Covers the accepted and denied
//   handshakes, the PSTATE restore-on-denial rule, multi-state transitions
//   without returning to a common state, and the PACTIVE-led policy.
//
//   Part B -- a SECOND device instance driven by scripted stimulus standing in
//   for a controller. This exists because the three initialization behaviours
//   of Section 2.2.2 cannot all be produced by pchannel_controller: behaviour 2
//   requires PREQ to be HIGH *before* reset deassertion, and our controller
//   resets PREQ LOW by design (that is behaviour 1). Driving the device
//   directly is the only way to prove it handles all three.
//
//   T0  Reset and bring-up; PSTATE captured at reset deassertion.
//   T1  Accepted transition (Figure 2-10).
//   T2  Denied transition (Figure 2-11), incl. PSTATE restored to current state.
//   T3  Multiple transitions without passing through a common state (Figure 2-15).
//   T4  PACTIVE-led transition (Section 2.2.3 minimum-state rule).
//   T5  Explicit request BELOW the PACTIVE floor is still issued (Section 2.2.3
//       "the controller can make any policy decision irrespective of PACTIVE").
//   B1  Init behaviour 1: PREQ LOW at reset deassertion, controller waits tinit.
//   B2  Init behaviour 2: PREQ HIGH before reset deassertion -- must be accepted
//       even with deny asserted (force-accept during tinit).
//   B3  Init behaviour 3: PREQ HIGH during tinit with PSTATE unchanged.
//
// STIMULUS TIMING CONVENTION
// Every DUT input is driven, and every DUT output sampled, on the NEGEDGE of
// the relevant clock, so the sampling posedge lands in the middle of the data
// eye. Driving on the posedge would put the input transition and the sampling
// edge at the same simulation time, leaving the outcome dependent on
// event-ordering inside the simulator and making waveforms unreadable.
//
// This matters more than usual here: PSTATE is the one P-Channel signal the
// device does NOT synchronize (Section 3.2), so it is captured directly by a
// PREQ-strobed register. A PSTATE transition landing on the capture edge is
// precisely the failure this convention keeps out of the testbench.

module pchannel_tb;

  import pchannel_pkg::*;

  localparam int unsigned PSTATE_W  = 2;
  localparam int unsigned PACTIVE_W = 3;
  localparam int unsigned TINIT     = 4;

  // Example-style encoding, local to this testbench (the RTL under test is
  // generic and attaches no meaning to these values).
  localparam logic [PSTATE_W-1:0] S_OFF = 2'd0;
  localparam logic [PSTATE_W-1:0] S_RET = 2'd1;
  localparam logic [PSTATE_W-1:0] S_ON  = 2'd2;

  // ---- Clocks: controller and device are unrelated (Section 3.2) ----
  logic cclk = 1'b0, dclk = 1'b0, mclk = 1'b0;
  always #5.00 cclk = ~cclk;
  always #6.85 dclk = ~dclk;
  always #0.50 mclk = ~mclk;

  logic crst_n = 1'b0;

  logic drst_n = 1'b0;
  // Monitor's own operating reset: deasserted once, early, and never again --
  // independent of the domain resets so the monitor's pipeline survives (and
  // can therefore observe) later domain-reset events.
  logic mrst_n = 1'b0;
  initial begin mrst_n = 1'b0; #1 mrst_n = 1'b1; end

  // ---- Part A: real controller + device pair ----
  logic [PSTATE_W-1:0]  pstate;
  logic                 preq, paccept, pdeny;
  logic [PACTIVE_W-1:0] pactive;

  logic [PSTATE_W-1:0]  req_state = S_ON;
  logic                 req_valid = 1'b0;
  logic                 enb_pactive = 1'b0;
  logic [PACTIVE_W-1:0] dev_pactive = 3'b000;
  logic                 tb_deny = 1'b0;

  logic [PSTATE_W-1:0] ctrl_cur, dev_cur, dev_req;
  logic dev_req_valid, dev_init, ctrl_init, ctrl_stable, xfer_done, xfer_denied;

  int unsigned viol_a, viol_b;
  int unsigned tb_errors = 0, checks = 0;

  pchannel_controller #(
    .PSTATE_W(PSTATE_W), .PACTIVE_W(PACTIVE_W), .SYNC_STAGES(2),
    .RESET_STATE(S_ON), .TINIT_WAIT(16)
  ) u_ctrl (
    .clk(cclk), .rst_n(crst_n),
    .pstate(pstate), .preq(preq), .paccept(paccept), .pdeny(pdeny), .pactive(pactive),
    .req_state(req_state), .req_valid(req_valid),
    .enb_pactive_led_transition(enb_pactive),
    .cur_state(ctrl_cur), .dev_stable(ctrl_stable), .ctrl_init_done(ctrl_init),
    .xfer_done(xfer_done), .xfer_denied(xfer_denied)
  );

  pchannel_device #(
    .PSTATE_W(PSTATE_W), .PACTIVE_W(PACTIVE_W), .SYNC_STAGES(2), .TINIT(TINIT)
  ) u_dev (
    .clk(dclk), .rst_n(drst_n),
    .pstate(pstate), .preq(preq), .paccept(paccept), .pdeny(pdeny), .pactive(pactive),
    .dev_pactive(dev_pactive), .dev_req_state(dev_req), .dev_req_valid(dev_req_valid),
    .dev_deny(tb_deny), .dev_busy(1'b0), .dev_cur_state(dev_cur), .dev_init_done(dev_init)
  );

  // ---------------------------------------------------------------------------
  // A second, dedicated pair for PSTATE_LEAD_CYCLES
  // ---------------------------------------------------------------------------
  // Figure 3-3 allows the controller to drive PSTATE ahead of raising PREQ, and
  // PSTATE_LEAD_CYCLES sets how far ahead. It had never been elaborated at
  // anything but 0 -- a configuration option with no instance behind it, the
  // same category the PPU's Chapter 7 options were in before `make ppucfg`.
  //
  // A separate pair rather than a parameter change on u_ctrl above, because
  // changing the lead would shift the timing of every existing phase. This one
  // is driven only by the lead measurement at the end.
  localparam int unsigned LEAD_N = 5;

  logic [PSTATE_W-1:0] l_pstate;
  logic                l_preq, l_paccept, l_pdeny;
  logic [PACTIVE_W-1:0] l_pactive;
  logic [PSTATE_W-1:0] l_req_state = S_ON, l_ctrl_cur, l_dev_cur, l_dev_req;
  logic                l_req_valid = 1'b0, l_dev_req_valid, l_dev_init;
  logic                l_ctrl_init, l_ctrl_stable, l_xfer_done, l_xfer_denied;
  int unsigned         viol_lead;

  pchannel_controller #(
    .PSTATE_W(PSTATE_W), .PACTIVE_W(PACTIVE_W), .SYNC_STAGES(2),
    .RESET_STATE(S_ON), .TINIT_WAIT(16), .PSTATE_LEAD_CYCLES(LEAD_N)
  ) u_ctrl_lead (
    .clk(cclk), .rst_n(crst_n),
    .pstate(l_pstate), .preq(l_preq), .paccept(l_paccept), .pdeny(l_pdeny),
    .pactive(l_pactive),
    .req_state(l_req_state), .req_valid(l_req_valid),
    .enb_pactive_led_transition(1'b0),
    .cur_state(l_ctrl_cur), .dev_stable(l_ctrl_stable), .ctrl_init_done(l_ctrl_init),
    .xfer_done(l_xfer_done), .xfer_denied(l_xfer_denied)
  );

  pchannel_device #(
    .PSTATE_W(PSTATE_W), .PACTIVE_W(PACTIVE_W), .SYNC_STAGES(2), .TINIT(TINIT)
  ) u_dev_lead (
    .clk(dclk), .rst_n(drst_n),
    .pstate(l_pstate), .preq(l_preq), .paccept(l_paccept), .pdeny(l_pdeny),
    .pactive(l_pactive),
    .dev_pactive('0), .dev_req_state(l_dev_req), .dev_req_valid(l_dev_req_valid),
    .dev_deny(1'b0), .dev_busy(1'b0), .dev_cur_state(l_dev_cur), .dev_init_done(l_dev_init)
  );

  // The lead pair gets its own monitor: a lead that broke the protocol (PSTATE
  // moving outside P_STABLE, rule PR3) must be caught, not just mis-timed.
  pchannel_monitor #(.PSTATE_W(PSTATE_W)) u_mon_lead (
    .clk(mclk), .rst_n(mrst_n), .crst_n(crst_n), .drst_n(drst_n),
    .preq(l_preq), .paccept(l_paccept), .pdeny(l_pdeny), .pstate(l_pstate),
    .violations(viol_lead)
  );

  // Measure the gap: controller clocks from PSTATE changing to PREQ rising.
  //
  // `lead_go` is not decoration. Without it the observer armed on the FIRST
  // PSTATE change of the run -- the settle out of reset, where l_pstate_d is
  // still X -- and then counted all the way through tinit to the eventual
  // request, reporting 153 cycles instead of 6. Holding it clear until the TB
  // is about to issue the request gives the measurement a known baseline.
  bit          lead_go = 1'b0;
  int unsigned lead_cycles = 0;
  bit          lead_armed = 1'b0, lead_seen = 1'b0;
  logic [PSTATE_W-1:0] l_pstate_d;
  always @(posedge cclk) begin
    if (!crst_n || !lead_go) begin
      lead_armed <= 1'b0; lead_seen <= 1'b0; lead_cycles <= 0;
      l_pstate_d <= l_pstate;
    end else begin
      if (!lead_seen) begin
        if (lead_armed) begin
          if (l_preq) lead_seen <= 1'b1;
          else        lead_cycles <= lead_cycles + 1;
        end else if (l_pstate !== l_pstate_d) begin
          lead_armed  <= 1'b1;
          lead_cycles <= 1;          // the cycle PSTATE moved counts as lead 1
        end
      end
      l_pstate_d <= l_pstate;
    end
  end

  pchannel_monitor #(.PSTATE_W(PSTATE_W)) u_mon (
    .clk(mclk), .rst_n(mrst_n), .crst_n(crst_n), .drst_n(drst_n),
    .preq(preq), .paccept(paccept), .pdeny(pdeny), .pstate(pstate), .violations(viol_a)
  );

  // ---- Part B: device alone, scripted controller stimulus ----
  logic                 b_rst_n = 1'b0;
  logic [PSTATE_W-1:0]  b_pstate = S_ON;
  logic                 b_preq = 1'b0;
  logic                 b_paccept, b_pdeny;
  logic [PACTIVE_W-1:0] b_pactive;
  logic                 b_deny = 1'b0;
  logic [PSTATE_W-1:0]  b_req, b_cur;
  logic                 b_req_valid, b_init;

  // A longer tinit than the Part A device, deliberately: behaviour 3 requires
  // PREQ to be SAMPLED inside the window, and with TINIT == SYNC_STAGES + 1
  // there is no room to raise it after reset release and still be observed in
  // time. Devices publish their own tinit, so two instances differing here is
  // exactly what the spec expects.
  pchannel_device #(
    .PSTATE_W(PSTATE_W), .PACTIVE_W(PACTIVE_W), .SYNC_STAGES(2), .TINIT(8)
  ) u_dev_b (
    .clk(dclk), .rst_n(b_rst_n),
    .pstate(b_pstate), .preq(b_preq), .paccept(b_paccept), .pdeny(b_pdeny),
    .pactive(b_pactive), .dev_pactive(3'b000),
    .dev_req_state(b_req), .dev_req_valid(b_req_valid), .dev_deny(b_deny), .dev_busy(1'b0),
    .dev_cur_state(b_cur), .dev_init_done(b_init)
  );

  pchannel_monitor #(.PSTATE_W(PSTATE_W)) u_mon_b (
    .clk(mclk), .rst_n(mrst_n), .crst_n(1'b1), .drst_n(b_rst_n),
    .preq(b_preq), .paccept(b_paccept), .pdeny(b_pdeny), .pstate(b_pstate),
    .violations(viol_b)
  );

  // ---- Current test phase, as ASCII in the waveform ----
  // VCD has no string type, so the phase name lives in a packed byte vector:
  // dumpers emit that as an ordinary reg, and GTKWave renders it as text once
  // the trace's Data Format is set to ASCII. A SystemVerilog `string` will not
  // survive the dump -- Icarus will not even cast one into a packed vector.
  //
  // Sized to hold the longest phase name below without truncation. That matters:
  // an over-long name assigned straight through $sformat would overflow and keep
  // the RIGHTMOST characters, silently dropping the "T4"/"B2" prefix that
  // identifies the test. set_phase truncates from the right instead.
  localparam int unsigned PHASE_CHARS = 56;
  reg [8*PHASE_CHARS-1:0] test_phase;

  // Single source of truth for the phase: drives the waveform signal and prints
  // the log banner together, so the two can never disagree.
  // tinit measurement. AMBA LPI Section 2.2.2 gives the controller a tinit
  // period after reset during which it must not issue a request; TINIT_WAIT is
  // that period in controller clocks. B1 below checks the device SIDE of tinit
  // -- that PSTATE is captured and denial suppressed -- but nothing measured how
  // long the controller actually waits, so shortening TINIT_WAIT to a single
  // cycle went unnoticed. Counted from reset release to the first PREQ rise.
  int unsigned tinit_cycles = 0;
  bit          tinit_done   = 1'b0;
  always @(posedge cclk) if (crst_n && !tinit_done) begin
    if (preq) tinit_done <= 1'b1;
    else      tinit_cycles <= tinit_cycles + 1;
  end

  task automatic set_phase(input string name);
    begin
      if (name.len() > PHASE_CHARS)
        $sformat(test_phase, "%-56s", name.substr(0, PHASE_CHARS-1));
      else
        $sformat(test_phase, "%-56s", name);
      $display("\n[%0t] ========== %0s ==========", $time, name);
    end
  endtask

  // ---- Helpers ----
  function automatic pch_state_e cur_if_state();
    return pch_decode(drst_n, preq, paccept, pdeny);
  endfunction

  task automatic chk(input bit cond, input string tag);
    begin
      checks++;
      if (cond) $display("[%0t]  ok  %s", $time, tag);
      else begin
        tb_errors++;
        $display("[%0t] ERR  %s", $time, tag);
      end
    end
  endtask

  task automatic wait_if_state(input pch_state_e exp, input int limit_ns, input string tag);
    time t0; bit hit;
    begin
      t0 = $time; hit = 1'b0; checks++;
      while (!hit) begin
        if (cur_if_state() === exp) begin
          hit = 1'b1;
          $display("[%0t]  ok  %s: reached %s", $time, tag, pch_name(exp));
        end else if ($time - t0 > limit_ns * 1000) begin
          tb_errors++;
          $display("[%0t] ERR  %s: timeout waiting for %s (saw %s)",
                   $time, tag, pch_name(exp), pch_name(cur_if_state()));
          hit = 1'b1;
        end else begin
          #1;
        end
      end
    end
  endtask

  // Wait for the pair to settle back to P_STABLE with the controller idle.
  task automatic wait_settled(input int limit_ns, input string tag);
    time t0; bit hit;
    begin
      t0 = $time; hit = 1'b0; checks++;
      while (!hit) begin
        if (cur_if_state() === P_STABLE && ctrl_stable) begin
          hit = 1'b1;
          $display("[%0t]  ok  %s: settled in P_STABLE", $time, tag);
        end else if ($time - t0 > limit_ns * 1000) begin
          tb_errors++;
          $display("[%0t] ERR  %s: timeout settling (saw %s, ctrl_stable=%0b)",
                   $time, tag, pch_name(cur_if_state()), ctrl_stable);
          hit = 1'b1;
        end else #1;
      end
    end
  endtask

  // Wait for the controller to report the transaction resolved. Sampling the
  // xfer_done/xfer_denied pulses is what makes this reliable: polling for
  // "P_STABLE and idle" instead would match the state the interface is ALREADY
  // in before the request has had time to start.
  task automatic wait_xfer(input int limit_ns, input string tag);
    time t0;
    bit  hit;
    begin
      t0 = $time; hit = 1'b0; checks++;
      while (!hit) begin
        @(negedge cclk);
        if (xfer_done) begin
          hit = 1'b1;
          $display("[%0t]  ok  %s: transition accepted", $time, tag);
        end else if (xfer_denied) begin
          hit = 1'b1;
          $display("[%0t]  ok  %s: transition denied", $time, tag);
        end else if (($time - t0) > limit_ns * 1000) begin
          hit = 1'b1;
          tb_errors++;
          $display("[%0t] ERR  %s: timeout waiting for completion (state %s)",
                   $time, tag, pch_name(cur_if_state()));
        end
      end
    end
  endtask

  // Issue an explicit request and wait for it to resolve.
  task automatic request(input logic [PSTATE_W-1:0] s, input int limit_ns, input string tag);
    begin
      @(negedge cclk); req_state <= s; req_valid <= 1'b1;
      wait_xfer(limit_ns, tag);
      @(negedge cclk); req_valid <= 1'b0;
      @(negedge cclk);
    end
  endtask

  // ---- Part B helpers: scripted controller stimulus against u_dev_b ----
  task automatic b_wait_ack(input int limit_ns, input string tag);
    time t0;
    bit  hit;
    begin
      t0 = $time; hit = 1'b0;
      while (!hit) begin
        @(negedge dclk);
        if (b_paccept || b_pdeny) hit = 1'b1;
        else if (($time - t0) > limit_ns * 1000) begin
          hit = 1'b1;
          tb_errors++;
          $display("[%0t] ERR  %s: timeout waiting for PACCEPT/PDENY", $time, tag);
        end
      end
    end
  endtask

  task automatic b_close(input int limit_ns, input string tag);
    time t0;
    bit  hit;
    begin
      @(negedge dclk); b_preq <= 1'b0;
      t0 = $time; hit = 1'b0;
      while (!hit) begin
        @(negedge dclk);
        if (!b_paccept && !b_pdeny) hit = 1'b1;
        else if (($time - t0) > limit_ns * 1000) begin
          hit = 1'b1;
          tb_errors++;
          $display("[%0t] ERR  %s: timeout closing handshake", $time, tag);
        end
      end
    end
  endtask

  task automatic b_handshake(input logic [PSTATE_W-1:0] s, input int limit_ns, input string tag);
    begin
      @(negedge dclk); b_pstate <= s;
      @(negedge dclk); b_preq   <= 1'b1;
      b_wait_ack(limit_ns, tag);
      b_close(limit_ns, tag);
    end
  endtask

  // ---------------------------------------------------------------------------
  initial begin
    $dumpfile("pchannel_tb.vcd");
    $dumpvars(0, pchannel_tb);

    // =========================================================================
    set_phase("T0: Reset and Bring-Up");
    $display("[%0t]   PSTATE is held at ON through reset; the device must capture", $time);
    $display("[%0t]   it within tinit (Section 2.2.2 device initialization).", $time);
    crst_n = 1'b0; drst_n = 1'b0; b_rst_n = 1'b0;
    #50;
    chk(paccept === 1'b0 && pdeny === 1'b0, "T0.reset: PACCEPT & PDENY LOW in reset");
    @(negedge cclk); crst_n = 1'b1;
    @(negedge dclk); drst_n = 1'b1;
    // Wait out both init periods.
    wait (ctrl_init === 1'b1 && dev_init === 1'b1);
    chk(dev_cur === S_ON,  "T0.init: device captured PSTATE=ON at reset deassertion");
    chk(ctrl_cur === S_ON, "T0.init: controller current state is ON");
    wait_settled(200, "T0.bringup");

    // =========================================================================
    set_phase("T1: Accepted Transition ON -> RET");
    $display("[%0t]   Figure 2-10: P_STABLE -> P_REQUEST -> P_ACCEPT -> P_COMPLETE.", $time);
    tb_deny = 1'b0;
    fork
      wait_if_state(P_REQUEST, 200, "T1.request");
      request(S_RET, 400, "T1.accept");
    join
    chk(ctrl_cur === S_RET, "T1: controller committed to RET");
    chk(dev_cur  === S_RET, "T1: device committed to RET");
    chk(pstate   === S_RET, "T1: PSTATE holds the new current state");

    // =========================================================================
    set_phase("T2: Denied Transition");
    $display("[%0t]   Figure 2-11: P_REQUEST -> P_DENIED -> P_CONTINUE, and the", $time);
    $display("[%0t]   controller must restore PSTATE to the current state at T4.", $time);
    tb_deny = 1'b1;
    fork
      wait_if_state(P_DENIED, 300, "T2.denied");
      request(S_OFF, 400, "T2.resolve");
    join
    chk(ctrl_cur === S_RET, "T2: controller state unchanged after denial");
    chk(dev_cur  === S_RET, "T2: device remained in its pre-transition state");
    chk(pstate   === S_RET, "T2: PSTATE restored to the current state (rule 3)");
    tb_deny = 1'b0;

    // =========================================================================
    set_phase("T3: Multiple Transitions (Figure 2-15)");
    $display("[%0t]   RET -> OFF -> ON without returning to a common state.", $time);
    request(S_OFF, 400, "T3.to-OFF");
    chk(ctrl_cur === S_OFF && dev_cur === S_OFF, "T3: reached OFF");
    request(S_ON, 400, "T3.to-ON");
    chk(ctrl_cur === S_ON && dev_cur === S_ON, "T3: reached ON directly from OFF");

    // =========================================================================
    set_phase("T4: PACTIVE-Led Transition");
    $display("[%0t]   Section 2.2.3: the most significant PACTIVE bit HIGH is the", $time);
    $display("[%0t]   minimum state required; the controller must move up to it.", $time);
    request(S_OFF, 400, "T4.setup-OFF");
    chk(ctrl_cur === S_OFF, "T4: parked at OFF with PACTIVE all LOW");
    enb_pactive = 1'b1;
    @(negedge dclk); dev_pactive <= 3'b100;   // PACTIVE[2] -> minimum state is ON
    wait_xfer(600, "T4.pactive-led");
    chk(ctrl_cur === S_ON, "T4: controller auto-requested ON from the PACTIVE floor");
    chk(dev_cur  === S_ON, "T4: device reached ON");

    // =========================================================================
    set_phase("T5: Explicit Request Below the PACTIVE Floor");
    $display("[%0t]   PACTIVE[2] stays HIGH (floor = ON) but the PM policy asks for", $time);
    $display("[%0t]   RET anyway. The spec permits it -- the controller may make any", $time);
    $display("[%0t]   policy decision irrespective of PACTIVE; the DEVICE is what", $time);
    $display("[%0t]   denies inappropriate requests. Here the device accepts.", $time);
    enb_pactive = 1'b0;   // stop the floor from immediately pulling it back up
    request(S_RET, 400, "T5.below-floor");
    chk(ctrl_cur === S_RET, "T5: below-floor request was issued and accepted");
    chk(dev_pactive[2] === 1'b1, "T5: PACTIVE floor was still ON throughout");

    chk(viol_a == 0, "MONITOR A: zero protocol-rule violations");

    // =========================================================================
    set_phase("B-1: PSTATE leads PREQ by PSTATE_LEAD_CYCLES (Figure 3-3)");
    $display("[%0t]   AMBA LPI Figure 3-3 lets the controller drive PSTATE ahead", $time);
    $display("[%0t]   of raising PREQ. PSTATE_LEAD_CYCLES sets how far ahead, and", $time);
    $display("[%0t]   until now it had never been elaborated at anything but 0 --", $time);
    $display("[%0t]   an option with no instance behind it, so neither the lead", $time);
    $display("[%0t]   nor the counter that produces it was ever exercised.", $time);
    $display("[%0t]   u_ctrl_lead is built with PSTATE_LEAD_CYCLES=%0d.", $time, LEAD_N);

    // Ask the lead controller for a transition and let it run to completion.
    @(negedge cclk) lead_go = 1'b1;          // baseline the observer first
    @(negedge cclk) begin l_req_state = S_RET; l_req_valid = 1'b1; end
    @(negedge cclk) l_req_valid = 1'b0;
    #4000;

    chk(lead_seen, "B-1: the lead controller did raise PREQ");
    $display("[%0t]   PSTATE led PREQ by %0d controller clocks (expected %0d)",
             $time, lead_cycles, LEAD_N + 1);
    chk(lead_cycles == LEAD_N + 1,
        "B-1: the lead is exactly PSTATE_LEAD_CYCLES + 1");
    chk(viol_lead == 0,
        "B-1: and the lead broke no P-Channel rule (PSTATE moved only in P_STABLE)");
    chk(l_dev_cur === S_RET, "B-1: the device committed the requested state");

    // =========================================================================
    set_phase("B0: the controller honours its tinit period");
    $display("[%0t]   AMBA LPI Section 2.2.2: the controller must not issue a", $time);
    $display("[%0t]   request during tinit. u_ctrl is built with TINIT_WAIT=16,", $time);
    $display("[%0t]   so PREQ must stay LOW for at least that many controller", $time);
    $display("[%0t]   clocks after reset release.", $time);
    $display("[%0t]   B1 below covers the DEVICE side of tinit -- PSTATE capture", $time);
    $display("[%0t]   and suppressed denial. The controller's own wait was never", $time);
    $display("[%0t]   measured, so a one-cycle tinit passed the whole suite.", $time);
    chk(tinit_done, "B0: the controller did eventually issue a request");
    $display("[%0t]   PREQ stayed LOW for %0d controller clocks", $time, tinit_cycles);
    chk(tinit_cycles >= 16, "B0: PREQ held LOW for at least TINIT_WAIT cycles");

    // =========================================================================
    set_phase("B1: Init Behaviour 1 (PREQ LOW at reset exit)");
    $display("[%0t]   Controller waits until tinit expires before requesting.", $time);
    b_rst_n = 1'b0; b_preq = 1'b0; b_pstate = S_ON; b_deny = 1'b0;
    #40;
    @(negedge dclk); b_rst_n = 1'b1;
    wait (b_init === 1'b1);
    chk(b_cur === S_ON, "B1: device captured PSTATE=ON during tinit");
    b_deny = 1'b1;   // after tinit, denial is live again
    b_handshake(S_RET, 400, "B1.deny-after-init");
    chk(b_cur === S_ON, "B1: request denied after tinit (deny is honoured)");
    b_deny = 1'b0;

    // =========================================================================
    set_phase("B2: Init Behaviour 2 (PREQ HIGH before reset exit)");
    $display("[%0t]   Section 2.2.2: 'The device must accept any request made at", $time);
    $display("[%0t]   reset exit or during tinit' -- so deny is SUPPRESSED here even", $time);
    $display("[%0t]   though b_deny is asserted.", $time);
    // Return to P_STABLE before asserting reset (Section 2.2.2 / monitor PR9).
    @(negedge dclk); b_preq = 1'b0;
    #50;
    b_rst_n = 1'b0;
    #40;
    b_pstate = S_RET;
    b_deny   = 1'b1;          // would deny, but must be ignored during tinit
    @(negedge dclk); b_preq = 1'b1;   // PREQ HIGH *before* reset deassertion
    #30;
    @(negedge dclk); b_rst_n = 1'b1;
    // The device must complete this transition and accept it.
    b_wait_ack(400, "B2");
    chk(b_paccept === 1'b1, "B2: device ACCEPTED despite deny (force-accept at reset exit)");
    b_close(400, "B2");
    chk(b_cur === S_RET, "B2: device committed to the requested state");
    chk(b_init === 1'b1, "B2: completing a transition ends the init period");
    b_deny = 1'b0;

    // =========================================================================
    set_phase("B3: Init Behaviour 3 (PREQ HIGH during tinit)");
    $display("[%0t]   PSTATE unchanged from its reset-deassertion value. This device", $time);
    $display("[%0t]   treats it as a second transition (IMPLEMENTATION DEFINED).", $time);
    #50;
    b_rst_n = 1'b0;
    #40;
    b_pstate = S_OFF;
    b_deny   = 1'b1;          // again must be ignored
    @(negedge dclk); b_rst_n = 1'b1;
    // Raise PREQ immediately after reset deassertion so it is SAMPLED well
    // inside tinit (TINIT=8, SYNC_STAGES=2 -> observed around cycle 3).
    @(negedge dclk); b_preq = 1'b1;
    b_wait_ack(400, "B3");
    chk(b_paccept === 1'b1, "B3: device accepted a request raised during tinit");
    b_close(400, "B3");
    chk(b_cur === S_OFF, "B3: device committed to the in-tinit request");
    b_deny = 1'b0;

    #200;
    chk(viol_b == 0, "MONITOR B: zero protocol-rule violations");

    // =========================================================================
    $display("\n==================== P-CHANNEL SUMMARY ====================");
    $display(" checks run          : %0d", checks);
    $display(" testbench errors    : %0d", tb_errors);
    $display(" monitor violations A: %0d", viol_a);
    $display(" monitor violations B: %0d", viol_b);
    $display(" RESULT: %s", (tb_errors == 0 && viol_a == 0 && viol_b == 0) ? "PASS" : "FAIL");
    $display("===========================================================\n");
    $finish;
  end

  initial begin
    #20_000_000;
    $display("GLOBAL TIMEOUT");
    $finish;
  end

endmodule
