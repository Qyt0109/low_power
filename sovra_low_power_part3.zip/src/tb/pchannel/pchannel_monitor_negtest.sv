`timescale 1ns/1ps
// Negative test for pchannel_monitor -- proves the checker is not vacuous.
//
// There is no DUT here. The testbench drives the interface wires directly,
// first through legal sequences (the monitor must stay silent) and then through
// one deliberate violation of each rule (the monitor must fire). Without this,
// a "zero violations" result from the functional testbenches would be
// worthless: a checker that never fires reports zero on everything.
//
// Each sub-test starts from a known legal idle so the violations stay isolated,
// and asserts only that the count GREW. Some illegal wire states inherently
// trip more than one rule at once -- driving PACCEPT HIGH while the device is
// in reset violates both PR11 and PR4 -- so demanding an exact delta would be
// asserting an implementation detail of the monitor rather than its behaviour.
// The monitor's own log lines identify which rule fired.

module pchannel_monitor_negtest;

  localparam int unsigned PSTATE_W = 2;

  localparam logic [PSTATE_W-1:0] ST_A = 2'd1;
  localparam logic [PSTATE_W-1:0] ST_B = 2'd2;

  logic mclk = 1'b0;
  always #0.5 mclk = ~mclk;

  logic mrst_n = 1'b0;
  logic crst_n = 1'b1;
  logic drst_n = 1'b1;

  logic                preq    = 1'b0;
  logic                paccept = 1'b0;
  logic                pdeny   = 1'b0;
  logic [PSTATE_W-1:0] pstate  = ST_A;

  int unsigned viol;
  int unsigned tb_errors = 0, checks = 0;

  pchannel_monitor #(.PSTATE_W(PSTATE_W)) u_mon (
    .clk(mclk), .rst_n(mrst_n), .crst_n(crst_n), .drst_n(drst_n),
    .preq(preq), .paccept(paccept), .pdeny(pdeny), .pstate(pstate),
    .violations(viol)
  );

  // ---- Current test phase, as ASCII in the waveform ----
  // VCD has no string type, so the phase name lives in a packed byte vector:
  // dumpers emit that as an ordinary reg, and GTKWave renders it as text once
  // the trace's Data Format is set to ASCII. A SystemVerilog `string` will not
  // survive the dump -- Icarus will not even cast one into a packed vector.
  localparam int unsigned PHASE_CHARS = 56;
  reg [8*PHASE_CHARS-1:0] test_phase;

  // Single source of truth for the phase: drives the waveform signal and prints
  // the log banner together, so the two can never disagree. Over-long names are
  // truncated from the right, because letting $sformat overflow would instead
  // drop the leading characters -- the rule name that identifies the test.
  task automatic set_phase(input string name);
    begin
      if (name.len() > PHASE_CHARS)
        $sformat(test_phase, "%-56s", name.substr(0, PHASE_CHARS-1));
      else
        $sformat(test_phase, "%-56s", name);
      $display("\n[%0t] ---------- %0s ----------", $time, name);
    end
  endtask

  // Drive a wire state and let it settle through the monitor's two-deep
  // sample pipeline before the next change.
  task automatic drive(input logic req, input logic acc, input logic den,
                       input logic [PSTATE_W-1:0] st);
    begin
      @(negedge mclk);
      preq = req; paccept = acc; pdeny = den; pstate = st;
      repeat (4) @(posedge mclk);
    end
  endtask

  // Return the interface to the all-LOW idle by the legal route, whatever it is
  // currently showing. Used between sub-tests so each violation is isolated.
  task automatic reset_idle();
    begin
      @(negedge mclk);
      drst_n = 1'b0; crst_n = 1'b0;
      preq = 1'b0; paccept = 1'b0; pdeny = 1'b0; pstate = ST_A;
      repeat (4) @(posedge mclk);
      @(negedge mclk);
      drst_n = 1'b1; crst_n = 1'b1;
      repeat (4) @(posedge mclk);
    end
  endtask

  int unsigned viol_before;

  task automatic expect_quiet(input string tag);
    begin
      checks++;
      if (viol == viol_before) $display("[%0t]  ok  %s: monitor stayed silent (legal)", $time, tag);
      else begin
        tb_errors++;
        $display("[%0t] ERR  %s: monitor fired on a LEGAL sequence (%0d -> %0d)",
                 $time, tag, viol_before, viol);
      end
    end
  endtask

  task automatic expect_fire(input string tag);
    begin
      checks++;
      if (viol > viol_before) $display("[%0t]  ok  %s: monitor fired (%0d -> %0d)", $time, tag, viol_before, viol);
      else begin
        tb_errors++;
        $display("[%0t] ERR  %s: monitor MISSED the violation (still %0d)", $time, tag, viol);
      end
    end
  endtask

  initial begin
    $dumpfile("pchannel_monitor_negtest.vcd");
    $dumpvars(0, pchannel_monitor_negtest);

    #2 mrst_n = 1'b1;
    repeat (4) @(posedge mclk);

    // =========================================================================
    set_phase("Legal sequences: the monitor must stay silent");
    viol_before = viol;
    // Accepted handshake: P_STABLE -> P_REQUEST -> P_ACCEPT -> P_COMPLETE -> P_STABLE
    drive(1'b0, 1'b0, 1'b0, ST_B);   // PSTATE change while all LOW  (rule 3 case 1)
    drive(1'b1, 1'b0, 1'b0, ST_B);   // PREQ rise, acks LOW          (PR1 ok)
    drive(1'b1, 1'b1, 1'b0, ST_B);   // PACCEPT rise, PREQ HIGH      (PR4 ok)
    drive(1'b0, 1'b1, 1'b0, ST_B);   // PREQ fall, PACCEPT HIGH      (PR2 ok)
    drive(1'b0, 1'b0, 1'b0, ST_B);   // PACCEPT fall, PREQ LOW       (PR5 ok)
    expect_quiet("legal.accept");

    viol_before = viol;
    // Denied handshake, including the PSTATE restore that rule 3 case 2 exists for.
    drive(1'b1, 1'b0, 1'b0, ST_A);   // PSTATE changed in P_STABLE, then PREQ rise
    drive(1'b1, 1'b0, 1'b1, ST_A);   // PDENY rise, PREQ HIGH, PACCEPT LOW (PR6 ok)
    drive(1'b0, 1'b0, 1'b1, ST_B);   // PREQ fall + PSTATE restore from P_DENIED
                                     //   (PR2 ok via the deny case, rule 3 case 2 ok)
    drive(1'b0, 1'b0, 1'b0, ST_B);   // PDENY fall, PREQ LOW, PACCEPT LOW  (PR7 ok)
    expect_quiet("legal.deny");

    // =========================================================================
    set_phase("PR1: PREQ rose outside P_STABLE");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);
    drive(1'b1, 1'b1, 1'b0, ST_A);
    drive(1'b0, 1'b1, 1'b0, ST_A);   // now in P_COMPLETE, PACCEPT HIGH
    viol_before = viol;
    drive(1'b1, 1'b1, 1'b0, ST_A);   // PREQ rises with PACCEPT HIGH -> PR1
    expect_fire("PR1");

    // =========================================================================
    set_phase("PR2: PREQ fell with both acks LOW");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);   // P_REQUEST
    viol_before = viol;
    drive(1'b0, 1'b0, 1'b0, ST_A);   // PREQ falls with no acknowledge -> PR2
    expect_fire("PR2");

    // =========================================================================
    set_phase("PR3: PSTATE changed outside P_STABLE/P_DENIED");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);   // P_REQUEST
    viol_before = viol;
    drive(1'b1, 1'b0, 1'b0, ST_B);   // PSTATE changes mid-request -> PR3
    expect_fire("PR3");

    // =========================================================================
    set_phase("PR4: PACCEPT rose with PREQ LOW");
    reset_idle();
    viol_before = viol;
    drive(1'b0, 1'b1, 1'b0, ST_A);   // PACCEPT rises unsolicited -> PR4
    expect_fire("PR4");

    // =========================================================================
    set_phase("PR5: PACCEPT fell with PREQ HIGH");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);
    drive(1'b1, 1'b1, 1'b0, ST_A);   // P_ACCEPT
    viol_before = viol;
    drive(1'b1, 1'b0, 1'b0, ST_A);   // PACCEPT falls while PREQ still HIGH -> PR5
    expect_fire("PR5");

    // =========================================================================
    set_phase("PR6: PDENY rose with PREQ LOW");
    reset_idle();
    viol_before = viol;
    drive(1'b0, 1'b0, 1'b1, ST_A);   // PDENY rises unsolicited -> PR6
    expect_fire("PR6");

    // =========================================================================
    set_phase("PR7: PDENY fell with PREQ HIGH");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);
    drive(1'b1, 1'b0, 1'b1, ST_A);   // P_DENIED
    viol_before = viol;
    drive(1'b1, 1'b0, 1'b0, ST_A);   // PDENY falls while PREQ still HIGH -> PR7
    expect_fire("PR7");

    // =========================================================================
    set_phase("PR8: illegal PACCEPT=1 with PDENY=1");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);
    viol_before = viol;
    drive(1'b1, 1'b1, 1'b1, ST_A);   // both acknowledges asserted -> PR8
    expect_fire("PR8");

    // =========================================================================
    set_phase("PR9: device reset asserted outside P_STABLE");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);   // P_REQUEST, acks LOW so PR11 cannot also fire
    viol_before = viol;
    @(negedge mclk); drst_n = 1'b0;
    repeat (4) @(posedge mclk);
    expect_fire("PR9");
    @(negedge mclk); drst_n = 1'b1;
    repeat (4) @(posedge mclk);

    // =========================================================================
    set_phase("PR10: controller reset asserted outside P_STABLE");
    reset_idle();
    drive(1'b1, 1'b0, 1'b0, ST_A);
    viol_before = viol;
    @(negedge mclk); crst_n = 1'b0;
    repeat (4) @(posedge mclk);
    expect_fire("PR10");
    @(negedge mclk); crst_n = 1'b1;
    repeat (4) @(posedge mclk);

    // =========================================================================
    set_phase("PR11: acknowledges not LOW during device reset");
    reset_idle();
    @(negedge mclk); drst_n = 1'b0;
    repeat (4) @(posedge mclk);
    viol_before = viol;
    drive(1'b0, 1'b1, 1'b0, ST_A);   // PACCEPT HIGH while held in reset -> PR11
    expect_fire("PR11");

    // =========================================================================
    set_phase("Still silent on a legal sequence afterwards");
    reset_idle();
    viol_before = viol;
    drive(1'b1, 1'b0, 1'b0, ST_A);
    drive(1'b1, 1'b1, 1'b0, ST_A);
    drive(1'b0, 1'b1, 1'b0, ST_A);
    drive(1'b0, 1'b0, 1'b0, ST_A);
    expect_quiet("legal.after");

    $display("\n==================== NEGATIVE TEST SUMMARY ====================");
    $display(" checks run       : %0d", checks);
    $display(" testbench errors : %0d", tb_errors);
    $display(" total violations flagged by the monitor: %0d", viol);
    $display(" RESULT: %s", (tb_errors == 0) ? "PASS" : "FAIL");
    $display("===============================================================\n");
    $finish;
  end

endmodule
