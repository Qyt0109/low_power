# P-Channel testbenches

Three testbenches for the P-Channel RTL in
[`src/rtl/pchannel/`](../../rtl/pchannel/README.md) (AMBA LPI, ARM IHI 0068C,
Chapter 2.2 and the Section 4.2.2 ON/RETENTION/OFF example). The per-phase
control-signal matrix of all three is [`TEST_MATRIX.md`](TEST_MATRIX.md).

## Files

| File | Top | Target | What it checks |
|---|---|---|---|
| `pchannel_tb.sv` | `pchannel_tb` | `pch` | The core protocol. Part A: a real `pchannel_controller`/`pchannel_device` pair on unrelated clocks (10.0 ns and 13.7 ns). Part B: a second device driven by scripted controller stimulus, for the three Section 2.2.2 initialization behaviours the controller cannot produce. A `pchannel_monitor` on each |
| `pchannel_pd_tb.sv` | `pchannel_pd_tb` | `pchpd`, `pchlint`, `wave-pch` | `pchannel_pd_top`, the ON/RETENTION/OFF domain end to end: what distinguishes a P-Channel from a Q-Channel is two non-running states with different consequences |
| `pchannel_monitor_negtest.sv` | `pchannel_monitor_negtest` | `pchneg` | No DUT: drives the wires directly, legal sequences first (the monitor must stay silent), then one deliberate violation of each rule PR1-PR11 (the count must grow) |
| `TEST_MATRIX.md` | | | Which control inputs each phase drives and what the combination proves |

## What is checked

`pchannel_tb`:

| Phase | Claim |
|---|---|
| T0 | Reset and bring-up; PSTATE captured at reset deassertion |
| T1 | Accepted transition (Figure 2-10) |
| T2 | Denied transition (Figure 2-11), PSTATE restored to the current state |
| T3 | Multiple transitions without a common state (Figure 2-15) |
| T4 | PACTIVE-led transition (Section 2.2.3 minimum-state rule) |
| T5 | An explicit request below the PACTIVE floor is still issued |
| B1-B3 | Init behaviours 1-3: PREQ LOW at reset exit; PREQ HIGH before reset deassertion, accepted with deny asserted; PREQ HIGH during tinit, force-accepted |

`pchannel_pd_tb`:

| Phase | Claim |
|---|---|
| P0 | Boots into ON; the device captures PSTATE during tinit |
| P1 | A work burst runs; busy asserted |
| P2 | RETENTION requested while busy with denial enabled: P_DENIED, PSTATE restored (Figure 2-11 T4) |
| P3 | RETENTION preserves state: retention actuation, `work_count` unchanged across a hold, the burst resumes |
| P4 | OFF loses state: the workload reset |
| P5 | OFF → RETENTION is unsupported (Table 4-1): denied and flagged |
| P6 | PACTIVE-led wake from OFF, with the pre-transition actions |
| P7 | Late device clock: released from reset with `dclk` stopped; tinit counted in device clocks that happen |

`pchannel_monitor_negtest`: PR1-PR11, each phase starting from a legal idle and
asserting only that the violation count grew (some illegal states trip two
rules at once, e.g. PACCEPT HIGH in device reset trips PR11 and PR4), then a
legal sequence afterwards that must stay silent.

## Running

```
make -C src pch    SIM=vcs
make -C src pchneg SIM=vcs
make -C src pchpd  SIM=vcs
make -C src pchall SIM=vcs     # all three
```

- Each run ends with `RESULT: PASS` or `RESULT: FAIL`. `pchannel_tb` passes
  only with no errors and no violations on either monitor; `pchannel_pd_tb`
  with no errors and no monitor violations; the negative test with no errors.
  The make targets return 0 whatever the result: read the line.
- These targets are not in the VCS regression and have no VCS log in the
  build tree. The counts in `rtl/pchannel/README.md` (35, 14 and 50 checks)
  are Icarus runs.
- Every input is driven and every output sampled on the negedge of its clock;
  P7 is the deliberate exception (its clock is stopped).

## Adding a test

Add a phase with its banner (the phase name is also the `test_phase` signal in
the waveform), check through the testbench's check task, and add a row to
`TEST_MATRIX.md`. A new monitor rule needs a sub-test in
`pchannel_monitor_negtest.sv` that constructs exactly that violation.

## References

- AMBA Low Power Interface Specification, ARM IHI 0068C, Section 2.2 and
  Table 4-1.
- [`src/rtl/pchannel/README.md`](../../rtl/pchannel/README.md),
  [`TEST_MATRIX.md`](TEST_MATRIX.md).
