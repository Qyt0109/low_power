# VC RDC waivers (make vcrdc). One waive_rdc per accepted violation class, each
# with its one-line justification as the -comment (SIGNOFF_REPORT.md
# Section 4). Anything not waived is fixed or listed in rdc/open_findings.txt.

# RDC-W1: the watchdog's reset of the SCP subsystem (wdog_rst) seen in the
# always-on logic (the PPUs' AXI adapters, the CPU RAM wrappers' arbitration
# into the cores, and scp_wdog's own power-on-reset registers, CAUSE/RESETS). The assertion is launched by a flop on clk_i (scp_wdog's
# registered rst_req_o, ANDed into rst_sub_n), so every such path is a timed
# reset-to-Q path into clk_i's domain, not an asynchronous event; and the
# watchdog drains the AXI4-Lite manager before it asserts (formal: scp_wdog
# a_drain_idle, a_drain_max), so no PPU transfer is in flight. Requires STA to
# time rst_req_o through the reset pins (requirement R5).
waive_rdc -add RDC_W1_WDOG_SYNC -tag RDC_CORRUPT_OBSERVED -include_compressed_viol \
  -filter {SrcObject =~ "u_scp/*" && (DestObject !~ "u_scp/*" || DestObject =~ "u_scp/u_wdog/*")} \
  -comment "Watchdog reset of the SCP subsystem: asserted from a clk_i flop (timed, R5) after the AXI4-Lite drain (formal a_drain_idle); destinations are clk_i logic (SIGNOFF_REPORT.md RDC-W1)"

# RDC-W2: each domain's device resets (DEVPORESETn/DEVWARMRESETn/DEVRETRESETn,
# d<n>_*) seen by the domain's always-on Q-Channel wrapper, its clock/reset
# bridge and its retained logic. Launched by ppu_seq flops on clk_i through
# rst_sync (dclk = clk_i in soc4): timed. And DEN 0051E device control orders
# them after the device has quiesced (Q_STOPPED, where qchannel_device holds
# its outputs) and after DEVCLKEN has stopped the device clock (CLKEN_RST_DLY),
# so the retained logic on dev_clk takes no edge while a reset asserts. The
# bridge samples the resets as data by design (H16); soc4_ctrl's status read
# data (core_sleep) is a clk_i flop capturing a timed path.
waive_rdc -add RDC_W2_DEVRST_SEQ -tag RDC_CORRUPT_OBSERVED -include_compressed_viol -regexp \
  -filter {SrcObject =~ "u_(cpu|acc)[0-9]/(u_ip/u_core|u_core|u_ram|u_dom/u_pd/u_(wl|ret)_rst)/.*" && (DestObject =~ "u_(cpu|acc)[0-9]/(u_dom/u_pd/u_dev|u_ckrst|u_ip/u_ret)/.*" || DestObject =~ "u_ctrl/.*")} \
  -comment "PPU device resets: clk_i-launched (timed), asserted only after Q_STOPPED and after DEVCLKEN has stopped the device clock (DEN 0051E device control, CLKEN_RST_DLY); ckrst_bridge observes them by design (SIGNOFF_REPORT.md RDC-W2)"

# RDC-W3: into the vendored Ibex cores' (SCP, AP, CPU0, CPU1) own resetless
# datapath flops and clock-gate latch, from flops whose reset also resets that
# Ibex: inside Ibex; the SCP subsystem's own flops (scp_irq, the timer, the
# AXI4-Lite manager; rst_sub_n, the SCP Ibex's reset) and its ext-window
# bus.sv (vendored Ibex shared/); a CPU RAM wrapper's core-side flops (reset
# with the core, core_rst_n) and its Q-Channel adapter's wake pulse (rst_ni,
# which also resets the PPU and so the core); the mailbox and soc4_ctrl on
# the SCP's ext window (rst_ni, which is part of every Ibex's reset); the
# AP's own flops (rst_ni, the AP Ibex's reset).
# Also the resetless read-data flops of the SCP's and the AP's timer.sv (the
# vendored Ibex shared/ timer), written by their own Ibex. Ibex is
# third-party (src/pmu/ibex, verbatim) and qualifies its resetless datapath
# with reset valid bits; its clocked logic is in reset whenever its source is.
foreach {w tag} {RDC_W3_IBEX_DATA RDC_CORRUPT_OBSERVED RDC_W3_IBEX_CLK RDC_CLOCK_CORRUPT_OBSERVED} {
  waive_rdc -add $w -tag $tag -include_compressed_viol \
    -filter {(SrcObject =~ "*/u_ibex/*" || SrcObject =~ "u_ext/*" || SrcObject =~ "u_scp/*" || SrcObject =~ "u_cpu?/u_ram/*" || SrcObject =~ "u_cpu?/u_adp/*" || SrcObject =~ "u_mbx/*" || SrcObject =~ "u_ctrl/*" || SrcObject =~ "u_ap/*") && (DestObject =~ "*/u_ibex/*" || DestObject =~ "*/u_timer/*")} \
    -comment "Into vendored Ibex's resetless datapath, its clock-gate latch and the vendored timer's read flops, from flops whose reset also resets that Ibex; Ibex qualifies them with reset valid bits; third-party (SIGNOFF_REPORT.md RDC-W3)"
}

# RDC-W4: the domains' clock gates (clk_gate's latch has no reset). rst_ni
# drops DEVCLKEN (u_clken_sync) or the PPU clock request (u_clkctrl)
# asynchronously; the gated dev_clk / ppu_clk shapes clocks only device or PPU
# logic held in reset by rst_ni or rst_ni-derived resets at that moment (rst_ni
# resets the PPU, whose device resets follow), so a cut pulse lands on flops in
# reset.
waive_rdc -add RDC_W4_CLKGATE -tag RDC_CLOCK_CORRUPT_OBSERVED -include_compressed_viol \
  -filter {(SrcObject =~ "*/u_dom/u_pd/u_clken_sync/*" && DestObject =~ "*/u_dom/u_pd/u_clkctrl/en_latch*") || (SrcObject =~ "*/u_dom/u_clkctrl/*" && DestObject =~ "*/u_dom/u_gate/en_latch*")} \
  -comment "System reset dropping a domain's clock enable: the gated clock only reaches device logic that rst_ni holds in reset at the same time (SIGNOFF_REPORT.md RDC-W4)"

# RDC-W5: the OpenTitan TL-UL socket's FIFO storage in the mailbox
# (tlul_fifo_sync / prim_fifo_sync, vendored) is resetless; its contents are
# qualified by the FIFO's reset depth/valid flops, which rst_ni resets; every
# source of the mailbox (the AP, the ports, the SCP's ext window) is reset by
# rst_ni or by a reset that contains it.
waive_rdc -add RDC_W5_OT_FIFO -tag RDC_CORRUPT_OBSERVED -include_compressed_viol \
  -filter {DestObject =~ "u_mbx/*storage*"} \
  -comment "Resetless storage of the vendored OpenTitan TL-UL FIFOs, qualified by their reset valid/depth flops in the same rst_ni domain (SIGNOFF_REPORT.md RDC-W5)"
