# `signoff/rdc` — VC RDC

Reset-domain-crossing sign-off (V6) of `soc4_top` with VC SpyGlass RDC, run
by `make vcrdc`. Results and the argument for each waiver class:
[`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 4.

## Files

| File | What it is |
|---|---|
| [`vcrdc.tcl`](vcrdc.tcl) | The run script: `enable_rdc`, the design read (`../common/read_design.tcl`, top `soc4_top`) with three RAM models black-boxed, `read_sdc ../cdc/soc4_top.sdc`, `constraints.tcl`, the waivers, `check_rdc`, the reports and the per-waiver counts |
| [`constraints.tcl`](constraints.tcl) | RDC constraints beyond the SDC: the flop-generated resets, their drive clock, the reset group, the black-box pin timing, RDC on asynchronous paths |
| [`waivers.tcl`](waivers.tcl) | 6 waivers in 5 classes: RDC-W1, RDC-W2, RDC-W3 (data and clock, two waivers), RDC-W4, RDC-W5 |
| [`open_findings.txt`](open_findings.txt) | Empty: no open RDC finding is allowed |

The clocks and the two reset ports come from the CDC SDC,
[`../cdc/soc4_top.sdc`](../cdc/soc4_top.sdc); see [`../cdc/README.md`](../cdc/README.md).

## What the run covers

| Item | Setting |
|---|---|
| Top | `soc4_top`, source list `SOC4_DUT_SRCS` |
| Clock | `clk_i` and the seven virtual clocks of the CDC SDC |
| Reset ports | `rst_ni`, `scp_rst_ni` (from the SDC), in one assertion group `sys_rst`: `scp_rst_ni` asserts only together with `rst_ni` (requirement R4) |
| Generated resets | `wdog_rst`: `u_scp/u_wdog/rst_req_o`, active HIGH, ANDed into the SCP subsystem reset. `d<n>_por`, `d<n>_warm`, `d<n>_ret` for n = 0..3 (`u_cpu0`, `u_cpu1`, `u_acc0`, `u_acc1`): each domain's `DEVPORESETn`/`DEVWARMRESETn`/`DEVRETRESETn` flop in `ppu_seq`. The tool inferred these only as soft resets |
| Drive clock | `set_reset_drive_clock` ties every generated reset to `clk_i`, so a crossing from it into `clk_i` logic is a timed path, not an asynchronous event |
| Asynchronous paths | `configure_rdc_corrupt -report_rdc_on_cdc true` (off by default) |
| Black boxes | `ppu_ip_sram`, `scp_ram` (the SCP's and the AP's 64 KB RAM) and PULP `tc_sram` (CPU RAMs, mailbox queues). Their pins are given input/output delays on `clk` in `constraints.tcl` |

## How to run and judge

```sh
make -C src vcrdc
```

Output in `build/signoff/rdc/`: `rdc.log`, `vcrdc_open.rpt` (gated),
`vcrdc_verbose.rpt`, `vcrdc_waived.rpt`, `vcrdc_waivers.txt`.
`../common/vc_gate.py` checks `vcrdc_open.rpt` against the empty
`open_findings.txt`, so any unwaived fatal, error or warning fails; see
[`../README.md`](../README.md).

Result on 2026-10-06: PASS, 7,325 crossings waived, 0 open. Per waiver
(`vcrdc_waivers.txt`): RDC_W1_WDOG_SYNC 2,326; RDC_W2_DEVRST_SEQ 182;
RDC_W3_IBEX_DATA 4,236; RDC_W3_IBEX_CLK 12; RDC_W4_CLKGATE 8;
RDC_W5_OT_FIFO 561. The waivers use `-include_compressed_viol`, so the counts
include compressed violations.

## Limits and open items

- **Black-boxed RAM models.** With the arrays elaborated, crossing generation
  over about 1.2 M array bits went past 50 GB and was stopped. So RDC across a
  RAM array is not checked, for example an SCP write into the fault-log block
  cut by the watchdog reset. The fault log carries magic numbers and checksums
  (`pmu/fw/mod/flog.h`) for that case.
- **The waivers rest on requirements.** RDC-W1 and RDC-W2 depend on STA timing
  the watchdog and PPU reset assertions through the reset pins (requirement
  R5: not false paths). RDC-W1 also rests on the formal proofs `a_drain_idle`
  and `a_drain_max` of scp_wdog. The `sys_rst` group rests on R4.
- **Third-party waivers.** RDC-W3 (Ibex) and RDC-W5 (OpenTitan TL-UL FIFO
  storage) waive crossings into vendored code that qualifies its resetless
  storage with reset valid bits. They are by path filter, so a new source
  matching those filters is waived too; review the counts in
  `vcrdc_waivers.txt` after an RTL change.
- `vcrdc.tcl`'s header says the tool finds the reset domains from the reset
  tree; `constraints.tcl` declares the flop-generated ones explicitly, and
  those declarations are what the run uses.

## References

- [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 4 and Section 8
  (R4, R5).
- DEN 0051E (PPU) Section 4.2, device reset control.
- `pmu/rtl/scp_wdog.sv`, `rtl/ppu/ppu_seq.sv`, `src/formal/scp_wdog/`.
