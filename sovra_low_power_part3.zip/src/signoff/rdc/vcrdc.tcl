# vcrdc.tcl -- VC RDC on soc4_top (make vcrdc; platform plan phase 6, V6;
# SIGNOFF_REPORT.md Section 4). Clocks and the two reset ports come from the
# CDC constraints (cdc/soc4_top.sdc); the reset domains below them -- the SCP
# subsystem's rst_sub_n (rst_ni & scp_rst_ni & ~watchdog), the watchdog's
# por_ni (rst_ni), each domain's DEVPORESETn/DEVWARMRESETn/DEVRETRESETn
# synchronisers -- are found by the tool from the reset tree.

set S $::env(PMU_SRC)
set_app_var enable_rdc true

set signoff_top  soc4_top
set signoff_tops {}
# The memory arrays are black-boxed: ppu_ip_sram (as in vccdc.tcl), and the
# behavioural RAM models scp_ram (64 KB, the SCP's and the AP's) and PULP's
# tc_sram (the CPU RAMs, the mailbox queues), all compiled macros in the SoC.
# With them in, RDC crossing generation over ~1.2 M array bits exceeded 50 GB
# and did not finish; an array bit has no reset and adds no reset domain.
# What crossing into a RAM means is argued in SIGNOFF_REPORT.md Section 4.
set signoff_bbox {ppu_ip_sram scp_ram tc_sram}
source $S/signoff/common/read_design.tcl

read_sdc $S/signoff/cdc/soc4_top.sdc
source $S/signoff/rdc/constraints.tcl
source $S/signoff/rdc/waivers.tcl

check_rdc
report_rdc -file vcrdc_open.rpt
report_rdc -verbose -limit 0 -file vcrdc_verbose.rpt
report_rdc -only_waived -verbose -limit 0 -file vcrdc_waived.rpt
source $S/signoff/common/waiver_counts.tcl
so_waiver_counts rdc vcrdc_waivers.txt
quit
