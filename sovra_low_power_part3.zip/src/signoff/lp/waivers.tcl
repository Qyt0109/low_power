# VC LP waivers (make vclp). One waive_lp per accepted violation class, each
# with its one-line justification as the -comment; SIGNOFF_REPORT.md Section 2
# lists them with the evidence. Anything not waived here is either fixed or an
# open finding in lp/open_findings.txt.

waive_lp -add LP_W1_RET_MAP_NOLIB -tag RET_MAP_MISMATCH \
  -filter {Strategy == "PD_DEV_0/RET_CPU0"} \
  -comment "No Liberty .db in the RTL flow (no link_library; DC/ICC2 not installed): the control_pin_count check has no retention cell to compare RET_CPU0 with; map_retention_cell is a synthesis-time check (SIGNOFF_REPORT.md LP-W1)"

# LP-W2: a domain's gated clock (u_clkctrl/gated_clk) and a CPU's instruction
# request (u_core/instr_req_o) leave PD_DEV_n and fan out to ALWAYS-ON sinks
# (the RAM wrapper u_ram, the accelerator banks) and back into PD_DEV_n (the
# core's clock pin; instr_gnt_i through u_ram). The isolation cell is required
# for the always-on sinks; VC LP reports the same-domain branch as redundant.
# Tried and rejected: -diff_supply_only TRUE removed it, but VCS native low
# power then dropped isolation on these ports altogether and an unclamped X
# reached the RAM wrapper (soc4pa: Ibex IbexInstrRValidX at 4413145 ns).
waive_lp -add LP_W2_ISO_FORK -tag ISO_STRATEGY_REDUND \
  -filter {StrategyNodeInfo:StrategyNode =~ "*/u_dom/u_pd/u_clkctrl/gated_clk" || StrategyNodeInfo:StrategyNode =~ "u_cpu?/u_core/instr_req_o"} \
  -comment "Isolation on a PD_DEV output that also feeds always-on sinks (gated_clk to the RAM wrapper/banks, instr_req_o to u_ram): required there; only the branch back into PD_DEV is redundant (SIGNOFF_REPORT.md LP-W2)"
