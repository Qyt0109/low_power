# `signoff/lp` — VC LP static checks of the power intent

Static checking (V7) of soc4's IEEE 1801 power intent, `upf/soc4_top.upf`,
against the `soc4_top` RTL with VC LP, run by `make vclp`. Results and the
argument for each waiver: [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md)
Section 2.

## Files

| File | What it is |
|---|---|
| [`vclp.tcl`](vclp.tcl) | The run script: `enable_lp base`, the design read (`../common/read_design.tcl`, top `soc4_top`, no black box), `read_upf soc4_vclp.upf`, the waivers, two `check_lp` runs, the reports and the per-waiver counts |
| [`soc4_vclp.upf`](soc4_vclp.upf) | The VC LP wrapper for the power intent: sets `s4_ret_sense level`, then `load_upf $PMU_SRC/upf/soc4_top.upf` |
| [`waivers.tcl`](waivers.tcl) | 2 waivers: LP-W1 (`RET_MAP_MISMATCH`), LP-W2 (`ISO_STRATEGY_REDUND` on the 6 forks to always-on sinks) |
| [`open_findings.txt`](open_findings.txt) | One line: LP-2 (`RET_STRATEGY_BACKUP` ×1) |

## The wrapper and the `s4_ret_sense` switch

`soc4_top.upf` is loaded unchanged, at the design top `soc4_top`. VC LP
elaborates `soc4_top` itself, so the wrapper has no `set_design_top`. (The
VCS power-aware simulation uses a different wrapper, `upf/soc4_tb_vcs.upf`,
which names `soc4_tb/u_dut`.)

One setting differs. `soc4_top.upf` has a switch, `s4_ret_sense`, that
chooses how `RET_CPU0` names its save and restore controls on the PCSM's
`ret_n`:

| `s4_ret_sense` | `-save_signal` | `-restore_signal` | Used by |
|---|---|---|---|
| `edge` (default, if unset) | `{ret_n negedge}` | `{ret_n posedge}` | VCS native low power: `soc4pa`, `soc4bfmpa`, `soc4stresspa` |
| `level` | `{ret_n low}` | `{ret_n high}` | VC LP, through `soc4_vclp.upf` |

VC LP rejects edge-sensitive save/restore (`[Error] UPF_INVALIDPOLINRET`),
although it is legal IEEE 1801-2013 (finding LP-1). `level` gives it the same
strategy, elements, supplies and control net, for static checking only.

## What the run covers

- `check_lp -stage upf`: the intent's completeness and consistency against the
  RTL. That is isolation and retention strategies (missing, redundant,
  unused), their control signals and supplies, the power switches, the power
  state table and supply-net connectivity.
- `check_lp -stage upf -family {designfeedthrough designfork}`: nets that pass
  through or fork across a switched domain. `-stage upf` leaves these
  families out by default.
- `report_lp -all_tags` writes every tag checked (132) to
  `vclp_summary.rpt`.

The design is soc4_top with all four switched domains (`PD_DEV_0` to `_3`),
their `PD_AON_n` and `PD_TOP`. The RAM macros sit on the always-on rail and
are retained or lost by their PCSM pins, not by UPF.

## How to run and judge

```sh
make -C src vclp
```

Output in `build/signoff/lp/`: `lp.log`, `vclp_open.rpt` (gated),
`vclp_summary.rpt`, `vclp_waived.rpt`, `vclp_waivers.txt`.
`../common/vc_gate.py` checks `vclp_open.rpt` against `open_findings.txt`; see
[`../README.md`](../README.md).

Result on 2026-10-06: PASS, 7 waived (LP-W1 ×1, LP-W2 ×6), 1 open finding
(LP-2). Infos `DESIGN_FEEDTHROUGH` 74 and `DESIGN_FORK` 6 were reviewed.

## Limits and open items

- **LP-2 (open).** In ON, `RET_CPU0`'s backup rail `VDD_RET_0` is off while
  `VDD_LOGIC_0` is on, because the PCSM raises `SW_RET` only on FULL_RET
  entry. That is right for balloon-latch retention cells and wrong for
  live-slave ones. It depends on the retention-style decision S5 (Physical).
- **LP-1 (flow question).** The UPF works around VC LP with `level`. Whether
  the implementation flow accepts the edge form is part of the S5 decision.
- **RTL stage only.** `-stage design` checks the isolation and retention cells
  that synthesis inserts; at RTL every strategy would be reported
  unimplemented (`man check_lp`: "not recommended ... in the RTL stage").
  `-stage pg` needs a PG netlist. Both belong to netlist sign-off; DC is not
  installed.
- **No Liberty.** There is no `.db`, so retention-cell mapping cannot be
  checked (waiver LP-W1).
- Only `soc4_top.upf` is checked. The PPU and Q-Channel UPF files in `upf/`
  are not part of VC LP sign-off.

## References

- [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 2 (LP-1 to LP-3,
  LP-W1, LP-W2) and Section 7.
- [`../../upf/README.md`](../../upf/README.md) and `upf/soc4_top.upf` (header:
  domains, isolation, retention, `s4_ret_sense`).
- [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md) Section 8 (soc4's power intent).
- IEEE 1801-2013 `set_retention`.
