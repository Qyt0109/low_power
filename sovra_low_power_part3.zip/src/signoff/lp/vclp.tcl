# vclp.tcl -- VC LP static checks of soc4_top's power intent (make vclp;
# platform plan phase 6, V7; signoff/SIGNOFF_REPORT.md Section 2).
#
#   check_lp -stage upf   the UPF's completeness and consistency against the
#                         RTL: isolation and retention strategies (missing,
#                         redundant, unused), their control signals and
#                         supplies, power switches, the power state table and
#                         the supply-net connectivity.
#   -family designfeedthrough designfork: not part of -stage upf by default
#                         (man check_lp), run explicitly: nets that pass
#                         through, or fork across, a switched domain.
#
# -stage design is not run: it checks the isolation and retention CELLS that
# synthesis inserts, and at RTL every strategy is reported unimplemented
# (ISO_INST_MISSING on each crossing). man check_lp: "not recommended ... in
# the RTL stage". -stage pg needs a PG netlist. Both belong to the netlist
# sign-off, after synthesis (no DC here).

set S $::env(PMU_SRC)
set_app_var enable_lp base

set signoff_top  soc4_top
set signoff_tops {}
set signoff_bbox {}
source $S/signoff/common/read_design.tcl

read_upf $S/signoff/lp/soc4_vclp.upf
source $S/signoff/lp/waivers.tcl

check_lp -stage upf
check_lp -stage upf -family {designfeedthrough designfork}

report_lp -all_tags -file vclp_summary.rpt
report_lp -verbose -limit 0 -file vclp_open.rpt
report_lp -only_waived -verbose -limit 0 -file vclp_waived.rpt
report_lp_statistics
source $S/signoff/common/waiver_counts.tcl
so_waiver_counts lp vclp_waivers.txt
quit
