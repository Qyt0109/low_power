# VC CDC waivers (make vccdc). One waive_cdc per accepted violation class, each
# with its one-line justification as the -comment (SIGNOFF_REPORT.md
# Section 3). Anything not waived is fixed or listed in cdc/open_findings_soc4.txt
# (the ppudom configuration's are in cdc/open_findings_ppudom.txt).

# CDC-W1: the interrupt OR. scp_irq ORs (pending & enable) of all inputs into
# irq_o; the asynchronous inputs (each through its own cdc_sync) reconverge
# there. No coherence is needed: each pending bit is held until firmware
# clears it (W1C), irq_o is "any pending", and firmware reads the bits one by
# one; a skew of a cycle between two synchronisers changes nothing.
waive_cdc -add CDC_W1_IRQ_OR -tag CDC_COHERENCY_ASYNCSRCS_RECONV_SEQ \
  -filter {ConvergencePoint == "u_scp/u_irq/irq_o"} \
  -comment "Independent interrupt sources reconverging in scp_irq's pending OR: each pending bit is sticky until W1C and read individually, no multi-bit coherence is required (SIGNOFF_REPORT.md CDC-W1)"

# CDC-W2: reset gating. Each flagged clear pin is driven by an AND of active-LOW
# resets, each a port or a flop output: ppu_dom_top's two rst_sync inputs
# (dev_poresetn & dev_warmresetn, dev_poresetn & dev_retresetn, all PPU flops;
# the rst_sync releases only after two dclk edges, so a sub-cycle glitch cannot
# release a domain), scp_top's rst_sub_n (rst_ni & ~ the watchdog's registered
# rst_req_o), and soc4_cpu_ram's sram_rst_n (aon_rst_ni & the PCSM's
# registered shutdown pin). An AND of active-LOW resets cannot glitch to
# assertion while all inputs stay HIGH; assertion is meant to be asynchronous.
waive_cdc -add CDC_W2_RST_AND -tag INTEGRITY_ASYNCRESET_COMBO_MUX \
  -filter {SeqElement =~ "*u_dom/u_pd/u_wl_rst/sync_q" || SeqElement =~ "*u_dom/u_pd/u_ret_rst/sync_q" || SeqElement =~ "u_scp/u_core/u_ibex/core_busy_q*" || SeqElement =~ "u_cpu*/u_ram/u_sram/rdata_q*"} \
  -comment "Async clears driven by an AND of active-LOW resets that are ports or flop outputs (PPU reset requests into rst_sync, rst_ni & registered watchdog request, aon reset & registered PCSM shutdown pin): no glitch to assertion (SIGNOFF_REPORT.md CDC-W2)"
