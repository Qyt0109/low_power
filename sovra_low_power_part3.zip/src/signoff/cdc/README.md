# `signoff/cdc` — VC CDC

Clock-domain-crossing sign-off (V6) with VC SpyGlass CDC, run by `make vccdc`.
The same script runs in two configurations, chosen by the Makefile through
`SIGNOFF_CFG`. The SDC files here are also the clock and reset constraints of
VC RDC (`../rdc/`). Results and the argument for each waiver:
[`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 3.

## Files

| File | What it is |
|---|---|
| [`vccdc.tcl`](vccdc.tcl) | The run script. Picks the top, SDC and waiver file from `SIGNOFF_CFG`, reads the design through `../common/read_design.tcl`, runs `check_cdc`, writes the reports and the per-waiver counts |
| [`soc4_top.sdc`](soc4_top.sdc) | Clocks, resets and port constraints of `soc4_top`. Used by `vccdc` (soc4) and by `vcrdc` |
| [`ppu_axi_dom_top.sdc`](ppu_axi_dom_top.sdc) | The PPU domain wrapper with `dclk` asynchronous to `aclk` (ppudom) |
| [`waivers_soc4.tcl`](waivers_soc4.tcl) | 2 waivers: CDC-W1, CDC-W2 |
| [`waivers_ppudom.tcl`](waivers_ppudom.tcl) | 7 waivers: PD-W1 to PD-W6 (PD-W3 is two `waive_cdc` commands, one per tag) |
| [`open_findings_soc4.txt`](open_findings_soc4.txt) | Empty: no open CDC finding is allowed on soc4_top |
| [`open_findings_ppudom.txt`](open_findings_ppudom.txt) | One line: CDC-3 (`CDC_COHERENCY_MULTI_SYNC` ×1) |

## What each run covers

### `soc4` — `soc4_top`, source list `SOC4_DUT_SRCS`

| Item | Constraint |
|---|---|
| Clock | One real clock, `clk` on `clk_i` (10 ns). The PPUs' `aclk`/`dclk` are `clk_i` inside soc4_top, and the gated device clocks come from `clk_gate` cells on it |
| Asynchronous inputs | Seven virtual clocks, mutually asynchronous and asynchronous to `clk`: `plic_vclk` (`plic_irq_i`, `plic_pend_i`), `rtc_vclk` (`rtc_wake_i`), `gpio_vclk` (`gpio_wake_i`), `bbrx_vclk` (`bbrx_det_i`), `dbg_vclk` (`dbg_pwrreq_i`), `acg0_vclk`/`acg1_vclk` (`acg_wake_i[0]`, `[1]`). These are scp_irq inputs 5-13, each through its own `cdc_sync` |
| Resets | `rst_ni` and `scp_rst_ni`, active LOW, asynchronous assertion. Their deassertion is synchronous to `clk_i` (requirement R1), so they also get an input delay on `clk` |
| Synchronous inputs | The strap `bfm_sel_i`, `scp_fetch_en_i`, the `sim_*`/`ap_ext_*` bus pages, the TL-UL ports, the accelerator stimulus, `hold_busy_i`, and the clkgate/tilereset acknowledgements `tile_clk_ack_i`/`tile_rst_ack_ni` (every `ckrst_bridge` in soc4 has `ACK_SYNC = 0`: requirement R2). All outputs are on `clk` |
| Black box | `ppu_ip_sram`, the SRAM macro model: its `always @(posedge shutdown)` array clear would otherwise be taken for a clock. Its bank pins are constrained on `clk` in the SDC |

### `ppudom` — `ppu_axi_dom_top`, source list `PPU_SRCS`

soc4 ties `dclk` to `clk_i`, so this run checks the multi-clock case a SOVRA
tile will have.

| Item | Constraint |
|---|---|
| Clocks | `aclk` (10 ns) and `dclk` (7 ns) on their ports; virtual `hc_vclk` for the hierarchical clock controller's Q-Channel (`hc_qreqn_i` in; `hc_qacceptn_o`, `hc_qdeny_o`, `hc_qactive_o` out); virtual `cfg_vclk` for `clk_force_i` and `entry_delay_i` (asynchronous configuration, PCK-600 Table A-25). All four mutually asynchronous |
| Reset | `aresetn`, active LOW, input delay on `aclk` |
| Port groups | AXI4-Lite slave and `qactive_only_i` on `aclk`; `irq`, `ppuhwstat` out on `aclk`; the device side (`dev_quiescent_*`, `dev_wake` in; `dev_quiescent_ok`, `dev_clken_req`, `dev_nret_rst_n`, `dev_ret_rst_n` out) on `dclk` |
| Parameter | `-pvalue+ppu_axi_dom_top.CLK_QACTIVE_SYNC=1`. With the default 0 the raw device QACTIVE reaches the clock controller unsynchronised (finding CDC-1, requirement R3) |
| Black box | `ppu_ip_sram`, as above |

## How to run and judge

```sh
make -C src vccdc
```

It runs `soc4` into `build/signoff/cdc_soc4/` and then `ppudom` into
`build/signoff/cdc_ppudom/`. Each gets `cdc_<cfg>.log`, `vccdc_open.rpt`
(gated), `vccdc_verbose.rpt`, `vccdc_waived.rpt` and `vccdc_waivers.txt`.
`../common/vc_gate.py` then checks `vccdc_open.rpt` against the matching
`open_findings_<cfg>.txt`; see [`../README.md`](../README.md) for the rule.
The target passes only if both configurations pass.

Result on 2026-10-06: soc4 12 waived, 0 open; ppudom 32 waived, 1 open (CDC-3).
All 9 asynchronous inputs of soc4 were found synchronised (`CDC_SYNC_CTRL` ×9).

## Limits and open items

- **CDC-3 (open).** `DEVPORESETn` feeds the two `dclk` reset synchronisers of
  `ppu_dom_top` (`u_wl_rst`, `u_ret_rst`) separately, so the two device
  resets can release one `dclk` cycle apart. Needs a design decision.
- **CDC-1 (open decision).** The default `CLK_QACTIVE_SYNC = 0` is correct
  only when `dclk` is `aclk`'s clock. The ppudom run overrides it; whether to
  change the default or keep requirement R3 is undecided.
- **One clock in soc4.** soc4 has no real second clock, so the soc4 run checks
  only the asynchronous input lines. The real multi-clock check is ppudom, on
  one domain wrapper, not on a full SOVRA tile.
- **Requirements, not checks.** R1 (synchronous reset release) and R2
  (synchronous acknowledgements, `ACK_SYNC = 0`) are written into the SDC as
  assumptions. The SoC integration must meet them.
- **Virtual-clock periods** are arbitrary distinct values; only the
  asynchronous grouping matters.

## References

- [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Sections 3.1, 3.2, 8 (R1-R3).
- `soc4/rtl/soc4_top.sv` header: CLOCKS AND RESETS, THE SCP'S INTERRUPT
  INPUTS, THE CLOCK/RESET REQUEST BRIDGES.
- `rtl/ppu/ppu_dom_top.sv`, `rtl/ppu/ppu_axi_dom_top.sv`, `rtl/ppu/ppu_clk_ctrl.sv`
  headers (the clock column of each port).
- AMBA Low Power Interface, ARM IHI 0068C, Sections 2.1.2, 3.1, 4.1.1;
  PCK-600 TRM Tables 3-7 and A-25.
