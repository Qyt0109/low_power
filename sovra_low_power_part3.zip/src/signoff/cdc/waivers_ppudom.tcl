# VC CDC waivers, configuration ppudom (ppu_axi_dom_top, dclk asynchronous to
# aclk; make vccdc). One waive_cdc per accepted violation class, each with its
# one-line justification as the -comment (SIGNOFF_REPORT.md Section 3.2).

# PD-W1: the hierarchical clock controller's Q-Channel outputs. hc_qacceptn_o
# and hc_qdeny_o are flop outputs (u_clkctrl/u_hc), hc_qactive_o is
# combinational by contract (PCK-600 TRM Table 3-7, ACTIVE_DENY_EN note: "The
# path from a device to the controller QACTIVE is combinatorial"); AMBA LPI
# (IHI 0068C) Section 3.1: "Re-synchronize all signals at the destination
# before use", "register all QREQn, QACCEPTn, and QDENY outputs".
waive_cdc -add PD_W1_HC_QCH -tag CDC_UNSYNC_NOSCHEME \
  -filter {DestObject == "hc_qactive_o" || DestObject == "hc_qacceptn_o" || DestObject == "hc_qdeny_o"} \
  -comment "Q-Channel outputs to an asynchronous controller: registered QACCEPTn/QDENY, combinational QACTIVE (PCK-600 Table 3-7); synchronised at the destination per AMBA LPI 3.1 (SIGNOFF_REPORT.md PD-W1)"

# PD-W2: the raw DEVQACTIVE term of PPUCLKQACTIVE (ppu_top.sv: "This must be
# the RAW pin") entering the clock controller's own synchroniser
# (CLK_QACTIVE_SYNC = 1) through ppuclk_needed's OR/compare. A glitch can only
# be a spurious QACTIVE pulse; AMBA LPI 3.1: "the handshake protocol guarantees
# functionally correct behavior regardless of QACTIVE behavior".
waive_cdc -add PD_W2_RAW_QACTIVE -tag CDC_UNSYNC_DATA \
  -filter {SrcObject == "u_pd/u_dev/qactive/Q" && DestObject =~ "u_clkctrl/g_act_sync*"} \
  -comment "Raw DEVQACTIVE in PPUCLKQACTIVE (required by AMBA LPI 4.1.1, ppu_top.sv) synchronised by the clock controller; QACTIVE is a hint, LPI 3.1 (SIGNOFF_REPORT.md PD-W2)"

# PD-W3: entry_delay_i, synchronised bit-wise (PCK-600 Table A-25: an
# asynchronous configuration input). ppu_clk_ctrl.sv: the sole consumer is a
# threshold compare re-evaluated every cycle that self-corrects once the bits
# settle; a transient threshold shifts one entry by a few cycles.
foreach {w tag} {PD_W3_ENTRY_DELAY_SEQ CDC_COHERENCY_ASYNCSRCS_RECONV_SEQ PD_W3_ENTRY_DELAY_COMB CDC_COHERENCY_RECONV_COMB} {
  waive_cdc -add $w -tag $tag -from {entry_delay_i*} \
    -comment "Quasi-static configuration bus entry_delay_i synchronised bit-wise; its only use is a per-cycle threshold compare that self-corrects (ppu_clk_ctrl.sv, PCK-600 Table A-25) (SIGNOFF_REPORT.md PD-W3)"
}

# PD-W4: QACCEPTn and QDENY of one Q-Channel, each synchronised, reconverging
# in the controller's FSM. AMBA LPI 2.1.2: "QACCEPTn can only transition ...
# when ... QDENY is LOW", "QDENY can only transition ... when ... QACCEPTn is
# HIGH": the two never change together, and each holds until QREQn moves.
waive_cdc -add PD_W4_QCH_PAIR -tag {CDC_COHERENCY_RECONV_COMB CDC_COHERENCY_RECONV_SEQ} \
  -filter {ConvergencePoint == "u_pd/u_ppu/u_devq/state/D[0]" || ConvergencePoint == "u_pd/u_ppu/u_seq/state/D[0]"} \
  -comment "Synchronised QACCEPTn/QDENY (and the QACTIVE hint) of one Q-Channel reconverging in its FSM: LPI 2.1.2 forbids them changing together; QACTIVE skew is harmless per LPI 3.1 and ppu_top.sv (SIGNOFF_REPORT.md PD-W4)"

# PD-W5: DEVQACTIVE synchronised twice in ppu_top (sync_act for the sequencer
# and interrupts, u_devq's own for the device-interface controller, whose
# QACTIVE policy inputs are tied LOW: ppu_top.sv). A hint seen a cycle apart.
waive_cdc -add PD_W5_QACTIVE_TWICE -tag CDC_COHERENCY_MULTI_SYNC \
  -filter {SrcInfo:SrcObject == "u_pd/u_dev/qactive/Q"} \
  -comment "DEVQACTIVE, a hint, synchronised separately for the sequencer and the device-interface controller; a one-cycle difference cannot break the handshake (LPI 3.1) (SIGNOFF_REPORT.md PD-W5)"

# CDC-W2 again (see waivers_soc4.tcl): ppu_dom_top's rst_sync inputs.
waive_cdc -add PD_W6_RST_AND -tag INTEGRITY_ASYNCRESET_COMBO_MUX \
  -filter {SeqElement == "u_pd/u_wl_rst/sync_q" || SeqElement == "u_pd/u_ret_rst/sync_q"} \
  -comment "Async clears driven by an AND of PPU reset-request flops into rst_sync: no glitch to assertion (SIGNOFF_REPORT.md CDC-W2)"
