# vccdc.tcl -- VC CDC (make vccdc; platform plan phase 6, V6;
# SIGNOFF_REPORT.md Section 3).

set S $::env(PMU_SRC)
set_app_var enable_cdc true

# Two configurations (SIGNOFF_CFG, set by the Makefile):
#   soc4     soc4_top, constraints cdc/soc4_top.sdc: one clock, the raw
#            interrupt/wake lines asynchronous (Section 3.1);
#   ppudom   ppu_axi_dom_top, constraints cdc/ppu_axi_dom_top.sdc: the PPU
#            domain wrapper with dclk asynchronous to aclk (Section 3.2).
set cfg $::env(SIGNOFF_CFG)
set signoff_tops {}
# ppu_ip_sram is the behavioural model of a compiled SRAM macro with its own
# sleep/shutdown pins ("nothing synthesizes from it", its header): its
# "always @(posedge shutdown)" array clear is not a clock. Black-boxed, as the
# macro will be (a .db in the SoC); its pins are constrained in the SDC.
set signoff_bbox {ppu_ip_sram}
set signoff_elab {}
switch $cfg {
  soc4   { set signoff_top soc4_top;        set sdc soc4_top.sdc }
  ppudom {
    set signoff_top ppu_axi_dom_top; set sdc ppu_axi_dom_top.sdc
    # CLK_QACTIVE_SYNC = 1: ppu_top's PPUCLKQACTIVE carries the RAW device
    # QACTIVE (dclk) by design (ppu_top.sv, "dev_qactive ... must be the RAW
    # pin"), so with dclk asynchronous to aclk the clock controller must
    # synchronise clk_qactive_i. The default 0 is right only for soc4, where
    # dclk is clk_i (finding CDC-1, integration requirement R3).
    set signoff_elab "-pvalue+ppu_axi_dom_top.CLK_QACTIVE_SYNC=1"
  }
  default { error "vccdc.tcl: unknown SIGNOFF_CFG $cfg" }
}
source $S/signoff/common/read_design.tcl

read_sdc $S/signoff/cdc/$sdc
source $S/signoff/cdc/waivers_$cfg.tcl

check_cdc
report_cdc -file vccdc_open.rpt
report_cdc -verbose -limit 0 -file vccdc_verbose.rpt
report_cdc -only_waived -verbose -limit 0 -file vccdc_waived.rpt
source $S/signoff/common/waiver_counts.tcl
so_waiver_counts cdc vccdc_waivers.txt
quit
