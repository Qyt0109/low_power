# soc4_top.sdc -- clocks, resets and port constraints of soc4_top for VC CDC
# and VC RDC (make vccdc, make vcrdc; SIGNOFF_REPORT.md Sections 3 and 4).
# Sources: soc4_top.sv's header (CLOCKS AND RESETS, THE SCP'S INTERRUPT
# INPUTS, THE CLOCK/RESET REQUEST BRIDGES) and the port list.

# ---- Clocks ----
# One free-running clock, clk_i, for everything (soc4_top.sv: "one
# free-running clk_i for everything, each domain's switched logic on its gated
# dev_clk"). The PPUs' dclk and aclk are clk_i inside soc4_top, and the gated
# device clocks come out of clk_gate cells, so they are clk_i's domain.
create_clock -name clk -period 10 [get_ports clk_i]

# The raw lines from elsewhere in the SoC (scp_irq inputs 5-13, IRQ_ASYNC =
# 0x3FE0, each through its own cdc_sync two-flop synchroniser) have no relation
# to clk_i, and none to each other: the PLIC, the RTC, the GPIO wake logic, the
# baseband receiver, the debug module and each access gate are separate
# sources. One virtual clock per source, all mutually asynchronous. The PLIC's
# output and its per-hart pending come from one block, so they share one.
create_clock -name plic_vclk  -period 7
create_clock -name rtc_vclk   -period 11
create_clock -name gpio_vclk  -period 13
create_clock -name bbrx_vclk  -period 17
create_clock -name dbg_vclk   -period 19
create_clock -name acg0_vclk  -period 23
create_clock -name acg1_vclk  -period 29
set_clock_groups -asynchronous -group {clk} -group {plic_vclk} -group {rtc_vclk} \
  -group {gpio_vclk} -group {bbrx_vclk} -group {dbg_vclk} -group {acg0_vclk} -group {acg1_vclk}
set_input_delay -clock plic_vclk 0 [get_ports {plic_irq_i plic_pend_i}]
set_input_delay -clock rtc_vclk  0 [get_ports rtc_wake_i]
set_input_delay -clock gpio_vclk 0 [get_ports gpio_wake_i]
set_input_delay -clock bbrx_vclk 0 [get_ports bbrx_det_i]
set_input_delay -clock dbg_vclk  0 [get_ports dbg_pwrreq_i]
set_input_delay -clock acg0_vclk 0 [get_ports {acg_wake_i[0]}]
set_input_delay -clock acg1_vclk 0 [get_ports {acg_wake_i[1]}]

# ---- Resets ----
# rst_ni: system and power-on reset (also scp_wdog's por_ni); scp_rst_ni: the
# SCP subsystem held while LOW. Both asynchronous assertion, active LOW. Their
# DEASSERTION is synchronous to clk_i: soc4_top has no reset synchroniser of
# its own, so the SoC's reset controller must release both on clk_i
# (integration requirement R1, SIGNOFF_REPORT.md). Hence also an input delay.
create_reset [get_ports rst_ni]     -sense low
create_reset [get_ports scp_rst_ni] -sense low
set_input_delay -clock clk 0 [get_ports {rst_ni scp_rst_ni}]

# ---- Inputs synchronous to clk_i ----
#   scp_fetch_en_i, bfm_sel_i (a static strap), the sim_* and ap_ext_* bus.sv
#   pages, the TL-UL ports (one-clock fabric), the accelerator stimulus and
#   hold_busy_i (test-only), and the SoC clkgate/tilereset acknowledgements:
#   every ckrst_bridge in soc4 has ACK_SYNC = 0, i.e. the acknowledgements are
#   taken as synchronous to clk_i (soc4's model runs on clk_i). A SoC whose
#   clkgate/tilereset answer on another clock sets ACK_SYNC = 2 (integration
#   requirement R2).
set_input_delay -clock clk 0 [get_ports {scp_fetch_en_i bfm_sel_i \
  sim_rvalid_i sim_rdata_i sim_err_i ap_ext_rvalid_i ap_ext_rdata_i ap_ext_err_i \
  tl_bfm_i tl_rpu_i acc_start_i acc_work_len_i acc_light_i acc_wake_i acc_deny_i \
  acc_ip_cmd_i acc_ip_seed_i hold_busy_i tile_clk_ack_i tile_rst_ack_ni}]
set_output_delay -clock clk 0 [all_outputs]

# ---- The SRAM macro models (ppu_ip_sram, black-boxed in vccdc.tcl) ----
# Each bank is clocked by its domain's gated dev_clk (clk_i's domain), and its
# sleep/shutdown pins come from the always-on PCSM on clk_i; in the SoC the
# macro's .db gives the same timing arcs. Inputs are captured, rdata launched,
# on clk.
set_output_delay -clock clk 0 [get_pins {u_acc*/u_ip/g_bank*u_bank/sleep u_acc*/u_ip/g_bank*u_bank/shutdown \
  u_acc*/u_ip/g_bank*u_bank/ce u_acc*/u_ip/g_bank*u_bank/we u_acc*/u_ip/g_bank*u_bank/addr* \
  u_acc*/u_ip/g_bank*u_bank/wdata*}]
set_input_delay -clock clk 0 [get_pins {u_acc*/u_ip/g_bank*u_bank/rdata*}]
