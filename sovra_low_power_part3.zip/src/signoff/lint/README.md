# `signoff/lint` — VC Lint

RTL lint of every platform module with VC SpyGlass Lint, GuideWare goal
`lint_rtl`, run by `make vclint`. Results and the argument for each waiver:
[`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 5.

## Files

| File | What it is |
|---|---|
| [`vclint.tcl`](vclint.tcl) | The run script: `enable_lint`, `configure_lint_setup -goal lint_rtl`, the design read (`../common/read_design.tcl`) with 11 tops and `ppu_ip_sram` black-boxed, the waivers, `check_lint`, the reports and the per-waiver counts |
| [`waivers.tcl`](waivers.tcl) | Third-party waivers by file (LINT-V1 as `waive_lint` and `waive_read`; LINT-V2 for the Ibex LSU) and the six reviewed platform classes LINT-W1 to LINT-W6 (`waive_lint` or `waive_read -family design`) |
| [`open_findings.txt`](open_findings.txt) | One line: LINT-1 (`RTLCheckerSummary` ×1), the missing SpyGlass checker |

## What the run covers

- **Tops** (default parameters): `soc4_top`, which brings the SCP, the AP,
  the four domains, the mailbox and the bridges, plus the blocks it does not
  instantiate: `acg_tluh`, `hart_ready_adp`, `hart_ready_regs`,
  `pchannel_pd_top`, `ppu_acg_pd_top`, `ppu_axi_pd_top`, `ppu_clkq_top`,
  `ppu_lpd_pd_top`, `ppu_top_axi_lite`, `qchannel_pd_top`.
- **Source list**: the Makefile's `VCLINT_SRCS`, that is `SOC4_DUT_SRCS` plus
  the non-testbench sources of the ACG/TL-UH, READY-adapter, ACG-PD, LPD, PD,
  P-Channel PD and PPU targets, with `*_monitor.sv` removed. 141 files on
  2026-10-06. The three protocol monitors (`qchannel_monitor`,
  `pchannel_monitor`, `ppu_monitor`) are simulation checkers that no RTL
  instantiates.
- **Directories**: `soc4/rtl`, `pmu/rtl`, `rtl/{ppu,qchannel,pchannel,acg,adp,ckrst,tluh,common}`.
- **Vendored code** that those tops pull in (Ibex and its `shared/`,
  OpenTitan, PULP `tc_sram`, `sovra_tl`) is linted too, then waived by file
  as third-party.
- **Checks that ran**: VC Lint's structural checker and VCS `+lint=all`
  (added to the design read by `read_design.tcl`).
- **No clocks or resets** are constrained; lint needs none.

## How to run and judge

```sh
make -C src vclint
```

Output in `build/signoff/lint/`: `lint.log`, `vclint_open.rpt` (gated),
`vclint_verbose.rpt`, `vclint_waived.rpt`, `vclint_waivers.txt`.
`../common/vc_gate.py` checks `vclint_open.rpt` against `open_findings.txt`;
see [`../README.md`](../README.md).

Result on 2026-10-06: PASS, vendored code and the six reviewed classes
waived, 1 open finding (LINT-1). `vclint_waivers.txt` holds the `waive_lint`
counts only; the `waive_read` waivers (LINT-V1's design-read half, LINT-W2's
`SM_MLAFF`, LINT-W3, LINT-W4) are in the report's waived totals.

## Limits and open items

- **LINT-1 (open, tool).** `lint_rtl` calls the SpyGlass-compatible RTL
  checker as `$VC_STATIC_HOME/SG_COMPAT/SPYGLASS_HOME/bin/spyglass`
  (`vcst_rtdb/.internal/cmdstat.txt`), and that file is **not installed**.
  So `lint_rtl`'s language rule set (the W* and STARC language rules) did
  **NOT RUN**. The structural checker and VCS `+lint=all` did run. The
  finding is kept in `open_findings.txt` so that it stays visible. It is
  closed only by installing the SpyGlass compatibility package and rerunning,
  which will produce new violations to disposition.
- **Default parameters only.** Each top is elaborated once with its defaults.
  Code under a parameter value no top uses is not elaborated.
- **Third-party waivers by path.** Any file under `src/vendor/opentitan/`,
  `src/vendor/pulp/`, `src/vendor/sovra_tl/` or `src/pmu/ibex/` is waived. A
  platform file placed there by mistake would be waived too.
- The waivers in LINT-W2 and LINT-W3 apply to whole files
  (`ppu_regs.sv`/`ppu_seq.sv`, and `src/rtl/*` for the elaboration-time
  `$fatal` checks), filtered by tag.

## References

- [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 5.
- `src/Makefile`: `VCLINT_SRCS`.
- [`../../vendor/README.md`](../../vendor/README.md): the vendored trees and
  the "vendor verbatim, write only glue" rule behind LINT-V1.
