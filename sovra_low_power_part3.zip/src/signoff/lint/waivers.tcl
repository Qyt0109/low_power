# VC Lint waivers (make vclint). Each waive_lint carries its one-line
# justification as the -comment (SIGNOFF_REPORT.md Section 5). Anything not
# waived is fixed or listed in lint/open_findings.txt.

# ---- Third-party code, linted and waived by file (vendored verbatim; each
# directory's README gives its origin and revision; the platform's rule is
# "vendor verbatim, write only glue", so their findings go upstream, not into
# local edits) ----
#   src/vendor/opentitan/   OpenTitan prim, tlul, lc            (Apache-2.0)
#   src/vendor/pulp/        PULP tech_cells_generic (tc_sram)   (Solderpad)
#   src/vendor/sovra_tl/    the SoC team's TileLink package     (Solderpad)
#   src/pmu/ibex/           Ibex RTL and its shared/ bus.sv, timer.sv (Apache-2.0)
waive_lint -add LINT_V1_THIRD_PARTY -regexp \
  -filter {FileName =~ ".*/src/vendor/(opentitan|pulp|sovra_tl)/.*" || FileName =~ ".*/src/pmu/ibex/.*"} \
  -comment "Vendored third-party RTL (OpenTitan, PULP tech_cells_generic, sovra_tl, Ibex), used verbatim: waived as third-party, not edited (SIGNOFF_REPORT.md LINT-V1)"
# Design-read messages (SM_*) are managed by waive_read, not waive_lint.
waive_read -add READ_V1_THIRD_PARTY -family design -regexp \
  -filter {FileName =~ ".*/src/vendor/(opentitan|pulp|sovra_tl)/.*" || FileName =~ ".*/src/pmu/ibex/.*"} \
  -comment "Vendored third-party RTL (OpenTitan, PULP tech_cells_generic, sovra_tl, Ibex), used verbatim: waived as third-party, not edited (SIGNOFF_REPORT.md LINT-V1)"
# The same Ibex code, reported against the first flop of the reset it uses:
# the CHERIoT load/store unit's cap_lsw_* latches take a reset-derived enable.
waive_lint -add LINT_V2_IBEX_LSU -tag STARC05-1.3.1.3 \
  -filter {DesignInstanceName =~ "*load_store_unit_i/cap_lsw_*"} \
  -comment "Vendored Ibex load/store unit latch enable (ibex_load_store_unit.sv 636-648) derived from the core's reset: third-party (SIGNOFF_REPORT.md LINT-V1)"

# ---- Platform RTL, reviewed ----
waive_lint -add LINT_W1_ICG_LATCH -tag InferLatch \
  -filter {FileName =~ "*/src/rtl/common/clk_gate.sv"} \
  -comment "clk_gate's en_latch is the intended latch of a latch-based clock gate (transparent while clk is LOW, glitch-free gating); a library ICG replaces it at synthesis (SIGNOFF_REPORT.md LINT-W1)"
foreach {cmd w tag} {waive_lint LINT_W2_CFG_REG_LATCH InferLatch {waive_read -family design} LINT_W2_CFG_REG_MLAFF SM_MLAFF} {
  {*}$cmd -add $w -tag $tag \
    -filter {FileName =~ "*/src/rtl/ppu/ppu_regs.sv" || FileName =~ "*/src/rtl/ppu/ppu_seq.sv"} \
    -comment "PPU_FUNRR/FULRR/MEMRR and the lock flop are written only when their option parameter is 1 (FUNC/FULL/MEM_RET_RAM_REG_CFG, LOCK_CFG; 0 in some soc4 domains): the always_ff keeps only its reset value, a constant, not a latch (SIGNOFF_REPORT.md LINT-W2)"
}
foreach {w tag} {LINT_W3_INITIAL SM_IGN_INITIAL LINT_W3_FATAL SM_UST} {
  waive_read -add $w -family design -tag $tag \
    -filter {FileName =~ "*/src/rtl/*"} \
    -comment "Elaboration-time parameter checks (initial blocks ending in \$fatal) in the PPU, its clock controller and the P-Channel blocks: simulation-only by intent, nothing to synthesize (SIGNOFF_REPORT.md LINT-W3)"
}
waive_read -add LINT_W4_ONEHOT_DECODE -family design -tag SM_PNP \
  -filter {FileName =~ "*/src/rtl/ppu/ppu_regs.sv"} \
  -comment "ppu_regs' read mux is unique case (1'b1) over rsel_*, each an equality decode of the same address against a distinct register offset: at most one is true (SIGNOFF_REPORT.md LINT-W4)"
waive_lint -add LINT_W5_PCSM_NODENY -tag FlopEConst \
  -filter {FileName =~ "*/src/rtl/pchannel/pchannel_controller.sv"} \
  -comment "The generic P-Channel controller, reused unmodified as the PCSM's: ppu_pcsm ties the P-Channel device's deny LOW (ppu_pcsm.sv 37, 190), so denied_state is never loaded (SIGNOFF_REPORT.md LINT-W5)"
waive_lint -add LINT_W6_CKRST_OBSERVES_RST -tag STARC05-1.3.1.3 \
  -filter {DesignInstanceName =~ "*u_ckrst/stat_o*"} \
  -comment "ckrst_bridge samples the domain's two device resets as data by design (platform plan H16): it forwards them to the SoC's tilereset as requests and checks the acknowledgements (SIGNOFF_REPORT.md LINT-W6)"
