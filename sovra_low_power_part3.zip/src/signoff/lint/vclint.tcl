# vclint.tcl -- VC Lint (VC SpyGlass Lint, GuideWare goal lint_rtl) on the
# platform RTL (make vclint; platform plan phase 6; SIGNOFF_REPORT.md
# Section 5).
#
# SCOPE. Every synthesizable module under soc4/rtl, pmu/rtl, rtl/ppu,
# rtl/qchannel, rtl/pchannel, rtl/acg, rtl/adp, rtl/ckrst, rtl/tluh and
# rtl/common, elaborated from the tops below with their default parameters
# (soc4_top brings the SCP, the four domains, the mailbox and the bridges;
# the others are the blocks soc4_top does not instantiate), and the vendored
# code they pull in (Ibex, OpenTitan, PULP, sovra_tl), which is linted and
# then waived as third-party by file (lint/waivers.tcl). The three protocol
# monitors (qchannel_monitor, pchannel_monitor, ppu_monitor) are simulation
# checkers that no RTL instantiates; they are not in the source list.
#
# The source list is the Makefile's (VCLINT_SRCS, written to SIGNOFF_FLIST).
# +lint=all (read_design.tcl) adds VCS's own lint messages to DESIGN_READ.

set S $::env(PMU_SRC)
set_app_var enable_lint true
configure_lint_setup -goal lint_rtl

set signoff_top  soc4_top
set signoff_tops {acg_tluh hart_ready_adp hart_ready_regs pchannel_pd_top ppu_acg_pd_top \
                  ppu_axi_pd_top ppu_clkq_top ppu_lpd_pd_top ppu_top_axi_lite qchannel_pd_top}
# ppu_ip_sram: the SRAM macro model (see vccdc.tcl); a hard macro in the SoC.
set signoff_bbox {ppu_ip_sram}
source $S/signoff/common/read_design.tcl

source $S/signoff/lint/waivers.tcl
check_lint
report_lint -limit 0 -file vclint_open.rpt
report_lint -verbose -limit 0 -file vclint_verbose.rpt
report_lint -only_waived -list -limit 0 -file vclint_waived.rpt
source $S/signoff/common/waiver_counts.tcl
so_waiver_counts lint vclint_waivers.txt
quit
