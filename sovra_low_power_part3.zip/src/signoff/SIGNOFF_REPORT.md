# Power-control platform: sign-off report (platform plan phase 6)

Date: 2026-10-06. Branch `scp-ibex-firmware`, on top of 68bb804 (phase 5).
Scope: `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.4 V6 and V7, §15.2 phase 6.
The user chose the Synopsys VC suite.

## 1. Tools, commands, verdict

| Tool | Version (from the logs) | Licence feature used |
|---|---|---|
| VC Static (`vc_static_shell`): VC LP, VC SpyGlass CDC/RDC/Lint | W-2024.09-SP2-1 (Mar 22, 2025), in `/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca` | VC-STATIC-LP (`enable_lp base`), VC-CDC, VC-RDC, VC-STATIC-LINT |
| VC Formal (`vcf -no_ui -fmode FPV`) | W-2024.09-SP2-1 | VC-FORMAL FPV |

The licence server is `27020@vsi-sandbox-01`; the features run to 2026-10-31.
`vcf -batch` fails because `libQt5Charts.so.5` is missing; `-no_ui` works.

| Target (`make -C src …`) | What it runs | Gate result |
|---|---|---|
| `vclp` | `signoff/lp/vclp.tcl` on soc4_top, with `upf/soc4_top.upf` | PASS: 7 waived, 1 open finding (LP-2) |
| `vccdc` | `signoff/cdc/vccdc.tcl` in two configurations: `soc4` and `ppudom` | PASS: 12 waived, 0 open (soc4); 32 waived, 1 open (CDC-3) (ppudom) |
| `vcrdc` | `signoff/rdc/vcrdc.tcl` on soc4_top | PASS: 7,325 crossings waived in 6 classes, 0 open |
| `vclint` | `signoff/lint/vclint.tcl` on every platform RTL top | PASS: vendored code and 6 reviewed classes waived, 1 open (LINT-1, tool) |
| `vcformal` | 7 blocks, `signoff/formal/<block>.tcl` | PASS: 271/271 assertions fully proven, 127/127 covers hit, none bounded |
| `vcformalneg` | the same properties against the 10 planted RTL mutants | PASS: every mutant falsifies 2 to 16 assertions |
| `signoff` | all of the above | PASS |

- **Where the output goes.** Runs write to `build/signoff/<run>/`, which is `/sim/sovra/quyetdv/pmu/build/signoff`. Nothing is written to `$HOME`.
- **The design read.** All four static tools use one read script, `signoff/common/read_design.tcl`. It takes `+define+SYNTHESIS` and VCS `+lint=all`. Its source list comes from the Makefile's own variables (`SOC4_DUT_SRCS`, `PPU_SRCS`, `VCLINT_SRCS`), so it is exactly what the simulations compile.
- **How the gate works.** `signoff/common/vc_gate.py` checks each report:
  - every unwaived fatal, error or warning must appear, tag and count, in the tool's `open_findings*.txt`;
  - a new violation fails the target, and so does a listed finding that has disappeared;
  - infos are printed but not gated.
- **Waivers.** They live in `signoff/<tool>/waivers*.tcl`. Each has its one-line justification as `-comment`. Every run also writes a per-waiver count to `<run>/v*_waivers.txt`. For VC Lint that file covers the `waive_lint` waivers only; the `waive_read` ones, for design-read messages, are in the report's waived totals.

## 2. VC LP: static UPF checks (V7)

**Setup.**
- `read_upf signoff/lp/soc4_vclp.upf` loads `upf/soc4_top.upf` at the design top `soc4_top`. VC LP elaborates `soc4_top` itself, so no `set_design_top` is needed; the VCS flavour `soc4_tb_vcs.upf` names `soc4_tb/u_dut` instead.
- `check_lp -stage upf` runs, and so do the families `designfeedthrough` and `designfork`, which `-stage upf` leaves out by default. `report_lp -all_tags` lists all 132 tags checked.
- Zero violations came back for:
  - isolation: `ISO_STRATEGY_MISSING`, `ISO_CONTROL_STATE`, `ISO_STRATSUPPLY_INCORRECT`;
  - retention: `RET_CONTROL_STATE`, `RET_CONTROL_UNCONN`, `RET_STRATEGY_NOSAVRES`;
  - power switches: `PSW_CONTROL_STATE`, `PSW_STRATEGY_CTRL_UNCONN`;
  - supplies: `UPF_SUPPLY_UNDRIVEN`, `UPF_SUPPLY_NOSTATE`, `UPF_SUPPLY_UNUSED`, `UPF_STRATEGY_CONN`;
  - the power state table: `UPF_PST_MISSING`, `PST_STATE_ZERO`.
- `-stage design` (it needs the inserted cells; man check_lp says "not recommended … in the RTL stage") and `-stage pg` (it needs a PG netlist) belong to the netlist sign-off. DC is not installed.
- The RAM macros are on the always-on rail by design (pins, not UPF), and no check disputes that.

| ID | Finding | Disposition |
|---|---|---|
| LP-1 | `[Error] UPF_INVALIDPOLINRET`: VC LP rejects RET_CPU0's edge-sensitive `-save_signal {ret_n negedge}` / `-restore_signal {ret_n posedge}`, which are legal IEEE 1801-2013 | **UPF changed.** `soc4_top.upf` now has a switch `s4_ret_sense`. The default `edge` is used by VCS NLP and is unchanged. `soc4_vclp.upf` sets `level` (save while ret_n LOW, restore while HIGH): the same net, strategy, elements and supplies. Whether the implementation flow accepts edges is part of the S5 decision |
| LP-2 | `RET_STRATEGY_BACKUP`: in ON, RET_CPU0's backup rail VDD_RET_0 is OFF while VDD_LOGIC_0 is ON. The PCSM raises SW_RET only on FULL_RET entry (`ppu_pcsm.sv`, `logic_ret = ret_rail`) | **Open**, needs a design decision. It is correct for balloon-latch retention cells and wrong for live-slave ones. It depends on the retention style S5 (Physical, §14.6). With live-slave cells, the PCSM must keep the retention rail on whenever the logic is on |
| LP-3 | `ISO_STRATEGY_REDUND` ×72: ISO_DEV_n's `-applies_to outputs` isolated wires that join two PD_DEV elements through an always-on scope (ACC u_ip/u_core → u_ip/u_ret, 33 per domain) | **UPF fixed.** A port-level `set_isolation NOISO_RET_n … -no_isolation` on `ret_load`/`ret_sig_in` (66 cells gone). Tried and rejected first: `-diff_supply_only TRUE`. VCS NLP then dropped isolation on instr_req_o and dev_clk altogether, and soc4pa failed Ibex `IbexInstrRValidX` at 4,413,145 ns |
| LP-W1 | `RET_MAP_MISMATCH` (control_pin_count) | Waived: there is no Liberty .db in this flow, so no retention cell to compare against; it is a synthesis-time mapping check |
| LP-W2 | `ISO_STRATEGY_REDUND` ×6: gated_clk (4 domains) and instr_req_o (2 CPUs) | Waived. These isolation cells are required for the always-on sinks (the RAM wrapper and banks); only the branch back into PD_DEV is redundant |
| info | `DESIGN_FEEDTHROUGH` 74, `DESIGN_FORK` 6 | Reviewed. They are the same PD_DEV → always-on → PD_DEV wires and forks |

## 3. VC CDC (V6)

### 3.1 soc4_top (`signoff/cdc/soc4_top.sdc`)

**Constraints.**
- One clock, `clk_i`; the gated device clocks derive from it.
- Seven virtual clocks, mutually asynchronous, for the raw lines: PLIC (output and per-hart pending), RTC, GPIO, BBRX, debug, and access gates 0 and 1.
- The resets `rst_ni` and `scp_rst_ni` are asynchronous to assert. Their deassertion is synchronous to `clk_i` (requirement R1).
- The `ckrst_bridge` acknowledgements are synchronous, because `ACK_SYNC = 0` (requirement R2).
- `ppu_ip_sram` is black-boxed with its pins constrained. Its header says "nothing synthesizes from it", and its `always @(posedge shutdown)` would otherwise be taken for a clock.

**Results.**
- All 9 asynchronous inputs (scp_irq inputs 5-13) are found synchronised: `CDC_SYNC_CTRL` ×9.
- No unsynchronised crossing remains.

| ID | Violation | Disposition |
|---|---|---|
| CDC-W1 | `CDC_COHERENCY_ASYNCSRCS_RECONV_SEQ` at `u_scp/u_irq/irq_o` | Waived. These are independent sources ORed into "any pending". Each pending bit is sticky until W1C and is read on its own (formal: scp_irq `a_pend_*`) |
| CDC-W2 | `INTEGRITY_ASYNCRESET_COMBO_MUX` ×11 | Waived. Each async clear is an AND of active-LOW resets that are ports or flop outputs (into rst_sync; `rst_sub_n`; `sram_rst_n`), so it cannot glitch to assertion |

### 3.2 ppu_axi_dom_top with dclk asynchronous to aclk (`signoff/cdc/ppu_axi_dom_top.sdc`)

soc4 ties `dclk` to `clk_i`, so the platform's real multi-clock case is checked on the domain wrapper that SOVRA tiles will use. Its clock columns come from the wrapper headers and PCK-600 Table A-25.

| ID | Finding | Disposition |
|---|---|---|
| CDC-1 | With the default `CLK_QACTIVE_SYNC = 0`, the raw device QACTIVE (dclk) reaches `ppu_clk_ctrl`'s state, idle counter and clk_running flops **unsynchronised**: 11 × `CDC_UNSYNC_DATA`. PPUCLKQACTIVE carries the raw DEVQACTIVE by design (`ppu_top.sv`; AMBA LPI 4.1.1) | **Real for an asynchronous dclk**; soc4 is unaffected. The run uses `-pvalue+…CLK_QACTIVE_SYNC=1` and is then clean. Requirement R3 is documented at the parameter (comment-only RTL change). Open decision: change the default, or keep R3 |
| CDC-3 | `CDC_COHERENCY_MULTI_SYNC`: DEVPORESETn feeds the two dclk reset synchronisers (u_wl_rst, u_ret_rst) separately, so dev_nret_rst_n and dev_ret_rst_n can release one dclk cycle apart | **Open**, low risk. Either use one synchroniser for the reset requests, or state the tolerance in the device contract |
| PD-W1 | `CDC_UNSYNC_NOSCHEME` ×22 into `hc_qacceptn_o`/`hc_qdeny_o`/`hc_qactive_o` | Waived. These are Q-Channel outputs to an asynchronous controller. QACCEPTn and QDENY are registered; QACTIVE is combinational by PCK-600 Table 3-7. LPI 3.1: "Re-synchronize all signals at the destination" |
| PD-W2 | `CDC_UNSYNC_DATA` ×1: the raw DEVQACTIVE term into the clock controller's synchroniser | Waived. QACTIVE is a hint: "the handshake protocol guarantees functionally correct behavior regardless of QACTIVE behavior" (LPI 3.1) |
| PD-W3 | entry_delay_i reconvergence (×3) | Waived. It is a quasi-static configuration bus, synchronised bit by bit, and its only consumer is a self-correcting compare (`ppu_clk_ctrl.sv`) |
| PD-W4 | QACCEPTn/QDENY (and QACTIVE) reconverging in the FSMs (×3) | Waived. LPI 2.1.2 forbids QACCEPTn and QDENY from changing together |
| PD-W5 | DEVQACTIVE synchronised twice (×1) | Waived. It is a hint (LPI 3.1) |
| PD-W6 | `INTEGRITY_ASYNCRESET_COMBO_MUX` ×2 | As CDC-W2 |

## 4. VC RDC (V6), soc4_top

**Setup.**
- The SDC of §3.1, plus `signoff/rdc/constraints.tcl`.
- Resets declared: the watchdog's `rst_req_o` (`wdog_rst`) and each domain's DEVPORESETn, DEVWARMRESETn and DEVRETRESETn (`d<n>_*`). The tool had inferred them only as soft resets.
- `set_reset_drive_clock` ties each of those resets to `clk_i`.
- `rst_ni` and `scp_rst_ni` form one assertion group (requirement R4).
- RDC is also enabled on asynchronous paths.
- The RAM models (`scp_ram`, `tc_sram`, `ppu_ip_sram`) are black-boxed with their pins constrained. With the arrays in, crossing generation passed 50 GB and was stopped.

**Results.** 7,325 corruption paths in 6 classes. Every one is waived on a design argument, with the per-class count:

| ID | Class | Paths | Argument |
|---|---|---:|---|
| RDC-W1 | wdog_rst → always-on logic (the PPU AXI adapters, CPU RAM arbitration, scp_wdog's power-on-reset registers) | 2,326 | The reset is asserted from a clk_i flop, so the path is timed (requirement R5). It is asserted only after the AXI4-Lite drain, proven by formal scp_wdog `a_drain_idle` and `a_drain_max` |
| RDC-W2 | PPU device resets → the domain's Q-Channel wrapper, ckrst_bridge, retained logic, soc4_ctrl status | 182 | Launched from clk_i flops. DEN 0051E device control asserts them only after Q_STOPPED and after DEVCLKEN has stopped the device clock (CLKEN_RST_DLY) |
| RDC-W3 | Into vendored Ibex's resetless datapath, its clock-gate latch, or timer.sv's read flops, from flops whose reset also resets that Ibex | 4,248 | Third-party code, qualified by reset valid bits |
| RDC-W4 | rst_ni dropping a domain's clock enable or PPU clock request into the clock-gate latches | 8 | The gated clock reaches only logic that is held in reset at the same moment |
| RDC-W5 | Into the resetless storage of the vendored OpenTitan TL-UL FIFOs | 561 | The storage is qualified by the FIFO's reset depth and valid flops, in the rst_ni domain |

RDC across a RAM array (for example, an SCP write cut by the watchdog reset into the fault-log block) is outside the tool's view because the arrays are black boxes. The fault log carries magic numbers and checksums (`mod/flog.h`) for exactly this case.

## 5. VC Lint (lint_rtl goal)

**Scope.** Every module in `soc4/rtl`, `pmu/rtl`, `rtl/{ppu,qchannel,pchannel,acg,adp,ckrst,tluh,common}` is elaborated from 11 tops: soc4_top, acg_tluh, hart_ready_adp, hart_ready_regs, pchannel_pd_top, ppu_acg_pd_top, ppu_axi_pd_top, ppu_clkq_top, ppu_lpd_pd_top, ppu_top_axi_lite and qchannel_pd_top. 141 files are read. The three protocol monitors are simulation checkers that no RTL instantiates, so they are left out. The vendored code is linted too.

| ID | Item | Disposition |
|---|---|---|
| LINT-1 | `RTLCheckerSummary` fatal: the SpyGlass-compatible RTL checker is called as `$VC_STATIC_HOME/SG_COMPAT/SPYGLASS_HOME/bin/spyglass` (`vcst_rtdb/.internal/cmdstat.txt`), and that is **not installed** | **NOT RUN** for lint_rtl's language rule set (the W* and STARC language rules). The structural checker and VCS `+lint=all` did run. This is an open tool finding, kept visible in `open_findings.txt` |
| fixed | `TFIPC`: `ppu_pd_top` and `ppu_axi_pd_top` left phase 5's `dev_clken_req` implicitly unconnected | RTL: an explicit `.dev_clken_req ()` in both |
| LINT-V1/V2 | Every violation in `src/vendor/opentitan/`, `src/vendor/pulp/`, `src/vendor/sovra_tl/` and `src/pmu/ibex/` (Ibex RTL and `shared/` bus.sv, timer.sv), and the Ibex LSU latch-enable STARC reports | Waived as third-party: vendored verbatim, not edited |
| LINT-W1 | InferLatch in `clk_gate` | Waived: it is the intended latch of the latch-based clock gate |
| LINT-W2 | InferLatch / SM_MLAFF on PPU_FUNRR/FULRR/MEMRR and the lock flop | Waived: their option parameter is 0 in some domains, so only a constant reset value remains |
| LINT-W3 | SM_IGN_INITIAL / SM_UST in the PPU and P-Channel blocks | Waived: these are elaboration-time parameter checks that end in `$fatal` |
| LINT-W4 | SM_PNP on ppu_regs' `unique case (1'b1)` | Waived: the selects are equality decodes against distinct offsets |
| LINT-W5 | FlopEConst on `pchannel_controller.denied_state` | Waived: the PCSM's P-Channel device never denies (`ppu_pcsm.sv` lines 37 and 190) |
| LINT-W6 | STARC05-1.3.1.3 at `u_ckrst/stat_o` | Waived: the bridge samples the device resets as data, by design (H16) |
| info | ULCO, WMIA-L, UI, RegInputOutput-ML on platform files | Reviewed: constant-width compares, parameter-dependent unused inputs, unregistered top ports |

## 6. VC Formal (V7)

- **Files.** The properties are bind files in `src/formal/<block>/`; the scripts are `signoff/formal/<block>.tcl`.
- **Result.** Every assertion is **fully proven**, with no bounded proof (`signoff/formal/bounded.txt` is empty). The tool reports every assertion with an antecedent as non-vacuous, and every cover is hit.
- **Assumptions.** Each one constrains inputs only and comes from an interface rule; the props files give the citation.

| Block | Parameters (formal only) | Assertions | Covers | Main properties | Mutants: assertions falsified |
|---|---|---:|---:|---|---|
| scp_irq | NUM_IN 4, 2 async + 2 sync | 52 proven | 25/25 | per bit: pending set (level/edge), mask, W1C and byte enables; **an event in the same cycle as its clear is kept** (`a_pend_set_wins`); irq = OR(pend & en); register map | SOC4_MUT_IRQ_SYNC0: 7 |
| scp_wdog | DRAIN_MAX 8 | 39 proven | 12/12 | an independent COUNT model; no expiry before TIMEOUT; expiry at TIMEOUT; good kick reloads; wrong key resets at once (BADKICK); LOCK sticky; TIMEOUT frozen while locked; **CAUSE survives rst_ni** (por_ni only); drain then RST_CYCLES pulse | SOC4_MUT_WDOG_CAUSE_SUB: 12 |
| ckrst_bridge | NUM_RST 2, STEP_SYNC 2, ACK_SYNC 0, MAX_WAIT 12 (also proven at 300) | 47 proven | 17/17 | LATE, MISSING and SPURIOUS each flagged exactly when they occur (both directions, per channel); sticky with W1C; set wins; fault = OR | CKRST_MUT_NOLATE: 7 |
| hart_ready_adp | 2 harts, 3 ports (TL-C + 2 TL-UH), with qchannel_device | 63 proven | 27/27 | port_idle against an independent message model; **accept only with READY and every port drained, and no wake**; **clear wins over set**; LPI Table 2-1 and 2.1.2 device rules; accept/deny hold until QREQn rises | NODRAIN: 6; SETWINS: 4 |
| soc4_mbx | soc4_top's (2 agents, 2 ports, port 1 without a_user); tc_sram black-boxed | 26 proven (24 more with both agents on one port) | 18/18 | **window k reached only if FW_EN[k] and (a_source & MASK) == VAL on AGENT_PORT[k]**; deny-all from reset; queue port only inside window k; **RING set only by an admitted doorbell write**; **no byte of window k's data reaches another agent's port** | FW_OPEN: 16; FW_NOMASK: 12 |
| tluh_gate | default (64-bit, 16 outstanding) | 19 proven | 10/10 | **no beat of a denied burst reaches the device**; **a burst in progress completes before gating**; every beat of a denied message answered with an error beat of the right shape, with no extras; responses are exact | SPLIT: 2; ONEBEAT: 4; ATOM: 10 |
| qchannel | controller, device, and the connected pair | 25 proven (6 of them liveness) | 18/18 | AMBA LPI IHI 0068C §2.1.2 handshake rules R1-R7 on the pins; Table 2-1 illegal state never reached; device reset LOW; Q_DENIED → QREQn HIGH; Q_EXIT/Q_CONTINUE/Q_REQUEST liveness | (no repo mutant; 2 scratch mutants: 15) |

Findings from the proofs. None needed an RTL change to prove; each is a behaviour to decide on.

| ID | Block | Finding |
|---|---|---|
| F-TLUH-1 | tluh_gate | `dev_a_valid_o` can be withdrawn before the device accepts a first beat, when flush_req/err_en rises (cover `c_dev_a_withdrawn`, depth 2). If TileLink requires valid to stay up until ready, as we assume of the host, this is a protocol violation. **Open**: needs the TileLink spec text, which is not in the repository, and a design decision |
| F-TLUH-2 | tluh_gate | There is no message-size guard: a_size ≥ LOG2_BYTES + 10 is truncated by tl_beat_cnt (CNT_W 10) |
| F-ADP-1 | hart_ready_adp | Same limit: on an 8-byte link, size ≥ 13 is counted as one beat. SOVRA's 64 B transfers do not reach it, but the limit is not documented |
| F-ADP-2 | hart_ready_adp | A D Grant opcode on a TL-UH port increments grant_q, and nothing decrements it. It is illegal TileLink, and the port would then stay busy for ever |
| F-ADP-3 | hart_ready_adp | On a TL-C port a Probe offered on B (b_valid && !b_ready) does not make the port busy, because only fired B beats are counted. The core could be powered off with a Probe pending |
| F-WDOG-1 | scp_wdog | A wrong kick during DRAIN/RESET is not recorded in BADKICK |
| F-CKRST-1 | ckrst_bridge | LATE and MISSING share one "flagged" bit, so a MISSING after a LATE on the same request edge is not reported separately |
| tool | — | `fvtrace` crashes in this install ("Dfgsim.cxx: DFGSIM cannot execute"), so counterexamples were debugged with helper assertions |

## 7. Changes to RTL and UPF, and the regression

- `upf/soc4_top.upf`: the `s4_ret_sense` switch (LP-1), and `NOISO_RET_2/_3` (LP-3).
- `rtl/ppu/ppu_pd_top.sv`, `rtl/ppu/ppu_axi_pd_top.sv`: explicit `.dev_clken_req ()` (TFIPC).
- `rtl/ppu/ppu_axi_dom_top.sv`: a comment on CLK_QACTIVE_SYNC (CDC-1, R3).

**Regression.** `run_regress.sh` was run with the default 31 targets into `build/regress_p6`. The three power-aware targets were run again with the final UPF into `build/regress_p6_pa`. All results are identical to the baselines:
- the 19 non-soc4 targets are identical to `merge/counts.tsv` under `summ()`;
- soc4: AP 76, TB 372;
- soc4bfm: BFM 78,606, TB 79,491;
- soc4stress: 34 PASS, TB 7,621;
- soc4wdog: TB 18;
- soc4neg: all 9 mutants fail at their own checks;
- soc4pa 404, soc4bfmpa 79,563, soc4stresspa 7,875. LP E=0 in all three, and the LP message counts are identical to phase 5;
- acgtluh 26, readyadp 35, ckrst 18 (each with its mutants);
- soc4ckrst: BFM 1,463, TB 1,545.

## 8. Open items and integration requirements

**Open findings.**
- LP-2 (retention style S5), with LP-1's flow question;
- CDC-1 (the default of CLK_QACTIVE_SYNC);
- CDC-3 (DEVPORESETn synchronised twice);
- LINT-1 (SpyGlass RTL checker not installed: language rules NOT RUN);
- F-TLUH-1, F-TLUH-2, F-ADP-1, F-ADP-2, F-ADP-3, F-WDOG-1, F-CKRST-1;
- the netlist stages of VC LP (`-stage design`, `pg`), which need synthesis.

**Integration requirements the sign-off rests on.**
- **R1:** rst_ni and scp_rst_ni are deasserted synchronously to clk_i.
- **R2:** set ckrst_bridge `ACK_SYNC = 2` if the SoC clkgate/tilereset acknowledges on another clock.
- **R3:** set `CLK_QACTIVE_SYNC = 1` in ppu_axi_dom_top when dclk is asynchronous to aclk.
- **R4:** scp_rst_ni is asserted only together with rst_ni; the run-time SCP-only reset is the watchdog's.
- **R5:** STA times the watchdog and PPU reset assertions (rst_req_o and the ppu_seq reset flops through the reset pins). These must not be declared false paths.
