# `signoff` — static and formal sign-off with the Synopsys VC suite

The scripts, constraints, waivers and open-findings lists behind platform plan
phase 6 (V6 CDC/RDC, V7 power intent and formal; `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`
§14.4, §15.2). Each `make` target runs one tool, then a small Python gate turns
the tool's report into PASS or FAIL. The results, every waiver's argument and
every open finding are in [`SIGNOFF_REPORT.md`](SIGNOFF_REPORT.md); this file
says how to run the flow and how to read it, and does not repeat the report.

## What is here

| Path | Contents |
|---|---|
| [`SIGNOFF_REPORT.md`](SIGNOFF_REPORT.md) | The sign-off report: tool versions, verdicts, findings, waivers, integration requirements R1-R5 |
| [`common/`](common/README.md) | The shared design read, the two gate scripts and the per-waiver counter |
| [`lp/`](lp/README.md) | VC LP: static checks of `upf/soc4_top.upf` on `soc4_top` |
| [`cdc/`](cdc/README.md) | VC CDC: two configurations, `soc4` and `ppudom`, with their SDC files |
| [`rdc/`](rdc/README.md) | VC RDC on `soc4_top` |
| [`lint/`](lint/README.md) | VC Lint (`lint_rtl` goal) on all platform RTL |
| [`formal/`](formal/README.md) | VC Formal FPV: one script per block, plus the bounded-proof list |

The formal properties themselves are not here: they are bind files in
`src/formal/<block>/`.

## Environment

| Item | Value |
|---|---|
| Host | vsi-sandbox-01 |
| Tools | VC Static `vc_static_shell` (VC LP, VC SpyGlass CDC/RDC/Lint) and VC Formal `vcf`, W-2024.09-SP2-1, installed inside VCS |
| Install | `/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca` |
| Licence | `27020@vsi-sandbox-01`; the VC features (VC-STATIC-LP, VC-CDC, VC-RDC, VC-STATIC-LINT, VC-FORMAL) run to **2026-10-31**. After that date, confirm with a real checkout |
| Not needed | A simulator. `SIM` is not read by these targets |

The tools need `VC_STATIC_HOME`. `src/Makefile` sets it by default
(`VC_STATIC_HOME ?= /system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca`) and exports
it, with `PMU_SRC`, to every run, so the `make` targets work from a plain
shell. To run a tool by hand, export it yourself:

```sh
export VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca
export PMU_SRC=/project/sovra/99_work/quyetdv/pmu/src
```

`make vccheck` fails early if `$VC_STATIC_HOME/bin/vc_static_shell` is missing.
Run `vcf` with `-no_ui`. `vcf -batch` fails here, because `libQt5Charts.so.5`
is missing.

## How to run

From the repository root (or `cd src` and drop `-C src`):

| Target | Runs | Gate |
|---|---|---|
| `make -C src vccheck` | Checks that VC Static is installed at `VC_STATIC_HOME` | — |
| `make -C src vclp` | `lp/vclp.tcl` on `soc4_top`, UPF loaded through `lp/soc4_vclp.upf` | `vc_gate.py` against `lp/open_findings.txt` |
| `make -C src vccdc` | `cdc/vccdc.tcl` twice: `SIGNOFF_CFG=soc4` (soc4_top) and `SIGNOFF_CFG=ppudom` (ppu_axi_dom_top, dclk asynchronous to aclk) | `vc_gate.py` against `cdc/open_findings_soc4.txt` and `cdc/open_findings_ppudom.txt` |
| `make -C src vcrdc` | `rdc/vcrdc.tcl` on `soc4_top` | `vc_gate.py` against `rdc/open_findings.txt` |
| `make -C src vclint` | `lint/vclint.tcl`: `soc4_top` plus 10 further tops | `vc_gate.py` against `lint/open_findings.txt` |
| `make -C src vcformal` | `formal/<block>.tcl` for the 7 blocks of `FV_BLOCKS` | `fv_summary.py prove` with `formal/bounded.txt` |
| `make -C src vcformalneg` | The same 7 scripts, one run per planted RTL mutant (`FV_MUTANTS`, 10 runs) | `fv_summary.py neg` |
| `make -C src signoff` | All six targets above, in order | Each target's gate; the first failure stops it |

The full `make signoff` took about 7 minutes of wall time on 2026-10-06
(`build/signoff/signoff.time`). Every target exits non-zero when its gate
fails.

### The source list

The static tools all read the design through
[`common/read_design.tcl`](common/README.md). The Makefile writes the source
list into each run directory as `files.f`, from its own variables
(`SOC4_DUT_SRCS` for soc4_top, `PPU_SRCS` for the ppudom CDC run,
`VCLINT_SRCS` for lint), duplicates dropped. The tools therefore read exactly
the files the simulations compile, with `+define+SYNTHESIS`.

### Where the output goes

Each run writes to `build/signoff/<run>/`, which is
`/sim/sovra/quyetdv/pmu/build/signoff/<run>/` (`build` is a symlink). Nothing
is written to `$HOME` or to `src/`.

| Run directory | Main files |
|---|---|
| `lp/`, `cdc_soc4/`, `cdc_ppudom/`, `rdc/`, `lint/` | `<run>.log` (the tool log), `files.f`, `v*_open.rpt` (unwaived, gated), `v*_verbose.rpt`, `v*_waived.rpt`, `v*_waivers.txt` (count per waiver), `vcst_rtdb/` |
| `formal/<block>/` | `run.log`, `fv_list.rpt` (`report_fv -list`, gated) |
| `formal/<block>_mut_<DEFINE>/` | The same, for one mutant |

`lp/` also has `vclp_summary.rpt` (`report_lp -all_tags`: every tag checked).
A run directory is cleared of `vcst_rtdb` and reports at the start of its run.

## How a gate passes

**VC LP, CDC, RDC and Lint** ([`common/vc_gate.py`](common/vc_gate.py)). The
gate reads the "Tree Summary" table of the run's `v*_open.rpt`. For each tag
it has the severity, the unwaived count and the waived count.

- Every unwaived **fatal, error or warning** must be listed in the tool's
  `open_findings*.txt`, with the same tag **and the same count**. A listed
  finding is printed as `OPEN FINDING <ID>`.
- Anything unwaived and not listed fails the target as `UNDISPOSITIONED`. So
  does a listed count that differs from the run.
- A listed finding that no longer occurs also fails the target: the list must
  be updated when something is fixed.
- **Infos** are printed as "reviewed; not gated".
- Waived counts are printed per tag, for review.

`open_findings*.txt` holds one finding per line, `TAG COUNT ID text`, and `#`
starts a comment. An empty file means no open finding is allowed.

**VC Formal** ([`common/fv_summary.py`](common/fv_summary.py)).

- `prove`: every assertion must be proven and not vacuous, and every cover
  covered. An inconclusive assertion passes only if `formal/bounded.txt`
  lists it (a bounded proof, printed with its depth). Falsified, vacuous,
  uncoverable or unlisted fails.
- `neg`: each mutant run must falsify at least one assertion. A mutant that
  falsifies nothing fails the target: the properties would not catch that bug.

## Waiver policy

- A waiver lives only in `<tool>/waivers*.tcl`, never in a report or on the
  command line.
- One waiver per accepted violation class, with a name (`LP_W1_...`,
  `CDC_W1_...`, `PD_W1_...`, `RDC_W1_...`, `LINT_W1_...`) that matches an ID
  in `SIGNOFF_REPORT.md`.
- Every waiver carries its one-line justification as `-comment`, and the
  comment cites the report ID. The longer argument (spec clause, formal
  property, RTL line) is in a comment above the waiver and in the report.
- Filters are as narrow as the argument: a tag plus an object, a convergence
  point, or a file. Vendored code is waived by file path, as third-party
  (it is used verbatim; see `src/vendor/README.md`).
- Each run writes `v*_waivers.txt` with how many violations each waiver
  absorbed, so a waiver that grows or drops to zero is visible. For VC Lint
  this covers the `waive_lint` waivers only; the `waive_read` waivers (design
  read messages) appear in the report's waived totals.
- If a violation cannot be argued away, it is fixed or it goes into
  `open_findings*.txt` with an ID, and the report lists it as open.

To add a waiver: write the argument in `SIGNOFF_REPORT.md` first, add the
`waive_<app>` with a `-comment` citing that ID, rerun the target, and check
the count in `v*_waivers.txt`.

## Limits and open items

The open findings and the integration requirements are listed in
[`SIGNOFF_REPORT.md`](SIGNOFF_REPORT.md) Section 8. The limits of the flow
itself:

- **RTL stage only.** VC LP runs `-stage upf`. `-stage design` and
  `-stage pg` need a synthesized and a PG netlist; DC is not installed.
- **LINT-1.** The SpyGlass-compatible RTL checker that `lint_rtl` calls is
  not installed, so its language rules did not run (see `lint/README.md`).
- **Black boxes.** CDC and lint black-box the SRAM macro model `ppu_ip_sram`.
  RDC also black-boxes `scp_ram` and `tc_sram`: with the arrays in, the run
  went past 50 GB. RDC across a RAM array is outside the tool's view.
- **Formal parameters.** Some blocks are proven with reduced, stated
  parameters (for example scp_wdog `DRAIN_MAX = 8`); see `formal/README.md`.
- **Tool defects.** `vcf -batch` needs a missing Qt library (use `-no_ui`), and
  `fvtrace` crashes in this install, so counterexamples are debugged with
  helper assertions.
- **Licence.** The VC features end on 2026-10-31.

## References

- [`SIGNOFF_REPORT.md`](SIGNOFF_REPORT.md): results, findings, waivers, R1-R5.
- `src/Makefile`, section "Phase 6: sign-off with the Synopsys VC suite".
- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.4 (V6, V7) and §15.2 (phase 6).
- The tool's own manual pages inside `vc_static_shell` (for example
  `man check_lp`, which the LP stage choice quotes).
