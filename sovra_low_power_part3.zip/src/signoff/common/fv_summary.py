#!/usr/bin/env python3
"""fv_summary.py -- the verdict of VC Formal runs (make vcformal, vcformalneg).

  fv_summary.py prove <bounded.txt> <block>=<fv_list.rpt> ...
  fv_summary.py neg   <block>:<define>=<fv_list.rpt> ...

Reads each run's `report_fv -list` output (fv_list.rpt).

prove: every assertion must be proven and not vacuous, and every cover
covered. An assertion left inconclusive passes only if <bounded.txt> lists it
("block property depth reason"): that is a bounded proof, reported with its
depth. Anything falsified, vacuous, uncoverable or unlisted fails.

neg: each run has one planted RTL mutant (a define) and must falsify at least
one assertion -- the properties are not vacuous against a real bug.
"""
import re
import sys

LINE = re.compile(r"^\s*\[\s*\d+\]\s+(\w+)\s+(?:\(depth=(\d+)\)\s+)?(?:\((\w+)\)\s+)?-\s+(\S+)")


def short(name):
    """block.props_instance.rest -> rest (keeps generate indices)."""
    return ".".join(name.split(".")[2:]) or name


def parse(path):
    sect, props = None, []
    for line in open(path, errors="replace"):
        s = line.strip()
        if s.startswith("> "):
            sect = s[2:].split()[0]
            continue
        m = LINE.match(line)
        if m and sect in ("Assertion", "Cover"):
            # (section, status, vacuity, name, depth)
            props.append((sect, m.group(1), m.group(3) or "", short(m.group(4)), m.group(2) or ""))
    return props


def prove(bounded_file, runs):
    bounded = {}
    for line in open(bounded_file):
        line = line.split("#", 1)[0].strip()
        if line:
            b, p, d, why = line.split(None, 3)
            bounded[(b, p)] = (d, why)
    bad = 0
    print(f"{'block':16s} {'assert':>7s} {'proven':>7s} {'bounded':>8s} {'cover':>6s} {'covered':>8s}  verdict")
    for spec in runs:
        block, path = spec.split("=", 1)
        props = parse(path)
        a = [p for p in props if p[0] == "Assertion"]
        c = [p for p in props if p[0] == "Cover"]
        if not a:
            print(f"{block:16s} no assertions found in {path}")
            bad += 1
            continue
        proven = [p for p in a if p[1] == "proven" and p[2] != "vacuous"]
        bnd, fails = [], []
        for p in a:
            if p in proven:
                continue
            if p[1] == "inconclusive" and (block, p[3]) in bounded:
                bnd.append((p[3], p[4]))
            else:
                fails.append(f"{p[3]}: {p[1]} {p[2]}".strip())
        cov = [p for p in c if p[1] == "covered"]
        fails += [f"{p[3]}: {p[1]}" for p in c if p[1] != "covered"]
        ok = not fails
        bad += 0 if ok else 1
        print(f"{block:16s} {len(a):7d} {len(proven):7d} {len(bnd):8d} {len(c):6d} {len(cov):8d}  "
              f"{'PASS' if ok else 'FAIL'}")
        for b, depth in bnd:
            d, why = bounded[(block, b)]
            print(f"    bounded {b}: depth {depth or d} reached (listed {d}): {why}")
        for f in fails:
            print(f"    *** {f}")
    print(f"vcformal: {'PASS' if bad == 0 else 'FAIL'}")
    return bad


def neg(runs):
    bad = 0
    for spec in runs:
        name, path = spec.split("=", 1)
        a = [p for p in parse(path) if p[0] == "Assertion"]
        fal = [f"{p[3]}@{p[4]}" for p in a if p[1] == "falsified"]
        ok = len(fal) > 0
        bad += 0 if ok else 1
        print(f"{name:48s} {len(fal):3d} falsified  {'as it must' if ok else '*** NONE: the mutant is not caught'}"
              f"  {' '.join(fal[:6])}{' ...' if len(fal) > 6 else ''}")
    print(f"vcformalneg: {'PASS' if bad == 0 else 'FAIL'}")
    return bad


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "prove":
        sys.exit(1 if prove(sys.argv[2], sys.argv[3:]) else 0)
    sys.exit(1 if neg(sys.argv[2:]) else 0)
