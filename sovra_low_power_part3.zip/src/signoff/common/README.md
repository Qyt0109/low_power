# `signoff/common` — the shared design read and the gates

Four files used by every sign-off target. They make the tools read one design
the same way and judge their reports by one rule. How to run the flow and the
waiver policy are in [`../README.md`](../README.md); the results are in
[`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md).

## Files

| File | Used by | What it does |
|---|---|---|
| [`read_design.tcl`](read_design.tcl) | `lp/vclp.tcl`, `cdc/vccdc.tcl`, `rdc/vcrdc.tcl`, `lint/vclint.tcl` (sourced) | Analyses and elaborates the design for VC Static |
| [`vc_gate.py`](vc_gate.py) | `make vclp vccdc vcrdc vclint` | The PASS/FAIL verdict of a VC Static run |
| [`fv_summary.py`](fv_summary.py) | `make vcformal vcformalneg` | The PASS/FAIL verdict of the VC Formal runs |
| [`waiver_counts.tcl`](waiver_counts.tcl) | the four VC Static scripts (sourced at the end) | Writes `v*_waivers.txt`: how many violations each waiver absorbed |

## `read_design.tcl`

The caller sets four Tcl variables before sourcing it:

| Variable | Meaning |
|---|---|
| `signoff_top` | The top module to elaborate (`soc4_top`, or `ppu_axi_dom_top` for the ppudom CDC run) |
| `signoff_tops` | Further tops elaborated alongside it (VC Lint's 10 extra tops), or `{}` |
| `signoff_bbox` | Modules to black-box, each justified where the caller sets it, or `{}` |
| `signoff_elab` | Extra VCS elaboration options, for example `-pvalue+` overrides, or `{}` |

The environment supplies `PMU_SRC` (the repository's `src/`) and
`SIGNOFF_FLIST`, the `files.f` that the Makefile writes from its own source
variables. The script then:

- sets `enable_sim_memory_models true`. Without it VC Static black-boxes, on
  its own, any module that "looks like a simulation memory model", and it took
  `ppu_ip_core`, which must be analysed. Black boxes are chosen only through
  `signoff_bbox`;
- analyses with `-timescale=1ns/1ps +define+SYNTHESIS +lint=all` and the two
  vendored OpenTitan include directories (`prim`, `dv_utils`).
  `+define+SYNTHESIS` removes the simulation-only `ifndef SYNTHESIS` checks in
  the platform RTL and in OpenTitan's `prim_assert` macros. `+lint=all` adds
  VCS's own lint messages to the design read;
- elaborates `signoff_top` with `signoff_elab` and `signoff_tops`.

## `vc_gate.py`

```
vc_gate.py <tool> <report> <open_findings.txt>
```

It parses the "Tree Summary" table of `report_<app>` output: severity, stage,
tag, unwaived count and waived count. Then:

- Every unwaived fatal, error or warning must appear in `<open_findings.txt>`
  with the same tag and count. Otherwise it is `UNDISPOSITIONED` and the gate
  fails.
- A listed finding whose tag no longer occurs fails the gate ("update the
  list").
- Infos are printed and never gated.
- The waived counts are printed per tag.

The findings file has one line per finding, `TAG COUNT ID text`, with `#`
comments. The exit status is 1 if anything is undispositioned. The script
exits with a message if the report is missing or has no Tree Summary.

## `fv_summary.py`

```
fv_summary.py prove <bounded.txt> <block>=<fv_list.rpt> ...
fv_summary.py neg   <block>:<define>=<fv_list.rpt> ...
```

It reads each run's `report_fv -list` output (`fv_list.rpt`), the Assertion
and Cover sections.

- `prove`: a block passes when every assertion is proven and not vacuous, and
  every cover is covered. An `inconclusive` assertion passes only if
  `bounded.txt` lists it as `block property depth reason`. It prints one row
  per block (assertions, proven, bounded, covers, covered, verdict).
- `neg`: each mutant run passes when at least one assertion is falsified. It
  prints the falsified properties with their depths.

## `waiver_counts.tcl`

Defines `so_waiver_counts <app> <outfile>`. For each waiver in the session
(read back from `waive_<app> -tcl`), it runs `report_<app> -waived <name>`
and writes the total of the "Waived" column, one line per waiver. It writes a
temporary `so_w.rpt` in the run directory and deletes it.

## Limits

- `vc_gate.py` depends on the layout of the Tree Summary table in
  W-2024.09-SP2-1 reports. A tool update that changes the columns makes it
  stop with "no Tree Summary" or misread counts; check it against a known run
  after any upgrade.
- Open findings are matched by tag and count, not by object. A finding that
  moves to another object with the same count still passes. The verbose
  report shows the objects.
- For VC Lint, `waiver_counts.tcl` counts `waive_lint` waivers only. The
  `waive_read` waivers (design-read messages) are not in `vclint_waivers.txt`.

## References

- [`../README.md`](../README.md): targets, environment, gate rules, waiver
  policy.
- [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 1.
- `src/Makefile`: `vc_static`, `vc_gate`, `vc_formal`, `SOC4_DUT_SRCS`,
  `PPU_SRCS`, `VCLINT_SRCS`.
