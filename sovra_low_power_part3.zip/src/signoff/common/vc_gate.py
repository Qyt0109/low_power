#!/usr/bin/env python3
"""vc_gate.py -- the verdict of a VC Static run (make vclp/vccdc/vcrdc/vclint).

  vc_gate.py <tool> <report> <open_findings.txt>

<report> is the tool's report_<app> output; its "Tree Summary" table gives,
per tag, the severity, stage, unwaived count and (once a waiver exists) the
waived count. Every unwaived fatal, error or warning must be listed, tag and
count, in <open_findings.txt> as a known open finding; anything else fails the
target, and so does a listed finding that no longer occurs (fixed: update the
list). Infos are printed, never gated. Waivers live in the tool's waivers*.tcl,
each with its justification as the -comment.

open_findings.txt: one finding per line, "TAG COUNT ID text"; '#' comments.
"""
import re
import sys

SEVERITIES = ("fatal", "error", "warning", "info")


def tree(path):
    """{(severity, tag): [unwaived, waived]} from the Tree Summary table."""
    rows = {}
    try:
        text = open(path, errors="replace").read()
    except OSError:
        sys.exit(f"vc_gate: cannot read {path}")
    m = re.search(r"Tree Summary\s*\n(.*?)\n\s*Total\b", text, re.S)
    if not m:
        sys.exit(f"vc_gate: no Tree Summary in {path}")
    cols = None
    for line in m.group(1).splitlines():
        f = line.split()
        if f[:3] == ["Severity", "Stage", "Tag"]:
            cols = f                      # Count, then Waived and/or Compressed
            continue
        if cols and len(f) >= 4 and f[3].isdigit() and f[0] in SEVERITIES:
            r = rows.setdefault((f[0], f[2]), [0, 0])
            r[0] += int(f[3])
            if "Waived" in cols and len(f) > cols.index("Waived"):
                r[1] += int(f[cols.index("Waived")])
    return rows


def main():
    tool, rpt, findings = sys.argv[1:4]
    rows = tree(rpt)
    known = {}
    for line in open(findings):
        line = line.split("#", 1)[0].strip()
        if line:
            tag, count, fid = line.split(None, 3)[:3]
            known[tag] = (int(count), fid)
    bad = 0
    seen = set()
    print(f"==== {tool}: unwaived violations ====")
    for (sev, tag), (n, _) in sorted(rows.items()):
        if n == 0:
            continue
        if sev == "info":
            print(f"  info     {tag:34s} {n:5d}  (reviewed; not gated)")
            continue
        seen.add(tag)
        if tag in known and known[tag][0] == n:
            print(f"  {sev:8s} {tag:34s} {n:5d}  OPEN FINDING {known[tag][1]}")
        else:
            bad += 1
            why = f"listed with {known[tag][0]}" if tag in known else "not waived, not an open finding"
            print(f"  {sev:8s} {tag:34s} {n:5d}  *** UNDISPOSITIONED ({why})")
    for tag, (n, fid) in sorted(known.items()):
        if tag not in seen:
            bad += 1
            print(f"  *** open finding {fid} ({tag} x{n}) no longer occurs: update {findings}")
    nw = sum(w for (_, w) in rows.values())
    print(f"==== {tool}: waived (waivers*.tcl, each justified) ====")
    for (sev, tag), (_, w) in sorted(rows.items()):
        if w:
            print(f"  {sev:8s} {tag:34s} {w:5d}  waived")
    if nw == 0:
        print("  (none)")
    print(f"{tool}: gate {'PASS' if bad == 0 else 'FAIL'} ({bad} undispositioned) -- "
          f"{nw} waived, {len(known)} open finding class(es)")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
