# read_design.tcl -- the design read shared by VC LP, VC CDC, VC RDC and VC Lint
# (platform plan phase 6; src/signoff/SIGNOFF_REPORT.md).
#
# The caller sets, before sourcing this file:
#   signoff_top     the top module to elaborate (soc4_top)
#   signoff_tops    further top modules elaborated alongside it (VC Lint), or {}
#   signoff_bbox    modules to black-box, each justified where it is set, or {}
#   signoff_elab    further VCS elaboration options (e.g. -pvalue+ overrides,
#                   each justified where it is set), or {}
# and the environment gives PMU_SRC (the repository's src/) and SIGNOFF_FLIST,
# the source list the Makefile writes from its own variables (SOC4_DUT_SRCS
# for soc4_top), so the static tools read exactly what the simulations read.
#
# +define+SYNTHESIS: every `ifndef SYNTHESIS block in the platform RTL and in
# the vendored OpenTitan prim_assert macros is a simulation-only check
# ($error, assertions); the static tools see the synthesizable design.
#
# enable_sim_memory_models: VC Static otherwise black-boxes on its own any
# module that "looks like a simulation memory model"; it took ppu_ip_core (the
# stand-in accelerator's logic, which must be analysed). Black boxes are
# chosen here, explicitly, through signoff_bbox.

set S $::env(PMU_SRC)
set_app_var enable_sim_memory_models true
foreach d $signoff_bbox { set_blackbox -designs $d }

analyze -format sverilog -vcs "-timescale=1ns/1ps +define+SYNTHESIS +lint=all \
  +incdir+$S/vendor/opentitan/prim +incdir+$S/vendor/opentitan/dv_utils \
  -f $::env(SIGNOFF_FLIST)"

if {![info exists signoff_elab]} { set signoff_elab {} }
elaborate $signoff_top -vcs "+lint=all $signoff_elab $signoff_tops"
