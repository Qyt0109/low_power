# waiver_counts.tcl -- per-waiver counts of a VC Static run (SIGNOFF_REPORT.md).
#   so_waiver_counts <app> <outfile>
# For each waiver the session holds (waive_<app> -tcl), report_<app> -waived
# gives its own Tree Summary; the "Waived" column total is written, one line
# per waiver, to <outfile>.
proc so_waiver_counts {app out} {
  redirect -variable dump { waive_$app -tcl }
  set names [regexp -all -inline -- {-add\s+\{?([A-Za-z0-9_]+)\}?} $dump]
  set fo [open $out w]
  foreach {- n} $names {
    report_$app -waived $n -file so_w.rpt
    set fh [open so_w.rpt]; set t [read $fh]; close $fh
    set sum 0
    foreach line [split $t "\n"] {
      if {[regexp {^\s+(error|warning|info|fatal)\s+\S+\s+\S+\s+\d+\s+(\d+)} $line -> - w]} {
        incr sum $w
      }
    }
    puts $fo [format "%-28s %6d" $n $sum]
  }
  close $fo
  file delete so_w.rpt
}
