# VC Formal FPV: scp_wdog (src/pmu/rtl/scp_wdog.sv) against
# src/formal/scp_wdog/scp_wdog_props.sv.
#   cd <run dir>; PMU_SRC=<repo>/src [FV_DEFINES=+define+X] vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/scp_wdog.tcl
# Elaboration parameters (formal only, stated in the report): DRAIN_MAX = 8
# (default 1024) so that a_drain_max / a_drainto_cause (a DRAIN_MAX-cycle
# sequence) stay small; KEY and RST_CYCLES = 16 are the defaults.
set S $::env(PMU_SRC)
set D ""
if {[info exists ::env(FV_DEFINES)]} { set D $::env(FV_DEFINES) }

set_fml_appmode FPV
read_file -top scp_wdog -format sverilog -sva -vcs "-sverilog -timescale=1ns/1ps $D \
  -pvalue+scp_wdog.DRAIN_MAX=8 \
  $S/pmu/rtl/scp_wdog.sv $S/formal/scp_wdog/scp_wdog_props.sv"

create_clock clk_i -period 100
# por_ni: the power-on reset, applied for the reset state and then held inactive.
create_reset por_ni -sense low
# rst_ni: asserted for the reset state too, then released to be a FREE input
# (the SCP subsystem reset, which may come at any time; not a create_reset, so
# the tool does not hold it inactive).
sim_force rst_ni -apply 0
sim_run -stable
sim_save_reset
sim_release rst_ni

check_fv -block
report_fv -list > fv_list.rpt
report_fv -list
quit
