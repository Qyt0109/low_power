# VC Formal FPV: scp_irq (src/pmu/rtl/scp_irq.sv) against
# src/formal/scp_irq/scp_irq_props.sv.
#   cd <run dir>; PMU_SRC=<repo>/src [FV_DEFINES=+define+X] vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/scp_irq.tcl
# Elaboration parameters (formal only, stated in the report): NUM_IN = 4,
# ASYNC = 4'b0011 (inputs 0 and 1 through the two-flop synchroniser, 2 and 3
# synchronous), SYNC_STAGES = 2 (the default). Both kinds of input are covered.
set S $::env(PMU_SRC)
set D ""
if {[info exists ::env(FV_DEFINES)]} { set D $::env(FV_DEFINES) }

set_fml_appmode FPV
read_file -top scp_irq -format sverilog -sva -vcs "-sverilog -timescale=1ns/1ps $D \
  -pvalue+scp_irq.NUM_IN=4 -pvalue+scp_irq.ASYNC=3 \
  $S/rtl/common/cdc_sync.sv $S/pmu/rtl/scp_irq.sv $S/formal/scp_irq/scp_irq_props.sv"

create_clock clk_i -period 100
create_reset rst_ni -sense low
sim_run -stable
sim_save_reset

check_fv -block
report_fv -list > fv_list.rpt
report_fv -list
quit
