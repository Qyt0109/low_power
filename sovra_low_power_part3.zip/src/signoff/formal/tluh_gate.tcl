# VC Formal FPV: tluh_gate (src/rtl/acg/tluh_gate.sv, the TL-UH data path of
# acg_tluh) as the top with its default parameters (AW 32, DW 64, SRCW 8,
# SINKW 1, SZW 4, OUTSTANDING 16), the properties of
# src/formal/tluh_gate/tluh_gate_props.sv. flush_req_i/err_en_i are free
# inputs (any controller, acg_ctrl included).
#
#   cd <run dir>; PMU_SRC=<repo>/src [FV_DEFINES="+define+ACG_TLUH_MUT_SPLIT"] \
#     $VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/tluh_gate.tcl
#
# Writes fv_list.rpt (report_fv -list) in the current directory.
set S $::env(PMU_SRC)
set DEFS ""
if {[info exists ::env(FV_DEFINES)]} { set DEFS $::env(FV_DEFINES) }

set_fml_appmode FPV
set_fml_var fml_vacuity_on true
# wall-clock cap for the whole check_fv; anything unresolved is reported bounded
set_fml_var fml_max_time 60M

set files [list \
  $S/vendor/sovra_tl/tl_pkg.sv $S/rtl/tluh/tluh_pkg.sv $S/rtl/tluh/tl_beat_cnt.sv \
  $S/rtl/acg/tluh_gate.sv $S/formal/tluh_gate/tluh_gate_props.sv]

read_file -top tluh_gate -format sverilog -sva \
  -vcs "-sverilog -timescale=1ns/1ps +define+SYNTHESIS $DEFS [join $files { }]"

create_clock clk_i -period 100
create_reset rst_ni -sense low
sim_run -stable
sim_save_reset

check_fv -block
redirect -file fv_list.rpt {report_fv -list}
report_fv -list
if {[info exists ::env(FV_POST)]} { source $::env(FV_POST) }
quit
