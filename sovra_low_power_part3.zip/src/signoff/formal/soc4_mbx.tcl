# VC Formal FPV: soc4_mbx (src/soc4/rtl/soc4_mbx.sv) with soc4_top's MBX_*
# parameters (src/formal/soc4_mbx/soc4_mbx_fv_top.sv) and the properties of
# src/formal/soc4_mbx/soc4_mbx_props.sv. The shared queue memory tc_sram is
# blackboxed: its read data is a free input, the properties are on the request
# path into it and the data path out of it.
#
#   cd <run dir>; PMU_SRC=<repo>/src [FV_DEFINES="+define+SOC4_MUT_FW_OPEN"] \
#     $VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/soc4_mbx.tcl
#
# Optional: FV_TOP=soc4_mbx_fv_top_shared (both agents on one port).
# Writes fv_list.rpt (report_fv -list) in the current directory.
set S $::env(PMU_SRC)
set DEFS ""
if {[info exists ::env(FV_DEFINES)]} { set DEFS $::env(FV_DEFINES) }
set OT $S/vendor/opentitan
# FV_TOP: soc4_mbx_fv_top (default, soc4_top's parameters) or
# soc4_mbx_fv_top_shared (stated override: both agents on one port)
set TOP soc4_mbx_fv_top
if {[info exists ::env(FV_TOP)] && $::env(FV_TOP) ne ""} { set TOP $::env(FV_TOP) }

set_fml_appmode FPV
set_fml_var fml_vacuity_on true
set_blackbox -designs {tc_sram}

set files [list \
  $OT/prim/prim_util_pkg.sv $OT/prim/prim_mubi_pkg.sv $OT/prim/prim_secded_pkg.sv \
  $OT/top/top_pkg.sv $OT/prim/prim_count_pkg.sv $OT/tlul/tlul_pkg.sv \
  $OT/prim/prim_secded_inv_64_57_enc.sv $OT/prim/prim_secded_inv_64_57_dec.sv \
  $OT/prim/prim_secded_inv_39_32_enc.sv $OT/prim/prim_secded_inv_39_32_dec.sv \
  $OT/prim/prim_sec_anchor_buf.sv $OT/prim_generic/prim_buf.sv \
  $OT/prim/prim_count.sv $OT/prim/prim_fifo_sync_cnt.sv $OT/prim/prim_fifo_sync.sv \
  $OT/tlul/tlul_data_integ_enc.sv $OT/tlul/tlul_data_integ_dec.sv \
  $OT/tlul/tlul_cmd_intg_gen.sv $OT/tlul/tlul_cmd_intg_chk.sv \
  $OT/tlul/tlul_rsp_intg_gen.sv $OT/tlul/tlul_rsp_intg_chk.sv \
  $OT/tlul/tlul_err.sv $OT/tlul/tlul_err_resp.sv $OT/tlul/tlul_fifo_sync.sv \
  $OT/tlul/tlul_socket_1n.sv $OT/tlul/tlul_sram_byte.sv $OT/tlul/tlul_adapter_sram.sv \
  $OT/tlul/tlul_adapter_reg.sv \
  $S/vendor/pulp/tech_cells_generic/tc_sram.sv \
  $S/soc4/rtl/soc4_tl_bound.sv $S/soc4/rtl/soc4_mbx.sv \
  $S/formal/soc4_mbx/soc4_mbx_fv_top.sv $S/formal/soc4_mbx/soc4_mbx_props.sv]

read_file -top $TOP -format sverilog -sva \
  -vcs "-sverilog -timescale=1ns/1ps +incdir+$OT/prim +incdir+$OT/dv_utils $DEFS [join $files { }]"

create_clock clk_i -period 100
create_reset rst_ni -sense low
sim_run -stable
sim_save_reset

check_fv -block
redirect -file fv_list.rpt {report_fv -list}
report_fv -list
# optional debug hook (e.g. fvtrace of a falsified property)
if {[info exists ::env(FV_POST)]} { source $::env(FV_POST) }
quit
