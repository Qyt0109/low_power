# VC Formal FPV: hart_ready_adp (src/rtl/adp/hart_ready_adp.sv) against
# src/formal/hart_ready_adp/hart_ready_adp_props.sv (bound properties plus the
# formal top hart_ready_adp_fv: the adapter and one qchannel_device per hart).
#   cd <run dir>; PMU_SRC=<repo>/src [FV_DEFINES=+define+X] vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/hart_ready_adp.tcl
# Configuration = src/tb/adp/hart_ready_adp_tb.sv's: NUM_HARTS = 2,
# NUM_PORTS = 3 (TL-C + TL-UH on hart 0, TL-UH on hart 1), SZW = 4,
# LOG2_BYTES = 3, CNT_W = 6 (the default).
set S $::env(PMU_SRC)
set D ""
if {[info exists ::env(FV_DEFINES)]} { set D $::env(FV_DEFINES) }

set_fml_appmode FPV
read_file -top hart_ready_adp_fv -format sverilog -sva -vcs "-sverilog -timescale=1ns/1ps $D \
  $S/vendor/sovra_tl/tl_pkg.sv $S/rtl/tluh/tluh_pkg.sv $S/rtl/tluh/tl_beat_cnt.sv \
  $S/rtl/qchannel/qchannel_pkg.sv $S/rtl/common/cdc_sync.sv $S/rtl/qchannel/qchannel_device.sv \
  $S/rtl/adp/hart_ready_adp.sv $S/formal/hart_ready_adp/hart_ready_adp_props.sv"

create_clock clk_i -period 100
create_reset rst_ni -sense low
sim_run -stable
sim_save_reset

check_fv -block
report_fv -list > fv_list.rpt
report_fv -list
quit
