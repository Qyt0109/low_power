# VC Formal FPV: the Q-Channel controller and device FSMs
# (src/rtl/qchannel/qchannel_controller.sv, qchannel_device.sv, with
# src/rtl/common/cdc_sync.sv) against AMBA LPI (ARM IHI 0068C) Section 2.1:
# each alone with the other side a constrained free input, and the two
# connected (src/formal/qchannel/qchannel_fv_top.sv, qchannel_props.sv).
#
#   cd <run dir>; PMU_SRC=<repo>/src [FV_DEFINES="+define+..."] \
#     $VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/qchannel.tcl
#
# Writes fv_list.rpt (report_fv -list) in the current directory.
set S $::env(PMU_SRC)
set DEFS ""
if {[info exists ::env(FV_DEFINES)]} { set DEFS $::env(FV_DEFINES) }

set_fml_appmode FPV
set_fml_var fml_vacuity_on true
set_fml_var fml_max_time 60M

set files [list \
  $S/rtl/qchannel/qchannel_pkg.sv $S/rtl/common/cdc_sync.sv \
  $S/rtl/qchannel/qchannel_controller.sv $S/rtl/qchannel/qchannel_device.sv \
  $S/formal/qchannel/qchannel_fv_top.sv $S/formal/qchannel/qchannel_props.sv]

read_file -top qchannel_fv_top -format sverilog -sva \
  -vcs "-sverilog -timescale=1ns/1ps $DEFS [join $files { }]"

create_clock clk -period 100
create_reset rst_n -sense low
sim_run -stable
sim_save_reset

check_fv -block
redirect -file fv_list.rpt {report_fv -list}
report_fv -list
if {[info exists ::env(FV_POST)]} { source $::env(FV_POST) }
quit
