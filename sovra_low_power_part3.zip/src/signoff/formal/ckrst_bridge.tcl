# VC Formal FPV: ckrst_bridge (src/rtl/ckrst/ckrst_bridge.sv) against
# src/formal/ckrst_bridge/ckrst_bridge_props.sv.
#   cd <run dir>; PMU_SRC=<repo>/src [FV_DEFINES=+define+X] [FV_MAX_WAIT=n] vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/ckrst_bridge.tcl
# Elaboration parameters: the soc4 instances' NUM_RST = 2, STEP_W = 1,
# STEP_SYNC = 2, ACK_SYNC = 0 (the defaults); MAX_WAIT = 12 for formal (default
# 300) so that a_miss_seq (a MAX_WAIT-cycle sequence) and the MISSING covers
# stay shallow. FV_MAX_WAIT overrides it (e.g. 300 for the SoC value).
set S $::env(PMU_SRC)
set D ""
if {[info exists ::env(FV_DEFINES)]} { set D $::env(FV_DEFINES) }
set MW 12
if {[info exists ::env(FV_MAX_WAIT)]} { set MW $::env(FV_MAX_WAIT) }

set_fml_appmode FPV
read_file -top ckrst_bridge -format sverilog -sva -vcs "-sverilog -timescale=1ns/1ps $D \
  -pvalue+ckrst_bridge.MAX_WAIT=$MW \
  $S/rtl/common/cdc_sync.sv $S/rtl/ckrst/ckrst_bridge.sv $S/formal/ckrst_bridge/ckrst_bridge_props.sv"

create_clock clk_i -period 100
create_reset rst_ni -sense low
sim_run -stable
sim_save_reset

check_fv -block
report_fv -list > fv_list.rpt
report_fv -list
quit
