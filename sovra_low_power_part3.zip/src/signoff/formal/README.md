# `signoff/formal` — VC Formal property proofs

Formal property verification (V7) with VC Formal in FPV mode, run by
`make vcformal` (prove) and `make vcformalneg` (planted mutants). This
directory holds one run script per block and the bounded-proof list. The
properties are bind files in `src/formal/<block>/`. Results, property counts
and the findings from the proofs: [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md)
Section 6.

## Files

| File | Block (RTL) | Formal top and parameters |
|---|---|---|
| [`scp_irq.tcl`](scp_irq.tcl) | `pmu/rtl/scp_irq.sv` | `scp_irq`, `NUM_IN = 4`, `ASYNC = 4'b0011` (inputs 0, 1 through `cdc_sync`; 2, 3 synchronous) |
| [`scp_wdog.tcl`](scp_wdog.tcl) | `pmu/rtl/scp_wdog.sv` | `scp_wdog`, `DRAIN_MAX = 8` (default 1024). `por_ni` is the reset; `rst_ni` is asserted for the reset state, then released as a free input |
| [`ckrst_bridge.tcl`](ckrst_bridge.tcl) | `rtl/ckrst/ckrst_bridge.sv` | `ckrst_bridge`, soc4's defaults except `MAX_WAIT = 12` (default 300); `FV_MAX_WAIT` overrides it |
| [`hart_ready_adp.tcl`](hart_ready_adp.tcl) | `rtl/adp/hart_ready_adp.sv` | `hart_ready_adp_fv`: the adapter and one `qchannel_device` per hart; 2 harts, 3 ports (TL-C + TL-UH on hart 0, TL-UH on hart 1) |
| [`soc4_mbx.tcl`](soc4_mbx.tcl) | `soc4/rtl/soc4_mbx.sv` | `soc4_mbx_fv_top` with soc4_top's `MBX_*` parameters; `tc_sram` black-boxed (its read data is a free input). `FV_TOP=soc4_mbx_fv_top_shared` puts both agents on one port |
| [`tluh_gate.tcl`](tluh_gate.tcl) | `rtl/acg/tluh_gate.sv` | `tluh_gate`, defaults (AW 32, DW 64, SRCW 8, SINKW 1, SZW 4, OUTSTANDING 16); `flush_req_i`/`err_en_i` free |
| [`qchannel.tcl`](qchannel.tcl) | `rtl/qchannel/qchannel_controller.sv`, `qchannel_device.sv` | `qchannel_fv_top`: each FSM alone against a constrained free other side, and the two connected |
| [`bounded.txt`](bounded.txt) | — | Assertions accepted as bounded proofs, `block property depth reason`. Empty: every assertion is fully proven |

Every script reads its files with `read_file -format sverilog -sva`, defines
the clock (period 100) and reset, runs `sim_run -stable` and `sim_save_reset`
for the reset state, then `check_fv -block`, and writes `report_fv -list` to
`fv_list.rpt` in the current directory. `qchannel`, `soc4_mbx` and
`tluh_gate` set `fml_vacuity_on true`; `qchannel` and `tluh_gate` cap
`check_fv` at 60 minutes (`fml_max_time 60M`).

### Environment variables

| Variable | Read by | Meaning |
|---|---|---|
| `PMU_SRC` | all | The repository's `src/` (set by the Makefile) |
| `FV_DEFINES` | all | Extra defines, for example `+define+SOC4_MUT_FW_OPEN` (set by `vcformalneg`) |
| `FV_MAX_WAIT` | `ckrst_bridge.tcl` | Overrides `MAX_WAIT` (for example 300, the SoC value) |
| `FV_TOP` | `soc4_mbx.tcl` | `soc4_mbx_fv_top` (default) or `soc4_mbx_fv_top_shared` |
| `FV_POST` | `qchannel.tcl`, `soc4_mbx.tcl`, `tluh_gate.tcl` | A Tcl file sourced after the proof, for debugging |

## How to run and judge

```sh
make -C src vcformal       # 7 blocks (FV_BLOCKS)
make -C src vcformalneg    # 10 mutant runs (FV_MUTANTS)
```

Each block runs in `build/signoff/formal/<block>/`, each mutant in
`build/signoff/formal/<block>_mut_<DEFINE>/`, with `run.log` and
`fv_list.rpt`. A run fails at once if `vcf` fails or writes no `fv_list.rpt`.

By hand, for one block:

```sh
export VC_STATIC_HOME=/system/EDA/Synopsys/vcs/W-2024.09-SP2/vcfca
export PMU_SRC=/project/sovra/99_work/quyetdv/pmu/src
mkdir -p /tmp/fv_scp_irq && cd /tmp/fv_scp_irq
$VC_STATIC_HOME/bin/vcf -no_ui -fmode FPV -f $PMU_SRC/signoff/formal/scp_irq.tcl
```

**Verdict** (`../common/fv_summary.py`):

- `vcformal` passes when every assertion of every block is proven and not
  vacuous (or listed in `bounded.txt`), and every cover is covered.
- `vcformalneg` passes when every mutant falsifies at least one assertion.

The mutants (`FV_MUTANTS` in `src/Makefile`) are the ones planted for the
unit tests and `soc4neg`: `SOC4_MUT_IRQ_SYNC0` (scp_irq),
`SOC4_MUT_WDOG_CAUSE_SUB` (scp_wdog), `CKRST_MUT_NOLATE` (ckrst_bridge),
`HART_READY_MUT_NODRAIN` and `HART_READY_MUT_SETWINS` (hart_ready_adp),
`SOC4_MUT_FW_OPEN` and `SOC4_MUT_FW_NOMASK` (soc4_mbx),
`ACG_TLUH_MUT_SPLIT`, `ACG_TLUH_MUT_ONEBEAT` and `ACG_TLUH_MUT_ATOM`
(tluh_gate).

Result on 2026-10-06: 271/271 assertions fully proven, 127/127 covers hit,
none bounded; every mutant falsifies 2 to 16 assertions.

## Limits and open items

- **Reduced parameters.** scp_irq (4 inputs), scp_wdog (`DRAIN_MAX = 8`) and
  ckrst_bridge (`MAX_WAIT = 12`; also proven at 300 by hand) are proven at
  smaller values than the SoC's so that the counter sequences stay shallow.
  The report states each one.
- **Black box.** In soc4_mbx, `tc_sram`'s read data is a free input: the
  properties cover the request path into the queue memory and the data path
  out of it, not the memory.
- **qchannel has no mutant** in `FV_MUTANTS`. Two scratch mutants were run by
  hand (15 assertions falsified); they are not in the repository.
- **Assumptions** constrain inputs only and each cites an interface rule in
  the props file. A wrong assumption hides bugs; read them with the
  properties.
- **Open findings from the proofs:** F-TLUH-1, F-TLUH-2, F-ADP-1, F-ADP-2,
  F-ADP-3, F-WDOG-1, F-CKRST-1 (behaviours to decide on; none failed a proof).
  See the report.
- **Tool.** Use `vcf -no_ui`: `-batch` needs the missing `libQt5Charts.so.5`.
  `fvtrace` crashes in this install, so counterexamples are debugged with
  helper assertions.

## References

- [`../SIGNOFF_REPORT.md`](../SIGNOFF_REPORT.md) Section 6.
- `src/formal/<block>/`: the property and formal-top files.
- AMBA Low Power Interface, ARM IHI 0068C, Section 2.1 (qchannel), Table 2-1.
