`timescale 1ns/1ps
// soc4's always-on AP: a third Ibex, with its own RAM, timer and bus, running a
// bare-metal RPMI client. It reaches the SCP only through TL-UL, at 0x2000_0000.
//
// References: docs/SOC4_DESIGN.md Sections 4.3 (its map) and 5.7
// (this module), decision 10 of 2026-10-01; OpenTitan tlul_adapter_host.sv at
// 16e86c9e (vendor/opentitan/README.md).
//
//   u_core (scp_core, Ibex) ──instr──────────────────────────► u_ram port B
//        └──data──► u_split ──local──► u_bus ──► u_ram port A    0x0000_0000
//                     │                     ├──► u_timer         0x0001_0000
//                     │                     └──► ext_* (TB)      0x0002_0000
//                     └──axi──► u_host (tlul_adapter_host) ──► tl_o  0x2000_0000
//
// THE MAP (Section 4.3)
//
//   0x0000_0000  64 KB  scp_ram, image +ap_firmware=<file.vmem>
//   0x0001_0000   1 KB  timer
//   0x0002_0000   4 KB  ext_*: the testbench's simulation control (TAG "ap"),
//                       the offsets of the SCP's (hal/sim.h), so SIM_HALT is
//                       0x0002_0008 as crt0.S expects
//   0x2000_0000  16 KB  TL-UL, multi-cycle: soc4_mbx (Section 4.6)
//   other               bus.sv decode error: a load/store access fault
//
// The instruction port goes straight to the RAM's port B, as in scp_top. The
// AP takes no interrupts and polls.
//
// THE FIXED a_source
//
// tlul_adapter_host has no a_source parameter: with MAX_REQS = 2 its a_source
// is a rotating counter (tlul_adapter_host.sv:60-91). soc4_mbx's firewall
// admits one source, so the AP's is set here, after the adapter. The command
// integrity does not cover a_source (tl_h2d_cmd_intg_t, tlul_pkg.sv:60-65) and
// the adapter ignores d_source, so the override is integrity-neutral.
// MAX_REQS = 2 matches the two same-side requests scp_data_split can issue
// (scp_data_split.sv:22-31); with 1, gnt_o = a_ready would accept a second one
// anyway (tlul_adapter_host.sv:117).

module soc4_ap #(
  parameter logic [7:0] AP_SOURCE = 8'h10   // the AP's TL-UL a_source (SOC4_AP_SOURCE)
) (
  input  logic              clk_i,
  input  logic              rst_ni,
  input  logic              fetch_en_i,     // AP_RUN && !bfm_sel_i

  // ---- 0x0002_0000: the simulation control page, bus.sv protocol ----
  output logic              ext_req_o,
  output logic              ext_we_o,
  output logic [3:0]        ext_be_o,
  output logic [31:0]       ext_addr_o,
  output logic [31:0]       ext_wdata_o,
  input  logic              ext_rvalid_i,
  input  logic [31:0]       ext_rdata_i,
  input  logic              ext_err_i,

  // ---- 0x2000_0000: TL-UL host ----
  output tlul_pkg::tl_h2d_t tl_o,
  input  tlul_pkg::tl_d2h_t tl_i,

  output logic              core_sleep_o
);

  localparam logic [31:0] RAM_BASE   = 32'h0000_0000;
  localparam logic [31:0] RAM_MASK   = 32'hFFFF_0000;
  localparam logic [31:0] TIMER_BASE = 32'h0001_0000;
  localparam logic [31:0] TIMER_MASK = 32'hFFFF_FC00;
  localparam logic [31:0] EXT_BASE   = 32'h0002_0000;
  localparam logic [31:0] EXT_MASK   = 32'hFFFF_F000;   // 4 KB: scp_sim_ctrl decodes addr[11:0] only
  localparam logic [31:0] TLUL_BASE  = 32'h2000_0000;
  localparam logic [31:0] TLUL_MASK  = 32'hFFFF_C000;

  localparam int unsigned NrDevices = 3;
  localparam int unsigned DevRam    = 0;
  localparam int unsigned DevTimer  = 1;
  localparam int unsigned DevExt    = 2;

  // ===========================================================================
  // Core
  // ===========================================================================
  logic        instr_req, instr_gnt, instr_rvalid, instr_err;
  logic [31:0] instr_addr, instr_rdata;

  logic        core_req, core_gnt, core_rvalid, core_we, core_err;
  logic [3:0]  core_be;
  logic [31:0] core_addr, core_wdata, core_rdata;

  scp_core #(.HART_ID(32'h10)) u_core (
    .clk_i         (clk_i),
    .rst_ni        (rst_ni),
    .boot_addr_i   (32'h0000_0000),

    .instr_req_o   (instr_req),
    .instr_gnt_i   (instr_gnt),
    .instr_rvalid_i(instr_rvalid),
    .instr_addr_o  (instr_addr),
    .instr_rdata_i (instr_rdata),
    .instr_err_i   (instr_err),

    .data_req_o    (core_req),
    .data_gnt_i    (core_gnt),
    .data_rvalid_i (core_rvalid),
    .data_we_o     (core_we),
    .data_be_o     (core_be),
    .data_addr_o   (core_addr),
    .data_wdata_o  (core_wdata),
    .data_rdata_i  (core_rdata),
    .data_err_i    (core_err),

    // The AP polls: no interrupt reaches it.
    .irq_timer_i   (1'b0),
    .irq_external_i(1'b0),
    .irq_fast_i    (15'd0),
    .irq_nm_i      (1'b0),

    .fetch_enable_i(fetch_en_i),
    .core_sleep_o  (core_sleep_o)
  );

  // ===========================================================================
  // Split: the TL-UL window off, the rest to bus.sv
  // ===========================================================================
  logic        loc_req, loc_gnt, loc_rvalid, loc_we, loc_err;
  logic [3:0]  loc_be;
  logic [31:0] loc_addr, loc_wdata, loc_rdata;

  logic        tl_req, tl_gnt, tl_rvalid, tl_we, tl_err;
  logic [3:0]  tl_be;
  logic [31:0] tl_addr, tl_wdata, tl_rdata;

  scp_data_split #(.AXI_BASE(TLUL_BASE), .AXI_MASK(TLUL_MASK)) u_split (
    .clk_i        (clk_i),
    .rst_ni       (rst_ni),

    .data_req_i   (core_req),
    .data_gnt_o   (core_gnt),
    .data_rvalid_o(core_rvalid),
    .data_we_i    (core_we),
    .data_be_i    (core_be),
    .data_addr_i  (core_addr),
    .data_wdata_i (core_wdata),
    .data_rdata_o (core_rdata),
    .data_err_o   (core_err),

    .loc_req_o    (loc_req),
    .loc_gnt_i    (loc_gnt),
    .loc_rvalid_i (loc_rvalid),
    .loc_we_o     (loc_we),
    .loc_be_o     (loc_be),
    .loc_addr_o   (loc_addr),
    .loc_wdata_o  (loc_wdata),
    .loc_rdata_i  (loc_rdata),
    .loc_err_i    (loc_err),

    .axi_req_o    (tl_req),
    .axi_gnt_i    (tl_gnt),
    .axi_rvalid_i (tl_rvalid),
    .axi_we_o     (tl_we),
    .axi_be_o     (tl_be),
    .axi_addr_o   (tl_addr),
    .axi_wdata_o  (tl_wdata),
    .axi_rdata_i  (tl_rdata),
    .axi_err_i    (tl_err)
  );

  // ===========================================================================
  // The AP's private bus: Ibex's bus.sv, one host, three devices
  // ===========================================================================
  logic        host_req    [1];
  logic        host_gnt    [1];
  logic [31:0] host_addr   [1];
  logic        host_we     [1];
  logic [3:0]  host_be     [1];
  logic [31:0] host_wdata  [1];
  logic        host_rvalid [1];
  logic [31:0] host_rdata  [1];
  logic        host_err    [1];

  logic        dev_req    [NrDevices];
  logic [31:0] dev_addr   [NrDevices];
  logic        dev_we     [NrDevices];
  logic [3:0]  dev_be     [NrDevices];
  logic [31:0] dev_wdata  [NrDevices];
  logic        dev_rvalid [NrDevices];
  logic [31:0] dev_rdata  [NrDevices];
  logic        dev_err    [NrDevices];

  logic [31:0] cfg_base [NrDevices];
  logic [31:0] cfg_mask [NrDevices];

  assign cfg_base[DevRam]   = RAM_BASE;
  assign cfg_mask[DevRam]   = RAM_MASK;
  assign cfg_base[DevTimer] = TIMER_BASE;
  assign cfg_mask[DevTimer] = TIMER_MASK;
  assign cfg_base[DevExt]   = EXT_BASE;
  assign cfg_mask[DevExt]   = EXT_MASK;

  assign host_req[0]   = loc_req;
  assign host_addr[0]  = loc_addr;
  assign host_we[0]    = loc_we;
  assign host_be[0]    = loc_be;
  assign host_wdata[0] = loc_wdata;
  assign loc_gnt       = host_gnt[0];
  assign loc_rvalid    = host_rvalid[0];
  assign loc_rdata     = host_rdata[0];
  assign loc_err       = host_err[0];

  bus #(
    .NrDevices   (NrDevices),
    .NrHosts     (1),
    .DataWidth   (32),
    .AddressWidth(32)
  ) u_bus (
    .clk_i               (clk_i),
    .rst_ni              (rst_ni),

    .host_req_i          (host_req),
    .host_gnt_o          (host_gnt),
    .host_addr_i         (host_addr),
    .host_we_i           (host_we),
    .host_be_i           (host_be),
    .host_wdata_i        (host_wdata),
    .host_rvalid_o       (host_rvalid),
    .host_rdata_o        (host_rdata),
    .host_err_o          (host_err),

    .device_req_o        (dev_req),
    .device_addr_o       (dev_addr),
    .device_we_o         (dev_we),
    .device_be_o         (dev_be),
    .device_wdata_o      (dev_wdata),
    .device_rvalid_i     (dev_rvalid),
    .device_rdata_i      (dev_rdata),
    .device_err_i        (dev_err),

    .cfg_device_addr_base(cfg_base),
    .cfg_device_addr_mask(cfg_mask)
  );

  // ---- RAM: port A here, port B on the fetch path; its own image ----
  scp_ram #(.IMAGE_PLUSARG("ap_firmware")) u_ram (
    .clk_i     (clk_i),
    .rst_ni    (rst_ni),

    .a_req_i   (dev_req[DevRam]),
    .a_we_i    (dev_we[DevRam]),
    .a_be_i    (dev_be[DevRam]),
    .a_addr_i  (dev_addr[DevRam]),
    .a_wdata_i (dev_wdata[DevRam]),
    .a_rvalid_o(dev_rvalid[DevRam]),
    .a_rdata_o (dev_rdata[DevRam]),

    .b_req_i   (instr_req),
    .b_gnt_o   (instr_gnt),
    .b_addr_i  (instr_addr),
    .b_rvalid_o(instr_rvalid),
    .b_rdata_o (instr_rdata),
    .b_err_o   (instr_err)
  );
  assign dev_err[DevRam] = 1'b0;

  // ---- Timer: Ibex's, unmodified; its interrupt is not used ----
  timer #(
    .DataWidth   (32),
    .AddressWidth(32)
  ) u_timer (
    .clk_i         (clk_i),
    .rst_ni        (rst_ni),
    .timer_req_i   (dev_req[DevTimer]),
    .timer_addr_i  (dev_addr[DevTimer]),
    .timer_we_i    (dev_we[DevTimer]),
    .timer_be_i    (dev_be[DevTimer]),
    .timer_wdata_i (dev_wdata[DevTimer]),
    .timer_rvalid_o(dev_rvalid[DevTimer]),
    .timer_rdata_o (dev_rdata[DevTimer]),
    .timer_err_o   (dev_err[DevTimer]),
    .timer_intr_o  ()
  );

  // ---- ext: straight out ----
  assign ext_req_o          = dev_req[DevExt];
  assign ext_we_o           = dev_we[DevExt];
  assign ext_be_o           = dev_be[DevExt];
  assign ext_addr_o         = dev_addr[DevExt];
  assign ext_wdata_o        = dev_wdata[DevExt];
  assign dev_rvalid[DevExt] = ext_rvalid_i;
  assign dev_rdata[DevExt]  = ext_rdata_i;
  assign dev_err[DevExt]    = ext_err_i;

  // ===========================================================================
  // TL-UL: OpenTitan's host adapter, then the fixed a_source
  // ===========================================================================
  tlul_pkg::tl_h2d_t tl_host;

  tlul_adapter_host #(
    .MAX_REQS              (2),
    .EnableDataIntgGen     (1),
    .EnableRspDataIntgCheck(0)
  ) u_host (
    .clk_i       (clk_i),
    .rst_ni      (rst_ni),
    .req_i       (tl_req),
    .gnt_o       (tl_gnt),
    .addr_i      (tl_addr),
    .we_i        (tl_we),
    .wdata_i     (tl_wdata),
    .wdata_intg_i('0),                          // regenerated: EnableDataIntgGen = 1
    .be_i        (tl_be),
    .instr_type_i(prim_mubi_pkg::MuBi4False),
    .user_rsvd_i ('0),
    .valid_o     (tl_rvalid),
    .rdata_o     (tl_rdata),
    .rdata_intg_o(),
    .err_o       (tl_err),
    .intg_err_o  (),
    .tl_o        (tl_host),
    .tl_i        (tl_i)
  );

  always_comb begin
    tl_o          = tl_host;
    tl_o.a_source = AP_SOURCE;
  end

endmodule
