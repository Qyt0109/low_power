`timescale 1ns/1ps
// soc4: a reduced system that checks the SCP's power-control functions. The
// SCP with four PPUs, four power domains (two Ibex CPUs, two stand-in
// accelerators), an always-on AP, and two RPMI agents over TL-UL: the AP, and
// an RPU stand-in that the testbench drives (platform plan PD6; soc4 has no
// RPU core).
//
// References: docs/SOC4_DESIGN.md Sections 2 (block diagram),
// 3 (domains), 4 (maps) and 5.1, 5.9 (this module); Proposed_PMU/
// SOC4_TASK_PROMPT.md and the decisions of 2026-10-01 it records; Arm Power
// Control System Architecture (ARM DEN 0050D) Section 7.2.3, "place all the
// PPUs with the SCP in the always-on domain".
//
//   ┌────────────────────────────────── soc4_top ──────────────────────────────────┐
//   │  u_scp (scp_top, NUM_PPU = 4)                                                │
//   │    ext 0x0002_xxxx ──► u_ext (bus.sv, 6 devices):                           │
//   │         sim_* (TB) | u_ctrl | u_mbx regs | u_mbx qmem | u_cpu0 ld | u_cpu1 ld│
//   │    m_axi[0..3] ──► u_cpu0, u_cpu1 (soc4_cpu_dom), u_acc0, u_acc1 (soc4_acc_dom)│
//   │    irq_i[15:0] ◄── 4 PPUs, doorbells, PLIC, wake, bridge faults (below)     │
//   │                                                                              │
//   │  u_ap (soc4_ap) ──tl──┐                                                      │
//   │  tl_bfm_i (TB) ───────┴─ bfm_sel_i ──► u_mbx port 0 (agent 0, the AP)        │
//   │  tl_rpu_i (TB's 2nd BFM) ────────────► u_mbx port 1 (agent 1, the RPU)       │
//   └──────────────────────────────────────────────────────────────────────────────┘
//
// DOMAINS (Section 3.1): DOMAIN_ID = PPU index n = SCP interrupt input n, PPU
// n at 0x4000_0000 + n * 0x1000.
//
//   n  instance  IP              low-power mode  RAM
//   0  u_cpu0    Ibex (scp_core) FULL_RET        4 KB tc_sram, FULRR bit 0
//   1  u_cpu1    Ibex (scp_core) OFF             4 KB tc_sram
//   2  u_acc0    ppu_device_ip   MEM_RET         8 banks, MEMRR
//   3  u_acc1    ppu_device_ip   OFF             8 banks
//
// The instance names are a contract: the power intent and the testbench use
// them. Everything outside the four domains' switched IPs is always-on (PD_TOP
// and each domain's PD_AON_n): the AP must reach the mailbox while every domain
// is off.
//
// THE SCP'S ext WINDOW (Section 4.2): bus.sv decodes (addr & mask) == base and
// lets the last match win, so the masks below do not overlap. Every device
// answers in one cycle, so the window keeps bus.sv's timing; an address no
// device matches is a decode error one cycle later.
//
//   dev  base         mask         target
//   0    0x0002_0000  0xFFFF_F000  sim_* port (testbench scp_sim_ctrl, TAG "fw")
//   1    0x0002_1000  0xFFFF_F000  u_ctrl (soc4_ctrl)
//   2    0x0002_2000  0xFFFF_F000  u_mbx SCP registers
//   3    0x0002_4000  0xFFFF_F800  u_mbx queue memory, 2 KiB: agent k's window
//                                  at + k * 0x400 (NUM_AGENTS KiB)
//   4    0x0002_8000  0xFFFF_F000  u_cpu0 RAM load port
//   5    0x0002_9000  0xFFFF_F000  u_cpu1 RAM load port
//
// CLOCKS AND RESETS (Section 2): one free-running clk_i for everything, each
// domain's switched logic on its gated dev_clk. scp_rst_ni holds the SCP
// subsystem alone in reset (its reset is rst_ni & scp_rst_ni); the mailbox and
// its firewall, soc4_ctrl, the AP and the PPUs are reset by rst_ni only.
//
// THE SCP WATCHDOG (platform plan H18; scp_wdog.sv) resets the SCP subsystem
// alone: scp_top applies its request inside, and hands the result back as
// rst_sub_no, which also resets the ext window's bus.sv (u_ext), the only
// SCP-side logic out here. Everything else keeps rst_ni: the four domains with
// their PPUs and PCSMs, soc4_ctrl (the CPUs' boot address and fetch enable,
// AP_RUN), the mailbox with its queues and firewall, and the AP. rst_ni is
// also the watchdog's power-on reset (por_ni), which alone clears its CAUSE.
//
// THE AP/BFM MUX: bfm_sel_i is a static strap, set from time 0 and never
// changed after reset. 1 hands mailbox port 0 to the testbench's
// bus-functional model and keeps the AP from fetching.
//
// THE MAILBOX'S AGENTS (platform plan H11-H13, F6; soc4_mbx.sv). Agent k =
// RPMI transport k = queue window k = doorbell RING[k], each on its own port:
//
//   k  agent  port  host                     a_user   window, doorbell (TL-UL)
//   0  AP     0     u_ap, or the BFM         driven   0x2000_0000, 0x2000_1000
//   1  RPU    1     tl_rpu_i: the testbench's  default  0x2000_2000, 0x2000_3000
//                   second BFM, a stand-in
//
// Port 1 is set to a host without OpenTitan's a_user, as a Chipyard TileLink
// master is, so its boundary adapter supplies TL_A_USER_DEFAULT (H13). Adding
// or removing an agent: MBX_AGENTS, MBX_PORTS, MBX_AGENT_PORT and
// MBX_HAS_A_USER below, the port's wiring into u_mbx's tl_mbx_h/tl_mbx_d, the
// doorbell's wire in irq_in, and the ext window's queue-memory mask; then the
// agent's entry in soc4_plat.h (SOVRA_PCSA_ARCHITECTURE.md Section 15.3).
//
// THE SCP'S INTERRUPT INPUTS (platform plan H7-H9, F10; scp_irq.sv). One
// generic bank; what each input means is the firmware's input table
// (src/soc4/fw/soc4_plat.h, SCP_PLAT_INPUTS), which lists the same inputs in
// the same order. Adding one is a wire in irq_in below, its IRQ_ASYNC bit, and
// a table entry.
//
//   i   source              clock   table: mode, action
//   0-3 ppu_irq[n]          clk_i   level, PPU n's interrupt (pd_poll)
//   4   u_mbx.db_irq_o[0]   clk_i   level, the AP's RPMI doorbell (RING[0])
//   5   plic_irq_i          async   level, notify the policy
//   6-7 plic_pend_i[n]      async   level, power up CPUn (DOMAIN_ID n)
//   8   rtc_wake_i          async   edge,  record wake reason 1
//   9   gpio_wake_i         async   edge,  power up ACC0
//   10  bbrx_det_i          async   edge,  record wake reason 2
//   11  dbg_pwrreq_i        async   level, ignore (soc4 has no debug domain)
//   12  acg_wake_i[0]       async   edge,  power up ACC1
//   13  acg_wake_i[1]       async   edge,  masked (no second gate in soc4)
//   14  u_mbx.db_irq_o[1]   clk_i   level, the RPU's RPMI doorbell (RING[1])
//   15  ckrst_irq           clk_i   level, a clock/reset bridge fault (H16, F11):
//                                   the OR of the four bridges' fault_o
//
// RING[1] is appended rather than placed beside RING[0], so the inputs of
// phase 2 keep their numbers; the bridge input likewise (phase 5).
//
// THE CLOCK/RESET REQUEST BRIDGES (platform plan PD8, H16, F11;
// rtl/ckrst/ckrst_bridge.sv). Each domain's u_ckrst forwards its PPU's
// DEVCLKEN and two device resets to the SoC's clkgate / tilereset -- here the
// testbench's model, on the tile_* ports, domain n at index n -- and checks
// the acknowledgements. Its status byte is soc4_ctrl's CKRST_STAT[8n+7:8n];
// a fault raises input 15. The domain's clock and resets still come from its
// PPU wrapper in soc4 (the bridges observe; see soc4_cpu_dom).
//
// The PPUs and the mailbox are always-on with the SCP on clk_i (PCSA 7.2.3),
// so they skip the synchroniser; every other input is a raw line from
// elsewhere in the SoC and gets two flops.
//
// hold_busy_i IS TEST-ONLY. One bit per domain, ORed into that domain's
// dev_quiescent_busy: a device that is busy and never answers a quiescence
// request, which is how a test makes a power-off step miss its deadline
// (Section 10.5). A PRODUCTION INTEGRATION TIES IT TO 0.

module soc4_top #(
  parameter logic [7:0]  AP_SOURCE         = 8'h10,  // the AP's TL-UL a_source (= SOC4_AP_SOURCE in soc4_regs.h)
  parameter int unsigned PCSM_RET_SETTLE   = 0,      // all four domains
  parameter int unsigned PCSM_LOGIC_SETTLE = 0,
  parameter int unsigned DEV_CNT_W         = 12      // ppu_device_ip CNT_W (sim.h SIM_WORK_LEN width)
) (
  input  logic                 clk_i,           // the only clock
  input  logic                 rst_ni,          // system reset
  input  logic                 scp_rst_ni,      // SCP subsystem held in reset while LOW
  input  logic                 scp_fetch_en_i,  // scp_top.fetch_enable_i
  input  logic                 bfm_sel_i,       // static: 1 = the testbench's BFM drives the TL-UL socket

  // ---- SCP sim-control page 0x0002_0000-0x0002_0FFF, bus.sv protocol ----
  output logic                 sim_req_o,
  output logic                 sim_we_o,
  output logic [3:0]           sim_be_o,
  output logic [31:0]          sim_addr_o,
  output logic [31:0]          sim_wdata_o,
  input  logic                 sim_rvalid_i,
  input  logic [31:0]          sim_rdata_i,
  input  logic                 sim_err_i,

  // ---- AP sim-control page (AP 0x0002_0000-0x0002_0FFF), bus.sv protocol ----
  output logic                 ap_ext_req_o,
  output logic                 ap_ext_we_o,
  output logic [3:0]           ap_ext_be_o,
  output logic [31:0]          ap_ext_addr_o,
  output logic [31:0]          ap_ext_wdata_o,
  input  logic                 ap_ext_rvalid_i,
  input  logic [31:0]          ap_ext_rdata_i,
  input  logic                 ap_ext_err_i,

  // ---- TL-UL bus-functional model port (used only when bfm_sel_i = 1) ----
  input  tlul_pkg::tl_h2d_t    tl_bfm_i,
  output tlul_pkg::tl_d2h_t    tl_bfm_o,

  // ---- The RPU's mailbox port (agent 1): a TL-UL host without a_user ----
  input  tlul_pkg::tl_h2d_t    tl_rpu_i,
  output tlul_pkg::tl_d2h_t    tl_rpu_o,

  // ---- Accelerator stimulus, bit k = ACCk (domain 2 + k) ----
  input  logic [1:0]           acc_start_i,
  input  logic [DEV_CNT_W-1:0] acc_work_len_i,
  input  logic [1:0]           acc_light_i,
  input  logic [1:0]           acc_wake_i,
  input  logic [1:0]           acc_deny_i,
  input  logic [1:0][1:0]      acc_ip_cmd_i,
  input  logic [7:0]           acc_ip_seed_i,

  // ---- TEST-ONLY, always-on: bit n ORed into domain n's dev_quiescent_busy ----
  input  logic [3:0]           hold_busy_i,

  // ---- Interrupt and wake inputs to the SCP (H8, H9): raw, asynchronous ----
  input  logic                 plic_irq_i,      // the SoC PLIC's output to the SCP
  input  logic [1:0]           plic_pend_i,     // the PLIC's per-hart pending, hart n = CPUn
  input  logic                 rtc_wake_i,
  input  logic                 gpio_wake_i,
  input  logic                 bbrx_det_i,      // baseband receive detect
  input  logic                 dbg_pwrreq_i,    // debug power-up request
  input  logic [1:0]           acg_wake_i,      // access gates' stall-and-wake requests

  // ---- The SoC's clkgate / tilereset, domain n at index n (H16; the TB's model) ----
  output logic [3:0]           tile_clk_req_o,
  input  logic [3:0]           tile_clk_ack_i,
  output logic [3:0][1:0]      tile_rst_req_no, // [n][0] dev_nret_rst_n, [n][1] dev_ret_rst_n
  input  logic [3:0][1:0]      tile_rst_ack_ni,

  output logic                 scp_sleep_o,     // scp_top.core_sleep_o
  output logic                 ap_sleep_o       // the AP's core_sleep_o
);

  localparam int unsigned NUM_PD  = 4;
  localparam int unsigned NUM_IRQ = 16;
  localparam logic [31:0] IRQ_ASYNC = 32'h0000_3FE0;   // inputs 5-13

  // The mailbox's agents and ports (the table above)
  localparam int unsigned               MBX_AGENTS     = 2;
  localparam int unsigned               MBX_PORTS      = 2;
  localparam logic [MBX_AGENTS-1:0][3:0] MBX_AGENT_PORT = {4'd1, 4'd0};   // RPU on 1, AP on 0
  localparam logic [MBX_PORTS-1:0]      MBX_HAS_A_USER = 2'b01;          // port 1: no a_user

  logic scp_rst_n, scp_sub_rst_n, wdog_rst;
  assign scp_rst_n = rst_ni & scp_rst_ni;

  // The domains' reset: rst_ni. NEGATIVE CONTROL (soc4neg M7): the watchdog's
  // reset also reaches the four domains, PPUs included, so a watchdog reset
  // takes every domain down. soc4bfm's W1 must fail.
  logic dom_rst_n;
`ifdef SOC4_MUT_WDOG_PPU
  assign dom_rst_n = rst_ni & ~wdog_rst;
`else
  assign dom_rst_n = rst_ni;
`endif

  // ===========================================================================
  // The SCP
  // ===========================================================================
  logic        ext_req, ext_we, ext_rvalid, ext_err;
  logic [3:0]  ext_be;
  logic [31:0] ext_addr, ext_wdata, ext_rdata;

  logic [NUM_PD-1:0][31:0] awaddr, wdata, araddr, rdata;
  logic [NUM_PD-1:0][2:0]  awprot, arprot;
  logic [NUM_PD-1:0][3:0]  wstrb;
  logic [NUM_PD-1:0][1:0]  bresp, rresp;
  logic [NUM_PD-1:0]       awvalid, awready, wvalid, wready, bvalid, bready;
  logic [NUM_PD-1:0]       arvalid, arready, rvalid, rready;
  logic [NUM_PD-1:0]       ppu_irq;
  logic [NUM_PD-1:0][15:0] hwstat;
  logic [MBX_AGENTS-1:0]   db_irq;
  logic [NUM_IRQ-1:0]      irq_in;
  logic [NUM_PD-1:0][7:0]  ckrst_stat, ckrst_clr;
  logic [NUM_PD-1:0]       ckrst_fault;
  logic                    ckrst_irq;

  // A bridge fault, any domain: the soc4_ctrl CKRST_STAT bytes say which.
  // NEGATIVE CONTROL (soc4neg M9): the bridges' faults never reach the SCP;
  // soc4ckrst's K1 must fail.
`ifdef SOC4_MUT_CKRST_IRQ
  assign ckrst_irq = 1'b0;
`else
  assign ckrst_irq = |ckrst_fault;
`endif

  // The input list (the table above; soc4_plat.h SCP_PLAT_INPUTS)
  assign irq_in = {ckrst_irq, db_irq[1], acg_wake_i, dbg_pwrreq_i, bbrx_det_i, gpio_wake_i,
                   rtc_wake_i, plic_pend_i, plic_irq_i, db_irq[0], ppu_irq};

  scp_top #(
    .NUM_PPU  (NUM_PD),
    .NUM_IRQ  (NUM_IRQ),
    .IRQ_ASYNC(IRQ_ASYNC),
    .BOOT_ADDR(32'h0000_0000)
  ) u_scp (
    .clk_i         (clk_i),
    .por_ni        (rst_ni),
    .rst_ni        (scp_rst_n),
    .fetch_enable_i(scp_fetch_en_i),
    .rst_sub_no    (scp_sub_rst_n),
    .wdog_rst_o    (wdog_rst),

    .ext_req_o     (ext_req),
    .ext_we_o      (ext_we),
    .ext_be_o      (ext_be),
    .ext_addr_o    (ext_addr),
    .ext_wdata_o   (ext_wdata),
    .ext_rvalid_i  (ext_rvalid),
    .ext_rdata_i   (ext_rdata),
    .ext_err_i     (ext_err),

    .m_axi_awaddr  (awaddr),
    .m_axi_awprot  (awprot),
    .m_axi_awvalid (awvalid),
    .m_axi_awready (awready),
    .m_axi_wdata   (wdata),
    .m_axi_wstrb   (wstrb),
    .m_axi_wvalid  (wvalid),
    .m_axi_wready  (wready),
    .m_axi_bresp   (bresp),
    .m_axi_bvalid  (bvalid),
    .m_axi_bready  (bready),
    .m_axi_araddr  (araddr),
    .m_axi_arprot  (arprot),
    .m_axi_arvalid (arvalid),
    .m_axi_arready (arready),
    .m_axi_rdata   (rdata),
    .m_axi_rresp   (rresp),
    .m_axi_rvalid  (rvalid),
    .m_axi_rready  (rready),

    .irq_i         (irq_in),
    .core_sleep_o  (scp_sleep_o)
  );

  // ===========================================================================
  // The ext window: a second bus.sv, one host (the SCP), six devices (5.9)
  // ===========================================================================
  localparam int unsigned NrExt    = 6;
  localparam int unsigned ExtSim   = 0;
  localparam int unsigned ExtCtrl  = 1;
  localparam int unsigned ExtMbx   = 2;
  localparam int unsigned ExtQmem  = 3;
  localparam int unsigned ExtLd0   = 4;
  localparam int unsigned ExtLd1   = 5;

  logic        host_req    [1];
  logic        host_gnt    [1];
  logic [31:0] host_addr   [1];
  logic        host_we     [1];
  logic [3:0]  host_be     [1];
  logic [31:0] host_wdata  [1];
  logic        host_rvalid [1];
  logic [31:0] host_rdata  [1];
  logic        host_err    [1];

  logic        dev_req    [NrExt];
  logic [31:0] dev_addr   [NrExt];
  logic        dev_we     [NrExt];
  logic [3:0]  dev_be     [NrExt];
  logic [31:0] dev_wdata  [NrExt];
  logic        dev_rvalid [NrExt];
  logic [31:0] dev_rdata  [NrExt];
  logic        dev_err    [NrExt];

  logic [31:0] cfg_base [NrExt];
  logic [31:0] cfg_mask [NrExt];

  assign cfg_base[ExtSim]  = 32'h0002_0000;  assign cfg_mask[ExtSim]  = 32'hFFFF_F000;
  assign cfg_base[ExtCtrl] = 32'h0002_1000;  assign cfg_mask[ExtCtrl] = 32'hFFFF_F000;
  assign cfg_base[ExtMbx]  = 32'h0002_2000;  assign cfg_mask[ExtMbx]  = 32'hFFFF_F000;
  assign cfg_base[ExtQmem] = 32'h0002_4000;  assign cfg_mask[ExtQmem] = 32'hFFFF_F800;  // MBX_AGENTS KiB
  assign cfg_base[ExtLd0]  = 32'h0002_8000;  assign cfg_mask[ExtLd0]  = 32'hFFFF_F000;
  assign cfg_base[ExtLd1]  = 32'h0002_9000;  assign cfg_mask[ExtLd1]  = 32'hFFFF_F000;

  // bus.sv grants in the cycle of the request (bus.sv:134); scp_top's own
  // bus.sv has already granted, so host_gnt is not used.
  assign host_req[0]   = ext_req;
  assign host_addr[0]  = ext_addr;
  assign host_we[0]    = ext_we;
  assign host_be[0]    = ext_be;
  assign host_wdata[0] = ext_wdata;
  assign ext_rvalid    = host_rvalid[0];
  assign ext_rdata     = host_rdata[0];
  assign ext_err       = host_err[0];

  bus #(
    .NrDevices   (NrExt),
    .NrHosts     (1),
    .DataWidth   (32),
    .AddressWidth(32)
  ) u_ext (
    .clk_i               (clk_i),
    .rst_ni              (scp_sub_rst_n),

    .host_req_i          (host_req),
    .host_gnt_o          (host_gnt),
    .host_addr_i         (host_addr),
    .host_we_i           (host_we),
    .host_be_i           (host_be),
    .host_wdata_i        (host_wdata),
    .host_rvalid_o       (host_rvalid),
    .host_rdata_o        (host_rdata),
    .host_err_o          (host_err),

    .device_req_o        (dev_req),
    .device_addr_o       (dev_addr),
    .device_we_o         (dev_we),
    .device_be_o         (dev_be),
    .device_wdata_o      (dev_wdata),
    .device_rvalid_i     (dev_rvalid),
    .device_rdata_i      (dev_rdata),
    .device_err_i        (dev_err),

    .cfg_device_addr_base(cfg_base),
    .cfg_device_addr_mask(cfg_mask)
  );

  // ---- Device 0: the testbench's simulation control ----
  assign sim_req_o          = dev_req[ExtSim];
  assign sim_we_o           = dev_we[ExtSim];
  assign sim_be_o           = dev_be[ExtSim];
  assign sim_addr_o         = dev_addr[ExtSim];
  assign sim_wdata_o        = dev_wdata[ExtSim];
  assign dev_rvalid[ExtSim] = sim_rvalid_i;
  assign dev_rdata[ExtSim]  = sim_rdata_i;
  assign dev_err[ExtSim]    = sim_err_i;

  // ===========================================================================
  // Control registers
  // ===========================================================================
  logic [1:0][31:0] cpu_boot;
  logic [1:0]       cpu_fetch_en, cpu_sleep, cpu_ld_open, cpu_wake;
  logic             ap_run;

  soc4_ctrl u_ctrl (
    .clk_i         (clk_i),
    .rst_ni        (rst_ni),
    .req_i         (dev_req[ExtCtrl]),
    .we_i          (dev_we[ExtCtrl]),
    .be_i          (dev_be[ExtCtrl]),
    .addr_i        (dev_addr[ExtCtrl]),
    .wdata_i       (dev_wdata[ExtCtrl]),
    .rvalid_o      (dev_rvalid[ExtCtrl]),
    .rdata_o       (dev_rdata[ExtCtrl]),
    .err_o         (dev_err[ExtCtrl]),
    .cpu_boot_o    (cpu_boot),
    .cpu_fetch_en_o(cpu_fetch_en),
    .ap_run_o      (ap_run),
    .bfm_sel_i     (bfm_sel_i),
    .cpu_sleep_i   (cpu_sleep),
    .cpu_ld_open_i (cpu_ld_open),
    .cpu_wake_i    (cpu_wake),
    .hwstat_i      (hwstat),
    .ckrst_stat_i  (ckrst_stat),
    .ckrst_clr_o   (ckrst_clr)
  );

  // ===========================================================================
  // The mailbox, and the AP/BFM mux in front of its port 0
  // ===========================================================================
  tlul_pkg::tl_h2d_t tl_ap_h, tl_sock_h;
  tlul_pkg::tl_d2h_t tl_ap_d, tl_sock_d;
  tlul_pkg::tl_h2d_t tl_mbx_h [MBX_PORTS];
  tlul_pkg::tl_d2h_t tl_mbx_d [MBX_PORTS];

  // Static select. The payload goes to both; the side not selected never sees
  // a_ready or d_valid.
  assign tl_sock_h = bfm_sel_i ? tl_bfm_i : tl_ap_h;
  always_comb begin
    tl_bfm_o = tl_sock_d;
    tl_ap_d  = tl_sock_d;
    if (bfm_sel_i) begin
      tl_ap_d.a_ready  = 1'b0;
      tl_ap_d.d_valid  = 1'b0;
    end else begin
      tl_bfm_o.a_ready = 1'b0;
      tl_bfm_o.d_valid = 1'b0;
    end
  end

  // The port wiring: port 0 the AP (or the BFM), port 1 the RPU
  assign tl_mbx_h[0] = tl_sock_h;
  assign tl_sock_d   = tl_mbx_d[0];
  assign tl_mbx_h[1] = tl_rpu_i;
  assign tl_rpu_o    = tl_mbx_d[1];

  soc4_mbx #(
    .NUM_AGENTS     (MBX_AGENTS),
    .NUM_PORTS      (MBX_PORTS),
    .AGENT_PORT     (MBX_AGENT_PORT),
    .PORT_HAS_A_USER(MBX_HAS_A_USER)
  ) u_mbx (
    .clk_i       (clk_i),
    .rst_ni      (rst_ni),
    .tl_h_i      (tl_mbx_h),
    .tl_h_o      (tl_mbx_d),

    .reg_req_i   (dev_req[ExtMbx]),
    .reg_we_i    (dev_we[ExtMbx]),
    .reg_be_i    (dev_be[ExtMbx]),
    .reg_addr_i  (dev_addr[ExtMbx]),
    .reg_wdata_i (dev_wdata[ExtMbx]),
    .reg_rvalid_o(dev_rvalid[ExtMbx]),
    .reg_rdata_o (dev_rdata[ExtMbx]),
    .reg_err_o   (dev_err[ExtMbx]),

    .mem_req_i   (dev_req[ExtQmem]),
    .mem_we_i    (dev_we[ExtQmem]),
    .mem_be_i    (dev_be[ExtQmem]),
    .mem_addr_i  (dev_addr[ExtQmem]),
    .mem_wdata_i (dev_wdata[ExtQmem]),
    .mem_rvalid_o(dev_rvalid[ExtQmem]),
    .mem_rdata_o (dev_rdata[ExtQmem]),
    .mem_err_o   (dev_err[ExtQmem]),

    .db_irq_o    (db_irq)
  );

  // ===========================================================================
  // The AP
  // ===========================================================================
  soc4_ap #(.AP_SOURCE(AP_SOURCE)) u_ap (
    .clk_i       (clk_i),
    .rst_ni      (rst_ni),
    .fetch_en_i  (ap_run & ~bfm_sel_i),

    .ext_req_o   (ap_ext_req_o),
    .ext_we_o    (ap_ext_we_o),
    .ext_be_o    (ap_ext_be_o),
    .ext_addr_o  (ap_ext_addr_o),
    .ext_wdata_o (ap_ext_wdata_o),
    .ext_rvalid_i(ap_ext_rvalid_i),
    .ext_rdata_i (ap_ext_rdata_i),
    .ext_err_i   (ap_ext_err_i),

    .tl_o        (tl_ap_h),
    .tl_i        (tl_ap_d),

    .core_sleep_o(ap_sleep_o)
  );

  // ===========================================================================
  // The four domains
  // ===========================================================================
  // CPU0 (domain 0) has FULL_RET and PPU_FULRR; CPU1 (domain 1) OFF only.
  soc4_cpu_dom #(
    .HART_ID          (32'd0),
    .FULL_RET         (1'b1),
    .PCSM_RET_SETTLE  (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE(PCSM_LOGIC_SETTLE)
  ) u_cpu0 (
    .clk_i        (clk_i),
    .rst_ni       (dom_rst_n),
    .s_axi_awaddr (awaddr[0]),
    .s_axi_awprot (awprot[0]),
    .s_axi_awvalid(awvalid[0]),
    .s_axi_awready(awready[0]),
    .s_axi_wdata  (wdata[0]),
    .s_axi_wstrb  (wstrb[0]),
    .s_axi_wvalid (wvalid[0]),
    .s_axi_wready (wready[0]),
    .s_axi_bresp  (bresp[0]),
    .s_axi_bvalid (bvalid[0]),
    .s_axi_bready (bready[0]),
    .s_axi_araddr (araddr[0]),
    .s_axi_arprot (arprot[0]),
    .s_axi_arvalid(arvalid[0]),
    .s_axi_arready(arready[0]),
    .s_axi_rdata  (rdata[0]),
    .s_axi_rresp  (rresp[0]),
    .s_axi_rvalid (rvalid[0]),
    .s_axi_rready (rready[0]),
    .irq_o        (ppu_irq[0]),
    .boot_addr_i  (cpu_boot[0]),
    .fetch_en_i   (cpu_fetch_en[0]),
    .ld_req_i     (dev_req[ExtLd0]),
    .ld_we_i      (dev_we[ExtLd0]),
    .ld_be_i      (dev_be[ExtLd0]),
    .ld_addr_i    (dev_addr[ExtLd0]),
    .ld_wdata_i   (dev_wdata[ExtLd0]),
    .ld_rvalid_o  (dev_rvalid[ExtLd0]),
    .ld_rdata_o   (dev_rdata[ExtLd0]),
    .ld_err_o     (dev_err[ExtLd0]),
    .hwstat_o     (hwstat[0]),
    .core_sleep_o (cpu_sleep[0]),
    .ld_open_o    (cpu_ld_open[0]),
    .wake_o       (cpu_wake[0]),
    .tile_clk_req_o (tile_clk_req_o[0]),
    .tile_clk_ack_i (tile_clk_ack_i[0]),
    .tile_rst_req_no(tile_rst_req_no[0]),
    .tile_rst_ack_ni(tile_rst_ack_ni[0]),
    .ckrst_stat_o   (ckrst_stat[0]),
    .ckrst_clr_i    (ckrst_clr[0]),
    .ckrst_fault_o  (ckrst_fault[0]),
    .hold_busy_i  (hold_busy_i[0])
  );

  soc4_cpu_dom #(
    .HART_ID          (32'd1),
    .FULL_RET         (1'b0),
    .PCSM_RET_SETTLE  (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE(PCSM_LOGIC_SETTLE)
  ) u_cpu1 (
    .clk_i        (clk_i),
    .rst_ni       (dom_rst_n),
    .s_axi_awaddr (awaddr[1]),
    .s_axi_awprot (awprot[1]),
    .s_axi_awvalid(awvalid[1]),
    .s_axi_awready(awready[1]),
    .s_axi_wdata  (wdata[1]),
    .s_axi_wstrb  (wstrb[1]),
    .s_axi_wvalid (wvalid[1]),
    .s_axi_wready (wready[1]),
    .s_axi_bresp  (bresp[1]),
    .s_axi_bvalid (bvalid[1]),
    .s_axi_bready (bready[1]),
    .s_axi_araddr (araddr[1]),
    .s_axi_arprot (arprot[1]),
    .s_axi_arvalid(arvalid[1]),
    .s_axi_arready(arready[1]),
    .s_axi_rdata  (rdata[1]),
    .s_axi_rresp  (rresp[1]),
    .s_axi_rvalid (rvalid[1]),
    .s_axi_rready (rready[1]),
    .irq_o        (ppu_irq[1]),
    .boot_addr_i  (cpu_boot[1]),
    .fetch_en_i   (cpu_fetch_en[1]),
    .ld_req_i     (dev_req[ExtLd1]),
    .ld_we_i      (dev_we[ExtLd1]),
    .ld_be_i      (dev_be[ExtLd1]),
    .ld_addr_i    (dev_addr[ExtLd1]),
    .ld_wdata_i   (dev_wdata[ExtLd1]),
    .ld_rvalid_o  (dev_rvalid[ExtLd1]),
    .ld_rdata_o   (dev_rdata[ExtLd1]),
    .ld_err_o     (dev_err[ExtLd1]),
    .hwstat_o     (hwstat[1]),
    .core_sleep_o (cpu_sleep[1]),
    .ld_open_o    (cpu_ld_open[1]),
    .wake_o       (cpu_wake[1]),
    .tile_clk_req_o (tile_clk_req_o[1]),
    .tile_clk_ack_i (tile_clk_ack_i[1]),
    .tile_rst_req_no(tile_rst_req_no[1]),
    .tile_rst_ack_ni(tile_rst_ack_ni[1]),
    .ckrst_stat_o   (ckrst_stat[1]),
    .ckrst_clr_i    (ckrst_clr[1]),
    .ckrst_fault_o  (ckrst_fault[1]),
    .hold_busy_i  (hold_busy_i[1])
  );

  // ACC0 (domain 2) has MEM_RET and PPU_MEMRR; ACC1 (domain 3) OFF only.
  soc4_acc_dom #(
    .MEM_RET          (1'b1),
    .DEV_CNT_W        (DEV_CNT_W),
    .PCSM_RET_SETTLE  (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE(PCSM_LOGIC_SETTLE)
  ) u_acc0 (
    .clk_i        (clk_i),
    .rst_ni       (dom_rst_n),
    .s_axi_awaddr (awaddr[2]),
    .s_axi_awprot (awprot[2]),
    .s_axi_awvalid(awvalid[2]),
    .s_axi_awready(awready[2]),
    .s_axi_wdata  (wdata[2]),
    .s_axi_wstrb  (wstrb[2]),
    .s_axi_wvalid (wvalid[2]),
    .s_axi_wready (wready[2]),
    .s_axi_bresp  (bresp[2]),
    .s_axi_bvalid (bvalid[2]),
    .s_axi_bready (bready[2]),
    .s_axi_araddr (araddr[2]),
    .s_axi_arprot (arprot[2]),
    .s_axi_arvalid(arvalid[2]),
    .s_axi_arready(arready[2]),
    .s_axi_rdata  (rdata[2]),
    .s_axi_rresp  (rresp[2]),
    .s_axi_rvalid (rvalid[2]),
    .s_axi_rready (rready[2]),
    .irq_o        (ppu_irq[2]),
    .hwstat_o     (hwstat[2]),
    .start_i      (acc_start_i[0]),
    .work_len_i   (acc_work_len_i),
    .light_i      (acc_light_i[0]),
    .wake_i       (acc_wake_i[0]),
    .deny_i       (acc_deny_i[0]),
    .ip_cmd_i     (acc_ip_cmd_i[0]),
    .ip_seed_i    (acc_ip_seed_i),
    .tile_clk_req_o (tile_clk_req_o[2]),
    .tile_clk_ack_i (tile_clk_ack_i[2]),
    .tile_rst_req_no(tile_rst_req_no[2]),
    .tile_rst_ack_ni(tile_rst_ack_ni[2]),
    .ckrst_stat_o   (ckrst_stat[2]),
    .ckrst_clr_i    (ckrst_clr[2]),
    .ckrst_fault_o  (ckrst_fault[2]),
    .hold_busy_i  (hold_busy_i[2])
  );

  soc4_acc_dom #(
    .MEM_RET          (1'b0),
    .DEV_CNT_W        (DEV_CNT_W),
    .PCSM_RET_SETTLE  (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE(PCSM_LOGIC_SETTLE)
  ) u_acc1 (
    .clk_i        (clk_i),
    .rst_ni       (dom_rst_n),
    .s_axi_awaddr (awaddr[3]),
    .s_axi_awprot (awprot[3]),
    .s_axi_awvalid(awvalid[3]),
    .s_axi_awready(awready[3]),
    .s_axi_wdata  (wdata[3]),
    .s_axi_wstrb  (wstrb[3]),
    .s_axi_wvalid (wvalid[3]),
    .s_axi_wready (wready[3]),
    .s_axi_bresp  (bresp[3]),
    .s_axi_bvalid (bvalid[3]),
    .s_axi_bready (bready[3]),
    .s_axi_araddr (araddr[3]),
    .s_axi_arprot (arprot[3]),
    .s_axi_arvalid(arvalid[3]),
    .s_axi_arready(arready[3]),
    .s_axi_rdata  (rdata[3]),
    .s_axi_rresp  (rresp[3]),
    .s_axi_rvalid (rvalid[3]),
    .s_axi_rready (rready[3]),
    .irq_o        (ppu_irq[3]),
    .hwstat_o     (hwstat[3]),
    .start_i      (acc_start_i[1]),
    .work_len_i   (acc_work_len_i),
    .light_i      (acc_light_i[1]),
    .wake_i       (acc_wake_i[1]),
    .deny_i       (acc_deny_i[1]),
    .ip_cmd_i     (acc_ip_cmd_i[1]),
    .ip_seed_i    (acc_ip_seed_i),
    .tile_clk_req_o (tile_clk_req_o[3]),
    .tile_clk_ack_i (tile_clk_ack_i[3]),
    .tile_rst_req_no(tile_rst_req_no[3]),
    .tile_rst_ack_ni(tile_rst_ack_ni[3]),
    .ckrst_stat_o   (ckrst_stat[3]),
    .ckrst_clr_i    (ckrst_clr[3]),
    .ckrst_fault_o  (ckrst_fault[3]),
    .hold_busy_i  (hold_busy_i[3])
  );

endmodule
