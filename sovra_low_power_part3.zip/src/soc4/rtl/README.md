# soc4 RTL

The SystemVerilog of the soc4 platform: `soc4_top` and the glue it is built
from. The heavy blocks are reused, not written here: the SCP (`scp_top`,
`src/pmu/rtl`), the PPU domain wrapper (`ppu_axi_dom_top`, `src/rtl/ppu`),
the clock/reset request bridge (`ckrst_bridge`, `src/rtl/ckrst`), Ibex
(`scp_core`, `bus.sv`, `timer.sv`), OpenTitan's TL-UL socket and adapters
(`src/vendor/opentitan`), PULP's `tc_sram` (`src/vendor/pulp`) and the
stand-in accelerator `ppu_device_ip`. What is in this folder is the wiring,
the address decode, and the small amount of policy that is specific to soc4.

The platform as a whole (domains, maps, make targets) is described in
[../README.md](../README.md).

## Files

| File | Module | One line |
|---|---|---|
| `soc4_top.sv` | `soc4_top` | The platform top: SCP, ext window, `soc4_ctrl`, mailbox, AP/BFM mux, AP, four domains |
| `soc4_mbx.sv` | `soc4_mbx` | RPMI mailbox: N agents over M TL-UL ports, queue windows, doorbells, source-ID firewall |
| `soc4_tl_bound.sv` | `soc4_tl_bound` | Per-port TL-UL boundary adapter: default `a_user`, source-ID width (no state) |
| `soc4_cpu_dom.sv` | `soc4_cpu_dom` | One CPU power domain: PPU wrapper, Ibex core, RAM, Q-Channel adapter, clock/reset bridge |
| `soc4_cpu_ram.sv` | `soc4_cpu_ram` | A CPU's 4 KB RAM on the always-on rail, PCSM macro pins, core ports and the SCP load port |
| `soc4_cpu_adp.sv` | `soc4_cpu_adp` | A CPU's Q-Channel device policy: accept only in WFI with nothing outstanding; wake pulse |
| `soc4_acc_dom.sv` | `soc4_acc_dom` | One accelerator power domain: PPU wrapper around `ppu_device_ip`, clock/reset bridge |
| `soc4_ctrl.sv` | `soc4_ctrl` | Control/status registers at SCP `0x0002_1000`: CPU boot and fetch, AP run, status |
| `soc4_ap.sv` | `soc4_ap` | The always-on AP: an Ibex with its own RAM, timer and bus, TL-UL host to the mailbox |

Compile order and file lists are `SOC4_RTL`, `SOC4_DUT_SRCS` and `SOC4_SRCS`
in `src/Makefile`.

## Hierarchy

```
soc4_top
├── u_scp    scp_top (NUM_PPU 4, NUM_IRQ 16, IRQ_ASYNC 0x3FE0)
├── u_ext    bus.sv: the SCP's ext window, 1 host, 6 devices
├── u_ctrl   soc4_ctrl
├── u_mbx    soc4_mbx (NUM_AGENTS 2, NUM_PORTS 2)
│   ├── g_port[p].u_bound  soc4_tl_bound
│   ├── g_port[p].u_sock   tlul_socket_1n
│   ├── g_agent[k].u_sram_ad, u_db_ad   tlul_adapter_sram, tlul_adapter_reg
│   └── u_qmem   tc_sram, 1 + NUM_AGENTS ports
├── u_ap     soc4_ap: u_core, u_split, u_bus, u_ram, u_timer, u_host
├── u_cpu0, u_cpu1   soc4_cpu_dom: u_dom, u_core, u_ram, u_adp, u_ckrst
└── u_acc0, u_acc1   soc4_acc_dom: u_dom, u_ip, u_ckrst
```

The instance names `u_cpu0`, `u_cpu1`, `u_acc0`, `u_acc1` (and the inner
`u_dom`, `u_core`, `u_ram`, `u_adp`, `u_ip`) are named by
`src/upf/soc4_top.upf` and by the testbench: treat them as an interface.

## Always-on and switched logic

From `src/upf/soc4_top.upf`:

| Power domain | Contents | Supply |
|---|---|---|
| `PD_TOP` | everything that is not a domain instance: `u_scp` (Ibex, RAM, timer, bus, `scp_irq`, `scp_wdog`), `u_ap`, `u_mbx`, `u_ctrl`, `u_ext`, the AP/BFM mux | always-on |
| `PD_AON_n` | the domain instance `u_cpuN` / `u_accK`: the PPU wrapper `u_dom` (PPU, PCSM, AXI adapter), the CPU RAM `u_cpuN/u_ram`, the Q-Channel adapter `u_cpuN/u_adp`, the accelerator banks `u_accK/u_ip/g_bank[*]`, the bridge `u_ckrst` | always-on |
| `PD_DEV_n` | CPU: `u_cpuN/u_core` and the PPU's `u_dom/u_pd/u_clkctrl`; ACC: `u_accK/u_ip/u_core`, `u_accK/u_ip/u_ret` and `u_dom/u_pd/u_clkctrl` | `VDD_LOGIC_n` through `SW_LOGIC_n` (controlled by the PCSM's `logic_on`) |

- Every `PD_DEV_n` output is isolated, clamp 0, on the PPU's
  `DEVISOLATEn`. For a CPU that means `instr_req`/`data_req` (no access),
  `core_sleep` (0: not asleep, so the adapter denies) and `dev_clk`; for an
  accelerator, `busy`. The inputs into `PD_DEV_n` all come from always-on
  logic and need no isolation.
- Retention: CPU0 only, and the whole core (`RET_CPU0` on `SS_RET_0`, save on
  the PCSM's `ret_n` falling, restore on rising). CPU1 and the accelerators
  have no retention rail.
- RAM contents are retained or lost by their PCSM macro pins
  (`ram_sleep`/`ram_sd`), never by UPF.
- The switches are control-only (`PGOOD_EN = 0`): settling is covered by the
  PPU's device control delays plus `PCSM_LOGIC_SETTLE` / `PCSM_RET_SETTLE`.

## soc4_top

Parameters:

| Parameter | Default | Meaning |
|---|---|---|
| `AP_SOURCE` | `8'h10` | The AP's TL-UL `a_source` (must equal `SOC4_AP_SOURCE` in `fw/hal/soc4_regs.h`) |
| `PCSM_RET_SETTLE`, `PCSM_LOGIC_SETTLE` | 0 | PCSM switch settling, all four domains (the testbench sets them from `make ... PCSM_*_SETTLE=`) |
| `DEV_CNT_W` | 12 | `ppu_device_ip` counter width (`SIM_WORK_LEN` width) |

Ports, by group:

| Group | Ports | Notes |
|---|---|---|
| Clock, reset | `clk_i`, `rst_ni`, `scp_rst_ni`, `scp_fetch_en_i` | `scp_rst_ni` LOW holds the SCP subsystem alone in reset |
| Strap | `bfm_sel_i` | Static from time 0: 1 gives mailbox port 0 to `tl_bfm_*` and stops the AP fetching |
| SCP sim page | `sim_*` | ext device 0, `bus.sv` protocol, to the testbench's `scp_sim_ctrl` (TAG `fw`) |
| AP sim page | `ap_ext_*` | the AP's `0x0002_0000` page, to the testbench (TAG `ap`) |
| Agent 0 BFM | `tl_bfm_i`, `tl_bfm_o` | used only when `bfm_sel_i = 1` |
| Agent 1 (RPU) | `tl_rpu_i`, `tl_rpu_o` | mailbox port 1, a host without OpenTitan's `a_user` |
| Accelerator stimulus | `acc_start_i`, `acc_work_len_i`, `acc_light_i`, `acc_wake_i`, `acc_deny_i`, `acc_ip_cmd_i`, `acc_ip_seed_i` | bit k = ACCk (domain 2 + k): the software that would run in the accelerator |
| Test only | `hold_busy_i[3:0]` | ORed into domain n's `dev_quiescent_busy`; makes a power-off miss its deadline. **A production integration ties it to 0** |
| SCP interrupt/wake inputs | `plic_irq_i`, `plic_pend_i[1:0]`, `rtc_wake_i`, `gpio_wake_i`, `bbrx_det_i`, `dbg_pwrreq_i`, `acg_wake_i[1:0]` | raw, asynchronous |
| SoC clock/reset | `tile_clk_req_o`, `tile_clk_ack_i`, `tile_rst_req_no`, `tile_rst_ack_ni` | domain n at index n; `[n][0]` = `dev_nret_rst_n`, `[n][1]` = `dev_ret_rst_n`; in soc4 the testbench's model answers |
| Status | `scp_sleep_o`, `ap_sleep_o` | the two always-on cores' `core_sleep_o` |

### The SCP's ext window (`u_ext`)

A second Ibex `bus.sv`, one host (the SCP), six devices. `bus.sv` decodes
`(addr & mask) == base` and the last match wins, so the masks do not overlap.
Every device answers one cycle after the request.

| Dev | Base | Mask | Target |
|---:|---|---|---|
| 0 | `0x0002_0000` | `0xFFFF_F000` | `sim_*` (testbench) |
| 1 | `0x0002_1000` | `0xFFFF_F000` | `u_ctrl` |
| 2 | `0x0002_2000` | `0xFFFF_F000` | `u_mbx` SCP registers |
| 3 | `0x0002_4000` | `0xFFFF_F800` | `u_mbx` queue memory, 2 KiB (1 KiB per agent) |
| 4 | `0x0002_8000` | `0xFFFF_F000` | `u_cpu0` RAM load port |
| 5 | `0x0002_9000` | `0xFFFF_F000` | `u_cpu1` RAM load port |

`u_ext` is reset by the SCP subsystem's reset (`scp_top.rst_sub_no`), so a
watchdog reset clears it along with the SCP.

### The SCP's interrupt inputs (`irq_in`)

One generic bank (`scp_irq`). The meaning of each input is the firmware's
input table (`fw/soc4_plat.h`, `SCP_PLAT_INPUTS`), which lists the same
inputs in the same order. `IRQ_ASYNC = 0x3FE0`: inputs 5–13 get a two-flop
synchroniser; the PPUs, doorbells and bridge fault are on `clk_i` and skip
it.

| Input | Source | Firmware's mode and action |
|---:|---|---|
| 0–3 | `ppu_irq[n]` | level; PPU n's interrupt (`pd_poll`) |
| 4 | `u_mbx.db_irq_o[0]` | level; the AP's doorbell (`RING[0]`) |
| 5 | `plic_irq_i` | level; notify the policy |
| 6–7 | `plic_pend_i[n]` | level; power up CPUn |
| 8 | `rtc_wake_i` | edge; record wake reason 1 |
| 9 | `gpio_wake_i` | edge; power up ACC0 |
| 10 | `bbrx_det_i` | edge; record wake reason 2 |
| 11 | `dbg_pwrreq_i` | level; ignored (no debug domain in soc4) |
| 12 | `acg_wake_i[0]` | edge; power up ACC1 |
| 13 | `acg_wake_i[1]` | edge; masked (no second gate in soc4) |
| 14 | `u_mbx.db_irq_o[1]` | level; the RPU's doorbell (`RING[1]`) |
| 15 | `ckrst_irq` | level; a clock/reset bridge fault: OR of the four bridges' `fault_o` |

Inputs 14 and 15 were appended (phases 3 and 5) so earlier inputs keep their
numbers.

### The AP/BFM mux

`bfm_sel_i` selects the host of mailbox port 0. The request payload goes to
both sides; the side not selected never sees `a_ready` or `d_valid`. The AP's
fetch enable is `AP_RUN & ~bfm_sel_i`.

### Reset domains

| Logic | Reset |
|---|---|
| `u_scp` | `rst_ni & scp_rst_ni`, plus its own watchdog; `por_ni = rst_ni` (only a power-on reset clears the watchdog's CAUSE) |
| `u_ext` | the SCP subsystem's reset (`rst_sub_no`) |
| the four domains (PPUs, PCSMs, bridges), `u_ctrl`, `u_mbx`, `u_ap` | `rst_ni` only |

So a watchdog reset reboots the SCP while every domain, the CPUs' boot
address and fetch enable, `AP_RUN`, the mailbox queues and firewall, and the
AP keep their state. Mutant M7 (`SOC4_MUT_WDOG_PPU`) breaks exactly this.

## soc4_mbx

`NUM_AGENTS` RPMI shared-memory transports over `NUM_PORTS` TL-UL
subordinate ports. Always-on (`PD_TOP`), reset by `rst_ni` only.

| Parameter | soc4 | Meaning |
|---|---|---|
| `NUM_AGENTS` | 2 | 1..16 |
| `NUM_PORTS` | 2 | 1..16; every port must carry at least one agent (elaboration error otherwise) |
| `AGENT_PORT` | `{4'd1, 4'd0}` | agent k's port: AP on 0, RPU on 1 |
| `PORT_HAS_A_USER` | `2'b01` (default `'1`) | bit p: port p's host drives OpenTitan's `a_user`; 0 makes `soc4_tl_bound` supply `TL_A_USER_DEFAULT` |
| `TL_BASE` | `0x2000_0000` | base of agent 0's TL-UL view |

Per port: `soc4_tl_bound`, then a firewall-and-decode block that drives
`dev_select_i` of a `tlul_socket_1n` with `2 * (agents on the port)` devices
(queue window and doorbell per agent) plus the socket's error responder.
Per agent: a `tlul_adapter_sram` onto port `1 + k` of the shared `tc_sram`,
and a `tlul_adapter_reg` for the doorbell word. The SCP uses port 0 of the
same memory. Both device adapters generate response integrity (the AP checks
it); none checks command integrity.

### An agent's view

Agent k, `W = TL_BASE + k * 0x2000`, decoded on the full `a_address`:

| Address | Behaviour |
|---|---|
| `W + 0x0000`–`0x03FF` | queue window k: Get, PutFull, PutPartial (byte enables honoured) |
| `W + 0x1000` | doorbell k: any write sets `RING[k]`; a read returns 0 |
| `W + 0x1004`–`0x1FFF` | `d_error`, no effect |
| anything else | `d_error`: another agent's window, or not a window at all |
| window or doorbell k while `!FW_EN[k]` or `(a_source & FW_MASK[k]) != FW_VAL[k]` | `d_error`, no effect; counted in `DENY_CNT[k]`, recorded in `FW_LAST` |

### SCP registers (base `0x0002_2000`)

| Offset | Name | Access | Reset | Fields |
|---|---|---|---|---|
| `0x000` | `DB_STATUS` | RO | 0 | `[N-1:0]` `RING[k]`, sticky; drives `db_irq_o[k]` as a level |
| `0x004` | `DB_CLEAR` | WO, W1C | — | bit k = 1 clears `RING[k]`; a ring in the same cycle wins; reads 0 |
| `0x008` | `INFO` | RO | — | `[7:0]` `NUM_AGENTS`, `[15:8]` `NUM_PORTS` |
| `0x00C` | `FW_LAST` | RO | 0 | last denial: `[7:0]` `a_source`, `[8]` valid, `[9]` `FW_EN[k]` was 0, `[19:16]` k |
| `0x100 + 0x20k` | `FW_EN[k]` | RW | 0 | `[0]` 0 denies every request to window k |
| `0x104 + 0x20k` | `FW_VAL[k]` | RW | `0x00` | `[7:0]` admitted when `(a_source & FW_MASK) == FW_VAL` |
| `0x108 + 0x20k` | `FW_MASK[k]` | RW | `0xFF` | `[7:0]` |
| `0x10C + 0x20k` | `DENY_CNT[k]` | RO, write clears | 0 | denials of window k, saturating |
| `0x110 + 0x20k` | `RING_CNT[k]` | RO, write clears | 0 | accepted doorbell writes, saturating |

A `bus.sv` device with registered read data. Single-bit and byte fields take
byte lane 0; `DB_CLEAR` honours every lane; writes to RO registers are
ignored; any other offset answers err. The queue memory at `0x0002_4000`
(window k at `+ k * 0x400`) honours byte enables and never errors.

The reset values (`FW_EN = 0`, `FW_VAL = 0`, `FW_MASK = 0xFF`) mean the
mailbox is deny-all from reset whatever the SCP does, and an `FW_EN` set
before the entry is programmed admits source `0x00` only. If two ports are
denied in the same cycle, `FW_LAST` records the higher port's.

## soc4_tl_bound

Glue between an agent's fabric and its mailbox port: no state, no protocol
change.

| Parameter | Default | Meaning |
|---|---|---|
| `HAS_A_USER` | 1 | 0: replace `a_user` with `tlul_pkg::TL_A_USER_DEFAULT` (a Chipyard host has none) |
| `HOST_AW`, `HOST_DW` | 32 | must equal `top_pkg::TL_AW`/`TL_DW` (elaboration error otherwise) |
| `HOST_SRCW` | 8 | the host's source-ID width, 1..`TL_AIW`; bits above it are driven 0 |

In SOVRA the SoC converts each TileLink TL-UH master to TL-UL (4-byte beats,
32 bits, shrunk source IDs, no atomics) before this adapter; the firewall
values are the converted IDs. `soc4_mbx` instantiates it with only
`HAS_A_USER` set.

## soc4_cpu_dom

One CPU domain around a real Ibex.

| Parameter | CPU0 | CPU1 | Meaning |
|---|---|---|---|
| `HART_ID` | 0 | 1 | `mhartid`; the CPU program branches on it |
| `FULL_RET` | 1 | 0 | `STA_FULL_RET_SPT_CFG` and `FULL_RET_RAM_REG_CFG` (`PPU_FULRR`) |
| `PCSM_RET_SETTLE`, `PCSM_LOGIC_SETTLE` | from the top | | |

Ports: the PPU's AXI4-Lite subordinate and `irq_o`; `boot_addr_i` and
`fetch_en_i` from `soc4_ctrl`; the SCP's load port `ld_*` (ext device 4 or
5); status `hwstat_o` (PPUHWSTAT), `core_sleep_o`, `ld_open_o`, `wake_o`; the
bridge's `tile_*`, `ckrst_stat_o`, `ckrst_clr_i`, `ckrst_fault_o`; and the
test-only `hold_busy_i`.

The PPU configuration (`ppu_axi_dom_top`): static only (every
`DYN_*_SPT_CFG` 0, `LOCK_CFG` 0, `OFF_MEM_RET_TRANS_CFG` 0),
`DEF_PWR_POLICY = PCSM_RESET_MODESTAT = OFF`, `WARM_RST_DEVREQEN_CFG = 0`
(so the SCP can hold the core in `WARM_RST` while it loads the RAM, with no
handshake). No hierarchical clock controller and no device wake.

The core's reset is `dev_ret_rst_n`: asserted in `OFF` and `WARM_RST`,
released in `ON`, and **held released in `FULL_RET`**, where the clock stops
and the core is retained, so CPU0 resumes where it stopped. The clock/reset
bridge observes `dev_clken_req`, both resets and `dev_isolaten`; in soc4 the
domain's clock and resets still come from the PPU wrapper.

## soc4_cpu_ram

4 KB (1024 words) of `tc_sram` on the always-on rail, two ports.

| Port | Path | Clock |
|---|---|---|
| 0 | the core's instruction fetch (Ibex IBX), read-only | `dev_clk` |
| 1 | the core's loads and stores, **shared with the SCP's load port, which wins** (`d_gnt_o` LOW in a load cycle) | array: `dev_clk`; load response: `clk_i` |

- Accessible only when the PCSM's bank-0 pins say so: `acc = (sleep === 0)
  && (sd === 0)`. While `sd` is 1 (or X) the array's reset is held, so the
  contents are destroyed and stay X. While `sleep` is 1, requests are masked
  and contents kept.
- An inaccessible or out-of-range (`addr[31:12] != 0`) access answers
  `err = 1` with data 0, never X (Ibex asserts its read data known).
- The load port opens only while `acc` and PPUHWSTAT is `ON` (`0x0100`) or
  `WARM_RST` (`0x0200`); otherwise it answers err next cycle and the RAM
  sees nothing. `ld_open_o` reports it (`CPU_STAT[5:4]`).
- `outstanding_o` = a request on the wires now, or a response still owed;
  the adapter uses it.
- Residual window: on the way down PPUHWSTAT reads `ON` for a few cycles
  after the clock stops, so a load there would not reach the RAM. The
  firmware loads only in static `WARM_RST` (see `fw/mod/README.md`).

## soc4_cpu_adp

The CPU's device-side Q-Channel policy, always-on.

| Signal | Rule |
|---|---|
| `deny_o` (`dev_quiescent_deny`) | `!hold_busy && !(core_sleep && !outstanding)`: accept only with the core in WFI and nothing outstanding |
| `busy_o` (`dev_quiescent_busy`) | `hold_busy`: test-only; holds the request waiting in Q_REQUEST and suppresses the deny |
| `wake_irq_o` | HIGH for `WAKE_PULSE` (default 8) cycles when the Q-Channel leaves Q_STOPPED; drives the core's `irq_external_i`, which ends WFI (`mie.MEIE` set, `mstatus.MIE` clear) |

A forced entry (`DEVREQEN = 0`) has no Q_STOPPED and so no wake pulse. The
pulse also fires on the first `ON` from `OFF`; the `WARM_RST` that the cold
sequence applies next resets the core anyway.

## soc4_acc_dom

One accelerator domain around `ppu_device_ip`.

| Parameter | ACC0 | ACC1 | Meaning |
|---|---|---|---|
| `MEM_RET` | 1 | 0 | `STA_MEM_RET_SPT_CFG` and `MEM_RET_RAM_REG_CFG` (`PPU_MEMRR`) |
| `DEV_CNT_W` | 12 | 12 | device counter width |

Same static-only PPU configuration as the CPU domain. The device's Q-Channel
policy is the one `ppu_pd_top` applies: `busy` (OR `hold_busy_i`) delays
quiescence, `deny_i && busy` refuses it, `wake_i | busy` is DEVQACTIVE. The
stimulus ports (`start_i`, `work_len_i`, `light_i`, `wake_i`, `deny_i`,
`ip_cmd_i`, `ip_seed_i`) come from the testbench. The RAM banks are driven by
the PCSM's `ram_sleep`/`ram_sd`; mutant M3 (`SOC4_MUT_ACC0_NORET`) miswires
them on ACC0 so retention acts as shutdown.

## soc4_ctrl

`bus.sv` device at SCP `0x0002_1000`, one-cycle response, cannot stall.
Reset by `rst_ni` only, so an SCP reset leaves it as it was.

| Offset | Name | Access | Reset | Fields |
|---|---|---|---|---|
| `0x000` | `CPU0_BOOT` | RW | 0 | `[31:8]` CPU0's boot address; `[7:0]` read 0, writes ignored (Ibex fetches its first instruction at `{[31:8], 8'h80}`) |
| `0x004` | `CPU1_BOOT` | RW | 0 | as `CPU0_BOOT` |
| `0x008` | `CPU_FETCH_EN` | RW | 0 | `[n]` CPUn's fetch enable |
| `0x00C` | `AP_RUN` | RW | 0 | `[0]` the AP's fetch enable (ANDed with `!BFM_SEL`) |
| `0x010` | `STRAPS` | RO | — | `[0]` `BFM_SEL` |
| `0x014` | `CPU_STAT` | RO | — | `[1:0]` `core_sleep` of CPU1..0 (post-isolation); `[5:4]` load port open; `[9:8]` bit 0 of each CPU's wake-pulse count (toggles per pulse) |
| `0x020 + 4n` | `HWSTAT_n` | RO | — | `[15:0]` PPUHWSTAT of domain n, n = 0..3 (one-hot, bit m = mode m) |
| `0x030` | `CKRST_STAT` | R/W1C | 0 | `[8n+7:8n]` domain n's bridge status: `[0]` LATE, `[1]` MISSING, `[2]` SPURIOUS, `[4]` clock, `[5]` reset 0 (`dev_nret_rst_n`), `[6]` reset 1 (`dev_ret_rst_n`); write 1 clears, byte lane n for domain n |

`CPUn_BOOT` honours byte enables; the other RW registers take byte lane 0.
Writes to RO registers are ignored; other offsets answer err. `core_sleep`
is meaningful only while the domain is `ON` or `WARM_RST`: elsewhere it
reads 1 in plain RTL (core in reset) and 0 under the power intent
(isolation clamp).

## soc4_ap

A third Ibex (`HART_ID 0x10`), always-on, booting at 0, no interrupts (it
polls).

```
u_core ──instr──────────────────────────────► u_ram port B
   └──data──► u_split ──local──► u_bus ──► u_ram port A    0x0000_0000  64 KB
                 │                     ├──► u_timer         0x0001_0000   1 KB
                 │                     └──► ext_* (TB)      0x0002_0000   4 KB
                 └──► u_host (tlul_adapter_host) ──► tl_o   0x2000_0000  16 KB
```

Anything else is a `bus.sv` decode error (an access fault). The RAM image
comes from the plusarg `+ap_firmware=<file.vmem>`. `tlul_adapter_host`
(`MAX_REQS = 2`) has a rotating `a_source`, so the module overrides
`a_source` with the `AP_SOURCE` parameter after the adapter; command
integrity does not cover `a_source`, so this is integrity-neutral.

## Extending the platform

The hardware edits for each kind of change (the firmware side is in
[../fw/README.md](../fw/README.md#how-to-add-or-remove-a-domain-an-agent-or-an-interrupt-input);
the full list is architecture document §15.3):

**A domain.** Instantiate a `soc4_cpu_dom` or `soc4_acc_dom` (or a new
wrapper around `ppu_axi_dom_top`) with its parameters and bridge; raise
`NUM_PD` (it sizes `scp_top`'s `NUM_PPU` and the AXI arrays); wire its
`ppu_irq` into `irq_in` (and adjust `NUM_IRQ` and `IRQ_ASYNC`); add it to
`src/upf/soc4_top.upf` and to the testbench. Note that `soc4_ctrl` is sized
for four domains: `HWSTAT_n` covers `0x020`–`0x02C`, `CKRST_STAT` is one
word of four bytes, and the `tile_*`/`hwstat`/`ckrst_*` vectors are `[3:0]`.
A CPU domain also needs a load-port device on `u_ext` and boot/fetch bits in
`soc4_ctrl`.

**An agent.** In `soc4_top`: `MBX_AGENTS`, `MBX_PORTS`, `MBX_AGENT_PORT`,
`MBX_HAS_A_USER`; the new port's wiring into `tl_mbx_h`/`tl_mbx_d` and a
top-level TL-UL port; its doorbell `db_irq[k]` as a new `irq_in` input; and
the queue-memory mask on ext device 3 (1 KiB per agent, so the window must
grow as a power of two).

**An interrupt input.** One wire in `irq_in` (appended, so existing numbers
do not move), its bit in `IRQ_ASYNC` if it is a raw line from elsewhere,
and `NUM_IRQ`.

## References

- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §13–15: §14.2 H7–H9 (interrupt
  inputs), H11–H13 (mailbox, firewall, boundary adapter), H16 (clock/reset
  bridge), H18 (watchdog); §15.3 (adding a domain or an agent).
- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../../docs/PMU_SOFTWARE_CONTRACT.md) §1
  (windows, doorbells, source IDs) and §2 (domains).
- [`src/upf/README.md`](../../upf/README.md) and `src/upf/soc4_top.upf`.
- [`src/rtl/ppu/README.md`](../../rtl/ppu/README.md): the PPU, its
  configuration parameters and modes.
- [`src/vendor/opentitan/README.md`](../../vendor/opentitan/README.md): the
  TL-UL integration rules.
- Background only: [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md) §2–5
  (block diagram, domains, maps, per-module notes) and §8 (power intent),
  which the module headers cite.
