`timescale 1ns/1ps
// A CPU domain's RAM: 4 KB of PULP tc_sram on the always-on rail, its macro
// pins driven by the PCSM, with the core's two ports and the SCP's load port.
//
// References: docs/SOC4_DESIGN.md Section 5.4 (this module) and
// decision 5 of 2026-10-01; rtl/ppu/ppu_ip_sram.sv:13-17, 68-105 (the pin
// behaviour reproduced here); rtl/ppu/ppu_pcsm.sv:643-660 (where sleep and
// shutdown come from); vendor/pulp/tech_cells_generic/tc_sram.sv (the array).
//
//                ┌─────────────────── soc4_cpu_ram ───────────────────┐
//   core instr ─►│ port 0 (IBX) ──────────────► tc_sram port 0        │
//   core data ──►│ port 1 (IBX) ──┐                                   │
//                │                ├─ load wins ► tc_sram port 1       │
//   SCP load ───►│ load (BUS1) ───┘   only in ON / WARM_RST           │
//   sleep, sd ──►│ acc = !sleep && !sd;  sd holds the array reset     │
//                └────────────────────────────────────────────────────┘
//
// THE MACRO PINS, WITHOUT A SECOND WRITER
//
// ppu_ip_sram models retention and shutdown by writing its array from a second
// process, which VCS refuses for an always_ff array (Error-[ICPD]). tc_sram has
// one writer, its always_ff, and an asynchronous reset that loads init_val --
// X with SimInit "none" -- into every word (tc_sram.sv:86-98, 124-129). So:
//
//   accessible   acc = (sleep === 0) && (sd === 0), as ppu_ip_sram
//   shutdown     the array's reset is held while sd is 1 (or X): the contents
//                are destroyed and stay X, and do not come back
//   sleep        requests are masked by acc, so the array keeps its values
//   inaccessible answered with err = 1 and data 0, never X: Ibex checks that
//                read data and err are known whenever rvalid is HIGH
//                (IbexInstrRPayloadX, ibex_top.sv:1409-1410; IbexDataRPayloadX,
//                :1497-1503), on the SCP's core as on this one
//
// Bank 0's pins are the CPU RAM's (FULRR bit 0 on CPU0); the PCSM's other
// seven banks are unused.
//
// THE PORTS
//
// Port 0 (instr) and port 1 (data) answer one cycle after the request, from
// flops on the gated dev_clk reset by the core's own reset: a forced power-down
// then freezes a request and its response together, and in OFF they are
// cleared with the core. Port 1 is shared with the load port, which has
// priority: d_gnt_o is LOW in a cycle the SCP loads. The load port is BUS1 on
// the always-on clock and opens only while the PPU reports ON or WARM_RST
// (PPUHWSTAT, one-hot: ppu_pkg.sv:134-147); otherwise it answers err the next
// cycle and the RAM sees nothing.
//
// Residual window (SOC4_DESIGN.md Section 5.4): on the way down PPUHWSTAT reads
// ON for a few cycles after DEVCLKEN falls, so a load there would be answered
// from the always-on flop but not reach the stopped RAM. The firmware loads
// only in static WARM_RST (Section 9.5).
//
// TIMING
//
// dev_clk is clk_i through a latch-and-AND gate (common/clk_gate.sv): its edge
// is in the same time step as clk_i's, in a later delta. Every input to the
// array comes from an NBA-assigned flop (the SCP's, Ibex's), so the array
// samples the previous cycle's values with no race.

module soc4_cpu_ram (
  input  logic        dev_clk_i,     // the domain's gated clock: the array and the core-side responses
  input  logic        aon_clk_i,     // clk_i: the load port's response
  input  logic        aon_rst_ni,    // rst_ni
  input  logic        core_rst_ni,   // the core's reset (dev_ret_rst_n): clears the core-side responses
  input  logic        sleep_i,       // PCSM bank-0 retention pin
  input  logic        sd_i,          // PCSM bank-0 shutdown pin
  input  logic [15:0] hwstat_i,      // PPUHWSTAT

  // ---- Port 0: instruction fetch (IBX) ----
  input  logic        i_req_i,
  output logic        i_gnt_o,
  output logic        i_rvalid_o,
  input  logic [31:0] i_addr_i,
  output logic [31:0] i_rdata_o,
  output logic        i_err_o,

  // ---- Port 1: loads and stores (IBX) ----
  input  logic        d_req_i,
  output logic        d_gnt_o,
  output logic        d_rvalid_o,
  input  logic        d_we_i,
  input  logic [3:0]  d_be_i,
  input  logic [31:0] d_addr_i,
  input  logic [31:0] d_wdata_i,
  output logic [31:0] d_rdata_o,
  output logic        d_err_o,

  // ---- The SCP's load port (BUS1), sharing port 1 ----
  input  logic        ld_req_i,
  input  logic        ld_we_i,
  input  logic [3:0]  ld_be_i,
  input  logic [31:0] ld_addr_i,
  input  logic [31:0] ld_wdata_i,
  output logic        ld_rvalid_o,
  output logic [31:0] ld_rdata_o,
  output logic        ld_err_o,

  output logic        outstanding_o, // a request now, or a response owed (soc4_cpu_adp)
  output logic        ld_open_o      // the load port is open (soc4_ctrl CPU_STAT)
);

  localparam int unsigned NumWords = 1024;   // 4 KB at 0x0000_0000 of the CPU's map

  // ---- The pins ----
  logic acc, sram_rst_n, open;
  assign acc        = (sleep_i === 1'b0) && (sd_i === 1'b0);
  assign sram_rst_n = aon_rst_ni && (sd_i === 1'b0);
  assign open       = acc && (hwstat_i == 16'h0100 /* ON */ || hwstat_i == 16'h0200 /* WARM_RST */);

  // ---- Range: the CPU's map is this 4 KB and nothing else (SOC4_DESIGN.md 4.7) ----
  logic i_in, d_in;
  assign i_in = (i_addr_i[31:12] == '0);
  assign d_in = (d_addr_i[31:12] == '0);

  // ---- The array ----
  logic [1:0]       p_req, p_we;
  logic [1:0][9:0]  p_addr;
  logic [1:0][31:0] p_wdata, p_rdata;
  logic [1:0][3:0]  p_be;

  logic d_gnt;
  assign i_gnt_o = i_req_i;
  assign d_gnt   = d_req_i && !ld_req_i;
  assign d_gnt_o = d_gnt;

  assign p_req[0]   = i_req_i && i_in && acc;
  assign p_we[0]    = 1'b0;
  assign p_addr[0]  = i_addr_i[11:2];
  assign p_wdata[0] = '0;
  assign p_be[0]    = '0;

  always_comb begin
    if (ld_req_i) begin
      p_req[1]   = open;
      p_we[1]    = ld_we_i;
      p_addr[1]  = ld_addr_i[11:2];
      p_wdata[1] = ld_wdata_i;
      p_be[1]    = ld_be_i;
    end else begin
      p_req[1]   = d_req_i && d_in && acc;
      p_we[1]    = d_we_i;
      p_addr[1]  = d_addr_i[11:2];
      p_wdata[1] = d_wdata_i;
      p_be[1]    = d_be_i;
    end
  end

  tc_sram #(
    .NumWords (NumWords),
    .DataWidth(32),
    .ByteWidth(8),
    .NumPorts (2),
    .Latency  (1),
    .SimInit  ("none")
  ) u_sram (
    .clk_i  (dev_clk_i),
    .rst_ni (sram_rst_n),
    .req_i  (p_req),
    .we_i   (p_we),
    .addr_i (p_addr),
    .wdata_i(p_wdata),
    .be_i   (p_be),
    .rdata_o(p_rdata)
  );

  // ---- Core-side responses: dev_clk, the core's reset ----
  logic i_rvalid_q, i_err_q, i_ok_q;
  logic d_rvalid_q, d_err_q, d_ok_q;

  always_ff @(posedge dev_clk_i or negedge core_rst_ni) begin
    if (!core_rst_ni) begin
      i_rvalid_q <= 1'b0;
      i_err_q    <= 1'b0;
      i_ok_q     <= 1'b0;
      d_rvalid_q <= 1'b0;
      d_err_q    <= 1'b0;
      d_ok_q     <= 1'b0;
    end else begin
      i_rvalid_q <= i_req_i;
      i_err_q    <= i_req_i && !(i_in && acc);
      i_ok_q     <= i_req_i &&  (i_in && acc);
      d_rvalid_q <= d_gnt;
      d_err_q    <= d_gnt && !(d_in && acc);
      d_ok_q     <= d_gnt &&  (d_in && acc);
    end
  end

  assign i_rvalid_o = i_rvalid_q;
  assign i_err_o    = i_err_q;
  assign i_rdata_o  = i_ok_q ? p_rdata[0] : 32'h0;   // an errored response carries 0, never X
  assign d_rvalid_o = d_rvalid_q;
  assign d_err_o    = d_err_q;
  assign d_rdata_o  = d_ok_q ? p_rdata[1] : 32'h0;

  // ---- Load-port response: the always-on clock, BUS1 ----
  logic ld_rvalid_q, ld_err_q, ld_ok_q;

  always_ff @(posedge aon_clk_i or negedge aon_rst_ni) begin
    if (!aon_rst_ni) begin
      ld_rvalid_q <= 1'b0;
      ld_err_q    <= 1'b0;
      ld_ok_q     <= 1'b0;
    end else begin
      ld_rvalid_q <= ld_req_i;
      ld_err_q    <= ld_req_i && !open;
      ld_ok_q     <= ld_req_i &&  open;
    end
  end

  assign ld_rvalid_o = ld_rvalid_q;
  assign ld_err_o    = ld_err_q;
  // 0 on an error, as on the core side: the SCP's Ibex checks a read response
  // for X (IbexDataRPayloadX) whether or not it carries err, and a closed RAM's
  // read register holds X.
  assign ld_rdata_o  = ld_ok_q ? p_rdata[1] : 32'h0;

  assign outstanding_o = i_req_i || d_req_i || i_rvalid_q || d_rvalid_q;
  assign ld_open_o     = open;

endmodule
