`timescale 1ns/1ps
// One accelerator power domain of soc4: a PPU-controlled domain around the
// stand-in device ppu_device_ip.
//
// References: docs/SOC4_DESIGN.md Sections 3 (modes and every
// ppu_axi_dom_top parameter), 5.6 (this module) and 8.2; decision 7 of
// 2026-10-01; Arm Power
// Policy Unit Architecture Specification v1.1 (ARM DEN 0051E).
//
//   AXI4-Lite ──► u_dom (ppu_axi_dom_top: PPU, PCSM) [PD_AON_n]
//                   │ dev_clk, resets, ram_sleep/ram_sd    ▲ busy | hold_busy
//                   ▼                                      │
//                 u_ip (ppu_device_ip): u_core, u_ret [PD_DEV_n]; banks [AON]
//
// THE CONFIGURATION (SOC4_DESIGN.md Section 3.3)
//
// Static only, no lock, no direct OFF -> MEM_RET (decision 2), as soc4_cpu_dom.
// The modes are ON, WARM_RST and OFF, plus MEM_RET when MEM_RET = 1 (ACC0),
// with its PPU_MEMRR register (Table 5-21): logic off, the RAM banks retained
// by their pins (Table 3-1). WARM_RST_DEVREQEN_CFG = 0, so the SCP's WARM_RST
// recovery of a faulted accelerator needs no handshake (Table 4-4).
//
// THE DEVICE'S Q-CHANNEL POLICY
//
// As ppu_pd_top has always applied it: busy delays quiescence, deny && busy
// refuses it, wake | busy is DEVQACTIVE (qchannel_device: QACTIVE <= busy |
// wake). hold_busy_i is TEST-ONLY: ORed into busy, it models a device that
// never quiesces, which is how soc4bfm makes a power-off miss its deadline
// (SOC4_DESIGN.md Section 10.5). A real SoC ties it to 0.
//
// The mutant SOC4_MUT_ACC0_NORET (soc4neg M3, Section 10.6), on the MEM_RET = 1
// instance only, miswires the bank pins so that retention acts as shutdown.
// The PPU's configuration and identification registers are untouched.

module soc4_acc_dom #(
  parameter bit          MEM_RET           = 1'b0,  // 1: STA_MEM_RET_SPT_CFG and MEM_RET_RAM_REG_CFG (ACC0)
  parameter int unsigned DEV_CNT_W         = 12,    // ppu_device_ip CNT_W
  parameter int unsigned PCSM_RET_SETTLE   = 0,
  parameter int unsigned PCSM_LOGIC_SETTLE = 0
) (
  input  logic        clk_i,
  input  logic        rst_ni,

  // ---- PPU: AXI4-Lite subordinate, as ppu_axi_dom_top's ----
  input  logic [31:0] s_axi_awaddr,
  input  logic [2:0]  s_axi_awprot,
  input  logic        s_axi_awvalid,
  output logic        s_axi_awready,
  input  logic [31:0] s_axi_wdata,
  input  logic [3:0]  s_axi_wstrb,
  input  logic        s_axi_wvalid,
  output logic        s_axi_wready,
  output logic [1:0]  s_axi_bresp,
  output logic        s_axi_bvalid,
  input  logic        s_axi_bready,
  input  logic [31:0] s_axi_araddr,
  input  logic [2:0]  s_axi_arprot,
  input  logic        s_axi_arvalid,
  output logic        s_axi_arready,
  output logic [31:0] s_axi_rdata,
  output logic [1:0]  s_axi_rresp,
  output logic        s_axi_rvalid,
  input  logic        s_axi_rready,
  output logic        irq_o,
  output logic [15:0] hwstat_o,        // PPUHWSTAT

  // ---- Stimulus: the software that would run in this domain (testbench) ----
  input  logic                 start_i,
  input  logic [DEV_CNT_W-1:0] work_len_i,
  input  logic                 light_i,
  input  logic                 wake_i,
  input  logic                 deny_i,
  input  logic [1:0]           ip_cmd_i,
  input  logic [7:0]           ip_seed_i,

  // ---- The SoC's clkgate / tilereset, through u_ckrst (platform plan PD8,
  //      H16), as soc4_cpu_dom ----
  output logic                 tile_clk_req_o,
  input  logic                 tile_clk_ack_i,
  output logic [1:0]           tile_rst_req_no,
  input  logic [1:0]           tile_rst_ack_ni,
  output logic [7:0]           ckrst_stat_o,
  input  logic [7:0]           ckrst_clr_i,
  output logic                 ckrst_fault_o,

  input  logic                 hold_busy_i  // TEST-ONLY; 0 in a real SoC
);

  logic       dev_clk, dev_nret_rst_n, dev_ret_rst_n;
  logic       dev_clken_req, dev_isolaten;
  logic       ip_busy, busy_t;
  logic [7:0] ram_sleep, ram_sd, bank_sleep, bank_sd;

  // u_ip.busy is an isolated output (clamp 0); hold_busy_i is always-on.
  assign busy_t = ip_busy | hold_busy_i;

  ppu_axi_dom_top #(
    .DEF_PWR_DYN_EN       (1'b0),
    .DEF_PWR_POLICY       (ppu_pkg::PM_OFF),
    .WARM_RST_DEVREQEN_CFG(1'b0),
    .DYN_ON_SPT_CFG       (1'b0),
    .DYN_FUNC_RET_SPT_CFG (1'b0),
    .DYN_FULL_RET_SPT_CFG (1'b0),
    .DYN_MEM_OFF_SPT_CFG  (1'b0),
    .DYN_MEM_RET_SPT_CFG  (1'b0),
    .DYN_OFF_SPT_CFG      (1'b0),
    .STA_FUNC_RET_SPT_CFG (1'b0),
    .STA_FULL_RET_SPT_CFG (1'b0),
    .STA_MEM_OFF_SPT_CFG  (1'b0),
    .STA_MEM_RET_SPT_CFG  (MEM_RET),
    .OFF_MEM_RET_TRANS_CFG(1'b0),
    .FUNC_RET_RAM_REG_CFG (1'b0),
    .FULL_RET_RAM_REG_CFG (1'b0),
    .MEM_RET_RAM_REG_CFG  (MEM_RET),
    .LOCK_CFG             (1'b0),
    .PCSM_RESET_MODESTAT  (ppu_pkg::PM_OFF),
    .PCSM_RET_SETTLE      (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE    (PCSM_LOGIC_SETTLE),
    .AXI_ADDR_W           (32)
  ) u_dom (
    .aclk          (clk_i),
    .aresetn       (rst_ni),

    .s_axi_awaddr  (s_axi_awaddr),
    .s_axi_awprot  (s_axi_awprot),
    .s_axi_awvalid (s_axi_awvalid),
    .s_axi_awready (s_axi_awready),
    .s_axi_wdata   (s_axi_wdata),
    .s_axi_wstrb   (s_axi_wstrb),
    .s_axi_wvalid  (s_axi_wvalid),
    .s_axi_wready  (s_axi_wready),
    .s_axi_bresp   (s_axi_bresp),
    .s_axi_bvalid  (s_axi_bvalid),
    .s_axi_bready  (s_axi_bready),
    .s_axi_araddr  (s_axi_araddr),
    .s_axi_arprot  (s_axi_arprot),
    .s_axi_arvalid (s_axi_arvalid),
    .s_axi_arready (s_axi_arready),
    .s_axi_rdata   (s_axi_rdata),
    .s_axi_rresp   (s_axi_rresp),
    .s_axi_rvalid  (s_axi_rvalid),
    .s_axi_rready  (s_axi_rready),

    .irq           (irq_o),

    // ---- No hierarchical clock controller above this PPU's ----
    .hc_qreqn_i    (1'b1),
    .hc_qacceptn_o (),
    .hc_qdeny_o    (),
    .hc_qactive_o  (),
    .qactive_only_i(1'b0),
    .clk_force_i   (1'b0),
    .entry_delay_i (8'd0),

    // ---- The device side: the stand-in's policy, as ppu_pd_top applies it ----
    .dclk              (clk_i),
    .dev_quiescent_busy(busy_t),
    .dev_quiescent_deny(deny_i && busy_t),
    .dev_wake          (wake_i | busy_t),
    .dev_quiescent_ok  (),

    .dev_clk           (dev_clk),
    .dev_clken_req     (dev_clken_req),
    .dev_nret_rst_n    (dev_nret_rst_n),
    .dev_ret_rst_n     (dev_ret_rst_n),
    .ram_sleep         (ram_sleep),
    .ram_sd            (ram_sd),
    .ppuhwstat         (hwstat_o),

    // Named by the power intent at the PPU's and the PCSM's own pins;
    // dev_isolaten is also the clock/reset bridge's step input.
    .dev_isolaten      (dev_isolaten),
    .logic_on          (),
    .logic_ret         (),
    .ret_n             ()
  );

`ifdef SOC4_MUT_ACC0_NORET
  // soc4neg M3: retention acts as shutdown on ACC0 (SOC4_DESIGN.md 10.6).
  if (MEM_RET) begin : g_mut_noret
    assign bank_sleep = '0;
    assign bank_sd    = ram_sd | ram_sleep;
  end else begin : g_pins
    assign bank_sleep = ram_sleep;
    assign bank_sd    = ram_sd;
  end
`else
  assign bank_sleep = ram_sleep;
  assign bank_sd    = ram_sd;
`endif

  // ---- The clock/reset request bridge: always-on (soc4_cpu_dom's u_ckrst) ----
  ckrst_bridge #(.NUM_RST(2), .STEP_W(1), .STEP_SYNC(2), .ACK_SYNC(0)) u_ckrst (
    .clk_i     (clk_i),
    .rst_ni    (rst_ni),
    .clken_i   (dev_clken_req),
    .rst_n_i   ({dev_ret_rst_n, dev_nret_rst_n}),
    .step_i    (dev_isolaten),
    .clk_req_o (tile_clk_req_o),
    .clk_ack_i (tile_clk_ack_i),
    .rst_req_no(tile_rst_req_no),
    .rst_ack_ni(tile_rst_ack_ni),
    .stat_o    (ckrst_stat_o),
    .stat_clr_i(ckrst_clr_i),
    .fault_o   (ckrst_fault_o)
  );

  // ---- The device: the stand-in accelerator ----
  ppu_device_ip #(.CNT_W(DEV_CNT_W)) u_ip (
    .clk       (dev_clk),
    .nret_rst_n(dev_nret_rst_n),
    .ret_rst_n (dev_ret_rst_n),
    .start     (start_i),
    .work_len  (work_len_i),
    .light_work(light_i),
    .busy      (ip_busy),
    .done      (),
    .ip_cmd    (ip_cmd_i),
    .ip_seed   (ip_seed_i),
    .bank_sleep(bank_sleep),
    .bank_sd   (bank_sd)
  );

endmodule
