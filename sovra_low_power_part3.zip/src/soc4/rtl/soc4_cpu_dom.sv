`timescale 1ns/1ps
// One CPU power domain of soc4: a PPU-controlled domain around a real Ibex
// core, with its RAM and Q-Channel adapter beside it on the always-on side.
//
// References: docs/SOC4_DESIGN.md Sections 3 (modes and every
// ppu_axi_dom_top parameter), 5.3 (this module), 5.4, 5.5 and 8.2 (which
// instance is on which supply); decisions 5 and 7 of 2026-10-01; Arm Power
// Policy Unit Architecture Specification v1.1 (ARM DEN 0051E).
//
//   ┌───────────────────────────── soc4_cpu_dom ─────────────────────────────┐
//   │  AXI4-Lite ──► u_dom (ppu_axi_dom_top: PPU, PCSM)          [PD_AON_n]   │
//   │                 │ dev_clk, dev_ret_rst_n          ▲ busy/deny  ▲ qok   │
//   │                 ▼                                 │            │       │
//   │  u_core (scp_core, Ibex) [PD_DEV_n] ◄─wake── u_adp (soc4_cpu_adp) [AON] │
//   │     │ instr, data                                                       │
//   │     ▼                                                                   │
//   │  u_ram (soc4_cpu_ram, tc_sram 4 KB) [AON, PCSM bank-0 pins] ◄── load    │
//   └─────────────────────────────────────────────────────────────────────────┘
//
// THE CONFIGURATION (SOC4_DESIGN.md Section 3.3)
//
// Static only (decision 2): every DYN_*_SPT_CFG is 0, and so are LOCK_CFG and
// OFF_MEM_RET_TRANS_CFG. The modes are ON, WARM_RST and OFF, which every PPU
// has (DEN 0051E 3.1.1), plus FULL_RET when FULL_RET = 1 (CPU0), with its
// PPU_FULRR register (Table 5-20). LOGIC_RET and DBG_RECOV do not exist on a
// Q-Channel PPU (Figure 3-2). The domain comes out of reset OFF and stays
// there (DEF_PWR_POLICY = PCSM_RESET_MODESTAT = OFF, Table 4-13) until the SCP
// powers it. WARM_RST_DEVREQEN_CFG = 0: no Q-Channel handshake between ON and
// WARM_RST (Table 4-4), so the SCP can hold a running core in reset while it
// loads the RAM.
//
// THE CORE'S RESET IS dev_ret_rst_n
//
// PORESETn & RETRESETn (ppu_dom_top.sv:511-525): asserted in OFF and WARM_RST,
// released in ON, and -- the point -- held released in FULL_RET, where the
// clock stops and the supply goes to the retention rail. The whole core is
// retained there (SOC4_DESIGN.md Section 8.2), and resumes where it stopped.
// The mutant SOC4_MUT_CPU0_NRET (soc4neg, Section 10.6) puts CPU0's core on
// dev_nret_rst_n instead, which FULL_RET asserts; the RAM's core-side flops
// follow the core's reset either way.
//
// The always-on inputs into the switched core (boot_addr_i, fetch_en_i, the
// wake pulse, the resets) need no isolation; the core's outputs are isolated
// by the power intent, clamp 0.

module soc4_cpu_dom #(
  parameter logic [31:0] HART_ID           = 32'd0,
  parameter bit          FULL_RET          = 1'b0,  // 1: STA_FULL_RET_SPT_CFG and FULL_RET_RAM_REG_CFG (CPU0)
  parameter int unsigned PCSM_RET_SETTLE   = 0,
  parameter int unsigned PCSM_LOGIC_SETTLE = 0
) (
  input  logic        clk_i,
  input  logic        rst_ni,

  // ---- PPU: AXI4-Lite subordinate, as ppu_axi_dom_top's ----
  input  logic [31:0] s_axi_awaddr,
  input  logic [2:0]  s_axi_awprot,
  input  logic        s_axi_awvalid,
  output logic        s_axi_awready,
  input  logic [31:0] s_axi_wdata,
  input  logic [3:0]  s_axi_wstrb,
  input  logic        s_axi_wvalid,
  output logic        s_axi_wready,
  output logic [1:0]  s_axi_bresp,
  output logic        s_axi_bvalid,
  input  logic        s_axi_bready,
  input  logic [31:0] s_axi_araddr,
  input  logic [2:0]  s_axi_arprot,
  input  logic        s_axi_arvalid,
  output logic        s_axi_arready,
  output logic [31:0] s_axi_rdata,
  output logic [1:0]  s_axi_rresp,
  output logic        s_axi_rvalid,
  input  logic        s_axi_rready,
  output logic        irq_o,

  // ---- Boot control, from soc4_ctrl ----
  input  logic [31:0] boot_addr_i,     // CPUn_BOOT
  input  logic        fetch_en_i,      // CPU_FETCH_EN[n]

  // ---- The SCP's load port (BUS1, ext device 4 or 5) ----
  input  logic        ld_req_i,
  input  logic        ld_we_i,
  input  logic [3:0]  ld_be_i,
  input  logic [31:0] ld_addr_i,
  input  logic [31:0] ld_wdata_i,
  output logic        ld_rvalid_o,
  output logic [31:0] ld_rdata_o,
  output logic        ld_err_o,

  // ---- Status, for soc4_ctrl ----
  output logic [15:0] hwstat_o,        // PPUHWSTAT
  output logic        core_sleep_o,    // post-isolation
  output logic        ld_open_o,
  output logic        wake_o,          // the adapter's wake pulse (CPU_STAT[9:8])

  // ---- The SoC's clkgate / tilereset, through u_ckrst (platform plan PD8,
  //      H16): requests out, acknowledgements in; the bridge's status ----
  output logic        tile_clk_req_o,
  input  logic        tile_clk_ack_i,
  output logic [1:0]  tile_rst_req_no,  // [0] dev_nret_rst_n, [1] dev_ret_rst_n
  input  logic [1:0]  tile_rst_ack_ni,
  output logic [7:0]  ckrst_stat_o,     // ckrst_bridge's status byte (soc4_ctrl CKRST_STAT)
  input  logic [7:0]  ckrst_clr_i,      // its W1C
  output logic        ckrst_fault_o,

  input  logic        hold_busy_i      // TEST-ONLY (soc4_cpu_adp); 0 in a real SoC
);

  // ---- Between the domain wrapper, the core, the RAM and the adapter ----
  logic        dev_clk, dev_nret_rst_n, dev_ret_rst_n, core_rst_n;
  logic        dev_clken_req, dev_isolaten;
  logic        busy, deny, qok, wake_irq, outstanding;
  logic [7:0]  ram_sleep, ram_sd;
  logic [15:0] hwstat;

  logic        instr_req, instr_gnt, instr_rvalid, instr_err;
  logic [31:0] instr_addr, instr_rdata;
  logic        data_req, data_gnt, data_rvalid, data_we, data_err;
  logic [3:0]  data_be;
  logic [31:0] data_addr, data_wdata, data_rdata;
  logic        core_sleep;

`ifdef SOC4_MUT_CPU0_NRET
  // soc4neg M1: CPU0's core on the reset FULL_RET asserts (SOC4_DESIGN.md 10.6).
  if (HART_ID == 32'd0) begin : g_mut_nret
    assign core_rst_n = dev_nret_rst_n;
  end else begin : g_ret
    assign core_rst_n = dev_ret_rst_n;
  end
`else
  assign core_rst_n = dev_ret_rst_n;
`endif

  ppu_axi_dom_top #(
    .DEF_PWR_DYN_EN       (1'b0),
    .DEF_PWR_POLICY       (ppu_pkg::PM_OFF),
    .WARM_RST_DEVREQEN_CFG(1'b0),
    .DYN_ON_SPT_CFG       (1'b0),
    .DYN_FUNC_RET_SPT_CFG (1'b0),
    .DYN_FULL_RET_SPT_CFG (1'b0),
    .DYN_MEM_OFF_SPT_CFG  (1'b0),
    .DYN_MEM_RET_SPT_CFG  (1'b0),
    .DYN_OFF_SPT_CFG      (1'b0),
    .STA_FUNC_RET_SPT_CFG (1'b0),
    .STA_FULL_RET_SPT_CFG (FULL_RET),
    .STA_MEM_OFF_SPT_CFG  (1'b0),
    .STA_MEM_RET_SPT_CFG  (1'b0),
    .OFF_MEM_RET_TRANS_CFG(1'b0),
    .FUNC_RET_RAM_REG_CFG (1'b0),
    .FULL_RET_RAM_REG_CFG (FULL_RET),
    .MEM_RET_RAM_REG_CFG  (1'b0),
    .LOCK_CFG             (1'b0),
    .PCSM_RESET_MODESTAT  (ppu_pkg::PM_OFF),
    .PCSM_RET_SETTLE      (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE    (PCSM_LOGIC_SETTLE),
    .AXI_ADDR_W           (32)
  ) u_dom (
    .aclk          (clk_i),
    .aresetn       (rst_ni),

    .s_axi_awaddr  (s_axi_awaddr),
    .s_axi_awprot  (s_axi_awprot),
    .s_axi_awvalid (s_axi_awvalid),
    .s_axi_awready (s_axi_awready),
    .s_axi_wdata   (s_axi_wdata),
    .s_axi_wstrb   (s_axi_wstrb),
    .s_axi_wvalid  (s_axi_wvalid),
    .s_axi_wready  (s_axi_wready),
    .s_axi_bresp   (s_axi_bresp),
    .s_axi_bvalid  (s_axi_bvalid),
    .s_axi_bready  (s_axi_bready),
    .s_axi_araddr  (s_axi_araddr),
    .s_axi_arprot  (s_axi_arprot),
    .s_axi_arvalid (s_axi_arvalid),
    .s_axi_arready (s_axi_arready),
    .s_axi_rdata   (s_axi_rdata),
    .s_axi_rresp   (s_axi_rresp),
    .s_axi_rvalid  (s_axi_rvalid),
    .s_axi_rready  (s_axi_rready),

    .irq           (irq_o),

    // ---- No hierarchical clock controller above this PPU's ----
    .hc_qreqn_i    (1'b1),
    .hc_qacceptn_o (),
    .hc_qdeny_o    (),
    .hc_qactive_o  (),
    .qactive_only_i(1'b0),
    .clk_force_i   (1'b0),
    .entry_delay_i (8'd0),

    // ---- The device side: the adapter's policy, no device wake (decision 7) ----
    .dclk              (clk_i),
    .dev_quiescent_busy(busy),
    .dev_quiescent_deny(deny),
    .dev_wake          (1'b0),
    .dev_quiescent_ok  (qok),

    .dev_clk           (dev_clk),
    .dev_clken_req     (dev_clken_req),
    .dev_nret_rst_n    (dev_nret_rst_n),
    .dev_ret_rst_n     (dev_ret_rst_n),
    .ram_sleep         (ram_sleep),
    .ram_sd            (ram_sd),
    .ppuhwstat         (hwstat),

    // Named by the power intent at the PPU's and the PCSM's own pins;
    // dev_isolaten is also the clock/reset bridge's step input.
    .dev_isolaten      (dev_isolaten),
    .logic_on          (),
    .logic_ret         (),
    .ret_n             ()
  );

  // ---- The core: switched (PD_DEV_n) ----
  scp_core #(.HART_ID(HART_ID)) u_core (
    .clk_i         (dev_clk),
    .rst_ni        (core_rst_n),
    .boot_addr_i   (boot_addr_i),

    .instr_req_o   (instr_req),
    .instr_gnt_i   (instr_gnt),
    .instr_rvalid_i(instr_rvalid),
    .instr_addr_o  (instr_addr),
    .instr_rdata_i (instr_rdata),
    .instr_err_i   (instr_err),

    .data_req_o    (data_req),
    .data_gnt_i    (data_gnt),
    .data_rvalid_i (data_rvalid),
    .data_we_o     (data_we),
    .data_be_o     (data_be),
    .data_addr_o   (data_addr),
    .data_wdata_o  (data_wdata),
    .data_rdata_i  (data_rdata),
    .data_err_i    (data_err),

    .irq_timer_i   (1'b0),
    .irq_external_i(wake_irq),
    .irq_fast_i    (15'd0),
    .irq_nm_i      (1'b0),

    .fetch_enable_i(fetch_en_i),
    .core_sleep_o  (core_sleep)
  );

  // ---- The RAM: always-on, retained or shut down by the PCSM's bank-0 pins ----
  soc4_cpu_ram u_ram (
    .dev_clk_i    (dev_clk),
    .aon_clk_i    (clk_i),
    .aon_rst_ni   (rst_ni),
    .core_rst_ni  (core_rst_n),
    .sleep_i      (ram_sleep[0]),
    .sd_i         (ram_sd[0]),
    .hwstat_i     (hwstat),

    .i_req_i      (instr_req),
    .i_gnt_o      (instr_gnt),
    .i_rvalid_o   (instr_rvalid),
    .i_addr_i     (instr_addr),
    .i_rdata_o    (instr_rdata),
    .i_err_o      (instr_err),

    .d_req_i      (data_req),
    .d_gnt_o      (data_gnt),
    .d_rvalid_o   (data_rvalid),
    .d_we_i       (data_we),
    .d_be_i       (data_be),
    .d_addr_i     (data_addr),
    .d_wdata_i    (data_wdata),
    .d_rdata_o    (data_rdata),
    .d_err_o      (data_err),

    .ld_req_i     (ld_req_i),
    .ld_we_i      (ld_we_i),
    .ld_be_i      (ld_be_i),
    .ld_addr_i    (ld_addr_i),
    .ld_wdata_i   (ld_wdata_i),
    .ld_rvalid_o  (ld_rvalid_o),
    .ld_rdata_o   (ld_rdata_o),
    .ld_err_o     (ld_err_o),

    .outstanding_o(outstanding),
    .ld_open_o    (ld_open_o)
  );

  // ---- The Q-Channel adapter: always-on ----
  soc4_cpu_adp u_adp (
    .dclk_i       (clk_i),
    .aon_rst_ni   (rst_ni),
    .core_sleep_i (core_sleep),
    .outstanding_i(outstanding),
    .qok_i        (qok),
    .hold_busy_i  (hold_busy_i),
    .busy_o       (busy),
    .deny_o       (deny),
    .wake_irq_o   (wake_irq)
  );

  // ---- The clock/reset request bridge: always-on (platform plan H16) ----
  // soc4 has no SoC clkgate or tilereset: the testbench's model
  // (tb/ckrst/soc_ckrst_model.sv) acknowledges the requests, and dev_clk and
  // the resets still come from the PPU's wrapper, so the bridge observes and
  // checks without changing the domain's timing. In the SoC the tile's clock
  // and resets come from the blocks the requests go to.
  ckrst_bridge #(.NUM_RST(2), .STEP_W(1), .STEP_SYNC(2), .ACK_SYNC(0)) u_ckrst (
    .clk_i     (clk_i),
    .rst_ni    (rst_ni),
    .clken_i   (dev_clken_req),
    .rst_n_i   ({dev_ret_rst_n, dev_nret_rst_n}),
    .step_i    (dev_isolaten),
    .clk_req_o (tile_clk_req_o),
    .clk_ack_i (tile_clk_ack_i),
    .rst_req_no(tile_rst_req_no),
    .rst_ack_ni(tile_rst_ack_ni),
    .stat_o    (ckrst_stat_o),
    .stat_clr_i(ckrst_clr_i),
    .fault_o   (ckrst_fault_o)
  );

  assign hwstat_o     = hwstat;
  assign core_sleep_o = core_sleep;
  assign wake_o       = wake_irq;

endmodule
