`timescale 1ns/1ps
// soc4's control registers, at SCP 0x0002_1000: the CPUs' boot address and
// fetch enable, the AP's run bit, the static straps, and status.
//
// References: docs/SOC4_DESIGN.md Sections 4.4 (the register
// map) and 5.8 (this module); decisions 5 and 6 of 2026-10-01.
//
// A bus.sv device (BUS1): it answers exactly one cycle after the request and
// cannot stall. Reset by rst_ni only, so the SCP held in reset leaves it as it
// was. Every output is known from reset, so Ibex's ASSERT_KNOWN on its boot
// address (IbexBootAddrX, ibex_top.sv:1404) holds in the CPUs.
//
//   off    name        access  reset  fields
//   0x000  CPU0_BOOT   RW      0      [31:8] CPU0's boot address; [7:0] read 0,
//                                     writes ignored: Ibex requires them 0
//                                     (ibex_if_stage.sv:932) and fetches its
//                                     first instruction at {[31:8], 8'h80}
//                                     (ibex_if_stage.sv:243, 250-251)
//   0x004  CPU1_BOOT   RW      0      as CPU0_BOOT
//   0x008  CPU_FETCH_EN RW     0      [n] CPUn's fetch enable
//   0x00C  AP_RUN      RW      0      [0] the AP's fetch enable (ANDed with
//                                     !BFM_SEL in soc4_top)
//   0x010  STRAPS      RO             [0] BFM_SEL
//   0x014  CPU_STAT    RO             [1:0] core_sleep of CPU1..0, post-isolation;
//                                     [5:4] load port open for CPU1..0;
//                                     [9:8] bit 0 of each CPU's wake-pulse count
//   0x020+4n HWSTAT_n  RO             [15:0] PPUHWSTAT of domain n, n = 0..3
//   0x030  CKRST_STAT  R/W1C   0      [8n+7:8n] domain n's clock/reset bridge
//                                     status (ckrst_bridge.sv): [0] LATE,
//                                     [1] MISSING, [2] SPURIOUS, [4] clock,
//                                     [5] reset 0 (dev_nret_rst_n), [6] reset 1
//                                     (dev_ret_rst_n). Sticky in the bridge;
//                                     writing 1 clears (byte lane n for domain
//                                     n). Platform plan H16, F11 (2026-10-05)
//
// Writes to CPUn_BOOT honour the byte enables; the other RW registers take
// their bits from byte lane 0. Writes to an RO register are ignored; any other
// offset answers err. core_sleep is defined only while the domain's PPUHWSTAT
// is ON or WARM_RST: outside them it reads 1 in RTL simulation (Ibex in reset)
// and 0 under power intent (the isolation clamp).

module soc4_ctrl (
  input  logic             clk_i,
  input  logic             rst_ni,

  // ---- bus.sv device port (BUS1) ----
  input  logic             req_i,
  input  logic             we_i,
  input  logic [3:0]       be_i,
  input  logic [31:0]      addr_i,
  input  logic [31:0]      wdata_i,
  output logic             rvalid_o,
  output logic [31:0]      rdata_o,
  output logic             err_o,

  // ---- Controls ----
  output logic [1:0][31:0] cpu_boot_o,
  output logic [1:0]       cpu_fetch_en_o,
  output logic             ap_run_o,

  // ---- Status ----
  input  logic             bfm_sel_i,
  input  logic [1:0]       cpu_sleep_i,
  input  logic [1:0]       cpu_ld_open_i,
  input  logic [1:0]       cpu_wake_i,     // each CPU adapter's wake pulse
  input  logic [3:0][15:0] hwstat_i,

  // ---- The clock/reset bridges (H16): status in, W1C out (one cycle) ----
  input  logic [3:0][7:0]  ckrst_stat_i,
  output logic [3:0][7:0]  ckrst_clr_o
);

  localparam logic [11:0] R_CPU0_BOOT = 12'h000;
  localparam logic [11:0] R_CPU1_BOOT = 12'h004;
  localparam logic [11:0] R_FETCH_EN  = 12'h008;
  localparam logic [11:0] R_AP_RUN    = 12'h00C;
  localparam logic [11:0] R_STRAPS    = 12'h010;
  localparam logic [11:0] R_CPU_STAT  = 12'h014;
  localparam logic [11:0] R_HWSTAT0   = 12'h020;
  localparam logic [11:0] R_HWSTAT3   = 12'h02C;
  localparam logic [11:0] R_CKRST     = 12'h030;

  logic [11:0] off;
  assign off = {addr_i[11:2], 2'b00};

  logic [1:0][31:8] boot_q;
  logic [1:0]       fetch_q;
  logic             ap_run_q;
  logic [1:0]       wake_q, wake_cnt_q;   // wake_cnt_q[n]: bit 0 of CPUn's pulse count

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      boot_q     <= '0;
      fetch_q    <= '0;
      ap_run_q   <= 1'b0;
      wake_q     <= '0;
      wake_cnt_q <= '0;
      ckrst_clr_o <= '0;
      rvalid_o   <= 1'b0;
      rdata_o    <= '0;
      err_o      <= 1'b0;
    end else begin
      wake_q     <= cpu_wake_i;
      wake_cnt_q <= wake_cnt_q ^ (cpu_wake_i & ~wake_q);

      rvalid_o <= req_i;
      err_o    <= 1'b0;
      rdata_o  <= '0;
      ckrst_clr_o <= '0;
      if (req_i) begin
        unique case (off)
          R_CPU0_BOOT, R_CPU1_BOOT: begin
            if (we_i) begin
              for (int b = 1; b < 4; b++)
                if (be_i[b]) boot_q[off[2]][8*b +: 8] <= wdata_i[8*b +: 8];
            end else begin
              rdata_o <= {boot_q[off[2]], 8'h00};
            end
          end
          R_FETCH_EN: begin
            if (we_i) begin
              if (be_i[0]) fetch_q <= wdata_i[1:0];
            end else begin
              rdata_o <= {30'd0, fetch_q};
            end
          end
          R_AP_RUN: begin
            if (we_i) begin
              if (be_i[0]) ap_run_q <= wdata_i[0];
            end else begin
              rdata_o <= {31'd0, ap_run_q};
            end
          end
          R_STRAPS:   if (!we_i) rdata_o <= {31'd0, bfm_sel_i};
          R_CPU_STAT: if (!we_i) rdata_o <= {22'd0, wake_cnt_q, 2'b00, cpu_ld_open_i, 2'b00, cpu_sleep_i};
          R_CKRST: begin
            if (we_i) begin
              for (int n = 0; n < 4; n++)
                if (be_i[n]) ckrst_clr_o[n] <= wdata_i[8*n +: 8];
            end else begin
              rdata_o <= ckrst_stat_i;
            end
          end
          default: begin
            if (off >= R_HWSTAT0 && off <= R_HWSTAT3) begin
              if (!we_i) rdata_o <= {16'd0, hwstat_i[off[3:2]]};
            end else begin
              err_o <= 1'b1;
            end
          end
        endcase
      end
    end
  end

  for (genvar n = 0; n < 2; n++) begin : g_cpu
    assign cpu_boot_o[n] = {boot_q[n], 8'h00};
  end
  assign cpu_fetch_en_o = fetch_q;
  assign ap_run_o       = ap_run_q;

endmodule
