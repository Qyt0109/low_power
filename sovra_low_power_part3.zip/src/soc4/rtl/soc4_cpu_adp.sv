`timescale 1ns/1ps
// A CPU domain's Q-Channel adapter: the device-side policy of an Ibex core
// behind a PPU. Always-on (PD_AON_n).
//
// References: docs/SOC4_DESIGN.md Section 5.5 (this module) and
// decision 7 of 2026-10-01; AMBA Low Power Interface Specification (ARM IHI
// 0068C) Section 2.1 for the Q-Channel; rtl/qchannel/qchannel_device.sv:77-128
// for how busy, deny and Q_STOPPED are applied.
//
//                 ┌────────────── soc4_cpu_adp ──────────────┐
//   core_sleep ──►│ deny = !hold_busy &&                     ├──► deny_o  (dev_quiescent_deny)
//   outstanding ─►│        !(core_sleep && !outstanding)     │
//   hold_busy ───►│ busy = hold_busy                         ├──► busy_o  (dev_quiescent_busy)
//   qok ─────────►│ leaving Q_STOPPED -> WAKE_PULSE cycles   ├──► wake_irq_o (core irq_external_i)
//                 └──────────────────────────────────────────┘
//
// ACCEPT ONLY IN WFI, WITH NOTHING OUTSTANDING
//
// qchannel_device answers a quiescence request with QDENY if deny is HIGH
// (deny wins over busy), waits in Q_REQUEST while busy is HIGH, and accepts
// otherwise. A core is quiescent when it sleeps in WFI and its RAM owes it
// nothing: core_sleep_o = 1 already means no fetch and no LSU transaction is
// outstanding (ibex_top.sv:316-331, ibex_core.sv:507-516), and outstanding_i
// (soc4_cpu_ram) closes the remaining gap -- a request on the wires this
// cycle, or a response the RAM still owes. Anything else is denied.
//
// hold_busy_i is TEST-ONLY. It models a device that is busy and never answers
// (SOC4_DESIGN.md Section 10.5): busy is held HIGH and deny suppressed, so a
// quiescence request waits in Q_REQUEST and the PPU, which has no timeout,
// waits with it. A real SoC ties it to 0, which makes this exactly decision 7.
//
// THE WAKE PULSE
//
// No device wake (dev_wake = 0, in soc4_cpu_dom). After a handshaked entry,
// the core resumes from WFI only on an interrupt, so when the Q-Channel leaves
// Q_STOPPED this module drives wake_irq_o HIGH for WAKE_PULSE dclk cycles.
// Ibex leaves WFI on mip & mie whatever mstatus.MIE is (ibex_cs_registers.sv:
// 1042-1043, ibex_controller.sv:603-620). The pulse must end before the core's
// next WFI, or core_sleep_o stays LOW and the next request is denied; 8 cycles
// is far shorter than the CPU program's work after a wake.
//
// The pulse also fires on the first ON from OFF, while the core is out of
// reset with fetch disabled; the WARM_RST that follows resets it. A forced
// entry (DEVREQEN = 0) has no Q_STOPPED and therefore no pulse: CPU0 then
// resumes exactly where it was frozen (SOC4_DESIGN.md Section 5.4).

module soc4_cpu_adp #(
  parameter int unsigned WAKE_PULSE = 8
) (
  input  logic dclk_i,          // the domain's ungated device-side clock
  input  logic aon_rst_ni,

  input  logic core_sleep_i,    // Ibex core_sleep_o, through isolation (clamp 0)
  input  logic outstanding_i,   // soc4_cpu_ram.outstanding_o
  input  logic qok_i,           // ppu_axi_dom_top.dev_quiescent_ok: Q_STOPPED, in dclk
  input  logic hold_busy_i,     // TEST-ONLY (soc4_top.hold_busy_i[n]); 0 in a real SoC

  output logic busy_o,          // -> dev_quiescent_busy
  output logic deny_o,          // -> dev_quiescent_deny
  output logic wake_irq_o       // -> the core's irq_external_i
);

  localparam int unsigned CW = $clog2(WAKE_PULSE + 1);

  assign busy_o = hold_busy_i;
  assign deny_o = !hold_busy_i && !(core_sleep_i && !outstanding_i);

  logic          qok_q;
  logic [CW-1:0] pulse_q;

  always_ff @(posedge dclk_i or negedge aon_rst_ni) begin
    if (!aon_rst_ni) begin
      qok_q   <= 1'b0;
      pulse_q <= '0;
    end else begin
      qok_q <= qok_i;
      if (qok_q && !qok_i)    pulse_q <= CW'(WAKE_PULSE);   // leaving Q_STOPPED
      else if (pulse_q != '0) pulse_q <= pulse_q - 1'b1;
    end
  end

  assign wake_irq_o = (pulse_q != '0);

endmodule
