`timescale 1ns/1ps
// The mailbox's TL-UL boundary adapter (platform plan H13): one per mailbox
// port, inside soc4_mbx, between an agent's fabric and the port's socket. It
// presents the platform's TL-UL subordinate to a SoC TileLink host. Glue only:
// no state, no protocol change.
//
// References: Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Sections 14.2 (H13) and
// 14.7; OpenTitan at 16e86c9e (vendor/opentitan/README.md): tlul_pkg.sv:46-58
// (a_user and TL_A_USER_DEFAULT), top_pkg.sv (the widths).
//
// WHAT IT DOES
//
//   a_user    HAS_A_USER = 0: a host without OpenTitan's a_user (a Chipyard
//             TileLink host has none) gets tlul_pkg::TL_A_USER_DEFAULT: no
//             instruction fetch (MuBi4False), integrity fields all ones
//             (tlul_pkg.sv:53-58). HAS_A_USER = 1 passes the host's a_user
//             (soc4's AP, whose tlul_adapter_host drives it).
//   integrity none is checked: every device behind the port is built with
//             CmdIntgCheck = 0 (soc4_mbx.sv), so a host that sends no command
//             integrity is accepted. The devices still generate response
//             integrity (EnableRspIntgGen = 1) for a host that checks it.
//   widths    TL-UL needs the host's address and data widths to equal the
//             platform's (top_pkg: TL_AW = 32, TL_DW = 32): an elaboration
//             error otherwise. A host's source ID may be narrower than
//             TL_AIW = 8 (HOST_SRCW): the bits above it are driven 0, so an
//             undriven upper bit never reaches the firewall, and d_source
//             returns the host's own ID in its low bits. A wider source ID is
//             an elaboration error: it would not survive the round trip.
//             a_size above 2 (more than 32 bits), and a mask that does not fit
//             the address and size, are answered d_error by the devices'
//             tlul_err (tlul_err.sv), as for any TL-UL host.
//
// THE SoC SIDE. SOVRA's fabric is TileLink TL-UH (Chipyard, VtCPU). The SoC
// converts each mailbox master to TL-UL with standard Chipyard/rocket-chip
// widgets before this adapter -- TLFragmenter to 4-byte beats (no bursts),
// TLWidthWidget to 32 bits, TLSourceShrinker to HOST_SRCW bits if needed, and
// TLAtomicAutomata or an error on atomics -- so what arrives here is TL-UL Get,
// PutFullData and PutPartialData of at most 4 bytes. The firewall's a_source
// values and masks (soc4_mbx.sv, FW_VAL/FW_MASK) are those of the converted
// source IDs: an external dependency on the SoC (Section 14.6).

module soc4_tl_bound #(
  parameter bit          HAS_A_USER = 1'b1,  // the host drives OpenTitan's a_user
  parameter int unsigned HOST_AW    = 32,    // the host's address width
  parameter int unsigned HOST_DW    = 32,    // ... data width
  parameter int unsigned HOST_SRCW  = 8      // ... source-ID width (<= TL_AIW)
) (
  input  logic              clk_i,           // for the testbench's bound checker only
  input  logic              rst_ni,

  input  tlul_pkg::tl_h2d_t tl_h_i,          // from the agent's fabric
  output tlul_pkg::tl_d2h_t tl_h_o,
  output tlul_pkg::tl_h2d_t tl_d_o,          // to the port's socket
  input  tlul_pkg::tl_d2h_t tl_d_i
);

  if (HOST_AW != top_pkg::TL_AW || HOST_DW != top_pkg::TL_DW) begin : g_bad_width
    $error("soc4_tl_bound: host AW/DW %0d/%0d, the platform's TL-UL is %0d/%0d (top_pkg.sv)",
           HOST_AW, HOST_DW, top_pkg::TL_AW, top_pkg::TL_DW);
  end
  if (HOST_SRCW < 1 || HOST_SRCW > top_pkg::TL_AIW) begin : g_bad_srcw
    $error("soc4_tl_bound: host source width %0d, must be 1..TL_AIW = %0d",
           HOST_SRCW, top_pkg::TL_AIW);
  end

  localparam logic [top_pkg::TL_AIW-1:0] SrcMask = top_pkg::TL_AIW'((1 << HOST_SRCW) - 1);

  always_comb begin
    tl_d_o          = tl_h_i;
    tl_d_o.a_source = tl_h_i.a_source & SrcMask;
    if (!HAS_A_USER) tl_d_o.a_user = tlul_pkg::TL_A_USER_DEFAULT;
  end

  assign tl_h_o = tl_d_i;

  logic unused_clk;
  assign unused_clk = clk_i ^ rst_ni;

endmodule
