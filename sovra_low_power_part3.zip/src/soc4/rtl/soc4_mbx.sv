`timescale 1ns/1ps
// soc4's RPMI mailbox: NUM_AGENTS RPMI shared-memory transports over
// NUM_PORTS TL-UL subordinate ports. Per agent k: a queue window (a region of
// one shared memory), a doorbell bit RING[k] that is its own input of the
// SCP's interrupt block, and a firewall entry on the TL-UL a_source.
// Always-on (PD_TOP).
//
// References: Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Sections 14.1 (PD6),
// 14.7 (H11, H12, H13, F6) and 15.2 phase 3; docs/SOC4_DESIGN.md
// Sections 4.5, 4.6 and 5.2 and decision 10 of 2026-10-01 (the one-agent
// mailbox this generalises); OpenTitan at 16e86c9e (vendor/opentitan/README.md)
// for the socket and the adapters; librpmi v1.0.0 lib/rpmi_transport_shmem.c:
// 236-249 for the queue layout each window holds; OpenSBI v1.9
// lib/utils/mailbox/fdt_mailbox_rpmi_shmem.c:300-305, 616-617 for how an RPMI
// agent rings a doorbell.
//
//                     ┌───────────────────────── soc4_mbx ─────────────────────────┐
//   port p (TL-UL) ──►│ u_bound (H13) ─► firewall+decode ─sel─► u_sock (2 * NP)    │
//   (one per port)    │                   for each agent k bound to port p:        │
//                     │                     ├─2j──► u_sram_ad ─► u_qmem port 1+k   │
//                     │                     ├─2j+1► u_db_ad ──► RING[k]            │
//                     │                     └─err─► tlul_err_resp (in the socket)  │
//   SCP mem (BUS1) ──►│ NUM_AGENTS KiB ─────────────────────────► u_qmem port 0    │
//   SCP regs (BUS1) ─►│ DB_*, INFO, FW_LAST, per agent FW_EN/VAL/MASK, counters    │
//                     │ db_irq_o[k] = RING[k] ───────────────────► scp_irq input   │
//                     └────────────────────────────────────────────────────────────┘
//
// AGENTS AND PORTS. AGENT_PORT[k] binds agent k to one port; a port may carry
// several agents, and every port carries at least one. A port decodes only
// the windows of its own agents: anything else is an error there. A port per
// agent (soc4: AP on port 0, RPU on port 1) lets an agent reach the SCP on its
// own path -- SOVRA's RPU must, in Eco mode, with the mesh off -- and one
// agent's stalled access then never holds up another's (each port has its own
// socket, and each window its own adapter and memory port).
//
// AN AGENT'S VIEW (agent k, on port AGENT_PORT[k]), decoded on the full
// a_address, W = TL_BASE + k * 0x2000:
//
//   W + 0x0000-03FF  queue window k: Get, PutFull, PutPartial (byte enables)
//   W + 0x1000       DOORBELL k: any write (any data, any mask) sets RING[k];
//                    a read returns 0, no effect
//   W + 0x1004-1FFF  d_error, no effect
//   anything else    d_error (tlul_err_resp inside the socket): another
//                    agent's window, and every address that is not a window.
//                    The SCP's registers have no TL-UL path at all.
//   window k while !FW_EN[k] or (a_source & FW_MASK[k]) != FW_VAL[k]: d_error,
//   no effect, DENY_CNT[k] counts it and FW_LAST records it (H12)
//
// soc4: agent 0 (the AP) at 0x2000_0000/0x2000_1000, agent 1 (the RPU) at
// 0x2000_2000/0x2000_3000.
//
// THE SCP'S VIEW: the queue memory at 0x0002_4000, window k at + k * 0x400
// (NUM_AGENTS KiB, byte enables honoured), and these registers at 0x0002_2000,
// which no agent can reach:
//
//   off           name       access            reset  fields
//   0x000         DB_STATUS  RO                0      [N-1:0] RING: bit k sticky;
//                                                     set by an accepted write
//                                                     to doorbell k; drives
//                                                     db_irq_o[k] as a level
//   0x004         DB_CLEAR   WO, W1C                  bit k = 1 clears RING[k].
//                                                     A ring in the same cycle
//                                                     wins
//   0x008         INFO       RO                       [7:0] NUM_AGENTS,
//                                                     [15:8] NUM_PORTS
//   0x00C         FW_LAST    RO                0      the last denial: [7:0]
//                                                     a_source, [8] valid, [9]
//                                                     FW_EN[k] was 0, [19:16] k,
//                                                     the transport whose
//                                                     window it addressed
//   0x100 + 0x20k FW_EN[k]   RW                0      [0] 0 denies every request
//                                                     to window k
//   0x104 + 0x20k FW_VAL[k]  RW                0x00   [7:0] admitted when
//   0x108 + 0x20k FW_MASK[k] RW                0xFF   [7:0] (a_source & FW_MASK)
//                                                     == FW_VAL. The reset
//                                                     values match source 0x00
//                                                     alone, as the one-agent
//                                                     FW_SRC did: an FW_EN set
//                                                     before the entry is
//                                                     programmed opens nothing
//                                                     wider
//   0x10C + 0x20k DENY_CNT[k] RO, write clears 0      denials of window k,
//                                                     counted at the socket's
//                                                     host-side A handshake,
//                                                     saturating
//   0x110 + 0x20k RING_CNT[k] RO, write clears 0      accepted writes to
//                                                     doorbell k
//
// A bus.sv device (BUS1), registered read data. Single-bit and byte fields
// take byte lane 0, DB_CLEAR honours every lane; a write to an RO register is
// ignored; any other offset answers err. Reset by rst_ni only: every FW_EN is
// 0 from reset (deny-all) whatever the SCP does, which soc4bfm's B0 and R0
// show with the SCP held in reset. Two denials in one cycle (on two ports):
// FW_LAST records the higher port's.
//
// ADDING OR REMOVING AN AGENT is a hand edit in a small set of places
// (SOVRA_PCSA_ARCHITECTURE.md Section 15.3): this module's NUM_AGENTS,
// NUM_PORTS, AGENT_PORT and PORT_HAS_A_USER and the port wiring in the
// platform top (soc4_top.sv), with the doorbell's input of the interrupt block
// and the ext window's queue-memory size there; the agent's entry in the
// platform header (soc4_plat.h, SCP_PLAT_AGENTS) with its doorbell input
// (SCP_PLAT_INPUTS) and its permissions (SCP_PLAT_DOMAINS); and, outside the
// repository, the software contract (window, doorbell, source ID, DOMAIN_IDs).
//
// INTEGRATION RULES (vendor/opentitan/README.md)
//
// soc4's AP checks response integrity on every response
// (tlul_rsp_intg_chk.sv:25-29, 47; tlul_adapter_host.sv:142), so both device
// adapters generate it (EnableRspIntgGen = 1); tlul_err_resp already does.
// CmdIntgCheck = 0: a host may send no command integrity at all (H13,
// soc4_tl_bound.sv). A denied request reaches no device: tlul_err_resp answers
// it a cycle later with d_error and DataWhenError (tlul_err_resp.sv:37-69). A
// socket holds a request to a different device until every response is back
// (tlul_socket_1n.sv:132-134), so responses return in order on each port, as
// the AP's Ibex needs.
//
// A window's word is written by two memory ports in one cycle only if its
// agent and the SCP touch the same head or tail, which RPMI's ownership rules
// exclude; tc_sram would let the agent's port, the higher one, win
// (tc_sram.sv:42-46). No two agents share a window: the firewall admits only
// agent k's sources to window k, and only through agent k's port.

module soc4_mbx #(
  parameter int unsigned                     NUM_AGENTS      = 2,
  parameter int unsigned                     NUM_PORTS       = 2,
  // AGENT_PORT[k]: the port agent k is bound to
  parameter logic [NUM_AGENTS-1:0][3:0]      AGENT_PORT      = {4'd1, 4'd0},
  // bit p: port p's host drives OpenTitan's a_user (soc4_tl_bound.sv)
  parameter logic [NUM_PORTS-1:0]            PORT_HAS_A_USER = '1,
  parameter logic [31:0]                     TL_BASE         = 32'h2000_0000
) (
  input  logic                   clk_i,
  input  logic                   rst_ni,

  // ---- Agents: one TL-UL subordinate per port ----
  input  tlul_pkg::tl_h2d_t      tl_h_i [NUM_PORTS],
  output tlul_pkg::tl_d2h_t      tl_h_o [NUM_PORTS],

  // ---- SCP registers, BUS1 ----
  input  logic                   reg_req_i,
  input  logic                   reg_we_i,
  input  logic [3:0]             reg_be_i,
  input  logic [31:0]            reg_addr_i,
  input  logic [31:0]            reg_wdata_i,
  output logic                   reg_rvalid_o,
  output logic [31:0]            reg_rdata_o,
  output logic                   reg_err_o,

  // ---- SCP queue-memory port, BUS1 ----
  input  logic                   mem_req_i,
  input  logic                   mem_we_i,
  input  logic [3:0]             mem_be_i,
  input  logic [31:0]            mem_addr_i,
  input  logic [31:0]            mem_wdata_i,
  output logic                   mem_rvalid_o,
  output logic [31:0]            mem_rdata_o,
  output logic                   mem_err_o,

  // ---- Doorbells to scp_irq: bit k a level, sticky until DB_CLEAR ----
  output logic [NUM_AGENTS-1:0]  db_irq_o
);

  localparam int unsigned AW_K = (NUM_AGENTS > 1) ? $clog2(NUM_AGENTS) : 1;
  localparam int unsigned QW   = $clog2(256 * NUM_AGENTS);   // queue memory, words
  localparam logic [31:0] WIN_STRIDE = 32'h2000;

  // FW_VAL/FW_MASK are TL_AIW bits wide; the register map gives them [7:0].
  if (top_pkg::TL_AIW != 8) begin : g_bad_aiw
    $error("soc4_mbx: TL_AIW = %0d, FW_VAL/FW_MASK are [7:0] (top_pkg.sv:10)", top_pkg::TL_AIW);
  end
  if (NUM_AGENTS < 1 || NUM_AGENTS > 16 || NUM_PORTS < 1 || NUM_PORTS > 16) begin : g_bad_count
    $error("soc4_mbx: NUM_AGENTS %0d, NUM_PORTS %0d: each must be 1..16 (FW_LAST[19:16], AGENT_PORT[k][3:0])",
           NUM_AGENTS, NUM_PORTS);
  end

  // The agents on port p, and the j-th of them (constant functions).
  function automatic int unsigned n_on(input int unsigned p);
    int unsigned n;
    n = 0;
    for (int unsigned k = 0; k < NUM_AGENTS; k++) if (AGENT_PORT[k] == p) n++;
    return n;
  endfunction

  function automatic int unsigned nth_on(input int unsigned p, input int unsigned j);
    int unsigned n, r;
    n = 0; r = 0;
    for (int unsigned k = 0; k < NUM_AGENTS; k++)
      if (AGENT_PORT[k] == p) begin
        if (n == j) r = k;
        n++;
      end
    return r;
  endfunction

  for (genvar k = 0; k < NUM_AGENTS; k++) begin : g_chk_agent
    if (AGENT_PORT[k] >= NUM_PORTS) begin : g_bad_port
      $error("soc4_mbx: agent %0d is bound to port %0d of %0d", k, AGENT_PORT[k], NUM_PORTS);
    end
  end

  // ===========================================================================
  // The SCP's registers: state
  // ===========================================================================
  localparam logic [11:0] R_DB_STATUS = 12'h000;
  localparam logic [11:0] R_DB_CLEAR  = 12'h004;
  localparam logic [11:0] R_INFO      = 12'h008;
  localparam logic [11:0] R_FW_LAST   = 12'h00C;
  localparam logic [11:0] R_AGENT     = 12'h100;   // + 0x20 * k
  localparam logic [4:0]  A_FW_EN     = 5'h00;
  localparam logic [4:0]  A_FW_VAL    = 5'h04;
  localparam logic [4:0]  A_FW_MASK   = 5'h08;
  localparam logic [4:0]  A_DENY_CNT  = 5'h0C;
  localparam logic [4:0]  A_RING_CNT  = 5'h10;

`ifdef SOC4_MUT_FW_OPEN
  // soc4neg M2: the firewall open at reset, source 0 admitted (SOC4_DESIGN.md 10.6).
  localparam logic       FwEnReset  = 1'b1;
`else
  localparam logic       FwEnReset  = 1'b0;
`endif

  logic [NUM_AGENTS-1:0] fw_en_q, ring_q;
  logic [7:0]            fw_val_q   [NUM_AGENTS];
  logic [7:0]            fw_mask_q  [NUM_AGENTS];
  logic [31:0]           deny_cnt_q [NUM_AGENTS];
  logic [31:0]           ring_cnt_q [NUM_AGENTS];
  logic [19:0]           fw_last_q;

  // The firewall entry of agent k (H12). soc4neg M5 ignores the mask.
  function automatic logic fw_ok(input int unsigned k, input logic [7:0] src);
`ifdef SOC4_MUT_FW_NOMASK
    return fw_en_q[k] && (src == fw_val_q[k]);
`else
    return fw_en_q[k] && ((src & fw_mask_q[k]) == fw_val_q[k]);
`endif
  endfunction

  function automatic logic in_qmem(input logic [31:0] a, input int unsigned k);
    logic [31:0] w;
    w = TL_BASE + 32'(k) * WIN_STRIDE;
    return a[31:10] == w[31:10];
  endfunction

  function automatic logic in_db(input logic [31:0] a, input int unsigned k);
    logic [31:0] w;
    w = TL_BASE + 32'(k) * WIN_STRIDE + 32'h1000;
    return a[31:12] == w[31:12];
  endfunction

  // Per port, as the port's firewall saw its accepted request
  logic                  port_deny     [NUM_PORTS];
  logic [AW_K-1:0]       port_deny_k   [NUM_PORTS];
  logic [7:0]            port_deny_src [NUM_PORTS];

  // Per agent: its two devices, as its port's socket presents them
  tlul_pkg::tl_h2d_t     ag_mem_h [NUM_AGENTS];
  tlul_pkg::tl_d2h_t     ag_mem_d [NUM_AGENTS];
  tlul_pkg::tl_h2d_t     ag_db_h  [NUM_AGENTS];
  tlul_pkg::tl_d2h_t     ag_db_d  [NUM_AGENTS];
  wire  [NUM_AGENTS-1:0] db_we_ok;

  // ===========================================================================
  // The ports: boundary adapter, firewall and decode, socket
  // ===========================================================================
  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_port
    localparam int unsigned NP  = n_on(p);
    localparam int unsigned ND  = 2 * NP;
    localparam int unsigned NWD = $clog2(ND + 1);

    if (NP == 0) begin : g_no_agent
      $error("soc4_mbx: port %0d carries no agent", p);
    end

    tlul_pkg::tl_h2d_t h;
    tlul_pkg::tl_d2h_t d;
    tlul_pkg::tl_h2d_t dh [ND];
    tlul_pkg::tl_d2h_t dd [ND];
    logic [NWD-1:0]    sel;
    logic              hit, ok;
    logic [AW_K-1:0]   hit_k;

    soc4_tl_bound #(.HAS_A_USER(PORT_HAS_A_USER[p])) u_bound (
      .clk_i (clk_i),
      .rst_ni(rst_ni),
      .tl_h_i(tl_h_i[p]),
      .tl_h_o(tl_h_o[p]),
      .tl_d_o(h),
      .tl_d_i(d)
    );

    // Firewall and decode -> dev_select_i: socket device 2j is the queue window
    // of the j-th agent on this port, 2j+1 its doorbell page; ND is the error
    // device (tlul_socket_1n.sv:35-38).
    always_comb begin
      sel   = NWD'(ND);
      hit   = 1'b0;
      ok    = 1'b0;
      hit_k = '0;
      for (int unsigned j = 0; j < NP; j++) begin
        automatic int unsigned k = nth_on(p, j);
        if (in_qmem(h.a_address, k) || in_db(h.a_address, k)) begin
          hit   = 1'b1;
          hit_k = AW_K'(k);
          ok    = fw_ok(k, h.a_source);
          if (ok) sel = NWD'(2 * j + (in_db(h.a_address, k) ? 1 : 0));
        end
      end
    end

    // Every other parameter default: pass-through FIFOs of depth 1, ExplicitErrs.
    tlul_socket_1n #(.N(ND)) u_sock (
      .clk_i       (clk_i),
      .rst_ni      (rst_ni),
      .tl_h_i      (h),
      .tl_h_o      (d),
      .tl_d_o      (dh),
      .tl_d_i      (dd),
      .dev_select_i(sel)
    );

    // A denial, where the socket's host side accepts it.
    assign port_deny[p]     = h.a_valid && d.a_ready && hit && !ok;
    assign port_deny_k[p]   = hit_k;
    assign port_deny_src[p] = h.a_source;

    for (genvar j = 0; j < NP; j++) begin : g_dev
      localparam int unsigned K = nth_on(p, j);
      assign ag_mem_h[K]   = dh[2 * j];
      assign dd[2 * j]     = ag_mem_d[K];
      assign ag_db_h[K]    = dh[2 * j + 1];
      assign dd[2 * j + 1] = ag_db_d[K];
    end
  end

  // ===========================================================================
  // The agents: a queue window and a doorbell each
  // ===========================================================================
  wire [NUM_AGENTS:0]          q_req, q_we;
  wire [NUM_AGENTS:0][QW-1:0]  q_addr;
  wire [NUM_AGENTS:0][31:0]    q_wdata;
  wire [NUM_AGENTS:0][3:0]     q_be;
  logic [NUM_AGENTS:0][31:0]   q_rdata;

  for (genvar k = 0; k < NUM_AGENTS; k++) begin : g_agent
    logic        req, we, rvalid_q;
    logic [7:0]  addr;
    logic [31:0] wdata, wmask;

    // The queue window: 1 KiB of the memory, tc_sram port 1 + k
    tlul_adapter_sram #(
      .SramAw          (8),
      .SramDw          (32),
      .SramDepth       (256),
      .Outstanding     (1),
      .ByteAccess      (1),
      .ErrOnWrite      (0),
      .ErrOnRead       (0),
      .CmdIntgCheck    (0),
      .EnableRspIntgGen(1),
      .EnableDataIntgGen(1),
      .EnableDataIntgPt(0),
      .SecFifoPtr      (0),
      .EnableReadback  (0),
      .DataXorAddr     (0)
    ) u_sram_ad (
      .clk_i                     (clk_i),
      .rst_ni                    (rst_ni),
      .tl_i                      (ag_mem_h[k]),
      .tl_o                      (ag_mem_d[k]),
      .en_ifetch_i               (prim_mubi_pkg::MuBi4False),
      .req_o                     (req),
      .req_type_o                (),
      .gnt_i                     (1'b1),
      .we_o                      (we),
      .addr_o                    (addr),
      .wdata_o                   (wdata),
      .wmask_o                   (wmask),
      .intg_error_o              (),
      .user_rsvd_o               (),
      .rdata_i                   (q_rdata[1 + k]),
      .rvalid_i                  (rvalid_q),
      .rerror_i                  (2'b00),
      .compound_txn_in_progress_o(),
      .readback_en_i             (prim_mubi_pkg::MuBi4False),
      .readback_error_o          (),
      .wr_collision_i            (1'b0),
      .write_pending_i           (1'b0)
    );

    assign q_req[1 + k]   = req;
    assign q_we[1 + k]    = we;
    assign q_addr[1 + k]  = QW'(k * 256) + QW'(addr);
    assign q_wdata[1 + k] = wdata;
    assign q_be[1 + k]    = {wmask[24], wmask[16], wmask[8], wmask[0]};

    // tlul_adapter_sram waits for rvalid only on reads: it pushes its SRAM
    // request FIFO for reads alone (sramreqfifo_wvalid = sram_ack & ~we_o).
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) rvalid_q <= 1'b0;
      else         rvalid_q <= req && !we;
    end

    // The doorbell: one write-only word behind a register adapter
    logic        db_re, db_we;
    logic [11:0] db_addr;

    tlul_adapter_reg #(
      .CmdIntgCheck    (0),
      .EnableRspIntgGen(1),
      .EnableDataIntgGen(1),
      .RegAw           (12),
      .RegDw           (32),
      .AccessLatency   (0)
    ) u_db_ad (
      .clk_i       (clk_i),
      .rst_ni      (rst_ni),
      .tl_i        (ag_db_h[k]),
      .tl_o        (ag_db_d[k]),
      .en_ifetch_i (prim_mubi_pkg::MuBi4False),
      .intg_error_o(),
      .re_o        (db_re),
      .we_o        (db_we),
      .addr_o      (db_addr),
      .wdata_o     (),
      .be_o        (),
      .busy_i      (1'b0),
      .rdata_i     (32'h0),
      .error_i     ((db_re | db_we) && (db_addr != 12'h000))
    );

    assign db_we_ok[k] = db_we && (db_addr == 12'h000);
  end

  // ===========================================================================
  // The memory: NUM_AGENTS KiB, port 0 the SCP's (BUS1), port 1 + k agent k's
  // ===========================================================================
  assign q_req[0]   = mem_req_i;
  assign q_we[0]    = mem_we_i;
  assign q_addr[0]  = mem_addr_i[QW+1:2];
  assign q_wdata[0] = mem_wdata_i;
  assign q_be[0]    = mem_be_i;

  tc_sram #(
    .NumWords (256 * NUM_AGENTS),
    .DataWidth(32),
    .ByteWidth(8),
    .NumPorts (1 + NUM_AGENTS),
    .Latency  (1),
    .SimInit  ("zeros")
  ) u_qmem (
    .clk_i  (clk_i),
    .rst_ni (rst_ni),
    .req_i  (q_req),
    .we_i   (q_we),
    .addr_i (q_addr),
    .wdata_i(q_wdata),
    .be_i   (q_be),
    .rdata_o(q_rdata)
  );

  // The SCP's port: tc_sram's Latency 1 is BUS1. The window is exactly
  // NUM_AGENTS KiB.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) mem_rvalid_o <= 1'b0;
    else         mem_rvalid_o <= mem_req_i;
  end
  assign mem_rdata_o = q_rdata[0];
  assign mem_err_o   = 1'b0;

  // ===========================================================================
  // The SCP's registers
  // ===========================================================================
  logic [11:0]           off, aoff;
  logic                  reg_wr, ag_sel;
  logic [AW_K-1:0]       ag_k;
  logic [4:0]            ag_r;
  logic [31:0]           bmask;
  logic [NUM_AGENTS-1:0] clr_bits, deny_ev;
  logic [31:0]           deny_base [NUM_AGENTS];
  logic [31:0]           ring_base [NUM_AGENTS];

  assign off    = {reg_addr_i[11:2], 2'b00};
  assign aoff   = off - R_AGENT;
  assign reg_wr = reg_req_i && reg_we_i;
  assign ag_sel = (off >= R_AGENT) && (32'(aoff[11:5]) < NUM_AGENTS);
  assign ag_k   = AW_K'(aoff[11:5]);
  assign ag_r   = aoff[4:0];
  assign bmask  = {{8{reg_be_i[3]}}, {8{reg_be_i[2]}}, {8{reg_be_i[1]}}, {8{reg_be_i[0]}}};
  assign clr_bits = (reg_wr && off == R_DB_CLEAR) ? NUM_AGENTS'(reg_wdata_i & bmask) : '0;

  // A denial of window k, on agent k's port; a write clears a counter, and an
  // event in the same cycle still counts.
  always_comb begin
    for (int unsigned k = 0; k < NUM_AGENTS; k++) begin
      deny_ev[k]   = port_deny[AGENT_PORT[k]] && (port_deny_k[AGENT_PORT[k]] == AW_K'(k));
      deny_base[k] = (reg_wr && ag_sel && ag_k == AW_K'(k) && ag_r == A_DENY_CNT) ? 32'd0 : deny_cnt_q[k];
      ring_base[k] = (reg_wr && ag_sel && ag_k == AW_K'(k) && ag_r == A_RING_CNT) ? 32'd0 : ring_cnt_q[k];
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      fw_en_q      <= {NUM_AGENTS{FwEnReset}};
      ring_q       <= '0;
      fw_last_q    <= '0;
      for (int unsigned k = 0; k < NUM_AGENTS; k++) begin
        fw_val_q[k]   <= '0;
        fw_mask_q[k]  <= 8'hFF;
        deny_cnt_q[k] <= '0;
        ring_cnt_q[k] <= '0;
      end
      reg_rvalid_o <= 1'b0;
      reg_rdata_o  <= '0;
      reg_err_o    <= 1'b0;
    end else begin
      // RING: set wins over clear
      ring_q <= (ring_q & ~clr_bits) | db_we_ok;
      for (int unsigned k = 0; k < NUM_AGENTS; k++) begin
        deny_cnt_q[k] <= (deny_ev[k] && deny_base[k] != '1) ? deny_base[k] + 32'd1 : deny_base[k];
        ring_cnt_q[k] <= (db_we_ok[k] && ring_base[k] != '1) ? ring_base[k] + 32'd1 : ring_base[k];
      end
      for (int unsigned p = 0; p < NUM_PORTS; p++)
        if (port_deny[p])
          fw_last_q <= {4'(port_deny_k[p]), 6'd0, !fw_en_q[port_deny_k[p]], 1'b1, port_deny_src[p]};

      reg_rvalid_o <= reg_req_i;
      reg_err_o    <= 1'b0;
      reg_rdata_o  <= '0;
      if (reg_req_i) begin
        if (ag_sel) begin
          unique case (ag_r)
            A_FW_EN: begin
              if (reg_we_i) begin
                if (reg_be_i[0]) fw_en_q[ag_k] <= reg_wdata_i[0];
              end else begin
                reg_rdata_o <= {31'd0, fw_en_q[ag_k]};
              end
            end
            A_FW_VAL: begin
              if (reg_we_i) begin
                if (reg_be_i[0]) fw_val_q[ag_k] <= reg_wdata_i[7:0];
              end else begin
                reg_rdata_o <= {24'd0, fw_val_q[ag_k]};
              end
            end
            A_FW_MASK: begin
              if (reg_we_i) begin
                if (reg_be_i[0]) fw_mask_q[ag_k] <= reg_wdata_i[7:0];
              end else begin
                reg_rdata_o <= {24'd0, fw_mask_q[ag_k]};
              end
            end
            A_DENY_CNT: if (!reg_we_i) reg_rdata_o <= deny_cnt_q[ag_k];
            A_RING_CNT: if (!reg_we_i) reg_rdata_o <= ring_cnt_q[ag_k];
            default:    reg_err_o <= 1'b1;
          endcase
        end else begin
          unique case (off)
            R_DB_STATUS: if (!reg_we_i) reg_rdata_o <= 32'(ring_q);
            R_DB_CLEAR:  ;                                   // write-only; reads 0
            R_INFO:      if (!reg_we_i) reg_rdata_o <= {16'd0, 8'(NUM_PORTS), 8'(NUM_AGENTS)};
            R_FW_LAST:   if (!reg_we_i) reg_rdata_o <= {12'd0, fw_last_q};
            default:     reg_err_o <= 1'b1;
          endcase
        end
      end
    end
  end

  assign db_irq_o = ring_q;

endmodule
