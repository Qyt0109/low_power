# soc4 — the 4-domain reference platform for the SCP power-control platform

soc4 is a reduced, complete test system for the SCP power-control platform: the
SCP (an Ibex in `scp_top`) with four PPUs driving four real power domains, an
always-on AP that talks RPMI to the SCP over TL-UL, and a second RPMI agent
(the RPU) played by the testbench. It is where the shared SCP firmware
(`src/pmu/fw`) and the platform hardware (`src/rtl/ppu`, `src/pmu/rtl`,
`src/rtl/ckrst`) are integrated and checked end to end, in plain RTL and under
the UPF power intent. SOVRA itself has 27 domains (architecture document §13);
soc4 keeps four so a full run stays short, and every change to the platform
must keep soc4 passing (§15.2).

| Domain (DOMAIN_ID = PPU index) | Instance | IP | Low-power mode RPMI OFF selects | RAM |
|---|---|---|---|---|
| 0 CPU0 | `u_cpu0` | Ibex (`scp_core`) | `FULL_RET`: the whole core retained, resumes where it stopped | 4 KB `tc_sram`, kept by `PPU_FULRR` bit 0 |
| 1 CPU1 | `u_cpu1` | Ibex (`scp_core`) | `OFF`: the next ON reloads and reboots it | 4 KB `tc_sram` |
| 2 ACC0 | `u_acc0` | `ppu_device_ip` (stand-in accelerator) | `MEM_RET`: logic off, RAM banks kept by `PPU_MEMRR` | 8 banks |
| 3 ACC1 | `u_acc1` | `ppu_device_ip` | `OFF` | 8 banks |

What makes it "reduced":

- **Static-only PPUs.** Every PPU is built with no dynamic modes, no lock, no
  direct `OFF → MEM_RET` hop and `PTCR` resetting to 0 (no device handshake
  between `ON` and `WARM_RST`). The modes are `OFF`, `ON`, `WARM_RST`, plus
  `FULL_RET` on CPU0 and `MEM_RET` on ACC0. Every domain comes out of reset
  in `OFF` and stays there until the SCP powers it.
- **Two agents.** Agent 0 is the AP (`soc4_ap`, a third Ibex running a
  bare-metal librpmi client), or the testbench's TL-UL BFM in its place.
  Agent 1 is the RPU, which soc4 does not have as a core: the testbench's
  second BFM drives its mailbox port.
- **One N-agent mailbox** (`soc4_mbx`): one TL-UL port per agent, a 1 KiB
  queue window, a doorbell and a source-ID firewall entry per agent.
- **One clock.** `clk_i` drives everything. Each domain's switched logic runs
  on its PPU's gated `dev_clk`.
- **Hand-written configuration.** Domains, agents and interrupt inputs are
  instantiated by hand in `soc4_top.sv` and listed by hand in
  `fw/soc4_plat.h`. Nothing is generated (decision of 2026-10-04).

## Contents

| Path | What | README |
|---|---|---|
| `rtl/` | `soc4_top` and its glue: CPU and accelerator domains, mailbox, control registers, AP | [rtl/README.md](rtl/README.md) |
| `fw/` | The only firmware build in the repository (`fw/Makefile`) and the platform table `soc4_plat.h` | [fw/README.md](fw/README.md) |
| `fw/scp/` | `soc4_scp`, the SCP's product firmware: boot, then the RPMI server | [fw/scp/README.md](fw/scp/README.md) |
| `fw/test/` | `soc4_stress` (DEN 0051E on the four PPUs) and `soc4_wdog` (the SCP watchdog) | [fw/test/README.md](fw/test/README.md) |
| `fw/ap/` | `soc4_ap`, the AP's RPMI agent program | [fw/ap/README.md](fw/ap/README.md) |
| `fw/cpu/` | The program CPU0 and CPU1 run (assembly), embedded in the SCP images | [fw/cpu/README.md](fw/cpu/README.md) |
| `fw/mod/` | The CPU image loader and cold-boot sequence | [fw/mod/README.md](fw/mod/README.md) |
| `fw/hal/` | `soc4_regs.h`: soc4's address maps and registers as the firmware sees them | [fw/hal/README.md](fw/hal/README.md) |

Elsewhere: the testbench is `src/tb/soc4/soc4_tb.sv` (with
`soc4_pa_supply_vcs.sv` for power-aware runs); the power intent is
`src/upf/soc4_top.upf`, loaded by `src/upf/soc4_tb_vcs.upf`.

## Block diagram

```
 soc4_top ─────────────────────────────────────────────────────────────────────────┐
 │ PD_TOP (always-on)                                                              │
 │                                                                                 │
 │  u_scp: scp_top (Ibex, 64 KB RAM, timer, scp_irq, scp_wdog), NUM_PPU = 4        │
 │    │ ext 0x0002_xxxx               │ AXI4-Lite m_axi[0..3]        ▲ irq_i[15:0]  │
 │    ▼                               │                              │              │
 │  u_ext: bus.sv, 6 devices          │      PPU IRQs 0-3, doorbells 4 and 14,      │
 │    0 sim_* ──► testbench           │      PLIC 5-7, wake lines 8-13,             │
 │    1 u_ctrl (soc4_ctrl)            │      clock/reset bridge fault 15            │
 │    2 u_mbx SCP registers           │                                             │
 │    3 u_mbx queue memory            │                                             │
 │    4 u_cpu0 RAM load port ─────┐   │                                             │
 │    5 u_cpu1 RAM load port ───┐ │   │                                             │
 │                              │ │   │                                             │
 │  u_ap: soc4_ap ──TL-UL──┐    │ │   │                                             │
 │  tl_bfm_i (TB BFM) ─────┴─ bfm_sel_i ─► u_mbx port 0 (agent 0, AP)               │
 │  tl_rpu_i (TB 2nd BFM) ──────────────► u_mbx port 1 (agent 1, RPU)               │
 └──────────────────────────────┼─┼───┼─────────────────────────────────────────────┘
                                │ │   ▼
   ┌ u_cpu0 / u_cpu1: soc4_cpu_dom ──────────┐  ┌ u_acc0 / u_acc1: soc4_acc_dom ─────┐
   │ PD_AON_n: u_dom (PPU, PCSM), u_ram      │  │ PD_AON_n: u_dom (PPU, PCSM),       │
   │   (4 KB tc_sram), u_adp, u_ckrst        │  │   u_ip RAM banks, u_ckrst          │
   │ PD_DEV_n (switched): u_core (Ibex),     │  │ PD_DEV_n (switched): u_ip/u_core,  │
   │   the PPU's u_clkctrl                   │  │   u_ip/u_ret, the PPU's u_clkctrl  │
   └─────────────────────────────────────────┘  └────────────────────────────────────┘
        tile_clk_* / tile_rst_* (each domain's clock/reset bridge) ──► testbench model
```

Everything outside the four domains' switched logic is always-on: the AP must
reach the mailbox while every domain is off, and the PPUs sit with the SCP in
the always-on domain (PCSA, ARM DEN 0050D §7.2.3). `rtl/README.md` has the
per-instance split.

Resets: `rst_ni` resets everything. `scp_rst_ni` additionally holds the SCP
subsystem alone in reset. A watchdog reset also resets the SCP subsystem
alone (and the ext window's `bus.sv`); the domains, PPUs, `soc4_ctrl`, the
mailbox and the AP keep running, which is what lets the rebooted firmware
take over.

## Address maps

### The SCP's map

From `src/pmu/fw/hal/scp_regs.h`, `src/pmu/rtl/scp_top.sv` and the ext
decode in `rtl/soc4_top.sv` (`fw/hal/soc4_regs.h` names the ext devices).

| Base | Size | What | Firmware name |
|---|---|---|---|
| `0x0000_0000` | 64 KB | SCP RAM: code, data, stack (persistent block in the top 1 KB) | `SCP_RAM_BASE` |
| `0x0001_0000` | 1 KB | timer (`mtime`/`mtimecmp`) | `SCP_TIMER_BASE` |
| `0x0001_1000` | 4 KB | interrupt status/enable block (`scp_irq`) | `SCP_IRQ_BASE` |
| `0x0001_2000` | 4 KB | watchdog (`scp_wdog`) | `SCP_WDOG_BASE` |
| `0x0002_0000` | 4 KB | ext dev 0: testbench sim control, TAG `fw` (`hal/sim.h`) | `SCP_SIM_BASE`, `SOC4_SIM_BASE` |
| `0x0002_1000` | 4 KB | ext dev 1: `soc4_ctrl` | `SOC4_CTRL_BASE` |
| `0x0002_2000` | 4 KB | ext dev 2: mailbox SCP registers | `SOC4_MBX_BASE` |
| `0x0002_4000` | 2 KiB | ext dev 3: mailbox queue memory, agent k's window at `+ k * 0x400` | `SOC4_QMEM_BASE`, `SOC4_QMEM_WIN(k)` |
| `0x0002_8000` | 4 KB | ext dev 4: CPU0 RAM load port | `SOC4_LD_BASE(0)` |
| `0x0002_9000` | 4 KB | ext dev 5: CPU1 RAM load port | `SOC4_LD_BASE(1)` |
| `0x4000_0000 + n * 0x1000` | 4 KB each | PPU n over AXI4-Lite, n = 0..3 (16 slots decoded; slots 4..15 answer DECERR) | `SCP_PPU_ADDR(n)` |

Inside the ext window (`0x0002_0000`–`0x0002_FFFF`) an address no device
matches is a decode error, which the SCP takes as an access fault.

### The AP's map

From `rtl/soc4_ap.sv` and `fw/hal/soc4_regs.h`.

| Base | Size | What |
|---|---|---|
| `0x0000_0000` | 64 KB | AP RAM (`scp_ram`, loaded from `+ap_firmware=<file.vmem>`) |
| `0x0001_0000` | 1 KB | timer (Ibex's; its interrupt is not used) |
| `0x0002_0000` | 4 KB | testbench sim control, TAG `ap`, same offsets as the SCP's (`SOC4_AP_SIM_BASE`) |
| `0x2000_0000` | 16 KB | TL-UL to the mailbox (port 0): window 0 at `0x2000_0000` (`SOC4_AP_QMEM`), doorbell 0 at `0x2000_1000` (`SOC4_AP_DOORBELL`) |

### The agents' TL-UL view

| Agent | Port | Queue window | Doorbell | `a_source` value / mask |
|---|---|---|---|---|
| 0 AP | 0 | `0x2000_0000`–`0x2000_03FF` | `0x2000_1000` | `0x10` / `0xFF` |
| 1 RPU | 1 | `0x2000_2000`–`0x2000_23FF` | `0x2000_3000` | `0x20` / `0xFC` (IDs `0x20`–`0x23`) |

Any other address on a port, another agent's window included, is answered
`d_error`. The SCP's mailbox registers have no TL-UL path. Every window is
denied from reset until the SCP firmware programs the firewall.

### Each CPU's own map

CPU0 and CPU1 see only their 4 KB RAM at `0x0000_0000`: vectors at 0, reset
at `0x80`, data words from `0xC00` (layout in
[fw/cpu/README.md](fw/cpu/README.md)). Anything above `0x0FFF` is a bus error.

## Make targets

All are in `src/Makefile`. Every simulation target needs `SIM=vcs` (the
power intent is written for VCS native low power), and every one but
`soc4elab` depends on `soc4fw`. Each run rebuilds the testbench, so a mutant build left by
`soc4neg` is never reused. Logs go to `build/vcs/soc4_tb/<run>.log`
(power-aware: `build/vcs_pa/soc4_tb/`).

| Target | What it runs | SCP image | Agent 0 |
|---|---|---|---|
| `make soc4fw` | Builds every soc4 firmware image into `build/fw/soc4` and prints their sizes. No simulator needed | — | — |
| `make soc4elab SIM=vcs` | Elaborates `soc4_top` alone (no testbench), runs time 0 (the PPUs' configuration checks, `tc_sram`), fails on any VCS error and lists warnings by kind | — | — |
| `make soc4 SIM=vcs` | The product path: the AP program is the RPMI agent; the testbench checks PPU and IP state at each AP checkpoint | `soc4_scp` | `soc4_ap` |
| `make soc4bfm SIM=vcs` | `soc4_scp` against the testbench's TL-UL BFM, SCP held in reset for 3000 cycles: firewall, discovery, ON/OFF, cancel, deny/force, deadline faults and recovery, bad IDs, unregistered group (B0–B11); every interrupt input (B12); the RPU on port 1 (R0, R1); a hung SCP reset by its watchdog and taking over (W1) | `soc4_scp` | BFM |
| `make soc4stress SIM=vcs` | `soc4_stress`: the SCP firmware against DEN 0051E on the four PPUs, AP held, one `RESULT` line per feature; any FAIL fails the target | `soc4_stress` | none |
| `make soc4wdog SIM=vcs` | `soc4_wdog`: the watchdog's registers, kick, lock, wrong kick, expiry, CAUSE and the kept block; the testbench expects exactly two watchdog resets (`+wdog_resets=2`) | `soc4_wdog` | none |
| `make soc4ckrst SIM=vcs` | `soc4_scp` against the BFM, step K1 only: ACC1's DCDR fields from the domain table, a late clock acknowledgement flagged, logged, FAULTed and recovered | `soc4_scp` | BFM |
| `make soc4neg SIM=vcs` | The nine negative controls (M1–M9): each rebuilds with one planted mutant and must fail at its own check | various, `soc4_scp_m6` for M6 | AP or BFM |
| `make soc4pa SIM=vcs` | `soc4` under the UPF power intent (VCS native low power) | `soc4_scp` | `soc4_ap` |
| `make soc4bfmpa SIM=vcs` | `soc4bfm` under the power intent | `soc4_scp` | BFM |
| `make soc4stresspa SIM=vcs` | `soc4stress` under the power intent | `soc4_stress` | none |

The three `*pa` targets also fail unless VCS's low-power checker reports
`ERROR = 0, FATAL = 0`, each `SW_LOGIC_n` switched its supply off at least
once, and the report says the power intent was applied. Under `SOC4_PA` the
testbench additionally checks the supply nets at every checkpoint.

PCSM switch settling is ideal (0) unless given, for all four domains:

```
make soc4pa SIM=vcs PCSM_RET_SETTLE=30 PCSM_LOGIC_SETTLE=20
```

The `soc4neg` mutants (defines in soc4 glue unless noted):

| # | Define | What it breaks | Run | Must fail with |
|---|---|---|---|---|
| M1 | `SOC4_MUT_CPU0_NRET` | CPU0's core on `dev_nret_rst_n`, which `FULL_RET` asserts | `soc4` | `[chk:FULLRET_REGS]` |
| M2 | `SOC4_MUT_FW_OPEN` | mailbox `FW_EN` resets to 1 | `soc4bfm` B0 | `[chk:FW_RESET_DENY]` |
| M3 | `SOC4_MUT_ACC0_NORET` | ACC0's retention acts as shutdown | `soc4` | `[chk:MEMRET_RAM]` |
| M4 | `SOC4_MUT_IRQ_SYNC0` | `scp_irq`'s synchroniser output | `soc4bfm` B12 | `[chk:WAKE_PLIC]` |
| M5 | `SOC4_MUT_FW_NOMASK` | the firewall ignores `FW_MASK` | `soc4bfm` R1 | `[chk:FW_MASK]` |
| M6 | `SCP_MUT_PERM_OPEN` (firmware) | `soc4_scp_m6` skips the per-domain permission check | `soc4bfm` R1 | `[chk:PERM]` |
| M7 | `SOC4_MUT_WDOG_PPU` | the watchdog reset also reaches the four domains | `soc4bfm` W1 | `[chk:WDOG_KEEP]` |
| M8 | `SOC4_MUT_WDOG_CAUSE_SUB` | the watchdog's CAUSE on the subsystem reset | `soc4bfm` W1 | `[chk:WDOG_CAUSE]` |
| M9 | `SOC4_MUT_CKRST_IRQ` | bridge faults never reach the SCP | `soc4ckrst` K1 | `[chk:CKRST_LOG]` |

## Extending soc4

Adding or removing a domain, an agent or an interrupt input is a by-hand
edit in a small, fixed set of places (architecture document §15.3). The
hardware side is described in [rtl/README.md](rtl/README.md#extending-the-platform),
the firmware side in [fw/README.md](fw/README.md#how-to-add-or-remove-a-domain-an-agent-or-an-interrupt-input).
The instance names `u_cpu0`, `u_cpu1`, `u_acc0`, `u_acc1` are a contract
with the power intent and the testbench: renaming one means editing both.

## References

- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §13 (SoC power modes and the
  domain partition), §14 (platform checklist: PD5–PD10, H7–H21, F5–F14,
  V3–V7), §15 (status, phase plan, and §15.3 adding a domain or an agent).
- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../docs/PMU_SOFTWARE_CONTRACT.md): what
  agent software sees — windows, doorbells, source IDs, DOMAIN_IDs,
  permissions, RPMI services, timing.
- [`src/pmu/README.md`](../pmu/README.md): the SCP and its shared firmware.
- [`src/pmu/PPU_FW_CONFORMANCE.md`](../pmu/PPU_FW_CONFORMANCE.md): the
  `soc4stress` result, row by row.
- [`src/upf/README.md`](../upf/README.md): the power intent files.
- Background only: [`docs/SOC4_DESIGN.md`](../../docs/SOC4_DESIGN.md), the soc4 design document
  that the RTL and firmware comments cite by section number. It was written
  before phases 1–6; its header note says where the current state is
  described.
