/* soc4 platform settings: force-included (-include) into every SCP-side
 * compile of src/soc4/fw/Makefile.
 *
 * docs/SOC4_DESIGN.md Sections 6.5 and 9.1, and the platform plan's
 * F5 (Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Sections 14.7 and 15.3). The
 * shared firmware under src/pmu/fw takes its platform from these macros and
 * has no defaults of its own:
 *
 *   SCP_NUM_PPU       pmu/fw/hal/scp_regs.h  PPU slots the firmware drives:
 *                                            one per domain of the table
 *   SCP_PLAT_DOMAINS  pmu/fw/mod/pd.h        THE DOMAIN TABLE: every setting
 *                                            the firmware keeps per domain
 *   SCP_PLAT_INPUTS   pmu/fw/hal/scp_irq.h   THE INPUT TABLE: what each input
 *                                            of the SCP's interrupt block is
 *   SCP_PLAT_AGENTS   pmu/fw/mod/agents.h    THE AGENT TABLE: the RPMI agents,
 *                     pmu/fw/rpmi/scp_rpmi.h one transport each
 *   SCP_PLAT_WDOG_TIMEOUT  pmu/fw/rpmi/scp_loop.h  the watchdog's timeout
 *   SCP_PLAT_CKRST_STAT    pmu/fw/mod/policy.c  the clock/reset bridges'
 *                                            status register holding domain d
 *
 * Written by hand, with no generator (the decision of 2026-10-04): adding or
 * removing a domain is one D(...) entry here, its PPU's I(...) entry, and
 * SCP_NUM_PPU, beside the hardware edits of SOVRA_PCSA_ARCHITECTURE.md
 * Section 15.3. Adding an interrupt or wake input is one I(...) entry here and
 * one wire in soc4_top's irq_in. Adding an agent is one A(...) entry here,
 * its doorbell's I(...) entry, and its bit in the .agents of each domain it
 * may vote for, beside soc4_top's mailbox parameters and port wiring
 * (soc4_mbx.sv, ADDING OR REMOVING AN AGENT).
 */
#ifndef SOC4_PLAT_H
#define SOC4_PLAT_H

#define SCP_NUM_PPU     4u

/* The SCP watchdog's timeout, in SCP clock cycles (platform plan H18;
 * hal/scp_wdog.h): 2^21, about 21 ms at 100 MHz. The loop sleeps at most an
 * eighth of it (2.6 ms), and scp/main.c checks at compile time that the rest
 * covers the longest pass of the main loop: (2 agents x 5 requests + 5
 * POWER_UP inputs + 1) power-ups of at most 1 ms = 16 ms <= 18.4 ms. */
#define SCP_PLAT_WDOG_TIMEOUT  0x00200000u

/* THE DOMAIN TABLE. One D(name, latency, fields) per domain, in DOMAIN_ID
 * order: DOMAIN_ID = PPU index n = SCP interrupt input n (SOC4_DESIGN.md
 * Section 3.1; the input table below). mod/pd.h (struct pd_cfg) says what each field is; here, why
 * each value:
 *
 *   .lp      where RPMI OFF takes the domain (DEN 0051E Table 3-2;
 *            SOC4_DESIGN.md 9.4): CPU0 FULL_RET, the whole core retained;
 *            ACC0 MEM_RET, the banks retained; CPU1 and ACC1 OFF
 *   .fulrr, .memrr  every bank retained: ppu_pcsm reads the byte as one retain
 *            enable per SRAM bank (REGISTERS.md 4.5). CPU0's PPU has PPU_FULRR
 *            alone, ACC0's PPU_MEMRR alone, the other two none (Section 3.3)
 *   .idr0, .idr1  what scp/main.c requires each PPU to report (Section 3.3).
 *            PPU_IDR0 (Table 5-26): STA_OFF_SPT b8, STA_MEM_RET_SPT b10,
 *            STA_FULL_RET_SPT b14, STA_ON_SPT b16, STA_WRM_RST_SPT b17, no
 *            dynamic bit [29:20], DEVCHAN [3:0] = 1 Q-Channel. PPU_IDR1
 *            (Table 5-27): FULL_RET_RAM_REG b5, MEM_RET_RAM_REG b4,
 *            SW_DEV_DEL_SPT b1, PWR_MODE_ENTRY_DEL_SPT b0; no LOCK_SPT b2, no
 *            OFF_MEM_RET_TRANS b12
 *   .cpu     a CPU's boot details: SOC4_CPU_BOOT_DETAILS, below
 *   .agents  the agents that may vote for the domain (platform plan F6): the
 *            AP for all four, the RPU for the two accelerators only. Another
 *            agent's request for the domain is refused with RPMI_ERR_DENIED
 *            (rpmi/scp_rpmi.h). The first agent listed, the AP, owns each
 *            domain's wake vote
 *   .ckrst_lat  the SoC clkgate / tilereset's worst-case acknowledgement
 *            latency, in PPU cycles (platform plan H16, F11; mod/pd.h): the
 *            testbench's model of them (tb/ckrst/soc_ckrst_model.sv) answers
 *            in 2 cycles for CPU0, CPU1 and ACC0, which the build's delays
 *            already cover (CLKEN_RST_DLY 4, CLKEN_ISO_DLY 2, RST_HWSTAT_DLY
 *            2), and in 6 for ACC1, whose PPU pd_init programs with
 *            CLKEN_RST_DLY, CLKEN_ISO_DLY and RST_HWSTAT_DLY = 6
 *   latency  DEVICE_POWER's trans_latency: 0, nothing measured yet
 */
#define SCP_PLAT_DOMAINS(D)                                                     \
  D("CPU0", 0, .kind = PD_KIND_CPU, .lp = PPU_MODE_FULL_RET, .fulrr = 0xFFu,    \
    .idr0 = 0x00034101u, .idr1 = 0x23u, .cpu = SOC4_CPU_BOOT_DETAILS(0),        \
    .agents = SCP_AG(AP), .ckrst_lat = 2)                                       \
  D("CPU1", 0, .kind = PD_KIND_CPU, .lp = PPU_MODE_OFF,                         \
    .idr0 = 0x00030101u, .idr1 = 0x03u, .cpu = SOC4_CPU_BOOT_DETAILS(1),        \
    .agents = SCP_AG(AP), .ckrst_lat = 2)                                       \
  D("ACC0", 0, .kind = PD_KIND_DEV, .lp = PPU_MODE_MEM_RET, .memrr = 0xFFu,     \
    .idr0 = 0x00030501u, .idr1 = 0x13u, .agents = SCP_AG(AP) | SCP_AG(RPU),     \
    .ckrst_lat = 2)                                                             \
  D("ACC1", 0, .kind = PD_KIND_DEV, .lp = PPU_MODE_OFF,                         \
    .idr0 = 0x00030101u, .idr1 = 0x03u, .agents = SCP_AG(AP) | SCP_AG(RPU),     \
    .ckrst_lat = 6)

/* THE INPUT TABLE (platform plan H7-H9, F10). One I(id, name, mode, en, act,
 * arg) per input of the SCP's interrupt block (scp_irq.sv), in input order:
 * input i is soc4_top's irq_in[i], and soc4_top's header has the same list.
 * hal/scp_irq.h says what each field is and how each action runs; mod/policy.h
 * (WAKE INPUTS) what a power-up from an input means for the votes.
 *
 *   PPU0-3   level: a PPU's IRQ is HIGH while any PPU_ISR/PPU_AISR bit is set
 *            (REGISTERS.md 4.4); serviced by pd_poll
 *   DB       level: the AP's doorbell, the mailbox's RING[0], sticky until
 *            DB_CLEAR (soc4_mbx.sv)
 *   PLIC     level: the SoC PLIC's output to the SCP. Its meaning is the
 *            SoC's; the policy is told (PD9: the SCP keeps no SoC modes)
 *   PLIC_H0/1  level: the PLIC's pending for hart n, which stays HIGH until
 *            the hart claims it -- so it can only be taken once the hart's
 *            domain is up: power up CPUn (PD5: an SCP static request)
 *   RTC, BBRX  edge: wake events with nothing to power in soc4; recorded as
 *            wake reasons 1 and 2
 *   GPIO     edge: a wake line for ACC0
 *   DBG      level: the debug power-up request. soc4 has no debug domain, so
 *            it is ignored (taken, counted, re-armed when LOW)
 *   ACG0     edge: an access gate's stall-and-wake request (PD5, H15): power up
 *            the gated domain, ACC1
 *   ACG1     edge: a second gate's request, not fitted in soc4: masked for good
 *            (en = 0), with the action it would have
 *   DB1      level: the RPU's doorbell, RING[1]. Last, so that the inputs before
 *            it keep their phase-2 numbers
 *   CKRST    level: a clock/reset bridge fault, any domain (soc4_top's
 *            ckrst_irq; platform plan H16, F11). The policy reads
 *            SCP_PLAT_CKRST_STAT, logs and FAULTs each flagged domain
 *            (mod/policy.h, CLOCK/RESET BRIDGE FAULTS); en = 1, opened by
 *            policy_init()
 *
 * en = 0 on the PPU and doorbell inputs too: their owners open them
 * (pd_init, rpmi_db_set_mask).
 */
#define SCP_PLAT_INPUTS(I)                                                      \
  I(PPU0,    "PPU0",    SCP_IN_LEVEL, 0, SCP_ACT_PPU,      0)                   \
  I(PPU1,    "PPU1",    SCP_IN_LEVEL, 0, SCP_ACT_PPU,      1)                   \
  I(PPU2,    "PPU2",    SCP_IN_LEVEL, 0, SCP_ACT_PPU,      2)                   \
  I(PPU3,    "PPU3",    SCP_IN_LEVEL, 0, SCP_ACT_PPU,      3)                   \
  I(DB,      "DB",      SCP_IN_LEVEL, 0, SCP_ACT_DOORBELL, 0)                   \
  I(PLIC,    "PLIC",    SCP_IN_LEVEL, 1, SCP_ACT_NOTIFY,   0)                   \
  I(PLIC_H0, "PLIC_H0", SCP_IN_LEVEL, 1, SCP_ACT_POWER_UP, 0)                   \
  I(PLIC_H1, "PLIC_H1", SCP_IN_LEVEL, 1, SCP_ACT_POWER_UP, 1)                   \
  I(RTC,     "RTC",     SCP_IN_EDGE,  1, SCP_ACT_REASON,   1)                   \
  I(GPIO,    "GPIO",    SCP_IN_EDGE,  1, SCP_ACT_POWER_UP, 2)                   \
  I(BBRX,    "BBRX",    SCP_IN_EDGE,  1, SCP_ACT_REASON,   2)                   \
  I(DBG,     "DBG",     SCP_IN_LEVEL, 1, SCP_ACT_IGNORE,   0)                   \
  I(ACG0,    "ACG0",    SCP_IN_EDGE,  1, SCP_ACT_POWER_UP, 3)                   \
  I(ACG1,    "ACG1",    SCP_IN_EDGE,  0, SCP_ACT_POWER_UP, 1)                   \
  I(DB1,     "DB1",     SCP_IN_LEVEL, 0, SCP_ACT_DOORBELL, 1)                   \
  I(CKRST,   "CKRST",   SCP_IN_LEVEL, 1, SCP_ACT_CKRST,    0)

/* The clock/reset bridges' status (soc4_ctrl CKRST_STAT): domain d's byte is
 * byte (d % 4) of the word at this address, W1C (mod/policy.c). */
#define SCP_PLAT_CKRST_STAT(d)  (SOC4_CTRL_CKRST + ((d) / 4u) * 4u)

/* THE AGENT TABLE (platform plan PD6, H11-H13, F6). One A(id, name, window,
 * db_in, src, mask, groups) per RPMI agent, in transport order: agent k =
 * transport k = the mailbox's window k, doorbell RING[k] and firewall entry k
 * (soc4_mbx.sv), on its own mailbox port (soc4_top.sv). mod/agents.h says
 * what each field is.
 *
 *   AP   the VtCPU cluster's stand-in: soc4's AP (or the testbench's BFM) on
 *        port 0, its one source ID 0x10 (soc4_ap's glue)
 *   RPU  the real-time processing unit's stand-in: the testbench's second BFM
 *        on port 1 (soc4 has no RPU core), the source IDs 0x20-0x23
 *
 * Both get BASE and DEVICE_POWER, over an M-mode context each. What each may
 * vote for is the domain table's .agents.
 */
#define SCP_PLAT_AGENTS(A)                                                      \
  A(AP,  "AP",  SOC4_QMEM_WIN(0), SCP_IN_DB,  SOC4_AP_SOURCE,  SOC4_AP_SRC_MASK,  \
    SCP_GRP_DPWR)                                                               \
  A(RPU, "RPU", SOC4_QMEM_WIN(1), SCP_IN_DB1, SOC4_RPU_SOURCE, SOC4_RPU_SRC_MASK, \
    SCP_GRP_DPWR)

/* CPU n's boot details (SOC4_DESIGN.md 4.4 and 9.5; hal/soc4_regs.h). Both
 * cores run the one image, cpu/cpu.S, embedded by cpu/cpu_img.S. The SCP loads
 * it into CPU n's RAM through the load port, which is open while
 * CPU_STAT.ld_open[n]; then it writes CPUn_BOOT and sets FETCH_EN[n]. */
#define SOC4_CPU_BOOT_DETAILS(n) (&(const struct pd_cpu){                       \
    .image     = cpu_img,               .words      = SOC4_CPU_WORDS,           \
    .load      = SOC4_LD_BASE(n),                                               \
    .open_reg  = SOC4_CTRL_CPU_STAT,    .open_mask  = SOC4_CPU_STAT_LDOPEN(n),  \
    .boot_reg  = SOC4_CTRL_CPU_BOOT(n), .boot_addr  = SOC4_CPU_BOOT,            \
    .fetch_reg = SOC4_CTRL_FETCH_EN,    .fetch_mask = 1u << (n) })

/* What the entries name. The assembler sources are compiled with this header
   too, and need none of it. */
#ifndef __ASSEMBLER__
#include <stdint.h>
#include "soc4_regs.h"
extern const uint32_t cpu_img[SOC4_CPU_WORDS];   /* cpu/cpu_img.S */
#endif

#endif
