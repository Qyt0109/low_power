/* soc4_stress -- the SCP firmware against the Arm PPU architecture (ARM DEN
 * 0051E) on soc4's four static-only PPUs (make soc4stress).
 *
 * docs/SOC4_DESIGN.md Section 11.3. It replaced ppu_stress, the
 * 12-domain stress test retired with pmu_top on 2026-10-02, and keeps its check
 * IDs, which are the rows of src/pmu/PPU_FW_CONFORMANCE.md Section 3, plus
 * five soc4-only rows (S.*). One line per feature:
 *
 *   RESULT <id> <PASS|FAIL|DEVIATION> checks <n> fails <n> cycles <n>
 *
 * DEVIATION: the behaviour is not what the spec or the driver's contract says,
 * and is exactly what a recorded finding predicts. It does not fail the run.
 * None is expected: S.DYNREQ was one until the driver fix of 2026-10-05
 * (Section 15.2-21; platform plan F1).
 *
 * THE DOMAINS (Section 3). DOMAIN_ID = PPU index:
 *
 *   0 CPU0  OFF FULL_RET ON WARM_RST   PPU_FULRR          an Ibex
 *   1 CPU1  OFF ON WARM_RST                               an Ibex
 *   2 ACC0  OFF MEM_RET ON WARM_RST    PPU_MEMRR          ppu_device_ip
 *   3 ACC1  OFF ON WARM_RST                               ppu_device_ip
 *
 * No dynamic modes, no lock, no OFF -> MEM_RET direct hop, PTCR resetting to 0
 * (no device handshake between ON and WARM_RST, Table 4-4). Features that need
 * what these PPUs are built without are left to the PPU unit testbenches
 * (Section 11.3, "N/A on soc4").
 *
 * THREE VIEWS: the registers (hal/ppu_v1, raw), the pins
 * (the testbench's observation window, hal/sim.h OBS_*, for domains 0-3), and
 * the spec tables, which soc4_tb checks at every hop and at every CHECK on
 * this SCP's sim control (Section 10.3). A feature also fails if the testbench
 * recorded any error while it ran.
 *
 * THE DOMAINS' SOFTWARE. The program plays it:
 *   ACC k (domain 2 + k)  WAKE, START, LIGHT, WORK_LEN, IP_CMD and IP_SEED on
 *                         this SCP's sim control, bit/field of domain 2 + k
 *   hold_busy[n]          testbench command 'H' on AP_CMD (SOC4_TB_HOLD): the
 *                         domain's adapter reports busy and never answers a
 *                         quiescence request; on a CPU it also suppresses the
 *                         deny (soc4_cpu_adp.sv)
 *   ACC deny              testbench command 'D' (SOC4_TB_DENY), bit k
 *   CPU0, CPU1            the real cores, running cpu/cpu.S once loaded
 * The testbench applies a command and echoes the word on AP_STAT.
 *
 * THE CPU DOMAINS' BASELINE. A CPU whose fetch is off, or whose program never
 * sleeps (CPU1), is awake, and its adapter denies every quiescence request
 * (decision 7). And a CPU must never fetch from a RAM that OFF has lost
 * (Ibex asserts its fetched data known). So between features a CPU domain has
 * FETCH_EN = 0 and PPU_PWCR.DEVREQEN = 0: its transitions are sequenced with
 * no device handshake (PPU 4.1.3). The features that need the handshake
 * (S.CPUQ, EDT.STATIC, PCSM.RAM, S.CPUBOOT) load the image, run it, and set
 * DEVREQEN = 1 in ON, as the driver's rule allows (README Section 6 rule 6).
 *
 * OBS_RAM (index 23): the testbench reads the always-on arrays. [7:0] bank b intact: every word as written (an ACC: the
 * ip_pattern of the seed of its last fill; a CPU, bank 0: every word of
 * 0x000-0xBFF as the load port last wrote it); [15:8] bank b lost (every word
 * X); [16] valid.
 *
 * THE PPU LINES. Each PPU's interrupt is one input of the SCP's interrupt
 * block (scp_irq.sv; the input table in soc4_plat.h): PPU n is input n, on the
 * SCP's clock with no synchroniser, and the block drives the core's machine
 * external interrupt, line 11. The PPU inputs stay masked in the block
 * (ENABLE) except where the interrupt path is under test; their level is read
 * from the block's RAW register.
 */
#include <stdarg.h>
#include <stdint.h>
#include "console.h"
#include "csr.h"
#include "timer.h"
#include "trap.h"
#include "sim.h"
#include "lib.h"
#include "ppu_v1.h"
#include "pd.h"
#include "soc4_regs.h"
#include "soc4_cpu.h"
#include "scp_irq.h"

#define ND    4u
#define ALLD  0xFu
#define TMO   30000u
#define DYN   PPU_PWPR_DYN_EN
#define LCK   PPU_PWPR_LOCK_EN

enum { M_OFF = PPU_MODE_OFF, M_MRET = PPU_MODE_MEM_RET, M_FULL = PPU_MODE_FULL_RET,
       M_ON = PPU_MODE_ON, M_WARM = PPU_MODE_WARM_RST };
enum { CPU0 = SOC4_CPU0, CPU1 = SOC4_CPU1, ACC0 = SOC4_ACC0, ACC1 = SOC4_ACC1 };

/* Each domain's static modes (Section 3.1), and its low-power one. */
static const uint8_t NM[ND]      = { 4, 3, 4, 3 };
static const uint8_t MS[ND][4]   = { { M_OFF, M_FULL, M_ON, M_WARM }, { M_OFF, M_ON, M_WARM, 0 },
                                     { M_OFF, M_MRET, M_ON, M_WARM }, { M_OFF, M_ON, M_WARM, 0 } };
static const uint16_t STA[ND]    = { 0x0321, 0x0301, 0x0305, 0x0301 };   /* bit m: mode m */
static const uint8_t LP[ND]      = { M_FULL, M_OFF, M_MRET, M_OFF };
static bool is_cpu(unsigned d)   { return d < 2u; }

/* ===========================================================================
 * Results
 * ========================================================================= */
static const char *cur = "setup";
static unsigned f_chk, f_fail, f_dev;
static unsigned n_pass, n_fail, n_dev, sum_chk;

/* One out-of-line failure path: the image is RAM, and a check is a few
   hundred call sites. */
static void __attribute__((noinline)) ck_fail(int line, const char *fmt, ...)
{
  f_fail++;
  if (f_fail > 5) return;
  va_list ap;
  va_start(ap, fmt);
  con_printf("  FAIL %s@%d: ", cur, line);
  con_vprintf(fmt, ap);
  con_putc('\n');
  va_end(ap);
}
#define CK(c, ...) do { f_chk++; if (!(c)) ck_fail(__LINE__, __VA_ARGS__); } while (0)

#define CKD(ok, known, ...) do { f_chk++; if (!(ok)) {                           \
      if (known) { f_dev++; con_printf("  DEVIATION %s@%d: ", cur, __LINE__); }   \
      else       { f_fail++; con_printf("  FAIL %s@%d: ", cur, __LINE__); }       \
      con_printf(__VA_ARGS__); con_putc('\n'); } } while (0)

static void feature(const char *id, void (*fn)(void))
{
  cur = id;
  f_chk = f_fail = f_dev = 0;
  uint32_t e0 = sim_tb_errors(), c0 = sim_cycle();
  fn();
  uint32_t e = sim_tb_errors() - e0;
  CK(e == 0, "the testbench recorded %u error(s) or violation(s) during this feature", e);
  const char *st = f_fail ? "FAIL" : f_dev ? "DEVIATION" : "PASS";
  con_printf("RESULT %-15s %-9s checks %5u fails %u cycles %u\n", id, st, f_chk, f_fail,
             sim_cycle() - c0);
  sum_chk += f_chk;
  if (f_fail) n_fail++; else if (f_dev) n_dev++; else n_pass++;
}

/* ===========================================================================
 * Access
 * ========================================================================= */
static const struct ppu *pp(unsigned d) { return &pd_tab[d].ppu; }
static const char *nm(unsigned d)        { return pd_cfg[d].name; }

/* The four PPUs' inputs of the interrupt block, as a mask. */
static uint32_t ppu_ins(void)
{
  uint32_t m = 0;
  for (unsigned d = 0; d < ND; d++) m |= scp_irq_ppu_bit(d);
  return m;
}
static const char *mn(unsigned m)        { return pd_mode_name((enum ppu_mode)m); }
static uint32_t R(unsigned d, uint32_t off)             { return mmio_read32(SCP_PPU_ADDR(d) + off); }
static void     W(unsigned d, uint32_t off, uint32_t v) { mmio_write32(SCP_PPU_ADDR(d) + off, v); }
static unsigned MODE(unsigned d)                        { return R(d, PPU_PWSR) & 0xFu; }
static uint32_t O(unsigned d, unsigned k)               { return sim_obs(d, k); }
static void     clr(unsigned d) { W(d, PPU_ISR, PPU_ISR_W1C); W(d, PPU_AISR, PPU_AISR_W1C); }

static void sb(unsigned d, uint32_t off, uint8_t v)
{
  *(volatile uint8_t *)(uintptr_t)(SCP_PPU_ADDR(d) + off) = v;
}
static void sh(unsigned d, uint32_t off, uint16_t v)
{
  *(volatile uint16_t *)(uintptr_t)(SCP_PPU_ADDR(d) + off) = v;
}

static void delay(uint32_t n)
{
  uint32_t t0 = sim_cycle();
  while (sim_cycle() - t0 < n) { }
}

static bool wait_mode(unsigned d, unsigned m, uint32_t tmo)
{
  uint32_t t0 = sim_cycle();
  while (MODE(d) != m)
    if (sim_cycle() - t0 > tmo) return false;
  return true;
}

static bool wait_all(uint32_t mask, const uint8_t *m, uint32_t tmo)
{
  uint32_t t0 = sim_cycle(), left = mask;
  while (left) {
    for (unsigned d = 0; d < ND; d++)
      if (((left >> d) & 1u) && MODE(d) == m[d]) left &= ~(1u << d);
    if (left && sim_cycle() - t0 > tmo) return false;
  }
  return true;
}

/* A static policy, and wait for it. PWR_DYN_EN is reserved on these PPUs, so
   README Section 6 rule 10 cannot be broken by any write here. */
static bool go(unsigned d, unsigned m)
{
  W(d, PPU_PWPR, m);
  bool ok = wait_mode(d, m, TMO);
  delay(40);                 /* the event pulses land, the PPU goes idle */
  return ok;
}

static bool go_all(uint32_t mask, const uint8_t *m)
{
  for (unsigned d = 0; d < ND; d++)
    if ((mask >> d) & 1u) W(d, PPU_PWPR, m[d]);
  bool ok = wait_all(mask, m, TMO);
  delay(60);
  return ok;
}

static void fill(uint8_t *m, uint8_t v) { for (unsigned d = 0; d < ND; d++) m[d] = v; }

/* The observation window, by difference. */
static uint32_t sn[ND][32];
static const uint8_t SNAPK[] = {
  OBS_QREQ_FALLS, OBS_PREQ_RISES, OBS_HOPS, OBS_EV_TRN, OBS_EV_SACC, OBS_EV_SDENY,
  OBS_EV_DACC, OBS_EV_DDENY, OBS_EV_LOCKED, OBS_DC_EDGES, OBS_EV_UNSPT,
  OBS_QREQ_RISES, OBS_EV_EDGE, OBS_ACT_EDGES, OBS_ERRS, OBS_CLK_GATES,
};
static void snap(unsigned d)
{
  sim_obs_sel(d);
  for (unsigned i = 0; i < sizeof SNAPK; i++) sn[d][SNAPK[i]] = sim_obs_rd(SNAPK[i]);
}
static uint32_t dl(unsigned d, unsigned k) { return O(d, k) - sn[d][k]; }

/* ===========================================================================
 * The domains' software
 * ========================================================================= */
static uint32_t wk, hold_m, deny_m;

/* A testbench command on AP_CMD, echoed on AP_STAT once applied (10.1). */
static void tb_cmd(uint32_t w)
{
  mmio_write32(SIM_AP_CMD, w);
  uint32_t t0 = sim_cycle();
  while (mmio_read32(SIM_AP_STAT) != w)
    if (sim_cycle() - t0 > 2000u) { CK(0, "testbench command %08x not applied", w); return; }
}
static void hold(unsigned d, bool on)
{
  hold_m = on ? (hold_m | 1u << d) : (hold_m & ~(1u << d));
  tb_cmd(SOC4_TB_HOLD | hold_m);
}
static void deny(unsigned d, bool on)               /* d = ACC0 or ACC1 */
{
  unsigned k = d - ACC0;
  deny_m = on ? (deny_m | 1u << k) : (deny_m & ~(1u << k));
  tb_cmd(SOC4_TB_DENY | deny_m);
}
static void wake(unsigned d, bool on) { wk = on ? (wk | 1u << d) : (wk & ~(1u << d)); sim_wake(wk); }
static void wake_mask(uint32_t m)     { wk = m; sim_wake(wk); }

/* A burst on ACC d: busy, DEVQACTIVE HIGH, for len device cycles. */
static bool burst(unsigned d, unsigned len)
{
  sim_light(0);
  sim_work_len(len);
  sim_start(1u << d);
  uint32_t t0 = sim_cycle();
  while (!(O(d, OBS_LIVE) & OBS_LIVE_QACTIVE))
    if (sim_cycle() - t0 > 300) return false;
  return true;
}

static bool idle(unsigned d)
{
  uint32_t t0 = sim_cycle();
  while (O(d, OBS_LIVE) & OBS_LIVE_QACTIVE)
    if (sim_cycle() - t0 > 6000u) return false;
  return true;
}

/* An ACC's eight banks filled with the seeded pattern (IP_CMD 01). */
static void acc_fill(unsigned d, uint8_t seed)
{
  sim_ip_seed(seed);
  sim_ip_cmd(1u << (2u * d));
  delay(100);
  sim_ip_cmd(0);
}

/* The CPU RAM, through the load port: open only in ON or WARM_RST. */
static uint32_t ld_rd(unsigned n, uint32_t off)
{
  return mmio_read32(SOC4_LD_BASE(n) + off);
}
static void ld_wr(unsigned n, uint32_t off, uint32_t v)
{
  mmio_write32(SOC4_LD_BASE(n) + off, v);
}

/* A CPU's device channel. DEVREQEN changes only in static ON reached (PPU
   4.1.3; ppu_set_devreq_en refuses otherwise). */
static bool cpu_bind(unsigned n, bool en)
{
  bool ok = (MODE(n) == M_ON) || go(n, M_ON);
  return ok && ppu_set_devreq_en(pp(n), en) == PPU_OK;
}

/* Load and boot CPU n (mod/soc4_cpu.h, the cold sequence), then wait for its
   boot marker (read back through the load port). */
static bool cpu_boot(unsigned n)
{
  int rc = soc4_cpu_cold(n, timer_after(200000u));
  CK(rc == PD_OK, "%s cold sequence: %d", nm(n), rc);
  uint32_t t0 = sim_cycle();
  while (ld_rd(n, SOC4_CPU_MARKER) != (SOC4_CPU_MAGIC | n))
    if (sim_cycle() - t0 > 20000u) { CK(0, "%s never wrote its boot marker", nm(n)); return false; }
  return rc == PD_OK;
}

/* The retention RAM bytes on all four PPUs, through the driver, which writes
   only the registers each has (PPU_IDR1 b6/b5/b4, Table 5-27): PPU_FULRR on
   CPU0, PPU_MEMRR on ACC0. */
static void ret_ram(uint8_t funrr, uint8_t fulrr, uint8_t memrr)
{
  for (unsigned d = 0; d < ND; d++) ppu_set_ret_ram(pp(d), funrr, fulrr, memrr);
}

/* ===========================================================================
 * The baseline every feature starts from and returns to: static OFF, every
 * event unmasked, no edge event, every present RAM retention bit set, no entry
 * delay, the switch-settle device control delays (mod/pd.c), PTCR 0 (its reset
 * value). ACCs: both enables set. CPUs: DEVREQEN = 0, fetch off.
 * ========================================================================= */
static void base_cfg(unsigned d)
{
  uint32_t want = is_cpu(d) ? 0x100u : 0x101u;
  if ((R(d, PPU_PWCR) & 1u) != (want & 1u))
    CK(MODE(d) == M_ON && ppu_set_devreq_en(pp(d), want & 1u) == PPU_OK,
       "%s: DEVREQEN cannot be restored outside ON", nm(d));
  W(d, PPU_PWCR, want);
  W(d, PPU_PTCR, 0u);
  W(d, PPU_IMR, 0u);
  W(d, PPU_AIMR, 0u);
  W(d, PPU_IESR, 0u);
  W(d, PPU_EDTR0, 0u);
  W(d, PPU_EDTR1, 0u);
  ppu_set_dev_delays(pp(d), &pd_dev_delays);
  clr(d);
}

static void home(void)
{
  wake_mask(0);
  if (hold_m) { hold_m = 0; tb_cmd(SOC4_TB_HOLD); }
  if (deny_m) { deny_m = 0; tb_cmd(SOC4_TB_DENY); }
  sim_ip_cmd(0);
  sim_light(0);
  for (unsigned d = ACC0; d < ND; d++) CK(idle(d), "%s: the device never went idle", nm(d));
  for (unsigned n = 0; n < 2; n++) {
    cpu_fetch(n, false);
    if (R(n, PPU_PWCR) & PPU_PWCR_DEVREQEN0) CK(cpu_bind(n, false), "%s: unbind", nm(n));
  }
  for (unsigned d = 0; d < ND; d++) {
    if ((R(d, PPU_PWCR) & 1u) != (is_cpu(d) ? 0u : 1u)) CK(go(d, M_ON), "%s ON", nm(d));
    base_cfg(d);
  }
  uint8_t z[ND];
  fill(z, M_OFF);
  CK(go_all(ALLD, z), "not every domain returned to OFF");
  ret_ram(0xFF, 0xFF, 0xFF);
  for (unsigned d = 0; d < ND; d++) clr(d);
}

/* ===========================================================================
 * RST -- every register's reset value on the four PPUs, before anything has
 * written one (Chapter 5 register tables), for soc4's configuration (Section
 * 3.3): policy OFF; PTCR = WARM_RST_DEVREQEN_CFG = 0; IMR without LOCKED
 * (LOCK_CFG = 0, ppu_irq.sv IMR_RST); the absent RAM registers reserved.
 * ========================================================================= */
static const struct { uint16_t off; uint32_t val; } RST_TAB[] = {
  { PPU_PWPR, 0 }, { PPU_PMER, 0 }, { PPU_PWSR, 0 }, { PPU_DISR, 0 }, { PPU_MISR, 0 },
  { PPU_STSR, 0 }, { PPU_UNLK, 0 }, { PPU_PWCR, 0x101 }, { PPU_PTCR, 0 },
  { PPU_IMR, 0x02 }, { PPU_AIMR, 0x06 }, { PPU_ISR, 0 }, { PPU_AISR, 0 }, { PPU_IESR, 0 },
  { PPU_OPSR, 0 }, { PPU_FUNRR, 0 }, { PPU_FULRR, 0 }, { PPU_MEMRR, 0 },
  { PPU_EDTR0, 0 }, { PPU_EDTR1, 0 }, { PPU_DCDR0, 0x00020202 }, { PPU_DCDR1, 0x0202 },
  { PPU_IIDR, 0x50C01000 }, { PPU_AIDR, 0x00000011 },
};
/* PPU_IDR0 / IDR1 (Tables 5-26, 5-27) per domain, as scp/main.c checks them. */
static const uint32_t IDR0[ND] = { 0x00034101u, 0x00030101u, 0x00030501u, 0x00030101u };
static const uint32_t IDR1[ND] = { 0x23u, 0x03u, 0x13u, 0x03u };

static void f_rst(void)
{
  for (unsigned d = 0; d < ND; d++) {
    for (unsigned i = 0; i < ARRAY_SIZE(RST_TAB); i++) {
      uint32_t v = R(d, RST_TAB[i].off);
      CK(v == RST_TAB[i].val, "PPU %u +0x%03x resets to 0x%08x, spec 0x%08x", d,
         RST_TAB[i].off, v, RST_TAB[i].val);
    }
    CK(R(d, PPU_IDR0) == IDR0[d] && R(d, PPU_IDR1) == IDR1[d], "PPU %u IDR0 %08x IDR1 %08x", d,
       R(d, PPU_IDR0), R(d, PPU_IDR1));
    sim_check(d, M_OFF);
  }
}

/* ===========================================================================
 * ID -- identification and discovery (5.2.23-5.2.26): what the firmware learns
 * ========================================================================= */
static void f_id(void)
{
  int found = pd_init();
  scp_irq_mask(ppu_ins());
  CK(found == (int)ND, "pd_init found %d PPUs", found);
  for (unsigned d = 0; d < ND; d++) {
    const struct ppu *p = pp(d);
    CK(p->aidr == 0x11u && p->idr0 == IDR0[d] && p->idr1 == IDR1[d] && p->iidr == 0x50C01000u,
       "%s: %08x %08x %08x %08x", nm(d), p->aidr, p->idr0, p->idr1, p->iidr);
    CK(p->sta_modes == STA[d] && p->dyn_modes == 0u && p->channels == 1u,
       "%s decodes static %04x dynamic %04x channels %u", nm(d), p->sta_modes, p->dyn_modes,
       p->channels);
    /* Each retention RAM register on its own PPU_IDR1 bit, b6 FUNRR, b5 FULRR,
       b4 MEMRR (Table 5-27): FULRR alone on CPU0, MEMRR alone on ACC0. */
    CK(!p->lock && !p->off_mem_ret && p->ret_ram_regs == ((IDR1[d] >> 4) & 7u) &&
       p->entry_delay && p->sw_dev_delay, "%s features", nm(d));
    for (unsigned m = 0; m < 16; m++)
      CK(ppu_policy_supported(p, (enum ppu_mode)m, false) == ((STA[d] >> m) & 1u) &&
         !ppu_policy_supported(p, (enum ppu_mode)m, true),
         "%s: driver's support answer for policy %u", nm(d), m);
  }
  /* The CPU baseline: DEVREQEN = 0, set in static ON (PPU 4.1.3). */
  for (unsigned n = 0; n < 2; n++) CK(cpu_bind(n, false), "%s: DEVREQEN = 0 in ON", nm(n));
  home();
}

/* ===========================================================================
 * REG.RW -- writable fields hold what is written; reserved bits and registers
 * are WI/RAZ (5.2): PPU_FUNRR on all four, PPU_FULRR but on CPU0, PPU_MEMRR but
 * on ACC0 (Tables 5-19..5-21); PWPR LOCK_EN [12] and PWR_DYN_EN [8] reserved
 * (rtl/ppu/REGISTERS.md:273; ppu_regs.sv:325-326)
 * ========================================================================= */
static const struct { uint16_t off; uint32_t mask; } RW_TAB[] = {
  { PPU_PWCR, 0x00000101 }, { PPU_PTCR, 0x00000001 }, { PPU_IMR, 0x00000007 },
  { PPU_AIMR, 0x00000007 }, { PPU_IESR, 0x00000003 }, { PPU_FUNRR, 0 },
  { PPU_FULRR, 0 }, { PPU_MEMRR, 0 }, { PPU_EDTR0, 0xFF00FFFF },
  { PPU_EDTR1, 0x0000FFFF }, { PPU_DCDR0, 0x00FFFFFF }, { PPU_DCDR1, 0x0000FFFF },
};
static const uint32_t PAT[] = { 0xFFFFFFFFu, 0x00000000u, 0xA5A5A5A5u, 0x5A5A5A5Au, 0x0F1E2D3Cu };

static uint32_t rw_mask(unsigned d, unsigned r)
{
  if (RW_TAB[r].off == PPU_FULRR && d == CPU0) return 0xFFu;
  if (RW_TAB[r].off == PPU_MEMRR && d == ACC0) return 0xFFu;
  return RW_TAB[r].mask;
}

static void f_reg_rw(void)
{
  uint8_t m[ND];
  fill(m, M_ON);             /* DEVREQEN may only change static and in ON */
  CK(go_all(ALLD, m), "all ON");
  for (unsigned r = 0; r < ARRAY_SIZE(RW_TAB); r++)
    for (unsigned k = 0; k < ARRAY_SIZE(PAT); k++) {
      for (unsigned d = 0; d < ND; d++) W(d, RW_TAB[r].off, PAT[k] ^ (0x01010101u * d));
      for (unsigned d = 0; d < ND; d++) {
        uint32_t want = (PAT[k] ^ (0x01010101u * d)) & rw_mask(d, r), v = R(d, RW_TAB[r].off);
        CK(v == want, "%s +0x%03x: wrote %08x, read %08x, expected %08x", nm(d),
           RW_TAB[r].off, PAT[k] ^ (0x01010101u * d), v, want);
      }
    }
  /* PPU_PWPR: a supported policy with every reserved bit set, LOCK_EN and
     PWR_DYN_EN included: admitted as static ON, both enables read 0 */
  for (unsigned d = 0; d < ND; d++) {
    W(d, PPU_PWPR, 0xFFFFE0F8u);
    CK(R(d, PPU_PWPR) == M_ON && MODE(d) == M_ON, "%s: PWPR reserved bits read %08x",
       nm(d), R(d, PPU_PWPR));
    base_cfg(d);
  }
  home();
}

/* ===========================================================================
 * REG.RO -- read-only registers ignore writes; reserved registers (PMER, STSR,
 * OPSR, UNLK with no lock) and unmapped offsets read zero, ignore writes, and
 * do not fault
 * ========================================================================= */
static const uint16_t RO_TAB[] = {
  PPU_PWSR, PPU_DISR, PPU_MISR, PPU_IDR0, PPU_IDR1, PPU_IIDR, PPU_AIDR,
};
static const uint16_t RSV_TAB[] = {
  PPU_PMER, PPU_STSR, PPU_OPSR, PPU_UNLK, 0x00C, 0x028, 0x02C, 0x048, 0x04C, 0x05C,
  0x060, 0x100, 0x15C, 0x168, 0x16C, 0x178, 0x17C, 0x800, 0xF00, 0xFAC, 0xFB8,
  0xFBC, 0xFC0, 0xFC4, 0xFD0, 0xFFC,
};

static void f_reg_ro(void)
{
  uint8_t m[ND];
  fill(m, M_ON);
  CK(go_all(ALLD, m), "all ON");
  for (unsigned d = 0; d < ND; d++) {
    uint32_t pw0 = R(d, PPU_PWPR);
    for (unsigned i = 0; i < ARRAY_SIZE(RO_TAB); i++) {
      uint32_t v0 = R(d, RO_TAB[i]);
      W(d, RO_TAB[i], 0xFFFFFFFFu);
      W(d, RO_TAB[i], 0u);
      uint32_t v1 = R(d, RO_TAB[i]);
      CK(v1 == v0, "%s +0x%03x read-only: %08x became %08x", nm(d), RO_TAB[i], v0, v1);
    }
    for (unsigned i = 0; i < ARRAY_SIZE(RSV_TAB); i++) {
      struct trap_fault f;
      trap_expect_fault();
      W(d, RSV_TAB[i], 0xFFFFFFFFu);
      bool fw = trap_take_fault(&f);
      trap_expect_fault();
      uint32_t v = R(d, RSV_TAB[i]);
      bool fr = trap_take_fault(&f);
      CK(!fw && !fr && v == 0, "%s +0x%03x: fault w%d r%d, reads %08x", nm(d), RSV_TAB[i],
         fw, fr, v);
    }
    uint32_t pwsr = R(d, PPU_PWSR);
    CK(R(d, PPU_PWPR) == pw0 && pwsr == M_ON, "%s: side effects, PWPR %08x PWSR %08x", nm(d),
       R(d, PPU_PWPR), pwsr);
  }
  home();
}

/* ===========================================================================
 * REG.BYTE -- byte and halfword writes (AXI WSTRB) change only their lanes
 * (6.2.1); PPU_PWPR admission judges the merged policy and enable (4.1.1):
 * on a static-only PPU a lane-0 write of an unsupported policy is refused
 * whole, and a lane-1 write with PWR_DYN_EN set leaves the policy and reads
 * DYN_EN 0 (reserved); ISR clears by lane
 * ========================================================================= */
static void f_reg_byte(void)
{
  static const uint8_t doms[] = { CPU1, ACC1 };
  for (unsigned i = 0; i < ARRAY_SIZE(doms); i++) {
    unsigned d = doms[i];
    CK(go(d, M_ON), "%s ON", nm(d));
    W(d, PPU_EDTR0, 0);
    sb(d, PPU_EDTR0 + 3, 0x11); CK(R(d, PPU_EDTR0) == 0x11000000u, "EDTR0 lane 3: %08x", R(d, PPU_EDTR0));
    sb(d, PPU_EDTR0 + 1, 0x22); CK(R(d, PPU_EDTR0) == 0x11002200u, "EDTR0 lane 1: %08x", R(d, PPU_EDTR0));
    sb(d, PPU_EDTR0 + 2, 0x33); CK(R(d, PPU_EDTR0) == 0x11002200u, "EDTR0 reserved lane 2: %08x", R(d, PPU_EDTR0));
    sb(d, PPU_EDTR0 + 0, 0x44); CK(R(d, PPU_EDTR0) == 0x11002244u, "EDTR0 lane 0: %08x", R(d, PPU_EDTR0));
    W(d, PPU_EDTR0, 0);
    W(d, PPU_DCDR0, 0x00030303u);
    sh(d, PPU_DCDR0 + 0, 0xBEEF); CK(R(d, PPU_DCDR0) == 0x0003BEEFu, "DCDR0 low half: %08x", R(d, PPU_DCDR0));
    sh(d, PPU_DCDR0 + 2, 0x1234); CK(R(d, PPU_DCDR0) == 0x0034BEEFu, "DCDR0 high half: %08x", R(d, PPU_DCDR0));
    ppu_set_dev_delays(pp(d), &pd_dev_delays);
    uint32_t pw = R(d, PPU_PWCR);
    sb(d, PPU_PWCR + 1, 0x00); CK(R(d, PPU_PWCR) == (pw & 1u), "PWCR lane 1 clear: %08x", R(d, PPU_PWCR));
    sb(d, PPU_PWCR + 1, 0x01); CK(R(d, PPU_PWCR) == (pw | 0x100u), "PWCR lane 1 set: %08x", R(d, PPU_PWCR));
    /* lane 1 alone, PWR_DYN_EN set: admitted with the policy held, as static */
    uint32_t u0 = O(d, OBS_EV_UNSPT);
    sb(d, PPU_PWPR + 1, 0x01);
    CK(R(d, PPU_PWPR) == M_ON && !(R(d, PPU_PWSR) & PPU_PWSR_DYN_STATUS) &&
       O(d, OBS_EV_UNSPT) == u0, "%s: PWPR lane 1 with DYN_EN: %08x, %u UNSPT", nm(d),
       R(d, PPU_PWPR), O(d, OBS_EV_UNSPT) - u0);
    /* ISR: STA_POLICY_TRN (lane 0) and, on the ACC, the input edge (lane 1) */
    W(d, PPU_IESR, PPU_EDGE_RISE);
    clr(d);
    W(d, PPU_PWPR, M_ON);
    uint32_t want = PPU_ISR_STA_POLICY_TRN;
    if (!is_cpu(d)) { wake(d, true); delay(40); wake(d, false); want |= PPU_ISR_PWR_ACTIVE_EDGE0; }
    delay(40);
    CK((R(d, PPU_ISR) & 0x101u) == want, "%s ISR %03x before", nm(d), R(d, PPU_ISR));
    sb(d, PPU_ISR + 1, 0x01);
    CK((R(d, PPU_ISR) & 0x101u) == 0x001u, "%s ISR %03x after lane 1", nm(d), R(d, PPU_ISR));
    sb(d, PPU_ISR + 0, 0x01);
    CK((R(d, PPU_ISR) & 0x101u) == 0u, "%s ISR %03x after lane 0", nm(d), R(d, PPU_ISR));
    W(d, PPU_IESR, 0);
    clr(d);
  }
  /* lane 0 alone: MEM_RET on CPU0, which does not support it, is refused whole */
  CK(go(CPU0, M_ON), "CPU0 ON");
  uint32_t u0 = O(CPU0, OBS_EV_UNSPT);
  clr(CPU0);
  sb(CPU0, PPU_PWPR + 0, M_MRET);
  delay(20);
  CK(R(CPU0, PPU_PWPR) == M_ON && O(CPU0, OBS_EV_UNSPT) - u0 == 1u &&
     (R(CPU0, PPU_AISR) & PPU_AISR_UNSPT_POLICY), "CPU0: lane-0 MEM_RET: PWPR %08x, %u UNSPT",
     R(CPU0, PPU_PWPR), O(CPU0, OBS_EV_UNSPT) - u0);
  CK(MODE(CPU0) == M_ON, "CPU0 moved");
  home();
}

/* ===========================================================================
 * REG.W1C -- ISR/AISR write-one-to-clear, a 0 changes nothing, OTHER_IRQ is
 * AISR's summary and cannot be cleared in ISR (5.2.12-13); the IRQ line is the
 * OR of both (4.1.2), at the pin and at the SCP's interrupt block, input n
 * ========================================================================= */
static void f_w1c(void)
{
  uint8_t m[ND];
  fill(m, M_ON);
  CK(go_all(ALLD, m), "all ON");
  for (unsigned d = 0; d < ND; d++) {
    uint32_t line = scp_irq_ppu_bit(d);
    clr(d);
    W(d, PPU_PWPR, M_ON);                    /* STA_POLICY_TRN, condition 1 */
    W(d, PPU_PWPR, PPU_MODE_LOGIC_RET);      /* UNSPT_POLICY                */
    delay(20);
    CK(R(d, PPU_ISR) == 0x81u && R(d, PPU_AISR) == 0x01u, "%s ISR %03x AISR %x", nm(d),
       R(d, PPU_ISR), R(d, PPU_AISR));
    CK((O(d, OBS_LIVE) & OBS_LIVE_IRQ) && (scp_irq_raw() & line), "%s IRQ not asserted", nm(d));
    W(d, PPU_ISR, 0x80u);
    CK(R(d, PPU_ISR) == 0x81u, "%s OTHER_IRQ cleared through ISR: %03x", nm(d), R(d, PPU_ISR));
    W(d, PPU_ISR, 0u);
    CK(R(d, PPU_ISR) == 0x81u, "%s a zero write changed ISR: %03x", nm(d), R(d, PPU_ISR));
    W(d, PPU_ISR, 0x01u);
    CK(R(d, PPU_ISR) == 0x80u, "%s ISR after W1C of bit 0: %03x", nm(d), R(d, PPU_ISR));
    W(d, PPU_AISR, 0u);
    CK(R(d, PPU_AISR) == 1u, "%s a zero write changed AISR", nm(d));
    W(d, PPU_AISR, 1u);
    CK(R(d, PPU_AISR) == 0u && R(d, PPU_ISR) == 0u, "%s not clear: ISR %03x AISR %x", nm(d),
       R(d, PPU_ISR), R(d, PPU_AISR));
    delay(5);
    CK(!(O(d, OBS_LIVE) & OBS_LIVE_IRQ) && !(scp_irq_raw() & line), "%s IRQ still HIGH", nm(d));
  }
  home();
}

/* ===========================================================================
 * STA.MATRIX -- every ordered pair of each domain's static modes (Tables 3-1,
 * 3-2): CPU0 and ACC0 12 each, CPU1 and ACC1 6 each, all four domains at once,
 * each on an Eulerian circuit of its own set. Per step and domain: the route
 * (a hop has ON at one end, PPU 3.3.2; OFF -> MEM_RET goes through ON, since
 * OFF_MEM_RET_TRANS = 0), device handshakes (one per departure from ON other
 * than to WARM_RST, which has none with PTCR 0, Table 4-4; none at all on a CPU,
 * DEVREQEN = 0), PCSM handshakes (none between ON and WARM_RST, Table 3-2 note
 * a), one STA_POLICY_TRN, one STA_ACCEPT per hop, nothing else; and soc4_tb
 * checks every hop against the spec tables.
 * ========================================================================= */
static unsigned circuit(unsigned k, uint8_t *out)   /* Hierholzer on the complete digraph K_k */
{
  uint8_t used[4], stack[14];
  unsigned sp = 0, n = 0;
  memset(used, 0, sizeof used);
  stack[sp++] = 0;
  while (sp) {
    unsigned v = stack[sp - 1];
    if (used[v] < k - 1u) {
      unsigned j = used[v]++;
      stack[sp++] = (uint8_t)(j < v ? j : j + 1u);
    } else {
      if (n < 13u) out[n] = (uint8_t)v;
      n++;
      sp--;
    }
  }
  return n;
}

static unsigned hops_of(unsigned a, unsigned b)  { return (a == M_ON || b == M_ON) ? 1u : 2u; }
static unsigned pcsm_hop(unsigned a, unsigned b)
{
  return ((a == M_ON && b == M_WARM) || (a == M_WARM && b == M_ON)) ? 0u : 1u;
}
static unsigned preqs_of(unsigned a, unsigned b)
{
  return hops_of(a, b) == 1u ? pcsm_hop(a, b) : pcsm_hop(a, M_ON) + pcsm_hop(M_ON, b);
}
static unsigned qreqs_of(unsigned d, unsigned a, unsigned b)
{
  if (is_cpu(d) || b == M_WARM) return 0u;
  return (a == M_ON || hops_of(a, b) == 2u) ? 1u : 0u;
}

static void f_matrix(void)
{
  static uint8_t circ[ND][13];
  unsigned len[ND], pairs = 0, hops = 0;
  for (unsigned d = 0; d < ND; d++) {
    unsigned n = circuit(NM[d], circ[d]);
    len[d] = NM[d] * (NM[d] - 1u);
    CK(n == len[d] + 1u && circ[d][0] == circ[d][len[d]], "%s circuit has %u nodes", nm(d), n);
  }
  uint8_t tgt[ND], from[ND];
  for (unsigned d = 0; d < ND; d++) tgt[d] = MS[d][circ[d][0]];
  CK(go_all(ALLD, tgt), "starting modes");
  static uint8_t cov[ND][4][4];
  memset(cov, 0, sizeof cov);
  for (unsigned s = 0; s < 12; s++) {
    for (unsigned d = 0; d < ND; d++) {
      unsigned j = s % len[d];
      from[d] = MS[d][circ[d][j]];
      tgt[d]  = MS[d][circ[d][j + 1]];
      if (s < len[d]) cov[d][circ[d][j]][circ[d][j + 1]]++;
      snap(d);
    }
    for (unsigned d = 0; d < ND; d++) W(d, PPU_PWPR, tgt[d]);
    CK(wait_all(ALLD, tgt, TMO), "step %u did not complete", s);
    delay(60);
    for (unsigned d = 0; d < ND; d++) {
      unsigned a = from[d], b = tgt[d], h = hops_of(a, b);
      CK(MODE(d) == b, "%s %s->%s: PWSR says %s", nm(d), mn(a), mn(b), mn(MODE(d)));
      sim_check(d, b);
      uint32_t dh = dl(d, OBS_HOPS), ds = dl(d, OBS_EV_SACC), dt = dl(d, OBS_EV_TRN);
      uint32_t dq = dl(d, OBS_QREQ_FALLS), dp = dl(d, OBS_PREQ_RISES);
      uint32_t other = dl(d, OBS_EV_SDENY) + dl(d, OBS_EV_DACC) + dl(d, OBS_EV_DDENY) +
                       dl(d, OBS_EV_LOCKED);
      CK(dh == h && ds == h && dt == 1u && dq == qreqs_of(d, a, b) && dp == preqs_of(a, b) &&
         other == 0u,
         "%s %s->%s: hops %u acc %u trn %u devhs %u pcsm %u other %u; expected %u %u 1 %u %u 0",
         nm(d), mn(a), mn(b), dh, ds, dt, dq, dp, other, h, h, qreqs_of(d, a, b), preqs_of(a, b));
      uint32_t isr = R(d, PPU_ISR);
      CK((isr & 3u) == 3u, "%s %s->%s: ISR %03x, expected STA_POLICY_TRN and STA_ACCEPT", nm(d),
         mn(a), mn(b), isr);
      clr(d);
      hops += h;
    }
  }
  for (unsigned d = 0; d < ND; d++)
    for (unsigned a = 0; a < NM[d]; a++)
      for (unsigned b = 0; b < NM[d]; b++) {
        CK(cov[d][a][b] == (a != b ? 1u : 0u), "%s %s->%s run %u times", nm(d), mn(MS[d][a]),
           mn(MS[d][b]), cov[d][a][b]);
        if (a != b && cov[d][a][b]) pairs++;
      }
  CK(pairs == 36u, "%u of 36 ordered pairs run", pairs);
  con_printf("  %u ordered pairs (12 + 6 + 12 + 6), %u hops\n", pairs, hops);
  home();
}

/* ===========================================================================
 * EVT.PTRN1 -- a static policy written when the mode already matches: no
 * transition, and STA_POLICY_TRN (4.1.2, first condition), every mode of every
 * domain (PWR_DYN_EN is reserved here, so the condition always applies)
 * ========================================================================= */
static void f_ptrn1(void)
{
  for (unsigned i = 0; i < 4; i++) {
    uint8_t m[ND];
    uint32_t mask = 0;
    for (unsigned d = 0; d < ND; d++)
      if (i < NM[d]) { m[d] = MS[d][i]; mask |= 1u << d; } else m[d] = M_OFF;
    CK(go_all(mask, m), "setup %u", i);
    for (unsigned d = 0; d < ND; d++) if ((mask >> d) & 1u) { snap(d); clr(d); W(d, PPU_PWPR, m[d]); }
    delay(60);
    for (unsigned d = 0; d < ND; d++) {
      if (!((mask >> d) & 1u)) continue;
      CK(dl(d, OBS_HOPS) == 0u && dl(d, OBS_QREQ_FALLS) == 0u && dl(d, OBS_PREQ_RISES) == 0u,
         "%s in %s: a same-mode write moved the PPU", nm(d), mn(m[d]));
      CK(dl(d, OBS_EV_TRN) == 1u && (R(d, PPU_ISR) & PPU_ISR_STA_POLICY_TRN),
         "%s in %s: %u STA_POLICY_TRN", nm(d), mn(m[d]), dl(d, OBS_EV_TRN));
      clr(d);
    }
  }
  home();
}

/* ===========================================================================
 * STA.QACT -- DEVQACTIVE and static transitions (3.4.2, spec:1272-1275; 3.4.1,
 * spec:1186-1190): a lower-priority transition waits for DEVQACTIVE LOW,
 * including an intermediate hop through ON; a higher one does not; the second
 * hop from ON of an upward route waits; ON <-> WARM_RST never does; a disabled
 * input counts as LOW. DEVQACTIVE comes from an ACC's wake, and from hold_busy
 * for a CPU.
 * ========================================================================= */
static void f_qact(void)
{
  unsigned d;
  /* A: ON, policy OFF, DEVQACTIVE HIGH: held in ON, policy not reverted */
  d = ACC1;
  CK(go(d, M_ON), "A setup");
  wake(d, true); snap(d);
  W(d, PPU_PWPR, M_OFF);
  delay(1500);
  CK(MODE(d) == M_ON && dl(d, OBS_HOPS) == 0u && dl(d, OBS_QREQ_FALLS) == 0u &&
     R(d, PPU_PWPR) == M_OFF, "A: %s in %s after 1500 cycles, %u handshakes", nm(d),
     mn(MODE(d)), dl(d, OBS_QREQ_FALLS));
  wake(d, false);
  CK(wait_mode(d, M_OFF, TMO) && dl(d, OBS_HOPS) == 1u, "A: did not go OFF once released");
  /* B: MEM_RET, policy OFF, DEVQACTIVE HIGH: held in MEM_RET -- the
     intermediate hop to ON waits too (the example in 3.4.2) */
  d = ACC0;
  CK(go(d, M_ON) && go(d, M_MRET), "B setup");
  wake(d, true); delay(40); snap(d);
  W(d, PPU_PWPR, M_OFF);
  delay(1500);
  CK(MODE(d) == M_MRET && dl(d, OBS_HOPS) == 0u && dl(d, OBS_DC_EDGES) == 0u,
     "B: %s in %s, %u hops: the PPU climbed while DEVQACTIVE was HIGH", nm(d), mn(MODE(d)),
     dl(d, OBS_HOPS));
  wake(d, false);
  CK(wait_mode(d, M_OFF, TMO) && dl(d, OBS_HOPS) == 2u, "B: MEM_RET->ON->OFF once released");
  /* C: OFF, policy ON, DEVQACTIVE HIGH: not delayed */
  d = ACC1;
  wake(d, true);
  uint32_t t0 = sim_cycle();
  W(d, PPU_PWPR, M_ON);
  CK(wait_mode(d, M_ON, 600), "C: OFF->ON waited for DEVQACTIVE (%u cycles)", sim_cycle() - t0);
  wake(d, false);
  /* D: CPU0 OFF, policy FULL_RET, DEVQACTIVE HIGH (hold_busy): the hop up to ON
     runs; the second hop, ON -> FULL_RET, is a transition FROM ON, which
     waits: "For transitions from ON, other than to WARM_RST, all DEVQACTIVE
     inputs must be LOW to begin a transition" (3.4.2). */
  d = CPU0;
  hold(d, true); snap(d);
  W(d, PPU_PWPR, M_FULL);
  delay(1500);
  CK(MODE(d) == M_ON && dl(d, OBS_HOPS) == 1u, "D: %s in %s, %u hops", nm(d), mn(MODE(d)),
     dl(d, OBS_HOPS));
  hold(d, false);
  CK(wait_mode(d, M_FULL, TMO), "D: FULL_RET once released");
  /* E: ON <-> WARM_RST with DEVQACTIVE HIGH: neither direction waits */
  d = ACC0;
  CK(go(d, M_ON), "E setup");
  wake(d, true);
  W(d, PPU_PWPR, M_WARM);
  CK(wait_mode(d, M_WARM, 600), "E: ON->WARM_RST waited for DEVQACTIVE");
  sim_check(d, M_WARM);
  W(d, PPU_PWPR, M_ON);
  CK(wait_mode(d, M_ON, 600), "E: WARM_RST->ON waited for DEVQACTIVE");
  wake(d, false);
  /* F: PWR_DEVACTIVEEN = 0: DEVQACTIVE HIGH is "assumed LOW" (3.4.1), on an ACC
     and on a CPU (hold_busy; DEVREQEN = 0, so nothing is asked of it) */
  d = ACC1;
  CK(go(d, M_ON), "F setup");
  W(d, PPU_PWCR, 0x001u);
  wake(d, true);
  W(d, PPU_PWPR, M_OFF);
  CK(wait_mode(d, M_OFF, 2000), "F: a disabled DEVQACTIVE held the transition");
  CK(O(d, OBS_LIVE) & OBS_LIVE_QACTIVE, "F: DEVQACTIVE was not HIGH");
  wake(d, false);
  d = CPU1;
  CK(go(d, M_ON), "F CPU1 ON");
  W(d, PPU_PWCR, 0x000u);
  hold(d, true);
  W(d, PPU_PWPR, M_OFF);
  CK(wait_mode(d, M_OFF, 2000), "F: CPU1 held by a disabled DEVQACTIVE");
  hold(d, false);
  home();
}

/* ===========================================================================
 * STA.MIDWRITE -- "Software writes to the Power Policy Register (PPU_PWPR) do
 * not interrupt mode transitions" (4.1.1): ACC0's down-hop held in Q_REQUEST by
 * hold_busy (busy, no deny: it waits for ever, qchannel_device.sv); PWPR = ON
 * written meanwhile; the hop ends only when the device accepts, then the PPU
 * heads for the new policy
 * ========================================================================= */
static void f_midwrite(void)
{
  unsigned d = ACC0;
  CK(go(d, M_ON), "setup");
  W(d, PPU_PWCR, 0x001u);            /* the PPU asks although DEVQACTIVE is HIGH */
  hold(d, true);
  snap(d);
  W(d, PPU_PWPR, M_OFF);
  delay(30);
  uint32_t lv = O(d, OBS_LIVE);
  CK(!(lv & OBS_LIVE_QREQN) && MODE(d) == M_ON, "not stalled in the handshake: live %08x", lv);
  W(d, PPU_PWPR, M_ON);
  CK(R(d, PPU_PWPR) == M_ON, "the mid-flight write did not land");
  delay(1500);
  CK(MODE(d) == M_ON && dl(d, OBS_HOPS) == 0u && !(O(d, OBS_LIVE) & OBS_LIVE_QREQN),
     "the write ended the transition: %s, %u hops", mn(MODE(d)), dl(d, OBS_HOPS));
  hold(d, false);
  uint32_t t0 = sim_cycle();
  while (dl(d, OBS_HOPS) < 2u && sim_cycle() - t0 < TMO) { }
  CK(wait_mode(d, M_ON, TMO), "never back in ON");
  delay(40);
  CK(dl(d, OBS_HOPS) == 2u && dl(d, OBS_EV_SACC) == 2u && dl(d, OBS_EV_TRN) == 1u &&
     dl(d, OBS_QREQ_FALLS) == 1u,
     "ON->OFF->ON: hops %u accepts %u completions %u handshakes %u",
     dl(d, OBS_HOPS), dl(d, OBS_EV_SACC), dl(d, OBS_EV_TRN), dl(d, OBS_QREQ_FALLS));
  home();
}

/* ===========================================================================
 * DENY -- a device refusing (4.1.1, 4.1.2, 4.2.9, Table 4-1): a static denial
 * reverts the policy to the current mode and touches no control; the third
 * STA_POLICY_TRN condition; the denial of the SECOND hop of a route through ON
 * (ACC0 MEM_RET, policy OFF: MEM_RET -> ON, then ON -> OFF denied). The device
 * is held busy with deny (hold_busy + 'D', 5.6: deny = deny_i && busy).
 * ========================================================================= */
static void f_deny(void)
{
  unsigned d = ACC1;
  CK(go(d, M_ON), "setup");
  W(d, PPU_PWCR, 0x001u);
  /* 1: static */
  hold(d, true); deny(d, true);
  snap(d); clr(d);
  W(d, PPU_PWPR, M_OFF);
  delay(120);
  CK(MODE(d) == M_ON && R(d, PPU_PWPR) == M_ON, "1: mode %s policy %08x", mn(MODE(d)),
     R(d, PPU_PWPR));
  CK(dl(d, OBS_EV_SDENY) == 1u && (R(d, PPU_ISR) & PPU_ISR_STA_DENY) && dl(d, OBS_EV_TRN) == 0u,
     "1: %u STA_DENY, %u STA_POLICY_TRN", dl(d, OBS_EV_SDENY), dl(d, OBS_EV_TRN));
  CK(dl(d, OBS_DC_EDGES) == 0u && dl(d, OBS_PREQ_RISES) == 0u && dl(d, OBS_HOPS) == 0u &&
     dl(d, OBS_QREQ_FALLS) == 1u && dl(d, OBS_QREQ_RISES) == 1u,
     "1: controls %u pcsm %u hops %u req %u/%u", dl(d, OBS_DC_EDGES), dl(d, OBS_PREQ_RISES),
     dl(d, OBS_HOPS), dl(d, OBS_QREQ_FALLS), dl(d, OBS_QREQ_RISES));
  hold(d, false); deny(d, false);
  delay(200);
  CK(dl(d, OBS_HOPS) == 0u && MODE(d) == M_ON, "1: the reverted transition was retried");
  /* 3: the last policy written during the transition is the current mode */
  hold(d, true);
  snap(d); clr(d);
  W(d, PPU_PWPR, M_OFF);
  delay(30);
  W(d, PPU_PWPR, M_ON);
  deny(d, true);
  delay(120);
  CK(MODE(d) == M_ON && dl(d, OBS_EV_SDENY) == 1u && dl(d, OBS_EV_TRN) == 1u &&
     (R(d, PPU_ISR) & 5u) == 5u, "3: deny %u trn %u ISR %03x", dl(d, OBS_EV_SDENY),
     dl(d, OBS_EV_TRN), R(d, PPU_ISR));
  hold(d, false); deny(d, false);
  /* 4: the second hop. PWR_DEVACTIVEEN = 0 lets the first hop start although
     the device is busy (3.4.1); the device refuses the second. */
  d = ACC0;
  CK(go(d, M_ON) && go(d, M_MRET), "4: MEM_RET");
  W(d, PPU_PWCR, 0x001u);
  hold(d, true); deny(d, true);
  snap(d); clr(d);
  W(d, PPU_PWPR, M_OFF);
  CK(wait_mode(d, M_ON, TMO), "4: intermediate ON");
  delay(400);
  CK(MODE(d) == M_ON && R(d, PPU_PWPR) == M_ON && dl(d, OBS_EV_SACC) == 1u &&
     dl(d, OBS_EV_SDENY) == 1u && dl(d, OBS_HOPS) == 1u,
     "4: %s policy %08x acc %u deny %u hops %u", mn(MODE(d)), R(d, PPU_PWPR),
     dl(d, OBS_EV_SACC), dl(d, OBS_EV_SDENY), dl(d, OBS_HOPS));
  sim_check(d, M_ON);
  hold(d, false); deny(d, false);
  home();
}

/* ===========================================================================
 * EVT.MASK -- a masked event does not set its status bit, and unmasking does
 * not resurrect it (5.2.10-11): every maskable event these PPUs have
 * (STA_POLICY_TRN, STA_ACCEPT, STA_DENY; UNSPT_POLICY). LOCKED, DYN_ACCEPT and
 * DYN_DENY cannot happen here (no lock, no dynamic modes).
 * ========================================================================= */
static void g_trn(unsigned d)   { W(d, PPU_PWPR, M_ON); delay(40); }
static void g_sacc(unsigned d)  { go(d, MODE(d) == M_ON ? M_WARM : M_ON); go(d, M_ON); }
static void g_sdeny(unsigned d)
{
  W(d, PPU_PWCR, 0x001u); hold(d, true); deny(d, true);
  W(d, PPU_PWPR, M_OFF); delay(100);
  hold(d, false); deny(d, false); W(d, PPU_PWCR, 0x101u); delay(40);
}
static void g_unspt(unsigned d) { W(d, PPU_PWPR, PPU_MODE_LOGIC_RET); delay(20); }

static const struct {
  const char *n; bool a; uint32_t bit; uint8_t k; void (*g)(unsigned);
} MC[] = {
  { "STA_POLICY_TRN", false, PPU_ISR_STA_POLICY_TRN, OBS_EV_TRN,   g_trn   },
  { "STA_ACCEPT",     false, PPU_ISR_STA_ACCEPT,     OBS_EV_SACC,  g_sacc  },
  { "STA_DENY",       false, PPU_ISR_STA_DENY,       OBS_EV_SDENY, g_sdeny },
  { "UNSPT_POLICY",   true,  PPU_AISR_UNSPT_POLICY,  OBS_EV_UNSPT, g_unspt },
};

static void f_mask(void)
{
  unsigned d = ACC1;
  for (unsigned i = 0; i < ARRAY_SIZE(MC); i++) {
    uint32_t mreg = MC[i].a ? PPU_AIMR : PPU_IMR, sreg = MC[i].a ? PPU_AISR : PPU_ISR;
    CK(go(d, M_ON), "ON");
    clr(d);
    W(d, mreg, MC[i].bit);
    uint32_t e0 = O(d, MC[i].k);
    MC[i].g(d);
    CK(O(d, MC[i].k) - e0 >= 1u, "%s: no event in the masked run", MC[i].n);
    CK(!(R(d, sreg) & MC[i].bit), "%s: a masked event set its status bit", MC[i].n);
    W(d, mreg, 0u);
    CK(!(R(d, sreg) & MC[i].bit), "%s: unmasking resurrected it", MC[i].n);
    CK(go(d, M_ON), "ON");
    clr(d);
    e0 = O(d, MC[i].k);
    MC[i].g(d);
    CK(O(d, MC[i].k) - e0 >= 1u && (R(d, sreg) & MC[i].bit), "%s: unmasked, status %03x",
       MC[i].n, R(d, sreg));
    clr(d);
  }
  home();
}

/* ===========================================================================
 * EVT.EDGE -- the input edge event (4.1.2, 5.2.14): none/rise/fall/both, one
 * event per edge; PPU_DISR follows the pin. ACC1's wake.
 * ========================================================================= */
static void f_edge(void)
{
  unsigned d = ACC1;
  CK(go(d, M_ON), "setup");
  for (unsigned e = 0; e < 4; e++) {
    W(d, PPU_IESR, e);
    clr(d);
    uint32_t e0 = O(d, OBS_EV_EDGE);
    wake(d, true);
    delay(60);
    uint32_t nr = O(d, OBS_EV_EDGE) - e0, ir = R(d, PPU_ISR) & PPU_ISR_PWR_ACTIVE_EDGE0;
    CK(R(d, PPU_DISR) == 1u, "DISR with DEVQACTIVE HIGH");
    W(d, PPU_ISR, PPU_ISR_PWR_ACTIVE_EDGE0);
    e0 = O(d, OBS_EV_EDGE);
    wake(d, false);
    delay(60);
    uint32_t nf = O(d, OBS_EV_EDGE) - e0, jf = R(d, PPU_ISR) & PPU_ISR_PWR_ACTIVE_EDGE0;
    CK(R(d, PPU_DISR) == 0u, "DISR with DEVQACTIVE LOW");
    W(d, PPU_ISR, PPU_ISR_PWR_ACTIVE_EDGE0);
    CK(nr == (e & 1u) && (ir != 0) == ((e & 1u) != 0), "IESR %u rising edge: %u events, ISR %x",
       e, nr, ir);
    CK(nf == ((e >> 1) & 1u) && (jf != 0) == (((e >> 1) & 1u) != 0),
       "IESR %u falling edge: %u events, ISR %x", e, nf, jf);
  }
  CK(MODE(d) == M_ON, "the edges moved a static ON");
  home();
}

/* ===========================================================================
 * EVT.EDGE_OFF -- the same event with PWR_DEVACTIVEEN clear (4.1.3: "These
 * enables have no effect on the generation of interrupts"), with the PPU's own
 * clock gated (no access) when the edge arrives
 * ========================================================================= */
static void f_edge_off(void)
{
  unsigned d = ACC1;
  CK(go(d, M_ON), "setup");
  W(d, PPU_IESR, PPU_EDGE_RISE);
  W(d, PPU_PWCR, 0x001u);
  clr(d);
  delay(300);                          /* no access: the PPU clock gates */
  uint32_t e0 = O(d, OBS_EV_EDGE);
  wake(d, true);
  delay(600);
  uint32_t n = O(d, OBS_EV_EDGE) - e0;
  bool irq = (O(d, OBS_LIVE) & OBS_LIVE_IRQ) != 0;
  CK(n == 1u && irq, "%s: disarmed rising edge: %u event(s), IRQ %u", nm(d), n, irq);
  CK(R(d, PPU_ISR) & PPU_ISR_PWR_ACTIVE_EDGE0, "the edge was lost");
  wake(d, false);
  delay(40);
  home();
}

/* ===========================================================================
 * EVT.UNSPT -- every unsupported and reserved static policy, with PWR_DYN_EN
 * and LOCK_EN 0 and 1 (both reserved here), on all four PPUs: the WHOLE write
 * is refused, one UNSPT_POLICY per write, OTHER_IRQ follows (3.1, 4.1.1,
 * Table 5-26). A supported policy with PWR_DYN_EN set is S.DYNREQ.
 * ========================================================================= */
static void f_unspt(void)
{
  uint8_t m[ND];
  fill(m, M_ON);
  CK(go_all(ALLD, m), "all ON");
  unsigned writes = 0;
  for (unsigned d = 0; d < ND; d++) {
    uint32_t before = R(d, PPU_PWPR);
    for (unsigned v = 0; v < 16; v++) {
      if ((STA[d] >> v) & 1u) continue;
      for (unsigned y = 0; y < 2; y++)
        for (unsigned l = 0; l < 2; l++) {
          uint32_t e0 = O(d, OBS_EV_UNSPT);
          W(d, PPU_PWPR, v | (y ? DYN : 0u) | (l ? LCK : 0u));
          uint32_t pw = R(d, PPU_PWPR), isr = R(d, PPU_ISR), aisr = R(d, PPU_AISR);
          CK(pw == before && O(d, OBS_EV_UNSPT) - e0 == 1u && (aisr & 1u) && (isr & 0x80u),
             "%s policy %u dyn %u lock %u: PWPR %08x, %u events, AISR %x ISR %03x", nm(d), v,
             y, l, pw, O(d, OBS_EV_UNSPT) - e0, aisr, isr);
          W(d, PPU_AISR, PPU_AISR_UNSPT_POLICY);
          writes++;
        }
    }
    CK(MODE(d) == M_ON && !(R(d, PPU_PWSR) & (PPU_PWSR_LOCK_STATUS | PPU_PWSR_DYN_STATUS)),
       "%s moved", nm(d));
  }
  con_printf("  %u refused writes (12 or 13 encodings x 4 enable pairs x 4 PPUs)\n", writes);
  home();
}

/* ===========================================================================
 * EVT.LINES -- PPU n's interrupt is input n of the SCP's interrupt block and no
 * other, as a level, and no Ibex fast line moves; and the firmware's handler
 * path (trap_external -> pd_poll -> scp_irq_collect) takes it, through the
 * block onto line 11, one interrupt per event
 * ========================================================================= */
static void f_lines(void)
{
  const uint32_t ppus = ppu_ins();
  const uint32_t fast = 0x7FFFu << 16;                         /* mip 16-30 */
  for (unsigned d = 0; d < ND; d++) clr(d);
  for (unsigned d = 0; d < ND; d++) {
    W(d, PPU_PWPR, PPU_MODE_LOGIC_RET);
    delay(10);
    uint32_t raw = scp_irq_raw() & ppus;
    CK(raw == scp_irq_ppu_bit(d) && !(csr_read(mip) & fast), "%s raised inputs %08x, mip %08x",
       nm(d), raw, csr_read(mip));
    W(d, PPU_AISR, PPU_AISR_UNSPT_POLICY);
    delay(5);
    CK(!(scp_irq_raw() & ppus), "%s: input still HIGH", nm(d));
  }
  uint32_t ext0 = trap_ext_count;
  scp_irq_unmask(ppus);
  irq_enable();
  for (unsigned d = 0; d < ND; d++) {
    uint32_t u0 = pd_tab[d].ev.unspt, s0 = pd_tab[d].ev.spurious;
    W(d, PPU_PWPR, PPU_MODE_LOGIC_RET);
    delay(30);
    pd_poll();
    CK(pd_tab[d].ev.unspt == u0 + 1u && pd_tab[d].ev.spurious == s0,
       "%s: handler counted %u UNSPT", nm(d), pd_tab[d].ev.unspt - u0);
  }
  irq_disable();
  scp_irq_mask(ppus);
  CK(trap_ext_count - ext0 == ND, "%u interrupts from the block for %u events",
     trap_ext_count - ext0, ND);
  home();
}

/* ===========================================================================
 * DEV.REQEN -- DEVREQEN = 0 (4.1.3): no handshake, DEVQREQn held HIGH, the
 * transition still sequenced, a busy device's refusal ignored; the driver's
 * rules (static and reached; re-enabled only from ON); and every forced entry
 * the CPU baseline makes
 * ========================================================================= */
static void f_devreq(void)
{
  unsigned d = ACC1;
  const struct ppu *p = pp(d);
  CK(go(d, M_ON), "setup");
  CK(ppu_set_devreq_en(p, false) == PPU_OK && R(d, PPU_PWCR) == 0x100u, "disable in ON");
  snap(d);
  CK(go(d, M_OFF), "OFF without handshake");
  CK(dl(d, OBS_QREQ_FALLS) == 0u && (O(d, OBS_LIVE) & OBS_LIVE_QREQN) &&
     dl(d, OBS_DC_EDGES) > 0u && dl(d, OBS_PREQ_RISES) == 1u && dl(d, OBS_HOPS) == 1u,
     "ON->OFF: handshakes %u controls %u pcsm %u", dl(d, OBS_QREQ_FALLS),
     dl(d, OBS_DC_EDGES), dl(d, OBS_PREQ_RISES));
  CK(ppu_set_devreq_en(p, true) == PPU_E_STATE, "driver re-enabled DEVREQEN outside ON");
  CK(go(d, M_ON), "ON without handshake");
  W(d, PPU_PWCR, 0x000u);              /* DEVQACTIVE disarmed too: nothing waits */
  hold(d, true); deny(d, true);
  snap(d);
  CK(go(d, M_OFF), "a busy, denying device was asked anyway");
  CK(dl(d, OBS_EV_SDENY) == 0u && dl(d, OBS_QREQ_FALLS) == 0u, "denied with DEVREQEN = 0");
  hold(d, false); deny(d, false);
  CK(go(d, M_ON), "ON");
  CK(ppu_set_devreq_en(p, true) == PPU_OK && (R(d, PPU_PWCR) & 1u), "re-enable in ON");
  W(d, PPU_PWCR, 0x101u);
  snap(d);
  CK(go(d, M_OFF) && dl(d, OBS_QREQ_FALLS) == 1u, "the handshake did not come back");
  CK(go(d, M_ON), "ON");
  /* mid-transition: policy not reached */
  W(d, PPU_PWCR, 0x001u);
  hold(d, true);
  W(d, PPU_PWPR, M_OFF);
  delay(30);
  CK(ppu_set_devreq_en(p, false) == PPU_E_STATE, "driver changed DEVREQEN mid-transition");
  hold(d, false);
  CK(wait_mode(d, M_OFF, TMO), "OFF");
  /* the CPUs' baseline: no handshake on their forced entries */
  for (unsigned n = 0; n < 2; n++) {
    snap(n);
    CK(go(n, M_ON) && go(n, M_OFF), "%s ON, OFF", nm(n));
    CK(dl(n, OBS_QREQ_FALLS) == 0u && !(R(n, PPU_PWCR) & 1u), "%s: %u handshakes", nm(n),
       dl(n, OBS_QREQ_FALLS));
  }
  home();
}

/* ===========================================================================
 * DEV.WARM -- Table 4-4: the ON <-> WARM_RST device handshake with (DEVREQEN,
 * WARM_RST_DEVREQEN) = (1,1) yes; (1,0), the reset value here, no; (0,x) no;
 * and never a PCSM handshake (Table 3-2 note a)
 * ========================================================================= */
static void f_warm(void)
{
  static const struct { uint8_t req, wreq; } T44[] = { {1, 0}, {1, 1}, {0, 1}, {0, 0} };
  unsigned d = ACC0;
  CK(go(d, M_ON), "setup");
  for (unsigned i = 0; i < 4; i++) {
    W(d, PPU_PTCR, T44[i].wreq);
    if (!T44[i].req) CK(ppu_set_devreq_en(pp(d), false) == PPU_OK, "DEVREQEN off");
    snap(d);
    CK(go(d, M_WARM), "WARM_RST");
    sim_check(d, M_WARM);
    CK(go(d, M_ON), "ON");
    unsigned hs = T44[i].req && T44[i].wreq;
    CK(dl(d, OBS_QREQ_FALLS) == hs && dl(d, OBS_QREQ_RISES) == hs && dl(d, OBS_PREQ_RISES) == 0u &&
       dl(d, OBS_HOPS) == 2u, "DEVREQEN %u WARM_RST_DEVREQEN %u: handshakes %u/%u pcsm %u",
       T44[i].req, T44[i].wreq, dl(d, OBS_QREQ_FALLS), dl(d, OBS_QREQ_RISES),
       dl(d, OBS_PREQ_RISES));
    if (!T44[i].req) CK(ppu_set_devreq_en(pp(d), true) == PPU_OK, "DEVREQEN on");
  }
  W(d, PPU_PTCR, 0u);
  home();
}

/* ===========================================================================
 * DEV.STATUS -- PPU_DISR follows DEVQACTIVE, armed or not (5.2.4); PPU_MISR
 * (5.2.5, Table 5-6) shows DEVQACCEPTn as a pin -- HIGH in ON, LOW when
 * quiesced, still HIGH while a request waits -- and DEVDENY_STATUS [16] and
 * PCSMPACCEPT_STATUS [0] LOW at rest. Each is sampled through a denial and a
 * power-up too: they are pulses of a few cycles, and an AXI read takes about
 * as long, so a sample that catches one is reported, and only the rest values
 * are checks.
 * ========================================================================= */
static void f_status(void)
{
  unsigned d = ACC1;
  CK(go(d, M_ON), "setup");
  CK(R(d, PPU_DISR) == 0u, "DISR idle");
  wake(d, true); delay(10);
  CK(R(d, PPU_DISR) == 1u, "DISR, armed, HIGH");
  wake(d, false); delay(10);
  CK(R(d, PPU_DISR) == 0u, "DISR, armed, LOW");
  W(d, PPU_PWCR, 0x001u);
  delay(300);
  wake(d, true);
  CK(R(d, PPU_DISR) == 1u, "DISR, disarmed and clock-gated, missed DEVQACTIVE HIGH");
  wake(d, false);
  CK(R(d, PPU_DISR) == 0u, "DISR, disarmed, missed DEVQACTIVE LOW");
  W(d, PPU_PWCR, 0x101u);
  CK(burst(d, 100) && R(d, PPU_DISR) == 1u, "DISR during a burst");
  delay(200);
  CK(R(d, PPU_DISR) == 0u, "DISR after the burst");
  CK(R(d, PPU_MISR) == 0x100u, "ON: MISR %08x, expected DEVQACCEPTn HIGH only", R(d, PPU_MISR));
  CK(go(d, M_OFF), "OFF");
  CK(R(d, PPU_MISR) == 0u, "OFF: MISR %08x, expected DEVQACCEPTn LOW", R(d, PPU_MISR));
  /* power-up: sample for PCSMPACCEPT */
  unsigned pacc = 0, deny_seen = 0, n = 0;
  W(d, PPU_PWPR, M_ON);
  for (uint32_t t0 = sim_cycle(); sim_cycle() - t0 < 300u; n++) pacc |= R(d, PPU_MISR) & 1u;
  CK(wait_mode(d, M_ON, TMO) && R(d, PPU_MISR) == 0x100u, "ON again: MISR %08x", R(d, PPU_MISR));
  /* a request waiting, then denied */
  W(d, PPU_PWCR, 0x001u);
  hold(d, true);
  W(d, PPU_PWPR, M_OFF);
  delay(30);
  uint32_t lv = O(d, OBS_LIVE), misr = R(d, PPU_MISR);
  CK(!(lv & OBS_LIVE_QREQN) && misr == 0x100u, "request waiting: live %08x MISR %08x", lv, misr);
  mmio_write32(SIM_AP_CMD, SOC4_TB_DENY | (1u << (d - ACC0)));   /* sample from the write on */
  deny_m = 1u << (d - ACC0);
  for (uint32_t t0 = sim_cycle(); sim_cycle() - t0 < 300u; ) deny_seen |= (R(d, PPU_MISR) >> 16) & 1u;
  CK(MODE(d) == M_ON && R(d, PPU_PWPR) == M_ON && !(R(d, PPU_MISR) & 0x10001u),
     "after the denial: %s, PWPR %08x, MISR %08x", mn(MODE(d)), R(d, PPU_PWPR), R(d, PPU_MISR));
  con_printf("  MISR pulses sampled: PCSMPACCEPT %s (power-up, %u reads), DEVDENY %s (denial)\n",
             pacc ? "seen" : "missed", n, deny_seen ? "seen" : "missed");
  hold(d, false); deny(d, false);
  home();
}

/* ===========================================================================
 * DLY -- device control delays (4.1.5, Table 4-5, 5.2.21-22): three settings
 * on each domain, read back, and measured at the pins: each spacing exactly
 * value + 1. RST_HWSTAT_DLY also waits for the device's handshake (4.1.5): on a
 * CPU, with DEVREQEN = 0, there is none, so it is exact there; on an ACC it is
 * at least value + 1, and exact once the delay outlasts the handshake.
 * ========================================================================= */
static const struct ppu_dev_delays DS[12] = {
  /* rst_hwstat iso_clken clken_rst clken_iso iso_rst */
  {   0,  20,   0,   0,   0 }, {   1,  14,   1,   1,   1 }, {   2,  20,   4,   2,   2 },
  {   7,   9,   7,   7,   7 }, {  31,  15,  31,  31,  31 }, {  63,   1,  63,   0,  63 },
  { 100,  50,   0, 100,   0 }, { 255, 255, 255, 255, 255 }, {  12,  30,   2,   5,   9 },
  {   0,  16,   0, 200,   0 }, { 200,   3,  17,   3, 200 }, {   9,  99,   9,   9,  99 },
};
static unsigned sat(unsigned v) { return v > 255u ? 255u : v; }

static void f_dly(void)
{
  for (unsigned set = 0; set < 3; set++) {
    for (unsigned d = 0; d < ND; d++) {
      const struct ppu_dev_delays *x = &DS[4u * set + d];
      CK(ppu_set_dev_delays(pp(d), x) == PPU_OK, "%s DCDR", nm(d));
      struct ppu_dev_delays g;
      ppu_get_dev_delays(pp(d), &g);
      CK(memcmp(&g, x, sizeof g) == 0, "%s DCDR read back", nm(d));
    }
    /* OFF -> ON moves every up-side control; ON -> OFF and ON -> LP every
       down-side one (FULL_RET through DEVWARMRESETn only) */
    uint8_t m[ND];
    for (unsigned s = 0; s < 4; s++) {
      if (s == 3) memcpy(m, LP, ND); else fill(m, s == 1 ? M_OFF : M_ON);
      CK(go_all(ALLD, m), "set %u step %u", set, s);
      for (unsigned d = 0; d < ND; d++) {
        const struct ppu_dev_delays *x = &DS[4u * set + d];
        if (m[d] == M_ON) {
          uint32_t v = O(d, OBS_UP_LAST);
          unsigned ic = v & 0xFFu, cr = (v >> 8) & 0xFFu, rh = (v >> 16) & 0xFFu;
          CK(ic == sat(x->iso_clken + 1u) && cr == sat(x->clken_rst + 1u),
             "%s up: iso>clk %u clk>rst %u for %u %u", nm(d), ic, cr, x->iso_clken, x->clken_rst);
          bool exact = is_cpu(d) || x->rst_hwstat >= 16u;
          CK(rh >= sat(x->rst_hwstat + 1u) && (!exact || rh == sat(x->rst_hwstat + 1u)),
             "%s up: rst>hwstat %u for %u", nm(d), rh, x->rst_hwstat);
        } else if (s >= 1) {
          uint32_t v = O(d, OBS_DN_LAST);
          unsigned ci = v & 0xFFu, ir = (v >> 8) & 0xFFu;
          CK(ci == sat(x->clken_iso + 1u) && ir == sat(x->iso_rst + 1u),
             "%s down to %s: clk>iso %u iso>rst %u for %u %u", nm(d), mn(m[d]), ci, ir,
             x->clken_iso, x->iso_rst);
        }
      }
    }
  }
  for (unsigned d = 0; d < ND; d++) CK(O(d, OBS_SPACINGS) > 0u, "%s: no spacing measured", nm(d));
  home();                                      /* restores pd_dev_delays */
}

/* ===========================================================================
 * EDT.STATIC -- power mode entry delays, static (4.1.3, Figure 4-10): the
 * start latency, PWPR write to DEVQREQn falling, grows by exactly D + 1 for a
 * delay of D. The OFF field on ACC1, MEM_RET on ACC0, FULL_RET on CPU0 (its
 * program loaded and asleep, DEVREQEN = 1, so there is a handshake to time).
 * MEM_OFF and FUNC_RET do not exist here.
 * ========================================================================= */
static void edt3(unsigned d, uint8_t off, uint8_t mret, uint8_t full)
{
  W(d, PPU_EDTR0, (uint32_t)full << 24 | (uint32_t)mret << 8 | off);
}

static bool cpu0_asleep(void)
{
  uint32_t t0 = sim_cycle();
  while (!(mmio_read32(SOC4_CTRL_CPU_STAT) & SOC4_CPU_STAT_SLEEP(0)))
    if (sim_cycle() - t0 > 5000u) return false;
  return true;
}

static void f_edt_sta(void)
{
  static const struct { uint8_t d, x; } T[3] = { { ACC1, M_OFF }, { ACC0, M_MRET }, { CPU0, M_FULL } };
  CK(cpu_boot(CPU0) && cpu_bind(CPU0, true), "CPU0 running, DEVREQEN = 1");
  for (unsigned k = 0; k < 3; k++) {
    unsigned d = T[k].d, x = T[k].x, D = 30u + 20u * k;
    CK(go(d, M_ON), "ON");
    edt3(d, x == M_OFF ? 0 : 200, x == M_MRET ? 0 : 200, x == M_FULL ? 0 : 200);
    if (d == CPU0) CK(cpu0_asleep(), "CPU0 not asleep");
    CK(go(d, x), "%s", mn(x));
    uint32_t l0 = O(d, OBS_LAT_WR);
    CK(go(d, M_ON), "ON");
    edt3(d, x == M_OFF ? D : 0, x == M_MRET ? D : 0, x == M_FULL ? D : 0);
    if (d == CPU0) CK(cpu0_asleep(), "CPU0 not asleep");
    CK(go(d, x), "%s", mn(x));
    uint32_t l1 = O(d, OBS_LAT_WR);
    CK(l1 - l0 == D + 1u, "%s ON->%s static: %u cycles with delay %u, %u with 0", nm(d), mn(x),
       l1, D, l0);
    con_printf("  static  ON->%-8s delay %3u: start latency %3u (%u + %u)\n", mn(x), D, l1, l0,
               l1 - l0);
  }
  home();
}

/* Not applied to a higher-priority mode, nor between ON and WARM_RST (4.1.3:
   "These delays apply for transitions to a lower priority power mode, except
   ... From WARM_RST to ON"). Timed by the cycle counter. */
static void f_edt_scope(void)
{
  unsigned d = ACC1;
  uint32_t t[2], w[2], r[2];
  for (unsigned k = 0; k < 2; k++) {
    uint8_t v = k ? 200 : 0;
    CK(go(d, M_OFF), "OFF");
    edt3(d, v, v, v);
    uint32_t t0 = sim_cycle();
    W(d, PPU_PWPR, M_ON);
    CK(wait_mode(d, M_ON, TMO), "ON");
    t[k] = sim_cycle() - t0;
    delay(40);
    t0 = sim_cycle();
    W(d, PPU_PWPR, M_WARM);
    CK(wait_mode(d, M_WARM, TMO), "WARM_RST");
    w[k] = sim_cycle() - t0;
    delay(40);
    t0 = sim_cycle();
    W(d, PPU_PWPR, M_ON);
    CK(wait_mode(d, M_ON, TMO), "ON");
    r[k] = sim_cycle() - t0;
    delay(40);
  }
  CK(t[1] < t[0] + 16u, "OFF->ON took %u cycles with every delay 200, %u with 0", t[1], t[0]);
  CK(w[1] < w[0] + 16u, "ON->WARM_RST took %u cycles with delays 200, %u with 0", w[1], w[0]);
  CK(r[1] < r[0] + 16u, "WARM_RST->ON took %u cycles with delays 200, %u with 0", r[1], r[0]);
  home();
}

/* The count restarts when its conditions go away mid-count (DEVQACTIVE raised,
   PWR_DEVACTIVEEN = 1), and a value reprogrammed mid-count is used only from
   the next count (4.1.3, Figure 4-10). Static OFF on ACC1, timed at the pins
   from the last DEVQACTIVE fall to DEVQREQn falling (OBS_LAT_ACT). */
static void f_edt_restart(void)
{
  unsigned d = ACC1;
  edt3(d, 100, 0, 0);
  CK(go(d, M_ON), "ON");
  wake(d, true);
  W(d, PPU_PWPR, M_OFF);
  delay(100);
  wake(d, false);
  CK(wait_mode(d, M_OFF, TMO), "OFF");
  uint32_t lf = O(d, OBS_LAT_ACT);
  CK(go(d, M_ON), "ON");
  snap(d);
  wake(d, true);
  W(d, PPU_PWPR, M_OFF);
  delay(50);
  wake(d, false); delay(45); wake(d, true); delay(15); wake(d, false);
  CK(wait_mode(d, M_OFF, TMO), "OFF after the blip");
  uint32_t lr = O(d, OBS_LAT_ACT);
  CK(lr == lf && dl(d, OBS_QREQ_FALLS) == 1u,
     "restart: %u cycles from the last fall, a full count is %u; %u requests", lr, lf,
     dl(d, OBS_QREQ_FALLS));
  CK(go(d, M_ON), "ON");
  wake(d, true);
  W(d, PPU_PWPR, M_OFF);
  delay(50);
  wake(d, false); delay(30);
  edt3(d, 5, 0, 0);
  CK(wait_mode(d, M_OFF, TMO), "OFF");
  uint32_t lp = O(d, OBS_LAT_ACT);
  CK(go(d, M_ON), "ON");
  wake(d, true);
  W(d, PPU_PWPR, M_OFF);
  delay(50);
  wake(d, false);
  CK(wait_mode(d, M_OFF, TMO), "OFF");
  uint32_t ln = O(d, OBS_LAT_ACT);
  CK(lp == lf && ln + 95u == lf, "reprogrammed 100 -> 5 mid-count: that count %u (full %u), next %u",
     lp, lf, ln);
  con_printf("  OFF_DEL 100: %u cycles; after a blip %u; reprogrammed mid-count %u; next count %u\n",
             lf, lr, lp, ln);
  home();
}

/* ===========================================================================
 * PCSM.RR -- PCSMPSTATE per Table 4-12: the retention byte of the mode being
 * entered (PPU_FULRR on CPU0, PPU_MEMRR on ACC0), 0 for every other mode, [7:4]
 * zero, [3:0] the mode
 * ========================================================================= */
static void f_pcsm_rr(void)
{
  ret_ram(0x00, 0x41, 0x83);
  static const uint8_t RRV[ND] = { 0x41, 0, 0x83, 0 };
  static const uint8_t SEQ[4] = { M_ON, 0xFF /* each its LP mode */, M_ON, M_OFF };
  uint8_t m[ND];
  for (unsigned s = 0; s < 4; s++) {
    if (SEQ[s] == 0xFF) memcpy(m, LP, ND); else fill(m, SEQ[s]);
    CK(go_all(ALLD, m), "step %u", s);
    for (unsigned d = 0; d < ND; d++) {
      unsigned x = m[d];
      uint32_t rr = (x == M_FULL || x == M_MRET) ? RRV[d] : 0u;
      uint32_t want = rr << 8 | x, got = O(d, OBS_PCSM_REQ);
      CK(got == want && OBS_LIVE_PSTATE(O(d, OBS_LIVE)) == want,
         "%s entering %s: PCSMPSTATE %04x, Table 4-12 %04x", nm(d), mn(x), got, want);
      sim_check(d, x);
    }
  }
  home();
}

/* ===========================================================================
 * PCSM.RAM -- the retention byte reaches the RAM (5.2.16-5.2.18; one enable
 * per bank, ppu_pcsm.sv:643-660), checked on the always-on arrays (OBS_RAM):
 *   ACC0 MEMRR 0xA5 keeps exactly banks 0, 2, 5, 7 through MEM_RET; 0xFF all;
 *        WARM_RST keeps all; ACC1 OFF keeps none
 *   CPU0 FULRR bit 0 = 1 keeps its RAM through FULL_RET: the warm resume works
 *        (a wake, the signature dumped); 0 loses it, and the next ON runs the
 *        cold sequence, fetch off first, so the core never runs from X
 * ========================================================================= */
#define RAM_OK(v)    ((v) & 0xFFu)
#define RAM_LOST(v)  (((v) >> 8) & 0xFFu)
#define RAM_VALID(v) (((v) >> 16) & 1u)

static void acc_ram(unsigned d, unsigned x, uint8_t rr, uint8_t ok, uint8_t lost, uint8_t seed)
{
  CK(go(d, M_ON), "%s ON", nm(d));
  if (d == ACC0) ret_ram(0x00, 0xFF, rr);
  acc_fill(d, seed);
  uint32_t v = O(d, OBS_RAM);
  CK(RAM_VALID(v) && RAM_OK(v) == 0xFFu, "%s: the fill did not take: %05x", nm(d), v);
  CK(go(d, x), "%s %s", nm(d), mn(x));
  sim_check(d, x);
  CK(go(d, M_ON), "%s ON", nm(d));
  v = O(d, OBS_RAM);
  CK(RAM_VALID(v) && RAM_OK(v) == ok && RAM_LOST(v) == lost,
     "%s through %s with rr %02x: banks intact %02x lost %02x, expected %02x %02x", nm(d), mn(x),
     rr, RAM_OK(v), RAM_LOST(v), ok, lost);
}

static void f_pcsm_ram(void)
{
  acc_ram(ACC0, M_MRET, 0xA5, 0xA5, 0x5A, 0x5A);
  acc_ram(ACC0, M_MRET, 0xFF, 0xFF, 0x00, 0x6B);
  acc_ram(ACC0, M_WARM, 0x00, 0xFF, 0x00, 0x7C);
  acc_ram(ACC1, M_OFF,  0x00, 0x00, 0xFF, 0xC3);
  /* CPU0 */
  CK(cpu_boot(CPU0) && cpu_bind(CPU0, true), "CPU0 running, DEVREQEN = 1");
  ret_ram(0x00, 0x01, 0xFF);
  CK(cpu0_asleep(), "CPU0 not asleep");
  uint32_t w0 = ld_rd(CPU0, SOC4_CPU_WAKES);
  CK(go(CPU0, M_FULL), "FULL_RET, FULRR 0x01");
  uint32_t v = O(CPU0, OBS_RAM);
  CK(RAM_VALID(v) && (RAM_OK(v) & 1u) && !(RAM_LOST(v) & 1u), "CPU0 RAM in FULL_RET: %05x", v);
  CK(go(CPU0, M_ON), "warm ON");
  uint32_t t0 = sim_cycle();
  while (ld_rd(CPU0, SOC4_CPU_WAKES) == w0 && sim_cycle() - t0 < 20000u) { }
  bool sig = ld_rd(CPU0, SOC4_CPU_WAKES) == w0 + 1u && ld_rd(CPU0, SOC4_CPU_TRAP) == 0u;
  for (unsigned i = 0; i < 12; i++)
    sig = sig && ld_rd(CPU0, SOC4_CPU_DUMP + 4u * i) == (uint32_t)SOC4_CPU_SIG(i, 0);
  CK(sig, "CPU0 after FULL_RET: wakes %u (was %u), the signature not intact",
     ld_rd(CPU0, SOC4_CPU_WAKES), w0);
  ret_ram(0x00, 0x00, 0xFF);
  CK(cpu0_asleep(), "CPU0 not asleep");
  CK(go(CPU0, M_FULL), "FULL_RET, FULRR 0x00");
  v = O(CPU0, OBS_RAM);
  CK(RAM_VALID(v) && (RAM_LOST(v) & 1u), "CPU0 RAM kept in FULL_RET with FULRR 0: %05x", v);
  CK(cpu_boot(CPU0), "the cold sequence after a lost RAM");
  CK(ld_rd(CPU0, SOC4_CPU_BOOTS) == 1u, "CPU0 boots %u after the reload", ld_rd(CPU0, SOC4_CPU_BOOTS));
  home();
}

/* ===========================================================================
 * CLK -- the PPU's own clock (PCK-600 clock Q-Channel, not DEN 0051E): it gates
 * when the PPU is idle, and every register access still completes
 * ========================================================================= */
static void f_clk(void)
{
  unsigned d = ACC1;
  uint32_t g0 = O(d, OBS_CLK_GATES);
  (void)R(d, PPU_AIDR);
  delay(300);
  uint32_t g1 = O(d, OBS_CLK_GATES);
  CK(g1 > g0, "the PPU clock was not gated again after an access");
  CK(R(d, PPU_AIDR) == 0x11u, "an access to a clock-gated PPU");
  uint32_t tot = 0;
  for (unsigned i = 0; i < ND; i++) {
    uint32_t g = O(i, OBS_CLK_GATES);
    CK(g > 0u, "%s: PPU clock never gated", nm(i));
    tot += g;
  }
  con_printf("  the four PPU clocks have been gated %u times so far\n", tot);
}

/* ===========================================================================
 * FW.STATES -- the manager (mod/pd.c) driving every static mode of every
 * domain through its interrupt path: pd_request_static() and pd_complete(),
 * with the PPU inputs taken through the interrupt block and serviced by
 * pd_poll()
 * ========================================================================= */
static void f_fw(void)
{
  scp_irq_unmask(ppu_ins());
  irq_enable();
  static const uint8_t SEQ[ND][6] = {
    { M_ON, M_FULL, M_ON, M_WARM, M_ON, M_OFF }, { M_ON, M_WARM, M_ON, M_OFF, M_OFF, M_OFF },
    { M_ON, M_MRET, M_ON, M_WARM, M_ON, M_OFF }, { M_ON, M_WARM, M_ON, M_OFF, M_OFF, M_OFF },
  };
  unsigned n = 0;
  uint32_t ev0 = 0;
  for (unsigned d = 0; d < ND; d++) ev0 += pd_tab[d].ev.policy_trn;
  for (unsigned i = 0; i < 6; i++)
    for (unsigned d = 0; d < ND; d++) {
      unsigned m = SEQ[d][i];
      uint32_t trn0 = pd_tab[d].ev.policy_trn;
      bool same = MODE(d) == m && R(d, PPU_PWPR) == m;
      int rc = pd_request_static(d, (enum ppu_mode)m, TMO);
      if (rc == PD_PENDING) rc = pd_complete(d);
      CK(rc == PD_OK, "%s -> %s: %s", nm(d), mn(m), pd_err_name(rc));
      /* A short request may complete inside pd_request_static() itself, before
         its interrupt; the event is then taken here. A request for the
         programming already in force writes nothing (mod/pd.c, start). */
      pd_sleep(100);
      CK(pd_tab[d].ev.policy_trn - trn0 == (same ? 0u : 1u), "%s -> %s: %u STA_POLICY_TRN taken",
         nm(d), mn(m), pd_tab[d].ev.policy_trn - trn0);
      CK(R(d, PPU_PWPR) == m && MODE(d) == m, "%s %s: PWPR %08x PWSR %08x", nm(d), mn(m),
         R(d, PPU_PWPR), R(d, PPU_PWSR));
      sim_check(d, m);
      n++;
    }
  pd_sleep(200);
  uint32_t sp = 0, ev = 0;
  for (unsigned d = 0; d < ND; d++) { sp += pd_tab[d].ev.spurious; ev += pd_tab[d].ev.policy_trn; }
  CK(sp == 0u, "%u spurious interrupts", sp);
  CK(ev - ev0 == 20u, "%u STA_POLICY_TRN taken by the handler path, expected 20", ev - ev0);
  irq_disable();
  scp_irq_mask(ppu_ins());
  con_printf("  %u static requests through the manager; lines serviced %u %u %u %u, "
             "STA_POLICY_TRN %u\n", n, pd_tab[0].ev.lines, pd_tab[1].ev.lines, pd_tab[2].ev.lines,
             pd_tab[3].ev.lines, ev - ev0);
  home();
}

/* ===========================================================================
 * pd_multi (the check ID of the conformance table's row, named after the
 * retired 12-domain test) -- refused and reverted writes reported as such by
 * the driver and
 * the manager (README Section 6 rules 1-2): an unsupported policy is REFUSED
 * (PPU 4.1.1: the whole write is discarded); a denial is REVERTED / DENIED
 * (Table 4-1)
 * ========================================================================= */
static void f_pd_multi(void)
{
  CK(go(CPU0, M_ON), "CPU0 ON");
  uint32_t u0 = O(CPU0, OBS_EV_UNSPT);
  CK(ppu_set_policy(pp(CPU0), PPU_MODE_MEM_RET, false, false) == PPU_E_REFUSED,
     "driver: MEM_RET on CPU0 not REFUSED");
  CK(pd_request_static(CPU0, PPU_MODE_MEM_RET, TMO) == PD_E_REFUSED,
     "manager: MEM_RET on CPU0 not REFUSED");
  CK(O(CPU0, OBS_EV_UNSPT) - u0 == 2u && MODE(CPU0) == M_ON && R(CPU0, PPU_PWPR) == M_ON,
     "CPU0: %u UNSPT, %s", O(CPU0, OBS_EV_UNSPT) - u0, mn(MODE(CPU0)));
  unsigned d = ACC1;
  CK(go(d, M_ON), "ACC1 ON");
  hold(d, true); deny(d, true);
  int rc = pd_request_static(d, PPU_MODE_OFF, TMO);   /* clears PWR_DEVACTIVEEN: the device is asked */
  if (rc == PD_PENDING) rc = pd_complete(d);
  CK(rc == PD_E_DENIED && MODE(d) == M_ON && R(d, PPU_PWPR) == M_ON,
     "manager: a denied OFF ended %s, %s", pd_err_name(rc), mn(MODE(d)));
  hold(d, false); deny(d, false);
  delay(100);
  W(d, PPU_PWCR, 0x101u);
  home();
}

/* ===========================================================================
 * S.CPUQ (soc4) -- the CPU Q-Channel adapter (decision 7; soc4_cpu_adp.sv): a
 * quiescence request is accepted only with the core in WFI and nothing
 * outstanding; an awake core denies (CPU1 never sleeps, so it always does);
 * hold_busy makes a CPU's request wait instead (busy, deny suppressed); leaving
 * Q_STOPPED pulses the wake that ends CPU0's WFI
 * ========================================================================= */
static void f_cpuq(void)
{
  CK(cpu_boot(CPU0) && cpu_boot(CPU1), "both CPUs running");
  CK(cpu_bind(CPU0, true) && cpu_bind(CPU1, true), "DEVREQEN = 1 on both");
  CK(cpu0_asleep(), "CPU0 not asleep");
  uint32_t st = mmio_read32(SOC4_CTRL_CPU_STAT);
  CK((st & 3u) == SOC4_CPU_STAT_SLEEP(0), "CPU_STAT sleep %x: CPU0 in WFI, CPU1 awake", st & 3u);
  /* CPU0 asleep: accepted */
  snap(CPU0);
  uint32_t w0 = ld_rd(CPU0, SOC4_CPU_WAKES);
  uint32_t t0 = st & SOC4_CPU_STAT_WAKE(0);
  CK(go(CPU0, M_FULL), "CPU0 FULL_RET");
  CK(dl(CPU0, OBS_QREQ_FALLS) == 1u && dl(CPU0, OBS_EV_SDENY) == 0u, "CPU0: %u requests %u denials",
     dl(CPU0, OBS_QREQ_FALLS), dl(CPU0, OBS_EV_SDENY));
  sim_check(CPU0, M_FULL);
  CK(go(CPU0, M_ON), "CPU0 ON");
  uint32_t tw = sim_cycle();
  while (ld_rd(CPU0, SOC4_CPU_WAKES) == w0 && sim_cycle() - tw < 20000u) { }
  CK(ld_rd(CPU0, SOC4_CPU_WAKES) == w0 + 1u, "CPU0 did not wake once: %u -> %u", w0,
     ld_rd(CPU0, SOC4_CPU_WAKES));
  CK((mmio_read32(SOC4_CTRL_CPU_STAT) & SOC4_CPU_STAT_WAKE(0)) != t0, "no wake pulse counted");
  /* CPU1 awake: denied, the policy reverted to ON (Table 4-1) */
  snap(CPU1); clr(CPU1);
  W(CPU1, PPU_PWCR, 0x001u);
  W(CPU1, PPU_PWPR, M_OFF);
  delay(300);
  CK(MODE(CPU1) == M_ON && R(CPU1, PPU_PWPR) == M_ON && dl(CPU1, OBS_EV_SDENY) == 1u,
     "CPU1: %s, PWPR %08x, %u denials", mn(MODE(CPU1)), R(CPU1, PPU_PWPR), dl(CPU1, OBS_EV_SDENY));
  /* CPU0 under hold_busy: the request waits in Q_REQUEST, no denial */
  CK(cpu0_asleep(), "CPU0 not asleep");
  hold(CPU0, true);
  W(CPU0, PPU_PWCR, 0x001u);
  snap(CPU0);
  W(CPU0, PPU_PWPR, M_FULL);
  delay(1000);
  CK(MODE(CPU0) == M_ON && !(O(CPU0, OBS_LIVE) & OBS_LIVE_QREQN) && dl(CPU0, OBS_EV_SDENY) == 0u,
     "CPU0 held: %s, live %08x, %u denials", mn(MODE(CPU0)), O(CPU0, OBS_LIVE),
     dl(CPU0, OBS_EV_SDENY));
  hold(CPU0, false);
  CK(wait_mode(CPU0, M_FULL, TMO), "CPU0 FULL_RET once released");
  home();
}

/* ===========================================================================
 * S.LOAD (soc4) -- the CPU RAM load port (decision 5; soc4_cpu_ram.sv): it
 * works in WARM_RST and ON; in any other mode an access errors (a load or
 * store access fault) and reaches no RAM; CPU_STAT shows it open or not
 * ========================================================================= */
static bool ld_fault(unsigned n, bool wr, uint32_t *mcause)
{
  struct trap_fault f;
  trap_expect_fault();
  if (wr) ld_wr(n, 0x100, 0x12345678u); else (void)ld_rd(n, 0x100);
  bool t = trap_take_fault(&f);
  *mcause = t ? f.mcause : 0;
  return t;
}

static void f_load(void)
{
  uint32_t mc;
  /* CPU1 in OFF */
  CK(!(mmio_read32(SOC4_CTRL_CPU_STAT) & SOC4_CPU_STAT_LDOPEN(1)), "CPU1 port open in OFF");
  CK(ld_fault(1, false, &mc) && mc == MCAUSE_LOAD_ACCESS, "OFF: load mcause %u", mc);
  CK(ld_fault(1, true, &mc) && mc == MCAUSE_STORE_ACCESS, "OFF: store mcause %u", mc);
  /* WARM_RST and ON (fetch off) */
  CK(go(CPU1, M_ON) && go(CPU1, M_WARM), "CPU1 WARM_RST");
  CK(mmio_read32(SOC4_CTRL_CPU_STAT) & SOC4_CPU_STAT_LDOPEN(1), "CPU1 port closed in WARM_RST");
  CK(!ld_fault(1, true, &mc), "WARM_RST: store faulted");
  CK(ld_rd(1, 0x100) == 0x12345678u, "WARM_RST: read back %08x", ld_rd(1, 0x100));
  ld_wr(1, 0x104, 0xCAFEF00Du);
  CK(go(CPU1, M_ON), "CPU1 ON");
  CK(mmio_read32(SOC4_CTRL_CPU_STAT) & SOC4_CPU_STAT_LDOPEN(1), "CPU1 port closed in ON");
  CK(ld_rd(1, 0x100) == 0x12345678u && ld_rd(1, 0x104) == 0xCAFEF00Du, "ON: read back %08x %08x",
     ld_rd(1, 0x100), ld_rd(1, 0x104));
  /* byte enables */
  *(volatile uint8_t *)(uintptr_t)(SOC4_LD_BASE(1) + 0x101) = 0xAB;
  CK(ld_rd(1, 0x100) == 0x1234AB78u, "byte store: %08x", ld_rd(1, 0x100));
  /* CPU0 in FULL_RET: closed */
  CK(go(CPU0, M_ON) && go(CPU0, M_FULL), "CPU0 FULL_RET");
  CK(!(mmio_read32(SOC4_CTRL_CPU_STAT) & SOC4_CPU_STAT_LDOPEN(0)), "CPU0 port open in FULL_RET");
  CK(ld_fault(0, false, &mc) && mc == MCAUSE_LOAD_ACCESS, "FULL_RET: load mcause %u", mc);
  /* an unmapped address in the ext window */
  trap_expect_fault();
  (void)mmio_read32(0x0002A000u);
  struct trap_fault f;
  CK(trap_take_fault(&f) && f.mcause == MCAUSE_LOAD_ACCESS, "ext 0x0002_A000 did not fault");
  home();
}

/* ===========================================================================
 * S.CPUBOOT (soc4) -- the cold sequence boots at CPUn_BOOT (decision 6;
 * mod/soc4_cpu.h): with FETCH_EN = 0 the core stays put out of reset; with it
 * set the core runs from CPUn_BOOT + 0x80; CPUn_BOOT[7:0] read 0; a WARM_RST of
 * a running CPU1 restarts it from its boot address with its RAM kept
 * ========================================================================= */
static void f_cpuboot(void)
{
  mmio_write32(SOC4_CTRL_CPU_BOOT(1), 0xFFFFFFFFu);
  CK(mmio_read32(SOC4_CTRL_CPU_BOOT(1)) == 0xFFFFFF00u, "CPU1_BOOT reads %08x",
     mmio_read32(SOC4_CTRL_CPU_BOOT(1)));
  mmio_write32(SOC4_CTRL_CPU_BOOT(1), SOC4_CPU_BOOT);
  cpu_fetch(1, false);
  CK(go(CPU1, M_ON) && go(CPU1, M_WARM), "CPU1 WARM_RST");
  CK(cpu_load(1) == 0, "load");
  CK(go(CPU1, M_ON), "ON, fetch off");
  delay(2000);
  CK(ld_rd(1, SOC4_CPU_MARKER) == 0u && ld_rd(1, SOC4_CPU_BOOTS) == 0u,
     "CPU1 ran with FETCH_EN = 0: marker %08x", ld_rd(1, SOC4_CPU_MARKER));
  cpu_fetch(1, true);
  uint32_t t0 = sim_cycle();
  while (ld_rd(1, SOC4_CPU_MARKER) != (SOC4_CPU_MAGIC | 1u) && sim_cycle() - t0 < 20000u) { }
  CK(ld_rd(1, SOC4_CPU_MARKER) == (SOC4_CPU_MAGIC | 1u) && ld_rd(1, SOC4_CPU_BOOTS) == 1u &&
     ld_rd(1, SOC4_CPU_TRAP) == 0u, "CPU1 boot: marker %08x boots %u trap %x",
     ld_rd(1, SOC4_CPU_MARKER), ld_rd(1, SOC4_CPU_BOOTS), ld_rd(1, SOC4_CPU_TRAP));
  uint32_t c1 = ld_rd(1, SOC4_CPU_COUNT);
  delay(1000);
  uint32_t c2 = ld_rd(1, SOC4_CPU_COUNT);
  CK(c2 > c1, "CPU1 COUNT %u -> %u", c1, c2);
  /* WARM_RST of the running core: no handshake (PTCR 0), RAM kept */
  CK(go(CPU1, M_WARM), "WARM_RST");
  sim_check(CPU1, M_WARM);
  CK(go(CPU1, M_ON), "ON");
  t0 = sim_cycle();
  while (ld_rd(1, SOC4_CPU_BOOTS) != 2u && sim_cycle() - t0 < 20000u) { }
  uint32_t c3 = ld_rd(1, SOC4_CPU_COUNT);
  CK(ld_rd(1, SOC4_CPU_BOOTS) == 2u && c3 < c2, "CPU1 after WARM_RST: boots %u, COUNT %u (was %u)",
     ld_rd(1, SOC4_CPU_BOOTS), c3, c2);
  /* CPU0 through the whole cold sequence */
  CK(cpu_boot(CPU0), "CPU0 cold");
  CK(ld_rd(0, SOC4_CPU_BOOTS) == 1u && ld_rd(0, SOC4_CPU_TRAP) == 0u, "CPU0 boots %u trap %x",
     ld_rd(0, SOC4_CPU_BOOTS), ld_rd(0, SOC4_CPU_TRAP));
  home();
}

/* ===========================================================================
 * S.LOCKREQ (soc4) -- a LOCK_EN request on a PPU without LOCK_SPT (IDR1 b2 =
 * 0, Table 5-27): the driver answers PPU_E_UNSUPPORTED without writing
 * (ppu_v1.c:108); a raw write with LOCK_EN set is admitted with it reading 0
 * (reserved, ppu_regs.sv:326), no UNSPT_POLICY, no lock
 * ========================================================================= */
static void f_lockreq(void)
{
  unsigned d = ACC1;
  snap(d); clr(d);
  CK(ppu_set_policy(pp(d), PPU_MODE_ON, false, true) == PPU_E_UNSUPPORTED, "driver did not refuse");
  delay(40);
  CK(R(d, PPU_PWPR) == M_OFF && MODE(d) == M_OFF && dl(d, OBS_EV_TRN) == 0u &&
     dl(d, OBS_EV_UNSPT) == 0u, "the driver wrote: PWPR %08x", R(d, PPU_PWPR));
  W(d, PPU_PWPR, M_OFF | LCK);
  delay(40);
  CK(R(d, PPU_PWPR) == M_OFF && !(R(d, PPU_PWSR) & PPU_PWSR_LOCK_STATUS) &&
     dl(d, OBS_EV_UNSPT) == 0u && dl(d, OBS_EV_TRN) == 1u,
     "{OFF, LOCK_EN}: PWPR %08x PWSR %08x, %u UNSPT %u TRN", R(d, PPU_PWPR), R(d, PPU_PWSR),
     dl(d, OBS_EV_UNSPT), dl(d, OBS_EV_TRN));
  W(d, PPU_PWPR, M_ON | LCK);
  CK(wait_mode(d, M_ON, TMO) && R(d, PPU_PWPR) == M_ON && dl(d, OBS_EV_UNSPT) == 0u,
     "{ON, LOCK_EN}: PWPR %08x", R(d, PPU_PWPR));
  home();
}

/* ===========================================================================
 * S.DYNREQ (soc4) -- a raw PWPR write {m, PWR_DYN_EN} with m statically
 * supported: PWR_DYN_EN is reserved on a PPU with no dynamic mode (DEN 0051E
 * Table 5-2; WI/RAZ, Section 5.2), so it is masked (ppu_regs.sv:325), admission
 * sees static m (:332), m takes effect, no UNSPT_POLICY. The driver's
 * ppu_set_policy(m, dyn = true) therefore refuses before writing
 * (PPU_E_UNSUPPORTED, IDR0 [29:20] all 0) and the PPU is untouched. Until the
 * fix of 2026-10-05 it wrote, m took effect, and it answered PPU_E_REFUSED: a
 * DEVIATION, the driver finding of Section 15.2-21
 * ========================================================================= */
static void f_dynreq(void)
{
  unsigned d = ACC1;
  snap(d);
  W(d, PPU_PWPR, M_ON | DYN);
  CK(wait_mode(d, M_ON, TMO) && R(d, PPU_PWPR) == M_ON &&
     !(R(d, PPU_PWSR) & PPU_PWSR_DYN_STATUS) && dl(d, OBS_EV_UNSPT) == 0u,
     "{ON, PWR_DYN_EN}: PWPR %08x PWSR %08x, %u UNSPT", R(d, PPU_PWPR), R(d, PPU_PWSR),
     dl(d, OBS_EV_UNSPT));
  delay(40);
  snap(d);
  int rc = ppu_set_policy(pp(d), PPU_MODE_OFF, true, false);
  delay(40);
  CK(rc == PPU_E_UNSUPPORTED && R(d, PPU_PWPR) == M_ON && MODE(d) == M_ON &&
     dl(d, OBS_EV_TRN) == 0u && dl(d, OBS_EV_UNSPT) == 0u,
     "ppu_set_policy(OFF, dyn) on a static-only PPU returned %d; PWPR %08x, %s, %u TRN %u UNSPT",
     rc, R(d, PPU_PWPR), mn(MODE(d)), dl(d, OBS_EV_TRN), dl(d, OBS_EV_UNSPT));
  home();
}

/* ===========================================================================
 * SOAK -- constrained random, all four domains at once: static policies,
 * refused writes, ACC wakes, bursts and denials, hold_busy, PWR_DEVACTIVEEN,
 * entry delays. Every so often the stimulus stops and each domain must settle
 * where its policy says (a denial reverts the policy, so that holds too), and
 * every refused write must have raised exactly one UNSPT_POLICY. soc4_tb checks
 * every hop throughout.
 * ========================================================================= */
static uint32_t rs = 0x5EED1234u;
static uint32_t rnd(void) { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return rs; }
static unsigned rn(unsigned n) { return rnd() % n; }

#define SOAK_OPS    2000u
#define SOAK_SETTLE 80u

static uint32_t uns[ND];

static void soak_settle(unsigned round)
{
  wake_mask(0);
  if (hold_m) { hold_m = 0; tb_cmd(SOC4_TB_HOLD); }
  if (deny_m) { deny_m = 0; tb_cmd(SOC4_TB_DENY); }
  delay(400);
  uint32_t t0 = sim_cycle(), left = ALLD;
  while (left && sim_cycle() - t0 < 60000u)
    for (unsigned d = 0; d < ND; d++)
      if (((left >> d) & 1u) && MODE(d) == (R(d, PPU_PWPR) & 0xFu)) left &= ~(1u << d);
  CK(left == 0u, "settle %u: domains %x never settled", round, left);
  delay(100);
  for (unsigned d = 0; d < ND; d++) {
    sim_check(d, MODE(d));
    CK(dl(d, OBS_EV_UNSPT) == uns[d], "%s: %u UNSPT events for %u refused writes", nm(d),
       dl(d, OBS_EV_UNSPT), uns[d]);
    uns[d] = 0;
    snap(d);
    clr(d);
  }
}

static void f_soak(void)
{
  unsigned cnt[9];
  memset(cnt, 0, sizeof cnt);
  memset(uns, 0, sizeof uns);
  uint32_t h0 = 0;
  for (unsigned d = 0; d < ND; d++) { snap(d); h0 += O(d, OBS_HOPS); }
  con_printf("  seed 0x%08x, %u operations, settled every %u\n", rs, SOAK_OPS, SOAK_SETTLE);
  for (unsigned i = 0; i < SOAK_OPS; i++) {
    unsigned d = rn(ND), r = rn(100);
    if (r < 35) {
      W(d, PPU_PWPR, MS[d][rn(NM[d])]);                                     cnt[0]++;
    } else if (r < 42) {
      unsigned v;
      do v = rn(16); while ((STA[d] >> v) & 1u);
      W(d, PPU_PWPR, v | (rn(2) ? DYN : 0u) | (rn(2) ? LCK : 0u));
      uns[d]++;                                                             cnt[1]++;
    } else if (r < 54 && !is_cpu(d)) {
      wake(d, !((wk >> d) & 1u));                                           cnt[2]++;
    } else if (r < 64 && !is_cpu(d)) {
      sim_light(rn(4) == 0 ? (1u << d) : 0u);
      sim_work_len(20 + rn(600));
      sim_start(1u << d);                                                   cnt[3]++;
    } else if (r < 69 && !is_cpu(d)) {
      deny(d, rn(10) < 3);                                                  cnt[4]++;
    } else if (r < 74) {
      hold(d, !((hold_m >> d) & 1u));                                       cnt[5]++;
    } else if (r < 81) {
      W(d, PPU_PWCR, (is_cpu(d) ? 0u : 1u) | (rn(4) ? 0x100u : 0u));        cnt[6]++;
    } else if (r < 90) {
      uint8_t v = (uint8_t)rn(41);
      edt3(d, v, v, v);                                                     cnt[7]++;
    } else {
      delay(rn(300));                                                       cnt[8]++;
    }
    if ((i + 1) % SOAK_SETTLE == 0) soak_settle((i + 1) / SOAK_SETTLE);
  }
  uint32_t h1 = 0;
  for (unsigned d = 0; d < ND; d++) h1 += O(d, OBS_HOPS);
  con_printf("  static %u refused %u wake %u burst %u deny %u hold %u devactive %u delay %u idle %u\n",
             cnt[0], cnt[1], cnt[2], cnt[3], cnt[4], cnt[5], cnt[6], cnt[7], cnt[8]);
  con_printf("  %u hops committed across the four domains, %u settle checkpoints\n", h1 - h0,
             SOAK_OPS / SOAK_SETTLE);
  sim_light(0);
  home();
}

/* ===========================================================================
 * The run
 * ========================================================================= */
int main(void)
{
  con_puts("\nsoc4_stress -- the SCP firmware against the Arm PPU architecture (DEN 0051E), soc4\n");
  timer_init();                                /* MTIE only; mstatus.MIE stays clear */
  if (scp_irq_init() != 0) {                   /* the input table; PPU inputs masked */
    con_puts("soc4_stress: the interrupt block's input count is not the table's\n");
    return 1;
  }

  feature("RST",            f_rst);            /* before anything writes a PPU */
  feature("ID",             f_id);
  feature("REG.RW",         f_reg_rw);
  feature("REG.RO",         f_reg_ro);
  feature("REG.BYTE",       f_reg_byte);
  feature("REG.W1C",        f_w1c);
  feature("STA.MATRIX",     f_matrix);
  feature("EVT.PTRN1",      f_ptrn1);
  feature("STA.QACT",       f_qact);
  feature("STA.MIDWRITE",   f_midwrite);
  feature("DENY",           f_deny);
  feature("EVT.MASK",       f_mask);
  feature("EVT.EDGE",       f_edge);
  feature("EVT.EDGE_OFF",   f_edge_off);
  feature("EVT.UNSPT",      f_unspt);
  feature("EVT.LINES",      f_lines);
  feature("DEV.REQEN",      f_devreq);
  feature("DEV.WARM",       f_warm);
  feature("DEV.STATUS",     f_status);
  feature("DLY",            f_dly);
  feature("EDT.STATIC",     f_edt_sta);
  feature("EDT.SCOPE",      f_edt_scope);
  feature("EDT.RESTART",    f_edt_restart);
  feature("PCSM.RR",        f_pcsm_rr);
  feature("PCSM.RAM",       f_pcsm_ram);
  feature("CLK",            f_clk);
  feature("FW.STATES",      f_fw);
  feature("pd_multi",       f_pd_multi);
  feature("S.CPUQ",         f_cpuq);
  feature("S.LOAD",         f_load);
  feature("S.CPUBOOT",      f_cpuboot);
  feature("S.LOCKREQ",      f_lockreq);
  feature("S.DYNREQ",       f_dynreq);
  feature("SOAK",           f_soak);

  uint32_t tb_checks = sim_tb_checks(), tb_errors = sim_tb_errors();
  con_printf("\nsoc4_stress: %u features -- %u PASS, %u DEVIATION, %u FAIL; %u firmware checks;"
             " testbench %u checks, %u errors\n", n_pass + n_dev + n_fail, n_pass, n_dev, n_fail,
             sum_chk, tb_checks, tb_errors);
  return (int)(n_fail + tb_errors);
}
