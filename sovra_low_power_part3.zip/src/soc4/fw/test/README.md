# soc4 SCP test images

Two SCP images that test the platform rather than serve it. Both run on the
SCP with the AP held (the strap gives port 0 to the BFM, which does
nothing: `+bfm +bfm_only=none`), and both end the run through the
testbench's `HALT` register with their failure count.

## Files

| File | Image | Target |
|---|---|---|
| `soc4_stress.c` | `soc4_stress`: the SCP firmware against the Arm PPU architecture (DEN 0051E) on the four static-only PPUs | `make soc4stress`, `make soc4stresspa` |
| `soc4_wdog.c` | `soc4_wdog`: the SCP watchdog and the fault-log block kept across its resets | `make soc4wdog` |

## soc4_stress

34 features, one `RESULT` line each:

```
RESULT <id> <PASS|FAIL|DEVIATION> checks <n> fails <n> cycles <n>
```

and a summary line at the end. `DEVIATION` means the behaviour differs from
the spec or the driver's contract exactly as a recorded finding predicts; it
does not fail the run. None is expected (`S.DYNREQ` was one until the driver
fix of 2026-10-05). A feature also fails if the testbench recorded any error
while it ran. The image returns `FAIL count + TB_ERRORS`; the make target
additionally fails unless every `RESULT` line is PASS or DEVIATION.

The check IDs are the rows of `src/pmu/PPU_FW_CONFORMANCE.md` (the result
and the row-by-row mapping are its Sections A and B). 29 come from the
retired 12-domain `ppu_stress`; the five `S.*` rows are soc4-only. Features
that need what these PPUs lack (dynamic modes, the lock, `MEM_OFF`,
`FUNC_RET`, the direct `OFF → MEM_RET` hop) are left to the PPU unit
testbenches (conformance report Section C).

| # | ID | What it checks |
|---:|---|---|
| 1 | `RST` | Every register's reset value on the four PPUs before anything writes one; `IDR0`/`IDR1` per domain |
| 2 | `ID` | `pd_init` discovery: `AIDR`, `IDR0`/`IDR1`, `IIDR`, the decoded static mode sets, no dynamic mode, one channel, feature bits; the driver's support answer for every policy |
| 3 | `REG.RW` | Writable fields hold five patterns; reserved bits and absent retention registers are WI/RAZ; `LOCK_EN` and `PWR_DYN_EN` reserved |
| 4 | `REG.RO` | Read-only registers ignore writes; reserved registers (`PMER`, `STSR`, `OPSR`, `UNLK`) and unmapped offsets read 0 and do not fault |
| 5 | `REG.BYTE` | Byte and halfword writes change only their lanes; `PPU_PWPR` admission judges the merged value; `ISR` clears by lane |
| 6 | `REG.W1C` | `ISR`/`AISR` write-one-to-clear, `OTHER_IRQ` as `AISR`'s summary; the IRQ line at the pin and at the SCP interrupt block's input n |
| 7 | `STA.MATRIX` | Every ordered pair of each domain's static modes (12 + 6 + 12 + 6), all four domains at once on Eulerian circuits: route, handshake counts and events per hop |
| 8 | `EVT.PTRN1` | A policy equal to the current mode: no transition, one `STA_POLICY_TRN` |
| 9 | `STA.QACT` | DEVQACTIVE gating of static transitions, including the intermediate hop through `ON` |
| 10 | `STA.MIDWRITE` | A `PPU_PWPR` write does not interrupt a hop in progress (ACC0's down-hop held by hold_busy) |
| 11 | `DENY` | A static denial reverts the policy and touches no control, including the denial of the second hop of a route through `ON` |
| 12 | `EVT.MASK` | A masked event does not set its status bit and unmasking does not resurrect it |
| 13 | `EVT.EDGE` | The input edge event (none, rise, fall, both) on ACC1's wake; `PPU_DISR` follows the pin |
| 14 | `EVT.EDGE_OFF` | The same with `PWR_DEVACTIVEEN` clear and the PPU's own clock gated |
| 15 | `EVT.UNSPT` | Every unsupported and reserved static policy refused whole, one `UNSPT_POLICY` per write |
| 16 | `EVT.LINES` | PPU n is input n of `scp_irq` and no other; the handler path takes one line-11 interrupt per event |
| 17 | `DEV.REQEN` | `DEVREQEN = 0`: no handshake, transition still sequenced, a busy device's refusal ignored; the driver's rules |
| 18 | `DEV.WARM` | DEN 0051E Table 4-4: the `ON ↔ WARM_RST` handshake by (`DEVREQEN`, `WARM_RST_DEVREQEN`); never a PCSM handshake |
| 19 | `DEV.STATUS` | `PPU_DISR` follows DEVQACTIVE; `PPU_MISR` accept, deny and PCSM bits |
| 20 | `DLY` | Device control delays, three settings per domain, each spacing at the pins exactly value + 1 |
| 21 | `EDT.STATIC` | Static entry delays (`OFF` on ACC1, `MEM_RET` on ACC0, `FULL_RET` on CPU0): start latency grows by exactly D + 1 |
| 22 | `EDT.SCOPE` | Entry delays not applied to a higher-priority mode nor between `ON` and `WARM_RST` |
| 23 | `EDT.RESTART` | The count restarts when its conditions go away; a value reprogrammed mid-count applies from the next count |
| 24 | `PCSM.RR` | `PCSMPSTATE` per Table 4-12, with the retention byte of the mode being entered |
| 25 | `PCSM.RAM` | The retention byte reaches the RAM: ACC0 `MEMRR = 0xA5` keeps banks 0, 2, 5, 7; CPU0 `FULRR` bit 0 keeps or loses the CPU RAM (warm resume or cold sequence) |
| 26 | `CLK` | The PPU's own clock gates when idle and every register access still completes |
| 27 | `FW.STATES` | The domain manager (`pd_request_static`, `pd_complete`, `pd_poll`) drives every static mode of every domain through the interrupt path |
| 28 | `pd_multi` | Refused and reverted writes reported as such by driver and manager (REFUSED, DENIED/REVERTED) |
| 29 | `S.CPUQ` | The CPU Q-Channel adapter: accept only in WFI with nothing outstanding; CPU1 always denies; hold_busy waits; the wake pulse ends CPU0's WFI |
| 30 | `S.LOAD` | The CPU RAM load port works in `WARM_RST` and `ON` only; elsewhere an access faults and reaches no RAM; `CPU_STAT` shows it |
| 31 | `S.CPUBOOT` | The cold sequence boots at `CPUn_BOOT`; `FETCH_EN = 0` holds the core; `CPUn_BOOT[7:0]` read 0; `WARM_RST` restarts a running CPU1 with its RAM kept |
| 32 | `S.LOCKREQ` | A `LOCK_EN` request on a PPU without the lock: the driver refuses without writing; a raw write is admitted with `LOCK_EN` reading 0 |
| 33 | `S.DYNREQ` | `{m, PWR_DYN_EN}` with m static: the PPU takes static m; the driver refuses before writing (`PPU_E_UNSUPPORTED`) |
| 34 | `SOAK` | Constrained random on all four domains (seed `0x5EED1234`, 2000 operations, settle checkpoint every 80) |

Rules the test lives by:

- **Three views.** Each feature checks the registers (raw, through
  `hal/ppu_v1`), the pins (the testbench's observation window, `SIM_OBS_*`)
  and the spec tables (`soc4_tb` checks every hop and every `SIM_CHECK`).
- **The domains' software is simulated.** ACC k's wake, start, light, work
  length, IP command and seed are bits of the SCP's sim page; hold_busy and
  the ACC deny are testbench commands on `AP_CMD` (`SOC4_TB_HOLD`,
  `SOC4_TB_DENY`), applied and echoed on `AP_STAT`. CPU0 and CPU1 are the
  real cores running `cpu/cpu.S` once loaded.
- **The baseline.** Every feature starts from and returns to (`home()`):
  every domain static `OFF`, events unmasked, no edge event, every present
  retention bit set, no entry delay, the build's device control delays,
  `PTCR` 0; ACCs with both enables set; CPUs with `FETCH_EN = 0` and
  `DEVREQEN = 0`. A CPU that is not asleep denies every quiescence request,
  and must never fetch from a RAM that `OFF` lost, so CPU transitions are
  sequenced without a handshake except in the features that load and run the
  image (`S.CPUQ`, `EDT.STATIC`, `PCSM.RAM`, `S.CPUBOOT`), which set
  `DEVREQEN = 1` in `ON`.
- **PPU interrupts** stay masked in the interrupt block except where the
  interrupt path is under test; their level is read from `SCP_IRQ_RAW`. The
  image has no policy, so wake and bridge inputs are collected but never
  acted on.

The domain list, modes and expected IDs are hard-coded (`ND = 4`, `MS`,
`STA`, `LP`, `IDR0`, `IDR1`, `RST_TAB`): a platform with other domains needs
these tables edited. A new feature is a `static void f_x(void)` that leaves
the platform at the baseline, plus a `feature("ID", f_x)` line in `main()`
and a row in the conformance report.

## soc4_wdog

The image runs three times; the watchdog's `CAUSE` register, which only a
power-on reset clears, tells the runs apart.

| Phase | Entered on | Checks |
|---|---|---|
| A | power-on (`CAUSE = POR`) | Reset values (`CTRL` 0, `TIMEOUT` `0xFFFF_FFFF`, `COUNT` 0); a new persistent record; a wrong kick while disabled does nothing; enable loads `COUNT` and it falls; kicked every 1500 cycles for 6 timeouts with no reset; unlocked, `TIMEOUT` is writable and disabling stops `COUNT`; locked, writes to `CTRL` and `TIMEOUT` are ignored, `EN` and `LOCK` cannot be cleared, the kick still works, `COUNT` is read-only; an unmapped offset (`+0x14`) is a load access fault. Then a **wrong kick**, which must reset the SCP |
| B | `CAUSE = WDOG | BADKICK`, one reset | The watchdog back to reset values (off, unlocked); `.data` restored and `.bss` cleared by `crt0.S`; the record kept with phase A's entry and one watchdog reset. Then armed (5000 cycles) and **not kicked**, so it must expire |
| C | `CAUSE = WDOG`, two resets | The record kept with three entries in order: phase A's, the wrong kick's, the expiry's, each with its cause. Halt with the failure count |

A phase with a failure halts at its end instead of going on (`HALT`
`0xDEAD5700 | fails`). From the outside, the testbench (`+wdog_resets=2`)
checks that there were exactly two watchdog resets, each of the SCP
subsystem alone, and `CAUSE` as each boot found it. The image links no PPU
driver, policy or RPMI: only `crt0.S`, the console, string, timer, trap
handling and `mod/flog.c`.

## References

- [`src/pmu/PPU_FW_CONFORMANCE.md`](../../../pmu/PPU_FW_CONFORMANCE.md):
  the `soc4stress` result and the row-by-row table.
- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.2 H18 and §14.3 F12 (the
  watchdog and fault log), §15.2 phase 4.
- Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E);
  [`src/rtl/ppu/README.md`](../../../rtl/ppu/README.md).
- `src/pmu/fw/hal/scp_wdog.h`, `src/pmu/fw/mod/flog.h`, `src/pmu/fw/hal/sim.h`.
- Background only: [`docs/SOC4_DESIGN.md`](../../../../docs/SOC4_DESIGN.md) §10 (testbench) and
  §11.3.
