/* soc4_wdog -- the SCP watchdog's own test (make soc4wdog): the registers, the
 * kick, the lock, a wrong kick, an expiry, the reset cause, and the block kept
 * across a watchdog reset (platform plan H18, F12; hal/scp_wdog.h,
 * mod/flog.h).
 *
 * The image runs three times, told apart by the watchdog's CAUSE register,
 * which only a power-on reset clears:
 *
 *   A  power-on   the reset values; a wrong kick while disabled does nothing;
 *                 enable, COUNT loaded and falling; kicked for 6 timeouts with
 *                 no reset; TIMEOUT and CTRL writable while unlocked, disable
 *                 stops COUNT; locked: CTRL and TIMEOUT writes ignored, EN
 *                 cannot be cleared, the kick still works; an unmapped offset
 *                 is an access fault. Then a WRONG KICK: the reset must follow
 *   B  wrong kick CAUSE = WDOG | BADKICK, one reset; the watchdog back to its
 *                 reset values (off, unlocked); .data put back from its load
 *                 copy and .bss cleared by crt0.S; the block kept, with A's
 *                 entry. Then armed and NOT kicked: it must expire
 *   C  expiry     CAUSE = WDOG alone, two resets; the block kept with both
 *                 watchdog entries in order. HALT with the failure count
 *
 * A phase with a failure halts at its end rather than going on. soc4_tb
 * (+wdog_resets=2) checks the resets from the outside: two, each one the SCP
 * subsystem's alone, and CAUSE as each boot finds it.
 */
#include <stdint.h>
#include "console.h"
#include "csr.h"
#include "timer.h"
#include "trap.h"
#include "sim.h"
#include "lib.h"
#include "scp_wdog.h"
#include "flog.h"

static unsigned checks, fails;

/* Changed in phase A; crt0.S must put it back from the load copy. */
static volatile uint32_t data_word = 0x600DDA7Au;
/* Set in phase A; crt0.S must clear it. */
static volatile uint32_t bss_word;

static void ck(int cond, const char *what, uint32_t got, uint32_t want)
{
  checks++;
  if (!cond) {
    fails++;
    con_printf("wdog: FAIL %s: 0x%08x, expected 0x%08x\n", what, got, want);
  }
}
#define CKEQ(what, got, want) do { uint32_t g_ = (got), w_ = (want); ck(g_ == w_, what, g_, w_); } while (0)

static void __attribute__((noreturn)) finish(const char *phase)
{
  con_printf("soc4_wdog: %u checks, %u failed (phase %s)\n", checks, fails, phase);
  sim_halt(fails ? (0xDEAD5700u | (fails & 0xFFu)) : 0u);
  for (;;) wfi();
}

/* The log's entries, oldest first. */
static const struct flog_entry *entry(unsigned i)
{
  return &scp_keep.e[(scp_keep.head + FLOG_N - scp_keep.count + i) % FLOG_N];
}

static void phase_a(uint32_t cause)
{
  con_puts("wdog: phase A (power-on)\n");
  CKEQ("A CAUSE at power-on", cause, SCP_WDOG_CAUSE_POR);
  scp_wdog_clear(cause);
  CKEQ("A CAUSE cleared", scp_wdog_cause(), 0u);
  CKEQ("A CTRL reset", scp_wdog_ctrl(), 0u);
  CKEQ("A TIMEOUT reset", mmio_read32(SCP_WDOG_TIMEOUT), 0xFFFFFFFFu);
  CKEQ("A COUNT reset", scp_wdog_count(), 0u);
  CKEQ("A record new", flog_boot(cause), 0u);
  flog_add(FLOG_FAULT, 3, 0xA5A5u);                  /* phase A's entry */
  data_word = 0xBAD0BAD0u;
  bss_word  = 0x0000B55Bu;

  /* Disabled: a wrong kick does nothing. */
  mmio_write32(SCP_WDOG_KICK, 0x12345678u);
  timer_delay(200);
  CKEQ("A wrong kick while disabled: no reset, CAUSE", scp_wdog_cause(), 0u);
  CKEQ("A wrong kick while disabled: COUNT", scp_wdog_count(), 0u);

  /* Enabled: loaded, falling. */
  mmio_write32(SCP_WDOG_TIMEOUT, 3000u);
  mmio_write32(SCP_WDOG_CTRL, SCP_WDOG_CTRL_EN);
  uint32_t c1 = scp_wdog_count(), c2 = scp_wdog_count();
  ck(c1 <= 3000u && c1 > 2900u && c2 < c1, "A COUNT loaded on enable and falling", c1, c2);

  /* Kicked every 1500 cycles for 6 timeouts: no reset. */
  uint32_t lo = 0xFFFFFFFFu;
  for (unsigned i = 0; i < 12; i++) {
    timer_delay(1500);
    uint32_t c = scp_wdog_count();
    if (c < lo) lo = c;
    scp_wdog_kick();
  }
  c1 = scp_wdog_count();
  ck(c1 > 2900u, "A COUNT reloaded by the kick", c1, 3000u);
  ck(lo > 1000u && lo < 2000u, "A COUNT before each kick about 1500 left", lo, 1500u);
  CKEQ("A no reset while kicked: CAUSE", scp_wdog_cause(), 0u);

  /* Unlocked: TIMEOUT writable, disabling stops COUNT, enabling reloads. */
  mmio_write32(SCP_WDOG_TIMEOUT, 4000u);
  CKEQ("A TIMEOUT written", mmio_read32(SCP_WDOG_TIMEOUT), 4000u);
  mmio_write32(SCP_WDOG_CTRL, 0u);
  CKEQ("A CTRL disabled", scp_wdog_ctrl(), 0u);
  c1 = scp_wdog_count();
  timer_delay(100);
  CKEQ("A COUNT stopped while disabled", scp_wdog_count(), c1);
  mmio_write32(SCP_WDOG_CTRL, SCP_WDOG_CTRL_EN);
  c1 = scp_wdog_count();
  ck(c1 <= 4000u && c1 > 3900u, "A COUNT reloaded with the new TIMEOUT", c1, 4000u);

  /* Locked: nothing can disable it or change its timeout. */
  mmio_write32(SCP_WDOG_CTRL, SCP_WDOG_CTRL_EN | SCP_WDOG_CTRL_LOCK);
  CKEQ("A CTRL locked", scp_wdog_ctrl(), SCP_WDOG_CTRL_EN | SCP_WDOG_CTRL_LOCK);
  mmio_write32(SCP_WDOG_CTRL, 0u);
  CKEQ("A CTRL = 0 ignored when locked", scp_wdog_ctrl(), SCP_WDOG_CTRL_EN | SCP_WDOG_CTRL_LOCK);
  mmio_write32(SCP_WDOG_CTRL, SCP_WDOG_CTRL_EN);
  CKEQ("A LOCK cannot be cleared", scp_wdog_ctrl(), SCP_WDOG_CTRL_EN | SCP_WDOG_CTRL_LOCK);
  mmio_write32(SCP_WDOG_TIMEOUT, 0xFFFFFFFFu);
  CKEQ("A TIMEOUT ignored when locked", mmio_read32(SCP_WDOG_TIMEOUT), 4000u);
  c1 = scp_wdog_count();
  c2 = scp_wdog_count();
  ck(c2 < c1, "A still counting when locked", c2, c1);
  scp_wdog_kick();
  c1 = scp_wdog_count();
  ck(c1 > 3900u, "A the kick works when locked", c1, 4000u);
  mmio_write32(SCP_WDOG_COUNT, 7u);
  c1 = scp_wdog_count();
  ck(c1 > 3800u, "A COUNT is read-only", c1, 4000u);

  /* An offset the block does not have answers err: a load access fault. */
  struct trap_fault f;
  trap_expect_fault();
  (void)mmio_read32(SCP_WDOG_BASE + 0x14u);
  const bool took = trap_take_fault(&f);
  ck(took && f.mcause == MCAUSE_LOAD_ACCESS, "A unmapped offset: load access fault",
     took ? f.mcause : 0xFFFFFFFFu, MCAUSE_LOAD_ACCESS);
  scp_wdog_kick();

  con_printf("wdog: phase A: %u checks, %u failed; now the wrong kick\n", checks, fails);
  if (fails) finish("A");
  mmio_write32(SCP_WDOG_KICK, 0x12345678u);
  timer_delay(200);
  ck(0, "A the wrong kick did not reset the SCP", scp_wdog_count(), 0u);
  finish("A");
}

static void phase_b(uint32_t cause)
{
  con_puts("wdog: phase B (after the wrong kick)\n");
  CKEQ("B CAUSE", cause, (1u << 8) | SCP_WDOG_CAUSE_WDOG | SCP_WDOG_CAUSE_BADKICK);
  scp_wdog_clear(cause);
  CKEQ("B CAUSE cleared, RESETS kept", scp_wdog_cause(), 1u << 8);
  CKEQ("B CTRL back to reset (off, unlocked)", scp_wdog_ctrl(), 0u);
  CKEQ("B TIMEOUT back to reset", mmio_read32(SCP_WDOG_TIMEOUT), 0xFFFFFFFFu);
  CKEQ("B COUNT back to reset", scp_wdog_count(), 0u);
  CKEQ("B .data put back by crt0", data_word, 0x600DDA7Au);
  CKEQ("B .bss cleared by crt0", bss_word, 0u);
  CKEQ("B record kept", flog_boot(cause), 1u);
  CKEQ("B watchdog resets in the record", scp_keep.wdog, 1u);
  CKEQ("B entries kept", scp_keep.count, 1u);
  CKEQ("B phase A's entry", entry(0)->detail, 0xA5A5u);
  flog_add(FLOG_WDOG, FLOG_DOM_NONE, cause);
  flog_dump();
  con_printf("wdog: phase B: %u checks, %u failed; now armed and not kicked\n", checks, fails);
  if (fails) finish("B");
  scp_wdog_arm(5000u);
  timer_delay(20000);
  ck(0, "B the watchdog did not expire", scp_wdog_count(), 0u);
  finish("B");
}

static void phase_c(uint32_t cause)
{
  con_puts("wdog: phase C (after the expiry)\n");
  CKEQ("C CAUSE", cause, (2u << 8) | SCP_WDOG_CAUSE_WDOG);
  scp_wdog_clear(cause);
  CKEQ("C record kept", flog_boot(cause), 1u);
  CKEQ("C watchdog resets in the record", scp_keep.wdog, 2u);
  flog_add(FLOG_WDOG, FLOG_DOM_NONE, cause);
  CKEQ("C entries", scp_keep.count, 3u);
  CKEQ("C entry 0: A's", entry(0)->code | (uint32_t)entry(0)->seq << 8, FLOG_FAULT | 0u << 8);
  CKEQ("C entry 1: the wrong kick", entry(1)->code | (uint32_t)entry(1)->seq << 8, FLOG_WDOG | 1u << 8);
  CKEQ("C entry 1's cause", entry(1)->detail, (1u << 8) | SCP_WDOG_CAUSE_WDOG | SCP_WDOG_CAUSE_BADKICK);
  CKEQ("C entry 2: the expiry", entry(2)->code | (uint32_t)entry(2)->seq << 8, FLOG_WDOG | 2u << 8);
  CKEQ("C entry 2's cause", entry(2)->detail, (2u << 8) | SCP_WDOG_CAUSE_WDOG);
  flog_dump();
  finish("C");
}

int main(void)
{
  const uint32_t cause = scp_wdog_cause();
  con_printf("\nsoc4_wdog: the SCP watchdog; CAUSE 0x%08x\n", cause);
  if (cause & SCP_WDOG_CAUSE_POR)          phase_a(cause);
  else if (cause & SCP_WDOG_CAUSE_BADKICK) phase_b(cause);
  else if (cause & SCP_WDOG_CAUSE_WDOG)    phase_c(cause);
  ck(0, "a reset that is neither power-on nor the watchdog's", cause, 0u);
  finish("?");
}
