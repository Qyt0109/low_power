# soc4 firmware

Every firmware image of the repository is built here. `src/pmu/fw` holds
the shared SCP firmware sources (driver, domain manager, policy, RPMI server,
librpmi) and has no Makefile of its own: this folder supplies the platform
(`soc4_plat.h`, `hal/soc4_regs.h`), the soc4-specific modules and the
programs, and `Makefile` builds them all.

## Files

| Path | What |
|---|---|
| `Makefile` | The build: six images, explicit source lists, flags, sizes |
| `soc4_plat.h` | The platform table, written by hand and force-included into every compile: domains, interrupt inputs, agents, watchdog timeout, CPU boot details |
| `scp/` | `soc4_scp`, the SCP's product firmware ([scp/README.md](scp/README.md)) |
| `test/` | `soc4_stress` and `soc4_wdog`, SCP test images ([test/README.md](test/README.md)) |
| `ap/` | `soc4_ap`, the AP's RPMI agent program ([ap/README.md](ap/README.md)) |
| `cpu/` | The program of CPU0 and CPU1 ([cpu/README.md](cpu/README.md)) |
| `mod/` | `soc4_cpu`: CPU image load and cold boot ([mod/README.md](mod/README.md)) |
| `hal/` | `soc4_regs.h`: soc4's maps and registers ([hal/README.md](hal/README.md)) |

## Building

```
make -C src/soc4/fw                 # into build/fw/soc4 (the default OUT)
make -C src/soc4/fw OUT=<dir>
make -C src/soc4/fw clean
make -C src soc4fw                  # what the simulation targets use: OUT=build/fw/soc4
```

The toolchain defaults to `riscv64-unknown-elf-` (`CROSS=` overrides it);
`bin2vmem.py` needs `python3` (`PYTHON=`). No simulator is needed. Every
image produces `<name>.elf`, `.bin`, `.vmem` (for `$readmemh` in `scp_ram`),
`.dis` (disassembly with source) and `.map`. A full build ends by printing
the sizes against the 64 KB RAM and `link.ld`'s 4 KB stack minimum.

## The images

| Image | Sources (beyond the shared base) | Extra flags | Used by |
|---|---|---|---|
| `cpu` | `cpu/cpu.S`, linked with `cpu/cpu.ld` | `-I hal`, no `soc4_plat.h`; `cpu.bin` padded to exactly 4096 bytes (the build fails otherwise) | not loaded by the testbench: embedded in `soc4_scp`, `soc4_scp_m6` and `soc4_stress` via `cpu/cpu_img.S` |
| `soc4_scp` | base + loader + six librpmi files + `port/rpmi_env.c`, `rpmi/scp_rpmi.c`, `rpmi/scp_loop.c`, `hal/rpmi_db.c`, `mod/policy.c`, `mod/flog.c`, `scp/main.c` | `-DCPU_BIN=…`, RPMI includes | `soc4`, `soc4bfm`, `soc4ckrst`, `soc4neg` (M1–M5, M7–M9), `soc4pa`, `soc4bfmpa` |
| `soc4_scp_m6` | as `soc4_scp` | `-DSCP_MUT_PERM_OPEN`: the per-domain permission check bypassed. **Never a product image** | `soc4neg` M6 |
| `soc4_stress` | base + loader + `test/soc4_stress.c` | `-DCPU_BIN=…` | `soc4stress`, `soc4stresspa` |
| `soc4_wdog` | `crt0.S`, `lib/console.c`, `lib/string.c`, `hal/timer.c`, `hal/trap.c`, `mod/flog.c`, `test/soc4_wdog.c` | | `soc4wdog` |
| `soc4_ap` | `crt0.S`, `lib/console.c`, `lib/string.c`, `hal/trap.c`, `hal/timer.c`, three librpmi files (`rpmi_shmem.c`, `rpmi_transport.c`, `rpmi_transport_shmem.c`), `ap/ap_main.c`, `ap/ap_rpmi.c`, `ap/ap_env.c` | RPMI includes | `soc4`, `soc4pa` (`+ap_firmware=`) |

The shared base (`BASE`) is `src/pmu/fw`'s `crt0.S`, `lib/console.c`,
`lib/string.c`, `hal/ppu_v1.c`, `hal/timer.c`, `hal/trap.c`,
`hal/scp_irq.c` and `mod/pd.c`. The loader (`LOADER`) is `mod/soc4_cpu.c`
and `cpu/cpu_img.S`. `soc4_scp` links librpmi's `rpmi_shmem.c`,
`rpmi_transport.c`, `rpmi_transport_shmem.c`, `rpmi_context.c`,
`rpmi_service_group_device_power.c` and `rpmi_service_group_sysmsi.c`
(SYSTEM_MSI is linked although no such group is registered, because
`rpmi_context.c` calls into it, guarded only at run time). SYSTEM_RESET is
not linked.

The testbench loads an SCP image with `+firmware=build/fw/soc4/<image>.vmem`
and the AP image with `+ap_firmware=build/fw/soc4/soc4_ap.vmem`.

### Sizes

`riscv64-unknown-elf-size` on the build in `build/fw/soc4` (built
2026-10-05; no firmware source has changed since), with the end of `.bss` and
the stack as the Makefile's `sizes` target computes them (stack = from
`_bss_end` to `_stack_top` = `0xFC00`, below the 1 KB persistent block):

| Image | text | data | bss | End of `.bss` (of 65536) | Stack (minimum 4096) |
|---|---:|---:|---:|---:|---:|
| `soc4_scp` | 22322 | 136 | 2596 | 24640 | 39872 |
| `soc4_scp_m6` | 22236 | 136 | 2596 | 24552 | 39960 |
| `soc4_stress` | 44458 | 16 | 1240 | 45732 | 18780 |
| `soc4_wdog` | 5846 | 4 | 592 | 5896 | 58616 |
| `soc4_ap` | 6640 | 4 | 456 | 7104 | 57408 |
| `cpu` | 416 | 0 | 0 | code ends at `0x1A0` (data from `0xC00`) | `cpu.bin` 4096 bytes |

`soc4_stress` is the largest; the SCP images include the 4 KB CPU image in
their text.

### Flags

| Flag | Why |
|---|---|
| `-march=rv32imc_zicsr_zifencei -mabi=ilp32` | what `scp_core` implements; Zicsr spelled out because GCC 12+ no longer implies it |
| `-nostdlib -nostartfiles -ffreestanding` | no rv32 soft-float multilib in this toolchain, so no libc or libgcc; `lib/` supplies `memcpy`/`memset` |
| `-fno-tree-loop-distribute-patterns` | stops GCC turning `lib/string.c`'s `memset` loop into a call to itself |
| `-fno-asynchronous-unwind-tables -fno-unwind-tables` | no `.eh_frame`; nothing unwinds and it costs RAM |
| `-ffunction-sections -fdata-sections`, `--gc-sections` | link only what an image uses (with the explicit source lists: no wildcard over `src/pmu/fw`) |
| `--orphan-handling=error` | a section `link.ld` does not place is a build error |
| `-include soc4_plat.h` | every SCP and AP compile gets the platform table |
| `-Os -g -mcmodel=medany -std=gnu11 -Wall -Wextra -Wno-unused-parameter` | |

Include path: `src/pmu/fw/{lib,hal,mod}`, then `hal/` and `mod/` here; the
RPMI images add librpmi's `include/`, `src/pmu/fw/port` and
`src/pmu/fw/rpmi`. `src/pmu/README.md` §4 has the measurements behind these
choices.

## soc4_plat.h: the platform table

The shared firmware takes its platform from these macros and has no defaults
of its own (a missing table is an `#error`). Each table is an X-macro: the
shared code expands it as many times as it needs.

| Macro | Consumed by | What |
|---|---|---|
| `SCP_NUM_PPU` (4) | `hal/scp_regs.h`, `mod/pd.h` (`PD_COUNT`) | PPU slots the firmware drives: one per domain |
| `SCP_PLAT_DOMAINS(D)` | `mod/pd.h`, `pd.c`, `rpmi/scp_rpmi.c` | the domain table |
| `SCP_PLAT_INPUTS(I)` | `hal/scp_irq.h` | the interrupt input table |
| `SCP_PLAT_AGENTS(A)` | `mod/agents.h`, `rpmi/scp_rpmi.h` | the agent table |
| `SCP_PLAT_WDOG_TIMEOUT` | `rpmi/scp_loop.h`, `scp/main.c` | watchdog timeout, `0x0020_0000` cycles (about 21 ms at 100 MHz) |
| `SCP_PLAT_CKRST_STAT(d)` | `mod/policy.c` | address of the bridge status word holding domain d (`SOC4_CTRL_CKRST + (d/4)*4`, byte `d % 4`, W1C) |
| `SOC4_CPU_BOOT_DETAILS(n)` | the domain table's `.cpu` | CPU n's `struct pd_cpu` |

### `SCP_PLAT_DOMAINS`: one `D(name, latency, fields)` per domain

In DOMAIN_ID order; DOMAIN_ID = PPU index = SCP interrupt input number.
`name` (at most 15 characters) is what DEVICE_POWER's `GET_ATTRIBUTES`
reports; `latency` is DEVICE_POWER's `trans_latency` (0 for all four:
nothing measured yet); `fields` are designated initializers of
`struct pd_cfg` (`src/pmu/fw/mod/pd.h`):

| Field | Meaning | CPU0 | CPU1 | ACC0 | ACC1 |
|---|---|---|---|---|---|
| `.kind` | `PD_KIND_CPU` (cold-booted by the SCP) or `PD_KIND_DEV` | CPU | CPU | DEV | DEV |
| `.lp` | where RPMI OFF takes the domain | `FULL_RET` | `OFF` | `MEM_RET` | `OFF` |
| `.funrr`, `.fulrr`, `.memrr` | retention RAM bytes, one retain enable per bank; `pd_init` writes only the registers the PPU has | `fulrr 0xFF` | — | `memrr 0xFF` | — |
| `.idr0` | `PPU_IDR0` the PPU must report (checked at boot) | `0x00034101` | `0x00030101` | `0x00030501` | `0x00030101` |
| `.idr1` | `PPU_IDR1` the PPU must report | `0x23` | `0x03` | `0x13` | `0x03` |
| `.cpu` | CPU boot details, `NULL` for a device | `SOC4_CPU_BOOT_DETAILS(0)` | `SOC4_CPU_BOOT_DETAILS(1)` | — | — |
| `.agents` | bitmap of agents that may vote (`SCP_AG(id)`); others get `RPMI_ERR_DENIED`; the lowest owns the wake vote | AP | AP | AP, RPU | AP, RPU |
| `.ckrst_lat` | the SoC clkgate/tilereset's worst-case acknowledgement latency, PPU cycles; `pd_init` raises `CLKEN_RST_DLY`, `CLKEN_ISO_DLY`, `RST_HWSTAT_DLY` to cover it (0 = build defaults) | 2 | 2 | 2 | 6 |

`SOC4_CPU_BOOT_DETAILS(n)` fills `struct pd_cpu` with: the image
(`cpu_img`, `SOC4_CPU_WORDS` = 1024 words), the load window
(`SOC4_LD_BASE(n)`), the open check (`CPU_STAT` & `SOC4_CPU_STAT_LDOPEN(n)`),
the boot register and address (`CPUn_BOOT`, `0x0`) and the fetch register
and bit (`CPU_FETCH_EN`, bit n).

### `SCP_PLAT_INPUTS`: one `I(id, name, mode, en, act, arg)` per input

In input order: input i is `soc4_top`'s `irq_in[i]`. `mode` is
`SCP_IN_LEVEL` or `SCP_IN_EDGE`; `en = 0` means the input's owner opens it
(PPU and doorbell inputs) or that it stays masked for good; `act` and `arg`
are what the firmware does (`src/pmu/fw/hal/scp_irq.h`).

| i | id | mode | en | act | arg |
|---:|---|---|---:|---|---:|
| 0–3 | `PPU0`–`PPU3` | level | 0 | `SCP_ACT_PPU` (opened by `pd_init`) | 0–3 |
| 4 | `DB` | level | 0 | `SCP_ACT_DOORBELL` (opened by `rpmi_db_set_mask`) | 0 |
| 5 | `PLIC` | level | 1 | `SCP_ACT_NOTIFY` | 0 |
| 6 | `PLIC_H0` | level | 1 | `SCP_ACT_POWER_UP` | 0 (CPU0) |
| 7 | `PLIC_H1` | level | 1 | `SCP_ACT_POWER_UP` | 1 (CPU1) |
| 8 | `RTC` | edge | 1 | `SCP_ACT_REASON` | 1 |
| 9 | `GPIO` | edge | 1 | `SCP_ACT_POWER_UP` | 2 (ACC0) |
| 10 | `BBRX` | edge | 1 | `SCP_ACT_REASON` | 2 |
| 11 | `DBG` | level | 1 | `SCP_ACT_IGNORE` | 0 |
| 12 | `ACG0` | edge | 1 | `SCP_ACT_POWER_UP` | 3 (ACC1) |
| 13 | `ACG1` | edge | 0 | `SCP_ACT_POWER_UP` (masked: no second gate) | 1 |
| 14 | `DB1` | level | 0 | `SCP_ACT_DOORBELL` | 1 |
| 15 | `CKRST` | level | 1 | `SCP_ACT_CKRST` (opened by `policy_init`) | 0 |

### `SCP_PLAT_AGENTS`: one `A(id, name, window, db_in, src, mask, groups)` per agent

In transport order: agent k = RPMI transport k = mailbox window k, doorbell
`RING[k]` and firewall entry k (`src/pmu/fw/mod/agents.h`).

| k | id | window | db_in | src / mask | groups |
|---:|---|---|---|---|---|
| 0 | `AP` | `SOC4_QMEM_WIN(0)` | `SCP_IN_DB` | `SOC4_AP_SOURCE` `0x10` / `SOC4_AP_SRC_MASK` `0xFF` | `SCP_GRP_DPWR` |
| 1 | `RPU` | `SOC4_QMEM_WIN(1)` | `SCP_IN_DB1` | `SOC4_RPU_SOURCE` `0x20` / `SOC4_RPU_SRC_MASK` `0xFC` | `SCP_GRP_DPWR` |

Both get BASE (every librpmi context has it) and DEVICE_POWER, each over an
M-mode context. What each agent may vote for is the domain table's
`.agents`.

### Consistency checks at build and boot

- `scp/main.c` statically asserts that `SCP_PLAT_WDOG_TIMEOUT` minus the
  loop's sleep covers the longest main-loop pass: (agents ×
  `SCP_RPMI_DRAIN_BUDGET` + the number of `SCP_ACT_POWER_UP` inputs + 1)
  power-ups of 1 ms. Adding agents or power-up inputs can break this.
- `mod/agents.h` asserts 1–8 agents (`.agents` is a byte).
- At boot `soc4_scp` checks the interrupt block's input count against the
  input table, every PPU's `AIDR`/`IDR0`/`IDR1` against the domain table,
  the mailbox's `INFO` agent count against the agent table, and each
  agent's `db_in` against its input entry; any mismatch halts with
  `0xDEAD54xx`.

## How to add or remove a domain, an agent or an interrupt input

These are the firmware edits; each goes with the hardware edits in
[../rtl/README.md](../rtl/README.md#extending-the-platform). The checklist
of record is `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §15.3.

**A domain.**

1. One `D(...)` entry in `SCP_PLAT_DOMAINS`, in DOMAIN_ID order: name, `.kind`,
   `.lp`, the retention byte(s) its PPU has, `.idr0`/`.idr1` as that PPU's
   configuration reports them, `.agents`, `.ckrst_lat`, and `.cpu` if it is
   a CPU (a `SOC4_CPU_BOOT_DETAILS(n)`-style entry with its own load window,
   boot and fetch registers).
2. Its PPU's `I(..., SCP_ACT_PPU, n)` entry in `SCP_PLAT_INPUTS`, at the
   input number the top wires it to.
3. `SCP_NUM_PPU`.
4. If the domain is beyond the fourth, `SCP_PLAT_CKRST_STAT` already
   computes the next status word, but `soc4_ctrl` must provide it (see the
   RTL README).
5. Its DOMAIN_ID and permissions in `docs/PMU_SOFTWARE_CONTRACT.md` §2.

The test images are not table-driven: `soc4_stress` hard-codes four
domains (`ND`, its mode and ID tables) and `soc4_ap` checks
`GET_NUM_DOMAINS == SOC4_NDOM` and the four names, so both need editing too,
as does `enum { SOC4_CPU0 … SOC4_NDOM }` in `hal/soc4_regs.h`.

**An agent.**

1. One `A(...)` entry in `SCP_PLAT_AGENTS`, in transport order: its window
   (`SOC4_QMEM_WIN(k)`), doorbell input, source value and mask (new
   `SOC4_*_SOURCE`/`_SRC_MASK` constants in `hal/soc4_regs.h`), groups.
2. Its doorbell's `I(..., SCP_ACT_DOORBELL, k)` entry in `SCP_PLAT_INPUTS`.
3. Its bit (`SCP_AG(id)`) in the `.agents` of every domain it may vote for.
4. Re-check the watchdog timeout assertion (it grows with the agent count).
5. Its window, doorbell, source IDs and permissions in the software contract
   §1, §2.

The transports, librpmi contexts, votes, doorbell handling and the librpmi
arena follow the agent table with no other edit.

**An interrupt or wake input.** One `I(...)` entry appended to
`SCP_PLAT_INPUTS` with its mode, enable and action, and one wire in
`soc4_top`'s `irq_in`. A new `SCP_ACT_POWER_UP` input counts against the
watchdog timeout assertion.

## References

- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.3 (firmware items F5–F14),
  §14.7, §15.2 (phases), §15.3 (adding a domain or an agent).
- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../../docs/PMU_SOFTWARE_CONTRACT.md).
- [`src/pmu/README.md`](../../pmu/README.md): the shared firmware, its rules
  and the build measurements (§4).
- `src/pmu/fw/vendor/librpmi/README.md`: the vendored librpmi v1.0.0.
- Background only: [`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md) §6.5,
  §9 (firmware) and §9.10 (sizes).
