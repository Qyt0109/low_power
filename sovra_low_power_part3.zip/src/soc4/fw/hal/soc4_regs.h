/* soc4's address maps, registers and layouts, as the firmware sees them.
 *
 * docs/SOC4_DESIGN.md Section 4, which src/soc4/rtl implements
 * (soc4_top.sv's ext decode, soc4_ctrl.sv, soc4_mbx.sv, soc4_ap.sv). Three
 * programs include this file: the SCP images, the AP image and, for the CPU
 * RAM layout, cpu/cpu.S. The part above the __ASSEMBLER__ guard is plain
 * #defines with no C suffixes, so the assembler can take it too.
 *
 * Every register answers in one cycle (bus.sv protocol). An unmapped offset
 * inside a device answers err, which the core takes as a load or store access
 * fault. Writes to a read-only register are ignored with no err (S1 RTL).
 */
#ifndef SOC4_REGS_H
#define SOC4_REGS_H

/* ---- The SCP's ext window, 0x0002_xxxx (Section 4.2) ---- */
#define SOC4_SIM_BASE      0x00020000   /* testbench scp_sim_ctrl, TAG "fw" (hal/sim.h) */
#define SOC4_CTRL_BASE     0x00021000   /* soc4_ctrl (4.4)                          */
#define SOC4_MBX_BASE      0x00022000   /* soc4_mbx SCP registers (4.5)             */
#define SOC4_QMEM_BASE     0x00024000   /* queue memory, byte enables honoured: one
                                           window per agent, 2 KiB in soc4         */
#define SOC4_QMEM_SIZE     0x00000400   /* one agent's window                       */
#define SOC4_QMEM_WIN(k)   (SOC4_QMEM_BASE + (k) * SOC4_QMEM_SIZE)
#define SOC4_LD_BASE(n)    (0x00028000 + (n) * 0x1000)   /* CPUn RAM load port (5.4) */

/* ---- soc4_ctrl (4.4) ---- */
#define SOC4_CTRL_CPU_BOOT(n)  (SOC4_CTRL_BASE + 0x000 + (n) * 4)  /* RW [31:8]; [7:0] read 0 */
#define SOC4_CTRL_FETCH_EN     (SOC4_CTRL_BASE + 0x008)   /* RW [n] CPUn fetch enable    */
#define SOC4_CTRL_AP_RUN       (SOC4_CTRL_BASE + 0x00C)   /* RW [0] AP fetch (& !BFM_SEL) */
#define SOC4_CTRL_STRAPS       (SOC4_CTRL_BASE + 0x010)   /* RO [0] BFM_SEL              */
#define SOC4_CTRL_CPU_STAT     (SOC4_CTRL_BASE + 0x014)   /* RO, fields below            */
#define SOC4_CTRL_HWSTAT(n)    (SOC4_CTRL_BASE + 0x020 + (n) * 4)  /* RO [15:0] PPUHWSTAT */
#define SOC4_CPU_STAT_SLEEP(n) (1 << (n))        /* core_sleep, post-isolation: defined
                                                    only while HWSTAT_n is ON or WARM_RST */
#define SOC4_CPU_STAT_LDOPEN(n) (1 << (4 + (n))) /* load port open (5.4)             */
#define SOC4_CPU_STAT_WAKE(n)  (1 << (8 + (n)))  /* toggles on each wake pulse (S1)  */
#define SOC4_CTRL_CKRST        (SOC4_CTRL_BASE + 0x030)   /* R/W1C [8n+7:8n] domain n's clock/reset
                                                             bridge status (ckrst_bridge.sv): [0] LATE,
                                                             [1] MISSING, [2] SPURIOUS, [4] clock,
                                                             [5] reset 0, [6] reset 1 (H16)        */

/* ---- soc4_mbx, SCP side (soc4_mbx.sv has the map): bit or block k = agent k ---- */
#define SOC4_MBX_DB_STATUS     (SOC4_MBX_BASE + 0x000)  /* RO [k] RING[k], sticky; a level input */
#define SOC4_MBX_DB_CLEAR      (SOC4_MBX_BASE + 0x004)  /* WO, W1C [k]; a ring wins; reads 0 */
#define SOC4_MBX_INFO          (SOC4_MBX_BASE + 0x008)  /* RO [7:0] agents, [15:8] ports */
#define SOC4_MBX_FW_LAST       (SOC4_MBX_BASE + 0x00C)  /* RO {[19:16] k, [9] FW_EN[k] was 0,
                                                           [8] valid, [7:0] a_source}    */
#define SOC4_MBX_AGENT(k)      (SOC4_MBX_BASE + 0x100 + (k) * 0x20)
#define SOC4_MBX_FW_EN(k)      (SOC4_MBX_AGENT(k) + 0x00)  /* RW [0], 0 at reset: deny all */
#define SOC4_MBX_FW_VAL(k)     (SOC4_MBX_AGENT(k) + 0x04)  /* RW [7:0] admitted if        */
#define SOC4_MBX_FW_MASK(k)    (SOC4_MBX_AGENT(k) + 0x08)  /* RW [7:0] (src & MASK) == VAL */
#define SOC4_MBX_DENY_CNT(k)   (SOC4_MBX_AGENT(k) + 0x0C)  /* RO, write clears             */
#define SOC4_MBX_RING_CNT(k)   (SOC4_MBX_AGENT(k) + 0x10)  /* RO, write clears             */

/* The agents' TL-UL source IDs, the values and masks the firmware programs
   into the firewall (soc4_plat.h, SCP_PLAT_AGENTS). The AP's is applied in
   soc4_ap's glue (5.7), one ID; a chosen constant (Section 15.2-19). The RPU
   stand-in (the testbench's second BFM) owns the range 0x20-0x23, which shows
   a value and mask matching a range of source IDs (platform plan H12). */
#define SOC4_AP_SOURCE     0x10
#define SOC4_AP_SRC_MASK   0xFF
#define SOC4_RPU_SOURCE    0x20
#define SOC4_RPU_SRC_MASK  0xFC

/* ---- The AP's map (4.3, 4.6) ---- */
#define SOC4_AP_SIM_BASE   0x00020000   /* testbench scp_sim_ctrl, TAG "ap": hal/sim.h offsets */
#define SOC4_AP_QMEM       0x20000000   /* window 0 of the queue memory, through TL-UL */
#define SOC4_AP_DOORBELL   0x20001000   /* any write rings RING[0]; a read returns 0  */
/* ---- The RPU's (agent 1's) view, on its own mailbox port: the software
   contract's, nothing here uses it ---- */
#define SOC4_RPU_QMEM      0x20002000   /* window 1                                  */
#define SOC4_RPU_DOORBELL  0x20003000   /* RING[1]                                   */

/* ---- CPU0/CPU1: their own 4 KB RAM at 0 (4.7) ---- */
#define SOC4_CPU_BOOT      0x00000000   /* boot address: vectors at 0, reset at 0x80 */
#define SOC4_CPU_RAM_SIZE  0x1000
#define SOC4_CPU_WORDS     1024
#define SOC4_CPU_DATA      0xC00        /* code ends at or below this (cpu.ld)       */
#define SOC4_CPU_MARKER    0xC00        /* 0xC0DE_0000 | mhartid, after each boot    */
#define SOC4_CPU_BOOTS     0xC04        /* boots since the image was loaded          */
#define SOC4_CPU_WAKES     0xC08        /* CPU0: WFI returns                         */
#define SOC4_CPU_TRAP      0xC0C        /* mcause of an unexpected trap, else 0      */
#define SOC4_CPU_DUMP      0xC10        /* CPU0: s0, s1, s2..s11 after each wake     */
#define SOC4_CPU_COUNT     0xC80        /* CPU1: its loop counter                    */
#define SOC4_CPU_STACK     0x1000       /* sp; the stack is 0xD00-0xFFF              */
#define SOC4_CPU_MAGIC     0xC0DE0000
#define SOC4_CPU_SIG(i, hart) (0x51000000 | ((i) << 8) | (hart))  /* s<i> on CPU0 (9.9) */

/* ---- Commands from the SCP's test image to the testbench (10.1) ----
 * Written to the SCP sim control's AP_CMD register; the testbench applies the
 * command and then echoes the same word on AP_STAT. Both are levels, so a
 * command repeated is harmless. */
#define SOC4_TB_HOLD       0x48000000   /* 'H' | [3:0]: hold_busy mask, per domain   */
#define SOC4_TB_DENY       0x44000000   /* 'D' | [1:0]: ACC deny mask, bit k = ACC k  */

#ifndef __ASSEMBLER__
#include <stdint.h>

/* Domain IDs: DOMAIN_ID = PPU index (Section 3.1). */
enum { SOC4_CPU0 = 0, SOC4_CPU1 = 1, SOC4_ACC0 = 2, SOC4_ACC1 = 3, SOC4_NDOM = 4 };

/* soc4_ctrl HWSTAT_n is one-hot, bit m for mode m (ppu_pkg.sv:134-147). */
#define SOC4_HWSTAT_OF(mode) (1u << (mode))
#endif

#endif
