# soc4 hal: `soc4_regs.h`

soc4's address maps, registers and memory layouts as the firmware sees them.
It is the firmware's copy of what `src/soc4/rtl` implements (the ext decode
in `soc4_top.sv`, `soc4_ctrl.sv`, `soc4_mbx.sv`, `soc4_ap.sv`). The SCP's own
private map (RAM, timer, interrupt block, watchdog, PPUs) is not here: it is
`src/pmu/fw/hal/scp_regs.h`, shared by every platform.

## Files

| File | What |
|---|---|
| `soc4_regs.h` | Every soc4 address, register offset, field and constant the SCP, AP and CPU programs use |

## What it defines

Three programs include it: the SCP images (via `soc4_plat.h`, which every
SCP and AP compile force-includes), the AP image, and `cpu/cpu.S` for the
CPU RAM layout. Everything above the `__ASSEMBLER__` guard is plain
`#define`s with no C suffixes so the assembler can take it.

| Group | Names | Values |
|---|---|---|
| SCP ext window | `SOC4_SIM_BASE`, `SOC4_CTRL_BASE`, `SOC4_MBX_BASE`, `SOC4_QMEM_BASE`, `SOC4_QMEM_SIZE`, `SOC4_QMEM_WIN(k)`, `SOC4_LD_BASE(n)` | `0x0002_0000`, `0x0002_1000`, `0x0002_2000`, `0x0002_4000`, `0x400` per agent, `0x0002_8000 + n * 0x1000` |
| `soc4_ctrl` | `SOC4_CTRL_CPU_BOOT(n)` (`+0x000 + 4n`), `SOC4_CTRL_FETCH_EN` (`+0x008`), `SOC4_CTRL_AP_RUN` (`+0x00C`), `SOC4_CTRL_STRAPS` (`+0x010`), `SOC4_CTRL_CPU_STAT` (`+0x014`), `SOC4_CTRL_HWSTAT(n)` (`+0x020 + 4n`), `SOC4_CTRL_CKRST` (`+0x030`) | fields: `SOC4_CPU_STAT_SLEEP(n)` bit n, `SOC4_CPU_STAT_LDOPEN(n)` bit 4+n, `SOC4_CPU_STAT_WAKE(n)` bit 8+n |
| Mailbox, SCP side | `SOC4_MBX_DB_STATUS` (`+0x000`), `_DB_CLEAR` (`+0x004`), `_INFO` (`+0x008`), `_FW_LAST` (`+0x00C`), `SOC4_MBX_AGENT(k)` (`+0x100 + 0x20k`) with `_FW_EN`, `_FW_VAL`, `_FW_MASK`, `_DENY_CNT`, `_RING_CNT` at `+0x00`..`+0x10` | |
| Source IDs | `SOC4_AP_SOURCE` / `SOC4_AP_SRC_MASK`, `SOC4_RPU_SOURCE` / `SOC4_RPU_SRC_MASK` | `0x10` / `0xFF`, `0x20` / `0xFC` |
| AP map | `SOC4_AP_SIM_BASE`, `SOC4_AP_QMEM`, `SOC4_AP_DOORBELL` | `0x0002_0000`, `0x2000_0000`, `0x2000_1000` |
| RPU view (contract only, unused here) | `SOC4_RPU_QMEM`, `SOC4_RPU_DOORBELL` | `0x2000_2000`, `0x2000_3000` |
| CPU RAM layout | `SOC4_CPU_BOOT`, `_RAM_SIZE`, `_WORDS`, `_DATA`, `_MARKER`, `_BOOTS`, `_WAKES`, `_TRAP`, `_DUMP`, `_COUNT`, `_STACK`, `_MAGIC`, `SOC4_CPU_SIG(i, hart)` | see [../cpu/README.md](../cpu/README.md) |
| Testbench commands | `SOC4_TB_HOLD` (`'H'`, `[3:0]` hold_busy mask per domain), `SOC4_TB_DENY` (`'D'`, `[1:0]` ACC deny mask) | written to the sim page's `AP_CMD`; the testbench echoes the word on `AP_STAT` once applied |
| C only | `enum { SOC4_CPU0, SOC4_CPU1, SOC4_ACC0, SOC4_ACC1, SOC4_NDOM }`, `SOC4_HWSTAT_OF(mode)` (one-hot PPUHWSTAT) | |

The register-level descriptions (fields, access, reset values) are in
[../../rtl/README.md](../../rtl/README.md); the comments in the header
summarise them.

Rules the header records: every register answers in one cycle; an unmapped
offset inside a device answers err (a load/store access fault on the core);
writes to a read-only register are ignored without err.

## Using and extending it

soc4 code includes `soc4_regs.h` directly. Shared code under `src/pmu/fw`
mostly gets soc4's values through `soc4_plat.h`'s tables; the one exception
is the doorbell backend `src/pmu/fw/hal/rpmi_db.c`, which includes this
header for `SOC4_MBX_DB_STATUS` and `SOC4_MBX_DB_CLEAR`. A second platform
must therefore provide a header with that name and those two registers, or
change `rpmi_db.c`. When the RTL changes a map or a register, change this
header to match, then `soc4_plat.h` if a table entry names the value. A new
agent needs its source-ID value and mask here; a new domain needs an entry
in the `SOC4_*` domain enum (and, for a CPU, its load window).

## References

- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../../../docs/PMU_SOFTWARE_CONTRACT.md)
  §1 (the agents' window, doorbell and source-ID values).
- `src/pmu/fw/hal/scp_regs.h` (the SCP's map) and `src/pmu/fw/hal/sim.h`
  (the testbench's sim page, `AP_CMD`/`AP_STAT`).
- Background only: [`docs/SOC4_DESIGN.md`](../../../../docs/SOC4_DESIGN.md) §4 (the maps) and
  §10.1 (testbench commands).
