/* The AP's RPMI client: librpmi's own shared-memory transport, used from the
 * agent's side.
 *
 * docs/SOC4_DESIGN.md Section 9.7. librpmi is reused unchanged:
 * rpmi_transport_enqueue() and rpmi_transport_dequeue() accept any queue type
 * below RPMI_QUEUE_MAX (LR lib/rpmi_transport.c:71-173), so the AP enqueues
 * on RPMI_QUEUE_A2P_REQ and dequeues from RPMI_QUEUE_P2A_ACK
 * (LR include/librpmi.h:164-170). The queue memory is the SCP's, seen through
 * TL-UL at SOC4_AP_QMEM; its layout is librpmi's (LR
 * lib/rpmi_transport_shmem.c:236-249) with rpmi/scp_rpmi.h's geometry: 64-byte
 * slots, 512-byte queues, 1 KiB in all.
 *
 * The SCP owns initialisation: rpmi_transport_shmem_create() fills the whole
 * memory with zeros (LR lib/rpmi_transport_shmem.c:218-220), so the AP's
 * platform ops make fill a no-op (all three ops are mandatory,
 * LR lib/rpmi_shmem.c:154). The AP starts only after the SCP has set AP_RUN,
 * which it does once the queues are initialised (scp/main.c).
 *
 * A call never hangs: a missing acknowledgement ends in AP_E_TIMEOUT after
 * `tmo` cycles of the AP's CYCLE register.
 */
#ifndef AP_RPMI_H
#define AP_RPMI_H

#include <stdint.h>

enum ap_err {
  AP_OK        =  0,
  AP_E_INIT    = -1,   /* librpmi refused the shmem or the transport          */
  AP_E_FULL    = -2,   /* the A2P queue is full (LR rpmi_transport.c:108-112)  */
  AP_E_TIMEOUT = -3,   /* no acknowledgement within the timeout               */
  AP_E_BADACK  = -4,   /* an acknowledgement that does not answer the request */
  AP_E_PARAM   = -5,   /* request too long for one slot                        */
};

int ap_rpmi_init(void);

/* One NORMAL_REQUEST and its acknowledgement. req/len: the request data;
 * rsp: room for up to AP_RPMI_DATA_MAX bytes, *rlen set to the ACK's data
 * length. Returns AP_OK or an AP_E_*; the RPMI status is in the data. */
#define AP_RPMI_DATA_MAX 56u          /* slot 64 - header 8 (LR librpmi.h:81) */
int ap_call(uint16_t grp, uint8_t srv, const void *req, uint16_t len,
            void *rsp, uint16_t *rlen, uint32_t tmo);

/* What the last ap_call() sent and got (for diagnostics). */
struct ap_rpmi_stats {
  uint32_t calls, timeouts, badacks, full;
  uint16_t last_token;
};
extern struct ap_rpmi_stats ap_rpmi_stats;

#endif
