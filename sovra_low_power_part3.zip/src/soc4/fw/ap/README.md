# soc4_ap — the AP's RPMI agent program

`soc4_ap` runs on soc4's always-on AP (`rtl/soc4_ap.sv`) in `make soc4` and
`make soc4pa`. It is agent 0: it drives the SCP's BASE and DEVICE_POWER
services through librpmi's own shared-memory transport, used from the
agent's side, and plays the software of the two accelerators through its
own sim-control page. At each step it asks the testbench to check the
PPU and the IP state (a checkpoint). It is a test program, not product
software: in SOVRA the agents are OpenSBI on the AP and the RPU's firmware,
which use the same transport (see `docs/PMU_SOFTWARE_CONTRACT.md`).

## Files

| File | What |
|---|---|
| `ap_main.c` | The test sequence A0–A16, the checkpoint protocol and the verdict |
| `ap_rpmi.h` | The client API: `ap_rpmi_init()`, `ap_call()`, error codes, `ap_rpmi_stats` |
| `ap_rpmi.c` | The client: librpmi shmem + transport on window 0, one request/acknowledgement per call |
| `ap_env.c` | librpmi's environment on the AP: `rpmi_env_zalloc` from a 256-byte arena, `rpmi_env_free` a no-op |

## The RPMI client (`ap_rpmi.c`)

- The queue memory is window 0 seen through TL-UL at `SOC4_AP_QMEM`
  (`0x2000_0000`), with `rpmi/scp_rpmi.h`'s geometry: 64-byte slots,
  512-byte queues, 1 KiB in all (a `_Static_assert` ties it to
  `SOC4_QMEM_SIZE`). The transport is created with no P2A request queue:
  A2P requests and P2A acknowledgements only, as on the SCP.
- **The SCP owns initialisation.** librpmi's transport create zeroes the
  memory, so the AP's `fill` platform op is a no-op; the AP starts only
  after the SCP sets `AP_RUN`, which it does once the queues are
  initialised.
- `ap_call(grp, srv, req, len, rsp, rlen, tmo)` builds a
  `NORMAL_REQUEST` with an incrementing token, enqueues it on
  `RPMI_QUEUE_A2P_REQ`, then rings the doorbell (`SOC4_AP_DOORBELL`, value 1:
  OpenSBI's order and value). It polls `RPMI_QUEUE_P2A_ACK` every 32 cycles
  and checks the acknowledgement's type, group, service and token.
- A call never hangs: it returns `AP_E_TIMEOUT` after `tmo` cycles of the
  sim page's `CYCLE` register. Other results: `AP_OK`, `AP_E_INIT`,
  `AP_E_FULL`, `AP_E_BADACK`, `AP_E_PARAM` (request over
  `AP_RPMI_DATA_MAX` = 56 bytes). The RPMI status is the first word of the
  response data.
- Reads and writes are plain `memcpy` (byte-wise in `lib/string.c`), so each
  byte is one TL-UL access with one mask bit; the queue memory accepts
  byte accesses.

## The checkpoint protocol with the testbench

The AP's sim page (`0x0002_0000`, TAG `ap`) has the same offsets as the
SCP's (`src/pmu/fw/hal/sim.h`).

1. The AP reads `SIM_TB_CHECKS`, then writes `SIM_CHECK` =
   `{[15:8] dom, [3:0] mode}`: "domain `dom` should now be in PPU mode
   `mode`".
2. The testbench runs the PPU-level check and the IP-state rule for
   `(dom, mode)` (for example: CPU0's signature after `FULL_RET`, ACC0's
   banks after `MEM_RET`) and advances `SIM_TB_CHECKS`.
3. The AP waits for `SIM_TB_CHECKS` to change, at most `CKPT_TMO` (100 000)
   cycles; a checkpoint never acknowledged counts as a failure.
4. IP-state rules that wait (up to 20 000 cycles for a CPU to boot or wake)
   may finish later, so before the verdict the AP waits `TB_SETTLE`
   (30 000) cycles and reads `SIM_TB_ERRORS`.

The program halts (returns from `main`, which `crt0.S` turns into
`SIM_HALT`) with `fails + (TB_ERRORS != 0)`: 0 is a pass.

## The sequence

Expectations use librpmi's own macros and enums, never literal numbers.

| Step | What |
|---|---|
| A0 | Transport create; queue heads and tails read 0 |
| A1 | BASE: spec version, implementation version and ID; `PROBE_SERVICE_GROUP` (BASE and DEVICE_POWER present, SYSTEM_RESET absent); `GET_ATTRIBUTES` shows an M-mode context |
| A2 | DEVICE_POWER discovery: 4 domains, names `CPU0`, `CPU1`, `ACC0`, `ACC1`, flags 0, latency 0; every domain OFF (RPMI and checkpoint) |
| A3–A6 | Each domain ON; ACC0 and ACC1 filled with a seeded pattern (`IP_SEED`, `IP_CMD` = 01) once ON |
| A7–A8 | CPU0 OFF → `FULL_RET` after the policy's hysteresis, then ON: the core's registers survive |
| A9–A10 | CPU1 OFF: it never sleeps, so it is denied, backed off three times and forced `OFF`; ON reloads it and it restarts from its boot address |
| A11–A14 | ACC0 OFF → `MEM_RET` (RAM kept) and back; ACC1 OFF (RAM lost) and back |
| A15 | All four OFF at once: CPU0 `FULL_RET`, CPU1 `OFF`, ACC0 `MEM_RET`, ACC1 `OFF` |
| A16 | Verdict: AP checks and fails, call and timeout counts, testbench checks and errors |

Waits after an OFF vote are fixed: `W_HYST` (150 000 cycles) covers the
policy's 1 ms hysteresis; `W_CPU1` (220 000) adds CPU1's three back-offs
(100, 200, 400 µs).

## Building and running

Built by `../Makefile` as `soc4_ap` (with `soc4_plat.h` force-included for
uniformity; nothing here depends on it). Run by `make soc4 SIM=vcs` and
`make soc4pa SIM=vcs`, loaded with `+ap_firmware=build/fw/soc4/soc4_ap.vmem`.
In `soc4bfm` and the other BFM runs the strap `bfm_sel_i` keeps the AP from
fetching and the testbench's BFM takes its port.

## Extending it

A new step is a call to `set_state` / `expect_state` (or `rq` for any
service) followed by `ckpt(dom, mode)`; the testbench must know the IP-state
rule for that `(dom, mode)`. A new service group needs its librpmi
encodings, and the SCP image must register it (`rpmi/scp_rpmi.c`). The
librpmi arena (256 bytes, 120 used) is sized for one shmem and one transport.

## References

- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../../../docs/PMU_SOFTWARE_CONTRACT.md)
  §1 (agents, windows, queue layout), §3 (RPMI services), §5.
- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.1 PD6 (two agents), §15.
- `src/pmu/fw/vendor/librpmi` (v1.0.0, unmodified).
- Background only: [`docs/SOC4_DESIGN.md`](../../../../docs/SOC4_DESIGN.md) §9.7, §9.8, §10.3,
  §10.4, §11.1.
