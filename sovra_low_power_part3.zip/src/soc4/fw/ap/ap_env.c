/* librpmi's environment on the AP: what its transport layer needs.
 *
 * The AP links three librpmi files (rpmi_shmem.c, rpmi_transport.c,
 * rpmi_transport_shmem.c; src/soc4/fw/Makefile). They ask the platform for
 * rpmi_env_zalloc (LR include/librpmi_env.h:218) and rpmi_env_free (:225);
 * rpmi_env_printf (:449) only in LIBRPMI_DEBUG builds, which this is not, and
 * rpmi_env_writel (:429) only from SYSTEM_MSI, which is not linked. The rest
 * of that header is static inlines librpmi carries itself.
 *
 * THE ARENA, 256 bytes, every block rounded to 8 (rpmi_shmem's 64-bit base):
 * rpmi_shmem 32, rpmi_transport_shmem 56, its queue table 2 x 16 = 32: 120
 * bytes, all at ap_rpmi_init() (pmu/fw/port/rpmi_env.h has the same figures).
 */
#include <librpmi.h>
#include "lib.h"

#define AP_ENV_ALIGN  8u
#define AP_ENV_ARENA  256u

static uint8_t  arena[AP_ENV_ARENA] __attribute__((aligned(AP_ENV_ALIGN)));
static uint32_t used;

void *rpmi_env_zalloc(rpmi_size_t size)
{
  if (size > AP_ENV_ARENA - used) return 0;
  uint8_t *p = &arena[used];
  used += (size + AP_ENV_ALIGN - 1u) & ~(AP_ENV_ALIGN - 1u);
  return memset(p, 0, size);
}

void rpmi_env_free(void *ptr)
{
  (void)ptr;                     /* the AP destroys nothing */
}
