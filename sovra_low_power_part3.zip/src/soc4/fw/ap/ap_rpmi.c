/* The AP's RPMI client over librpmi's transport. See ap_rpmi.h. */
#include <librpmi.h>
#include "ap_rpmi.h"
#include "soc4_regs.h"
#include "scp_regs.h"
#include "sim.h"
#include "lib.h"

/* rpmi/scp_rpmi.h's geometry, which the SCP created the transport with. */
#define AP_SLOT    64u               /* SCP_RPMI_SLOT_SIZE = RPMI_SLOT_SIZE_MIN */
#define AP_QUEUE   (AP_SLOT * 8u)    /* SCP_RPMI_QUEUE_SIZE                     */
#define AP_SHMEM   (2u * AP_QUEUE)   /* SCP_RPMI_SHMEM_SIZE                     */
#define AP_POLL    32u               /* cycles between looks at the ACK queue   */

_Static_assert(AP_SHMEM == SOC4_QMEM_SIZE, "the transport fills the queue memory");

struct ap_rpmi_stats ap_rpmi_stats;

static struct rpmi_transport *tr;
static uint16_t token;

/* struct rpmi_shmem_platform_ops (LR include/librpmi.h:395-407). Plain loads
   and stores: the AP's Ibex has no data cache. lib/string.c's memcpy is
   byte-wise, so each byte is one TL-UL access with one mask bit, which the
   queue memory takes (tlul_adapter_sram ByteAccess = 1, soc4_mbx.sv). */
static enum rpmi_error ap_rd(void *priv, rpmi_uint64_t a, void *in, rpmi_uint32_t n)
{
  (void)priv;
  memcpy(in, (const void *)(uintptr_t)a, n);
  return RPMI_SUCCESS;
}

static enum rpmi_error ap_wr(void *priv, rpmi_uint64_t a, const void *out, rpmi_uint32_t n)
{
  (void)priv;
  memcpy((void *)(uintptr_t)a, out, n);
  return RPMI_SUCCESS;
}

/* A no-op: the SCP initialised the queues, and a fill from here would wipe
   them (LR lib/rpmi_transport_shmem.c:218-220). */
static enum rpmi_error ap_fill(void *priv, rpmi_uint64_t a, char c, rpmi_uint32_t n)
{
  (void)priv; (void)a; (void)c; (void)n;
  return RPMI_SUCCESS;
}

static const struct rpmi_shmem_platform_ops ap_ops = { ap_rd, ap_wr, ap_fill };

int ap_rpmi_init(void)
{
  struct rpmi_shmem *sh = rpmi_shmem_create("ap", SOC4_AP_QMEM, AP_SHMEM, &ap_ops, 0);
  if (!sh) return AP_E_INIT;
  /* p2a_req_queue_size 0: A2P requests and P2A acknowledgements only, as the
     SCP (rpmi/scp_rpmi.c). */
  tr = rpmi_transport_shmem_create("ap", AP_SLOT, AP_QUEUE, 0, sh);
  return tr ? AP_OK : AP_E_INIT;
}

/* One slot. Word-aligned so the header's 16-bit fields are aligned. */
union ap_slot {
  struct rpmi_message msg;
  uint32_t            w[AP_SLOT / 4u];
};

int ap_call(uint16_t grp, uint8_t srv, const void *req, uint16_t len,
            void *rsp, uint16_t *rlen, uint32_t tmo)
{
  static union ap_slot q, a;
  if (!tr) return AP_E_INIT;
  if (len > AP_RPMI_DATA_MAX) return AP_E_PARAM;
  ap_rpmi_stats.calls++;

  /* The header (LR include/librpmi.h:26-110): group [15:0], service [23:16],
     flags [31:24] with the type in [2:0]; data length [15:0], token [31:16]. */
  memset(&q, 0, sizeof q);
  q.msg.header.servicegroup_id = grp;
  q.msg.header.service_id      = srv;
  q.msg.header.flags           = RPMI_MSG_NORMAL_REQUEST;
  q.msg.header.datalen         = len;
  q.msg.header.token           = ++token;
  if (len) memcpy(q.msg.data, req, len);
  ap_rpmi_stats.last_token = token;

  /* Tail first, then the doorbell: OpenSBI's order, with its default value 1
     (lib/utils/mailbox/fdt_mailbox_rpmi_shmem.c:300-305, 616-617). */
  if (rpmi_transport_enqueue(tr, RPMI_QUEUE_A2P_REQ, &q.msg) != RPMI_SUCCESS) {
    ap_rpmi_stats.full++;
    return AP_E_FULL;
  }
  mmio_write32(SOC4_AP_DOORBELL, 1u);

  const uint32_t t0 = sim_cycle();
  for (;;) {
    if (rpmi_transport_dequeue(tr, RPMI_QUEUE_P2A_ACK, &a.msg) == RPMI_SUCCESS) break;
    if (sim_cycle() - t0 > tmo) {
      ap_rpmi_stats.timeouts++;
      return AP_E_TIMEOUT;
    }
    const uint32_t t1 = sim_cycle();
    while (sim_cycle() - t1 < AP_POLL) { }
  }

  /* The acknowledgement: type ACKNOWLEDGEMENT, the same group, service and
     token (LR lib/rpmi_context.c:339-343). */
  const struct rpmi_message_header *h = &a.msg.header;
  if ((h->flags & RPMI_MSG_FLAGS_TYPE) != RPMI_MSG_ACKNOWLEDGEMENT ||
      h->servicegroup_id != grp || h->service_id != srv || h->token != token ||
      h->datalen > AP_RPMI_DATA_MAX) {
    ap_rpmi_stats.badacks++;
    return AP_E_BADACK;
  }
  *rlen = h->datalen;
  if (h->datalen) memcpy(rsp, a.msg.data, h->datalen);
  return AP_OK;
}
