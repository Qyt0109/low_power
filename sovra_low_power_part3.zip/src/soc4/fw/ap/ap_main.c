/* soc4_ap: the AP's test program on soc4 (make soc4).
 *
 * docs/SOC4_DESIGN.md Sections 9.8 and 11.1. The AP is RPMI agent 0 of 2 (the
 * RPU, agent 1, is a testbench BFM). It drives the SCP's DEVICE_POWER service
 * through librpmi's transport (ap/ap_rpmi.h) and plays the software in the two
 * accelerators through its own sim control (AP_SIM, TAG "ap": IP_SEED, IP_CMD).
 *
 * Every expectation below is an encoding from librpmi itself (its macros and
 * enums), never a number written here. Each failed expectation counts in
 * `fails`. At the end the AP halts with fails + (TB_ERRORS != 0): 0 is a pass.
 *
 * CHECKPOINTS. CHECK {[15:8] dom, [3:0] mode} on the AP's sim control asks the
 * testbench to check domain dom in PPU mode `mode`: the PPU-level CHECK and
 * the IP-state rule for (dom, mode) (Sections 10.3, 10.4). The AP then waits
 * for TB_CHECKS to advance, bounded by CKPT_TMO cycles; a checkpoint the
 * testbench never acknowledges is a failure. IP-state rules that wait (up to
 * 20000 cycles for a CPU to boot or wake) may finish after that; the AP waits
 * TB_SETTLE cycles before it reads TB_ERRORS at the end.
 *
 * Waits after an OFF vote are fixed: the policy waits out 1 ms (100 000
 * cycles) of hysteresis, and CPU1's power-off adds three back-offs (100, 200,
 * 400 us) before it is forced (mod/policy.h).
 */
#include <stdint.h>
#include <librpmi.h>
#include "console.h"
#include "sim.h"
#include "lib.h"
#include "soc4_regs.h"
#include "ap_rpmi.h"
#include "ppu_v1.h"           /* the mode encodings only (DEN 0051E Table 3-2) */

#define TMO_CALL    400000u      /* an ON is bounded by on_ticks, 100 000      */
#define CKPT_TMO    100000u
#define TB_SETTLE    30000u
#define W_HYST      150000u      /* hysteresis + 50 000                        */
#define W_CPU1      220000u      /* hysteresis + 3 back-offs + 50 000          */
#define W_ALL       250000u
#define W_FILL         100u      /* a fill of all eight banks (>= 64 cycles)   */
#define SEED_ACC0     0x5Au
#define SEED_ACC1     0xC3u

static unsigned fails, checks;
static const char *step = "A0";

#define CK(c, ...) do { checks++; if (!(c)) { fails++;                          \
      con_printf("ap: FAIL %s (line %d): ", step, __LINE__);                     \
      con_printf(__VA_ARGS__); con_putc('\n'); } } while (0)

static void wait_cycles(uint32_t n)
{
  const uint32_t t0 = sim_cycle();
  while (sim_cycle() - t0 < n) { }
}

static void ckpt(unsigned dom, unsigned mode)
{
  const uint32_t c0 = sim_tb_checks();
  sim_check(dom, mode);
  const uint32_t t0 = sim_cycle();
  while (sim_tb_checks() == c0)
    if (sim_cycle() - t0 > CKPT_TMO) {
      CK(0, "checkpoint (%u, %u) not acknowledged by the testbench", dom, mode);
      return;
    }
}

/* A request of n words; the response's words in r[], its length in bytes
   returned (or a negative AP_E_*). */
static int rq(uint16_t grp, uint8_t srv, const uint32_t *req, unsigned n, uint32_t *r)
{
  uint16_t rlen = 0;
  memset(r, 0, AP_RPMI_DATA_MAX);
  int rc = ap_call(grp, srv, req, (uint16_t)(4u * n), r, &rlen, TMO_CALL);
  CK(rc == AP_OK, "group 0x%x service 0x%x: ap_call %d", grp, srv, rc);
  return rc == AP_OK ? (int)rlen : rc;
}

static void set_state(unsigned id, uint32_t state)
{
  uint32_t req[2] = { id, state }, r[14];
  int len = rq(RPMI_SRVGRP_DEVICE_POWER, RPMI_DPWR_SRV_SET_DPWR_STATE, req, 2, r);
  CK(len == 4 && r[0] == (uint32_t)RPMI_SUCCESS, "SET_DPWR_STATE(%u, %u): len %d status %d",
     id, state, len, (int)r[0]);
}

static void expect_state(unsigned id, uint32_t state)
{
  uint32_t req[1] = { id }, r[14];
  int len = rq(RPMI_SRVGRP_DEVICE_POWER, RPMI_DPWR_SRV_GET_DPWR_STATE, req, 1, r);
  CK(len == 8 && r[0] == (uint32_t)RPMI_SUCCESS && r[1] == state,
     "GET_DPWR_STATE(%u): len %d status %d state %u, expected %u", id, len, (int)r[0], r[1],
     state);
}

/* The accelerator's own software: fill its eight banks with a seeded pattern
   (IP_CMD 01 for domain n at [2n+1:2n], hal/sim.h). */
static void acc_fill(unsigned dom, uint8_t seed)
{
  sim_ip_seed(seed);
  sim_ip_cmd(1u << (2u * dom));
  wait_cycles(W_FILL);
  sim_ip_cmd(0);
}

int main(void)
{
  con_puts("\nsoc4_ap: the AP, an RPMI agent on soc4 (librpmi v1.0.0 transport)\n");
  uint32_t r[14], req[2];
  int len;

  /* A0: the transport. The SCP has initialised the queues before AP_RUN. */
  step = "A0";
  CK(ap_rpmi_init() == AP_OK, "librpmi transport create");
  CK(mmio_read32(SOC4_AP_QMEM + 0x000) == 0 && mmio_read32(SOC4_AP_QMEM + 0x040) == 0 &&
     mmio_read32(SOC4_AP_QMEM + 0x200) == 0 && mmio_read32(SOC4_AP_QMEM + 0x240) == 0,
     "queue heads and tails not 0 at start");

  /* A1: BASE (LR include/librpmi.h:217-236; lib/rpmi_context.c:64-190). */
  step = "A1";
  len = rq(RPMI_SRVGRP_BASE, RPMI_BASE_SRV_GET_SPEC_VERSION, 0, 0, r);
  CK(len == 8 && r[0] == RPMI_SUCCESS &&
     r[1] == RPMI_BASE_VERSION(RPMI_SPEC_VERSION_MAJOR, RPMI_SPEC_VERSION_MINOR),
     "GET_SPEC_VERSION: len %d %d %08x", len, (int)r[0], r[1]);
  len = rq(RPMI_SRVGRP_BASE, RPMI_BASE_SRV_GET_IMPLEMENTATION_VERSION, 0, 0, r);
  CK(len == 8 && r[0] == RPMI_SUCCESS &&
     r[1] == RPMI_BASE_VERSION(LIBRPMI_IMPL_VERSION_MAJOR, LIBRPMI_IMPL_VERSION_MINOR),
     "GET_IMPLEMENTATION_VERSION: len %d %d %08x", len, (int)r[0], r[1]);
  len = rq(RPMI_SRVGRP_BASE, RPMI_BASE_SRV_GET_IMPLEMENTATION_IDN, 0, 0, r);
  CK(len == 8 && r[0] == RPMI_SUCCESS && r[1] == LIBRPMI_IMPL_ID,
     "GET_IMPLEMENTATION_IDN: len %d %d %08x", len, (int)r[0], r[1]);
  static const struct { uint16_t g; uint8_t present; } PROBE[] = {
    { RPMI_SRVGRP_BASE, 1 }, { RPMI_SRVGRP_DEVICE_POWER, 1 }, { RPMI_SRVGRP_SYSTEM_RESET, 0 },
  };
  for (unsigned i = 0; i < ARRAY_SIZE(PROBE); i++) {
    req[0] = PROBE[i].g;
    len = rq(RPMI_SRVGRP_BASE, RPMI_BASE_SRV_PROBE_SERVICE_GROUP, req, 1, r);
    CK(len == 8 && r[0] == RPMI_SUCCESS && ((r[1] != 0) == (PROBE[i].present != 0)),
       "PROBE_SERVICE_GROUP 0x%x: len %d %d version %08x", PROBE[i].g, len, (int)r[0], r[1]);
  }
  len = rq(RPMI_SRVGRP_BASE, RPMI_BASE_SRV_GET_ATTRIBUTES, 0, 0, r);
  CK(len == 20 && r[0] == RPMI_SUCCESS && (r[1] & RPMI_BASE_FLAGS_F0_PRIVILEGE),
     "BASE GET_ATTRIBUTES: len %d %d flags %08x (M-mode context)", len, (int)r[0], r[1]);

  /* A2: DEVICE_POWER discovery (LR lib/rpmi_service_group_device_power.c:177-279). */
  step = "A2";
  len = rq(RPMI_SRVGRP_DEVICE_POWER, RPMI_DPWR_SRV_GET_NUM_DOMAINS, 0, 0, r);
  CK(len == 8 && r[0] == RPMI_SUCCESS && r[1] == SOC4_NDOM, "GET_NUM_DOMAINS: len %d %d %u",
     len, (int)r[0], r[1]);
  static const char *const NAME[SOC4_NDOM] = { "CPU0", "CPU1", "ACC0", "ACC1" };
  for (unsigned id = 0; id < SOC4_NDOM; id++) {
    req[0] = id;
    len = rq(RPMI_SRVGRP_DEVICE_POWER, RPMI_DPWR_SRV_GET_ATTRIBUTES, req, 1, r);
    const char *nm = (const char *)&r[3];
    CK(len == 28 && r[0] == RPMI_SUCCESS && r[1] == 0 && r[2] == 0 &&
       memcmp(nm, NAME[id], 5) == 0, "GET_ATTRIBUTES(%u): len %d %d flags %u latency %u",
       id, len, (int)r[0], r[1], r[2]);
  }
  for (unsigned id = 0; id < SOC4_NDOM; id++) {
    expect_state(id, RPMI_DPWR_STATE_OFF);
    ckpt(id, PPU_MODE_OFF);
  }

  /* A3-A6: each domain ON; the answer comes once PPU_PWSR shows ON. */
  step = "A3"; set_state(SOC4_CPU0, RPMI_DPWR_STATE_ON); ckpt(SOC4_CPU0, PPU_MODE_ON);
  step = "A4"; set_state(SOC4_CPU1, RPMI_DPWR_STATE_ON); ckpt(SOC4_CPU1, PPU_MODE_ON);
  step = "A5"; set_state(SOC4_ACC0, RPMI_DPWR_STATE_ON); acc_fill(SOC4_ACC0, SEED_ACC0);
  ckpt(SOC4_ACC0, PPU_MODE_ON);
  step = "A6"; set_state(SOC4_ACC1, RPMI_DPWR_STATE_ON); acc_fill(SOC4_ACC1, SEED_ACC1);
  ckpt(SOC4_ACC1, PPU_MODE_ON);

  /* A7-A8: CPU0 to FULL_RET and back: the core's registers survive. */
  step = "A7"; set_state(SOC4_CPU0, RPMI_DPWR_STATE_OFF); expect_state(SOC4_CPU0, RPMI_DPWR_STATE_OFF);
  wait_cycles(W_HYST); ckpt(SOC4_CPU0, PPU_MODE_FULL_RET);
  step = "A8"; set_state(SOC4_CPU0, RPMI_DPWR_STATE_ON); ckpt(SOC4_CPU0, PPU_MODE_ON);

  /* A9-A10: CPU1 never sleeps: denied four times, then forced OFF; ON
     reloads it and it restarts from its boot address. */
  step = "A9"; set_state(SOC4_CPU1, RPMI_DPWR_STATE_OFF); wait_cycles(W_CPU1); ckpt(SOC4_CPU1, PPU_MODE_OFF);
  step = "A10"; set_state(SOC4_CPU1, RPMI_DPWR_STATE_ON); ckpt(SOC4_CPU1, PPU_MODE_ON);

  /* A11-A14: MEM_RET keeps ACC0's RAM; OFF loses ACC1's. */
  step = "A11"; set_state(SOC4_ACC0, RPMI_DPWR_STATE_OFF); wait_cycles(W_HYST); ckpt(SOC4_ACC0, PPU_MODE_MEM_RET);
  step = "A12"; set_state(SOC4_ACC0, RPMI_DPWR_STATE_ON); ckpt(SOC4_ACC0, PPU_MODE_ON);
  step = "A13"; set_state(SOC4_ACC1, RPMI_DPWR_STATE_OFF); wait_cycles(W_HYST); ckpt(SOC4_ACC1, PPU_MODE_OFF);
  step = "A14"; set_state(SOC4_ACC1, RPMI_DPWR_STATE_ON); ckpt(SOC4_ACC1, PPU_MODE_ON);

  /* A15: all four OFF at once. */
  step = "A15";
  for (unsigned id = 0; id < SOC4_NDOM; id++) set_state(id, RPMI_DPWR_STATE_OFF);
  wait_cycles(W_ALL);
  for (unsigned id = 0; id < SOC4_NDOM; id++) expect_state(id, RPMI_DPWR_STATE_OFF);
  ckpt(SOC4_CPU0, PPU_MODE_FULL_RET); ckpt(SOC4_CPU1, PPU_MODE_OFF); ckpt(SOC4_ACC0, PPU_MODE_MEM_RET); ckpt(SOC4_ACC1, PPU_MODE_OFF);

  /* A16: the verdict. */
  step = "A16";
  wait_cycles(TB_SETTLE);
  const uint32_t tbc = sim_tb_checks(), tbe = sim_tb_errors();
  con_printf("soc4_ap: %u checks, %u fails; %u calls, %u timeouts; testbench %u checks, %u errors\n",
             checks, fails, ap_rpmi_stats.calls, ap_rpmi_stats.timeouts, tbc, tbe);
  return (int)(fails + (tbe != 0u));
}
