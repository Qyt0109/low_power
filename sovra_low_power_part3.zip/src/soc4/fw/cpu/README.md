# The CPU program (CPU0 and CPU1)

One assembly image that both of soc4's CPU-domain Ibex cores run; the
behaviour is chosen by `mhartid`. The SCP embeds it and copies it into a
CPU's 4 KB RAM through the load port when it cold-boots the domain. Its job
is to make power-state effects visible: CPU0 proves that `FULL_RET` keeps the
core's state, CPU1 proves that a core that never sleeps is forced off.

## Files

| File | What |
|---|---|
| `cpu.S` | The program: vector table, reset, per-hart code, trap handler |
| `cpu.ld` | Link script: one 4 KB RAM at 0; asserts the vector table layout and that code ends at or below `0xC00` |
| `cpu_img.S` | Embeds `cpu.bin` (`.incbin CPU_BIN`) as the word-aligned symbol `cpu_img` in `.rodata` of the SCP images |

## Behaviour

Ibex takes traps at `mtvec` = boot address (0, vectored) and fetches its
first instruction at boot address + `0x80`, so the image has 32 jumps to
`cpu_trap` at `0x00`–`0x7C` and the reset jump at `0x80`. Assembly only, so
the register signature does not depend on a compiler.

On every boot (`cpu_start`): `sp = 0x1000`, increment `BOOTS`, write
`MARKER = 0xC0DE_0000 | mhartid`, then:

| Hart | Behaviour |
|---|---|
| CPU0 (`mhartid` 0) | Loads `s0`..`s11` with `SOC4_CPU_SIG(i, 0)` = `0x5100_0000 | i << 8`, sets `mie.MEIE` (`mstatus.MIE` stays 0) and sleeps in WFI. The adapter's wake pulse on `irq_external` ends the WFI with no trap. After each wake it increments `WAKES`, dumps `s0`..`s11` to `DUMP`, and sleeps again. In WFI `core_sleep_o` is 1, so its adapter accepts a quiescence request |
| CPU1 (`mhartid` 1) | Counts forever, storing every iteration to `COUNT`. It never sleeps, so its adapter denies every quiescence request and its power-off is always forced |
| either | An unexpected trap writes `mcause` to `TRAP` and loops in WFI |

Through `FULL_RET` with its RAM retained, CPU0's core is retained too and
resumes where it stopped: after a wake the `DUMP` words must equal the
signature (`soc4_stress` `PCSM.RAM`, `soc4`'s CPU0 checkpoints). After `OFF`
the next ON is a cold boot (reload, `BOOTS` and `MARKER` written again).

## Data words

Defined in `hal/soc4_regs.h` (`SOC4_CPU_*`); the testbench reads them from
the always-on array, the SCP through the load port.

| Offset | Name | Content |
|---|---|---|
| `0xC00` | `MARKER` | `0xC0DE_0000 | mhartid`, after each boot |
| `0xC04` | `BOOTS` | boots since the image was loaded |
| `0xC08` | `WAKES` | CPU0: WFI returns |
| `0xC0C` | `TRAP` | `mcause` of an unexpected trap, else 0 |
| `0xC10`–`0xC3C` | `DUMP` | CPU0: `s0`..`s11` after each wake |
| `0xC80` | `COUNT` | CPU1: its loop counter |
| `0xD00`–`0xFFF` | stack | `sp` starts at `0x1000` |

The image holds 0 in every data word: the build pads `cpu.bin` with zeros to
exactly 4096 bytes (and fails if it is not), so the SCP's copy defines every
word. That matters because `tc_sram` starts X and Ibex asserts that fetched
data is known even when it prefetches past the code.

## Building and using

Built by `../Makefile` as `cpu.elf` → `cpu.bin` (with `-I hal`, without
`soc4_plat.h`'s C part). The code currently ends at `0x1A0`. `cpu_img.S` is
assembled into `soc4_scp`, `soc4_scp_m6` and `soc4_stress` with
`-DCPU_BIN="<OUT>/cpu.bin"`; the domain table's `SOC4_CPU_BOOT_DETAILS(n)`
points at `cpu_img`, and `mod/soc4_cpu.c` copies it.

## Extending it

Keep the code below `0xC00` (`cpu.ld` asserts it) and add any new data word
to `hal/soc4_regs.h`, where the testbench and SCP images read the layout. A
change to CPU0's sleep/wake loop must keep the wake-pulse rule of
`soc4_cpu_adp`: the pulse (8 cycles) must end before the next WFI.

## References

- `../../rtl/README.md` (`soc4_cpu_dom`, `soc4_cpu_ram`, `soc4_cpu_adp`).
- Background only: [`docs/SOC4_DESIGN.md`](../../../../docs/SOC4_DESIGN.md) §4.7, §9.5, §9.9.
