/* soc4_scp: the SCP's product firmware on soc4. Boot, then the RPMI server.
 *
 * docs/SOC4_DESIGN.md Section 9.6 (decision 3). The boot order:
 *
 *   W  the watchdog (platform plan H18, F12; hal/scp_wdog.h, mod/flog.h): its
 *      CAUSE says why the SCP (re)started, and is cleared. The block kept
 *      across a reset (the fault log, the votes) is kept if the reset was not
 *      a power-on and the block checks, else started anew. The watchdog is
 *      armed and locked with SCP_PLAT_WDOG_TIMEOUT: from here on only the main
 *      loop's kick holds it off. A watchdog reset is logged, and the log is
 *      printed. A boot after a reset that was not a power-on TAKES OVER (steps 1
 *      and 3 below): the PPUs, the domains, soc4_ctrl (the CPUs' boot and
 *      fetch, AP_RUN) and the mailbox kept their state
 *   0  the interrupt block: scp_irq_init() programs every input from the
 *      platform's input table (level or edge; the policy's inputs enabled,
 *      the PPUs' and the doorbell's left to their owners) and checks the
 *      block's input count against the table
 *   1  the PPUs: pd_init() probes all four, programs IMR/AIMR, clears
 *      ISR/AISR, the retention RAM registers each PPU has (from the domain
 *      table), the entry delay and the device control delays, and unmasks
 *      the PPUs' inputs 0-3 of the block. It does not touch PPU_PWPR, so all four
 *      stay in PPU OFF (DEF_PWR_POLICY = OFF). Each PPU's identification is
 *      then checked against the build (Section 3.3; the table's idr0, idr1).
 *   2  the mailbox: its agent count checked against the agent table, each
 *      agent's doorbell input checked against the input table, then each
 *      agent's firewall entry programmed (FW_VAL, FW_MASK, then FW_EN): window
 *      k admits agent k's source IDs, and only them (decision 10; platform
 *      plan H12)
 *   3  RPMI: one transport per agent on its queue window, which librpmi
 *      zeroes (LR lib/rpmi_transport_shmem.c:218-220); BASE + DEVICE_POWER (4
 *      domains), one M-mode context each; the policy; the main loop
 *   4  AP_RUN = 1: the AP may start, now that the queues are initialised
 *
 * TAKING OVER: step 1 is pd_adopt(), which writes no PPU that already holds
 * its settings; step 2 programs the same firewall entries again; step 3
 * re-creates the transports, whose queues librpmi zeroes -- an agent's
 * request in flight across the reset gets no answer and times out
 * (rpmi/scp_rpmi.h says what an agent sees) -- keeps the votes, and adopts
 * every domain as the PPUs and the votes say (mod/policy.h, ADOPTION), with no
 * PPU write; step 4 writes AP_RUN = 1 again, which it already is.
 *
 * IN THE MAIN LOOP the work hook also reads each transport's firewall DENY_CNT
 * and logs the denials since the last look (FLOG_FW_DENY), with FW_LAST.
 *
 * A failure at boot is fatal: the console says which, and the run halts with
 * 0xDEAD5400 | code (the testbench's HALT; there is none in silicon). Once the
 * server runs it never returns.
 */
#include <stdint.h>
#include "console.h"
#include "sim.h"
#include "pd.h"
#include "scp_rpmi.h"
#include "scp_loop.h"
#include "soc4_regs.h"
#include "policy.h"
#include "scp_irq.h"
#include "scp_wdog.h"
#include "flog.h"

enum { SOC4_E_PPU = 1, SOC4_E_ID = 2, SOC4_E_RPMI = 3, SOC4_E_IRQ = 4, SOC4_E_MBX = 5 };

/* THE WATCHDOG'S TIMEOUT must cover the longest time between two kicks that is
   not a hang (rpmi/scp_loop.h): a sleep of at most SCP_LOOP_KICK_TICKS, then
   one pass's work. What can make a pass long is a synchronous ON, each bounded
   by the policy's power-up deadline (policy_cfg_default.on_ticks, 1 ms): at
   most SCP_RPMI_DRAIN_BUDGET from each transport's drain, and one per
   POWER_UP input of the input table; one more for the rest of the pass. */
#define SCP_PU_COUNT(id, nm, mode, en, act, arg) + ((act) == SCP_ACT_POWER_UP)
enum { SCP_NUM_POWER_UP = 0 SCP_PLAT_INPUTS(SCP_PU_COUNT) };
#undef SCP_PU_COUNT
_Static_assert((uint64_t)SCP_PLAT_WDOG_TIMEOUT - SCP_LOOP_KICK_TICKS >=
               (uint64_t)(SCP_NUM_XPORT * SCP_RPMI_DRAIN_BUDGET + SCP_NUM_POWER_UP + 1u) *
               S4_TICKS_PER_MS, "SCP_PLAT_WDOG_TIMEOUT is shorter than a sleep and the longest pass");

static void __attribute__((noreturn)) die_code(unsigned code, const char *what)
{
  con_printf("scp: FATAL: %s (code %u)\n", what, code);
  sim_halt(0xDEAD5400u | code);
  for (;;) { }
}

/* Section 3.3: what each PPU must report, PPU_IDR0 and PPU_IDR1 from the
   domain table (soc4_plat.h gives the bits), one Q-Channel (DEVCHAN), and
   PPU_AIDR 0x11, architecture v1.1 (DEN 0051E Table 5-29). */
static void check_ident(unsigned d)
{
  const struct ppu *p = &pd_tab[d].ppu;
  const struct pd_cfg *c = &pd_cfg[d];
  if (p->aidr != PPU_AIDR_V1_1 || p->idr0 != c->idr0 || p->idr1 != c->idr1 ||
      p->channels != 1u) {
    con_printf("scp: %s: AIDR %08x IDR0 %08x IDR1 %08x, expected %08x %08x %08x\n",
               c->name, p->aidr, p->idr0, p->idr1, PPU_AIDR_V1_1, c->idr0, c->idr1);
    die_code(SOC4_E_ID, "a PPU is not the one the platform was built with");
  }
}

static const struct scp_rpmi_hooks hooks = {
  .dpwr_vote = policy_vote,
};

/* The firewall's denials since the last look, per transport, into the fault
   log. DENY_CNT is never cleared (the testbench counts on it): what was last
   logged is kept in the block that survives a watchdog reset. */
static void fw_watch(void)
{
  for (unsigned k = 0; k < SCP_NUM_AGENTS; k++) {
    const uint32_t n = mmio_read32(SOC4_MBX_DENY_CNT(k));
    const uint32_t seen = scp_keep.deny_seen[k];
    if (n == seen) continue;
    const uint32_t more = (n > seen) ? n - seen : n;
    scp_keep.deny_seen[k] = n;
    flog_commit();
    flog_add(FLOG_FW_DENY, k, ((more > 0xFFFu ? 0xFFFu : more) << 20) |
                              (mmio_read32(SOC4_MBX_FW_LAST) & 0xFFFFFu));
  }
}

static void work(void)
{
  policy_work();
  fw_watch();
}

static const struct scp_loop_hooks loop_hooks = {
  .work     = work,
  .deadline = policy_deadline,
};

int main(void)
{
  con_puts("\nsoc4_scp: SCP firmware, RPMI v1.0 over librpmi v1.0.0, 4 domains, 2 agents\n");

  /* W. Why we are here; the kept block and the log; then the watchdog. */
  const uint32_t cause = scp_wdog_cause();
  scp_wdog_clear(cause);
  const bool takeover = !(cause & SCP_WDOG_CAUSE_POR);
  const bool kept = flog_boot(cause);
  scp_wdog_arm(SCP_PLAT_WDOG_TIMEOUT);
  con_printf("scp: reset cause 0x%08x (%s%s%s%s), %u watchdog reset(s) since power-on; record %s\n",
             cause, (cause & SCP_WDOG_CAUSE_POR) ? "power-on" : "",
             (cause & SCP_WDOG_CAUSE_WDOG) ? "watchdog" : "",
             (cause & SCP_WDOG_CAUSE_BADKICK) ? ", wrong kick" : "",
             (cause & SCP_WDOG_CAUSE_DRAINTO) ? ", AXI not drained" : "",
             SCP_WDOG_RESETS(cause), kept ? "kept" : "new");
  if (cause & SCP_WDOG_CAUSE_WDOG) flog_add(FLOG_WDOG, FLOG_DOM_NONE, cause);
  flog_dump();

  /* 0. The interrupt block, from the input table. */
  if (scp_irq_init() != 0) die_code(SOC4_E_IRQ, "the interrupt block's input count is not the table's");

  /* 1. The PPUs: probed and set up, or, after a reset of the SCP alone, taken
        over as they are. */
  if ((takeover ? pd_adopt() : pd_init()) != (int)PD_COUNT)
    die_code(SOC4_E_PPU, "pd_init did not find every PPU");
  for (unsigned d = 0; d < PD_COUNT; d++) check_ident(d);

  /* 2. The mailbox, from the agent table: one firewall entry per agent. */
  if ((mmio_read32(SOC4_MBX_INFO) & 0xFFu) != SCP_NUM_AGENTS)
    die_code(SOC4_E_MBX, "the mailbox's agent count is not the agent table's");
  for (unsigned k = 0; k < SCP_NUM_AGENTS; k++) {
    const struct scp_agent *a = &scp_agent[k];
    if (a->db_in >= SCP_NUM_IN || scp_irq_db_bit(k) != SCP_IN_BIT(a->db_in))
      die_code(SOC4_E_MBX, "an agent's doorbell input is not its input table entry");
    mmio_write32(SOC4_MBX_FW_VAL(k), a->src);
    mmio_write32(SOC4_MBX_FW_MASK(k), a->mask);
    mmio_write32(SOC4_MBX_FW_EN(k), 1u);
  }

  /* 3. RPMI: one transport per agent, on its window. */
  int rc = scp_rpmi_init(&hooks);
  if (rc != SCP_RPMI_OK) {
    con_printf("scp: scp_rpmi_init: %d\n", rc);
    die_code(SOC4_E_RPMI, "the RPMI server did not start");
  }
  policy_init(0);
  if (takeover) {
    policy_adopt(kept);
    con_printf("scp: took over: %u domain(s) not in low power, %u PPU(s) reprogrammed\n",
               policy_adopted, pd_adopt_rewrites);
  }
  scp_loop_init(&loop_hooks);

  /* 4. The AP may start. */
  mmio_write32(SOC4_CTRL_AP_RUN, 1u);
  con_puts("scp: ready; AP_RUN set\n");
  scp_loop_run();
}
