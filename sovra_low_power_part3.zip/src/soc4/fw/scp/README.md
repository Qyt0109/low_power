# soc4_scp — the SCP's product firmware on soc4

`main.c` is the platform's entry point for the SCP product image: it boots
the SCP, sets up the interrupt block, the PPUs, the mailbox firewall and the
RPMI server from the platform tables, lets the AP start, and runs the server
loop forever. Almost all of the logic is the shared firmware in `src/pmu/fw`
(PPU driver, domain manager `pd`, policy, fault log, RPMI server and loop,
librpmi); this file is the soc4 glue and the boot order.

## Files

| File | What |
|---|---|
| `main.c` | Boot sequence, identity checks, firewall programming, the main loop's work hook, the fatal-error path |

## The boot sequence

| Step | What happens |
|---|---|
| W | Read and clear the watchdog's `CAUSE`. If the reset was not a power-on, this is a **takeover**. `flog_boot()` keeps the persistent block (fault log, votes) if the reset was not a power-on and the block checks, else starts it anew. Arm and lock the watchdog with `SCP_PLAT_WDOG_TIMEOUT`; from here only the main loop's kick holds it off. Log a watchdog reset; print the log |
| 0 | `scp_irq_init()`: program every input from `SCP_PLAT_INPUTS` (level/edge; policy inputs enabled, PPU and doorbell inputs left to their owners) and check the block's input count against the table |
| 1 | `pd_init()` (or `pd_adopt()` on takeover, which writes no PPU that already holds its settings): probe the four PPUs, program IMR/AIMR, clear ISR/AISR, write the retention RAM registers each PPU has, the entry delay and device control delays, unmask PPU inputs 0–3. `PPU_PWPR` is not touched, so every domain stays `OFF`. Then check each PPU's `AIDR` (`0x11`, v1.1), `IDR0`, `IDR1` and channel count (one Q-Channel) against the domain table |
| 2 | Check the mailbox's `INFO` agent count against the agent table and each agent's doorbell input against its input entry; then per agent write `FW_VAL`, `FW_MASK`, then `FW_EN = 1`. Window k now admits agent k's source IDs only |
| 3 | `scp_rpmi_init()`: one transport per agent on its queue window (librpmi zeroes it), BASE + DEVICE_POWER (4 domains), one M-mode context each. `policy_init()`. On takeover, `policy_adopt()` adopts every domain as the PPUs and the kept votes say, with no PPU write |
| 4 | `AP_RUN = 1`: the AP may start now the queues exist (on takeover it already is 1) |

Then `scp_loop_run()`, which never returns. The loop's `work` hook runs
`policy_work()` and then `fw_watch()`, which reads each transport's
`DENY_CNT` and logs the denials since the last look (`FLOG_FW_DENY`, with
`FW_LAST`). `DENY_CNT` is never cleared (the testbench counts on it); the
last value seen is kept in the persistent block so a watchdog reset does not
log the same denials twice.

On takeover an agent's request in flight across the reset gets no answer
and times out on the agent's side (`rpmi/scp_rpmi.h` describes what the
agent sees).

## Failure at boot

Fatal: the console names the failure and the run halts with
`0xDEAD5400 | code` through the testbench's `HALT` register (silicon has
none, and would simply stop).

| Code | Meaning |
|---:|---|
| 1 | `SOC4_E_PPU`: `pd_init`/`pd_adopt` did not find every PPU |
| 2 | `SOC4_E_ID`: a PPU's identification does not match the domain table |
| 3 | `SOC4_E_RPMI`: the RPMI server did not start |
| 4 | `SOC4_E_IRQ`: the interrupt block's input count is not the table's |
| 5 | `SOC4_E_MBX`: the mailbox's agent count, or an agent's doorbell input, is not the table's |

A compile-time assertion checks that `SCP_PLAT_WDOG_TIMEOUT` minus the
loop's longest sleep (`SCP_LOOP_KICK_TICKS`) covers the longest pass of the
main loop: (`SCP_NUM_XPORT * SCP_RPMI_DRAIN_BUDGET` + the number of
`SCP_ACT_POWER_UP` inputs + 1) power-ups of at most 1 ms each.

## Building and running

Built by `../Makefile` as `soc4_scp` (and, with `-DSCP_MUT_PERM_OPEN`, as the
mutant `soc4_scp_m6` for `soc4neg` M6). It embeds the CPU image. Used by
`make soc4`, `soc4bfm`, `soc4ckrst`, `soc4neg`, `soc4pa` and `soc4bfmpa`
(`+firmware=build/fw/soc4/soc4_scp.vmem`). What the BFM runs exercise
(B0–B12, R0, R1, W1, K1) is listed in `src/Makefile` and
[../../README.md](../../README.md).

## Extending it

A new platform copies this file and keeps the order: watchdog, interrupt
block, PPUs, mailbox, RPMI, then let the agents run. Domains, agents and
inputs are not edited here: they come from `soc4_plat.h` (see
[../README.md](../README.md#how-to-add-or-remove-a-domain-an-agent-or-an-interrupt-input)).
A new periodic duty goes in the `work` hook; it must stay short, since the
watchdog timeout budget assumes a pass is bounded by its power-ups.

## References

- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.3 (F5, F6, F10, F11, F12),
  §15.2.
- [`docs/PMU_SOFTWARE_CONTRACT.md`](../../../../docs/PMU_SOFTWARE_CONTRACT.md)
  §3–5 (services, timing, what an agent sees).
- [`src/pmu/README.md`](../../../pmu/README.md) and the shared modules it
  calls: `mod/pd.h`, `mod/policy.h`, `mod/flog.h`, `hal/scp_irq.h`,
  `hal/scp_wdog.h`, `rpmi/scp_rpmi.h`, `rpmi/scp_loop.h`.
- Background only: [`docs/SOC4_DESIGN.md`](../../../../docs/SOC4_DESIGN.md) §3.3, §9.6.
