# soc4 mod: CPU image load and cold boot

`soc4_cpu` is how the SCP brings up a CPU domain on soc4: each Ibex runs from
its own 4 KB RAM, which the SCP fills through the CPU's load window before
releasing the core. Everything platform-specific comes from the domain
table's boot details (`pd_cfg[d].cpu`, a `struct pd_cpu` from
`soc4_plat.h`'s `SOC4_CPU_BOOT_DETAILS(n)`), so the code itself names no
address. Linked into `soc4_scp`, `soc4_scp_m6` and `soc4_stress` only.

## Files

| File | What |
|---|---|
| `soc4_cpu.h` | The API and the cold-sequence contract |
| `soc4_cpu.c` | `cpu_fetch`, `cpu_load`, `soc4_cpu_cold` |

## API

| Function | What | Returns |
|---|---|---|
| `void cpu_fetch(unsigned d, bool en)` | Read-modify-write of CPU d's fetch-enable bit (`fetch_reg`, `fetch_mask`) | — |
| `int cpu_load(unsigned d)` | Copies the image (`image`, `words`) to the load window (`load`) with word stores, then writes the boot address (`boot_reg` ← `boot_addr`). Refuses if `open_reg & open_mask` is clear | 0, or `SOC4_CPU_E_CLOSED` (-20, distinct from every `PD_E_*`) |
| `int soc4_cpu_cold(unsigned d, uint64_t until)` | The cold sequence below; every PPU step is bounded by `until` (`mtime`) | `PD_OK`, a `PD_E_*`, or `SOC4_CPU_E_CLOSED` |

`d` is a DOMAIN_ID whose table entry is `PD_KIND_CPU`.

## The cold sequence

| Step | Action | Why |
|---:|---|---|
| 1 | fetch enable = 0 | the core must not fetch from a RAM that is X (lost in `OFF`) or stale |
| 2 | static `ON` | core out of reset with fetch off: it idles |
| 3 | static `WARM_RST` | core held in reset (`dev_ret_rst_n` = 0); no device handshake, because the soc4 PPUs reset `PTCR.WARM_RST_DEVREQEN` to 0 (DEN 0051E Table 4-4) |
| 4 | `cpu_load`, then fetch enable = 1 | the image, the boot address |
| 5 | static `ON` | reset released: Ibex samples `boot_addr_i` and fetches at boot + `0x80` |
| 6 | return once `PPU_PWSR` shows `ON` | |

Each PPU step is `pd_request_static()` followed, if pending, by
`pd_complete()` (`src/pmu/fw/mod/pd.h`).

Rules:

- **Load only in step 4**, with the PPU in static `WARM_RST` and `PPU_PWSR`
  showing it. On the way down PPUHWSTAT still reads `ON` for a few cycles
  after the device clock stops, so the load port may answer without
  reaching the RAM at any other time (`soc4_cpu_ram`'s residual window).
- Word stores only: `lib/string.c`'s `memcpy` is byte-wise.
- `CPUn_BOOT[7:0]` must be 0 (Ibex fetches at `{boot[31:8], 8'h80}`).
- The caller may take step 1 earlier: the policy clears `FETCH_EN` before it
  re-enables a forced CPU domain's device channel, which itself needs static
  `ON` (`mod/policy.c`, ON step 4). Clearing it twice is harmless.

## Extending it

A new CPU domain needs no code here: give its domain-table entry a
`struct pd_cpu` with its own image, load window, open check, boot and fetch
registers. A CPU with a different load mechanism (a DMA, a ROM boot) would
replace `cpu_load`; the PPU steps around it would stay.

## References

- [`../cpu/README.md`](../cpu/README.md) (the image),
  [`../../rtl/README.md`](../../rtl/README.md) (`soc4_cpu_ram`, `soc4_ctrl`).
- `src/pmu/fw/mod/pd.h` (`struct pd_cpu`, `PD_E_*`).
- Background only: [`docs/SOC4_DESIGN.md`](../../../../docs/SOC4_DESIGN.md) §5.4, §9.5.
