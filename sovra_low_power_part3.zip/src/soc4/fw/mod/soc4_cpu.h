/* soc4's CPU domains: image load and boot control.
 *
 * docs/SOC4_DESIGN.md Section 9.5 (decisions 5 and 6). Every
 * function takes the CPU's DOMAIN_ID d, a PD_KIND_CPU entry of the domain
 * table, and every address and value it uses comes from that entry's boot
 * details, pd_cfg[d].cpu (mod/pd.h; soc4: soc4_plat.h). Each core runs from
 * its own 4 KB RAM, which the SCP fills through the CPU's load window
 * (soc4_cpu_ram.sv). The window is open only while the PPU's PPUHWSTAT is ON or
 * WARM_RST and the bank is neither asleep nor shut down (open_reg & open_mask,
 * soc4's CPU_STAT.ld_open); otherwise every access answers err, which is an
 * access fault on the SCP.
 *
 * THE COLD SEQUENCE (soc4_cpu_cold), inside one deadline:
 *
 *   1  fetch enable = 0                    the core must not fetch from a RAM
 *                                          that is X (lost in OFF) or stale
 *   2  static ON                           out of reset, fetch off: idles
 *   3  static WARM_RST                     core reset (dev_ret_rst_n = 0); no
 *                                          device handshake, because the soc4
 *                                          PPUs reset PTCR.WARM_RST_DEVREQEN
 *                                          to 0 (DEN 0051E Table 4-4)
 *   4  load: the image in word stores, the boot address, fetch enable = 1
 *   5  static ON                           reset released: Ibex samples
 *                                          boot_addr_i and fetches at +0x80
 *   6  return once PPU_PWSR shows ON
 *
 * THE LOAD RUNS ONLY IN STEP 4, with the PPU in static WARM_RST and PPU_PWSR
 * showing it. On the way down PPUHWSTAT still reads ON for a few cycles after
 * the device clock has stopped (Section 5.4, residual window), so a load at
 * any other time could be answered without reaching the RAM. The words are
 * copied with word stores: lib/string.c's memcpy is byte-wise.
 *
 * Step 1 may be taken earlier by the caller: the policy clears FETCH_EN before
 * it re-enables a forced domain's device channel, which itself needs static ON
 * (mod/policy.c, ON step 4).
 */
#ifndef SOC4_CPU_H
#define SOC4_CPU_H

#include <stdint.h>
#include <stdbool.h>

/* A load that found the window closed. In the pd_err range's neighbourhood, but
   distinct from every PD_E_* (mod/pd.h). */
#define SOC4_CPU_E_CLOSED  (-20)

void cpu_fetch(unsigned d, bool en);               /* read-modify-write of the
                                                      fetch-enable register */
int  cpu_load(unsigned d);                         /* step 4 without the fetch enable:
                                                      0 or SOC4_CPU_E_CLOSED */
/* Steps 1-6 (with step 1 too: clearing it twice is harmless). Every PPU step is
   bounded by `until` (mtime). Returns PD_OK or a PD_E_* / SOC4_CPU_E_CLOSED. */
int  soc4_cpu_cold(unsigned d, uint64_t until);

#endif
