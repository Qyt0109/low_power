/* soc4's CPU image load and boot control. See soc4_cpu.h.
 * Linked into soc4's SCP images only (src/soc4/fw/Makefile). */
#include "soc4_cpu.h"
#include "pd.h"
#include "timer.h"
#include "scp_regs.h"

void cpu_fetch(unsigned d, bool en)
{
  const struct pd_cpu *c = pd_cfg[d].cpu;
  uint32_t v = mmio_read32(c->fetch_reg);
  v = en ? (v | c->fetch_mask) : (v & ~c->fetch_mask);
  mmio_write32(c->fetch_reg, v);
}

int cpu_load(unsigned d)
{
  const struct pd_cpu *c = pd_cfg[d].cpu;
  if (!(mmio_read32(c->open_reg) & c->open_mask)) return SOC4_CPU_E_CLOSED;
  /* Locals: a volatile store may alias *c, so c->image and c->words would
     otherwise be read again at every word. Tested at the bottom: one branch a
     word, as in the copy with a constant count this replaced. */
  volatile uint32_t *dst = (volatile uint32_t *)(uintptr_t)c->load;
  const uint32_t *src = c->image, *const end = c->image + c->words;
  if (src != end)
    do *dst++ = *src++; while (src != end);
  /* soc4: [7:0] read 0 and must be 0: Ibex fetches at {boot[31:8], 8'h80}
     (soc4_ctrl.sv; ibex_if_stage.sv:243, 250-251). */
  mmio_write32(c->boot_reg, c->boot_addr);
  return 0;
}

static uint32_t left(uint64_t until)
{
  const uint64_t now = timer_now();
  return (now >= until) ? 1u : (uint32_t)(until - now);
}

static int run(unsigned d, int rc)
{
  return (rc == PD_PENDING) ? pd_complete(d) : rc;
}

int soc4_cpu_cold(unsigned d, uint64_t until)
{
  int rc;
  cpu_fetch(d, false);                                          /* 1 */
  if ((rc = run(d, pd_request_static(d, PPU_MODE_ON, left(until)))))       return rc;  /* 2 */
  if ((rc = run(d, pd_request_static(d, PPU_MODE_WARM_RST, left(until))))) return rc;  /* 3 */
  if ((rc = cpu_load(d)))                                       return rc;  /* 4 */
  cpu_fetch(d, true);
  return run(d, pd_request_static(d, PPU_MODE_ON, left(until)));          /* 5, 6 */
}
