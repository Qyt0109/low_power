`timescale 1ns/1ps
// P-Channel package: interface-state encoding, decode helper, and the
// PACTIVE minimum-state rule.
//
// Implements the handshake state definitions from the AMBA Low Power Interface
// Specification (ARM IHI 0068C), Section 2.2, Table 2-2 "P-Channel handshake
// states".
//
// Unlike the Q-Channel, RESETn is PART of the P-Channel state decode: the
// device's power state is not observable on the wires (it is a PSTATE *value*
// the device has captured), so the spec gives reset its own interface state.
//
//   RESETn  PREQ  PACCEPT  PDENY  State        Meaning
//   ------  ----  -------  -----  -----------  -----------------------------------
//     0      x       0       0    P_RESET      Device is in reset
//     1      0       0       0    P_STABLE     Device state is stable
//     1      1       0       0    P_REQUEST    Transition to PSTATE requested
//     1      1       1       0    P_ACCEPT     Device accepted; controller drops PREQ
//     1      0       1       0    P_COMPLETE   PREQ dropped; device must drop PACCEPT
//     1      1       0       1    P_DENIED     Device denied; controller drops PREQ
//                                              and restores PSTATE to current state
//     1      0       0       1    P_CONTINUE   PREQ dropped; device must drop PDENY
//     x      x       1       1    (illegal)    Unused combination
//
// Note the asymmetry with the Q-Channel: each side's FSM only ever occupies
// FOUR of these seven states. P_COMPLETE and P_CONTINUE exist because of the
// round trip -- they are the window between the controller dropping PREQ and
// the device observing that through its synchronizer. They are interface
// states the monitor decodes, not states either FSM decides in. The two FSMs
// therefore get their own enums below rather than reusing pch_state_e, so a
// reader is never misled into thinking controller state == interface state.

package pchannel_pkg;

  // ---------------------------------------------------------------------------
  // Interface state (Table 2-2) -- what the monitor and testbenches decode from
  // the wires. Not used as an FSM state type by either side.
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    P_RESET,
    P_STABLE,
    P_REQUEST,
    P_ACCEPT,
    P_COMPLETE,
    P_DENIED,
    P_CONTINUE,
    P_ILLEGAL
  } pch_state_e;

  // Controller-side FSM states. C_COMPLETE/C_CONTINUE are the controller
  // waiting for the device to drop its acknowledge.
  typedef enum logic [1:0] {
    C_STABLE,
    C_REQUEST,
    C_COMPLETE,
    C_CONTINUE
  } pch_ctrl_state_e;

  // Device-side FSM states. The device is in D_ACCEPT/D_DENIED while the
  // interface passes through P_COMPLETE/P_CONTINUE.
  typedef enum logic [1:0] {
    D_STABLE,
    D_REQUEST,
    D_ACCEPT,
    D_DENIED
  } pch_dev_state_e;

  // Widest PACTIVE this package's helper function supports. Callers with
  // narrower PACTIVE zero-extend; the loop below simply never sees the upper
  // bits set.
  localparam int unsigned PCH_PACTIVE_MAX = 32;

  // ---------------------------------------------------------------------------
  // Decode the interface state from RESETn and the three handshake signals.
  // ---------------------------------------------------------------------------
  function automatic pch_state_e pch_decode(input logic resetn,
                                            input logic preq,
                                            input logic paccept,
                                            input logic pdeny);
    // Table 2-2 last row: {x, x, 1, 1} is the unused combination, and it is
    // illegal irrespective of RESETn -- so this test comes before the reset
    // test, not after it.
    if (paccept === 1'b1 && pdeny === 1'b1) return P_ILLEGAL;
    // RESETn LOW with PACCEPT/PDENY LOW is P_RESET; PREQ is a don't-care.
    if (resetn === 1'b0) return P_RESET;
    case ({preq, paccept, pdeny})
      3'b000:  return P_STABLE;
      3'b100:  return P_REQUEST;
      3'b110:  return P_ACCEPT;
      3'b010:  return P_COMPLETE;
      3'b101:  return P_DENIED;
      3'b001:  return P_CONTINUE;
      default: return P_ILLEGAL;  // unreachable: {*,1,1} filtered above
    endcase
  endfunction

  // Human-readable name, for logging.
  function automatic string pch_name(input pch_state_e s);
    case (s)
      P_RESET:    return "P_RESET";
      P_STABLE:   return "P_STABLE";
      P_REQUEST:  return "P_REQUEST";
      P_ACCEPT:   return "P_ACCEPT";
      P_COMPLETE: return "P_COMPLETE";
      P_DENIED:   return "P_DENIED";
      P_CONTINUE: return "P_CONTINUE";
      default:    return "P_ILLEGAL";
    endcase
  endfunction

  // ---------------------------------------------------------------------------
  // Section 2.2.3 PACTIVE rule: "The most significant PACTIVE bit set HIGH then
  // indicates the minimum power state required by the device to process
  // operations." Returns that bit index, or 0 when no bit is set -- with no
  // bits HIGH the device is hinting it could accept the lowest state, which is
  // also the implicit meaning of an omitted PACTIVE[0] (Section 4.2.2).
  //
  // This encodes the SPEC'S TYPICAL arrangement (one PACTIVE bit per power
  // state, LSB = lowest state). Section 2.2.3 explicitly says the arrangement
  // is not restricted, so a device using a different PACTIVE mapping needs its
  // own decode rather than this helper.
  // ---------------------------------------------------------------------------
  function automatic int unsigned pch_pactive_min_state(
      input logic [PCH_PACTIVE_MAX-1:0] pactive);
    pch_pactive_min_state = 0;
    for (int unsigned i = 0; i < PCH_PACTIVE_MAX; i++)
      if (pactive[i]) pch_pactive_min_state = i;
  endfunction

endpackage
