# P-Channel RTL — AMBA Low Power Interface

A synthesizable SystemVerilog implementation of the **P-Channel** power-state
handshake from the **AMBA Low Power Interface Specification (ARM IHI 0068C,
Section 2.2)**, with self-checking testbenches and an executable protocol
checker. The controller and device sit in **independent, asynchronous clock
domains** (§3.2), every interface output is a **registered flip-flop**, and every
cross-domain input passes through a **multi-flop synchronizer** — except
`PSTATE`, which the spec deliberately exempts and which is captured with a
resynchronized `PREQ` strobe instead.

The RTL is split in two:

* **Generic protocol layer** — `pchannel_pkg`, `cdc_sync`,
  `pchannel_device`, `pchannel_controller`, `pchannel_monitor`. Parameterizable
  `PSTATE` and `PACTIVE` widths, and **no interpretation of any power-state
  value**. Reusable as-is.
* **Example layer** — the spec's own ON / RETENTION / OFF device from §4.2.2
  (Figure 4-6 and Table 4-1), its transition/denial policy, a power-actuation
  sequencer, a retention-aware workload, and an integration top.

This is the companion to the Q-Channel implementation in
[`../qchannel/`](../qchannel/), and closes the gap that the research survey of
open-source RTL recorded — that no open RTL implementation of the P-Channel
exists (research notes removed 2026-10-06).

> Verified with **Icarus Verilog 12.0**. `make pch` → **35 checks, PASS**;
> `make pchneg` → **14 checks, PASS**; `make pchpd` → **50 checks, PASS**.
> All report **0 protocol violations**, and the negative test proves the
> checker fires on all eleven rules.

## Contents

- [1. Background — what the P-Channel is](#1-background--what-the-p-channel-is)
- [2. Why not just use a Q-Channel](#2-why-not-just-use-a-q-channel)
- [3. Architecture](#3-architecture)
- [4. Module reference](#4-module-reference)
- [5. The two FSMs in detail](#5-the-two-fsms-in-detail)
- [6. Handshake rules and how they are enforced](#6-handshake-rules-and-how-they-are-enforced)
- [7. Waveforms](#7-waveforms)
- [8. Clock-domain crossing, PSTATE capture, and tinit](#8-clock-domain-crossing-pstate-capture-and-tinit)
- [9. Verification](#9-verification)
- [10. Running](#10-running)
- [11. Integration guide](#11-integration-guide)
- [12. Scope and limitations](#12-scope-and-limitations)
- [13. References](#13-references)

---

## 1. Background — what the P-Channel is

A handshake between a **power controller** and a **device** that negotiates
transitions between **multiple named power states**. The controller proposes a
state on `PSTATE` and raises `PREQ`; the device either accepts (`PACCEPT`) or
denies (`PDENY`). A separate vector, `PACTIVE`, lets the device advertise what it
currently needs.

| Signal | Driver | Width | Meaning |
|---|---|---|---|
| `PSTATE`  | controller | M | the power state a transition is requested to |
| `PREQ`    | controller | 1 | active HIGH request |
| `PACCEPT` | device     | 1 | active HIGH acceptance |
| `PDENY`   | device     | 1 | active HIGH denial |
| `PACTIVE` | device     | N | per-requirement activity indication |

Polarities are chosen so every transition starts and ends all-LOW, which makes
default isolation (clamp-to-zero) safe.

**The state table includes `RESETn`** — this is the first real departure from the
Q-Channel, and it exists because a P-Channel device's state is *not* observable on
the wires:

| `RESETn` | `PREQ` | `PACCEPT` | `PDENY` | State | Description |
|:---:|:---:|:---:|:---:|---|---|
| 0 | x | 0 | 0 | **P_RESET** | Device is in reset |
| 1 | 0 | 0 | 0 | **P_STABLE** | Device state is stable |
| 1 | 1 | 0 | 0 | **P_REQUEST** | Transition to `PSTATE` requested |
| 1 | 1 | 1 | 0 | **P_ACCEPT** | Accepted; controller must drop `PREQ` |
| 1 | 0 | 1 | 0 | **P_COMPLETE** | `PREQ` dropped; device must drop `PACCEPT` |
| 1 | 1 | 0 | 1 | **P_DENIED** | Denied; controller drops `PREQ` and restores `PSTATE` |
| 1 | 0 | 0 | 1 | **P_CONTINUE** | `PREQ` dropped; device must drop `PDENY` |
| x | x | 1 | 1 | *(illegal)* | Unused combination |

* **Accepted:** `P_STABLE → P_REQUEST → P_ACCEPT → P_COMPLETE → P_STABLE` (Figure 2-10).
* **Denied:** `P_STABLE → P_REQUEST → P_DENIED → P_CONTINUE → P_STABLE` (Figure 2-11).

Transitions can go **directly between any two supported states** without passing
through a common operational state (Figure 2-15) — the property that makes this
worth having.

---

## 2. Why not just use a Q-Channel

A Q-Channel offers exactly **one** quiescent state. It can express "running" and
"stopped", and nothing else. It therefore cannot distinguish *stopped but
remembering* from *stopped and forgotten* — which is precisely the distinction a
power architecture is built on.

The example layer here makes that concrete and testable:

| State | Power | Workload | Consequence |
|---|---|---|---|
| `ON` | full | running | — |
| `RETENTION` | retention rails only | frozen | **state preserved** |
| `OFF` | removed | reset | **state lost** |

Test **P3** freezes a work burst mid-flight, holds it through a retention window,
and proves the counter resumes rather than restarts. Test **P4** drops an
identical burst to OFF and proves the state is gone. That pair is the entire
argument for the P-Channel in two tests.

The cost is complexity: `PSTATE` is a multi-bit value with its own signalling
rule, the interface state depends on reset, and the device has to be told what
state it is in at reset exit — which is what `tinit` (§8) is for.

---

## 3. Architecture

```
      controller clock domain                        device clock domain
 ┌───────────────────────────────────┐   ┌────────────────────────────────────┐
 │        pchannel_controller         │   │          pchannel_device           │
 │                                    │   │                                    │
 │ req_state ─►┌─────┐  PSTATE (reg)  │   │            ┌──────────┐            │
 │ req_valid   │     ├────────────────┼───┼───────────►│ capture  │            │
 │ enb_pactive │ FSM │  PREQ   (reg)  │   │  ┌──────┐  │  strobe  │            │
 │             │     ├────────────────┼───┼─►│ 2-FF ├─►│          │            │
 │          ┌─►└─────┘                │   │  │ sync │  └────┬─────┘            │
 │          │                         │   │  └──────┘       ▼                  │
 │     ┌────┴─────┐   PACCEPT         │◄──┼──────────────┌─────┐◄ dev_deny     │
 │     │  2-FF    │◄─ PDENY ──────────┼◄──┼──────────────┤ FSM │─► dev_req_*   │
 │     │  sync    │◄─ PACTIVE[N-1:0] ─┼◄──┼──────────────└─────┘◄ dev_pactive  │
 │     └──────────┘   (per-bit)       │   │   PACCEPT/PDENY/PACTIVE (reg)      │
 │  cur_state, pactive_floor_state    │   │   dev_cur_state, dev_init_done     │
 └───────────────────────────────────┘   └────────────────────────────────────┘
            ▲        ▲        ▲       ▲
      PSTATE│  PREQ  │PACCEPT │ PDENY │        (raw interface wires)
         ┌──┴────────┴────────┴───────┴──┐
         │       pchannel_monitor         │  oversampled, reports `violations`
         │  PR1–PR8 signalling rules      │
         │  PR9/PR10/PR11 reset rules     │
         └────────────────────────────────┘
```

Key structural properties:

* `PREQ` and `PSTATE` are register outputs of the controller; `PACCEPT`, `PDENY`
  and `PACTIVE` are register outputs of the device. §2.2.1 requires exactly this.
* Everything crossing is synchronized **except `PSTATE`** — see §8.
* `PACTIVE` bits are synchronized **independently**, per §2.2.1: "All bits of
  PACTIVE are independent of each other and might come from various asynchronous
  sources." They may resolve on different cycles, and the policy must tolerate it.
* Both FSMs reset into the all-LOW `P_STABLE` boundary.

### Example-layer integration (`pchannel_pd_top`)

```
  always-on domain (aon_clk)                  device domain (dclk)
 ┌──────────────────────────────┐   ┌────────────────────────────────────┐
 │ pm_req ─► u_actuator ─► u_ctrl ══ P-Channel ══► u_dev ─► u_policy      │
 │              │  ▲          ▲  │   │               │  (transition +     │
 │   floor_state│  └──────────┘  │   │               │   denial matrix)   │
 │              ▼                │   │               ▼                    │
 │ pwr_on / iso_en / wl_retain / wl_rst_n ──────► u_workload              │
 └──────────────────────────────┘   └────────────────────────────────────┘
```

Two arrangement decisions worth understanding:

* **The wrapper is in the parent domain.** `pchannel_device`, the policy and the
  P-Channel logic sit in a domain that stays alive in all three states; only the
  workload is in the managed child domain. This is §4.2.1's *parent-child*
  example (Figure 4-5): "All P-Channel interface logic and control logic is
  located within Power Domain 0." The alternative (Figure 4-4) cannot answer a
  request from OFF at all — "Since some logic functionality is required at
  minimum to respond to the P-Channel requests, this arrangement cannot support
  RAM-only power domains."
* **The actuator, not the controller, owns the PACTIVE-led trigger.** The
  generic controller has a built-in PACTIVE-led policy, but `pchannel_pd_top`
  ties it off and consumes the exported floor in `pchannel_pwr_actuator`
  instead. A floor-led move is always *upward*, and upward moves are exactly the
  ones needing pre-transition actions — powering the domain, releasing isolation
  and reset — **before** the request is issued. Letting the controller self-start
  would send a request to a device whose power has not been restored. Whoever
  owns the actuation must own the trigger. In a system with no actuation to
  sequence, driving `enb_pactive_led_transition` on the controller directly is
  simpler and correct.

---

## 4. Module reference

> Port names carry **no `_i`/`_o` suffixes**, matching the Q-Channel RTL.

### Generic protocol layer

#### `pchannel_pkg` — [`pchannel_pkg.sv`](pchannel_pkg.sv)
`pch_state_e` (the seven Table 2-2 interface states plus `P_ILLEGAL`),
`pch_decode(resetn, preq, paccept, pdeny)`, `pch_name()`, and
`pch_pactive_min_state()` implementing the §2.2.3 minimum-state rule.

Also defines **separate FSM state enums** — `pch_ctrl_state_e` and
`pch_dev_state_e`. Each side only ever occupies four of the seven interface
states; `P_COMPLETE` and `P_CONTINUE` are the round-trip window between the
controller dropping `PREQ` and the device seeing it through its synchronizer.
They are decoded by the monitor, not decided in by either FSM, so conflating
"controller state" with "interface state" would mislead.

#### `cdc_sync` — [`cdc_sync.sv`](../common/cdc_sync.sv)
`WIDTH`-wide vector of independent per-bit synchronizer chains.

| Parameter | Default | Meaning |
|---|---|---|
| `WIDTH` | `1` | number of independent signals |
| `STAGES` | `2` | flops per chain; `0` = combinational passthrough for same-domain use |
| `RESET_VAL` | `1'b0` | reset level |

**Never pass `PSTATE` through this.** It is the one signal §3.2 exempts from
resynchronization, because independent per-bit synchronizers give no coherency
guarantee across a multi-bit value.

#### `pchannel_device` — [`pchannel_device.sv`](pchannel_device.sv)

| Parameter | Default | Meaning |
|---|---|---|
| `PSTATE_W` | `2` | M |
| `PACTIVE_W` | `3` | N |
| `SYNC_STAGES` | `2` | synchronizer depth for `PREQ` |
| `TINIT` | `4` | **published** tinit, in device clocks (§8) |
| `PACTIVE_RST` | `'0` | reset value for `PACTIVE` (§2.2.2 permits LOW or HIGH) |

| Port | Dir | Description |
|---|---|---|
| `clk`, `rst_n` | in | device clock, async-assert reset |
| `pstate` | in | requested state — **async, not synchronized** |
| `preq` | in | request (async) |
| `paccept`, `pdeny`, `pactive` | out | registered device outputs |
| `dev_pactive` | in | activity/requirement contributions |
| `dev_req_state` | out | the captured `PSTATE` under evaluation |
| `dev_req_valid` | out | HIGH for the single cycle the device is deciding |
| `dev_deny` | in | the decision, sampled that same cycle |
| `dev_cur_state` | out | committed current power state |
| `dev_init_done` | out | tinit elapsed, `PSTATE` captured, denial live |

`dev_req_state → policy → dev_deny` is a combinational round trip out of and back
into the module, the same shape as `qchannel_device`'s `dev_quiescent_deny`.

There is an **elaboration-time check** that `TINIT >= SYNC_STAGES + 1`. A
too-small `tinit` promises the controller something the device cannot deliver,
and only bites on reset paths a directed test may never reach.

#### `pchannel_controller` — [`pchannel_controller.sv`](pchannel_controller.sv)

| Parameter | Default | Meaning |
|---|---|---|
| `PSTATE_W`, `PACTIVE_W`, `SYNC_STAGES` | `2`,`3`,`2` | as above |
| `PSTATE_LEAD_CYCLES` | `0` | *extra* `PSTATE` lead beyond the baseline 1 cycle (Figure 3-3) |
| `RESET_STATE` | `'0` | state presented on `PSTATE` from reset, captured by the device during tinit |
| `TINIT_WAIT` | `16` | first-request delay, **in controller clocks** |

| Port | Dir | Description |
|---|---|---|
| `pstate`, `preq` | out | registered controller outputs |
| `paccept`, `pdeny`, `pactive` | in | device outputs (async) |
| `req_state`, `req_valid` | in | explicit PM request |
| `enb_pactive_led_transition` | in | runtime gate for the §2.2.3 floor policy |
| `cur_state` | out | controller's view of the device state |
| `pactive_floor_state` | out | the synchronized §2.2.3 minimum state |
| `dev_stable` | out | interface in `P_STABLE` and controller idle |
| `ctrl_init_done` | out | `TINIT_WAIT` elapsed |
| `xfer_done`, `xfer_denied` | out | 1-cycle completion pulses |

Two policy behaviours worth knowing:

* **PACTIVE-led requests take priority** over explicit ones, and are retried
  while the floor stands. §2.2.3 warns that "Failure by the power controller to
  respond to a request for a higher state might lead to system deadlock."
* **Explicit requests are not retried after a denial** until `req_valid` is
  re-pulsed. Holding `req_valid` across a denial would otherwise re-issue the
  identical request forever. §2.2.2 frames denial as letting the controller "make
  another request, *possibly to a different state*, if there are changes in the
  system conditions" — not as an invitation to spin.

Requests *below* the PACTIVE floor are deliberately still permitted: the spec
lets the controller make any policy decision irrespective of `PACTIVE`, and makes
the **device** responsible for denying inappropriate ones.

#### `pchannel_monitor` — [`pchannel_monitor.sv`](pchannel_monitor.sv)
Passive checker for all seven signalling rules plus the illegal combination and
three reset rules. Ports mirror the Q-Channel monitor: an always-on `rst_n` (which
must **not** be gated by the domain resets it watches), observed `crst_n`/`drst_n`,
the wires, and a running `violations` count. Imports nothing, so it stays usable
as a `bind` target where the package is not in scope.

### Example layer

| File | Role |
|---|---|
| [`pchannel_state_policy.sv`](pchannel_state_policy.sv) | `pch_example_pkg` (ON/RETENTION/OFF encoding) + the Table 4-1 transition and denial matrix |
| [`pchannel_pwr_actuator.sv`](pchannel_pwr_actuator.sv) | pre/post-transition sequencer: power switch, isolation, retention, workload reset |
| [`pchannel_workload.sv`](pchannel_workload.sv) | retention-aware workload — frozen by `retain`, reset by `rst_n` |
| [`pchannel_pd_top.sv`](pchannel_pd_top.sv) | the integrated managed power domain |

The actuator enforces the invariant that makes the sequencing safe: **throughout
a handshake the applied actuation is always that of the higher-power of the two
states**. Going up, the target's resources are applied before `PREQ` (§2.2.2 T1);
going down, the source's are held until after `PACCEPT` falls (T5). On denial it
reverses any pre-transition actions, as T5 requires.

---

## 5. The two FSMs in detail

Both are Moore machines in a **single sequential `always_ff` block**, so every
interface output is a direct registered output — never combinational decode, per
§2.2.1.

### Device FSM (`pchannel_device`)

| State | Drives | Next-state condition (on synchronized `PREQ`) |
|---|---|---|
| `D_STABLE` | `PACCEPT`=0, `PDENY`=0 | `PREQ` HIGH → capture `PSTATE`, latch `req_in_init`, → `D_REQUEST` |
| `D_REQUEST` | unchanged | `dev_deny && !req_in_init` → `D_DENIED` (`PDENY` HIGH); else → `D_ACCEPT` (`PACCEPT` HIGH) |
| `D_ACCEPT` | `PACCEPT`=1 | `PREQ` LOW → drop `PACCEPT`, commit `cur_state`, end init, → `D_STABLE` |
| `D_DENIED` | `PDENY`=1 | `PREQ` LOW → drop `PDENY`, → `D_STABLE` |

`req_in_init` is latched at the moment `PREQ` is **sampled**, not evaluated when
the decision is taken a cycle later. §2.2.2 phrases the rule as "*On sampling*
PREQ HIGH at reset exit or during tinit", so a request observed inside the window
must be force-accepted even if tinit expires between observing it and answering
it. Testing `init_done` at decision time leaves a one-cycle hole through which a
legal in-tinit request gets wrongly denied — a bug this implementation had and
test **B3** caught.

### Controller FSM (`pchannel_controller`)

| State | Drives `PREQ` | Next-state condition |
|---|---|---|
| `C_STABLE` | 0 | request pending → drive `PSTATE`, wait out the lead, raise `PREQ` → `C_REQUEST` |
| `C_REQUEST` | 1 | `PACCEPT` → drop `PREQ`, → `C_COMPLETE`; `PDENY` → drop `PREQ`, **restore `PSTATE`**, → `C_CONTINUE` |
| `C_COMPLETE` | 0 | `PACCEPT` LOW → commit `cur_state`, pulse `xfer_done`, → `C_STABLE` |
| `C_CONTINUE` | 0 | `PDENY` LOW → pulse `xfer_denied`, → `C_STABLE` |

---

## 6. Handshake rules and how they are enforced

The seven §2.2.2 rules, enforced **structurally** (each FSM only changes an
output from a state where the rule permits) and **observationally** (the monitor
flags any violation on the wires).

| Rule | Constraint |
|---|---|
| PR1 | `PREQ` 0→1 only when `PACCEPT` LOW and `PDENY` LOW |
| PR2 | `PREQ` 1→0 only when (`PACCEPT` HIGH, `PDENY` LOW) or (`PACCEPT` LOW, `PDENY` HIGH) |
| **PR3** | **`PSTATE` changes only when (`PREQ`,`PACCEPT`,`PDENY` all LOW) or (`PREQ` HIGH, `PDENY` HIGH, `PACCEPT` LOW)** |
| PR4 | `PACCEPT` 0→1 only when `PREQ` HIGH and `PDENY` LOW |
| PR5 | `PACCEPT` 1→0 only when `PREQ` LOW and `PDENY` LOW |
| PR6 | `PDENY` 0→1 only when `PREQ` HIGH and `PACCEPT` LOW |
| PR7 | `PDENY` 1→0 only when `PREQ` LOW and `PACCEPT` LOW |
| PR8 | `{PACCEPT,PDENY} = {1,1}` never occurs (Table 2-2) |

**PR3 is the one to get right.** Its second legal case looks wrong at first
glance: `PSTATE` may change while `PREQ` is still HIGH, provided `PDENY` is HIGH
too. That is the `P_DENIED` state, and it exists precisely so the controller can
restore `PSTATE` to the device's current state on the same edge it drops `PREQ`
(Figure 2-11 T4). The rule is evaluated against the state being *left*, which is
why the simultaneous change is legal.

Three further checks cover reset:

| Rule | Constraint | Status |
|---|---|---|
| **PR9** | device reset asserted only in `P_STABLE` | literal §2.2.2 rule |
| **PR10** | controller reset asserted only in `P_STABLE` | **not** a literal spec rule — symmetric best practice, same rationale as the Q-Channel monitor's R9 |
| **PR11** | `PACCEPT`/`PDENY` LOW throughout device reset | literal §2.2.2 rule |

PR9 is checked against the monitor's own last-sampled state, not by re-reading
the wires: the device's registers snap LOW asynchronously the instant reset
asserts, so the pre-reset state has to come from the pipeline.

---

## 7. Waveforms

**Accepted transition (Figure 2-10):**
```
 state    | P_STABLE | P_REQUEST | P_ACCEPT | P_COMPLETE | P_STABLE
 PSTATE     STATE A  ╳═══════════ STATE B ═══════════════════════
 PREQ     __________/‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\_____________________
 PACCEPT  ______________________/‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\_____________
 PDENY    _____________________________________________________
          ctrl drives      device      ctrl drops    device drops
          PSTATE+PREQ      accepts     PREQ          PACCEPT
```

**Denied transition (Figure 2-11):**
```
 state    | P_STABLE | P_REQUEST | P_DENIED | P_CONTINUE | P_STABLE
 PSTATE     STATE A  ╳═══ STATE B ═══════╳═══════ STATE A ═══════
 PREQ     __________/‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\_____________________
 PACCEPT  _____________________________________________________
 PDENY    ______________________/‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\_____________
                                          ▲
                             PSTATE restored HERE, on the same
                             edge PREQ falls — legal because the
                             state being left is P_DENIED (PR3)
```

**Multiple transitions (Figure 2-15):** `A → B → C` with no return to a common
state in between — test **T3**.

---

## 8. Clock-domain crossing, `PSTATE` capture, and `tinit`

### Why `PSTATE` is not synchronized

§3.2: "Re-synchronize all signals, **with the exception of PSTATE**, at their
destination before use." A multi-bit value through independent per-bit
synchronizers has no coherency guarantee — bits can resolve on different cycles,
producing a `PSTATE` that was never driven. So instead (§3.2.1):

* The controller **registers** `PSTATE` and drives it at least **one controller
  cycle before** raising `PREQ`. (The spec permits changing both on the same edge;
  a lead is strictly safer and costs nothing. `PSTATE_LEAD_CYCLES` adds more, per
  Figure 3-3.)
* The device captures `PSTATE` using the **resynchronized `PREQ` as a strobe**, by
  which point it has been stable for the lead cycle plus `SYNC_STAGES` device
  cycles.
* Production flows should still add a **max-delay constraint** on `PSTATE` so it
  reaches the capture register before the synchronized `PREQ` edge.

### Why `tinit` exists

A Q-Channel device can reset into a known state because the state *is* the wires.
A P-Channel device cannot: its state is a `PSTATE` value it must sample, and at
reset deassertion there is no handshake to carry it — `PREQ` may legally be LOW.
So the device self-captures `PSTATE`, and publishes `tinit` as the contract:
*hold `PSTATE` stable for this many of my clock cycles after reset deassertion and
I guarantee I have captured it, for all possible reset states.*

Three obligations follow, and the third is why `tinit` is real RTL behaviour and
not just a datasheet number:

1. `PSTATE` must be stable across the whole window.
2. The controller must not start a new transition until it expires — unless it
   uses §2.2.2 behaviour 2 (`PREQ` HIGH *before* reset deassertion) or behaviour 3
   (`PREQ` HIGH during `tinit` with `PSTATE` unchanged).
3. **The device must accept any request made at reset exit or during `tinit`** —
   denial is suppressed in that window.

### Choosing its value

| Term | Typical | Notes |
|---|---|---|
| Reset-deassert synchronizer depth | 2–3 device clocks | |
| `PSTATE` capture register | 1 clock | plus any pipeline stages |
| **Clock availability after reset exit** | **0 to hundreds** | usually dominant, system-dependent |
| Internal init sequencing | device-specific | RAM init, register-file clear |
| Margin | — | |

The third row is what actually sets the number, and the spec says so: "The
defined period is typically dependent on any delay in availability of the clock
from reset exit" (§2.2.4). A domain that has just been powered up may have a
gated, ramping or late clock — and cycles that never happen do not elapse. §2.2.4
also requires a multi-clock device to state *which* clock `tinit` is measured in.

Test **P7** makes this visible: the domain is released from reset with `dclk`
**stopped**, and `dev_init_done` provably stays LOW for the whole window until the
clock arrives.

> **The `TINIT_WAIT` trap.** The device publishes `tinit` in **device** clocks,
> but the controller's wait counter runs on the **controller** clock. It must be
> sized for the worst-case device:controller frequency ratio —
> `ceil(TINIT × f_ctrl / f_dev_min)` plus margin. Copying the device's number
> straight into `TINIT_WAIT` is the classic way to get this wrong, and it fails
> only when the device clock is slow or late.

---

## 9. Verification

Three testbenches under [`../../tb/pchannel/`](../../tb/pchannel/), each binding
`pchannel_monitor` and failing if the violation count is non-zero.

A per-phase breakdown of which control-signal combination each test drives, for
all three testbenches, is in
[`../../tb/pchannel/TEST_MATRIX.md`](../../tb/pchannel/TEST_MATRIX.md).

### Reading the test phase in the waveform

Each testbench drives a `test_phase` signal carrying the name of the test
currently running, so a waveform can be read against the test tables below
without cross-referencing timestamps in the log.

VCD has no string type, so the name lives in a packed byte vector (`reg
[8*56-1:0]`) written via `$sformat`. To see it as text in GTKWave, add
`test_phase` to the trace list, then right-click it and choose **Data Format →
ASCII**. Without that it renders as a very wide hex number. A SystemVerilog
`string` would not work here — it is not dumped to VCD at all, and Icarus will
not even cast one into a packed vector.

`set_phase()` sets the signal and prints the log banner in one call, so the
waveform and the transcript cannot drift apart.

### Stimulus timing convention

Every DUT input is driven, and every DUT output sampled, on the **negedge** of
the relevant clock, so the sampling posedge lands in the middle of the data eye.
Driving on the posedge would put the input transition and the sampling edge at
the same simulation time, leaving the outcome dependent on event ordering inside
the simulator and making waveforms unreadable.

This matters more here than in most designs: `PSTATE` is the one P-Channel signal
the device does **not** synchronize (§3.2), so it goes straight into a
`PREQ`-strobed capture register. A `PSTATE` transition landing on the capture edge
is precisely the failure this convention keeps out of the testbench — and it is
the same hazard that `set_max_delay -datapath_only` addresses in silicon.

The deliberate exception is **P7**, which drives with raw delays while `dclk` is
stopped. There are no edges to align to, which is the point of the test.

### Core protocol — [`pchannel_tb.sv`](../../tb/pchannel/pchannel_tb.sv)

Part A is a real controller/device pair on unrelated clocks (10.0 ns / 13.7 ns).
Part B is a **second device instance driven by scripted stimulus**, which exists
because the three §2.2.2 initialization behaviours cannot all be produced by
`pchannel_controller` — behaviour 2 needs `PREQ` HIGH *before* reset deassertion,
and the controller resets it LOW by design (that *is* behaviour 1).

| Test | Scenario | Spec anchor |
|---|---|---|
| **T0** | Reset and bring-up; `PSTATE` captured at reset deassertion | §2.2.2 |
| **T1** | Accepted transition | Figure 2-10 |
| **T2** | Denied transition, incl. `PSTATE` restored to current state | Figure 2-11, PR3 |
| **T3** | `RET → OFF → ON` with no return to a common state | Figure 2-15 |
| **T4** | PACTIVE-led transition from the minimum-state floor | §2.2.3 |
| **T5** | Explicit request *below* the floor is still issued | §2.2.3 |
| **B1** | Init behaviour 1: `PREQ` LOW at reset exit; denial live after `tinit` | §2.2.2 |
| **B2** | Init behaviour 2: `PREQ` HIGH before reset exit — **accepted despite `dev_deny`** | §2.2.2 |
| **B3** | Init behaviour 3: `PREQ` HIGH during `tinit` | §2.2.2 |

**35 checks, 0 errors, 0 violations on both monitors — PASS.**

### Monitor negative test — [`pchannel_monitor_negtest.sv`](../../tb/pchannel/pchannel_monitor_negtest.sv)

No DUT. Drives legal sequences (monitor must stay silent), then one deliberate
violation of **each of PR1–PR11** (monitor must fire), then a legal sequence again
to prove it is not stuck. Without this, "zero violations" everywhere else would be
worthless — a checker that never fires reports zero on everything.

**14 checks, 0 errors — PASS**, with all eleven rules confirmed firing.

The Q-Channel monitor has no equivalent and would benefit from a port of this
pattern — see [that README's §8.1](../qchannel/README.md#81-known-gap--no-negative-test-for-this-monitor).

### Power-domain integration — [`pchannel_pd_tb.sv`](../../tb/pchannel/pchannel_pd_tb.sv)

Drives `pchannel_pd_top` (AON 4.3 ns, device 13.7 ns, monitor 1 ns).

| Test | Scenario |
|---|---|
| **P0** | Reset and bring-up into ON; `PSTATE` captured during `tinit` |
| **P1** | Work burst runs; `busy` asserted, `work_count` decrements |
| **P2** | Request RETENTION while busy → denied; `PSTATE` restored; pre-transition actions reversed; workload never interrupted |
| **P3** | **RETENTION preserves state**: burst frozen mid-flight; retention actuation checked (retain and isolation asserted, **domain still powered**); `work_count` unchanged across the window; thaw releases retention and isolation; burst resumes rather than restarts and runs to completion |
| **P4** | **OFF loses state**: identical burst dropped to OFF, workload reset, power removed |
| **P5** | Unsupported `OFF → RETENTION` denied and flagged (Table 4-1) |
| **P6** | PACTIVE-led wake from OFF, with pre-transition actions making the request answerable |
| **P7** | **Late device clock**: reset released with `dclk` stopped; `tinit` provably does not elapse; transition completes once the clock arrives, and is accepted with denial enabled |

**50 checks, 0 errors, 0 violations — PASS.**

A per-phase breakdown of the driving signal values, and of the two phases removed
as redundant, is in
[`../../tb/pchannel/TEST_MATRIX.md`](../../tb/pchannel/TEST_MATRIX.md).

---

## 10. Running

```sh
make -C src pch      # core protocol TB      (writes build/pchannel_tb.vcd)
make -C src pchneg   # monitor negative test
make -C src pchpd    # ON/RETENTION/OFF TB   (writes build/pchannel_pd_tb.vcd)
make -C src pchall   # all three
make -C src pchlint  # compile-only elaboration check
make -C src wave-pch # open the power-domain waveform (needs gtkwave)
make -C src all      # every testbench in the repo, P-Channel and Q-Channel
```

Requires Icarus Verilog (`iverilog`/`vvp`). Override with `make IVERILOG=... VVP=...`.
Build artifacts land in `build/` (git-ignored).

---

## 11. Integration guide

1. **Enumerate the device's power states first.** §2.2.4 requires documenting
   `PSTATE` encodings, `PACTIVE` bit assignments, which bits are tied LOW or
   omitted, every supported transition, which transitions can be denied, the
   `PSTATE` values valid at reset deassertion, and `tinit` with the clock it is
   measured in. [`pchannel_state_policy.sv`](pchannel_state_policy.sv) is what
   that looks like in RTL.
2. **Order the encoding by increasing power.** The §2.2.3 minimum-state rule and
   the controller's floor comparison are magnitude comparisons; an arbitrary
   encoding silently breaks them.
3. **Instantiate `pchannel_device`** in the device clock domain and drive
   `dev_deny` from your policy, using `dev_req_state`/`dev_req_valid`.
4. **Support at least one reset-exit state.** §3.2.2 strongly recommends a
   `PSTATE` initialization value that exits reset directly into a functional
   state; set the controller's `RESET_STATE` to it.
5. **Size `TINIT` and `TINIT_WAIT` separately** — §8. They are in different clock
   domains and are not the same number.
6. **Decide where the PACTIVE-led trigger lives.** If a transition needs power,
   isolation or reset sequenced first, the block that owns that sequencing must
   own the trigger; tie the controller's `enb_pactive_led_transition` off and
   consume `pactive_floor_state` there instead (§3).
7. **Put the P-Channel logic in a domain that survives the states it manages**
   (§4.2.1), unless the device genuinely can be woken out-of-band.
8. **Synthesis constraints:** mark `cdc_sync` flops `ASYNC_REG`; false-path
   the handshake crossings; **`set_max_delay -datapath_only` on `PSTATE`** so it
   beats the synchronized `PREQ` to the capture register; keep `PACTIVE` combining
   logic to an OR of registers (§3.2); clamp the interface LOW at power
   boundaries.

For a device with a **single** quiescent state, use the simpler **Q-Channel**
instead — [`../qchannel/`](../qchannel/).

---

## 12. Scope and limitations

* **`PACTIVE` arrangement is the spec's typical one.** `pch_pactive_min_state()`
  assumes one bit per state, LSB = lowest. §2.2.3 explicitly says the arrangement
  is not restricted, so a device using a different mapping needs its own decode.
* **Metastability is not simulated.** Icarus does not inject it; the testbenches
  validate functional correctness across unrelated clocks. Tolerance is the job of
  the synchronizer structure plus CDC tooling and formal.
* **No SVA.** The monitor is a portable procedural checker so it runs under plain
  Icarus; a production environment would add bound SVA and formal coverage.
* **Behavioural actuation.** `pchannel_pwr_actuator` models power switches,
  isolation and retention as plain signals with settle counters; a real flow
  drives library power-management cells and a UPF/CPF power intent.
* **The `unsupported` backstop is out-of-spec territory.** §2.2.1 requires the
  controller to present only supported `PSTATE` values, so an unsupported request
  is a controller bug with no defined response. The policy denies it and raises a
  flag, which is the least-destructive option — but note this denies from OFF even
  though Table 4-1 gives OFF no denial support.
* **Status-flag latency.** `cur_state` and `dev_stable` lag the wire-level state,
  inherent to synchronous controllers that must synchronize an acknowledge before
  acting; the testbenches wait on completion pulses rather than assuming a fixed
  latency.

---

## 13. References

* **AMBA Low Power Interface Specification, ARM IHI 0068C** — local copy at
  [`../../../references/standards/arm-amba-low-power-interface-spec.pdf`](../../../references/standards/arm-amba-low-power-interface-spec.pdf).
  §2.2 (P-Channel), Table 2-2 (states), §2.2.2 (handshake rules, reset and
  initialization), §2.2.3 (PACTIVE operation), §2.2.4 (power-state and transition
  support definition), §2.2.5 (signal subsets), §3.2 (implementation and PSTATE
  capture), §4.2 (application examples, incl. Table 4-1).
* **Power Control System Architecture (PCSA), ARM DEN0050** — local copy at
  [`../../../references/standards/arm-power-control-system-architecture-pcsa-den0050.pdf`](../../../references/standards/arm-power-control-system-architecture-pcsa-den0050.pdf).
* [Q-Channel implementation](../qchannel/) — the single-quiescent-state sibling.
* [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md) — the SoC power architecture these channels serve (§5: which protocol on which interface).
* Note 11 (Arm IP and SoC power architecture) and note 16 (open-source RTL implementations): research notes removed 2026-10-06.


## Mutation campaign — the P-Channel suites (wave six)

Twelve mutations against `pchannel_device`, `pchannel_controller`,
`pchannel_pwr_actuator` and `pchannel_monitor` itself.

| | Rule broken | Killed by |
|---|---|---|
| P1 | LPI 2.2.2 device must accept during `tinit` | `pch` |
| P2 | LPI 2.2.2 `PSTATE` captured at the `PREQ` edge | `pch` |
| P3 | LPI 2.2.2 accept commits the requested state | `pch` |
| P4 | LPI 2.2.2 `PACCEPT` drops only when `PREQ` drops | `pch` |
| P5 | LPI 2.2.2 `PDENY` drops only when `PREQ` drops | `pch` |
| P6 | LPI 2.2.2 a denial retains the current state | `pch` |
| P7 | `dev_stable` means settled *and* unarmed | *not a spec rule — see below* |
| P8 | the controller honours its `tinit` | `pch` (**B0, new**) |
| P9 | actuator requests only while armed | *redundant guard* |
| P10 | monitor `PR3`: `PSTATE` stability | `pchneg` |
| P11 | monitor `PR4`: `PACCEPT` rises only in `P_REQUEST` | `pchneg` |
| P12 | monitor `PR8`: `PACCEPT=1,PDENY=1` illegal | `pchneg` |

### Checking the checker

P10–P12 break `pchannel_monitor`'s own rules, and all three were caught by
`pchneg`. That was worth confirming rather than assuming: a negative test scored
on a plain pass marker could in principle report success while detecting nothing,
and this one does not — its checks assert that specific violations *were* seen.

### P8 — a duration nobody measured

B1 covers the **device** side of `tinit`: `PSTATE` is captured and denial is
suppressed, per *"The device must accept any request made at reset exit or during
tinit"*. Nothing covered the **controller** side — how long it actually waits
before its first request — so collapsing `TINIT_WAIT` from 16 cycles to 1 passed
the entire suite.

**B0** counts controller clocks from reset release to the first `PREQ` rise and
requires at least `TINIT_WAIT`. This is the same shape as `RST_HWSTAT_DLY` in the
PPU (wave two, W7): a delay that every functional check tolerates because nothing
downstream depends on its length, so only a direct measurement pins it down.

### P7 and P9 — neither is a spec rule

`dev_stable` is a controller status output, not an LPI signal. Its only consumer
is a settle predicate in `pchannel_tb`, and weakening it does not break the suite
because the checks that follow re-settle anyway.

`ctrl_req_valid`'s extra `!ctrl_xfer_done && !ctrl_xfer_denied` terms are
belt-and-braces: `astate` returns to `A_IDLE` on completion, so the request
deasserts on the same edge regardless. A one-cycle redundancy, not a behaviour.
