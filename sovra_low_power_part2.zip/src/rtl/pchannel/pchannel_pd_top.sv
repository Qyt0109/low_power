`timescale 1ns/1ps
// EXAMPLE LAYER -- P-Channel managed power domain, top-level integration.
//
// Wires the generic protocol blocks to the Section 4.2.2 ON/RETENTION/OFF
// example, an actuation sequencer, and a retention-aware workload:
//
//   pm_req ─► u_actuator ─► u_ctrl ══ P-Channel ══► u_dev ─► u_policy
//                  │            ▲                     │          ▲
//                  │            └── PACCEPT/PDENY/PACTIVE        │ busy
//                  ▼                                              │
//        pwr_on / iso_en / wl_retain / wl_rst_n ─► u_workload ────┘
//
// Domain arrangement follows Section 4.2.1's PARENT-CHILD example (Figure 4-5),
// where "All P-Channel interface logic and control logic is located within
// Power Domain 0". That matters and is not an arbitrary choice:
//
//   * u_dev, u_policy and the P-Channel wrapper logic sit in the PARENT domain,
//     clocked by dclk and reset by drst_n. They stay operable in every one of
//     the three states, including OFF.
//   * Only u_workload sits in the managed CHILD domain. It is what actually
//     loses state in OFF (wl_rst_n) and freezes in RETENTION (wl_retain).
//
// Putting the wrapper in the child domain instead -- the Section 4.2.1
// "simple" arrangement of Figure 4-4 -- would mean the device cannot answer a
// P-Channel request from OFF at all, so every wake would need out-of-band
// signalling and OFF -> RETENTION could never be negotiated. The spec spells
// this out: "Since some logic functionality is required at minimum to respond
// to the P-Channel requests, this arrangement cannot support RAM-only power
// domains."
//
// Clock domains: u_ctrl and u_actuator on aon_clk (always-on -- a power
// controller has to be the one thing guaranteed alive to sequence everything
// else); u_dev, u_policy and u_workload on dclk. The two are asynchronous, per
// Section 3.2.
//
// Like qchannel_pd_top, only real system-level ports are exposed here. Every
// internal handshake wire, actuation signal and status flag is a genuine
// internal of this module; a testbench observes them by hierarchical reference
// (e.g. u_top.preq, u_top.u_workload.work_count) rather than growing debug-only
// ports.

module pchannel_pd_top #(
  parameter int unsigned SYNC_STAGES = 2,
  parameter int unsigned CNT_W       = 8,
  // Device-published tinit, in DEVICE (dclk) cycles.
  parameter int unsigned TINIT       = 4,
  // Controller-side wait, in CONTROLLER (aon_clk) cycles. Must cover TINIT
  // device cycles at the worst-case dclk:aon_clk ratio -- see the note in
  // pchannel_controller.sv. Defaulted generously here because this example
  // deliberately runs dclk slower than aon_clk.
  parameter int unsigned TINIT_WAIT  = 32,
  parameter int unsigned PRE_SETTLE  = 8,
  parameter int unsigned POST_SETTLE = 4
) (
  // Always-on domain: P-Channel controller + actuation sequencer
  input  logic             aon_clk,
  input  logic             aon_rst_n,     // async, ACTIVE LOW

  // Device (parent) domain: P-Channel wrapper logic
  input  logic             dclk,
  input  logic             drst_n,        // async, ACTIVE LOW

  // Power-management policy
  input  logic [1:0]       pm_req_state,  // EX_OFF / EX_RET / EX_ON
  input  logic             pm_req_valid,  // rising edge launches a transition
  input  logic             enb_pactive_led_transition,
  // 1 = the device may deny a transition while the workload is busy (Table 4-1
  // denial support); 0 = accept regardless, letting the workload be frozen or
  // reset mid-burst. Gating the policy's `busy` input is all this takes.
  input  logic             policy_deny_enb,

  // Workload stimulus (device domain)
  input  logic             start,
  input  logic [CNT_W-1:0] work_len,
  input  logic             wake           // external wake -> PACTIVE[2]
);

  import pch_example_pkg::*;

  // ---- P-Channel interface wires (asynchronous between the two domains) ----
  logic [EX_PSTATE_W-1:0]  pstate;
  logic                    preq, paccept, pdeny;
  logic [EX_PACTIVE_W-1:0] pactive;

  // ---- Controller-side internals ----
  logic [EX_PSTATE_W-1:0] ctrl_req_state, ctrl_cur_state, pactive_floor_state;
  logic                   ctrl_req_valid, ctrl_init_done;
  logic                   ctrl_stable, xfer_done, xfer_denied;

  // ---- Device-side internals ----
  logic [EX_PSTATE_W-1:0] dev_req_state, dev_cur_state;
  logic                   dev_req_valid, dev_deny, dev_init_done, dev_unsupported;

  // ---- Actuation ----
  logic pwr_on, iso_en, wl_retain, wl_rst_n, act_busy, act_denied;

  // ---- Workload ----
  logic             busy, done;
  logic [CNT_W-1:0] work_count;

  // ---------------------------------------------------------------------------
  // PACTIVE composition (Section 2.2.3 typical arrangement: one bit per state,
  // LSB = lowest). Section 3.2 recommends the combining logic be limited to a
  // logical OR where possible, which is what bit 2 is.
  //
  //   [2] ON   - the device needs full function: work in flight, or an
  //              external wake event.
  //   [1] RET  - the device has state worth keeping: a burst is part-way
  //              through, so dropping below RETENTION would lose it. This is
  //              what stops the PACTIVE-led policy from allowing OFF while a
  //              partially-completed burst is being retained.
  //   [0] OFF  - omitted per Table 4-1 and tied LOW: it is the implicit
  //              minimum when no other bit is HIGH.
  // ---------------------------------------------------------------------------
  logic [EX_PACTIVE_W-1:0] dev_pactive;
  assign dev_pactive = {(busy | wake), (work_count != '0), 1'b0};

  // ---- P-Channel controller (aon_clk domain, always-on) ----
  pchannel_controller #(
    .PSTATE_W    (EX_PSTATE_W),
    .PACTIVE_W   (EX_PACTIVE_W),
    .SYNC_STAGES (SYNC_STAGES),
    .RESET_STATE (EX_ON),        // Section 3.2.2: reset directly into a functional state
    .TINIT_WAIT  (TINIT_WAIT)
  ) u_ctrl (
    .clk                        (aon_clk),
    .rst_n                      (aon_rst_n),
    .pstate                     (pstate),
    .preq                       (preq),
    .paccept                    (paccept),
    .pdeny                      (pdeny),
    .pactive                    (pactive),
    .req_state                  (ctrl_req_state),
    .req_valid                  (ctrl_req_valid),
    // Tied OFF deliberately. The controller's built-in PACTIVE-led policy would
    // raise PREQ as soon as the floor moves, but a floor-led move UP is exactly
    // the case needing pre-transition actions (power, isolation, reset) BEFORE
    // the request. The floor is therefore exported below and consumed by
    // u_actuator, which owns that sequencing. In a system with no actuation to
    // sequence, driving this HIGH instead is the simpler and correct choice.
    .enb_pactive_led_transition (1'b0),
    .cur_state                  (ctrl_cur_state),
    .pactive_floor_state        (pactive_floor_state),
    .dev_stable                 (ctrl_stable),
    .ctrl_init_done             (ctrl_init_done),
    .xfer_done                  (xfer_done),
    .xfer_denied                (xfer_denied)
  );

  // ---- Actuation sequencer (aon_clk domain, always-on) ----
  pchannel_pwr_actuator #(
    .PRE_SETTLE  (PRE_SETTLE),
    .POST_SETTLE (POST_SETTLE)
  ) u_actuator (
    .aon_clk          (aon_clk),
    .aon_rst_n        (aon_rst_n),
    .pm_req_state     (pm_req_state),
    .pm_req_valid     (pm_req_valid),
    .floor_state      (pactive_floor_state),
    .enb_pactive_led  (enb_pactive_led_transition),
    .ctrl_cur_state   (ctrl_cur_state),
    .ctrl_init_done   (ctrl_init_done),
    .ctrl_xfer_done   (xfer_done),
    .ctrl_xfer_denied (xfer_denied),
    .ctrl_req_state   (ctrl_req_state),
    .ctrl_req_valid   (ctrl_req_valid),
    .pwr_on           (pwr_on),
    .iso_en           (iso_en),
    .wl_retain        (wl_retain),
    .wl_rst_n         (wl_rst_n),
    .act_busy         (act_busy),
    .act_denied       (act_denied)
  );

  // ---- P-Channel device wrapper (dclk domain, parent power domain) ----
  pchannel_device #(
    .PSTATE_W    (EX_PSTATE_W),
    .PACTIVE_W   (EX_PACTIVE_W),
    .SYNC_STAGES (SYNC_STAGES),
    .TINIT       (TINIT)
  ) u_dev (
    .clk           (dclk),
    .rst_n         (drst_n),
    .pstate        (pstate),
    .preq          (preq),
    .paccept       (paccept),
    .pdeny         (pdeny),
    .pactive       (pactive),
    .dev_pactive   (dev_pactive),
    .dev_req_state (dev_req_state),
    .dev_req_valid (dev_req_valid),
    .dev_deny      (dev_deny),
    // No sequencing to finish before a state change: the actuator here reacts
    // to cur_state after the fact. See pchannel_device's dev_busy.
    .dev_busy      (1'b0),
    .dev_cur_state (dev_cur_state),
    .dev_init_done (dev_init_done)
  );

  // ---- Transition / denial policy (combinational, dclk domain) ----
  pchannel_state_policy u_policy (
    .cur_state   (dev_cur_state),
    .req_state   (dev_req_state),
    .req_valid   (dev_req_valid),
    .busy        (busy & policy_deny_enb),
    .deny        (dev_deny),
    .unsupported (dev_unsupported)
  );

  // ---- Workload (managed child domain) ----
  pchannel_workload #(.CNT_W(CNT_W)) u_workload (
    .clk        (dclk),
    .rst_n      (wl_rst_n),
    .retain     (wl_retain),
    .start      (start),
    .work_len   (work_len),
    .busy       (busy),
    .done       (done),
    .work_count (work_count)
  );

endmodule
