`timescale 1ns/1ps
// P-Channel device-side finite state machine (CDC-aware).
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section 2.2.
// This is the block a device wraps itself in to become P-Channel compliant. It
// receives the controller's transition request (PREQ + PSTATE), decides whether
// to accept or deny, and drives the acknowledge pair (PACCEPT, PDENY) plus the
// activity/requirement vector (PACTIVE).
//
// This module is deliberately GENERIC: it implements the protocol only and
// knows nothing about what any PSTATE value means. Which transitions are
// supported, and which may be denied, is a device-specific policy that arrives
// on dev_deny -- see pchannel_state_policy.sv for the spec's own ON/RETENTION/
// OFF worked example (Section 4.2.2, Table 4-1).
//
// Clock-domain crossing:
//   * PREQ arrives from the controller's asynchronous domain and is passed
//     through a multi-flop synchronizer before the FSM samples it.
//   * PSTATE is deliberately NOT synchronized. Section 3.2 exempts it: it is a
//     multi-bit value, and independent per-bit synchronizers give no coherency
//     guarantee. Instead it is captured using the resynchronized PREQ as a
//     strobe (Section 3.2.1). By the time preq_sync rises, PSTATE has been
//     stable at the pin for at least SYNC_STAGES device cycles, because the
//     controller drives PSTATE at least one controller cycle before raising
//     PREQ (see pchannel_controller.sv). Implementers should still place a
//     max-delay constraint on PSTATE so it reaches this capture register
//     before the synchronized PREQ edge -- Section 3.2.1.
//   * PACCEPT, PDENY and PACTIVE are driven from dedicated output flip-flops
//     (never combinational decode), per Section 2.2.1: "The PACCEPT and PDENY
//     signals from a device and the PREQ and PSTATE signals from a controller
//     must all be driven directly by registers."
//
// Device-internal contract:
//   * dev_pactive    - the raw activity/requirement contributions, registered
//                      out onto PACTIVE. Section 3.2 recommends the combining
//                      logic feeding this be limited to a logical OR.
//   * dev_req_state  - the captured PSTATE now under evaluation, valid while
//                      dev_req_valid is HIGH.
//   * dev_req_valid  - HIGH for the single cycle the device is deciding.
//   * dev_deny       - the decision, sampled in that same cycle. This is a
//                      combinational round trip out of and back into this
//                      module (dev_req_state -> policy -> dev_deny), the same
//                      shape as qchannel_device's dev_quiescent_deny.
//   * dev_cur_state  - the committed current power state.
//   * dev_init_done  - tinit has elapsed (or a transition has completed);
//                      PSTATE has been captured and denial is enabled.
//
// tinit -- why this exists and what sets its value (Section 2.2.2):
//   A Q-Channel device can reset into a known state because the state IS the
//   wires. A P-Channel device cannot: its state is a PSTATE value it must
//   sample, and at reset deassertion there is no handshake to carry it (PREQ
//   may legally be LOW). So the device self-captures PSTATE, and publishes
//   tinit as the contract "hold PSTATE stable for this many of my clock cycles
//   after reset deassertion and I guarantee I have captured it, for all
//   possible reset states."
//
//   Three obligations follow, and the last is why tinit is real RTL behaviour
//   rather than a datasheet number:
//     - PSTATE must be stable across the whole window.
//     - The controller must not start a new transition until it expires,
//       unless it uses one of the other two Section 2.2.2 init behaviours.
//     - "The device must accept any request made at reset exit or during
//       tinit" -- denial is SUPPRESSED in this window (force-accept below).
//
//   Choosing TINIT for a real instance: reset-deassert synchronizer depth, plus
//   the PSTATE capture register, plus -- usually dominant, and the reason the
//   spec makes this device-documented -- any delay in clock availability after
//   reset exit ("The defined period is typically dependent on any delay in
//   availability of the clock from reset exit", Section 2.2.4), plus internal
//   init sequencing, plus margin. A device with several clocks must also state
//   which clock tinit is measured in.
//
//   The parameter here is the PUBLISHED contract, not the structural minimum.
//   The elaboration check below enforces only the structural floor.
//
// IMPLEMENTATION DEFINED choices made here, which a real device would have to
// document per Section 2.2.4:
//   * A request arriving during tinit (Section 2.2.2 third controller
//     behaviour) IS treated as a second transition: PSTATE is re-captured and
//     committed normally. The spec leaves this open. It is benign either way
//     because that behaviour requires the controller to hold PSTATE unchanged.
//   * On denial the device RETAINS its knowledge of the current state rather
//     than re-sampling PSTATE when PREQ falls. Section 3.2.1 permits either.

module pchannel_device #(
  parameter int unsigned PSTATE_W    = 2,   // M: width of PSTATE
  parameter int unsigned PACTIVE_W   = 3,   // N: width of PACTIVE
  parameter int unsigned SYNC_STAGES = 2,   // synchronizer depth for PREQ
  parameter int unsigned TINIT       = 4,   // published tinit, in device clocks
  // Section 2.2.2: "PACTIVE bits can be reset LOW or HIGH. If the device must
  // enter a specific power state to process start-up operations then the
  // relevant PACTIVE bit can be reset HIGH. If no such requirement exists, ARM
  // recommends all PACTIVE bits are reset LOW."
  parameter logic [PACTIVE_W-1:0] PACTIVE_RST = '0
) (
  input  logic clk,      // device clock domain
  input  logic rst_n,    // device domain reset, async assert

  // P-Channel, device side
  input  logic [PSTATE_W-1:0]  pstate,   // requested state (async, NOT synchronized)
  input  logic                 preq,     // request, active HIGH (async)
  output logic                 paccept,  // accept,  active HIGH (registered)
  output logic                 pdeny,    // deny,    active HIGH (registered)
  output logic [PACTIVE_W-1:0] pactive,  // activity/requirements (registered)

  // Device-internal
  input  logic [PACTIVE_W-1:0] dev_pactive,    // activity contributions
  output logic [PSTATE_W-1:0]  dev_req_state,  // captured PSTATE under evaluation
  output logic                 dev_req_valid,  // 1 = deciding this cycle
  input  logic                 dev_deny,       // 1 = deny the pending request

  // 1 = cannot accept YET. Held in D_REQUEST, so dev_req_valid stays HIGH and
  // the device neither accepts nor denies until it drops.
  //
  // AMBA LPI (IHI 0068C) permits it, but by SILENCE rather than by a sentence.
  // An earlier version of this comment quoted the spec as saying the device
  // "responds with PACCEPT or PDENY when it has completed the transition or
  // determined it cannot". THAT WORDING IS NOT IN IHI 0068C -- it was a
  // paraphrase written inside quotation marks, and a spec cross-check found it.
  //
  // What the spec actually does is describe the handshake without bounding the
  // device's response: Figure 2-10 has the controller set PREQ at T2 and the
  // device drive PACCEPT at T3, with no statement about how many cycles may
  // separate them. Holding in D_REQUEST is therefore legal because nothing
  // forbids it, which is a weaker claim than the one that was here.
  //
  // The one place the spec IS explicit constrains the opposite case, and that
  // quote is verbatim: "The device must accept any request made at reset exit
  // or during tinit" (Section 2.2.2). Busy delays an acceptance; it must never
  // turn one into a denial.
  //
  // THIS PORT WAS BUILT ONCE BEFORE AND REVERTED, AND THE REVERT WAS WRONG.
  // The case then was the retention save, on the argument that the margin was
  // structural: D_ACCEPT exists and the controller must react to it, so the
  // save always led the supply removal by at least a cycle. That held only
  // while the save itself took one cycle. Once ppu_pcsm's save waited for a
  // switch acknowledge, it landed up to 31 cycles after the supply had gone
  // (pmu/README.md 10.2 finding 4). ppu_pcsm now holds the accept through its
  // whole retention sequence as well: a margin nothing enforces is a margin
  // the next change can remove.
  //
  // A power switch needs it anyway. Rail settling is ANALOGUE and unbounded --
  // no FSM shape provides it, and ppu_pcsm cannot honour its own documented
  // obligation to "hold PCSMPACCEPT LOW until its rails have actually settled"
  // without somewhere to say "not yet".
  //
  // TIE IT LOW unless the device has sequencing to finish before the state
  // change is safe.
  //
  // Denial WINS over busy: a device that has decided it cannot do something at
  // all should say so rather than stall. Section 2.2.2's tinit rule -- "The
  // device must accept any request made at reset exit or during tinit" -- is
  // not weakened either; busy delays that acceptance, it does not turn it into
  // a denial.
  input  logic                 dev_busy,
  output logic [PSTATE_W-1:0]  dev_cur_state,  // committed current power state
  output logic                 dev_init_done   // 1 = tinit elapsed, PSTATE captured
);

  import pchannel_pkg::*;

  // ---------------------------------------------------------------------------
  // Structural floor on TINIT. A request asserted at reset exit (Section 2.2.2
  // behaviour 2) needs SYNC_STAGES device cycles to appear on preq_sync, plus
  // one cycle for the FSM to act on it. Publishing a tinit below that would
  // promise the controller something this device cannot deliver -- and it would
  // only bite on reset paths a directed test may never reach, so it is checked
  // at elaboration rather than left to simulation.
  // ---------------------------------------------------------------------------
  initial begin
    if (TINIT < SYNC_STAGES + 1)
      $fatal(1, "pchannel_device: TINIT (%0d) is below the structural minimum SYNC_STAGES+1 (%0d)",
             TINIT, SYNC_STAGES + 1);
  end

  localparam int unsigned INIT_CNT_W = $clog2(TINIT + 1);

  // ---------------------------------------------------------------------------
  // Synchronize PREQ into the device clock domain. PREQ is LOW at the reset
  // boundary, so the chain resets LOW.
  // ---------------------------------------------------------------------------
  logic preq_sync;
  cdc_sync #(.WIDTH(1), .STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_preq_sync (.clk(clk), .rst_n(rst_n), .d(preq), .q(preq_sync));

  pch_dev_state_e          state;
  logic [PSTATE_W-1:0]     req_state;
  logic [PSTATE_W-1:0]     cur_state;
  logic [INIT_CNT_W-1:0]   init_cnt;
  logic                    init_done;
  // Latched at the moment PREQ was SAMPLED, not evaluated when the accept/deny
  // decision is taken a cycle later. Section 2.2.2 phrases the rule as "On
  // sampling PREQ HIGH at reset exit or during tinit" -- so a request observed
  // inside the window must be force-accepted even if tinit expires between
  // observing it and answering it. Testing init_done at decision time instead
  // leaves a one-cycle hole through which a legal in-tinit request gets denied.
  logic                    req_in_init;

  // ---------------------------------------------------------------------------
  // Single sequential Moore FSM: state and the acknowledge outputs move
  // together on the same clock edge, so PACCEPT/PDENY are always direct
  // registered outputs -- never combinational decode, per Section 2.2.1. Arms
  // that transition between two states sharing the same output value leave it
  // untouched (it already holds the correct level).
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state     <= D_STABLE;
      paccept   <= 1'b0;          // Section 2.2.2: both LOW at reset assertion
      pdeny     <= 1'b0;
      pactive   <= PACTIVE_RST;
      req_state   <= '0;
      cur_state   <= '0;
      init_cnt    <= '0;
      init_done   <= 1'b0;
      req_in_init <= 1'b0;
    end else begin
      // ---- tinit: capture PSTATE at reset deassertion ------------------------
      // Capture at the END of the window: that is the worst case the published
      // contract actually guarantees, so modelling it here keeps simulation
      // honest about how much stability the controller really owes us.
      if (!init_done) begin
        if (init_cnt == INIT_CNT_W'(TINIT - 1)) begin
          init_done <= 1'b1;
          cur_state <= pstate;
        end else begin
          init_cnt <= init_cnt + 1'b1;
        end
      end

      // ---- handshake FSM -----------------------------------------------------
      unique case (state)
        // Idle. Wait for the controller to raise PREQ, and use the
        // resynchronized edge as the strobe that captures PSTATE.
        D_STABLE: begin
          if (preq_sync) begin
            req_state   <= pstate;
            req_in_init <= !init_done;   // captured at SAMPLE time, see above
            state       <= D_REQUEST;
          end
        end
        // Decide. dev_deny is evaluated against the just-captured req_state.
        // For a request sampled during tinit denial is suppressed entirely
        // (Section 2.2.2: "The device must accept any request made at reset
        // exit or during tinit").
        D_REQUEST: begin
          if (dev_deny && !req_in_init) begin
            state <= D_DENIED;
            pdeny <= 1'b1;      // -> PDENY HIGH
          end else if (!dev_busy) begin
            state   <= D_ACCEPT;
            paccept <= 1'b1;    // -> PACCEPT HIGH
          end
          // else: stay here. dev_req_valid remains HIGH, which is how the
          // caller knows a decision is still owed.
        end
        // Accepted. The interface passes through P_COMPLETE while we wait for
        // the controller to drop PREQ; then drop PACCEPT and commit the new
        // state. Completing a transition also ends the init period -- the
        // device "must be ready to accept another P-Channel request
        // immediately after completing the first transition" (Section 2.2.2).
        D_ACCEPT: begin
          if (!preq_sync) begin
            paccept   <= 1'b0;
            cur_state <= req_state;
            init_done <= 1'b1;
            state     <= D_STABLE;
          end
        end
        // Denied. The interface passes through P_CONTINUE; the controller has
        // restored PSTATE to our current state. We retain cur_state rather
        // than re-sampling PSTATE (Section 3.2.1 permits either).
        D_DENIED: begin
          if (!preq_sync) begin
            pdeny <= 1'b0;
            state <= D_STABLE;
          end
        end
        default: state <= D_STABLE;
      endcase

      // PACTIVE is independent of the handshake (Section 2.2.1: "The handshake
      // signal states are independent of the PACTIVE bits") so it is updated
      // unconditionally every cycle, outside the state case.
      pactive <= dev_pactive;
    end
  end

  // Derived combinationally from state/registers rather than hand-tracked in
  // each case arm, so these invariants cannot get out of sync with the FSM.
  assign dev_req_valid = (state == D_REQUEST);
  assign dev_req_state = req_state;
  assign dev_cur_state = cur_state;
  assign dev_init_done = init_done;

endmodule
