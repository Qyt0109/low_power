`timescale 1ns/1ps
// P-Channel controller-side finite state machine (CDC-aware).
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section 2.2.
// This is the power-controller end of the interface. It owns PREQ and PSTATE,
// samples the device acknowledges (PACCEPT, PDENY) and the activity vector
// (PACTIVE), and sequences transitions while obeying the seven signalling rules
// of Section 2.2.2.
//
// Like pchannel_device this module is GENERIC: it never interprets a PSTATE
// value beyond comparing magnitudes for the PACTIVE minimum-state rule. Which
// states exist and which transitions are legal is the integrator's business.
//
// Clock-domain crossing:
//   * PACCEPT, PDENY and PACTIVE arrive from the device's asynchronous domain
//     and are each passed through a multi-flop synchronizer. PACTIVE bits are
//     synchronized independently and may resolve on different cycles -- Section
//     2.2.1 says the bits are independent and may come from various
//     asynchronous sources, so the policy below must tolerate that.
//   * PREQ and PSTATE are driven from dedicated output flip-flops (Section
//     2.2.1: PREQ and PSTATE "must all be driven directly by registers";
//     Section 3.2: "Register the PSTATE output to ensure it does not glitch").
//
// PSTATE timing:
//   PSTATE is always driven at least ONE controller cycle before PREQ rises.
//   The spec permits changing both on the same edge (Figure 2-10 at T2), but a
//   lead is strictly safer because the device does not synchronize PSTATE --
//   it captures it with the resynchronized PREQ as a strobe, so PSTATE gets
//   the lead cycle plus the device's SYNC_STAGES to settle. PSTATE_LEAD_CYCLES
//   adds FURTHER cycles on top of that baseline, implementing Figure 3-3's
//   "additional timing for PSTATE by asserting PSTATE before PREQ" for systems
//   that need more margin than a max-delay constraint alone can buy.
//
// Rule 3 and the denial path:
//   "PSTATE can only transition when either: PREQ, PACCEPT and PDENY are all
//   LOW; or PREQ and PDENY are both HIGH, and PACCEPT is LOW." The second case
//   is exactly P_DENIED, which is why restoring PSTATE to the current state on
//   the same edge that drops PREQ is legal -- the rule is evaluated against
//   the state being left, and that state is P_DENIED. This matches Figure 2-11
//   at T4: "the power controller samples PDENY HIGH and sets PREQ LOW and
//   returns PSTATE to the value for the current state".
//
// Controller policy and PACTIVE (Section 2.2.3):
//   "The P-Channel handshake is independent of PACTIVE and the controller can
//   make any policy decision irrespective of any activity on PACTIVE. However,
//   the device can deny any inappropriate request."
//
//   Two request sources are supported, and PACTIVE-led wins:
//     - PACTIVE-led (gated by enb_pactive_led_transition, a runtime input so
//       the policy can be switched on the fly): the most significant PACTIVE
//       bit set HIGH is the minimum state the device needs. If the current
//       state is BELOW that floor, the controller requests the floor. The spec
//       warns that "Failure by the power controller to respond to a request for
//       a higher state might lead to system deadlock", so this path takes
//       priority over any explicit request.
//     - Explicit req_state/req_valid from the power-management policy.
//
//   Requests BELOW the PACTIVE floor are deliberately still allowed on the
//   explicit path -- the spec lets the controller decide any policy and lets
//   the device deny what it cannot do. Suppressing them here would silently
//   remove a legal controller behaviour.
//
//   A request for the state the device is already in is treated as a no-op by
//   this controller (see want_explicit below). Section 2.2.4 lets a device
//   define actions for a request to its current state, but honouring it from a
//   LEVEL-sensitive req_valid would relaunch the same handshake forever.
//   A controller needing that behaviour should pulse req_valid and drop the
//   inequality term.

module pchannel_controller #(
  parameter int unsigned PSTATE_W           = 2,  // M: width of PSTATE
  parameter int unsigned PACTIVE_W          = 3,  // N: width of PACTIVE
  parameter int unsigned SYNC_STAGES        = 2,  // depth for PACCEPT/PDENY/PACTIVE
  parameter int unsigned PSTATE_LEAD_CYCLES = 0,  // extra PSTATE lead (Figure 3-3)
  // State presented on PSTATE from reset, which the device captures during its
  // tinit window (Section 2.2.2). Must be a state the device supports entering
  // directly from reset -- Section 3.2.2 strongly recommends at least one such
  // value exists, and Section 2.2.5 requires it for an unused interface.
  parameter logic [PSTATE_W-1:0] RESET_STATE = '0,
  // Section 2.2.2 behaviour 1: "The controller waits until tinit has expired
  // before requesting a transition to a new state."
  //
  // IMPORTANT: the device publishes tinit in DEVICE clock cycles, but this
  // counter runs on the CONTROLLER clock. It must therefore be sized for the
  // worst-case device:controller frequency ratio -- if the device clock is
  // slower, the same number of controller cycles is NOT the same amount of
  // time. Set this to ceil(TINIT * f_ctrl / f_dev_min) plus margin. Counting
  // the device's number here directly is the classic way to get this wrong.
  parameter int unsigned TINIT_WAIT = 16
) (
  input  logic clk,      // controller clock domain
  input  logic rst_n,    // controller domain reset, async assert

  // P-Channel, controller side
  output logic [PSTATE_W-1:0]  pstate,   // requested state (registered)
  output logic                 preq,     // request, active HIGH (registered)
  input  logic                 paccept,  // accept,  active HIGH (async)
  input  logic                 pdeny,    // deny,    active HIGH (async)
  input  logic [PACTIVE_W-1:0] pactive,  // activity/requirements (async)

  // System control
  input  logic [PSTATE_W-1:0] req_state,                   // explicitly requested state
  input  logic                req_valid,                   // 1 = request req_state
  input  logic                enb_pactive_led_transition,  // 1 = honour the PACTIVE floor
  output logic [PSTATE_W-1:0] cur_state,                   // controller's view of device state
  // The Section 2.2.3 minimum state, decoded from the SYNCHRONIZED PACTIVE and
  // exported in this controller's clock domain. Published so an integration
  // that must sequence power/isolation/reset before a state change can consume
  // the floor at the level that owns that sequencing, without instantiating a
  // second synchronizer on the same wires. See pchannel_pd_top.sv.
  output logic [PSTATE_W-1:0] pactive_floor_state,
  output logic                dev_stable,                  // 1 = interface in P_STABLE
  output logic                ctrl_init_done,              // 1 = TINIT_WAIT elapsed
  output logic                xfer_done,                   // 1-cycle pulse: transition accepted
  output logic                xfer_denied                  // 1-cycle pulse: transition denied
);

  import pchannel_pkg::*;

  initial begin
    if (PACTIVE_W > PCH_PACTIVE_MAX)
      $fatal(1, "pchannel_controller: PACTIVE_W (%0d) exceeds PCH_PACTIVE_MAX (%0d)",
             PACTIVE_W, PCH_PACTIVE_MAX);
  end

  localparam int unsigned LEAD_W = $clog2(PSTATE_LEAD_CYCLES + 2);
  localparam int unsigned INIT_W = $clog2(TINIT_WAIT + 1);

  // ---------------------------------------------------------------------------
  // Synchronize the device-driven signals into the controller clock domain.
  // All reset LOW (the P_RESET / P_STABLE boundary).
  // ---------------------------------------------------------------------------
  logic                 paccept_sync, pdeny_sync;
  logic [PACTIVE_W-1:0] pactive_sync;

  cdc_sync #(.WIDTH(1), .STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_acc_sync (.clk(clk), .rst_n(rst_n), .d(paccept), .q(paccept_sync)),
  u_den_sync (.clk(clk), .rst_n(rst_n), .d(pdeny  ), .q(pdeny_sync  ));

  cdc_sync #(.WIDTH(PACTIVE_W), .STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_act_sync (.clk(clk), .rst_n(rst_n), .d(pactive), .q(pactive_sync));

  // ---------------------------------------------------------------------------
  // Section 2.2.3 minimum-state decode.
  // ---------------------------------------------------------------------------
  logic [PCH_PACTIVE_MAX-1:0] pactive_ext;
  logic [31:0]                pactive_floor_w;
  logic [PSTATE_W-1:0]        pactive_floor;

  always_comb begin
    pactive_ext     = '0;
    pactive_ext[PACTIVE_W-1:0] = pactive_sync;
    pactive_floor_w = pch_pactive_min_state(pactive_ext);
  end
  assign pactive_floor       = pactive_floor_w[PSTATE_W-1:0];
  assign pactive_floor_state = pactive_floor;

  pch_ctrl_state_e     state;
  logic [LEAD_W-1:0]   lead_cnt;
  logic                armed;      // PSTATE driven, waiting out the lead before PREQ
  logic [INIT_W-1:0]   init_cnt;
  logic                init_done;

  // Retry suppression for the explicit path. Without this, holding req_valid
  // asserted across a denial makes the controller immediately re-issue the
  // identical request, which the device denies again -- a livelock, and against
  // the spirit of Section 2.2.2: the denial mechanism exists so "the controller
  // can make another request, POSSIBLY TO A DIFFERENT STATE, if there are
  // changes in the system conditions", not so it can spin on the same one.
  //
  // The PM policy must therefore drop req_valid (or change req_state) to retry.
  // Deliberately NOT applied to the PACTIVE-led path: there the device is
  // itself asking for the state, so persisting is correct, and giving up would
  // be the deadlock Section 2.2.3 warns about.
  logic [PSTATE_W-1:0] denied_state;
  logic                denied_pend;

  // Request arbitration. PACTIVE-led upward moves take priority: ignoring them
  // is the documented deadlock hazard.
  logic want_pactive, want_explicit, want_transition;
  logic [PSTATE_W-1:0] target_state;

  assign want_pactive    = enb_pactive_led_transition && (pactive_floor > cur_state);
  assign want_explicit   = req_valid && (req_state != cur_state)
                           && !(denied_pend && (req_state == denied_state));
  assign want_transition = init_done && (want_pactive || want_explicit);
  assign target_state    = want_pactive ? pactive_floor : req_state;

  // ---------------------------------------------------------------------------
  // Single sequential Moore FSM: PREQ and PSTATE are direct registered outputs.
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state       <= C_STABLE;
      preq        <= 1'b0;         // Section 2.2.2 behaviour 1: PREQ LOW at reset exit
      pstate      <= RESET_STATE;  // the value the device captures during tinit
      cur_state   <= RESET_STATE;
      lead_cnt    <= '0;
      armed       <= 1'b0;
      init_cnt     <= '0;
      init_done    <= 1'b0;
      xfer_done    <= 1'b0;
      xfer_denied  <= 1'b0;
      denied_state <= '0;
      denied_pend  <= 1'b0;
    end else begin
      xfer_done   <= 1'b0;   // default: these are 1-cycle pulses
      xfer_denied <= 1'b0;

      // A fresh req_valid pulse re-arms the explicit path after a denial.
      if (!req_valid) denied_pend <= 1'b0;

      if (!init_done) begin
        if (init_cnt == INIT_W'(TINIT_WAIT - 1)) init_done <= 1'b1;
        else                                     init_cnt  <= init_cnt + 1'b1;
      end

      unique case (state)
        // Idle. Drive PSTATE, wait out the lead, then raise PREQ. PSTATE may
        // legally change here: rule 3's first case is PREQ/PACCEPT/PDENY all
        // LOW, which is exactly P_STABLE.
        C_STABLE: begin
          if (armed) begin
            if (lead_cnt == '0) begin
              preq  <= 1'b1;
              armed <= 1'b0;
              state <= C_REQUEST;
            end else begin
              lead_cnt <= lead_cnt - 1'b1;
            end
          end else if (want_transition) begin
            pstate   <= target_state;
            armed    <= 1'b1;
            lead_cnt <= LEAD_W'(PSTATE_LEAD_CYCLES);
          end
        end
        // Requested. Wait for the device to accept or deny. Only one of the two
        // can change on a single handshake transition (Section 2.2.1), so the
        // priority here is a tie-break that never fires in a legal handshake.
        C_REQUEST: begin
          if (paccept_sync) begin
            preq  <= 1'b0;        // -> P_COMPLETE
            state <= C_COMPLETE;
          end else if (pdeny_sync) begin
            preq         <= 1'b0;       // -> P_CONTINUE
            denied_state <= pstate;     // remember what was refused, before the restore
            denied_pend  <= 1'b1;
            pstate       <= cur_state;  // Figure 2-11 T4: restore PSTATE (legal: from P_DENIED)
            state        <= C_CONTINUE;
          end
        end
        // Accepted. Wait for the device to drop PACCEPT, then commit. PSTATE
        // still holds the requested value, so it is the new current state.
        C_COMPLETE: begin
          if (!paccept_sync) begin
            cur_state <= pstate;
            xfer_done <= 1'b1;
            state     <= C_STABLE;
          end
        end
        // Denied. Wait for the device to drop PDENY. cur_state is unchanged --
        // "the device remains in its pre-transition state and keeps all
        // operational abilities associated with that state" (Section 2.2.2).
        C_CONTINUE: begin
          if (!pdeny_sync) begin
            xfer_denied <= 1'b1;
            state       <= C_STABLE;
          end
        end
        default: state <= C_STABLE;
      endcase
    end
  end

  // Derived combinationally from state so the invariant cannot drift. Note this
  // is the CONTROLLER's view: it reports P_STABLE only once it has seen the
  // device's acknowledge fall through its own synchronizer, so it lags the
  // wire-level state. That lag is why the monitor checks reset assertion
  // against the wires rather than against this flag.
  assign dev_stable     = (state == C_STABLE) && !armed;
  assign ctrl_init_done = init_done;

endmodule
