`timescale 1ns/1ps
// EXAMPLE LAYER -- power-actuation sequencer (pre- and post-transition actions).
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section
// 2.2.2. The handshake itself only NEGOTIATES a state change; something has to
// actually move the power, isolation and retention controls, and the spec is
// specific about when:
//
//   T1  "the power controller must take any necessary PRE-transition actions
//       prior to requesting a new state. These actions are generally associated
//       with a transition to a higher-power state. This might include powering
//       up a domain or bringing RAM out of the retention state."
//
//   T5  "Once the controller samples PACCEPT LOW it can take any POST-transition
//       actions required. These actions are generally associated with
//       transitioning to a lower-power state. This might include removing power
//       from a power domain or placing a RAM into a retention state."
//
// The resulting invariant, which is what makes this safe: throughout the
// handshake the applied actuation is always that of the HIGHER-power of the
// two states involved. Going up, the target's resources are applied early
// (before PREQ); going down, the source's resources are held late (until after
// PACCEPT falls). At no point is the device asked to operate with resources it
// does not yet, or no longer, have.
//
// On denial, Section 2.2.2 requires the reverse: "In the case of a denial this
// will generally require reversing any pre-transition actions which were taken
// between T1 and T2." Handled by restoring the pre-request state below.
//
// Launch is RISING-EDGE triggered on pm_req_valid. A level-triggered launch
// would re-issue a denied request forever, since a denial by definition leaves
// the device in the state that made pm_req_state differ from it in the first
// place. Retry policy therefore belongs to the PM logic driving this block, not
// here.
//
// Sizing PRE_SETTLE: it must cover the slowest of {power-switch ramp,
// isolation release, workload reset release} AND, when the transition releases
// the managed domain from reset, the device's tinit. Under-sizing it produces
// a request the device cannot yet answer.

module pchannel_pwr_actuator #(
  parameter int unsigned PRE_SETTLE  = 8,  // aon_clk cycles for pre-transition actions
  parameter int unsigned POST_SETTLE = 4   // aon_clk cycles for post-transition actions
) (
  input  logic aon_clk,
  input  logic aon_rst_n,

  // Power-management policy request (rising edge on pm_req_valid launches)
  input  logic [pch_example_pkg::EX_PSTATE_W-1:0] pm_req_state,
  input  logic                                    pm_req_valid,

  // Section 2.2.3 PACTIVE-led path. The minimum state the device is asking for,
  // already synchronized into this clock domain by pchannel_controller.
  //
  // This is deliberately consumed HERE rather than by the controller's own
  // built-in PACTIVE-led policy, which pchannel_pd_top ties off. The controller
  // can raise PREQ the moment the floor moves, but a floor-led move UP is
  // exactly the case that needs pre-transition actions first -- powering the
  // domain, releasing isolation and reset. Letting the controller self-start
  // would issue a request to a device whose power has not been restored yet.
  // Whoever owns the actuation must own the trigger.
  input  logic [pch_example_pkg::EX_PSTATE_W-1:0] floor_state,
  input  logic                                    enb_pactive_led,

  // pchannel_controller interface
  input  logic [pch_example_pkg::EX_PSTATE_W-1:0] ctrl_cur_state,
  input  logic                                    ctrl_init_done,
  input  logic                                    ctrl_xfer_done,
  input  logic                                    ctrl_xfer_denied,
  output logic [pch_example_pkg::EX_PSTATE_W-1:0] ctrl_req_state,
  output logic                                    ctrl_req_valid,

  // Domain actuation
  output logic pwr_on,      // power switch enable
  output logic iso_en,      // isolation clamp enable
  output logic wl_retain,   // workload retention hold
  output logic wl_rst_n,    // workload reset, active LOW

  // Status
  output logic act_busy,    // 1 = a sequence is in flight
  output logic act_denied   // 1 = the last launched request was denied
);

  import pch_example_pkg::*;

  typedef enum logic [1:0] {
    A_IDLE,
    A_PRE,
    A_REQ,
    A_POST
  } act_state_e;

  localparam int unsigned SETTLE_MAX = (PRE_SETTLE > POST_SETTLE) ? PRE_SETTLE : POST_SETTLE;
  localparam int unsigned CNT_W      = $clog2(SETTLE_MAX + 1);

  act_state_e              astate;
  logic [EX_PSTATE_W-1:0]  applied_state;  // what the actuation outputs reflect
  logic [EX_PSTATE_W-1:0]  tgt, from;
  logic [CNT_W-1:0]        cnt;
  logic                    pm_req_q;

  wire pm_req_rise = pm_req_valid && !pm_req_q;

  // A floor-led launch is level-triggered, not edge-triggered: the device is
  // asserting a standing requirement, and Section 2.2.3 warns that failing to
  // respond to a request for a higher state "might lead to system deadlock".
  //
  // It cannot livelock against a denial in this example: floor-led moves only
  // ever go UP, and the Table 4-1 policy has no deniable upward transition
  // (OFF -> ON is the only one, and OFF has no denial support). A device that
  // denied a state it was simultaneously demanding via PACTIVE would be
  // contradicting itself, and would need a retry gap here.
  wire floor_led = enb_pactive_led && (floor_state > ctrl_cur_state);

  always_ff @(posedge aon_clk or negedge aon_rst_n) begin
    if (!aon_rst_n) begin
      astate        <= A_IDLE;
      // Boot with the domain fully powered: Section 3.2.2 "ARM strongly
      // recommends that the device supports at least one PSTATE initialization
      // value that facilitates exit from reset directly into a functional
      // state." That value is ON, and this is the actuation that backs it.
      applied_state <= EX_ON;
      tgt           <= EX_ON;
      from          <= EX_ON;
      cnt           <= '0;
      pm_req_q      <= 1'b0;
      act_denied    <= 1'b0;
    end else begin
      pm_req_q <= pm_req_valid;

      unique case (astate)
        A_IDLE: begin
          // The floor takes priority over the PM policy: it is the device
          // saying it cannot function in its current state, which the PM
          // policy's preference does not override.
          if (ctrl_init_done && floor_led) begin
            tgt           <= floor_state;
            from          <= ctrl_cur_state;
            act_denied    <= 1'b0;
            applied_state <= floor_state;   // floor-led is always UP -> pre-transition
            cnt           <= CNT_W'(PRE_SETTLE);
            astate        <= A_PRE;
          end else if (pm_req_rise && ctrl_init_done && (pm_req_state != ctrl_cur_state)) begin
            tgt        <= pm_req_state;
            from       <= ctrl_cur_state;
            act_denied <= 1'b0;
            if (pm_req_state > ctrl_cur_state) begin
              // Going UP: apply the target's resources before requesting (T1).
              applied_state <= pm_req_state;
              cnt           <= CNT_W'(PRE_SETTLE);
              astate        <= A_PRE;
            end else begin
              // Going DOWN: nothing to do until the device has agreed.
              astate <= A_REQ;
            end
          end
        end

        A_PRE: begin
          if (cnt == '0) astate <= A_REQ;
          else           cnt    <= cnt - 1'b1;
        end

        A_REQ: begin
          if (ctrl_xfer_done) begin
            if (tgt < from) begin
              // Going DOWN: remove resources only now (T5).
              applied_state <= tgt;
              cnt           <= CNT_W'(POST_SETTLE);
              astate        <= A_POST;
            end else begin
              astate <= A_IDLE;
            end
          end else if (ctrl_xfer_denied) begin
            applied_state <= from;   // reverse any pre-transition actions
            act_denied    <= 1'b1;
            astate        <= A_IDLE;
          end
        end

        A_POST: begin
          if (cnt == '0) astate <= A_IDLE;
          else           cnt    <= cnt - 1'b1;
        end

        default: astate <= A_IDLE;
      endcase
    end
  end

  assign ctrl_req_state = tgt;

  // Gated combinationally on the completion pulses, not just on astate. The
  // controller returns to C_STABLE on the SAME edge it pulses xfer_done/
  // xfer_denied, so a request that stayed asserted for that one extra cycle
  // would be re-armed by the controller before this FSM could withdraw it.
  assign ctrl_req_valid = (astate == A_REQ) && !ctrl_xfer_done && !ctrl_xfer_denied;
  assign act_busy       = (astate != A_IDLE);

  // Actuation decode. Purely a function of applied_state so the "higher-power of
  // the two" invariant above is enforced by WHEN applied_state moves, not by
  // per-signal sequencing scattered through the FSM.
  //
  // RETENTION keeps pwr_on asserted: the retention rails stay powered, which is
  // exactly what distinguishes it from OFF.
  always_comb begin
    unique case (applied_state)
      EX_ON:   begin pwr_on = 1'b1; iso_en = 1'b0; wl_retain = 1'b0; wl_rst_n = 1'b1; end
      EX_RET:  begin pwr_on = 1'b1; iso_en = 1'b1; wl_retain = 1'b1; wl_rst_n = 1'b1; end
      EX_OFF:  begin pwr_on = 1'b0; iso_en = 1'b1; wl_retain = 1'b0; wl_rst_n = 1'b0; end
      default: begin pwr_on = 1'b1; iso_en = 1'b0; wl_retain = 1'b0; wl_rst_n = 1'b1; end
    endcase
  end

endmodule
