`timescale 1ns/1ps
// EXAMPLE LAYER -- device power-state definition and transition/denial policy.
//
// pchannel_device and pchannel_controller are generic: they implement the
// protocol and never interpret a PSTATE value. Everything in THIS file is the
// device-specific half that Section 2.2.4 requires a real device to document:
// "To allow for correct controller design, device documentation must include a
// full enumeration of its power states and the allowed transitions between
// them."
//
// The state set here is the spec's own worked example, Section 4.2.2
// Figure 4-6 and Table 4-1:
//
//   State      PACTIVE bit  PACTIVE status  Supported transitions to  Denial support
//   ---------  -----------  --------------  ------------------------  --------------
//   ON             2            Driven      RETENTION or OFF               Yes
//   RETENTION      1            Driven      ON or OFF                      Yes
//   OFF            0            Omitted     ON                             No
//
// PACTIVE[0] (OFF) is omitted by the device because it is the implicit minimum
// state requirement when all other bits are LOW; Section 4.2.2 requires it be
// tied LOW at the controller if the input exists at all.
//
// Note that OFF -> RETENTION is NOT a supported transition. That is not an
// oversight: from OFF the domain has no operable logic to save anything into
// retention, so the device must pass through ON. Section 4.2.1 discusses this
// directly -- "transitions between power states without operable logic require
// intermediate transitions to and from the operable state".

package pch_example_pkg;

  localparam int unsigned EX_PSTATE_W  = 2;
  localparam int unsigned EX_PACTIVE_W = 3;

  // PSTATE encoding. Ordered by increasing power/functionality so that the
  // magnitude comparison in pchannel_controller's PACTIVE-led policy and the
  // pchannel_pkg minimum-state helper both mean what they look like they mean.
  localparam logic [EX_PSTATE_W-1:0] EX_OFF = 2'd0;
  localparam logic [EX_PSTATE_W-1:0] EX_RET = 2'd1;
  localparam logic [EX_PSTATE_W-1:0] EX_ON  = 2'd2;

  function automatic string ex_state_name(input logic [EX_PSTATE_W-1:0] s);
    case (s)
      EX_OFF:  return "OFF";
      EX_RET:  return "RETENTION";
      EX_ON:   return "ON";
      default: return "UNDEFINED";
    endcase
  endfunction

endpackage

// -----------------------------------------------------------------------------
// Combinational transition/denial policy. Sits alongside pchannel_device and
// answers the one question the generic FSM cannot: should this request be
// denied?
//
// The device asserts dev_req_valid for a single cycle with the freshly captured
// PSTATE on dev_req_state; this block answers on dev_deny in that same cycle.
// It is a combinational round trip out of and back into pchannel_device, the
// same shape as qchannel_device's dev_quiescent_deny.
// -----------------------------------------------------------------------------
module pchannel_state_policy (
  input  logic [pch_example_pkg::EX_PSTATE_W-1:0] cur_state,
  input  logic [pch_example_pkg::EX_PSTATE_W-1:0] req_state,
  input  logic                                    req_valid,
  input  logic                                    busy,        // work in flight
  output logic                                    deny,
  output logic                                    unsupported  // status/assertion hook
);

  import pch_example_pkg::*;

  logic supported, deniable;

  always_comb begin
    supported = 1'b0;
    deniable  = 1'b0;
    unique case (cur_state)
      EX_ON:  begin
        supported = (req_state == EX_RET) || (req_state == EX_OFF);
        deniable  = 1'b1;
      end
      EX_RET: begin
        supported = (req_state == EX_ON) || (req_state == EX_OFF);
        deniable  = 1'b1;
      end
      EX_OFF: begin
        supported = (req_state == EX_ON);
        deniable  = 1'b0;   // Table 4-1: no denial support from OFF
      end
      default: begin
        supported = 1'b0;
        deniable  = 1'b0;
      end
    endcase

    // Section 2.2.1: "A controller must only present supported PSTATE values to
    // a device." An unsupported request is therefore a CONTROLLER bug, not a
    // situation the protocol defines a response for. Two things happen here:
    //
    //  * `unsupported` is raised so a testbench or assertion can catch the
    //    controller doing it. In normal operation this must never fire.
    //  * The request is denied anyway, as the least-destructive response
    //    available -- denial leaves the device in its current state with all
    //    its operational abilities (Section 2.2.2), whereas accepting would
    //    commit the device to a state it cannot actually implement.
    //
    // Note this deliberately denies from OFF even though Table 4-1 says OFF has
    // no denial support. Both branches are already outside the spec at that
    // point; refusing an impossible transition is the safer of the two.
    unsupported = req_valid && !supported;
    deny        = req_valid && ((deniable && busy) || !supported);
  end

endmodule
