// P-Channel protocol checker.
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section
// 2.2.2 "Handshake rules", plus the illegal-combination row of Table 2-2 and
// the reset requirements of "Device reset and initialization". This is a
// passive monitor: it oversamples the interface wires and, on every
// transition, checks the transition was legal given the accompanying signal
// values. It is the executable form of the spec's rules and is meant to be
// bound alongside any controller/device pair.
//
// The seven signalling rules (Section 2.2.2). Note that unlike the Q-Channel,
// one of them governs a BUS (PSTATE) rather than a handshake wire:
//   PR1  PREQ    LOW->HIGH  only when PACCEPT LOW and PDENY LOW.
//   PR2  PREQ    HIGH->LOW  only when (PACCEPT HIGH and PDENY LOW)
//                                  or (PACCEPT LOW  and PDENY HIGH).
//   PR3  PSTATE  changes    only when (PREQ, PACCEPT and PDENY all LOW)
//                                  or (PREQ HIGH and PDENY HIGH and PACCEPT LOW).
//   PR4  PACCEPT LOW->HIGH  only when PREQ HIGH and PDENY LOW.
//   PR5  PACCEPT HIGH->LOW  only when PREQ LOW  and PDENY LOW.
//   PR6  PDENY   LOW->HIGH  only when PREQ HIGH and PACCEPT LOW.
//   PR7  PDENY   HIGH->LOW  only when PREQ LOW  and PACCEPT LOW.
//   PR8  (Table 2-2) PACCEPT HIGH with PDENY HIGH is an illegal combination.
//
// PR3 is the rule most easily got wrong in an implementation, because its
// second legal case looks surprising: PSTATE may change while PREQ is still
// HIGH, provided PDENY is HIGH too. That is the P_DENIED state, and it exists
// precisely so the controller can restore PSTATE to the device's current state
// on the same edge it drops PREQ (Figure 2-11 at T4).
//
// The companion-signal condition for each edge is evaluated on the "from"
// state -- the values held immediately before the transition -- which is what
// the rules describe.
//
// Reset-related checks:
// - PR9  "Device reset assertion by a controller must occur only when the
//        interface is in the P_STABLE state" (Section 2.2.2). Checked on the
//        falling edge of drst_n against the monitor's last-sampled wire state:
//        the device's registers snap LOW asynchronously the instant its reset
//        asserts, so the pre-reset state has to come from the monitor's own
//        pipeline, not from re-reading the wires.
// - PR10 Symmetric check for the controller's own reset. The spec text only
//        names device reset, but a controller reset asserted mid-handshake
//        drops PREQ without the device's agreement and desynchronizes the two
//        FSMs just the same. Not a literal spec rule; flagged for the same
//        isolation-boundary rationale as PR9.
// - PR11 "At reset assertion a device must set both PACCEPT and PDENY LOW"
//        (Section 2.2.2). Checked continuously while drst_n is asserted, but
//        reported at most once per reset episode so a non-compliant device
//        does not flood the log.
//
// `crst_n`/`drst_n` are purely observed here (edge-detected), independent of
// this monitor's own `rst_n`. `rst_n` must be the monitor's own always-on
// operating reset and must NOT be gated by the domain resets being watched --
// otherwise the very domain-reset event PR9/PR10/PR11 need to see would also
// wipe the monitor's pipeline in the same instant, and the violation would go
// unseen.

// This module deliberately imports nothing: it checks the raw wires against the
// signalling rules directly, so it stays usable as a bind target even where the
// package is not in scope.

module pchannel_monitor #(
  parameter int unsigned PSTATE_W = 2
) (
  input  logic                clk,      // oversampling clock
  input  logic                rst_n,    // monitor's own operating reset (always-on)
  input  logic                crst_n,   // controller domain reset, observed for PR10
  input  logic                drst_n,   // device domain reset, observed for PR9/PR11
  input  logic                preq,
  input  logic                paccept,
  input  logic                pdeny,
  input  logic [PSTATE_W-1:0] pstate,
  output int unsigned         violations
);

  // Two registered copies: p_* (from state) and c_* (to state). The checks below
  // run before the shift, so they compare the current p_* -> c_* transition and
  // evaluate each rule's companion condition on p_* (the "from" state).
  logic                p_req, p_acc, p_den;
  logic                c_req, c_acc, c_den;
  logic [PSTATE_W-1:0] p_state, c_state;
  logic                pr11_flagged;
  int unsigned         viol;

  assign violations = viol;

  // Sim-only monitor: blocking assignments in a clocked block, checks first, then
  // shift. `flag` increments the violation count and logs the offending edge.
  task automatic flag(input string rule, input string msg);
    viol = viol + 1;
    $display("[%0t] PCH-VIOLATION %s: %s  (from {PREQ=%0b PACCEPT=%0b PDENY=%0b PSTATE=%0h} -> {%0b %0b %0b %0h})",
             $time, rule, msg, p_req, p_acc, p_den, p_state, c_req, c_acc, c_den, c_state);
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      // At reset the interface is the all-LOW quiescent boundary.
      p_req = 1'b0; p_acc = 1'b0; p_den = 1'b0; p_state = '0;
      c_req = 1'b0; c_acc = 1'b0; c_den = 1'b0; c_state = '0;
      viol  = 0;
      pr11_flagged = 1'b0;
    end else begin
      // PR1: PREQ 0->1
      if (!p_req && c_req)
        if (!((!p_acc) && (!p_den))) flag("PR1", "PREQ rose outside P_STABLE");
      // PR2: PREQ 1->0
      if (p_req && !c_req)
        if (!((p_acc && !p_den) || (!p_acc && p_den)))
          flag("PR2", "PREQ fell outside P_ACCEPT/P_DENIED");
      // PR3: PSTATE changed
      if (p_state !== c_state)
        if (!(((!p_req) && (!p_acc) && (!p_den)) || (p_req && p_den && (!p_acc))))
          flag("PR3", "PSTATE changed outside P_STABLE/P_DENIED");
      // PR4: PACCEPT 0->1
      if (!p_acc && c_acc)
        if (!(p_req && (!p_den))) flag("PR4", "PACCEPT rose outside P_REQUEST");
      // PR5: PACCEPT 1->0
      if (p_acc && !c_acc)
        if (!((!p_req) && (!p_den))) flag("PR5", "PACCEPT fell outside P_COMPLETE");
      // PR6: PDENY 0->1
      if (!p_den && c_den)
        if (!(p_req && (!p_acc))) flag("PR6", "PDENY rose outside P_REQUEST");
      // PR7: PDENY 1->0
      if (p_den && !c_den)
        if (!((!p_req) && (!p_acc))) flag("PR7", "PDENY fell outside P_CONTINUE");
      // PR8: illegal combination present on the wires
      if (c_acc == 1'b1 && c_den == 1'b1)
        flag("PR8", "illegal state PACCEPT=1,PDENY=1");

      // PR11: PACCEPT/PDENY must be LOW throughout device reset assertion.
      if (!drst_n) begin
        if ((paccept || pdeny) && !pr11_flagged) begin
          pr11_flagged = 1'b1;
          viol = viol + 1;
          $display("[%0t] PCH-VIOLATION PR11: PACCEPT/PDENY not LOW during device reset (PACCEPT=%0b PDENY=%0b)",
                   $time, paccept, pdeny);
        end
      end else begin
        pr11_flagged = 1'b0;
      end

      // Shift the two-deep pipeline of sampled values (after the checks).
      p_req = c_req; p_acc = c_acc; p_den = c_den; p_state = c_state;
      c_req = preq;  c_acc = paccept; c_den = pdeny; c_state = pstate;
    end
  end

  // PR9/PR10: reset must only be asserted while the interface is P_STABLE, i.e.
  // {PREQ, PACCEPT, PDENY} == {0,0,0}. `rst_n` gates out both simulation
  // start-up (before the monitor's own pipeline holds a real sample) and any
  // brief X->0 initializer edge on crst_n/drst_n at time zero.
  always @(negedge drst_n) begin
    if (rst_n && !(c_req == 1'b0 && c_acc == 1'b0 && c_den == 1'b0)) begin
      viol = viol + 1;
      $display("[%0t] PCH-VIOLATION PR9: device reset asserted outside P_STABLE (state was {PREQ=%0b PACCEPT=%0b PDENY=%0b})",
               $time, c_req, c_acc, c_den);
    end
  end

  always @(negedge crst_n) begin
    if (rst_n && !(c_req == 1'b0 && c_acc == 1'b0 && c_den == 1'b0)) begin
      viol = viol + 1;
      $display("[%0t] PCH-VIOLATION PR10: controller reset asserted outside P_STABLE (state was {PREQ=%0b PACCEPT=%0b PDENY=%0b})",
               $time, c_req, c_acc, c_den);
    end
  end

endmodule
