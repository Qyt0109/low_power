`timescale 1ns/1ps
// EXAMPLE LAYER -- retention-aware workload behind a P-Channel device.
//
// Models the functional logic a P-Channel device wraps, and exists to make the
// difference between the three example power states observable:
//
//   ON         runs normally
//   RETENTION  frozen, state PRESERVED  (retain HIGH)
//   OFF        reset,  state LOST       (rst_n LOW)
//
// That distinction is the whole reason a device needs a P-Channel rather than a
// Q-Channel: a Q-Channel offers exactly one quiescent state, so it cannot
// express "stopped but remembering" and "stopped and forgotten" as different
// things to negotiate.
//
// Work model: on a rising `start` while idle, load `work_len` and count down
// one per clock, holding `busy` HIGH until the count drains, then pulse `done`.
// `busy` feeds the transition policy, so a busy workload can deny a request to
// leave ON.
//
// `done` is deliberately NOT held through retention. Retention preserves
// architectural state; a one-cycle status strobe is not that, and letting it
// survive would produce a spurious extra `done` pulse on the far side of a
// retention window.

module pchannel_workload #(
  parameter int unsigned CNT_W = 8
) (
  input  logic             clk,
  input  logic             rst_n,       // LOW when the domain is OFF -> state lost
  input  logic             retain,      // 1 = retention: hold all state
  input  logic             start,       // request to begin a work burst
  input  logic [CNT_W-1:0] work_len,    // number of clocks of work to perform
  output logic             busy,        // 1 = processing
  output logic             done,        // 1-cycle pulse when a burst completes
  output logic [CNT_W-1:0] work_count   // remaining work (observability)
);

  typedef enum logic {
    IDLE,
    WORK
  } fsm_t;
  fsm_t cstate;

  logic [CNT_W-1:0] cnt;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cstate <= IDLE;
      cnt    <= '0;
      busy   <= 1'b0;
      done   <= 1'b0;
    end else begin
      // Cleared unconditionally -- see the note above on why `done` is not
      // retained state.
      done <= 1'b0;

      if (!retain) begin
        case (cstate)
          IDLE: begin
            if (start) begin
              cnt    <= work_len;
              cstate <= WORK;
              busy   <= 1'b1;
            end
          end
          WORK: begin
            if (cnt == '0) begin
              cstate <= IDLE;
              busy   <= 1'b0;
              done   <= 1'b1;
            end else begin
              cnt <= cnt - 1'b1;
            end
          end
          default: cstate <= IDLE;
        endcase
      end
    end
  end

  assign work_count = cnt;

endmodule
