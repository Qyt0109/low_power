`timescale 1ns/1ps
// ppu_dom_top -- a PPU-controlled power domain, with the device outside it.
//
// Everything ppu_pd_top used to hold except the device: the PPU, the PCSM,
// the always-on Q-Channel device agent, the device clock gate and the
// device's reset synchronizers. The device attaches to the device-side ports
// below: ppu_device_ip in simulation, and in the SoC a CVA6 core, a DSP or an
// NPU. ppu_pd_top is this module plus ppu_device_ip and nothing else.
// ppu_axi_dom_top is this module behind the AXI4-Lite bridge, and soc4
// instantiates one per domain, four in all.
//
//   software ──► ppu_top ──┬── DEVQREQn ═══► qchannel_device ◄── dev_quiescent_busy
//                          │  ◄═ DEVQACCEPTn/QDENY/QACTIVE ═╝   ◄── dev_quiescent_deny
//                          │                                    ◄── dev_wake
//                          │                                    ──► dev_quiescent_ok
//                          ├── DEVCLKEN ──[sync]──► clock gate ───► dev_clk
//                          ├── DEVISOLATEn ───────────────────────► dev_isolaten
//                          ├── DEVPORESETn & DEVWARMRESETn ─[sync]► dev_nret_rst_n
//                          ├── DEVPORESETn & DEVRETRESETn  ─[sync]► dev_ret_rst_n
//                          ├── PPUHWSTAT ─────────────────────────► ppuhwstat
//                          └── PCSMPSTATE/PREQ ══► ppu_pcsm ══════► logic_on, logic_ret,
//                                ◄══ PCSMPACCEPT ═══┘                ret_n, ram_sleep, ram_sd
//
// -----------------------------------------------------------------------------
// THE DEVICE-SIDE PORTS
//
// The set is what ppu_pd_top wired between this logic and ppu_device_ip, plus
// the controls whose consumer is the power intent rather than RTL:
//
//   port                 dir  clock    what it is
//   dev_quiescent_busy   in   dclk     the device cannot become quiescent yet
//   dev_quiescent_deny   in   dclk     the device refuses a quiescence request
//   dev_wake             in   dclk     the device wants to run (DEVQACTIVE)
//   dev_quiescent_ok     out  dclk     the device is in Q_STOPPED
//   dev_clk              out  dclk     the device clock: dclk gated by DEVCLKEN
//   dev_clken_req        out  dclk     DEVCLKEN resynchronised into dclk: what
//                                      gates dev_clk, brought out as a request
//                                      for a SoC clock gate (ckrst_bridge)
//   dev_nret_rst_n       out  dclk     DEVPORESETn & DEVWARMRESETn: non-retained logic
//   dev_ret_rst_n        out  dclk     DEVPORESETn & DEVRETRESETn:  retained logic
//   dev_isolaten         out  aon_clk  DEVISOLATEn: LOW = the device's outputs clamped
//   ppuhwstat            out  aon_clk  PPUHWSTAT
//   logic_on, logic_ret  out  aon_clk  the two power switch controls
//   ret_n                out  aon_clk  retention save (falling) and restore (rising)
//   ram_sleep, ram_sd    out  aon_clk  SRAM macro retention and shutdown, per bank
//
// The first four are qchannel_device's device-internal contract, unchanged; see
// that module for what each means to the handshake. ppu_pd_top drives the three
// inputs from ppu_device_ip's busy -- busy, deny_enb && busy and wake | busy,
// the terms it has always used. A Q-Channel device adapter for a real device
// drives them from that device's own state.
//
// The last five are ppu_pcsm's technology-specific controls, passed straight
// through. ret_n, ram_sleep, ram_sd and logic_ret come out of registers there,
// and nothing here decodes them again. A memory power pin or a retention
// control driven from a combinational decode glitches between delta cycles in
// simulation and between unequal gate delays in silicon; ppu_pcsm.sv records
// the retained banks that cost. logic_on is ppu_pcsm's decode of its committed
// mode, as it always was.
//
// WHAT A DEVICE ATTACHED HERE NEEDS FROM THE POWER INTENT
//
// Isolation, switching and retention are UPF, not RTL (see below), so the RTL
// ports are only half of attaching a device. The power intent must also:
//
//   - put the device's logic in the switched domain, with u_clkctrl here;
//   - keep its RAM macros out of it, on the always-on rail, with ram_sleep and
//     ram_sd on their pins. MEM_RET is "Logic OFF, RAM RET" (Table 3-1), so an
//     array on the switched rail is corrupted in the one mode that keeps it;
//   - isolate the device's outputs into always-on logic with dev_isolaten,
//     clamped to their quiescent values;
//   - name the device's retained state in the retention strategy, with ret_n as
//     the save and restore signal and the retention rail as its supply.
//
// upf/ppu_pd_top.upf is that intent for ppu_device_ip inside ppu_pd_top, and
// upf/soc4_top.upf applies the same intent to each of soc4's four domains.
//
// -----------------------------------------------------------------------------
// SWITCH SETTLING: PCSM_*_SETTLE, NOT AN ACKNOWLEDGE
//
// ppu_pcsm is built here with PGOOD_EN = 0. No parameter changes that, and no
// switch acknowledge port exists. That was decided on 2026-09-29 and confirmed
// on 2026-09-30 (decision D11). A real switch's settling time goes into
// PCSM_RET_SETTLE and PCSM_LOGIC_SETTLE, per domain, from its datasheet. The
// PPU's device control delays (PPU_DCDR0/1) keep the isolation, clock and
// reset gaps. ppu_pcsm still has two acknowledge inputs, and they are tied to
// the controls below. At PGOOD_EN = 0 it does not wait on them.
//
// -----------------------------------------------------------------------------
// DOMAIN PARTITION, AND THE ONE THING THAT CHANGED FROM qchannel_pd_top
//
// Clock domains: ppu_top and ppu_pcsm on aon_clk (always-on -- PCSA 7.2.3, "the
// PPU must be placed in a power domain that is relative always-on to the power
// domain it is controlling", and a PCSM cannot be powered by the supply it
// gates). The Q-Channel device wrapper and the device run on dclk.
//
// Power domains: the device's logic and its clock gate are switched. The
// Q-Channel device wrapper is NOT -- and, more importantly, IT IS NOT HELD IN
// THE DOMAIN'S RESET EITHER.
//
// That second half is the substantive difference from qchannel_pd_top, where
// the wrapper shares drst_n with the workload. src/upf/README.md records the
// consequence there as an open item: while the domain is down the wrapper is
// powered but reset, so DEVQACTIVE is stuck LOW and a wake cannot revive the
// domain. It also records why the fix could not be applied in isolation --
// once QACTIVE can rise from a down domain, the interface can try to leave
// Q_STOPPED before the supply is back, which AMBA LPI Section 2.1.2 forbids,
// "so the two belong in the same change".
//
// The PPU is the missing half of that change. ppu_top ties
// enb_qactive_led_quiescence_exit LOW so the Q-Channel controller cannot
// un-quiesce on its own, and routes DEVQACTIVE into ppu_seq as a wake REQUEST
// instead; the sequencer restores the PCSM state, de-isolates, restarts the
// clock and releases the resets BEFORE it drops the quiescence request. With
// that ordering guaranteed, giving the wrapper a reset independent of the
// domain is safe -- so here it gets aon_rst_n resynchronized into dclk, the
// interface stays alive while the domain is off, and wake works.
//
// That is also why the wrapper stays in this module rather than going out with
// the device: it has to be always-on and reset-free with respect to the
// domain, and this module is where both are guaranteed.
//
// -----------------------------------------------------------------------------
// TWO DEVICE RESETS, NOT ONE
//
// The device has two classes of logic state, and the PPU's reset table draws a
// line between them that only exists if something consumes all three device
// resets:
//
//   dev_nret_rst_n   non-retained   DEVPORESETn & DEVWARMRESETn
//   dev_ret_rst_n    retained       DEVPORESETn & DEVRETRESETn
//
// The FULL_RET row of Table 4-9 is what the pair is for: PORESETn 1,
// WARMRESETn 0, RETRESETn 1, so the first product is 0 and the second is 1 --
// the non-retained logic is reset while the retained logic keeps its value.
// Every other mode drives the two products the same way, which is why FULL_RET
// is the only mode that needs them separated. A device with no retained state
// leaves dev_ret_rst_n open.
//
// -----------------------------------------------------------------------------
// ISOLATION IS UPF, NOT RTL
//
// dev_isolaten drives no logic here. The off-to-on crossings are clamped by
// the isolation strategy in the power intent, following the same convention as
// the Q-Channel design: a clamp is a physical cell, and modelling it in RTL
// would put a second, hand-maintained copy of the clamp value next to the one
// in the power intent.
//
// There is more than one crossing, and the count is worth stating because both
// UPF files claimed "exactly ONE" until the intent was first executed and
// Xcelium's elaboration report disagreed:
//
//   the device's outputs   into dev_quiescent_busy/deny and dev_wake, and so
//                          into the always-on device wrapper
//   u_clkctrl.gated_clk    out through dev_clk, which is always-on wiring, and
//                          back into the device -- domain membership follows
//                          the net's scope, not the endpoints' instances
//   the device's RAM       out to the always-on SRAM banks
//   controls
//
// The strategy is written at domain level with -applies_to outputs, so all of
// them are covered. The RAM crossing is the one that changes what the clamp is
// FOR: a corrupted write-enable reaching a retained memory would destroy it,
// and clamping to 0 is what makes that unreachable.
//
// The clamp is load-bearing here in a way it was not in qchannel_pd_top.
// There, the wrapper was held in reset while the domain was down, so its
// outputs were pinned regardless of what busy did. Here the wrapper is live,
// and an unpowered device's busy would otherwise reach dev_quiescent_deny and
// dev_wake every cycle.

import ppu_pkg::*;

module ppu_dom_top #(
  // Same ordering as ppu_top: by the offset of the register each parameter is
  // visible in, then by bit position within it, high to low. Everything from
  // DEF_PWR_DYN_EN down is forwarded verbatim to ppu_top; see there for what
  // each one selects.
  //
  // They are forwarded rather than left inside ppu_top for one reason: a
  // parameter that only exists on the inner module can never be cleared by
  // anything that instantiates the domain, so its `0` behaviour -- which the
  // spec defines in detail, register by register -- is unreachable and
  // therefore untestable. See ppu_minconfig_tb, and the fifth DUT in
  // ppu_reset_tb for PCSM_TINIT_WAIT.

  // ---- PPU_PWPR, 0x000 (Table 5-2) ----
  parameter bit         DEF_PWR_DYN_EN        = 1'b0,     // [8]     PWR_DYN_EN
  parameter logic [3:0] DEF_PWR_POLICY        = PM_ON,    // [3:0]   PWR_POLICY

  // ---- PPU_PTCR, 0x024 (Table 5-12) ----
  parameter bit         WARM_RST_DEVREQEN_CFG = 1'b1,     // [0]     WARM_RST_DEVREQEN

  // ---- PPU_DCDR0, 0x170 (Table 5-24) ----
  parameter logic [7:0] RST_HWSTAT_DLY_CFG    = 8'd2,     // [23:16] RST_HWSTAT_DLY
  parameter logic [7:0] ISO_CLKEN_DLY_CFG     = 8'd2,     // [15:8]  ISO_CLKEN_DLY
  parameter logic [7:0] CLKEN_RST_DLY_CFG     = 8'd2,     // [7:0]   CLKEN_RST_DLY

  // ---- PPU_DCDR1, 0x174 (Table 5-25) ----
  parameter logic [7:0] CLKEN_ISO_DLY_CFG     = 8'd2,     // [15:8]  CLKEN_ISO_DLY
  parameter logic [7:0] ISO_RST_DLY_CFG       = 8'd2,     // [7:0]   ISO_RST_DLY

  // ---- PPU_IDR0, 0xFB0 (Table 5-26) -- Tables 7-4 and 7-1 mode support ----
  parameter bit         DYN_ON_SPT_CFG        = 1'b1,     // [28]    DYN_ON_SPT
  parameter bit         DYN_FUNC_RET_SPT_CFG  = 1'b1,     // [27]    DYN_FUNC_RET_SPT
  parameter bit         DYN_FULL_RET_SPT_CFG  = 1'b1,     // [26]    DYN_FULL_RET_SPT
  parameter bit         DYN_MEM_OFF_SPT_CFG   = 1'b1,     // [25]    DYN_MEM_OFF_SPT
  parameter bit         DYN_MEM_RET_SPT_CFG   = 1'b1,     // [22]    DYN_MEM_RET_SPT
  parameter bit         DYN_OFF_SPT_CFG       = 1'b1,     // [20]    DYN_OFF_SPT
  parameter bit         STA_FUNC_RET_SPT_CFG  = 1'b1,     // [15]    STA_FUNC_RET_SPT
  parameter bit         STA_FULL_RET_SPT_CFG  = 1'b1,     // [14]    STA_FULL_RET_SPT
  parameter bit         STA_MEM_OFF_SPT_CFG   = 1'b1,     // [13]    STA_MEM_OFF_SPT
  parameter bit         STA_MEM_RET_SPT_CFG   = 1'b1,     // [10]    STA_MEM_RET_SPT

  // ---- PPU_IDR1, 0xFB4 (Table 5-27) -- optional features ----
  parameter bit         OFF_MEM_RET_TRANS_CFG = 1'b1,     // [12]    OFF_MEM_RET_TRANS
  parameter bit         FUNC_RET_RAM_REG_CFG  = 1'b1,     // [6]     FUNC_RET_RAM_REG
  parameter bit         FULL_RET_RAM_REG_CFG  = 1'b1,     // [5]     FULL_RET_RAM_REG
  parameter bit         MEM_RET_RAM_REG_CFG   = 1'b1,     // [4]     MEM_RET_RAM_REG
  parameter bit         LOCK_CFG              = 1'b1,     // [2]     LOCK_SPT
  parameter bit         SW_DEV_DEL_CFG        = 1'b1,     // [1]     SW_DEV_DEL_SPT
  parameter bit         PWR_MODE_ENTRY_DEL_CFG= 1'b1,     // [0]     PWR_MODE_ENTRY_DEL_SPT

  // ---- Not visible in any register ----
  parameter int unsigned SYNC_STAGES          = 2,

  // ---- Which crossings this integration actually has ----
  //
  // THIS module is what decides, and it decides by wiring: u_ppu and u_pcsm are
  // both given aon_clk below, so the PCSM P-Channel never leaves a clock
  // domain. Two stages each way on a path with no crossing is four cycles added
  // to every PCSM handshake -- and every power mode transition performs at
  // least one -- plus about ten flops per PPU instance.
  //
  // It is a PARAMETER rather than a hardcoded 0, and the distinction is not
  // pedantry. PCSA 7.2.3 requires the PCSM be in a power domain relative
  // always-on to the one it controls; it says nothing about clocks, so a
  // different integration may legitimately put the PCSM on its own clock. What
  // makes 0 correct here is the two .clk connections in this file, which is
  // exactly the kind of fact a parameter default is for and a constant is not.
  //
  // The DEVICE interface keeps its synchronizers: u_dev runs on dclk and is the
  // one genuine asynchronous crossing in the design. PCSA 7.1.3 recommends
  // partitioning clock domains "at either asynchronous boundaries or at other
  // natural divergences in the clock tree such as a power domain boundary",
  // which is precisely where this one sits.
  parameter bit          PCSM_SYNC_EN         = 1'b0,
  parameter bit          DEV_SYNC_EN          = 1'b1,
  parameter bit          DEV_ACTIVE_SYNC_EN   = 1'b1,
  parameter bit          QCLK_SYNC_EN         = 1'b1,
  // What the PCSM reports on PCSMMODESTAT at reset (Section 4.1.6, Table 4-13).
  parameter logic [3:0] PCSM_RESET_MODESTAT   = PM_OFF,
  // The switches' settling times, in aon_clk cycles, which the PCSM waits out
  // before the retention save and before the restore and the accept of a
  // power-up. 0, the default, is right for ideal switches such as the power
  // intent's. See ppu_pcsm, and SWITCH SETTLING above.
  parameter int unsigned PCSM_RET_SETTLE      = 0,
  parameter int unsigned PCSM_LOGIC_SETTLE    = 0,
  // The PCSM's published tinit, in PPU clock cycles (AMBA LPI Section 2.2.2).
  parameter int unsigned PCSM_TINIT_WAIT      = 16
) (
  // ---- Always-on domain: PPU and PCSM ----
  input  logic aon_clk,
  input  logic aon_rst_n,     // async, ACTIVE LOW

  // ---- PPU software interface ----
  input  logic [11:0] reg_waddr,
  input  logic [31:0] reg_wdata,
  input  logic        reg_wen,
  input  logic [3:0]  reg_wstrb,
  input  logic [11:0] reg_raddr,
  input  logic        reg_ren,
  output logic [31:0] reg_rdata,
  output logic        irq,

  // ---- PPU clock control interface (PCK-600 Tables A-28, A-29) ----
  //
  // Brought straight out to this module's boundary rather than terminated
  // inside it, because the block that owns them is a CLOCK CONTROLLER and a
  // clock controller is not part of a power domain -- it sits above one and
  // usually above several. ppu_axi_dom_top and ppu_clkq_top close the loop by
  // putting a ppu_clk_ctrl on the other end of these four wires and gating
  // aon_clk with its clken_o.
  //
  // Tie ppuclk_qreqn HIGH and pwakeup LOW to leave the interface parked in
  // Q_RUN. In that configuration the channel is inert: nothing inside the PPU
  // consumes its state.
  input  logic        ppuclk_qreqn,
  output logic        ppuclk_qacceptn,
  output logic        ppuclk_qdeny,
  output logic        ppuclk_qactive,
  input  logic        pwakeup,

  // ---- The device's clock ----
  input  logic        dclk,

  // ---- Device side: the Q-Channel, qchannel_device's contract (dclk) ----
  input  logic        dev_quiescent_busy,
  input  logic        dev_quiescent_deny,
  input  logic        dev_wake,
  output logic        dev_quiescent_ok,

  // ---- Device side: clock and resets (dclk) ----
  output logic        dev_clk,
  // DEVCLKEN after u_clken_sync, the enable of u_clkctrl below. Added
  // 2026-10-05 for the clock/reset request bridge (platform plan H16, PD8):
  // where the SoC's clkgate is the authority, this is the request into it.
  // An output only: nothing inside changes.
  output logic        dev_clken_req,
  output logic        dev_nret_rst_n,
  output logic        dev_ret_rst_n,

  // ---- Device side: isolation and status (aon_clk) ----
  output logic        dev_isolaten,
  output logic [15:0] ppuhwstat,

  // ---- Device side: the PCSM's technology-specific controls (aon_clk) ----
  output logic        logic_on,
  output logic        logic_ret,
  output logic        ret_n,
  output logic [7:0]  ram_sleep,
  output logic [7:0]  ram_sd
);

  // Q-Channel wires (asynchronous between aon_clk and dclk).
  logic dev_qreqn, dev_qacceptn, dev_qdeny, dev_qactive;

  // Device controls out of the PPU (aon_clk domain). DEVISOLATEn and PPUHWSTAT
  // go straight to the ports of the same name.
  logic        dev_clken, dev_poresetn, dev_retresetn, dev_warmresetn;

  // PCSM P-Channel (both ends in the aon_clk domain).
  logic [15:0] pcsm_pstate;
  logic        pcsm_preq, pcsm_paccept;
  logic [7:0]  pcsm_modestat;

  // PCSM decode with no RTL consumer. ram_on, ram_ret and ram_cfg are what
  // ram_sleep and ram_sd are registered from, and pcsm_mode is the committed
  // mode; the testbenches read all four hierarchically.
  logic        ram_on, ram_ret;
  logic [7:0]  ram_cfg;
  logic [3:0]  pcsm_mode;

  // Device-clock-domain internals.
  logic dev_clken_dclk;   // DEVCLKEN, resynchronized into dclk
  logic wrap_rst_n;       // wrapper reset, independent of the domain

  // ---- The PPU ----
  ppu_top #(
    .DEF_PWR_DYN_EN        (DEF_PWR_DYN_EN),
    .DEF_PWR_POLICY        (DEF_PWR_POLICY),
    .WARM_RST_DEVREQEN_CFG (WARM_RST_DEVREQEN_CFG),
    .RST_HWSTAT_DLY_CFG    (RST_HWSTAT_DLY_CFG),
    .ISO_CLKEN_DLY_CFG     (ISO_CLKEN_DLY_CFG),
    .CLKEN_RST_DLY_CFG     (CLKEN_RST_DLY_CFG),
    .CLKEN_ISO_DLY_CFG     (CLKEN_ISO_DLY_CFG),
    .ISO_RST_DLY_CFG       (ISO_RST_DLY_CFG),
    .DYN_ON_SPT_CFG        (DYN_ON_SPT_CFG),
    .DYN_FUNC_RET_SPT_CFG  (DYN_FUNC_RET_SPT_CFG),
    .DYN_FULL_RET_SPT_CFG  (DYN_FULL_RET_SPT_CFG),
    .DYN_MEM_OFF_SPT_CFG   (DYN_MEM_OFF_SPT_CFG),
    .DYN_MEM_RET_SPT_CFG   (DYN_MEM_RET_SPT_CFG),
    .DYN_OFF_SPT_CFG       (DYN_OFF_SPT_CFG),
    .STA_FUNC_RET_SPT_CFG  (STA_FUNC_RET_SPT_CFG),
    .STA_FULL_RET_SPT_CFG  (STA_FULL_RET_SPT_CFG),
    .STA_MEM_OFF_SPT_CFG   (STA_MEM_OFF_SPT_CFG),
    .STA_MEM_RET_SPT_CFG   (STA_MEM_RET_SPT_CFG),
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG),
    .FUNC_RET_RAM_REG_CFG  (FUNC_RET_RAM_REG_CFG),
    .FULL_RET_RAM_REG_CFG  (FULL_RET_RAM_REG_CFG),
    .MEM_RET_RAM_REG_CFG   (MEM_RET_RAM_REG_CFG),
    .LOCK_CFG              (LOCK_CFG),
    .SW_DEV_DEL_CFG        (SW_DEV_DEL_CFG),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .SYNC_STAGES           (SYNC_STAGES),
    .QCLK_SYNC_EN          (QCLK_SYNC_EN),
    .DEV_SYNC_EN           (DEV_SYNC_EN),
    .DEV_ACTIVE_SYNC_EN    (DEV_ACTIVE_SYNC_EN),
    .PCSM_SYNC_EN          (PCSM_SYNC_EN),
    .PCSM_RESET_MODESTAT   (PCSM_RESET_MODESTAT),
    .PCSM_TINIT_WAIT       (PCSM_TINIT_WAIT)
  ) u_ppu (
    .clk      (aon_clk),
    .rst_n    (aon_rst_n),

    // ---- Section 6.2 software interface, straight out to the wrapper's ports ----
    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wen  (reg_wen),
    .reg_wstrb(reg_wstrb),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren),
    .reg_rdata(reg_rdata),
    .irq      (irq),

    // ---- Clock control interface, straight out to this module's ports ----
    .ppuclk_qreqn   (ppuclk_qreqn),
    .ppuclk_qacceptn(ppuclk_qacceptn),
    .ppuclk_qdeny   (ppuclk_qdeny),
    .ppuclk_qactive (ppuclk_qactive),
    .pwakeup        (pwakeup),

    // ---- Section 6.3 device interface: the Q-Channel to u_dev below ----
    .dev_qreqn   (dev_qreqn),
    .dev_qacceptn(dev_qacceptn),
    .dev_qdeny   (dev_qdeny),
    .dev_qactive (dev_qactive),

    // ---- Section 6.4 device controls: clock gate, isolation, three resets ----
    .ppuhwstat    (ppuhwstat),
    .dev_clken     (dev_clken),
    .dev_poresetn  (dev_poresetn),
    .dev_retresetn (dev_retresetn),
    .dev_warmresetn(dev_warmresetn),
    .dev_isolaten  (dev_isolaten),

    // ---- Section 6.5 PCSM interface, to u_pcsm below ----
    .pcsm_pstate  (pcsm_pstate),
    .pcsm_preq    (pcsm_preq),
    .pcsm_paccept (pcsm_paccept),
    .pcsm_modestat(pcsm_modestat)
  );

  // ---- PCSM (always-on, same domain as the PPU) ----
  // The PCSM's own end of the same non-crossing. Both halves have to agree or
  // only one side's flops disappear.
  //
  // PGOOD_EN is 0 and is not a parameter of this module (SWITCH SETTLING in
  // the header), so the switch acknowledges are tied to the controls: the tie
  // ppu_pd_top's PGOOD_EN = 0 default always selected.
  logic pg_logic, pg_ret;
  assign pg_logic = logic_on;
  assign pg_ret   = logic_ret;

  ppu_pcsm #(
    .SYNC_STAGES   (PCSM_SYNC_EN ? SYNC_STAGES : 0),
    .TINIT         (4),
    .RESET_MODESTAT(PCSM_RESET_MODESTAT),
    .PGOOD_EN      (1'b0),
    .RET_SETTLE    (PCSM_RET_SETTLE),
    .LOGIC_SETTLE  (PCSM_LOGIC_SETTLE)
  ) u_pcsm (
    .clk   (aon_clk),
    .rst_n (aon_rst_n),

    // ---- The P-Channel device side of the same three wires u_ppu drives ----
    .pcsm_pstate (pcsm_pstate),
    .pcsm_preq   (pcsm_preq),
    .pcsm_paccept(pcsm_paccept),

    .ack_logic_on (pg_logic),
    .ack_logic_ret(pg_ret),

    // ---- Table 3-1 decode: what the switches and RAM actually do ----
    .logic_on    (logic_on),
    .logic_ret   (logic_ret),
    .ram_on      (ram_on),
    .ram_ret     (ram_ret),
    .ram_cfg     (ram_cfg),

    // ---- Registered technology-specific controls: the SRAM macro pins, per
    //      bank, and the logic retention cells' save/restore ----
    .ram_sleep   (ram_sleep),
    .ram_sd      (ram_sd),
    .ret_n       (ret_n),

    // ---- The mode it decoded, and what it reports back at reset release ----
    .pcsm_mode   (pcsm_mode),
    .pcsm_modestat(pcsm_modestat)
  );

  // ---- Device-interface Q-Channel wrapper (dclk domain, always-on) ----
  // Reset from aon_rst_n rather than from the PPU's device resets, so the
  // interface survives the domain going down and DEVQACTIVE can carry a wake
  // back to the PPU. See the header for why that is only safe with a PPU
  // sequencing the way back up.
  rst_sync u_wrap_rst (
    .clk      (dclk),
    .rst_in_n (aon_rst_n),
    .rst_out_n(wrap_rst_n)
  );

  qchannel_device #(.SYNC_STAGES(SYNC_STAGES)) u_dev (
    .clk     (dclk),
    .rst_n   (wrap_rst_n),

    // ---- The Q-Channel, device side ----
    .qreqn   (dev_qreqn),
    .qacceptn(dev_qacceptn),
    .qdeny   (dev_qdeny),
    .qactive (dev_qactive),

    // ---- The device's policy: when it may stop, deny, and ask to wake ----
    .dev_quiescent_busy(dev_quiescent_busy),
    .dev_quiescent_deny(dev_quiescent_deny),
    .dev_wake          (dev_wake),
    .dev_quiescent_ok  (dev_quiescent_ok)
  );

  // ---- Clock gating ----
  // DEVCLKEN is driven in the aon_clk domain and gates a dclk-domain clock, so
  // it crosses asynchronously and must be resynchronized before it reaches the
  // gate. This is precisely the case Section 4.1.5 warns about when choosing
  // CLKEN_RST_DLY: "if the clock enable is re-synchronized the clock might not
  // be running as soon as the clock enable is asserted from the PPU, so a
  // larger delay period might need to be used".
  cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_clken_sync (.clk(dclk), .rst_n(wrap_rst_n), .d(dev_clken), .q(dev_clken_dclk));

  clk_gate u_clkctrl (
    .clk      (dclk),
    .clk_en   (dev_clken_dclk),
    .gated_clk(dev_clk)
  );

  assign dev_clken_req = dev_clken_dclk;

  // ---- Device resets ----
  // The two products of TWO DEVICE RESETS in the header, each synchronized
  // into dclk.
  logic dev_rst_in_n, dev_ret_rst_in_n;
  assign dev_rst_in_n     = dev_poresetn & dev_warmresetn;
  assign dev_ret_rst_in_n = dev_poresetn & dev_retresetn;

  rst_sync u_wl_rst (
    .clk      (dclk),
    .rst_in_n (dev_rst_in_n),
    .rst_out_n(dev_nret_rst_n)
  );

  rst_sync u_ret_rst (
    .clk      (dclk),
    .rst_in_n (dev_ret_rst_in_n),
    .rst_out_n(dev_ret_rst_n)
  );

endmodule
