# PPU conformance status and roadmap

What this PPU implements against the **Arm Power Policy Unit Architecture
Specification v1.1** (ARM DEN 0051E), what it does not, and what would have to
change to close each remaining item.

Companion to [`README.md`](README.md), which describes how the block works.
This file is only concerned with *coverage against the specification*. Section
references are to ARM DEN 0051E unless marked otherwise.

**Nothing in [§5](#5-suggested-next-steps) has been implemented.** It is a
roadmap, not a changelog.

---

## 1. At a glance

| | Count | |
|---|---:|---|
| Spec features implemented and verified | 33 | [§2](#2-implemented-and-verified) |
| Implemented but **not** verified | none | [§3.1](#31-built-but-not-exercised-by-any-test) |
| Not implemented — **architecturally impossible** for a Q-Channel PPU | 8 | [§4.1](#41-cannot-exist-on-a-q-channel-ppu) |
| Not implemented — optional features, additive | 3 | [§4.2](#42-optional-features-not-built) |
| Known deviations and simplifications | 5 | [§3.2](#32-deviations-and-simplifications) |
| Confirmed non-conformances | **all fixed** (F1–F13) | [§3.4](#34-confirmed-non-conformances) |

The headline: **the Q-Channel PPU profile is functionally complete and
conformant.** A line-by-line cross-check against the specification tables found
eight conformance gaps (Section 3.4), later passes and the SCP firmware stress
test five more; all are now fixed, and each later fix carries a regression
check that fails without it. Every mandatory
behaviour and every optional feature a single-Q-Channel PPU can have is built,
and nothing mandatory is outstanding.

What remains is (a) two optional extensions the specification treats as
independent axes — emulation modes and multiple Q-Channels — and (b) integration
work that is about the *domain* rather than the PPU: a PCSM power-good, a RAM
macro, retiring the older hand-written scheme, and a synthesis flow.

Synthesis now has **partial** evidence rather than none — see
[§6](#6-synthesis-status), which is deliberately precise about what is and is
not covered, because "the linter is clean" is easy to over-read.

---

## 2. Implemented and verified

Verified = exercised by a check in [`ppu_pd_tb.sv`](../../tb/ppu/ppu_pd_tb.sv).
Phase references are to [`TEST_MATRIX.md`](../../tb/ppu/TEST_MATRIX.md).

### Power modes and transitions

| Feature | Spec | Where | Test |
|---|---|---|---|
| All 7 Q-Channel modes: `OFF`, `MEM_RET`, `FULL_RET`, `MEM_OFF`, `FUNC_RET`, `ON`, `WARM_RST` | §3.1, Table 3-1/3-2 | `ppu_pkg` | P2, P3 |
| `ON`-anchored transition routing | §3.3.2 | `ppu_seq` | P4 |
| `OFF → MEM_RET` direct hop, PCSM-only, one-way | §3.3.2, §4.2.6 | `S_PCSM_ONLY` | P8 |
| Static transitions | §3.4.2 | `ppu_seq` | P2 |
| Dynamic transitions via `DEVQACTIVE`, both directions | §3.4.3 | `ppu_seq` | P7 |
| `WARM_RST` excluded from dynamic transitions | §3.4.3 | `ppu_policy_spt` | P9 |
| Lock: enter, hold against a wake, release via `PPU_UNLK` | §3.4.3 | `ppu_seq` | P10 |
| Reset behaviour, default policy `ON`, silent default transition | §4.2.1 | `ppu_seq` | P0 |

### Sequencing and device control

| Feature | Spec | Where | Test |
|---|---|---|---|
| Departure ordering: quiesce → clock → isolation → reset → PCSM | §4.1.5, Fig 4-24 | `S_DN_*` | P2 |
| Return ordering: PCSM → isolation → clock → reset → un-quiesce | §4.1.5, Fig 4-22 | `S_UP_*` | P2 |
| Per-mode device control values | Tables 4-7/4-9/4-11 | `ppu_devctl` | P2, P3 |
| `PPUHWSTAT` one-hot, spec-exact bit positions | §4.1.4 | `ppu_hwstat` | P0, P2 |
| `RST_HWSTAT_DLY` gated on the device handshake as well as the count | Table 4-5 | `S_UP_RST` | P2 |
| `ON ↔ WARM_RST` handshake switchable via `WARM_RST_DEVREQEN` | Table 4-4 | `dev_hs_for_hop` | P3 |
| Denial: policy reversion per Table 4-1, no controls touched | §4.1.1, §4.2.9 | `S_DENIED` | P5 |

### PCSM interface

| Feature | Spec | Where | Test |
|---|---|---|---|
| P-Channel master with no `PDENY`/`PACTIVE` | §4.1.6 | `ppu_top` | P6 |
| Handshake gates the sequence in both directions | §4.1.6 | `ppu_seq` | P6 |
| `WARM_RST` presented to the PCSM as `ON` | Table 3-2 note a | `ppu_pcsm_mode` | P3 |
| Retention config passed through to `PCSMPSTATE[15:8]` | §5.2.16–18 | `hop_ram_cfg` | P2, P8 |

### Programmer's model

| Feature | Spec | Where | Test |
|---|---|---|---|
| Unsupported policy refused, `PPU_PWPR` unchanged, `UNSPT_POLICY_IRQ` raised | §4.1.1 | `ppu_regs` | P9 |
| Support depends on policy **and** dynamic enable jointly | §4.1.1 | `ppu_policy_spt` | P9 |
| `PPU_IDR0`/`IDR1` derived from the build parameters | §5.2.23–24 | `ppu_regs` | P1 |
| `PPU_IIDR`/`PPU_AIDR` | §5.2.25–26 | `ppu_regs` | P1 |
| Reserved registers decoded and read-as-zero | §5.2 | `ppu_regs` | P1 |
| Policy-completion interrupts fire once per policy, not per hop | §4.1.2 | `ppu_seq` | P4 |
| Denial interrupt | §4.1.2 | `ppu_irq` | P5 |
| Lock interrupt | §4.1.2 | `ppu_irq` | P10 |

---

## 3. Implemented but incomplete

### 3.1 Built but not exercised by any test

**All six items previously listed here were closed by testbench phases P11-P15
and P17.** Entry delay timers, the input edge interrupt, both `PPU_PWCR`
enables, non-default device control delays and the acceptance interrupts are
now exercised. P12 additionally confirmed the audit's claim that `S_DELAY` had
never executed before it (`delay_entries == 0` at the end of P11).

**Both configuration paths that were open here are now covered**, by
[`ppu_reset_tb.sv`](../../tb/ppu/ppu_reset_tb.sv) (`make ppurst`). They needed a
second instantiation rather than a new phase, because the two inputs that decide
reset behaviour are both elaboration-time: `DEF_PWR_POLICY` is a configuration
parameter and `PCSMMODESTAT` is *"only sampled by the PPU at reset release"*. So
that testbench builds **four** DUTs, one per row of Table 4-13, and shares one
software-interface bus across them so a single read returns all four values.

| `DEF_PWR_POLICY` | `PCSMMODESTAT` | Table 4-13 behaviour | Previously run? |
|---|---|---|---|
| `OFF` | `OFF` | initialises into `OFF` | no |
| `OFF` | `MEM_RET` | initialises into `MEM_RET` | no — and **F5** lived here |
| `ON` | `OFF` | initialises into `ON` | yes, `ppu_pd_tb` P0 |
| `ON` | `MEM_RET` | initialises into `MEM_RET`, then transitions to `ON` | no |

Nothing in this section remains open.

### 3.4 Confirmed non-conformances

Found by cross-checking the RTL against the specification's own tables rather
than against the task brief it was written from. **All three are now fixed.**
The lesson worth keeping: every one came from trusting a derived summary over
the specification's own tables.

| # | Defect | Spec | Location |
|---|---|---|---|
| ~~**F1**~~ | **FIXED.** `WARM_RST` drove `DEVRETRESETn` HIGH; Table 4-9 groups `WARM_RST` with `MEM_RET_EMU`/`OFF_EMU` at `DEVRETRESETn = 0`. Table 4-8 defines `DEVWARMRESETn` as the warm reset for *non-retention* registers and `DEVRETRESETn` for *retention* registers, so a warm reset asserts both — only `FULL_RET`/`LOGIC_RET` hold it HIGH. As built, a component in `WARM_RST` kept its retention registers un-reset. Caught independently by testbench phase P21 on its first run, which is why it was fixed here rather than deferred: the all-modes actuation table cannot be written correctly without it. | Table 4-9 | [`ppu_pkg.sv`](ppu_pkg.sv) |
| ~~**F2**~~ | **FIXED.** `STA_POLICY_PWR_IRQ` was implemented, but Section 4.1.2 states the power and operating policy completion events *"are not supported when operating modes are not supported."* `PPU_IDR1[8]` must read 0 and `PPU_AISR[3]`/`PPU_AIMR[3]` must be reserved. With no operating modes the event is an exact duplicate of `STA_POLICY_TRN`, which is why the spec removes it. `PPU_IDR1` now reads `0x1077`, not `0x1177`, and `PPU_AIMR[4:3]`/`PPU_AISR[4:3]` are write-ignored — checked in P20. | §4.1.2 | [`ppu_regs.sv`](ppu_regs.sv), [`ppu_irq.sv`](ppu_irq.sv), [`ppu_seq.sv`](ppu_seq.sv) |
| ~~**F3**~~ | **FIXED.** Three comments cited *"Section 4.2.3"* for "a transition to a higher priority power mode cannot be denied". The statement is in §4.2.9, not §4.2.3: *"Q-Channel PPU transitions to higher priority power modes, except for those to warm reset, cannot be denied."* Figure 4-36, in the same section, shows such a transition being denied on a P-Channel PPU. The behaviour is correct for a **Q-Channel** PPU, and the mechanism is AMBA LPI Table 2-1 — `Q_DENIED` is reachable only from `Q_REQUEST`, and the exit path has no deny state. This matters because §4.2.9's reversal obligation is real, and the argument that it is vacuous here rests entirely on this claim. All three sites now cite §4.2.9 and AMBA LPI Table 2-1, and note that the PPU spec shows the opposite for a P-Channel PPU. | §4.2.9 | [`ppu_seq.sv`](ppu_seq.sv), [`README.md`](README.md) |

The one gap that was unimplemented rather than wrong, also now closed:

| # | Gap | Spec |
|---|---|---|
| ~~**F4**~~ | **FIXED.** Full-policy completion conditions 3 and 4, both of which require `PPU_PWPR` to be written *during* a transition. Condition 3: a denied transition whose mid-flight policy write matches the current mode — software changed its mind to the mode it was already in, so the outcome *is* what it last asked for, and without the event that write would be acknowledged by nothing. Condition 4: a transition completing with `PWR_DYN_STATUS = 1` after `PWR_DYN_EN` was cleared mid-flight, reachable only because the status lags the enable until the sequencer is idle (§3.4.3). Both are covered by phase P27, with negative contrasts for each, and each condition was mutation-tested independently. | §4.1.2 |
| ~~**F5**~~ | **FIXED.** With `DEF_PWR_POLICY = OFF` and `PCSMMODESTAT = MEM_RET`, §4.1.6 requires `PPU_PWPR.PWR_POLICY` to be set to `MEM_RET`; `ppu_regs` reset it to `DEF_PWR_POLICY` unconditionally, so that build initialised into `MEM_RET` and immediately left for `OFF`. Row 2 of [`ppu_reset_tb`](../../tb/ppu/ppu_reset_tb.sv) is the regression test — reverting the fix fails four of its checks. That mutation also surfaced a **second symptom the original audit missed**: the unwanted `MEM_RET → OFF` transition raised a completion interrupt, which §4.2.1 forbids for the default transition. | §4.1.6, Table 4-13 |

### Found by the deep behavioural re-read

A second pass over Chapter 3 and 4 looking specifically at *behaviour* rather
than feature presence — because a feature can be built and still not match the
description — turned up two more, both in code that was already passing every
test it had:

| # | Defect | Spec |
|---|---|---|
| ~~**F7**~~ | **FIXED.** `DEVQACTIVE` gated only *dynamic* transitions. §3.4.2 "Static Power Mode Transitions with a Q-Channel PPU" is explicit: *"For transitions from ON, other than to WARM_RST, all DEVQACTIVE inputs must be LOW to begin a transition"* — a **static** rule, and a different one from §3.4.3's. The two look alike from a distance and are not: dynamic `DEVQACTIVE` HIGH means "climb to ON" and *sets a target*; static `DEVQACTIVE` HIGH means "do not leave ON" and only **blocks**, never dragging the PPU upward, because a static policy is a target rather than a minimum. `WARM_RST` is exempt both ways. Covered by phase P28; mutation-tested both by reverting the gate (4 failures) and by over-blocking `WARM_RST` (2 failures). | §3.4.2 |
| ~~**F8**~~ | **FIXED, and the most consequential of the three.** §4.1.6 "PCSM P-Channel Reset": *"The PCSMPSTATE output is reset to the default power mode of the PPU... This ensures that the reset value is sampled by the PCSM before any other transition is allowed on the interface."* `PCSMPSTATE`'s reset value was hardcoded to `OFF`. With `PCSMMODESTAT = MEM_RET` the PPU therefore reported `MEM_RET` while the PCSM captured `OFF` during its `tinit` and drove `ram_ret = 0` — **dropping the RAM retention it had just told the PPU it was holding.** And nothing corrected it, because with policy equal to status no transition ever ran. Now derived from `PCSM_RESET_MODESTAT`, with an RTL check that the parameter and the pin agree. Covered by `ppu_reset_tb`; reverting the fix fails four checks. | §4.1.6 |
| — | **Coverage gap, not a defect.** §4.1.3's rule that a delay value reprogrammed mid-count *"continues to use the previous programmed value until the count is restarted"* was implemented correctly but nothing distinguished it from the alternative. Now phase P29: shrinking `OFF_DEL` from 60 to 2 mid-count still counts 61, and the next count uses 3. | §4.1.3 |

### Found by the detailed functional cross-check (pass 8)

| ID | Finding | Spec |
|---|---|---|
| ~~**F9**~~ | **FIXED, and the most consequential functional defect found so far.** §3.4.2: *"Transitions to lower priority power modes are delayed until the relevant power mode DEVACTIVE inputs are LOW. **This is true even if the PPU must go through an intermediate power mode** to reach the programmed policy... all power mode DEVACTIVE inputs between FULL_RET and OFF must be LOW **before the PPU begins the intermediate transition to ON**."* `sta_block` gated on `cur_mode == PM_ON`, which implements only the *last* hop of that and lets the intermediate one through. Observed: from `FULL_RET`, with static policy `OFF` and `DEVQACTIVE` HIGH, the PPU climbed to `ON` — powering up the domain and releasing its reset — and parked there. **A static request for OFF left the domain fully ON.** §3.3.1 is explicit that raising the mode on hardware signalling is what *dynamic* transitions are for; under a static policy `DEVQACTIVE` may only ever hold a transition back, never cause one. Now gated on `pwr_policy < cur_mode` (the encodings are monotonic in priority), with `WARM_RST` exempt in **both** directions — the return leg has `cur_mode = WARM_RST(9)` and policy `ON(8)`, a numerical decrease that is not a power-down. Covered by P31. | §3.4.2, §3.3.1 |

| ~~**F10**~~ | **FIXED.** §4.1.1 requires a denied static transition to revert `PPU_PWPR` to the mode in `PPU_PWSR`. It did — but the sequencer then re-launched the transition that had just been reverted. `revert_vld` is asserted on the same edge that moves `S_DENIED` to `S_IDLE`, so `S_IDLE` next evaluates while `ppu_regs` is still writing the reverted value: it reads `pwr_policy` one cycle stale, sees the **denied** policy, and starts the hop again. Not self-correcting — `hop_q` is latched at that moment and no departure state re-checks it (`S_DELAY` does, but `use_entry_delay` is false whenever the entry delay is `0`, which is its **reset** value, so the out-of-the-box configuration is the vulnerable one). Measured on the full stack: one denied request for `OFF` produced **`ON → OFF → ON`**, powering the domain down to a mode software had explicitly had reverted out from under it, then back up. Fixed by adding `&& !revert_vld` to the `S_IDLE` hop-start condition; the reverted policy equals `cur_mode` by construction, so the suppressed hop is one that is not needed a cycle later anyway. Covered by `ppudeny` D10. | §4.1.1 |

Two things about F9 are worth recording beyond the fix itself, and both apply
to F10 as well.

**It was invisible to end-state checking.** The broken design still reached `OFF`
eventually — it just went the wrong way first and waited in the wrong place. Every
existing phase asserted where the PPU *ended up*, so none of them could see it.
P31 asserts the mode is **held**, which is the only formulation that fails against
the old behaviour.

**The first version of P31 was vacuous**, and the reason generalises.
`check_mode()` in `ppu_pd_tb` *programs* the policy it then verifies — it means
"go to mode X and check the actuation", not "assert we are in X". Using it to
assert "held in `FULL_RET`" silently overwrote the very policy under test, so the
phase passed against a design that blocked nothing. It was caught by tracing why
a later wait timed out and finding `pwr_policy` had reverted to a value nothing
in the phase had written. Assertions about *not moving* must be passive.

### Found by the SCP firmware stress test (2026-09-29)

Three PPU findings, from driving all twelve PPUs of `pmu_top` (retired
2026-10-02; soc4 now carries the firmware-side check) from firmware
(`pmu/PPU_FW_CONFORMANCE.md`). Root causes and proofs are in
[`FIX_PLAN.md`](FIX_PLAN.md); each regression check below fails without its fix.

| ID | Finding | Spec |
|---|---|---|
| ~~**F11**~~ | **FIXED.** A `PPU_PWPR` write with `LOCK_EN` and `PWR_DYN_EN` made in a lockable mode, with a different target, launched the hop it should have prevented: `locked_q` is registered and `S_IDLE` read its old value on the write's own cycle. `{OFF}` in `MEM_RET` ended locked in `ON`. Now `lock_on_write`, the write branch of the lock condition, is combinational and holds `final_tgt`. Regression: `ppu_pd_tb` P36 | §3.4.3, *Locking the PPU* |
| ~~**F12**~~ | **FIXED.** With `PWR_DEVACTIVEEN` = 0 the PPU did not request its gated clock for a `DEVQACTIVE` edge, so the input edge interrupt waited for an unrelated register access. Now, while `PPU_IESR` selects an edge, the clock is requested whenever the input differs from what the edge detector last saw. Regression: `ppu_clkq_tb` G9 | §4.1.3, *DEVACTIVE Enables*; Table 5-9 |
| ~~**F13**~~ | **FIXED.** `STA_POLICY_TRN` completion condition 1 tested `PWR_DYN_STATUS` instead of `PPU_PWPR.PWR_DYN_EN`, and so was wrong exactly for same-mode writes that change the enable. Regression: `ppu_pd_tb` P35 | §4.1.2, *Full Policy Transition Completion* |

The same run found two defects in `ppu_pcsm`, the PCSM model (retention
strobes for Logic Mode OFF, and retention sequencing that rested on a timing
margin). They are not PPU conformance items; `make ppupcsmpg` is their
regression.

### Independent re-derivation of the tables (pass 9)

Every finding up to here came from one reader working through the same PDF. Nine
defects were found that way and the four passes after them found none — but
convergence is not correctness, and a misreading made *consistently* would
survive every pass. This one targets that.

The discipline is the ordering, not the reading: each table was derived from the
specification text and **written to a file before any RTL was opened**, so the
comparison is mechanical and cannot drift toward the answer already in the code.
Sources read fresh: Table 3-1 (logic/RAM modes), Table 3-2 (mode enumeration),
Tables 4-7 / 4-9 / 4-11 (clock enable, resets, isolation), and §3.4.2 / §3.4.3.

| Derived | Compared against | Result |
|---|---|---|
| 11 mode encodings | `ppu_pkg::PM_*` | match |
| `PPUHWSTAT` one-hot mapping, `[15:11]` reserved | `ppu_hwstat()` | match |
| Device controls × 7 modes (35 bits) | `ppu_devctl()` | match |
| PCSM logic/RAM actuation × 6 PCSM-visible modes | `ppu_pcsm` | match |
| 5 static rules (§3.4.2) | `sta_block`, `final_tgt` | match |
| 6 dynamic rules (§3.4.3) | `dyn_status_q`, lock, `ppu_mode_dynamic_spt` | match |

**No mismatches.** The device-control matrix needed reordering to compare —
the specification splits it across three tables in the order clock/reset/isolation
while `ppu_devctl` packs it reset-first — which is exactly the kind of place a
transcription error hides, and it is clean.

#### One latent incompleteness, found by reading the footnote rather than the row

Table 3-2's footnote **a** — *"In these power modes the PPU instructs the PCSM to
have the same conditions as ON"* — marks **four** modes: `DBG_RECOV`,
`WARM_RST`, `MEM_RET_EMU` and `OFF_EMU`. `ppu_pcsm_mode()` mapped only
`WARM_RST`.

This is **not a current defect**: `ppu_mode_static_spt` accepts only the seven
modes this PPU builds, so the other three can never become a hop target, and no
test could have exposed it. It is a trap for later. The two emulation modes exist
to reproduce the functional conditions of `OFF` and `MEM_RET` *without removing
power*; passed through unmapped they would encode `0b0001` / `0b0011` and instruct
the PCSM to remove the very power the mode exists to keep — the exact failure the
footnote prevents, arriving silently the day emulation modes were added.

The function now transcribes the whole footnote. All fifteen suites pass
unchanged, which is the expected result for unreachable code and is the evidence
that nothing else moved.

#### What this pass does and does not settle

It settles that the **tables** are transcribed correctly, by a route that could
not be steered by the existing answer. It does **not** remove the single-reader
risk for the prose rules: S1–S5 and D1–D6 were restated by the same person who
wrote them, and agreement there is weaker evidence than agreement on a table of
numbers. A genuinely separate reader remains the only thing that closes that.

### Signal-level conformance (Chapter 6)

Never cross-checked before pass 8, and mechanically checkable: does every signal
Chapter 6 defines exist, with the right direction and width, and is anything
extra present?

| Spec table | Signal | Ours | Verdict |
|---|---|---|---|
| 6-1 | `CLK`, `RESETn` | `clk`, `rst_n` | ✔ |
| 6-2 | APB bus | `reg_waddr[11:0]`, `reg_wdata`, `reg_wen`, `reg_wstrb[3:0]`, `reg_raddr[11:0]`, `reg_ren`, `reg_rdata` | ✔ — §6.2.1: *"The type of bus interface used is IMPLEMENTATION DEFINED"*, APB is given as **an example**, so the generic strobe bus is explicitly permitted |
| 6-3 | `IRQ` | `irq` | ✔ |
| 6-4 | `DEVQACTIVE`, `DEVQREQn`, `DEVQACCEPTn`, `DEVQDENY` | all four | ✔ single channel, so no per-channel suffix is needed (§6.3 note) |
| 6-5 | P-Channel device iface | absent | n/a — Q-Channel PPU |
| 6-6 | `PPUHWSTAT[31:0]`ᵃ | `ppuhwstat[15:0]` | ✔ reduced; footnote a: *"This is the maximum width, it can be reduced if not all modes are supported."* `[31:16]` is operating-mode status, and Table 3-2 puts power modes in `[10:0]` with `[15:11]` reserved-zero — which `ppu_hwstat()` produces exactly |
| 6-6 | `DEVCLKEN`, `DEVPORESETn`, `DEVRETRESETn`, `DEVWARMRESETn`, `DEVISOLATEn` | all five | ✔ |
| 6-6 | `DEVEMUCLKEN`, `DEVEMUISOLATEn` | absent | n/a — no emulation modes |
| 6-7 | `PCSMPSTATE[15:0]`, `PCSMPREQ`, `PCSMPACCEPT`, `PCSMMODESTAT[7:0]` | all four, exact widths | ✔ |

No signal missing, none extra, every direction correct. The single width reduction
is the one the spec explicitly sanctions.

**Chapter 8 (AXI LPI Support)** is integration guidance for attaching an AXI LPI
device to a PPU Q-Channel, not a requirement on the PPU — the device end ties
`DEVQDENY` LOW and the PPU is unchanged. Worth one note: it restates the
DEVQACTIVE gating rule a third time (*"When a policy other than ON is programmed,
the PPU waits until the DEVQACTIVE input is LOW and then requests quiescence
entry"*), consistent with §3.4.2 and §4.1.3, and satisfied by the F9 fix.

**Chapter 2** is descriptive; it carries no normative requirement not covered
elsewhere.

### A consequence of F7 worth knowing

Fixing F7 made **static denial unreachable in the default configuration**, and
that is correct rather than a regression. `qchannel_device` ORs the workload's
`busy` into `DEVQACTIVE`, so a busy workload advertises activity; §3.4.2 then
stops the PPU asking it to quiesce at all, and a device that is never asked
cannot deny.

A denial then survives only through the CDC race — `busy` rises in `dclk` while
`DEVQACTIVE` needs a `dclk` edge plus two `aon_clk` sync stages to reach the PPU,
so a policy write can land inside that window. That race is exactly what the
denial mechanism exists **for**, and far too fragile to build a test on. So P5,
P18 and P27 now clear `PWR_DEVACTIVEEN` first: §3.4.1 makes a disabled input
*"assumed to be LOW for the purposes of transition control"*, the PPU commits,
and the device gets to refuse. P26 randomises the same enable so denials stay
reachable in the random phase.

And one timing deviation in an implemented event:

| # | Deviation | Spec |
|---|---|---|
| ~~**F6**~~ | **FIXED.** `STA_ACCEPT_IRQ` fired when the device handshake was *accepted* on the departure path — before the device controls and the PCSM handshake — where §4.1.2 says "accepted **and completed**". It was also gated on a handshake existing, so a hop without one produced no event, though the spec says the event is for *"all completed static transitions"*. It now fires at the commit, per hop, unconditionally. Covered by phase P30 in five cases, including a `DEVREQEN = 0` hop added specifically because mutation testing showed the direct `OFF → MEM_RET` case could **not** catch a re-gating regression. | §4.1.2 |

### 3.2 Deviations and simplifications

Each is deliberate, and each is defensible against the specification text — but
they are deviations, and a reader should not have to infer them.

| Deviation | Justification | Risk if wrong |
|---|---|---|
| **The device control sequence is walked unconditionally**, even on hops where a signal does not change (`ON ↔ FUNC_RET` is a complete no-op on the wires) | Table 4-5 constrains a *minimum* separation; an extra delay cannot violate a minimum | None functionally. Costs a few cycles of latency on hops that need none. |
| **`pchannel_controller.RESET_STATE` is fixed at `OFF`'s encoding**, even when `PCSMMODESTAT` says `MEM_RET` | Self-correcting: the sequencer requests a PCSM transition whenever its target differs from the controller's `cur_state`, and a `MEM_RET` start can only hop to `ON` first | Latent. If a future change let the PPU issue a request for `OFF` before any other hop, the controller would think it was already there and skip the handshake. |
| **Generic strobe bus, not APB** | §6.2.1 makes the bus type IMPLEMENTATION DEFINED and offers APB only as an example | None. A wrapper is additive; nothing in `ppu_regs` depends on the handshake. |
| **No PCSM power-good** | The PPU architecture has no such input either (§6.5 lists none) | Real, but the obligation is the PCSM's: it must not assert `PCSMPACCEPT` before its rails settle. `ppu_pcsm` documents this and stands in with handshake latency. |
| **`ram_on`/`ram_ret`/`ram_cfg` decoded but unconsumed** | `dummy_workload` is flops; there is no RAM macro in the domain | None for the PPU. It does mean `MEM_OFF` has no observable effect below the PCSM. |

### 3.3 One measured, sanctioned protocol violation

P3 produces exactly one `qchannel_monitor` R8 violation, and the phase asserts
the count rather than ignoring it. With `WARM_RST_DEVREQEN = 0` there is no
device handshake, so `DEVWARMRESETn` asserts while the interface is still in
`Q_RUN` — a genuine AMBA LPI §2.1.2 breach that PPU Table 4-4 explicitly
sanctions, because the option exists so a component with *no* `WARM_RST`
support can still be warm reset. See [`README.md` §9.2](README.md#92-the-expected-protocol-violations).

---

## 4. Not implemented

### 4.1 Cannot exist on a Q-Channel PPU

These are not missing features. The specification makes them structurally
unavailable to a single-Q-Channel, no-operating-mode PPU, and Table 5-26 /
Table 5-27 hard-wire their support bits to `0`. **Implementing them would mean
building a different PPU, not extending this one.**

| Absent | Why | Consequences in this build |
|---|---|---|
| **Operating modes** | P-Channel only (§3.1.2) | `PPU_OPSR` reserved; `OP_POLICY`/`OP_DYN_EN`/`OP_STATUS`/`OP_DEVACTIVEEN`/`OP_ACTIVE_EDGE_IRQ` reserved; `NUM_OPMODE = 0`; `STA_POLICY_OP_IRQ` absent |
| **`LOGIC_RET`** | *"Always set to 0b0 for a Q-Channel PPU"* (Table 5-26) | `PPU_EDTR0[23:16]` (`LOGIC_RET_DEL`) reserved |
| **`DBG_RECOV`** | Same (Table 5-26) | `PPU_PTCR[1]` (`DBG_RECOV_PORST_EN`) reserved |
| **`PPU_STSR`** | §5.2.6: *"For a Q-Channel PPU with a single Q-Channel this register is reserved"* — with one channel, `DEVQDENY` identifies itself | Reserved, reads zero |
| **P-Channel device interface** | This is a Q-Channel PPU by configuration (`DEVCHAN_CFG = 1`) | `DEVPSTATE`/`DEVPREQ`/`DEVPACCEPT`/`DEVPDENY`/`DEVPACTIVE` do not exist |
| **`DEV_PREQ_DLY`** | P-Channel device delay only (§4.1.3, Fig 4-9) | Not a parameter |
| **Two-handshake bring-up from `OFF`/`MEM_RET`** | §4.2.2 describes it *"For P-Channel PPU"*; a Q-Channel cannot carry a mode value, so there is nothing to initialise the component with | Single exit handshake, per Fig 4-22 |
| **Dynamic `WARM_RST`** | §3.4.3 excludes it for a Q-Channel PPU | `DYN_WRM_RST_SPT = 0`; programming it dynamically raises `UNSPT_POLICY_IRQ` |

### 4.2 Optional features not built

These *could* be added. Each is an independent axis in §7 "Configuration
Options", and none is required for conformance.

| Not built | Spec | What it would add |
|---|---|---|
| **Emulation modes** `OFF_EMU`, `MEM_RET_EMU` | §3.1.1, §4.1.1, §4.2.7 | `PPU_PMER.EMU_EN`; `DEVEMUCLKEN`/`DEVEMUISOLATEn` outputs; `EMU_ACCEPT_IRQ`/`EMU_DENY_IRQ`; the `OFF_EMU → OFF`, `MEM_RET_EMU → MEM_RET` and `OFF_EMU ↔ MEM_RET_EMU` transition rules |
| **Multiple device Q-Channels** (2–8) | §7.1.1 | Per-channel `DEVREQEN[7:0]` and `PWR_DEVACTIVEEN[15:8]`; denial aggregation across channels; `PPU_STSR` becomes a real register; `PPU_IESR[15:0]` populated |
| **APB software interface** | §6.2.1 | The `PSEL`/`PENABLE`/`PREADY` two-phase protocol, as a wrapper over the existing register file |

---

## 5. Suggested next steps

Ordered by value per unit of effort. **None of this is implemented.**

### Tier 0 — fix the confirmed defects — **DONE**

All three of Section 3.4's non-conformances are fixed:

- **F1** landed with P21, because an all-modes actuation table cannot be written
  correctly against a wrong table — the fix and its check had to arrive together.
- **F2** removed the `STA_POLICY_PWR_IRQ` event from `ppu_seq`, `ppu_irq`,
  `ppu_top` and `PPU_IDR1`, and P20 now checks that `PPU_AIMR[4:3]` and
  `PPU_AISR[4:3]` are genuinely write-ignored rather than merely unused.
- **F3** was comment-only. All three sites now cite AMBA LPI Table 2-1 and say
  explicitly that the PPU spec shows the *opposite* for a P-Channel PPU
  (Figure 4-36), so the next reader is not tempted to re-derive the wrong
  justification.

Both were closed after the tier-0 three: F5 alongside `ppu_reset_tb`, which is
its regression test, and F4 alongside phase P27.

F4 and F5 are larger and only matter for configurations this build does not
use, so they belong below rather than here.

### Tier 1 — verify what already exists

**Items 1-5 of this tier were completed by testbench phases P11-P20**, which
took the suite from 132 to 218 checks (339 now, with P21-P25). Entry delay timers, the input edge
interrupt, both `PPU_PWCR` enables, non-default device control delays and the
interrupt semantics are all now exercised, along with several corners that were
not on the original list: policy writes landing mid-transition, dynamic denial
with its non-reverting policy, the lock release paths other than `PPU_UNLK`,
and reserved/unmapped register access.

The cycle-accurate delay checks in P11 have been mutation-tested — injecting an
off-by-one into `ppu_seq`'s `CLKEN_ISO_DLY` counter makes P11 fail with the
exact wrong value. Worth re-running that mutation after any change to the delay
counters, since a timing check that cannot fail is worse than no check.

**Phases P21-P25 then went further than the original tier**, adding a
behavioural power-intent model ([`ppu_power_model.sv`](../../tb/ppu/ppu_power_model.sv))
that stands in for the UPF where no UPF-aware simulator exists. It gives the
suite what it previously had no way to check at all: that the mode transitions
have a *physical* effect. Every mode is now checked as a complete nine-signal
actuation vector, the gated clock is counted in every mode, retention and
corruption are distinguished, the isolation clamp is shown to be load-bearing,
and eight power-sequencing rules run continuously. See
[`TEST_MATRIX.md`](../../tb/ppu/TEST_MATRIX.md) for the three modelling traps
that had to be solved to get there.

What remains in this tier:

1. **Add a `ppu_monitor`, plus a negative test for it.** This is now the
   largest structural gap. `qchannel_monitor` checks the Q-Channel protocol
   independently of the stimulus, and `pchannel_monitor_negtest` proves that
   monitor can fail. The PPU's own rules — Section 4.1.5 ordering, "no device
   control moves before the handshake on a departure", "`PPUHWSTAT` is always
   one-hot and always matches `PWR_STATUS`" — are still checked only by
   directed comparisons inside the testbench. A monitor would catch ordering
   violations in phases that were not written to look for them, and would let
   P2 and P11 stop hand-comparing cycle counts. Follow the existing precedent:
   rule numbers, a `violations` count, and a negative test that deliberately
   breaks each rule.

**Item 2 -- the two unexercised configurations -- is DONE**, as
[`ppu_reset_tb.sv`](../../tb/ppu/ppu_reset_tb.sv): four DUTs, one per row of
Table 4-13, 28 checks. It carries F5's regression test, and F5 was fixed with it.

**Item 3 -- constrained-random policy sequencing -- is DONE**, as testbench
phase P26. It adds no new checking logic, exactly as predicted: the three
checkers already own the properties, so the phase only generates traffic and
asserts that nothing complained. It is reproducible (`+seed=`), soakable
(`+iters=`), and tallies its own coverage so that "0 errors" cannot be mistaken
for "0 stimulus". Seven seeds and a 500-iteration soak pass.

It also earned its keep immediately: seed 999 exposed a missing workload drain
in the post-storm functional check. The RTL was correct -- the device was
refusing to quiesce for a burst still in flight -- which is the reminder that
the first suspect for a random failure is the generator.

**Tier 1 is therefore COMPLETE.** The suite is now six targets: `make ppu` (358
checks), `make ppuneg` (the monitor's negative test, 14), `make ppurst`
(Table 4-13, 28), plus the Q-Channel and P-Channel suites. `make all` runs
everything.

### Tier 2 — spec features not built

**F4 is closed** (Section 3.4), so there is no longer a conformance item in
this tier -- only genuinely optional extensions. Phase P27 covers both of its
conditions, each mutation-tested.

8. **Emulation modes** (`OFF_EMU`, `MEM_RET_EMU`). The largest *self-contained*
   spec addition. It does not change the transition topology — everything stays
   anchored at `ON` — but it adds `PPU_PMER`, two device control outputs, two
   interrupt events, and the rule that a transition aimed at `OFF` lands on
   `OFF_EMU` instead while `EMU_EN` is set, plus the no-handshake
   `OFF_EMU → OFF` and `MEM_RET_EMU → MEM_RET` paths. `ppu_pkg` already decodes
   both encodings in order to reject them, so the support-lookup plumbing is in
   place. Roughly: one new register, five new `ppu_seq` cases, two `ppu_irq`
   events.

9. **A second device Q-Channel.** The biggest architectural change on this
   list, and the one that most changes the shape of `ppu_seq`. Today "the
   device accepted" is one `dev_stopped` bit; with N channels it becomes "all N
   accepted", denial becomes "any denied", and the denial path has to record
   *which* — which is precisely why `PPU_STSR` exists and is reserved here.
   Worth doing only if a real domain needs it; the single-channel case is not a
   degenerate special case of it, it is genuinely simpler.

10. **APB wrapper.** Mechanical, and deliberately deferred rather than
    forgotten: nothing in `ppu_regs` depends on the strobe handshake, so this
    is a new module and no edits. Do it when something needs to talk to the PPU
    over a real bus fabric.

### Tier 3 — integration and physical

11. **Give the PCSM a power-good acknowledge.** Not a PPU change — the PPU
    already waits for `PCSMPACCEPT` before doing anything else. It means an
    input on `ppu_pcsm`, a delay model between "request accepted" and "rail
    settled", and an `-ack_port` on both switches in the UPF. This is the
    remaining sequencing gap called out in
    [`src/upf/README.md`](../../upf/README.md).

12. **Put a RAM macro in the domain.** `MEM_OFF` exists solely to express
    "logic on, RAM off" and currently has no observable effect below the PCSM;
    `PPU_FUNRR`/`FULRR`/`MEMRR` drive per-bank configuration that nothing
    consumes. A memory model would make three of the seven modes physically
    distinguishable instead of two, and would give the IMPLEMENTATION DEFINED
    retention bits a meaning to be checked against.

13. **Retrofit `qchannel_pd_top` onto the PPU.** The repository now has two
    power control schemes: the hand-written `clk_gate` +
    `qchannel_devrst_ctrl` path, and this one. Building standalone was the
    right first move — it avoided coupling the PPU's design to that top level's
    existing interlock behaviour — but retiring the ad hoc path is what turns
    the PPU from "a second scheme" into "the scheme". Note this also closes the
    two open items in `src/upf/README.md` for the *original* domain rather than
    only for a new one.

14. **Finish the synthesis flow.** Started -- see [§6](#6-synthesis-status).
    (2026-10-06: the Vivado flow, `make ppusynth` and `src/constraints` were
    removed; see the note at the top of §6.)
    `make ppuvlint` runs today and is a real gate; the constraints
    (`ppu_pd_top.xdc`,
    `ppu_lpi.xdc`) are written but have never
    been executed, and `make ppusynth` needs a Vivado this machine does not
    have. Two things remain: run it, and add a `ppu_lpi_check.tcl` coverage
    checker like the Q-Channel block's, because a constraint file validated
    only against source can match nothing and still look correct.

### Not recommended

**Do not add operating modes, `LOGIC_RET`, `DBG_RECOV`, or a P-Channel device
interface to this block.** They are P-Channel PPU features
([§4.1](#41-cannot-exist-on-a-q-channel-ppu)); bolting them onto a Q-Channel
PPU would contradict the identification registers and, more importantly, the
mode transition rules of §3.3.2 that the whole sequencer design rests on. If a
P-Channel PPU is ever needed, it is a sibling of `ppu_top` sharing `ppu_regs`
and `ppu_irq`, not a superset of it.

---

## 6. Synthesis status

> **2026-10-06: superseded in part; kept as the record.** `src/lint`
> (`ppu_comb_check.py` with `make ppulatch`, `ppu_srclist_check.py` with
> `make ppusrc`, `ppu_upf_check.py`) was removed on 2026-10-05, and the Vivado
> flow (`make synth`, `impl`, `xsim-pd`, `xsim-diff`, `ppusynth`) with
> `src/constraints` (the XDC files and Tcl checks named below) on 2026-10-06.
> The files are in the git history. Static sign-off is now the Synopsys VC
> suite (`make signoff`;
> [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md)): VC Lint
> reports inferred latches (`InferLatch`, §5 there), and VC CDC/RDC check the
> crossings the XDC files described (§3, §4 there). Synthesis is still not
> run anywhere.

The block's weakest area, and stated precisely because "the linter is clean" is
easy to over-read.

### What runs today

`make ppuvlint` — a Verilator `-Wall` **gate** over the synthesizable RTL
(monitors, the power model and the testbenches excluded, since they use
`$display` in always blocks and are never synthesized). Three warning classes
are waived, each with a reason recorded in the Makefile rather than to quieten
the output:

| Waived | Why it is deliberate here |
|---|---|
| `UNUSED` | `ppu_pd_top` declares the PPU's outputs as real internals with no RTL consumer on purpose — some are observability read hierarchically by the testbench (this repo's no-debug-ports convention), and some have the **power intent** as their consumer: `u_pcsm/logic_on` is the power switch's control port in the UPF, and `DEVISOLATEn` is the isolation enable. Both are load-bearing; neither is visible to Verilator. |
| `PINCONNECTEMPTY` | Documented tie-offs on the reused generic blocks — `pdeny`/`pactive` because a PCSM P-Channel has neither (§4.1.6), `xfer_done` because `ppu_seq` tracks completion through `cur_state`. |
| `IMPORTSTAR` | Matches the existing `qchannel` and `pchannel` style. |

Anything else fails the target.

### What the gate is actually known to catch

Established by **injecting each fault and confirming the gate fires**, not by
reading the manual:

| Class | Injected fault | Caught? |
|---|---|:---:|
| `WIDTH` | narrowed a counter declaration | yes |
| `CASEINCOMPLETE` | removed a `default` arm | yes |
| `SYNCASYNCNET` | used a reset both synchronously and asynchronously | yes |
| `BLKANDNBLK` / `BLKSEQ` | blocking assignment to a non-blocking variable | yes (error) |
| **inferred latch** | `always_comb` branch left without an assignment | **NO** |

### The gap Verilator leaves, and how it is covered instead

**Verilator 4.038 cannot check latch inference at all.** `-Wwarn-LATCH` answers
*"Unknown warning specified"*, and a deliberately incomplete `always_comb`
branch passed `ppuvlint` silently. So `ppuvlint: clean` must never be read as
"no latches".

That class is covered by a separate gate instead:
`src/lint/ppu_comb_check.py` (`make ppulatch`).
It enumerates every `always_comb` block in the synthesizable RTL and requires
one of the two idioms that make a latch impossible — an unconditional
assignment before any branching, or full branch coverage (every `case` has a
`default`, every `if` chain ends in a bare `else`).

All **seven** blocks pass:

| Block | Idiom |
|---|---|
| `ppu_regs.sv:381` `rdata_next` | unconditional default **and** a `default:` arm |
| `ppu_irq.sv:138` `edge_event` | `case` with `default:` |
| `ppu_irq.sv:152` `isr_set`/`aisr_set` | unconditional `= '0` before branching |
| `ppu_seq.sv:259` `final_tgt` | `if`/`else if`/**`else`** |
| `ppu_seq.sv:273` `hop_tgt` | `if`/`else if`/`else if`/**`else`** |
| `ppu_seq.sv:299` `entry_delay` | `case` with `default:` |
| `ppu_seq.sv:331` `hop_ram_cfg` | `case` with `default:` |

**Mutation-tested** against three latch shapes — a `case` with its `default`
removed (on two different blocks) and an `if` chain with no final `else` — and
it catches all three, including the exact fault Verilator passed. It also fails
if it finds *no* blocks, so a path or format change cannot make it vacuous.

It is not a Verilog parser and a real synthesis run supersedes it. But the class
is no longer unverified: it is checked by a gate whose ability to fail has been
demonstrated.

### What is written but never executed

`ppu_pd_top.xdc` (clocks, asynchronous clock
groups, reset and I/O) and `ppu_lpi.xdc` (CDC:
`ASYNC_REG`, bounded `set_max_delay -datapath_only` in **both** directions, and
the reset-release paths kept timed). `make ppusynth` mirrors the Q-Channel
block's `make synth` and fails cleanly with a pointer when Vivado is absent,
which it is here.

Both files follow the Q-Channel constraints' pure-XDC discipline and record one
finding worth reviewing: the PPU has two AMBA LPI interfaces but only **one** is
asynchronous. The PCSM P-Channel has both ends in `aon_clk` — **because
`ppu_pd_top` wires them that way**, not because any specification says so. PCSA
7.2.3 constrains the PCSM's *power* domain ("a power domain that is relative
always-on to the power domain it is controlling") and is silent on clocks; an
earlier version of this paragraph cited it as if it settled the clock question,
and it does not.

Those `cdc_sync` instances were degenerate — real flops on a same-domain path,
four cycles added to every PCSM handshake. They are now removed by
`PCSM_SYNC_EN = 0`, which `ppu_pd_top` sets because it is the module that makes
the wiring decision. `ppu_top` defaults it to **1**: a module that cannot see
its own integration must assume the crossing is real.

### The constraint self-check

`ppu_lpi_check.tcl` is written, and is the
answer to the question a constraint file cannot answer about itself. Every
selector in `ppu_lpi.xdc` uses `-quiet`, which is **silent when it matches
nothing** — a typo, a renamed register, a changed synchronizer depth or an
inlined hierarchy all yield a file that reads correctly, applies cleanly and
constrains nothing. And that failure is invisible in a timing report, because an
unconstrained CDC path does not appear as a violation; it appears as a path
nobody asked about.

So the checker counts what matched and compares against what the RTL says should
exist (16 data-synchronizer flops from 8 `cdc_sync` instances, 4 from two
`rst_sync`), verifies the crossings are **bounded rather than false-pathed**,
verifies the reset *release* paths are still timed, and — the check most likely
to earn its keep — verifies the PCSM P-Channel is **not** constrained as a
crossing. Both ends of it are in `aon_clk`, so a reviewer copying
`qchannel_lpi.xdc` would naturally constrain it, and that would be wrong rather
than merely redundant.

### Synthesis in a real tool: OUT OF SCOPE

Vivado is not installed on this machine. Verified rather than assumed: no
`vivado`/`xvlog`/`xelab`/`xsim` binary anywhere under `/`, `/data`, `/home`,
`/opt`, `/usr/local` or `/tools`; no `settings64.sh`; no `~/.Xilinx` and no
Vivado journal or log, so it has never been run by this account; and both
`XILINXD_LICENSE_FILE` and `LM_LICENSE_FILE` are unset. (Two mounts,
`/media/hoantxn` and `/media/vsi-digic`, are unreadable to this account and
could not be checked.)

Note this is not specific to the PPU: the pre-existing Q-Channel `make synth`,
`make impl` and `xsim-pd` targets have never run here either.

**Running synthesis is therefore out of scope by decision, not merely
unreached.** `ppu_lpi.xdc` and `ppu_lpi_check.tcl` are reviewed deliverables:
correct by inspection, unexecuted.

They used to share that standing with the UPF. They no longer do — Xcelium is
installed here and `make ppupaall` runs the whole PPU suite under IEEE 1801
power intent. That is worth knowing before reading "correct by inspection" as
"correct": the UPF had been reviewed to the same standard and still carried a
wrong Xcelium invocation, a UPF 1.0 command the standard had dropped, and a
comment that miscounted the domain crossings. See
[`upf/README.md`](../../upf/README.md), "What the first power-aware runs found".

**`make ppusynth` used to be worse than unrun — it was wrong.** It sourced
`synth_check.tcl`, the Q-Channel flow script, which reads only `rtl/qchannel` and
synthesizes `qchannel_pd_top`. With Vivado present it would have *succeeded*:
synthesized a different design, validated a different constraint set, written
reports named after it, and never read a line of PPU RTL. The target warned about
exactly this — but only in the branch taken when Vivado is **absent**, so the
warning appeared precisely when it did not matter.

Now fixed. `constraints/ppu_synth_check.tcl` reads the full PPU source list,
synthesizes `ppu_pd_top` out-of-context, applies `ppu_pd_top.xdc` and
`ppu_lpi.xdc`, and sources `ppu_lpi_check.tcl`. It comes with
`ppu_pd_top_synth_keep.xdc`, needed for a subtler reason than the Q-Channel
version: `ppu_pd_top` *does* have real outputs, but the PCSM's actuation signals
and the sequencer's isolation/reset outputs drive nothing inside the module and
would be trimmed — taking with them the very cells `ppu_lpi_check.tcl` looks for,
turning a missing harness into what looks like a constraint bug.

Two parts of that were checkable here and were checked:

- Every instance name in the keep-XDC was verified against the hierarchy the
  simulator elaborates, reusing the VCD reader from `lint/ppu_upf_check.py`. It
  caught `u_clken_sync` missing from the first draft — one of the eight
  `cdc_sync` instances `ppu_lpi_check.tcl` section 1 counts.
- `make ppusrc` (`lint/ppu_srclist_check.py`)
  asserts the synthesis file list equals `PPU_SRCS` minus the two
  verification-only modules, so the two flows cannot silently drift onto
  different designs.

What remains genuinely unrun:

1. **The synthesis itself.** Vivado is not installed, so
   `ppu_synth_check.tcl` has never executed — the same standing as the XDC files
   it applies.
2. **`ppu_lpi_check.tcl` has never run**, so nothing has confirmed the `-quiet`
   regexps in `ppu_lpi.xdc` match real synthesized register names.

So one claim in the block rests on review alone rather than on a passing check:
**that the constraints match real synthesized names.** Every other property has a
gate whose ability to fail has been demonstrated.


---

## 7. What the deep behavioural re-read changed

The first cross-check compared the RTL against the specification's **tables** —
encodings, register fields, per-mode control values — and found three defects. A
second pass read the **prose** of Chapters 3 and 4 instead, asking of each
implemented feature "does it behave the way the text describes", and found three
more. All six were in code that was passing every test it had.

| | Where it hid |
|---|---|
| **F6** acceptance events fired at handshake-accept, not at completion, and not at all without a handshake | §4.1.2's wording is *"accepted **and completed**"* and *"for **all** completed static transitions"*. Nothing tested the event's timing, so the difference was invisible. |
| **F7** `DEVQACTIVE` gated only dynamic transitions | §3.4.2 has a **static** rule that looks like §3.4.3's and is not: dynamic HIGH *sets a target*, static HIGH only *blocks*. Reading one and assuming the other is the whole failure. |
| **F8** `PCSMPSTATE` reset to `OFF` regardless of `PCSMMODESTAT` | The consequence was on the **PCSM's** side of the interface, so every PPU-side check passed while the domain silently lost its retained RAM. |

Three lessons worth carrying:

1. **A feature can be built, tested and still not conform.** Every one of these
   was in the "implemented and verified" table before this pass.
2. **Check the far side of an interface.** F8 was invisible from the PPU's
   registers; it took looking at what the PCSM actually captured and actuated.
3. **Mutation-test the test, not just the design.** P30's `OFF → MEM_RET` case
   looked like coverage of "fires without a handshake" and could not actually
   catch a re-gating regression, because `dev_hs_q` is set before the path is
   chosen. Only injecting that regression revealed it; a `DEVREQEN = 0` case had
   to be added.

### Two requirements nothing was checking

Table 4-12 constrains two `PCSMPSTATE` fields that no test or monitor rule
touched before this pass:

- `[7:4]`, the operating-mode field: *"If the PPU is configured as a Q-Channel
  PPU, or operating modes are not supported, this field is reserved and is always
  set to 0b0000."* Both conditions hold here. Now monitor rule `U10`.
- `[15:8]`, the RAM retain value: carried only by `FUNC_RET`, `FULL_RET` and
  `MEM_RET`, and *"For all other transitions these bits are set to
  0b00000000."* Now monitor rule `U11`.

The RTL was correct on both counts — but neither was verified, and both are the
kind of reserved-field requirement that a later change could break silently.

**`U11`'s first version was wrong, and the monitor caught it on correct
hardware.** It compared the retain field against the *settled* mode from
`PPUHWSTAT`, and fired during the `OFF → MEM_RET` direct hop: `PCSMPSTATE`
carries the mode being *requested*, which legitimately leads the committed one,
and on that path no device control moves so nothing invalidated the settle
condition. Table 4-12 describes the field per *transition*, not per settled mode
— so the rule now compares the retain field against the mode field **in the same
vector**, which needs no settle condition and cannot produce that false positive.
A reminder that a new checker rule is itself unverified code.

### An assumption, rather than a spec gap

The fourth pass found no defect but did find an untested **assumption**: every
testbench ran at one PPU:device clock ratio. §4.1.5 makes the ratio explicitly
significant, since device-control delays are counted in PPU cycles while the
thing being spaced lives in the device's domain — and the case the spec warns
about, a PPU *slower* than its device, had never run.

`make ppuratio` now covers four ratios from 10× faster to 6.7× slower, all
passing with both monitors at zero. Worth recording as a distinct category: not
"the spec says X and we do Y", but "we have only ever tested one point in a space
the spec says matters".

A fifth pass applied the same question to the **configuration** axis and found
the larger instance of it: of seven Chapter 7 optional-feature parameters, five
had never been elaborated to `0`, leaving the false arm of seventeen RTL guards
unsimulated. `make ppucfg` now builds them, and the spec behaviour they were
guarding holds — including the §5.2.19 / §5.2.21 distinction between a register
that becomes *reserved* and one that becomes *read-only with its delays still in
force*. Still no defect: the guards were written correctly, they had simply never
run.

### Table 4-14 appears to list four transitions this PPU does not implement

Worth recording because a reviewer will hit it. Table 4-14 gives, among the modes
this PPU supports, these non-`ON`-anchored pairs as allowed:

`OFF → MEM_OFF` · `MEM_OFF → OFF` · `FULL_RET → FUNC_RET` · `FUNC_RET → FULL_RET`

None of them are implemented, and that is correct. Table 4-14 covers **both** PPU
types; §3.3.2 narrows it for a Q-Channel PPU, verbatim:

> *"Although multiple power modes are supported with a Q-Channel PPU it only
> transitions between ON and the power mode programmed in the PPU_PWPR register.
> The only exceptions to this are transitions which do not perform a device
> interface Q-Channel handshake, these transitions are: ... **From OFF to
> MEM_RET**. ..."*

So on a Q-Channel PPU those four route through `ON`, and the reachable set is
ON-anchored plus the single direct hop — 13 pairs. `MEM_RET → OFF` stays absent
because Table 4-14 gives `MEM_RET` exactly one end mode, `ON`; the hop is
one-way. This is now measured rather than argued: see the coverage matrix below.

A sixth pass took the same question to reset: every testbench asserted
`aon_rst_n` once, at time zero, so §4.2.1 was covered only on the release side.
`make ppurstf` now lands an asynchronous reset at 180 points across three
transitions. No defect again — recovery, PPU/PCSM agreement and actuation are
correct at every point, and both ordering checkers stay at zero.

A seventh pass stopped adding stimulus and started **measuring** it.
`TEST_MATRIX.md` had a hand-written table asserting all seven modes are entered,
and P26 tallies mode requests — both about *modes*, while the specification
defines transitions as a *matrix*. "Every mode was entered" is satisfied by a
suite that only ever goes `ON → X → ON`, which is the shape of most phases.
[`ppu_coverage.sv`](../../tb/ppu/ppu_coverage.sv) now measures the matrix inside
`make ppu`, and the suite covers **13 of 13** reachable pairs and **7 of 7**
Chapter 5 events, with zero illegal pairs taken. The check is enforced, not
printed: removing the direct hop as a mutation drops it to 12/13 and fails.

Worth stating plainly, because it is the useful generalisation from all these
passes: re-reading the specification never surfaces this class of gap. Only
asking what the testbench holds constant does. Three axes have now been swept —
clock ratio, build configuration and reset timing — and each one was invisible to
every reading of the spec that preceded it.

### Sections read at this depth

Chapter 3 in full (3.1.1 mode definitions, 3.2.1 values, 3.3.1–3.3.2 transition
graphs, 3.4.1–3.4.3 transition rules, intermediate transitions, lock); Chapter 4
(4.1.1–4.1.6, 4.2.1–4.2.9, and the PCSM reset and `PCSMMODESTAT` subsections);
Chapter 5 register descriptions in full; Chapters 6 and 7.

Not read at this depth, and deliberately: §3.1.2 and §3.6 (operating modes),
§4.2.7–4.2.8 (emulation and `DBG_RECOV` sequences), §4.3 (operating-mode use
models) and Chapter 8 (AXI LPI appendix). All four describe features that
[§4.1](#41-cannot-exist-on-a-q-channel-ppu) establishes cannot exist on this PPU
or that [§4.2](#42-optional-features-not-built) records as not built — so there
is no implemented behaviour for them to contradict.
