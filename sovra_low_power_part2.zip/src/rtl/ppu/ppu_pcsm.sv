`timescale 1ns/1ps
// PCSM -- Power Control State Machine model.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Sections 2.2, 4.1.6 and Table 3-1; ARM PCSA (DEN 0050)
// Section 7 for the PCSM's role.
//
// The PCSM is the block that physically actuates a power domain: it owns the
// switches, the retention supplies and the RAM power/retention controls, and
// it is told what to do over a P-Channel from the PPU. It lives in the
// always-on domain alongside the PPU -- a block that gates a supply can never
// be powered by that supply (PCSA 7.2.2).
//
// WHAT THIS MODEL IS AND IS NOT
//
// It is the P-Channel DEVICE end plus the Table 3-1 decode of PCSMPSTATE into
// actuation. It is not a model of analogue switch behaviour: there is no ramp
// time and no inrush limiting. The PPU has no power-good input (Section 6.5
// lists none), so a real PCSM's obligation is to hold PCSMPACCEPT LOW until
// its rails have actually settled -- Section 4.1.6 puts the whole power
// transition before the PCSM completes the handshake. This one finishes the
// retention save and restore, and the logic rail's power-up, before it
// accepts. At PGOOD_EN = 1 it also confirms both rails down before accepting a
// power-down; at PGOOD_EN = 0, with nothing to confirm, the power-down rail
// change and the RAM pins follow the committed state, at t4 (see the logic
// decode below). What "settled" means comes from PGOOD_EN: the switches'
// acknowledges when it is 1, and RET_SETTLE / LOGIC_SETTLE cycles when it is
// 0 -- none by default, for ideal switches.
//
// NO DENIAL, NO ACTIVITY
//
// Section 4.1.6, verbatim: the PCSM P-Channel "has no PDENY or PACTIVE
// signals". A PCSM cannot refuse -- refusing to remove power is not a decision
// the actuator gets to make, it is one the PPU already made on the device's
// behalf via the Q-Channel handshake. So dev_deny is tied LOW here and the
// generic pchannel_device's denial path is unreachable by construction, which
// is why the module's pdeny output is left unconnected below.

import ppu_pkg::*;

module ppu_pcsm #(
  parameter int unsigned SYNC_STAGES = 2,
  // Published tinit, in PCSM clock cycles (AMBA LPI Section 2.2.2). The PPU
  // side must not request a transition until this has expired; ppu_top's
  // PCSM_TINIT_WAIT is the matching count on the controller.
  parameter int unsigned TINIT = 4,
  // What this PCSM reports on PCSMMODESTAT at the PPU's reset release
  // (Section 4.1.6). Only OFF and MEM_RET are legal. MEM_RET models a PCSM that
  // kept RAM in retention across the PPU's own reset, which is the entire
  // reason the signal exists.
  parameter logic [3:0] RESET_MODESTAT = PM_OFF,
  // 1 = the switch acknowledges are real and must be waited for.
  // 0 = tie them to the controls at the integration and behave as before.
  //
  // Defaults OFF so every existing instantiation is unchanged: the acknowledge
  // ports are still there and still consumed, but an integration that drives
  // them combinationally from the controls sees exactly the previous timing.
  parameter bit         PGOOD_EN       = 1'b0,
  // Used only when PGOOD_EN = 0, where there is no acknowledge to wait for: the
  // settling time of each switch, in PCSM clock cycles. The save is taken no
  // sooner than RET_SETTLE cycles after the retention rail is switched on. The
  // restore, and the accept of any request that turns the logic rail on, come
  // no sooner than LOGIC_SETTLE cycles after the logic rail is switched on.
  //
  // 0 means no wait, which is correct for ideal switches -- the UPF's are -- and
  // is the timing every integration was built with, so both default to it.
  // RET_SETTLE 0 and 1 behave alike: the save always lands a cycle after the
  // retention rail rises. With LOGIC_SETTLE 0 a power-up is accepted on the
  // edge the logic rail is switched on; the restore still follows a cycle later.
  parameter int unsigned RET_SETTLE   = 0,
  parameter int unsigned LOGIC_SETTLE = 0
) (
  // Always-on domain: the same clock and reset as the PPU. The P-Channel
  // device FSM still synchronizes PREQ, which is degenerate here -- both ends
  // share a clock -- but harmless, and keeping the generic block unmodified is
  // worth more than the two flops it costs.
  input  logic clk,
  input  logic rst_n,

  // ---- PCSM P-Channel, device side ----
  input  logic [15:0] pcsm_pstate,
  input  logic        pcsm_preq,
  output logic        pcsm_paccept,

  // ---- Switch acknowledges ----
  //
  // NOT AN ARM SIGNAL. power-good appears nowhere in DEN 0050, DEN 0051E, the
  // PCK-600 TRM or IHI 0068C -- all four were searched. PCSA Section 6.5.1 puts
  // it below the architectural boundary deliberately: the PCSM "abstracts the
  // PPUs power policies to implementation technology specific power management,
  // such as power switch and retention controls", and how you know a rail has
  // settled is exactly that technology-specific part.
  //
  // It comes from Proposed_PMU/SOVRA_POWER_GATING.md Section 3.1 instead (that
  // document was removed on 2026-10-05; it is in the git history), and
  // in simulation it is produced by IEEE 1801's own mechanism -- the -ack_port
  // and -ack_delay options of create_power_switch -- rather than by a testbench
  // pin. The delay then lives with the switch that causes it.
  //
  // ONE PER SWITCHED RAIL, AND NO RAM. ram_on/ram_ret drive compiled SRAM
  // macro pins whose timing is a property of the macro, not of a UPF power
  // switch; there is no switch to acknowledge and the UPF deliberately models
  // no RAM rail at all (see upf/ppu_pd_top.upf section 9).
  // THE ACKNOWLEDGES ARE ASSUMED TO ARRIVE. THERE IS NO TIMEOUT.
  //
  // A deliberate decision, recorded because the failure mode is silent: a
  // switch that never acknowledges leaves this module holding PCSMPACCEPT LOW
  // forever, the PPU waiting on its P-Channel, and the domain stuck
  // mid-transition with no error anywhere. Nothing reports it and nothing
  // recovers.
  //
  // The alternative was rejected rather than overlooked. It would need the PCSM
  // to signal a fault, and DEN 0051E Section 4.1.6 leaves it nowhere to do so:
  // the PCSM P-Channel "has no PDENY or PACTIVE signals", so a stuck switch
  // cannot be reported over the architected interface at all. It would have to
  // become a sideband to the SCP -- SOVRA_POWER_GATING.md (removed) 4.2's
  // PWR_ERR_STATUS has a "switch fault" code waiting for exactly that -- which
  // is a system-level mechanism this block should not invent on its own.
  //
  // So the contract is: whoever drives these guarantees they eventually track
  // their control. Under UPF that is create_power_switch's -ack_port, which
  // always does. On silicon it is a real power-good detector, and if that can
  // fail then the fault path has to be designed at SoC level and this decision
  // revisited.
  input  logic ack_logic_on,   // SW_LOGIC has settled to whatever logic_on asks
  input  logic ack_logic_ret,  // SW_RET has settled to whatever logic_ret asks

  // ---- Actuation (Table 3-1) ----
  output logic       logic_on,    // logic domain at full supply
  output logic       logic_ret,   // logic domain on the retention supply
  output logic       ram_on,      // RAM at full supply
  output logic       ram_ret,     // RAM on the retention supply
  output logic [7:0] ram_cfg,     // PCSMPSTATE[15:8], IMPLEMENTATION DEFINED
  output logic [3:0] pcsm_mode,   // committed PCSMPSTATE[3:0], for observability

  // ---- SRAM macro pins, one pair per bank ----
  // REGISTERED, and that is not a style choice -- see the block that drives
  // them for the failure that made it necessary.
  output logic [7:0] ram_sleep,   // hold contents, block access
  output logic [7:0] ram_sd,      // remove power, lose contents

  // ---- Logic retention cell control ----
  // Active LOW: 0 = state saved and held, 1 = normal operation. Drives the
  // save/restore of the retention strategy in upf/ppu_pd_top.upf.
  output logic       ret_n,

  // Section 4.1.6 "PCSMMODESTAT": what this PCSM reports back to the PPU at
  // reset release. Only OFF and MEM_RET are legal values.
  output logic [7:0] pcsm_modestat
);

  // The acknowledges come from a switch, which is neither in this clock domain
  // nor in any clock domain -- a UPF -ack_delay is wall-clock, and a real
  // power-good detector is analogue. Two flops, unconditionally: unlike the
  // PCSM P-Channel there IS a crossing here, so there is nothing to optimise
  // away with a SYNC_EN parameter.
  logic ack_logic_on_s, ack_logic_ret_s;

  cdc_sync #(.STAGES(2), .RESET_VAL(1'b0))
    u_ack_on_sync (.clk(clk), .rst_n(rst_n), .d(ack_logic_on),  .q(ack_logic_on_s));
  cdc_sync #(.STAGES(2), .RESET_VAL(1'b0))
    u_ack_ret_sync(.clk(clk), .rst_n(rst_n), .d(ack_logic_ret), .q(ack_logic_ret_s));

  logic [15:0] cur_state;
  logic        dev_req_valid;
  logic [15:0] dev_req_state;
  // SW_RET control. Declared here because logic_ret is assigned from it above
  // the retention block that drives it.
  logic        ret_rail;
  // Declared here for the same reason ret_rail is: u_pdev below consumes
  // accept_hold, and the request decode that defines it is further down.
  logic        accept_hold;
  logic        req_wants_logic, req_logic_off, req_retains_logic;

  pchannel_device #(
    .PSTATE_W   (16),
    .PACTIVE_W  (1),
    .SYNC_STAGES(SYNC_STAGES),
    .TINIT      (TINIT),
    .PACTIVE_RST(1'b0)
  ) u_pdev (
    .clk    (clk),
    .rst_n  (rst_n),

    // ---- The P-Channel wires. Section 4.1.6: this channel "has no PDENY or
    //      PACTIVE signals", so the two outputs that would carry them are left
    //      unconnected rather than driven to a value nobody reads.
    .pstate (pcsm_pstate),
    .preq   (pcsm_preq),
    .paccept(pcsm_paccept),
    .pdeny  (),            // unreachable: dev_deny is tied LOW
    .pactive(),            // no PACTIVE on a PCSM P-Channel

    // ---- Device-side control. The PCSM always accepts, so dev_deny is tied
    //      LOW and dev_init_done is unused: acceptance needs no arbitration.
    .dev_pactive  (1'b0),
    .dev_req_state(dev_req_state),
    .dev_req_valid(dev_req_valid),
    .dev_deny     (1'b0),
    .dev_busy     (accept_hold),
    .dev_cur_state(cur_state),
    .dev_init_done()
  );

  // ---------------------------------------------------------------------------
  // Table 3-1 decode. WARM_RST never appears here: Table 3-2 footnote a has the
  // PPU present it to the PCSM as ON, since the PCSM has no notion of warm
  // reset -- only the device interface does.
  // ---------------------------------------------------------------------------
  logic [3:0] mode;
  assign mode = cur_state[3:0];

  // THE UP-LEG LEADS THE ACCEPT. THE DOWN-LEG DOES TOO WHEN THERE IS AN
  // ACKNOWLEDGE TO WAIT FOR.
  //
  // Decoding logic_on from cur_state alone puts the whole rail change AFTER
  // PCSMPACCEPT, which leaves nothing for an acknowledge to gate -- waiting on
  // it would deadlock, because the switch is not asked to move until the
  // handshake it is supposed to hold up has already completed.
  //
  // So a request that TURNS THE RAIL ON drives it immediately, from the pending
  // request, and the accept is then held until the rail is confirmed (hold_on
  // below). That is the direction where the hazard lives: the PPU releases
  // DEVRSTn on the strength of PCSMPACCEPT, and releasing reset into a domain
  // whose rail has not settled is corruption that looks like a functional bug.
  //
  // At PGOOD_EN = 0 the down-leg stays on the committed decode: with no
  // acknowledge there is nothing to wait for, the PPU has already isolated,
  // gated and reset the domain before PCSMPREQ, so nothing observes the rail
  // discharging, and the next power-up's wait starts from its own rise.
  //
  // At PGOOD_EN = 1 it leads the accept too (early_off below). Section 4.1.6:
  // "The power transition in the PCSM must happen between t1 and t4 in Figure
  // 4-15", t4 being PCSMPACCEPT falling -- and a PCSM that completes a
  // power-down before its switch has even been told to move breaks more than
  // that sentence. Its acknowledge is then still HIGH when a quick power-up
  // arrives, and "logic rail confirmed" reads true for a rail that is on its
  // way down: measured in ppu_pcsm_pgood_tb, a FULL_RET -> ON with no gap
  // restored on the stale acknowledge and the rail fell after the restore.
  // Confirming the rail down inside the handshake means a power-up after a
  // power-down starts from an acknowledge that is LOW, so the next HIGH is a
  // fresh one. A reset is the other way the rail goes off, and it confirms
  // nothing: logic_on drops at once while a slow switch still acknowledges
  // HIGH. ack_on_fresh below covers that case.
  wire mode_keeps_logic = (mode == PM_ON) || (mode == PM_FUNC_RET)
                                            || (mode == PM_MEM_OFF);

  // early_on HOLDS THE RAIL ACROSS THE HANDSHAKE, and it is not optional.
  //
  // dev_req_valid is HIGH only in D_REQUEST. cur_state commits later, when the
  // controller drops PREQ and the device leaves D_ACCEPT. Between the two,
  // req_wants_logic has gone LOW and mode is still the OLD, powered-off value,
  // so an unlatched early term drops the rail again mid-transition.
  //
  // Measured, before this register existed: logic_on pulsed 1-0-1 across the
  // accept, the retention FSM saw the first rising edge and released ret_n, and
  // ppu_power_model PU10 fired six times in one ppu_pd_tb run -- "retention
  // restore before the logic supply returned" -- taking P23 with it.
  // ack_on_fresh, PGOOD_EN = 1 only: the logic acknowledge has been seen LOW
  // since the rail was last told off. Tracked while the rail is off and held
  // while it is on. early_on waits for it, so the rail is not turned back on
  // over an acknowledge that has not yet fallen -- after a reset with the
  // domain ON, for a switch slower than the PPU's start-up (ppu_pcsm_pgood_tb
  // Z, found by review) -- and logic_up requires it, so the accept cannot go
  // by that stale HIGH either. After an ordinary power-down, hold_off has
  // already confirmed the acknowledge LOW, so this costs nothing there.
  logic ack_on_fresh;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)         ack_on_fresh <= 1'b0;
    else if (!logic_on) ack_on_fresh <= !ack_logic_on_s;
  end

  logic early_on;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                early_on <= 1'b0;
    else if (req_wants_logic && (!PGOOD_EN || ack_on_fresh || mode_keeps_logic))
                               early_on <= 1'b1;   // a request wants the rail
    else if (mode_keeps_logic) early_on <= 1'b0;   // the commit has caught up
  end

  // early_off: the down-leg's counterpart, PGOOD_EN = 1 only. Set once a
  // request that removes the logic supply is pending from a mode that has it,
  // and any save that request needs has been taken -- so the retention
  // sequence keeps its order: rail up, save, then the logic supply goes.
  // Cleared when the commit has caught up, exactly as early_on is.
  logic early_off, ret_saved;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                early_off <= 1'b0;
    else if (PGOOD_EN && req_logic_off && mode_keeps_logic
             && (!req_retains_logic || ret_saved))
                               early_off <= 1'b1;
    else if (!mode_keeps_logic) early_off <= 1'b0;
  end

  assign logic_on  = (mode_keeps_logic && !early_off) || early_on;

  // logic_ret is NOT "(mode == PM_FULL_RET)", and the difference is a real
  // sequencing requirement rather than a modelling nicety. See the retention
  // block below for the derivation and the failure that produced it.
  assign logic_ret = ret_rail;
  assign ram_on    = (mode == PM_ON);
  assign ram_ret   = (mode == PM_FUNC_RET) || (mode == PM_FULL_RET) || (mode == PM_MEM_RET);
  assign ram_cfg   = cur_state[15:8];
  assign pcsm_mode = mode;

  // ---------------------------------------------------------------------------
  // SRAM macro pins, per bank
  // ---------------------------------------------------------------------------
  // Section 2.2 makes the PCSM the block that "controls the power switches", and
  // a compiled SRAM's sleep and shutdown pins are power control -- so they
  // belong here rather than in the device, even though the macro lives there.
  // Deriving them anywhere else is what broke, and the failure is worth stating
  // because it is silent, catastrophic, and invisible to every check that only
  // looks at settled values.
  //
  // THE GLITCH
  //
  // ppu_device_ip originally decoded the pins itself from ram_on, ram_ret and
  // ram_cfg. Those are three SEPARATE continuous assignments from cur_state, so
  // they settle in three separate delta cycles, and on an ON -> FUNC_RET
  // transition the simulator evaluated
  //
  //     ram_on   1 -> 0     first
  //     ram_ret  0 -> 1     after
  //     ram_cfg  00 -> 0F   after
  //
  // leaving "!ram_on && !(ram_ret && ram_cfg[b])" momentarily TRUE for every
  // bank, including the ones the mode was entered specifically to retain. A
  // zero-width pulse on shutdown, and the retained memory was gone -- measured:
  // bank 0 held 0xe2a55a5a before the transition and X immediately after, with
  // its shutdown bit reading 0 on both sides.
  //
  // In simulation that presents as "FUNC_RET/FULL_RET/MEM_RET lost their RAM"
  // with no other symptom. In silicon it is a glitch on a memory's power pin,
  // which is not a data-integrity bug so much as a dead part.
  //
  // THE FIX, AND WHY IT IS A FLOP AND NOT JUST A TIDIER EXPRESSION
  //
  // Computing all three from cur_state inside ONE always_comb would remove the
  // delta skew in RTL simulation, and would still be wrong: after synthesis
  // these become real gates with real, unequal propagation delays, and the same
  // decode glitches again for the same reason. A memory's power-control pins
  // have to come out of flops. Registering costs one aon_clk of latency between
  // the PCSM committing a state and the pins following it, which is free here:
  // the PPU has already stopped the clock and isolated the domain before the
  // PCSM request on the way down, and does not release either until after the
  // acknowledge on the way up, so the array is inaccessible across the whole
  // window in which the pins move.
  //
  // Reset drives both pins LOW rather than asserting shutdown. Asserting it
  // would be a posedge, and a posedge on shutdown destroys the array -- correct
  // for a cold boot, where the contents are undefined anyway, but it would also
  // fire on every warm reset of the PPU, wiping memories that the device had
  // every right to keep. Table 4-13 is about which mode the PPU comes up in, not
  // about clearing the device's RAM.
  // ---------------------------------------------------------------------------
  // Logic retention cell control
  // ---------------------------------------------------------------------------
  // Retention save/restore is the PCSM's job, for the same reason the switches
  // and the RAM pins are: it is physical actuation of the domain's power, and
  // the PPU reaches it only by naming a state over the P-Channel.
  //
  // WHY IT CANNOT BE A PPU DEVICE CONTROL
  //
  // The PPU has five device controls -- DEVCLKEN, DEVISOLATEn and three resets
  // -- and NONE of them is a save/restore strobe. Two wrong answers were tried
  // before this one, and both are worth recording because both look plausible:
  //
  //   DEVRETRESETn   Table 4-8 makes it the warm RESET FOR retention registers,
  //                  not a save control. Table 4-11 then leaves it HIGH for the
  //                  whole of FULL_RET, so a strategy keyed on its edge never
  //                  saves in the one mode retention exists for -- silently,
  //                  with every functional check still passing.
  //
  //   DEVISOLATEn    Has the right edges, and is still wrong: it is the
  //                  isolation control. Keying retention off it makes two
  //                  independent device controls one signal, so any future
  //                  change to the isolation timing silently moves the
  //                  retention save with it. The architecture separates them;
  //                  the power intent should not rejoin them.
  //
  // WHY IT LEADS THE SUPPLY, AND HOW
  //
  // The save has to happen while the state is still powered. cur_state only
  // commits when the P-Channel accepts, which is the same instant the supply
  // decode changes -- too late. dev_req_state/dev_req_valid are the PENDING
  // request, visible before the accept, so the save is taken from the target
  // state rather than the committed one.
  //
  // WHICH REQUESTS SAVE: TABLE 3-1'S LOGIC MODE COLUMN
  //
  // Table 3-1 gives each mode a Logic Mode and a RAM Mode, and this machine is
  // the logic half: ret_n drives the save/restore of the UPF strategy on the
  // retained registers, whose shadow cells run on SW_RET. RAM retention is the
  // other half and a separate path -- ram_ret, ram_cfg, ram_sleep and ram_sd
  // above, decoded from the committed mode -- which this machine never touches.
  //
  // Logic Mode RET is FULL_RET and LOGIC_RET. The Q-Channel PPU this PCSM
  // serves never requests LOGIC_RET (PPU_IDR0 defines its support bit as
  // "Always set to 0b0 for a Q-Channel PPU"), but the decode names it so that it
  // is the table's rule rather than one mode's. MEM_RET and OFF have Logic Mode
  // OFF: their logic state is lost with VDD_LOGIC, and the PPU holds the
  // retained registers in reset in both (DEVPORESETn and DEVRETRESETn LOW).
  // This machine used to strobe a save and a restore for them as well, into
  // shadow cells whose supply was never switched on -- VCS native low power
  // reported each one, LP_SAVE_RETPWRDN and LP_RESTORE_RETPWRDN, 50 and 39 of
  // them in one pd_multi run on the 12-domain pmu_top, since retired
  // (pmu/README.md 10.2 finding 3). It leaves them
  // alone now.
  wire [3:0] req_mode        = dev_req_state[3:0];
  wire       req_keeps_logic = (req_mode == PM_ON) || (req_mode == PM_FUNC_RET)
                                                   || (req_mode == PM_MEM_OFF);
  assign     req_retains_logic = (req_mode == PM_FULL_RET) || (req_mode == PM_LOGIC_RET);
  assign     req_logic_off     = dev_req_valid && !req_keeps_logic;
  assign     req_wants_logic   = dev_req_valid &&  req_keeps_logic;
  wire       ret_request       = dev_req_valid &&  req_retains_logic;

  // ---------------------------------------------------------------------------
  // When a rail counts as up
  // ---------------------------------------------------------------------------
  // At PGOOD_EN = 1, when its switch says so. At PGOOD_EN = 0 there is no
  // acknowledge, so a rail counts as up once its control has been on for the
  // settling time -- at once for the default of 0, which is right for the
  // ideal switches of the UPF. The counts restart whenever the control drops,
  // so a quick off-then-on waits the full time again.
  localparam int unsigned LWAIT = (LOGIC_SETTLE > 0) ? LOGIC_SETTLE - 1 : 0;
  localparam int unsigned RWAIT = (RET_SETTLE   > 0) ? RET_SETTLE   - 1 : 0;
  localparam int unsigned LAW   = (LWAIT > 0) ? $clog2(LWAIT + 1) : 1;
  localparam int unsigned RAW   = (RWAIT > 0) ? $clog2(RWAIT + 1) : 1;
  localparam logic [LAW-1:0] LWAIT_V = LWAIT;
  localparam logic [RAW-1:0] RWAIT_V = RWAIT;

  logic [LAW-1:0] logic_age;   // cycles logic_on has been HIGH, saturating
  logic [RAW-1:0] ret_age;     // cycles ret_rail has been HIGH, saturating
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      logic_age <= '0;
      ret_age   <= '0;
    end else begin
      if (!logic_on)                logic_age <= '0;
      else if (logic_age != LWAIT_V) logic_age <= logic_age + 1'b1;
      if (!ret_rail)                ret_age   <= '0;
      else if (ret_age != RWAIT_V)  ret_age   <= ret_age + 1'b1;
    end
  end

  wire logic_up = PGOOD_EN            ? (logic_on && ack_on_fresh && ack_logic_on_s)
                : (LOGIC_SETTLE == 0) ? 1'b1
                :                       (logic_on && (logic_age == LWAIT_V));
  wire ret_up   = PGOOD_EN            ? ack_logic_ret_s
                : (RET_SETTLE == 0)   ? 1'b1
                :                       (ret_rail && (ret_age == RWAIT_V));

  // THREE STATES, NOT A LEVEL DECODE
  //
  // The obvious version -- assert on the pending request, deassert once
  // logic_on is high again -- does not work, and the way it fails is instructive
  // enough to keep: dev_req_valid pulses while the request is still PENDING, so
  // logic_on is necessarily still HIGH at that moment. The deassert condition is
  // already true on the very next cycle and ret_n comes back up before the
  // supply has moved at all. Measured, on an ON -> FULL_RET transition:
  //
  //     25210 NS  ret_n=1  logic_on=1
  //     25220 NS  ret_n=0  logic_on=1     <- save
  //     25230 NS  ret_n=1  logic_on=1     <- restore, one cycle later
  //
  // A one-cycle pulse, not a retention window. The save was taken and discarded
  // before VDD_LOGIC was ever removed, so the retained registers were corrupted
  // by the power-down exactly as if there had been no retention at all.
  //
  // The save has to be HELD across the whole supply-absent window, so the state
  // machine has to observe the supply actually going away rather than infer it
  // from the request. RET_DOWN is that observation.
  // THE RETENTION RAIL MUST LEAD THE PRIMARY RAIL, AND LAG IT COMING BACK
  //
  // logic_ret was "(mode == PM_FULL_RET)" -- a continuous assignment off
  // cur_state, exactly like logic_on. Both therefore changed on the same
  // commit, and in different delta cycles: SW_LOGIC turned OFF before SW_RET
  // turned ON. For that instant VDD_RET was absent, SS_RET matched its RET_OFF
  // state, and RET_OFF carries -simstate CORRUPT -- so the retention cells lost
  // their own supply and the value that had just been saved was destroyed. The
  // restore then put back nothing.
  //
  // The symptom was FULL_RET behaving exactly like MEM_RET, which is precisely
  // the distinction this design exists to make. Reduced to a 40-line testcase:
  // driving the two switch controls from two independent testbench signals
  // PASSES, and changing only their derivation to two continuous assignments
  // off one shared register FAILS. Nothing else in the testcase moved.
  //
  // This is not a simulation artefact. A PCSM that switches both rails on the
  // same edge loses retained state in silicon too, for the same reason and with
  // less warning -- real switches have real, unequal turn-on and turn-off
  // times. The retention rail has to be up and settled BEFORE the primary rail
  // goes, and must stay up until AFTER it returns.
  //
  // ret_rail is that widened window. It is asserted from the PENDING request,
  // so it leads the commit that removes the primary supply, and released one
  // cycle after the restore, so it lags the restoration. The machine only ever
  // leaves RET_IDLE for a request that retains logic, so the rail is held for
  // as long as it is out of RET_IDLE.
  typedef enum logic [1:0] {
    RET_IDLE,   // ret_n = 1, domain running
    RET_ARM,    // retention rail RAISED, save not yet taken
    RET_SAVED,  // ret_n = 0, save taken, supply not yet removed
    RET_DOWN    // ret_n = 0, supply confirmed removed
  } ret_state_t;
  ret_state_t ret_state;
  assign ret_saved = (ret_state == RET_SAVED);

  // MAKE BEFORE BREAK ON BOTH EDGES, AND THE BUG THAT SHOWED IT WAS ONLY ONE
  //
  // This used to be "(ret_state != RET_IDLE) && ret_keep", which is one cycle
  // BEHIND the state it decodes -- so the rail came up one cycle AFTER ret_n
  // fell. The save was therefore taken into a retention cell whose supply was
  // not yet on.
  //
  // That was always wrong and never failed, because the P-Channel's
  // synchronizers put five cycles between the rail coming up and the logic
  // supply going away, and the retention model had settled long before it
  // mattered. Removing them (PCSM_SYNC_EN = 0, the crossing not being real)
  // narrowed the gap to one cycle and the FULL_RET signature stopped
  // surviving -- ppu_pd_tb P23 and P23a, under UPF only.
  //
  // RET_ARM is the fix: one state whose entire job is to raise the rail and
  // wait, so the save lands on a powered cell. The rail rises on the edge that
  // enters RET_ARM, from the pending request, and falls one cycle AFTER the
  // restore, when the machine is back in RET_IDLE.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) ret_rail <= 1'b0;
    else        ret_rail <= (ret_state != RET_IDLE) || ret_request;
  end

  // ---------------------------------------------------------------------------
  // Hold PCSMPACCEPT while the transition still owes a step
  // ---------------------------------------------------------------------------
  // Section 4.1.6: "The power transition in the PCSM must happen between t1 and
  // t4 in Figure 4-15, before the P-Channel transition is completed by the
  // PCSM." Figure 4-15 puts t1 at PCSMPREQ rising and t4 at PCSMPACCEPT
  // falling, and pchannel_device commits cur_state on that same edge -- so
  // anything decoded from the committed state happens AFTER t4, and every step
  // the transition needs has to be finished before the accept. dev_busy holds
  // the device in D_REQUEST, with the request still visible, until it is.
  //
  // This used to rest on a margin instead. The save was left out of the
  // handshake because it "always leads the supply removal by at least a cycle"
  // (pchannel_device's dev_busy note), which was true while RET_ARM took one
  // cycle. PGOOD_EN = 1 made RET_ARM wait for an acknowledge and the margin
  // went: the save landed 1 to 31 cycles after the logic supply was removed, a
  // power-up during the wait stranded the machine in RET_SAVED with the
  // retention rail on, and the restore -- following logic_on, which early_on
  // makes lead the request -- ran ahead of any logic switch of two cycles or
  // more (pmu/README.md 10.2 finding 4, ppu_pcsm_pgood_tb).
  //
  //   hold_on       a request that keeps logic: the logic rail is up
  //   hold_save     a request that retains logic: the save has been taken
  //   hold_restore  a request that keeps logic, leaving a retaining mode: the
  //                 restore has been taken
  //   hold_off      PGOOD_EN = 1, a request that removes logic: the logic rail
  //                 is confirmed down (early_off above)
  //   hold_ret_off  PGOOD_EN = 1, a request that does not retain logic: the
  //                 retention rail is confirmed down, so the next save cannot
  //                 go by a stale acknowledge either
  //
  // With the save and restore inside the handshake, the P-Channel is busy
  // whenever RET_ARM or RET_DOWN owes a step, and AMBA LPI admits no new request
  // until PACCEPT has fallen. Nothing can supersede a power-down part-way, so
  // RET_SAVED's arm for that case is a safety net rather than a path.
  //
  // At PGOOD_EN = 0 with both settle times 0, hold_on, hold_off and
  // hold_ret_off are always 0, and the only cost is two cycles on each FULL_RET
  // entry and two on each exit.
  wire hold_on      = req_wants_logic && !logic_up;
  wire hold_save    = ret_request && ((ret_state == RET_IDLE) || (ret_state == RET_ARM));
  wire hold_restore = req_wants_logic && (ret_state != RET_IDLE);
  wire hold_off     = PGOOD_EN && req_logic_off && (logic_on || ack_logic_on_s);
  wire hold_ret_off = PGOOD_EN && dev_req_valid && !req_retains_logic
                               && (ret_rail || ack_logic_ret_s);
  assign accept_hold = hold_on || hold_save || hold_restore || hold_off || hold_ret_off;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ret_state <= RET_IDLE;
      ret_n     <= 1'b1;
    end else begin
      case (ret_state)
        RET_IDLE:
          // Act on the PENDING request, which leads the supply change --
          // cur_state only commits when the P-Channel accepts, and by then the
          // decode has already removed the rail.
          if (ret_request) ret_state <= RET_ARM;

        RET_ARM:
          // ONE CYCLE WAS ONLY EVER ENOUGH BECAUSE THE RAIL WAS INSTANT.
          //
          // This state exists so the retention rail is UP before the save is
          // taken -- the ordering ppu_power_model PU9 checks. The rail rose on
          // the edge that entered it, and the save waits until the rail counts
          // as up: the next cycle for an ideal switch, RET_SETTLE cycles or the
          // acknowledge for a real one. hold_save keeps the request pending
          // meanwhile, so the logic supply cannot go first.
          if (ret_up) begin
            ret_state <= RET_SAVED;
            ret_n     <= 1'b0;
          end

        RET_SAVED:
          // Wait for the logic supply to go: at the commit, or at PGOOD_EN = 1
          // at early_off, inside the handshake.
          //
          // The first arm cannot be reached through the P-Channel any more --
          // the save is taken before the accept and the supply goes at the
          // commit, so no request that keeps logic can arrive in between. It
          // stays so that such a request can never leave the save held on a
          // running domain; ppu_pcsm_pgood_tb C5 checks it is never taken.
          if (req_wants_logic) begin
            ret_state <= RET_IDLE;
            ret_n     <= 1'b1;
          end else if (!logic_on) begin
            ret_state <= RET_DOWN;
          end

        RET_DOWN:
          // Restore once the logic supply is BACK, not merely requested. early_on
          // raises logic_on at the request, so logic_on alone ran the restore
          // ahead of any switch slower than a cycle. hold_restore keeps the
          // request pending meanwhile, so the restore is inside the handshake
          // and ahead of the PPU's isolation release. Every hop the PPU makes
          // out of FULL_RET is to ON (ppu_seq's hops are anchored on ON), so
          // this is the only way out of RET_DOWN.
          if (logic_on && logic_up) begin
            ret_state <= RET_IDLE;
            ret_n     <= 1'b1;
          end

        default: begin
          ret_state <= RET_IDLE;
          ret_n     <= 1'b1;
        end
      endcase
    end
  end

  logic [3:0] nxt_mode;
  logic [7:0] nxt_cfg;
  logic       nxt_ram_ret;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ram_sleep <= 8'h00;
      ram_sd    <= 8'h00;
    end else begin
      // Read out of the single registered cur_state, so every term below is
      // taken from one consistent value with no ordering between them.
      nxt_mode    = cur_state[3:0];
      nxt_cfg     = cur_state[15:8];
      nxt_ram_ret = (nxt_mode == PM_FUNC_RET) || (nxt_mode == PM_FULL_RET)
                 || (nxt_mode == PM_MEM_RET);
      for (int b = 0; b < 8; b++) begin
        ram_sleep[b] <=  nxt_ram_ret && nxt_cfg[b];
        ram_sd[b]    <= (nxt_mode != PM_ON) && !(nxt_ram_ret && nxt_cfg[b]);
      end
    end
  end

  // Section 4.1.6: sampled by the PPU at reset release only, so a constant is
  // the honest model -- the value cannot legally change afterwards.
  //
  // Note what this does NOT model: with RESET_MODESTAT = MEM_RET the PCSM tells
  // the PPU it is holding RAM in retention, but this model's own actuation
  // still starts at OFF, because pchannel_device captures PCSMPSTATE during
  // tinit and the controller presents OFF's encoding out of reset. That is a
  // limitation of the PCSM model rather than of the PPU: what the PPU owes
  // Table 4-13 is the right initial PWR_STATUS and PWR_POLICY, and that is
  // what ppu_reset_tb checks.
  assign pcsm_modestat = {4'h0, RESET_MODESTAT};

endmodule
