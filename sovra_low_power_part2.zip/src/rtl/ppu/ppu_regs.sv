`timescale 1ns/1ps
// PPU software register file.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Chapter 5 "Programmers Model", restricted to the fields that
// remain meaningful for a single-Q-Channel PPU with no operating modes.
//
// BUS PROTOCOL
//
// Section 6.2.1 makes the bus type IMPLEMENTATION DEFINED and offers APB only
// as an example. This uses a generic strobe interface -- addr/wdata/wen/ren
// with a one-cycle registered read and no wait states -- so the register file
// can be driven and checked directly by a testbench without a bus agent. An
// APB (or any other) wrapper can be added later without touching anything
// below: nothing here depends on the handshake, only on "a write happened this
// cycle at this address".
//
// WHAT IS RESERVED HERE, AND WHY IT IS A DECISION RATHER THAN AN OMISSION
//
// Section 5.2: "All reserved bits are Write Ignored and Read as Zero
// (WI/RAZ)." Three whole registers are reserved by construction:
//
//   PPU_PMER (0x004)  emulation modes are not built
//   PPU_STSR (0x018)  Section 5.2.6, verbatim: "For a Q-Channel PPU with a
//                     single Q-Channel this register is reserved" -- with one
//                     channel there is nothing for a per-channel denial vector
//                     to disambiguate
//   PPU_OPSR (0x044)  operating modes are P-Channel only (Section 5.2.15)
//
// and every operating-mode field inside the surviving registers goes the same
// way. They are decoded and dropped rather than left to fall through the
// default arm, so that an access to one is visibly "a register this PPU does
// not have" rather than indistinguishable from a mistyped address.
//
// THE ONE PLACE A WRITE CAN BE REFUSED
//
// PPU_PWPR. Section 4.1.1 "Programming Unsupported Policies": "If there is an
// attempt to program an unsupported policy, the Power Policy Register
// (PPU_PWPR) is not updated and, if unmasked, an unsupported policy interrupt
// event occurs." Support is a joint property of the policy value AND the
// dynamic enable being written -- WARM_RST is a legal static policy and an
// illegal dynamic one -- so the check runs on the write data as a pair, and it
// rejects the WHOLE register write, LOCK_EN included, not just the offending
// field.

import ppu_pkg::*;

module ppu_regs #(
  // Section 7.1.3 "Default Power Policy". ON means the PPU brings the domain
  // up out of reset by itself (Figure 4-18); OFF means it sits powered down
  // until software says otherwise.
  parameter logic [3:0] DEF_PWR_POLICY        = PM_ON,
  parameter bit         DEF_PWR_DYN_EN        = 1'b0,
  parameter bit         WARM_RST_DEVREQEN_CFG = 1'b1,

  // Optional-feature configuration, reported back to software in PPU_IDR1.
  parameter bit LOCK_CFG               = 1'b1,
  parameter bit SW_DEV_DEL_CFG         = 1'b1,  // PPU_DCDR0/1 writable
  parameter bit PWR_MODE_ENTRY_DEL_CFG = 1'b1,  // PPU_EDTR0/1 present
  parameter bit OFF_MEM_RET_TRANS_CFG  = 1'b1,
  parameter bit FUNC_RET_RAM_REG_CFG   = 1'b1,  // PPU_FUNRR present
  parameter bit FULL_RET_RAM_REG_CFG   = 1'b1,  // PPU_FULRR present
  parameter bit MEM_RET_RAM_REG_CFG    = 1'b1,  // PPU_MEMRR present
  // Per-mode support, built from the Table 7-1 / 7-4 parameters in ppu_top.
  parameter logic [15:0] STA_MASK      = 16'h03E5,
  parameter logic [15:0] DYN_MASK      = 16'h01E5,

  // Device control delay defaults (Section 7.3 "Device Control Delay
  // Parameters"). Table 4-5 defines each as "minimum number of PPU clock
  // cycles ... is <PARAM> + 1", so 0 is a legal value meaning one cycle.
  parameter logic [7:0] RST_HWSTAT_DLY_CFG = 8'd2,
  parameter logic [7:0] ISO_CLKEN_DLY_CFG  = 8'd2,
  parameter logic [7:0] CLKEN_RST_DLY_CFG  = 8'd2,
  parameter logic [7:0] CLKEN_ISO_DLY_CFG  = 8'd2,
  parameter logic [7:0] ISO_RST_DLY_CFG    = 8'd2,

  // PPU_IIDR (Section 5.2.25). IMPLEMENTER is deliberately NOT 0x43B: that is
  // Arm's registered JEP106 identity code and this is not an Arm-licensed
  // implementation. 0x000 is used instead, with a project-local PRODUCT_ID.
  parameter logic [11:0] IIDR_PRODUCT_ID  = 12'h50C,
  parameter logic [ 3:0] IIDR_VARIANT     = 4'h0,
  parameter logic [ 3:0] IIDR_REVISION    = 4'h1,
  parameter logic [11:0] IIDR_IMPLEMENTER = 12'h000
) (
  input logic clk,
  input logic rst_n,

  // The mode the PCSM reports at reset release, derived from PCSMMODESTAT by
  // ppu_top. Section 4.1.6 makes it affect this register's RESET VALUE, which
  // is why the register file needs it at all -- see the reset branch below.
  input logic [3:0] reset_mode,

  // ---- Software interface (generic strobe) ----
  //
  // The write and read addresses are SEPARATE buses, not one shared with a
  // direction bit. AXI4-Lite gives AW/W/B and AR/R no ordering relative to each
  // other, so a bridge is free to have a write and a read outstanding at the
  // same time; a shared address bus would force it to serialise them. With two
  // buses the register file simply decodes twice and the bridge needs no
  // arbiter. See the note on simultaneous same-address access further down.
  input  logic [11:0] waddr,
  input  logic [31:0] wdata,
  input  logic [ 3:0] wstrb,  // byte lanes, see the note below
  input  logic        wen  ,
  input  logic [11:0] raddr,
  input  logic        ren  ,
  output logic [31:0] rdata,

  // ---- Configuration out to the sequencer ----
  output logic [3:0] pwr_policy,
  output logic       pwr_dyn_en,
  output logic       lock_en   ,

  // ---- Single-cycle pulses: PPU_UNLK written, PPU_PWPR accepted ----
  output logic unlock_wr,  // 1-cycle pulse: PPU_UNLK.UNLOCK written
  output logic policy_wr,  // 1-cycle pulse: PPU_PWPR accepted

  // ---- PPU_PWCR / PPU_PTCR: per-transition channel and DEVACTIVE enables ----
  output logic devreqen         ,  // PPU_PWCR.DEVREQEN[0]
  output logic devactiveen      ,  // PPU_PWCR.PWR_DEVACTIVEEN[0]
  output logic warm_rst_devreqen,  // PPU_PTCR.WARM_RST_DEVREQEN

  // ---- PPU_DCDR0 / PPU_DCDR1: device control delays (Table 4-5) ----
  output logic [7:0] rst_hwstat_dly,
  output logic [7:0] iso_clken_dly ,
  output logic [7:0] clken_rst_dly ,
  output logic [7:0] clken_iso_dly ,
  output logic [7:0] iso_rst_dly   ,

  // ---- PPU_EDTR0 / PPU_EDTR1: per-mode entry delays ----
  output logic [7:0] off_del     ,
  output logic [7:0] mem_ret_del ,
  output logic [7:0] full_ret_del,
  output logic [7:0] func_ret_del,
  output logic [7:0] mem_off_del ,

  // ---- Retention RAM configuration, forwarded into PCSMPSTATE ----
  output logic [7:0] funrr,
  output logic [7:0] fulrr,
  output logic [7:0] memrr,

  // ---- Status in from the sequencer ----
  input logic [3:0] pwr_status    ,
  input logic       pwr_dyn_status,
  input logic       lock_status   ,
  // Section 4.1.1 "Transition Denial Policy Reversion": on a denial the policy
  // reverts to the mode in PPU_PWSR, and any dynamic enable set during the
  // transition reverts to its pre-transition value. The sequencer owns the
  // Table 4-1 decision about WHETHER to revert; this file only applies it.
  input logic       revert_vld   ,
  input logic [3:0] revert_policy,
  input logic       revert_dyn_en,

  // ---- Device interface / PCSM status inputs, already synchronized ----
  input logic dev_qactive ,
  input logic dev_qacceptn,
  input logic dev_qdeny   ,
  input logic pcsm_paccept,

  // ---- Interrupt block: this file decodes, ppu_irq stores ----
  output logic wr_imr ,
  output logic wr_aimr,
  output logic wr_isr ,
  output logic wr_aisr,
  output logic wr_iesr,

  // ---- Interrupt register write strobes, decoded here and used in ppu_irq ----
  input logic [31:0] imr ,
  input logic [31:0] aimr,
  input logic [31:0] isr ,
  input logic [31:0] aisr,
  input logic [31:0] iesr,

  output logic ev_unspt_policy
);

  // ---------------------------------------------------------------------------
  // Identification registers. Fixed at elaboration from the parameters above,
  // so PPU_IDR0/IDR1 always describe the PPU that was actually built -- there
  // is no second copy of the feature set for the two to drift apart.
  // ---------------------------------------------------------------------------
  // Table 5-26, with this PPU's mode set substituted in. DYN_WRM_RST_SPT[29],
  // DYN_LGC_RET_SPT[24], STA_DBG_RECOV_SPT[18] and STA_LGC_RET_SPT[12] are
  // "Always set to 0b0 for a Q-Channel PPU"; the emulation bits [23], [21],
  // [11] and [9] are 0 because those modes are not built. NUM_OPMODE = 0x0
  // reads as "1 operating mode", which is the spec's encoding for disabled.
  localparam logic [31:0] IDR0_VAL =
      ((DYN_MASK[PM_ON      ] ? 32'b1 : 32'b0) << 28)   // [ 28] DYN_ON_SPT
    | ((DYN_MASK[PM_FUNC_RET] ? 32'b1 : 32'b0) << 27)   // [ 27] DYN_FUNC_RET_SPT
    | ((DYN_MASK[PM_FULL_RET] ? 32'b1 : 32'b0) << 26)   // [ 26] DYN_FULL_RET_SPT
    | ((DYN_MASK[PM_MEM_OFF ] ? 32'b1 : 32'b0) << 25)   // [ 25] DYN_MEM_OFF_SPT
    | ((DYN_MASK[PM_MEM_RET ] ? 32'b1 : 32'b0) << 22)   // [ 22] DYN_MEM_RET_SPT
    | ((DYN_MASK[PM_OFF     ] ? 32'b1 : 32'b0) << 20)   // [ 20] DYN_OFF_SPT
    | ((STA_MASK[PM_WARM_RST] ? 32'b1 : 32'b0) << 17)   // [ 17] STA_WRM_RST_SPT
    | ((STA_MASK[PM_ON      ] ? 32'b1 : 32'b0) << 16)   // [ 16] STA_ON_SPT
    | ((STA_MASK[PM_FUNC_RET] ? 32'b1 : 32'b0) << 15)   // [ 15] STA_FUNC_RET_SPT
    | ((STA_MASK[PM_FULL_RET] ? 32'b1 : 32'b0) << 14)   // [ 14] STA_FULL_RET_SPT
    | ((STA_MASK[PM_MEM_OFF ] ? 32'b1 : 32'b0) << 13)   // [ 13] STA_MEM_OFF_SPT
    | ((STA_MASK[PM_MEM_RET ] ? 32'b1 : 32'b0) << 10)   // [ 10] STA_MEM_RET_SPT
    | ((STA_MASK[PM_OFF     ] ? 32'b1 : 32'b0) <<  8)   // [  8] STA_OFF_SPT
    | ((                        32'd1        ) <<  0);  // [3:0] DEVCHAN = 1 Q-Channel

  // Table 5-27. Three bits stay 0 for operating-mode reasons:
  //   [10] OP_ACTIVE                  operating modes cannot exist here
  //   [9]  STA_POLICY_OP_IRQ_SPT      ditto
  //   [8]  STA_POLICY_PWR_IRQ_SPT     Section 4.1.2 makes BOTH policy-split
  //        completion events unsupported "when operating modes are not
  //        supported" -- not just the operating-mode one. With no operating
  //        modes the power-policy event carries exactly the information
  //        STA_POLICY_TRN already carries.
  localparam logic [31:0] IDR1_VAL =
      ((OFF_MEM_RET_TRANS_CFG  ? 32'b1 : 32'b0) << 12)   // OFF_MEM_RET_TRANS
    | ((FUNC_RET_RAM_REG_CFG   ? 32'b1 : 32'b0) <<  6)   // FUNC_RET_RAM_REG
    | ((FULL_RET_RAM_REG_CFG   ? 32'b1 : 32'b0) <<  5)   // FULL_RET_RAM_REG
    | ((MEM_RET_RAM_REG_CFG    ? 32'b1 : 32'b0) <<  4)   // MEM_RET_RAM_REG
    | ((LOCK_CFG               ? 32'b1 : 32'b0) <<  2)   // LOCK_SPT
    | ((SW_DEV_DEL_CFG         ? 32'b1 : 32'b0) <<  1)   // SW_DEV_DEL_SPT
    | ((PWR_MODE_ENTRY_DEL_CFG ? 32'b1 : 32'b0) <<  0);  // PWR_MODE_ENTRY_DEL_SPT

  localparam logic [31:0] IIDR_VAL =
      {IIDR_PRODUCT_ID, IIDR_VARIANT, IIDR_REVISION, IIDR_IMPLEMENTER};

  localparam logic [31:0] AIDR_VAL = 32'h0000_0011;  // architecture v1.1

  // ---------------------------------------------------------------------------
  // Register storage
  // ---------------------------------------------------------------------------
  // PPU_PWPR
  logic [3:0] pwpr_policy_q;
  logic       pwpr_dyn_en_q;
  logic       pwpr_lock_en_q;
  // PPU_PWCR
  logic       pwcr_devreqen_q;
  logic       pwcr_devactiveen_q;
  // PPU_PTCR
  logic       ptcr_warm_rst_devreqen_q;
  // PPU_PUNRR PPU_PULRR PPU_MEMRR
  logic [7:0] funrr_q, fulrr_q, memrr_q;
  // PPU_DETR0
  logic [7:0] full_ret_del_q, mem_ret_del_q, off_del_q;
  // PPU_DETR1
  logic [7:0] func_ret_del_q, mem_off_del_q;
  // PPU_DCDR0
  logic [7:0] rst_hwstat_dly_q, iso_clken_dly_q, clken_rst_dly_q;
  // PPU_DCDR1
  logic [7:0] clken_iso_dly_q, iso_rst_dly_q;

  // ---------------------------------------------------------------------------
  // Address decode. One select per implemented register, plus an explicit
  // "reserved register" term for the three that this PPU decodes only in order
  // to ignore.
  // ---------------------------------------------------------------------------
  // Written but never read back: PPU_UNLK is write-only (Section 5.2.7,
  // "A read always returns 0b0").
  wire wsel_pwpr  = (waddr == A_PWPR );
  wire wsel_unlk  = (waddr == A_UNLK );
  wire wsel_pwcr  = (waddr == A_PWCR );
  wire wsel_ptcr  = (waddr == A_PTCR );
  wire wsel_imr   = (waddr == A_IMR  );
  wire wsel_aimr  = (waddr == A_AIMR );
  wire wsel_isr   = (waddr == A_ISR  );
  wire wsel_aisr  = (waddr == A_AISR );
  wire wsel_iesr  = (waddr == A_IESR );
  wire wsel_funrr = (waddr == A_FUNRR);
  wire wsel_fulrr = (waddr == A_FULRR);
  wire wsel_memrr = (waddr == A_MEMRR);
  wire wsel_edtr0 = (waddr == A_EDTR0);
  wire wsel_edtr1 = (waddr == A_EDTR1);
  wire wsel_dcdr0 = (waddr == A_DCDR0);
  wire wsel_dcdr1 = (waddr == A_DCDR1);

  // Read but never written: PPU_PWSR, PPU_DISR and PPU_MISR are status, and
  // the four identification registers are fixed at elaboration.
  wire rsel_pwpr  = (raddr == A_PWPR );
  wire rsel_pwsr  = (raddr == A_PWSR );
  wire rsel_disr  = (raddr == A_DISR );
  wire rsel_misr  = (raddr == A_MISR );
  wire rsel_pwcr  = (raddr == A_PWCR );
  wire rsel_ptcr  = (raddr == A_PTCR );
  wire rsel_imr   = (raddr == A_IMR  );
  wire rsel_aimr  = (raddr == A_AIMR );
  wire rsel_isr   = (raddr == A_ISR  );
  wire rsel_aisr  = (raddr == A_AISR );
  wire rsel_iesr  = (raddr == A_IESR );
  wire rsel_funrr = (raddr == A_FUNRR);
  wire rsel_fulrr = (raddr == A_FULRR);
  wire rsel_memrr = (raddr == A_MEMRR);
  wire rsel_edtr0 = (raddr == A_EDTR0);
  wire rsel_edtr1 = (raddr == A_EDTR1);
  wire rsel_dcdr0 = (raddr == A_DCDR0);
  wire rsel_dcdr1 = (raddr == A_DCDR1);
  wire rsel_idr0  = (raddr == A_IDR0 );
  wire rsel_idr1  = (raddr == A_IDR1 );
  wire rsel_iidr  = (raddr == A_IIDR );
  wire rsel_aidr  = (raddr == A_AIDR );

  // ---------------------------------------------------------------------------
  // Byte lanes (Section 6.2.1)
  //
  // The specification leaves the bus type IMPLEMENTATION DEFINED and shows an
  // APB3 example in Table 6-2, which has no strobe. This build carries one
  // anyway, so the register file can sit directly behind an APB4 PSTRB or an
  // AXI4-Lite WSTRB instead of behind a shim that has to invent a
  // read-modify-write it cannot perform atomically.
  //
  // `wr` is the qualified write. A transaction with no lane asserted is not a
  // write: without this, wstrb == 0 would still fire policy_wr, raise
  // UNSPT_POLICY_IRQ and pulse the W1C strobes -- every side effect of a
  // transaction that transfers nothing.
  //
  // Each field below is then gated by the lane it lives in. That is exact
  // rather than approximate because every IMPLEMENTED field in this register
  // file lies wholly within one byte lane. PPU_PWCR is the case worth naming:
  // its architectural PWR_DEVACTIVEEN is [18:8] and does cross lanes, but with
  // one Q-Channel only bit [8] exists, so wstrb[1] covers it.
  // ---------------------------------------------------------------------------
  wire wr = wen && (|wstrb);

  // ---------------------------------------------------------------------------
  // PPU_PWPR write admission (Section 4.1.1). Evaluated on the write DATA, as
  // the value/enable pair software is asking for -- not on the current state.
  // ---------------------------------------------------------------------------
  wire       pwpr_wr         = (wr && wsel_pwpr);
  wire [3:0] pwpr_wr_policy  = (wstrb[0] ? wdata[3:0] : pwpr_policy_q );
  wire       pwpr_wr_dyn_en  = (wstrb[1] ? wdata[  8] : pwpr_dyn_en_q ) && (|DYN_MASK);
  wire       pwpr_wr_lock_en = (wstrb[1] ? wdata[ 12] : pwpr_lock_en_q) && (LOCK_CFG);
  // Split rather than a `wire ... = ...` like the four above: Verilator 4.038
  // mis-parses a function call inside a net DECLARATION assignment, dropping the
  // comma between the last two arguments. The same call in a standalone `assign`
  // is fine, so the workaround costs one line and no semantics.
  wire pwpr_wr_ok;
  assign pwpr_wr_ok = ppu_policy_spt(STA_MASK, DYN_MASK, pwpr_wr_policy, pwpr_wr_dyn_en);

  // Merged with what the register already holds, because the two fields sit in
  // DIFFERENT byte lanes -- PWR_POLICY is [3:0] and PWR_DYN_EN is [8]. A write
  // of byte 0 alone changes the policy and must be admitted against the CURRENT
  // dynamic enable, not against whatever the master happened to leave on
  // wdata[8] in a lane it did not select. Admitting the un-merged word would
  // reject pairs software never asked for, and accept pairs it never asked for
  // either. The merged value is both what gets validated and what gets
  // committed, so the two can never disagree.
  assign policy_wr       = (pwpr_wr &&  pwpr_wr_ok);
  assign ev_unspt_policy = (pwpr_wr && !pwpr_wr_ok);

  assign unlock_wr = (LOCK_CFG && wr && wsel_unlk && wstrb[0] && wdata[0]);

  // Interrupt-register write strobes, routed to ppu_irq.
  assign wr_imr  = (wr && wsel_imr );
  assign wr_aimr = (wr && wsel_aimr);
  assign wr_isr  = (wr && wsel_isr );
  assign wr_aisr = (wr && wsel_aisr);
  assign wr_iesr = (wr && wsel_iesr);

  // ---------------------------------------------------------------------------
  // Writes
  //
  // The denial revert takes priority over a software write in the same cycle.
  // That ordering is not arbitrary: Section 4.1 says "Software writes to the
  // Power Policy Register (PPU_PWPR) do not interrupt mode transitions", so a
  // write that lands in the same cycle as the reversion is a write that
  // arrived DURING the transition being reverted -- and Section 4.1.1's whole
  // point is that the transition's outcome, not that write, decides the
  // resulting policy.
  // ---------------------------------------------------------------------------
  wire [3:0] reset_pwpr_policy = (
    (DEF_PWR_POLICY == PM_OFF) && (reset_mode == PM_MEM_RET)
  ) ? PM_MEM_RET : DEF_PWR_POLICY;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      // Section 4.1.6 "PCSMMODESTAT", and Table 4-13's second row: when
      // PCSMMODESTAT reports MEM_RET the PPU adopts it as the current mode, and
      // "if the default power policy, DEF_PWR_POLICY, is OFF, sets
      // PPU_PWPR.PWR_POLICY to MEM_RET."
      //
      // Without this the DEF_PWR_POLICY = OFF build would initialise into
      // MEM_RET and then immediately leave for OFF -- Table 4-13 says it should
      // simply stay. The condition is only meaningful when the default is OFF:
      // with a default of ON the PPU is supposed to transition up anyway, so
      // the policy stays ON and the PCSM's reported mode only decides where the
      // journey starts.
      pwpr_policy_q            <= reset_pwpr_policy;
      pwpr_dyn_en_q            <= DEF_PWR_DYN_EN;
      pwpr_lock_en_q           <= 1'b0;
      // Table 5-10: all available DEVREQEN and PWR_DEVACTIVEEN bits reset to 1.
      pwcr_devreqen_q          <= 1'b1;
      pwcr_devactiveen_q       <= 1'b1;
      ptcr_warm_rst_devreqen_q <= WARM_RST_DEVREQEN_CFG;
      funrr_q                  <= 8'h00;
      fulrr_q                  <= 8'h00;
      memrr_q                  <= 8'h00;
      full_ret_del_q           <= 8'h00;
      mem_ret_del_q            <= 8'h00;
      off_del_q                <= 8'h00;
      func_ret_del_q           <= 8'h00;
      mem_off_del_q            <= 8'h00;
      rst_hwstat_dly_q         <= RST_HWSTAT_DLY_CFG;
      iso_clken_dly_q          <= ISO_CLKEN_DLY_CFG;
      clken_rst_dly_q          <= CLKEN_RST_DLY_CFG;
      clken_iso_dly_q          <= CLKEN_ISO_DLY_CFG;
      iso_rst_dly_q            <= ISO_RST_DLY_CFG;
    end else begin
      if (revert_vld) begin
        pwpr_policy_q <= revert_policy;
        pwpr_dyn_en_q <= revert_dyn_en;
      end else if (pwpr_wr && pwpr_wr_ok) begin
        pwpr_policy_q  <= pwpr_wr_policy;
        pwpr_dyn_en_q  <= pwpr_wr_dyn_en;
        pwpr_lock_en_q <= pwpr_wr_lock_en;
      end

      if (wr && wsel_pwcr) begin
        if (wstrb[1]) pwcr_devactiveen_q <= wdata[8];   // [8] PWR_DEVACTIVEEN
        if (wstrb[0]) pwcr_devreqen_q    <= wdata[0];   // [0] DEVREQEN       
      end

      if (wr && wsel_ptcr) begin 
        if(wstrb[0]) ptcr_warm_rst_devreqen_q <= wdata[0];
      end

      // Section 7.1.5 gives each register its own parameter, so a build can have
      // PPU_MEMRR present and PPU_FUNRR reserved.
      if (FUNC_RET_RAM_REG_CFG && wr && wsel_funrr && wstrb[0]) funrr_q <= wdata[7:0];
      if (FULL_RET_RAM_REG_CFG && wr && wsel_fulrr && wstrb[0]) fulrr_q <= wdata[7:0];
      if ( MEM_RET_RAM_REG_CFG && wr && wsel_memrr && wstrb[0]) memrr_q <= wdata[7:0];

      if (PWR_MODE_ENTRY_DEL_CFG) begin
        // PPU_EDTR0[23:16] is LOGIC_RET_DEL: reserved, no LOGIC_RET here.
        if (wr && wsel_edtr0) begin
          if (wstrb[3]) full_ret_del_q <= wdata[31:24];
          if (wstrb[1]) mem_ret_del_q  <= wdata[15:8];
          if (wstrb[0]) off_del_q      <= wdata[7:0];
        end
        if (wr && wsel_edtr1) begin
          if (wstrb[1]) func_ret_del_q <= wdata[15:8];
          if (wstrb[0]) mem_off_del_q  <= wdata[7:0];
        end
      end

      // Section 5.2.21: "When device control delay configuration functionality
      // is not supported this register is read only" -- the fields still exist
      // and still read back their configured defaults, they just cannot move.
      if (SW_DEV_DEL_CFG) begin
        if (wr && wsel_dcdr0) begin
          if (wstrb[2]) rst_hwstat_dly_q <= wdata[23:16];
          if (wstrb[1]) iso_clken_dly_q  <= wdata[15:8];
          if (wstrb[0]) clken_rst_dly_q  <= wdata[7:0];
        end
        if (wr && wsel_dcdr1) begin
          if (wstrb[1]) clken_iso_dly_q <= wdata[15:8];
          if (wstrb[0]) iso_rst_dly_q   <= wdata[7:0];
        end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Read mux. Registered on ren, giving the one-cycle latency the interface
  // promises. Every bit not named here reads as zero, which is what Section
  // 5.2's WI/RAZ rule requires of the reserved fields.
  // ---------------------------------------------------------------------------
  logic [31:0] rdata_next;

  always_comb begin
    // Every case below assigns only the bits its register actually implements,
    // and this default supplies the rest. That is what Section 5.2 asks for --
    // reserved bits read as zero -- and it means each case reads as the
    // register's field table rather than as a concatenation whose padding has
    // to be counted to be checked. A field at [23:16] is written at [23:16].
    rdata_next = 32'h0;
    unique case (1'b1)
      // Table 5-2
      rsel_pwpr: begin
        rdata_next[ 12] = pwpr_lock_en_q;                 // LOCK_EN
        rdata_next[  8] = pwpr_dyn_en_q;                  // PWR_DYN_EN
        rdata_next[3:0] = pwpr_policy_q;                  // PWR_POLICY
      end
      // Table 5-4
      rsel_pwsr: begin
        rdata_next[ 12] = lock_status;                    // LOCK_STATUS
        rdata_next[  8] = pwr_dyn_status;                 // PWR_DYN_STATUS
        rdata_next[3:0] = pwr_status;                     // PWR_STATUS
      end
      // Table 5-5. PWR_DEVACTIVE_STATUS is [10:0], one bit per Q-Channel, so
      // with a single channel only bit 0 exists.
      rsel_disr: begin
        rdata_next[  0] = dev_qactive;                     // PWR_DEVACTIVE_STATUS
      end
      // Table 5-6. Each field is one bit per channel and reflects the PIN, not
      // a decoded meaning -- DEVQACCEPTn is active LOW and reads back that way.
      rsel_misr: begin
        rdata_next[ 16] = dev_qdeny;                       // DEVDENY_STATUS
        rdata_next[  8] = dev_qacceptn;                    // DEVACCEPT_STATUS
        rdata_next[  0] = pcsm_paccept;                    // PCSMPACCEPT_STATUS
      end
      // Table 5-9. PWR_DEVACTIVEEN is [18:8] and DEVREQEN is [7:0]; one
      // Q-Channel means the low bit of each.
      rsel_pwcr: begin
        rdata_next[  8] = pwcr_devactiveen_q;             // PWR_DEVACTIVEEN
        rdata_next[  0] = pwcr_devreqen_q;                // DEVREQEN
      end
      // Table 5-12
      rsel_ptcr: begin
        rdata_next[  0] = ptcr_warm_rst_devreqen_q;       // WARM_RST_DEVREQEN
      end
      // Tables 5-13 to 5-17. These arrive from ppu_irq already masked to the
      // bits this build implements, so they are taken whole.
      rsel_imr : rdata_next = imr;
      rsel_aimr: rdata_next = aimr;
      rsel_isr : rdata_next = isr;
      rsel_aisr: rdata_next = aisr;
      rsel_iesr: rdata_next = iesr;

      // Tables 5-19 to 5-21. Section 7.1.5 gives each its own parameter, so a
      // build can have one present and another reserved.
      rsel_funrr: if (FUNC_RET_RAM_REG_CFG) rdata_next[7:0] = funrr_q;  // FUNC_RET_RAM
      rsel_fulrr: if (FULL_RET_RAM_REG_CFG) rdata_next[7:0] = fulrr_q;  // FULL_RET_RAM
      rsel_memrr: if ( MEM_RET_RAM_REG_CFG) rdata_next[7:0] = memrr_q;  //  MEM_RET_RAM

      // Tables 5-22 and 5-23. PPU_EDTR0[23:16] is LOGIC_RET_DEL, reserved here.
      rsel_edtr0: if (PWR_MODE_ENTRY_DEL_CFG) begin
        rdata_next[31:24] = full_ret_del_q;               // FULL_RET_DEL
        rdata_next[15: 8] = mem_ret_del_q;                // MEM_RET_DEL
        rdata_next[ 7: 0] = off_del_q;                    // OFF_DEL
      end
      rsel_edtr1: if (PWR_MODE_ENTRY_DEL_CFG) begin
        rdata_next[15: 8] = func_ret_del_q;               // FUNC_RET_DEL
        rdata_next[ 7: 0] = mem_off_del_q;                // MEM_OFF_DEL
      end

      // Tables 5-24 and 5-25. Section 5.2.21 makes these read-only rather than
      // absent when SW_DEV_DEL_CFG is 0, so they always read their values back.
      rsel_dcdr0: begin
        rdata_next[23:16] = rst_hwstat_dly_q;             // RST_HWSTAT_DLY
        rdata_next[15: 8] = iso_clken_dly_q;              // ISO_CLKEN_DLY
        rdata_next[ 7: 0] = clken_rst_dly_q;              // CLKEN_RST_DLY
      end
      rsel_dcdr1: begin
        rdata_next[15: 8] = clken_iso_dly_q;              // CLKEN_ISO_DLY
        rdata_next[ 7: 0] = iso_rst_dly_q;                // ISO_RST_DLY
      end

      // Tables 5-26 to 5-29, composed at elaboration.
      rsel_idr0: rdata_next = IDR0_VAL;
      rsel_idr1: rdata_next = IDR1_VAL;
      rsel_iidr: rdata_next = IIDR_VAL;
      rsel_aidr: rdata_next = AIDR_VAL;

      // PPU_UNLK is write-only ("A read always returns 0b0"), PPU_PMER /
      // PPU_STSR / PPU_OPSR are reserved, and any unmapped address reads zero.
      default: ;
    endcase
  end

  // Simultaneous read and write of the SAME register.
  //
  // rdata_next is combinational from the register state, and the write commits
  // on the same edge that captures it, so the read returns the value from
  // BEFORE the write. That is read-before-write, and it is the only ordering
  // that can be stated as a rule: AXI4-Lite orders AW/W/B against AR/R not at
  // all, so a bridge that had both outstanding could not have told which the
  // master intended to happen first anyway.
  //
  // It matters most for the write-1-to-clear registers, where a read
  // concurrent with a clear returns the bits that were just cleared. A driver
  // that reads PPU_ISR to decide what to service, then writes back what it
  // read, is unaffected -- that is a sequence, not a concurrency. A driver
  // issuing both at once gets one stale read, and the clear still happens.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)   rdata <= 32'h0;
    else if (ren) rdata <= rdata_next;
  end

  // ---------------------------------------------------------------------------
  // Configuration outputs
  // ---------------------------------------------------------------------------
  assign pwr_policy        = pwpr_policy_q           ;
  assign pwr_dyn_en        = pwpr_dyn_en_q           ;
  assign lock_en           = pwpr_lock_en_q          ;
  assign devreqen          = pwcr_devreqen_q         ;
  assign devactiveen       = pwcr_devactiveen_q      ;
  assign warm_rst_devreqen = ptcr_warm_rst_devreqen_q;
  assign rst_hwstat_dly    = rst_hwstat_dly_q        ;
  assign iso_clken_dly     = iso_clken_dly_q         ;
  assign clken_rst_dly     = clken_rst_dly_q         ;
  assign clken_iso_dly     = clken_iso_dly_q         ;
  assign iso_rst_dly       = iso_rst_dly_q           ;
  assign off_del           = off_del_q               ;
  assign mem_ret_del       = mem_ret_del_q           ;
  assign full_ret_del      = full_ret_del_q          ;
  assign func_ret_del      = func_ret_del_q          ;
  assign mem_off_del       = mem_off_del_q           ;
  assign funrr             = funrr_q                 ;
  assign fulrr             = fulrr_q                 ;
  assign memrr             = memrr_q                 ;

endmodule
