`timescale 1ns/1ps
//=============================================================================
// ppu_device_ip -- the device the PPU controls
//
// Replaces dummy_workload. That block was a counter with a busy flag: enough
// to negotiate a Q-Channel with, and nothing else. It could not tell FULL_RET
// from MEM_RET, it had no RAM at all, and so PPU_FUNRR/PPU_FULRR/PPU_MEMRR --
// three whole registers of RAM retention configuration -- reached nothing.
// Six of the seven power modes were, below the PCSM, the same thing.
//
// This IP is built so that EVERY mode is distinguishable, by holding three
// classes of state that survive different things:
//
//   u_core   non-retained logic.  Reset by DEVPORESETn & DEVWARMRESETn.
//                                 In PD_DEV, no retention cells.
//   u_ret    retained logic.      Reset by DEVPORESETn & DEVRETRESETn.
//                                 In PD_DEV, covered by set_retention on the
//                                 VDD_RET rail.
//   u_bank   eight SRAM banks.    NOT in PD_DEV at all. Always-on rail, with
//                                 sleep/shutdown pins doing the work.
//
//      mode        u_core     u_ret     bank, cfg=1   bank, cfg=0
//      ON          keep       keep      keep          keep
//      WARM_RST    reset      reset     keep          keep
//      FUNC_RET    keep       keep      keep          LOST
//      MEM_OFF     keep       keep      LOST          LOST
//      FULL_RET    RESET      keep      keep          LOST
//      MEM_RET     corrupt    corrupt   keep          LOST
//      OFF         corrupt    corrupt   LOST          LOST
//
// No two rows are alike. That is the whole design.
//
//-----------------------------------------------------------------------------
// WHY THE RAM IS NOT IN THE SWITCHED DOMAIN
//
// MEM_RET is "Logic OFF, RAM RET" (Table 3-1). If the array sat on SW_LOGIC's
// rail it would be corrupted by -simstate CORRUPT in exactly the mode whose
// definition is that it is not. And a second UPF switch for the RAM would be
// modelling something silicon does not do: a compiled macro is not power-gated
// by the standard-cell rail's switch, it has its own pins.
//
// So the banks stay on the always-on rail and their pins carry the intent:
//
//   sleep_i    = ram_ret && ram_cfg[i]                  contents held, no access
//   shutdown_i = (mode != ON) && !(ram_ret && ram_cfg[i])   contents lost
//
// ram_on/ram_ret are the PCSM's decode of PCSMPSTATE[3:0]; ram_cfg is
// PCSMPSTATE[15:8], which Section 4.1.6 leaves IMPLEMENTATION DEFINED and this
// design defines as one retention enable per bank. A bank whose bit is clear
// is shut down even in FUNC_RET/FULL_RET/MEM_RET -- which is what makes those
// three registers observable for the first time.
//
// Both pins are computed and REGISTERED in ppu_pcsm, not here. That is the one
// thing about this file worth reading twice: decoding them here glitched the
// shutdown pin on every mode change and wiped the retained banks. See
// ppu_pcsm.sv.
//
//-----------------------------------------------------------------------------
// CLOCK AND CROSSINGS
//
// The banks are clocked by the same gated clock as the logic. That is
// deliberate rather than incidental: a macro on an always-on rail whose clock
// is gated with the domain cannot be accessed while the domain is down, so the
// clock gate is a second, independent guarantee on top of the sleep/shutdown
// pins.
//
// bank_sleep/bank_sd are registered in the aon_clk domain and consumed here
// with no synchroniser. They are quasi-static -- they change only as part of a
// PCSM handshake that the PPU has already sequenced the clock and the resets
// around, and the array is inaccessible on both sides of every such change.
// Synchronising them into dclk would add a delay between the PCSM committing a
// state and the array reflecting it, which is the wrong direction: the pins
// should lead the access, not lag it.
//
// The array is never accessible with corrupted controls, and that is
// structural rather than lucky. ram_addr/ram_we/ram_ce originate in PD_DEV and
// cross into these always-on macros, so they are X while the domain is
// unpowered -- but every mode with the logic unpowered (FULL_RET, MEM_RET, OFF)
// has ram_on LOW, which puts every bank in either sleep or shutdown, and
// ppu_ip_sram honours neither a read nor a write in either state.
//=============================================================================

module ppu_device_ip #(
  parameter int unsigned CNT_W = 8,
  parameter int unsigned NBANK = 8,
  parameter int unsigned AW    = 4,
  parameter int unsigned DW    = 32
) (
  input  logic             clk,           // gated device clock
  input  logic             nret_rst_n,    // DEVPORESETn & DEVWARMRESETn, synced
  input  logic             ret_rst_n,     // DEVPORESETn & DEVRETRESETn,  synced

  // ---- Workload stimulus ----
  input  logic             start,
  input  logic [CNT_W-1:0] work_len,
  input  logic             light_work,
  output logic             busy,
  output logic             done,

  // ---- IP command ----
  input  logic [1:0]       ip_cmd,        // 00 idle, 01 fill, 10 verify
  input  logic [7:0]       ip_seed,

  // ---- SRAM macro pins, from the PCSM ----
  // Taken as registered pins rather than decoded here from ram_on/ram_ret/
  // ram_cfg. Decoding them here is what the first version did, and it destroyed
  // the contents of every retained bank on entry to FUNC_RET, FULL_RET and
  // MEM_RET -- the three modes that exist to preserve them. ppu_pcsm carries the
  // full account; the short version is that three separate continuous
  // assignments from one register settle in three separate delta cycles, and
  // the shutdown term is true in between.
  input  logic [NBANK-1:0] bank_sleep,
  input  logic [NBANK-1:0] bank_sd
);

  // ---- RAM ports ----
  logic          ram_ce, ram_we;
  logic [AW-1:0] ram_addr;
  logic [DW-1:0] ram_wdata [NBANK];
  logic [DW-1:0] ram_rdata [NBANK];

  for (genvar b = 0; b < NBANK; b++) begin : g_bank
    ppu_ip_sram #(.AW(AW), .DW(DW)) u_bank (
      .clk     (clk),
      .sleep   (bank_sleep[b]),
      .shutdown(bank_sd[b]),
      .ce      (ram_ce),
      .we      (ram_we),
      .addr    (ram_addr),
      .wdata   (ram_wdata[b]),
      .rdata   (ram_rdata[b])
    );
  end

  // ---- Retained logic ----
  logic          ret_load;
  logic [DW-1:0] ret_sig_in;
  logic [7:0]    ret_seed_q;
  logic [DW-1:0] ret_sig;

  ppu_ip_ret #(.DW(DW)) u_ret (
    .clk   (clk),
    .rst_n (ret_rst_n),
    .load  (ret_load),
    .seed  (ip_seed),
    .sig_in(ret_sig_in),
    .seed_q(ret_seed_q),
    .sig   (ret_sig)
  );

  // ---- Non-retained logic ----
  logic [DW-1:0]    sig_nret;
  logic [NBANK-1:0] ram_bank_ok;
  logic             ip_done;

  ppu_ip_core #(.CNT_W(CNT_W), .NBANK(NBANK), .AW(AW), .DW(DW)) u_core (
    .clk       (clk),
    .rst_n     (nret_rst_n),
    .start     (start),
    .work_len  (work_len),
    .light_work(light_work),
    .busy      (busy),
    .done      (done),
    .ip_cmd    (ip_cmd),
    .ip_seed   (ip_seed),
    .ram_ce    (ram_ce),
    .ram_we    (ram_we),
    .ram_addr  (ram_addr),
    .ram_wdata (ram_wdata),
    .ram_rdata (ram_rdata),
    .ret_load  (ret_load),
    .ret_sig_in(ret_sig_in),
    .sig_nret  (sig_nret),
    .ram_bank_ok(ram_bank_ok),
    .ip_done   (ip_done)
  );

  // sig_nret, ram_bank_ok, ip_done, u_ret.sig and u_ret.seed_q have no RTL
  // consumer on purpose. They are read hierarchically by the testbenches, which
  // is this repository's convention for observability -- see qchannel_pd_top's
  // header for why debug-only ports are not added.

endmodule
