`timescale 1ns/1ps
// PPU power mode sequencer -- the state machine that turns a programmed policy
// into an ordered sequence of Q-Channel, device-control and PCSM operations.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E), Sections 3.3.2, 3.4, 4.1.3, 4.1.5 and 4.2.
//
// This is the only genuinely new design work in the PPU: the two protocol
// engines it drives already exist in this repository (qchannel_controller,
// pchannel_controller) and are instantiated unmodified by ppu_top.
//
// -----------------------------------------------------------------------------
// 1. WHY THERE IS NO TRANSITION TABLE
//
// Section 3.3.2, verbatim: "Although multiple power modes are supported with a
// Q-Channel PPU it only transitions between ON and the power mode programmed in
// the PPU_PWPR register." Every hop therefore has ON at one end, and the graph
// collapses to a single decision:
//
//   target == current             -> nothing to do
//   target and current both != ON -> go to ON first, then to target
//   otherwise                     -> one hop, straight there
//
// with exactly ONE exception, which Section 3.3.2 also names: OFF to MEM_RET,
// "made without going through ON", with no device interface handshake because
// the component is unaware it happened. That exception is one-way. Table 4-14
// lists OFF -> MEM_RET but gives MEM_RET only ON and DBG_RECOV as end modes,
// so MEM_RET -> OFF routes through ON like everything else. (The block's
// README draws that arrow bidirectional; the spec's own transition table is
// the authority followed here.)
//
// -----------------------------------------------------------------------------
// 2. PRIORITY IS THE ENCODING, AND DIRECTION IS THE TARGET
//
// The 4-bit mode encodings are monotonic in priority (see ppu_pkg), so a
// magnitude compare answers "is this a transition to a lower priority mode?".
// But the sequencer does not actually need that compare to choose an ORDER,
// because of point 1: with every hop anchored at ON,
//
//   hop target != ON  ->  leaving ON: quiesce first, then device controls,
//                         then PCSM        (Section 4.1.5, Figure 4-24)
//   hop target == ON  ->  returning to ON: PCSM first, then device controls,
//                         then release quiescence  (Figure 4-22)
//
// That also lands ON -> WARM_RST on the correct path even though WARM_RST is
// HIGHER priority than ON. Figure 4-26 shows it sequenced exactly like a
// departure from ON -- handshake, then assert DEVWARMRESETn -- because what
// decides the order is which end of the hop is ON, not which mode is nominally
// higher up the ladder. A priority compare would have got that case wrong.
//
// -----------------------------------------------------------------------------
// 3. THE DEVICE CONTROL SEQUENCE IS WALKED UNCONDITIONALLY
//
// Section 4.1.5 gives the two orderings, and Table 4-5 gives a minimum cycle
// count between each adjacent pair of changes. This FSM spends those cycles on
// every hop, including hops where a given signal does not actually change
// value -- ON <-> FUNC_RET, for instance, has an identical device-control row,
// so the whole clock/isolation/reset walk is a no-op on the wires.
//
// That is deliberate. The alternative -- skipping steps whose signal is
// already at the target value -- makes the observable timing of a transition
// depend on which pair of modes it connects, which is a far harder property to
// verify than "the sequence is always the same shape". The spec permits it
// either way: Table 4-5 constrains a MINIMUM separation, and a delay inserted
// where nothing changed cannot violate a minimum.
//
// -----------------------------------------------------------------------------
// 4. DENIAL CAN ONLY HAPPEN IN ONE PLACE
//
// A Q-Channel transition to a higher priority power mode cannot be denied, and
// on the departure path the device handshake runs BEFORE any device control
// moves. So by construction the only state that can see DEVQDENY is S_DN_QREQ,
// and at that point not one clock enable, isolation or reset has been touched.
//
// The un-deniability is a PPU-spec statement, Section 4.2.9: "Q-Channel PPU
// transitions to higher priority power modes, except for those to warm reset,
// cannot be denied." The same section shows the opposite for the other channel
// type: Figure 4-36 is a P-Channel PPU being denied on FULL_RET -> ON. What
// makes it true here is AMBA LPI (ARM IHI 0068C) Table 2-1: Q_DENIED is
// reachable only from Q_REQUEST, and the exit path Q_STOPPED -> Q_EXIT ->
// Q_RUN has no denial state at all, so a device cannot refuse to come back up.
// Since every return to ON is an exit handshake, no up-transition other than
// ON -> WARM_RST is deniable.
//
// The consequence is worth stating plainly because it reads like a missing
// feature otherwise: Section 4.1.1's "reverse whatever device controls were
// already sequenced" has nothing to reverse in this ordering. What the denial
// path below actually does is the other half of that section -- revert the
// policy per Table 4-1, raise the denial event, and wait for the Q-Channel to
// finish its own Q_DENIED -> Q_CONTINUE -> Q_RUN recovery before declaring the
// sequencer idle again.
//
// -----------------------------------------------------------------------------
// 5. QACTIVE IS THE PPU'S TO ACT ON, NOT THE Q-CHANNEL CONTROLLER'S
//
// qchannel_controller can be told to leave Q_STOPPED by itself when QACTIVE
// rises (its enb_qactive_led_quiescence_exit input, the Figure 2-8 policy).
// ppu_top deliberately ties that OFF and routes QACTIVE here instead.
//
// The reason is a protocol violation waiting to happen. In a PPU the domain
// behind the Q-Channel may be genuinely unpowered, and AMBA LPI Section 2.1.2
// only permits power to be absent in Q_STOPPED. If the controller un-quiesced
// on its own, the interface would leave Q_STOPPED while the supply is still
// off and the PCSM has not been asked for anything. Routing QACTIVE into the
// policy instead makes it a wake REQUEST: the sequencer restores the PCSM
// state and the device controls first, and only then releases quiescence. That
// is what "dynamic transition" means in Section 3.4.3, and it is the same
// sequencing obligation src/upf/README.md flags as needing a PPU to discharge.

import ppu_pkg::*;

module ppu_seq #(
  parameter bit OFF_MEM_RET_TRANS_CFG  = 1'b1,
  parameter bit LOCK_CFG               = 1'b1,
  parameter bit PWR_MODE_ENTRY_DEL_CFG = 1'b1,
  // Which modes this build supports, from the Table 7-1 parameters. Only the
  // lock needs it here: a mode the build does not have cannot be locked in.
  parameter logic [15:0] STA_MASK      = 16'h03E5
) (
  input logic clk,
  input logic rst_n,

  // The mode the PPU is in at reset release, before any transition. Section
  // 4.1.6 "PCSMMODESTAT": OFF or MEM_RET only, and "only sampled by the PPU at
  // reset release" -- which is why it is an input read inside the reset branch
  // rather than a parameter. ppu_top derives it from the PCSMMODESTAT pins.
  input logic [3:0] reset_mode,

  // ---- PPU_PWPR: the policy the sequencer is chasing ----
  input logic [3:0] pwr_policy,
  input logic       pwr_dyn_en,
  input logic       lock_en   ,

  // ---- Single-cycle pulses: PPU_UNLK written, PPU_PWPR accepted ----
  input logic unlock_wr,
  input logic policy_wr,

  // ---- PPU_PWCR / PPU_PTCR: per-transition channel and DEVACTIVE enables ----
  input logic devreqen         ,
  input logic devactiveen      ,
  input logic warm_rst_devreqen,

  // ---- PPU_DCDR0 / PPU_DCDR1: device control delays (Table 4-5) ----
  input logic [7:0] rst_hwstat_dly,
  input logic [7:0] iso_clken_dly ,
  input logic [7:0] clken_rst_dly ,
  input logic [7:0] clken_iso_dly ,
  input logic [7:0] iso_rst_dly   ,

  // ---- PPU_EDTR0 / PPU_EDTR1: per-mode entry delays ----
  input logic [7:0] off_del     ,
  input logic [7:0] mem_ret_del ,
  input logic [7:0] full_ret_del,
  input logic [7:0] func_ret_del,
  input logic [7:0] mem_off_del ,

  // ---- Retention RAM configuration, forwarded into PCSMPSTATE ----
  input logic [7:0] funrr,
  input logic [7:0] fulrr,
  input logic [7:0] memrr,

  // ---- Status back to the register file ----

  // ---- PPU_PWSR ----
  output logic [3:0] pwr_status    ,
  output logic       pwr_dyn_status,
  output logic       lock_status   ,

  // ---- Section 4.1.1 denial revert: the sequencer overrides PPU_PWPR ----
  output logic       revert_vld   ,
  output logic [3:0] revert_policy,
  output logic       revert_dyn_en,

  // ---- Interrupt events, single-cycle pulses ----
  output logic ev_sta_policy_trn,
  output logic ev_sta_accept    ,
  output logic ev_sta_deny      ,
  output logic ev_dyn_accept    ,
  output logic ev_dyn_deny      ,
  output logic ev_locked        ,

  // ---- Device interface Q-Channel, via qchannel_controller ----
  output logic req_dev_quiescence,
  input  logic dev_stopped       ,  // controller reports Q_STOPPED
  input  logic dev_q_run         ,  // interface decoded as Q_RUN (see ppu_top)
  input  logic dev_qdeny          ,  // synchronized DEVQDENY
  input  logic dev_qactive        ,  // synchronized DEVQACTIVE

  // ---- PCSM P-Channel, via pchannel_controller ----
  //
  // Completion is read off pcsm_cur_state, not off the controller's xfer_done
  // pulse. The two fire on the same edge -- pchannel_controller commits
  // cur_state and pulses xfer_done together -- but only the state is a LEVEL,
  // and a level cannot be missed. Waiting on the pulse instead is what the
  // first version of this file did, and it had a real bug: on the completing
  // cycle "the PCSM is already where I want it" is ALSO true, so whichever
  // branch tested that first won and the request was left asserted, firing the
  // next transition's PCSM handshake early. Deriving both the exit and the
  // request from one expression makes that class of skew impossible.
  output logic [15:0] pcsm_req_state,
  output logic        pcsm_req_valid,
  input  logic [15:0] pcsm_cur_state,
  input  logic        pcsm_init_done,

  // ---- Device control outputs (Section 6.4) ----
  output logic [15:0] ppuhwstat    ,
  output logic        dev_clken     ,
  output logic        dev_isolaten  ,
  output logic        dev_poresetn  ,
  output logic        dev_warmresetn,
  output logic        dev_retresetn ,

  // ---- "This PPU needs its clock" ----
  //
  // Not a specification signal: DEN 0051E Table 6-1 gives the PPU one clock and
  // one reset and says nothing about gating either. It is the device-internal
  // condition behind the CLOCK Q-Channel that Arm's own PPU implementation adds
  // on top of the architecture (PCK-600 Table A-29, ppuclk_*), exported here
  // rather than re-derived in ppu_top because the three terms are all sequencer
  // state and only the sequencer knows they are complete.
  //
  // AMBA LPI Section 4.1.1 is the rule it implements: a device with a clock
  // Q-Channel alongside another interface must keep QACTIVE asserted whenever
  // "CLK must be active to perform the management actions in the device that
  // are required before the power state transition, and to respond on the power
  // control interface".
  //
  // Three terms, and each one is a way for the PPU to have work outstanding:
  //
  //   state != S_IDLE   a transition is in flight -- including S_DELAY, where
  //                     the entry-delay counter is running and needs edges
  //   hop_needed        a transition is DUE but has not started. This is the
  //                     term that carries a wake: hop_tgt is combinational in
  //                     qactive_eff, so DEVQACTIVE rising under a dynamic
  //                     policy makes hop_needed rise with no clock at all
  //   !pcsm_init_done   the reset-time PCSM handshake (Section 4.1.6) has not
  //                     finished, so the PPU has start-up work. This is what
  //                     makes the signal HIGH out of reset, which is what AMBA
  //                     LPI Section 2.1.2 "Device reset" asks of a device that
  //                     "must perform start-up operations on exit from reset"
  //
  // Everything else the PPU does begins with a register write, and a register
  // write is announced by PWAKEUP -- see ppu_top.
  output logic        ppu_active
);

  // ---------------------------------------------------------------------------
  // States. The two ordered walks of Section 4.1.5 are spelled out as separate
  // state chains rather than one shared chain with a direction flag: the two
  // orders are reverses of each other only in the signal names, not in what
  // each step waits for, and merging them would hide that.
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    S_IDLE,        // at pwr_status, nothing in flight
    S_DELAY,       // power mode entry delay timer (Section 4.1.3)
    S_DN_QREQ,     // leaving ON: quiesce the device, watch for denial
    S_DN_CLKEN,    // de-assert clock enables, wait CLKEN_ISO_DLY
    S_DN_ISO,      // assert isolation, wait ISO_RST_DLY
    S_DN_RST,      // assert resets
    S_DN_PCSM,     // PCSM handshake into the target state
    S_UP_PCSM,     // returning to ON: PCSM handshake first
    S_UP_ISO,      // de-assert isolation, wait ISO_CLKEN_DLY
    S_UP_CLKEN,    // assert clock enables, wait CLKEN_RST_DLY
    S_UP_RST,      // de-assert resets, release quiescence, wait RST_HWSTAT_DLY
    S_PCSM_ONLY,   // OFF -> MEM_RET: PCSM handshake and nothing else
    S_DENIED       // device denied; let the Q-Channel recover, then revert
  } ppu_state_e;

  ppu_state_e state;

  logic [3:0] cur_mode;      // == pwr_status
  logic [3:0] hop_q;         // the hop currently being executed
  logic [7:0] cnt;
  logic       dyn_status_q;
  logic       locked_q;
  logic       dev_hs_q;      // this hop uses the device interface handshake
  logic       req_quiesce_q;
  logic       init_pending;  // the post-reset default transition (no interrupts)
  logic       dyn_en_at_start;
  logic       policy_wr_d;

  // Section 4.1.2's third full-policy-completion condition needs to know
  // whether PPU_PWPR was written WHILE a transition was in flight, and what
  // was written -- not what the register holds afterwards, because a denial
  // reverts it (Table 4-1). pwr_policy one cycle after the write is the value
  // software asked for, before any reversion, which is what last_wr_policy
  // captures.
  logic       pol_wr_in_trans;
  logic [3:0] last_wr_policy;

  // ---------------------------------------------------------------------------
  // Target selection
  // ---------------------------------------------------------------------------
  // Section 4.1.3 "DEVACTIVE Enables": a disabled DEVACTIVE input "is always
  // assumed to be LOW for the purposes of transition control".
  logic qactive_eff;
  assign qactive_eff = dev_qactive && devactiveen;

  // DEVQACTIVE GATES BOTH KINDS OF TRANSITION, NOT JUST DYNAMIC ONES.
  //
  // Section 3.4.3, dynamic: the programmed policy is a MINIMUM -- all enabled
  // DEVQACTIVE LOW while in ON starts a move down to the policy, any
  // DEVQACTIVE HIGH while in the policy mode starts a move back to ON. Both
  // directions collapse into one expression, which also behaves correctly if
  // the PPU is sitting in some third mode when dynamic transitions are enabled.
  //
  // Section 3.4.2, STATIC, "Static Power Mode Transitions with a Q-Channel
  // PPU", verbatim: "For transitions from ON, other than to WARM_RST, all
  // DEVQACTIVE inputs must be LOW to begin a transition." And immediately
  // before it: "Transitions to lower priority power modes are delayed until the
  // relevant power mode DEVACTIVE inputs are LOW."
  //
  // That is a genuinely different rule from the dynamic one and it is easy to
  // miss, because the two look alike from a distance:
  //
  //   dynamic  DEVQACTIVE HIGH means "climb to ON"     -- it sets the target
  //   static   DEVQACTIVE HIGH means "do not leave ON" -- it only BLOCKS, and
  //            never drags the PPU upward, because a static policy is a target
  //            rather than a minimum
  //
  // So the static term below holds the PPU in ON rather than retargeting it,
  // and it is the reason the same section says "The power mode DEVACTIVE inputs
  // do not delay transitions to higher priority power modes" -- climbing is
  // never gated either way.
  //
  // WARM_RST is exempt in both directions: "For transitions between ON and
  // WARM_RST there is no dependence on the DEVQACTIVE inputs."
  //
  // Section 3.4.3 "Lock": while locked the PPU "remains in that power mode
  // until it is unlocked... even if the DEVACTIVE inputs, or software set
  // minimum policy, are requesting a higher priority power mode", so the lock
  // sits on top of everything else.
  // The gate is on the DIRECTION OF THE POLICY, not on the current mode, and
  // that distinction is the whole rule. Section 3.4.2:
  //
  //   "Transitions to lower priority power modes are delayed until the relevant
  //    power mode DEVACTIVE inputs are LOW. This is true even if the PPU must go
  //    through an intermediate power mode to reach the programmed policy.
  //    ... a component in FULL_RET cannot make a direct transition to OFF, it
  //    must pass through ON. However, all power mode DEVACTIVE inputs between
  //    FULL_RET and OFF must be LOW BEFORE THE PPU BEGINS THE INTERMEDIATE
  //    TRANSITION TO ON."
  //
  // Gating on `cur_mode == PM_ON` implements only the last hop of that and lets
  // the intermediate one through, which produces the opposite of what a static
  // policy means: from FULL_RET with policy OFF and DEVQACTIVE HIGH, the PPU
  // climbs to ON -- powering up and releasing reset on the whole domain -- and
  // then parks there, because the gate only engages once it has arrived. A
  // static request for OFF must never leave the domain fully ON. Section 3.3.1
  // is explicit that raising the mode on hardware signalling is what DYNAMIC
  // transitions are for; under a static policy DEVQACTIVE may only ever hold a
  // transition back, never cause one.
  //
  // Because the mode encodings are monotonic in priority (Table 3-2),
  // `pwr_policy < cur_mode` is exactly "the policy asks to go down".
  //
  // WARM_RST is exempt in BOTH directions: "For transitions between ON and
  // WARM_RST there is no dependence on the DEVQACTIVE inputs." Testing only
  // `pwr_policy != PM_WARM_RST` would cover ON -> WARM_RST but not the return,
  // where cur_mode is WARM_RST(9) and the policy is ON(8) -- a numerical
  // decrease that is not a power-down at all.
  logic warm_rst_pair, sta_block;
  assign warm_rst_pair = (cur_mode == PM_WARM_RST) || (pwr_policy == PM_WARM_RST);
  assign sta_block     = qactive_eff && (pwr_policy < cur_mode) && !warm_rst_pair;

  // THE WRITE-TIME LOCK HOLDS FROM THE WRITE ITSELF.
  //
  // Section 3.4.3, "Locking the PPU": the PPU is locked when "The PPU_PWPR is
  // written with LOCK_EN and PWR_DYN_EN set to 0b1 and" it "is in a lockable
  // power mode"; "LOCK_EN and PWR_DYN_EN do not need to have been 0b1 before
  // the write." A locked PPU may make only the two _EMU transitions the section
  // lists, and neither is built here.
  //
  // locked_q is a register, so it holds the lock from the cycle AFTER the
  // write. The same write may also ask for a different mode, and this S_IDLE
  // cycle is where that hop would be launched -- measured, from MEM_RET a single
  // {OFF, PWR_DYN_EN, LOCK_EN} write started the climb to ON on the edge that
  // set locked_q, and the PPU ended locked in ON (ppu_pd_tb P36). This term is
  // the same set condition as the lock block's write branch, available
  // combinationally, so the hop sees the lock on the write's own cycle.
  logic lock_on_write;
  assign lock_on_write = LOCK_CFG && lock_en && pwr_dyn_en && !unlock_wr
                      && policy_wr_d && (state == S_IDLE)
                      && ppu_mode_lockable(STA_MASK, cur_mode);

  logic [3:0] final_tgt;
  always_comb begin
    if (locked_q || lock_on_write) final_tgt = cur_mode;
    else if (dyn_status_q) final_tgt = qactive_eff ? PM_ON : pwr_policy;
    else if (sta_block)    final_tgt = cur_mode;   // held where it is
    else                   final_tgt = pwr_policy;
  end

  // The single Section 3.3.2 exception: OFF -> MEM_RET direct, one way.
  logic direct_off_to_mem_ret;
  assign direct_off_to_mem_ret = OFF_MEM_RET_TRANS_CFG
                              && (cur_mode  == PM_OFF)
                              && (final_tgt == PM_MEM_RET);

  // The ON-anchored hop, per point 1 in the header.
  logic [3:0] hop_tgt;
  always_comb begin
    if (final_tgt == cur_mode)                          hop_tgt = cur_mode;
    else if (direct_off_to_mem_ret)                     hop_tgt = PM_MEM_RET;
    else if ((cur_mode != PM_ON) && (final_tgt != PM_ON)) hop_tgt = PM_ON;
    else                                                hop_tgt = final_tgt;
  end

  logic hop_needed;
  assign hop_needed = (hop_tgt != cur_mode);

  // See the port declaration for what each term is and why it is here.
  assign ppu_active = (state != S_IDLE) || hop_needed || !pcsm_init_done;

  // Table 4-4: the device interface handshake for ON <-> WARM_RST has its own
  // enable on top of the per-channel one, so that components with no WARM_RST
  // support can still be warm reset by the PPU.
  logic warm_rst_hop, dev_hs_for_hop;
  assign warm_rst_hop   = (hop_tgt == PM_WARM_RST) || (cur_mode == PM_WARM_RST);
  assign dev_hs_for_hop = devreqen && (warm_rst_hop ? warm_rst_devreqen : 1'b1);

  // ---------------------------------------------------------------------------
  // Power mode entry delay (Section 4.1.3)
  //
  // "These delays apply for transitions to a lower priority power mode" -- so
  // this is the one place the priority compare genuinely matters, and it is
  // also why ON -> WARM_RST gets no delay despite being a departure from ON:
  // WARM_RST is higher priority, and PPU_EDTR0/1 has no field for it.
  // ---------------------------------------------------------------------------
  logic [7:0] entry_delay;
  always_comb begin
    case (hop_tgt)
      PM_OFF:      entry_delay = off_del;
      PM_MEM_RET:  entry_delay = mem_ret_del;
      PM_FULL_RET: entry_delay = full_ret_del;
      PM_MEM_OFF:  entry_delay = mem_off_del;
      PM_FUNC_RET: entry_delay = func_ret_del;
      default:     entry_delay = 8'h00;
    endcase
  end

  logic use_entry_delay;
  assign use_entry_delay = PWR_MODE_ENTRY_DEL_CFG
                        && hop_needed
                        && (hop_tgt < cur_mode)
                        && ppu_mode_has_entry_delay(hop_tgt)
                        && (entry_delay != 8'h00);

  // ---------------------------------------------------------------------------
  // PCSM target state (Section 4.1.6)
  //
  //   [15:8] RAM retention configuration, IMPLEMENTATION DEFINED (Sections
  //          5.2.16-18) and passed through opaquely -- the PPU attaches no
  //          meaning to these bits, it only routes the register belonging to
  //          the mode being entered
  //   [7:4]  operating mode: permanently 0, none exist here
  //   [3:0]  power mode, with WARM_RST mapped to ON (Table 3-2 footnote a)
  // ---------------------------------------------------------------------------
  logic [7:0]  hop_ram_cfg;
  logic [15:0] hop_pcsm_state;
  logic        pcsm_needed;

  always_comb begin
    case (hop_q)
      PM_FUNC_RET: hop_ram_cfg = funrr;
      PM_FULL_RET: hop_ram_cfg = fulrr;
      PM_MEM_RET:  hop_ram_cfg = memrr;
      default:     hop_ram_cfg = 8'h00;
    endcase
  end

  assign hop_pcsm_state = {hop_ram_cfg, 4'h0, ppu_pcsm_mode(hop_q)};
  // ON <-> WARM_RST lands here as "not needed": both map to the same PCSM
  // state, so there is no request to make and the state is skipped entirely.
  assign pcsm_needed    = (hop_pcsm_state != pcsm_cur_state);

  assign pcsm_req_state = hop_pcsm_state;

  // ---------------------------------------------------------------------------
  // Device control values for the mode being entered, and for the mode the PPU
  // sits in at reset release.
  // ---------------------------------------------------------------------------
  logic [4:0] dc_tgt, dc_reset;
  assign dc_tgt   = ppu_devctl(hop_q);
  assign dc_reset = ppu_devctl(reset_mode);

  // ---------------------------------------------------------------------------
  // Sequencer
  // ---------------------------------------------------------------------------
  logic commit_dn, commit_up, commit_direct;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state         <= S_IDLE;
      cur_mode      <= reset_mode;
      hop_q         <= reset_mode;
      cnt           <= 8'h00;
      dyn_status_q  <= 1'b0;
      locked_q      <= 1'b0;
      dev_hs_q      <= 1'b0;
      init_pending  <= 1'b1;
      dyn_en_at_start <= 1'b0;
      policy_wr_d   <= 1'b0;
      pol_wr_in_trans <= 1'b0;
      last_wr_policy  <= reset_mode;

      // The device is held quiesced out of reset whenever the domain starts in
      // a mode below ON. AMBA LPI Section 2.1.2 permits power to be absent only
      // in Q_STOPPED, and reset_mode is OFF or MEM_RET -- both unpowered -- so
      // anything else would have the interface claim the domain is running
      // while its supply is off. qchannel_controller resets into Q_STOPPED with
      // QREQn LOW, and holding the request keeps it there until this sequencer
      // has restored the PCSM state and the device controls.
      req_quiesce_q <= (reset_mode != PM_ON);

      ppuhwstat     <= ppu_hwstat(reset_mode);
      dev_poresetn   <= dc_reset[DC_PORESETN];
      dev_warmresetn <= dc_reset[DC_WARMRESETN];
      dev_retresetn  <= dc_reset[DC_RETRESETN];
      dev_clken      <= dc_reset[DC_CLKEN];
      dev_isolaten   <= dc_reset[DC_ISOLATEN];

      pcsm_req_valid <= 1'b0;
      revert_vld     <= 1'b0;

      ev_sta_policy_trn <= 1'b0;
      ev_sta_accept     <= 1'b0;
      ev_sta_deny       <= 1'b0;
      ev_dyn_accept     <= 1'b0;
      ev_dyn_deny       <= 1'b0;
      ev_locked         <= 1'b0;
    end else begin
      // All of these are single-cycle pulses.
      ev_sta_policy_trn <= 1'b0;
      ev_sta_accept     <= 1'b0;
      ev_sta_deny       <= 1'b0;
      ev_dyn_accept     <= 1'b0;
      ev_dyn_deny       <= 1'b0;
      ev_locked         <= 1'b0;
      revert_vld        <= 1'b0;
      policy_wr_d       <= policy_wr;

      // A write is "during the transition" if the sequencer was not idle when
      // it landed. A write that STARTS a transition is therefore not counted,
      // which is right: Section 4.1.2's first condition already covers that
      // case separately.
      if (policy_wr_d) begin
        last_wr_policy <= pwr_policy;
        if (state != S_IDLE) pol_wr_in_trans <= 1'b1;
      end

      // ---- Lock (Section 3.4.3) ----
      // Unlock is evaluated every cycle and wins over the set conditions
      // below: "The PPU is unlocked when any of the following conditions
      // occur:" -- "Software writes a one to the PPU_UNLK.UNLOCK bit." and
      // "Either the PPU_PWPR.LOCK_EN, or the PPU_PWPR.PWR_DYN_EN, is set to
      // 0b0."
      //
      // The set condition fires on the COMMIT edge rather than on the first
      // idle cycle afterwards, and the difference is load-bearing: locking is
      // only interesting when dynamic transitions are enabled, and a dynamic
      // PPU that has just arrived in OFF is exactly the PPU that would start
      // climbing back out on a DEVQACTIVE the very next cycle. Setting the
      // lock one cycle late would let that escape happen before the lock it
      // exists to prevent could take effect.
      //
      // The write branch is lock_on_write, the term final_tgt also reads, so
      // the lock this sets and the hop it suppresses cannot disagree.
      if (LOCK_CFG && !(unlock_wr || !lock_en || !pwr_dyn_en)) begin
        if (!locked_q
            && ((commit_dn || commit_up || commit_direct)
                  ? ppu_mode_lockable(STA_MASK, hop_q)
                  : lock_on_write)) begin
          // The two reachable spec conditions: arriving in a lockable mode,
          // and PPU_PWPR being written with both enables set while already
          // sitting in one. The third listed condition -- "a transition from
          // one of the lockable power modes is denied" -- cannot occur on this
          // PPU: leaving OFF or MEM_RET always means a hop UP to ON, and per
          // AMBA LPI Table 2-1 the exit handshake has no denial state, so an
          // up-transition cannot be refused. See header point 4.
          locked_q  <= 1'b1;
          ev_locked <= !init_pending;
        end
      end else if (LOCK_CFG) begin
        locked_q <= 1'b0;
      end

      unique case (state)
        // ---------------------------------------------------------------------
        S_IDLE: begin
          // Section 3.4.3: a change to PWR_DYN_EN only takes effect once any
          // in-flight transition has finished, and PWR_DYN_STATUS is what
          // reports when that has happened.
          dyn_status_q    <= pwr_dyn_en;
          pol_wr_in_trans <= 1'b0;

          // ...but NOT on the cycle a denial reversion is being applied.
          //
          // revert_vld is asserted on the same edge that moves S_DENIED to
          // S_IDLE, so on the very next edge this state evaluates while
          // ppu_regs is still writing the reverted value into PPU_PWPR. Without
          // this guard pwr_policy is read one cycle stale -- it still holds the
          // policy that was just DENIED -- and the sequencer immediately
          // re-launches the transition Section 4.1.1 had just reverted.
          //
          // It is not self-correcting. hop_q is latched here, and no departure
          // state re-checks it (only S_DELAY does, and use_entry_delay is false
          // whenever the entry delay is 0, which is its reset value). So if the
          // device happens to accept the second time, the domain walks all the
          // way down to a mode software never asked for and then climbs back:
          // measured as ON -> OFF -> ON after a single denied request.
          //
          // One cycle of delay costs nothing. The reverted policy equals
          // cur_mode by construction, so the hop this guard suppresses is one
          // that will not be needed a cycle later anyway.
          if (hop_needed && pcsm_init_done && !revert_vld) begin
            hop_q    <= hop_tgt;
            dev_hs_q <= dev_hs_for_hop;
            dyn_en_at_start <= pwr_dyn_en;

            if (use_entry_delay) begin
              cnt   <= entry_delay;
              state <= S_DELAY;
            end else if (direct_off_to_mem_ret) begin
              pcsm_req_valid <= 1'b1;
              state          <= S_PCSM_ONLY;
            end else if (hop_tgt == PM_ON) begin
              state <= S_UP_PCSM;
            end else begin
              req_quiesce_q <= dev_hs_for_hop;
              state         <= S_DN_QREQ;
            end
          end else if (!hop_needed) begin
            // Section 4.2.1: the post-reset default transition "does not
            // generate an interrupt event when it completes" -- and if the
            // default policy needs no transition at all, there is nothing to
            // suppress, so ordinary event reporting starts immediately.
            init_pending <= 1'b0;

            // Section 4.1.2 "Full Policy Transition Completion", first bullet:
            // the event also fires "Following the write of a supported policy
            // to PPU_PWPR when the PPU is not in transition, and both
            // PPU_PWPR.PWR_DYN_EN and the PPU_PWPR.OP_DYN_EN are set to 0b0",
            // and the mode already matches. policy_wr_d rather than policy_wr
            // because pwr_policy only carries the new value from the next cycle.
            //
            // The REGISTER, pwr_dyn_en, not the status. dyn_status_q takes the
            // written enable on this same edge, so here it still holds the value
            // from before the write, and testing it gave the wrong answer for
            // exactly the writes that flip PWR_DYN_EN (ppu_pd_tb P35). There are
            // no operating modes, so OP_DYN_EN is 0 by construction (the note at
            // the end of the same list).
            if (policy_wr_d && !pwr_dyn_en && !init_pending
                && (pwr_policy == cur_mode)) begin
              ev_sta_policy_trn <= 1'b1;
            end
          end
        end

        // ---------------------------------------------------------------------
        // Entry delay. Section 4.1.3: "If, while the entry delay timer is
        // counting, conditions change such that the transition being counted
        // should no longer take place, then the counter is reset." Leaving for
        // S_IDLE does exactly that -- the counter is reloaded from scratch if
        // and when the conditions come back.
        S_DELAY: begin
          if (!hop_needed || (hop_tgt != hop_q)) begin
            state <= S_IDLE;
          end else if (cnt == 8'h00) begin
            req_quiesce_q <= dev_hs_q;
            state         <= S_DN_QREQ;
          end else begin
            cnt <= cnt - 8'h01;
          end
        end

        // ---------------------------------------------------------------------
        // Departure from ON: quiesce first (Section 4.1.5), and the only state
        // in the whole FSM that can be denied (header point 4).
        S_DN_QREQ: begin
          if (!dev_hs_q) begin
            cnt   <= clken_iso_dly;
            state <= S_DN_CLKEN;
            dev_clken <= dc_tgt[DC_CLKEN];
          end else if (dev_qdeny) begin
            req_quiesce_q <= 1'b0;
            state         <= S_DENIED;
          end else if (dev_stopped) begin
            cnt      <= clken_iso_dly;
            dev_clken <= dc_tgt[DC_CLKEN];
            state    <= S_DN_CLKEN;
          end
        end

        S_DN_CLKEN: begin
          if (cnt == 8'h00) begin
            dev_isolaten <= dc_tgt[DC_ISOLATEN];
            cnt         <= iso_rst_dly;
            state       <= S_DN_ISO;
          end else begin
            cnt <= cnt - 8'h01;
          end
        end

        S_DN_ISO: begin
          if (cnt == 8'h00) begin
            dev_poresetn   <= dc_tgt[DC_PORESETN];
            dev_warmresetn <= dc_tgt[DC_WARMRESETN];
            dev_retresetn  <= dc_tgt[DC_RETRESETN];
            state         <= S_DN_RST;
          end else begin
            cnt <= cnt - 8'h01;
          end
        end

        S_DN_RST: begin
          if (pcsm_needed) begin
            pcsm_req_valid <= 1'b1;
            state          <= S_DN_PCSM;
          end else begin
            // ON -> WARM_RST arrives here: the PCSM is told to hold the same
            // conditions as ON, so there is no handshake to run.
            state <= S_IDLE;
          end
        end

        S_DN_PCSM: begin
          if (!pcsm_needed) begin
            pcsm_req_valid <= 1'b0;
            state          <= S_IDLE;
          end
        end

        // ---------------------------------------------------------------------
        // Return to ON: PCSM first, then device controls, then release
        // quiescence (Section 4.1.5, Figure 4-22).
        S_UP_PCSM: begin
          if (!pcsm_needed) begin
            pcsm_req_valid <= 1'b0;
            dev_isolaten    <= dc_tgt[DC_ISOLATEN];
            cnt            <= iso_clken_dly;
            state          <= S_UP_ISO;
          end else begin
            pcsm_req_valid <= 1'b1;
          end
        end

        S_UP_ISO: begin
          if (cnt == 8'h00) begin
            dev_clken <= dc_tgt[DC_CLKEN];
            cnt      <= clken_rst_dly;
            state    <= S_UP_CLKEN;
          end else begin
            cnt <= cnt - 8'h01;
          end
        end

        S_UP_CLKEN: begin
          if (cnt == 8'h00) begin
            dev_poresetn   <= dc_tgt[DC_PORESETN];
            dev_warmresetn <= dc_tgt[DC_WARMRESETN];
            dev_retresetn  <= dc_tgt[DC_RETRESETN];
            cnt           <= rst_hwstat_dly;
            // Release quiescence on the same edge the resets come off: the
            // device interface handshake and RST_HWSTAT_DLY run concurrently,
            // and Table 4-5 makes the HWSTAT update wait for both ("This delay
            // is also dependant on the completion of the device interface").
            req_quiesce_q <= 1'b0;
            state         <= S_UP_RST;
          end else begin
            cnt <= cnt - 8'h01;
          end
        end

        S_UP_RST: begin
          if (cnt != 8'h00) begin
            cnt <= cnt - 8'h01;
          end else if (!dev_hs_q || dev_q_run) begin
            state <= S_IDLE;
          end
        end

        // ---------------------------------------------------------------------
        // OFF -> MEM_RET (Section 4.2.6): "it only needs to complete a PCSM
        // handshake. There is no change in conditions of the reset, isolation
        // and clock enable and no device interface handshake as the logic is
        // off in both power modes." Nothing below touches a device control,
        // and req_quiesce_q is deliberately left as it is -- the device stays
        // quiesced across the hop and never learns it happened.
        S_PCSM_ONLY: begin
          if (!pcsm_needed) begin
            pcsm_req_valid <= 1'b0;
            state          <= S_IDLE;
          end
        end

        // ---------------------------------------------------------------------
        // Denial (Sections 4.1.1, 4.2.9). qchannel_controller drives its own
        // Q_DENIED -> Q_CONTINUE -> Q_RUN recovery once the request is
        // withdrawn; waiting for Q_RUN here stops the sequencer re-requesting
        // into the middle of that recovery.
        S_DENIED: begin
          if (dev_q_run) begin
            if (dyn_status_q) ev_dyn_deny <= !init_pending;
            else              ev_sta_deny <= !init_pending;

            // Table 4-1: with PWR_DYN_STATUS LOW the power policy reverts to
            // the mode in PPU_PWSR; with it HIGH nothing is reverted, because
            // the policy is only a minimum and the DEVACTIVE inputs, not the
            // register, are driving the transition.
            // Only the strobe is registered; see the note on revert_policy
            // below for why the VALUES are not.
            if (!dyn_status_q) begin
              revert_vld <= 1'b1;

              // Section 4.1.2, third full-policy-completion condition: the
              // event ALSO fires when "a denied transition completes with both
              // PPU_PWSR.PWR_DYN_STATUS and PPU_PWSR.OP_DYN_STATUS set to 0b0"
              // and "PPU_PWPR is written during the transition" and "the last
              // power and operating policies written match the current power
              // and operating modes."
              //
              // It reads oddly until you see what it is for: software asked for
              // a mode, changed its mind mid-flight to the mode the PPU is
              // already in, and the original request was then refused. The
              // outcome is exactly what software last asked for, so it is told
              // its policy has been reached -- even though the only transition
              // that ran was denied. Without this the write would be
              // acknowledged by nothing at all.
              if (pol_wr_in_trans && (last_wr_policy == cur_mode))
                ev_sta_policy_trn <= !init_pending;
            end
            state <= S_IDLE;
          end
        end

        default: state <= S_IDLE;
      endcase

      // ---- Commit ----
      // Kept out of the case above so that the mode update, the PPUHWSTAT
      // update and the completion events are written in exactly one place for
      // all three completion paths, rather than three times over.
      if (commit_dn || commit_up || commit_direct) begin
        cur_mode  <= hop_q;
        ppuhwstat <= ppu_hwstat(hop_q);

        // Section 4.1.2 "Static Transition Acceptance": "This event occurs when
        // a static transition is accepted AND COMPLETED. This includes the
        // completion of intermediate transitions", with the worked example
        // making the per-hop firing explicit -- FULL_RET to OFF via ON raises it
        // twice, once on reaching ON and once on reaching OFF.
        //
        // So it belongs HERE, at the commit, and not where an earlier version
        // put it: on the device handshake being accepted. Two things were wrong
        // with that. It fired on the departure path BEFORE the device controls
        // and the PCSM handshake had run, so "completed" was not yet true; and
        // it was gated on a handshake existing, so a hop with none -- the
        // OFF -> MEM_RET direct path, or any hop with DEVREQEN cleared --
        // produced no event at all, though the spec says the event is "for ALL
        // completed static transitions".
        //
        // Table 4-2 selects which of the two events fires: static when
        // PWR_DYN_STATUS is LOW, dynamic when it is HIGH.
        if (!init_pending) begin
          if (dyn_status_q) ev_dyn_accept <= 1'b1;
          else              ev_sta_accept <= 1'b1;
        end

        if (init_pending) begin
          // Section 4.2.1: the default transition out of reset is silent.
          init_pending <= 1'b0;
        end else if ((hop_q == pwr_policy) && (!dyn_status_q || !pwr_dyn_en)) begin
          // Section 4.1.2: the completion event fires when the mode matches
          // the PROGRAMMED POLICY, "even when this takes more than one
          // transition" -- so an intermediate hop through ON completes
          // silently (hop_q != pwr_policy) and only the final one reports.
          //
          // The dynamic term covers TWO of the section's conditions at once:
          //
          //   !dyn_status_q               an accepted static transition
          //                               (second condition)
          //   dyn_status_q && !pwr_dyn_en fourth condition -- "any transition
          //                               completes with PWR_DYN_STATUS set to
          //                               0b1, but PWR_DYN_EN is set to 0b0",
          //                               i.e. software switched the PPU back
          //                               to a static policy WHILE the dynamic
          //                               transition was in flight. Since
          //                               PWR_DYN_STATUS only updates in
          //                               S_IDLE, that is precisely the state
          //                               the two bits are in at this commit.
          //
          // A genuinely dynamic transition (both bits set) reports through
          // DYN_ACCEPT instead, per Table 4-2.
          //
          // There is only ONE completion event here. The power-policy and
          // operating-policy split events are unsupported when operating modes
          // are not supported (Section 4.1.2), and with no operating modes the
          // power-policy event would carry exactly this event's information.
          ev_sta_policy_trn <= 1'b1;
        end
      end
    end
  end

  // The three points at which a hop is finished. Written as combinational
  // decodes of the state being LEFT so the commit block above stays a single
  // assignment set.
  assign commit_dn     = (state == S_DN_RST) && !pcsm_needed;
  assign commit_up     = (state == S_UP_RST) && (cnt == 8'h00)
                                             && (!dev_hs_q || dev_q_run);
  assign commit_direct = ((state == S_DN_PCSM) || (state == S_PCSM_ONLY))
                                             && !pcsm_needed;

  assign pwr_status     = cur_mode;
  assign pwr_dyn_status = dyn_status_q;
  assign lock_status    = locked_q;

  // The reversion VALUES are combinational while revert_vld is registered, and
  // the asymmetry is deliberate. Registering both means ppu_regs samples the
  // values on the same edge that sets the strobe -- so it sees whatever they
  // held BEFORE the denial, not the mode being reverted to. Section 4.1.1 says
  // the policy reverts "to the current mode as shown in the Power Status
  // Register", and cur_mode is exactly that register's contents; it cannot
  // change during a denial, because a denial is the reason no mode change
  // happened. Same argument for the dynamic enable, whose pre-transition value
  // was latched when the transition began.
  assign revert_policy  = cur_mode;
  assign revert_dyn_en  = dyn_en_at_start;

  // Section 4.1.3 "Device Interface Channel Enables": when a Q-Channel is
  // disabled "DEVQREQn is driven permanently HIGH", i.e. no quiescence is ever
  // requested on it. Applying devreqen here rather than inside the FSM means
  // the FSM never has to remember the enable state, and clearing the enable
  // mid-flight cannot leave a stale request asserted.
  assign req_dev_quiescence = req_quiesce_q && devreqen;

endmodule
