`timescale 1ns/1ps
// A power domain reached through an access control gate.
//
// Reference: Arm PCSA (DEN 0050 D) Sections 4.2.10 and 7.2.8; Arm PPU
// Architecture Specification v1.1 (ARM DEN 0051E) Sections 4.1.3, 4.1.5, 4.1.6.
//
//   TL-UL host (always powered)                   PD_DEV (can power off)
//       tl_h2d_i --->  [ acg_tlul ]  --->  [ acg_resp_tlul ]
//       tl_d2h_o <---                <---
//                           ^
//                       Q-Channel  <--- ppu_top's DEVQREQn
//
// This is PCSA Section 7.2's AON relationship -- "One domain is always powered,
// whilst the other can power-off" -- which is the simplest of the three it
// defines and the one that needs no LPC. The RAON and Independent cases need
// two switched domains and two PPUs.
//
// -----------------------------------------------------------------------------
// WHAT THIS DEMONSTRATES THAT NOTHING ELSE DOES
//
// PCSA 4.2.10 permits a memory system to be powered off underneath a live
// requester, on one condition:
//
//   "it is possible for the memory system to be powered-off when agents that
//    require its availability are active, provided those requests trigger a
//    mechanism that allows the transaction to be completed transparently."
//
// Everything in this file exists to make that one sentence true and testable:
// a transaction arrives at a domain that has no power, is stalled rather than
// failed, raises DEVQACTIVE, the PPU restores the domain autonomously, and the
// transaction then completes. No software anywhere on that path.
//
// -----------------------------------------------------------------------------
// NO LPD-Q HERE, AND THE EARLIER PLAN SAID THERE WOULD BE
//
// The plan for this file had a qchannel_lpd fanning DEVQREQn out to the gate
// and to the responder, in sequencer mode, so the gate closed first. It is not
// here because acg_resp_tlul has no Q-Channel: it is a memory, with no activity
// to report and nothing to quiesce beyond what the gate already guarantees.
// Once the gate has drained and is blocking, the responder is idle BY
// CONSTRUCTION.
//
// One LPI endpoint means the PPU drives it directly. An LPD-Q would appear the
// moment this domain gained a second thing with its own Q-Channel -- a DMA
// engine, say -- and ppu_lpd_pd_top already shows that shape.
//
// -----------------------------------------------------------------------------
// CLOCKS
//
// The gate runs on the UNGATED dclk and the responder on the gated one. They
// share a TL-UL bus, which is synchronous, so that looks like a violation and
// is not: the gate only passes traffic when it is open, and it is only open
// when the domain is powered and clocked. DEVCLKEN is dropped after the
// Q-Channel accepts, which is after the drain, so no response is ever owed by a
// responder whose clock has stopped.
//
// The gate must stay clocked while the domain is down, because a stalled
// transaction has to be able to raise QACTIVE. That is the same reasoning PCSA
// 7.2.8 gives for its placement: "any wake-up logic must always be implemented
// in the upstream power domain".

import ppu_pkg::*;
import tlul_pkg::*;

module ppu_acg_pd_top #(
  parameter int unsigned SYNC_STAGES = 2,
  parameter int unsigned RESP_MODEL  = 0,    // 0 = stall and wake
  parameter int unsigned Outstanding = 8,
  parameter logic [3:0]  DEF_PWR_POLICY = PM_ON,
  parameter logic [3:0]  PCSM_RESET_MODESTAT = PM_OFF,
  parameter bit          PGOOD_EN    = 1'b0
) (
  input  logic aon_clk,
  input  logic aon_rst_n,

  // ---- Section 6.2 software interface ----
  input  logic [11:0] reg_waddr,
  input  logic [31:0] reg_wdata,
  input  logic        reg_wen,
  input  logic [3:0]  reg_wstrb,
  input  logic [11:0] reg_raddr,
  input  logic        reg_ren,
  output logic [31:0] reg_rdata,
  output logic        irq,

  input  logic dclk,

  // ---- TL-UL, host side. The requester stays powered. ----
  input  tl_h2d_t tl_h2d_i,
  output tl_d2h_t tl_d2h_o,

  // ---- Observability ----
  output logic acg_gated,
  output logic acg_err,
  output logic dev_qactive_o
);

  logic dev_qreqn, dev_qacceptn, dev_qdeny, dev_qactive;
  logic dev_clken, dev_isolaten, dev_poresetn, dev_warmresetn, dev_retresetn;
  logic pcsm_preq, pcsm_paccept;
  logic [15:0] pcsm_pstate;
  logic [7:0]  pcsm_modestat;

  logic logic_on, logic_ret, ram_on, ram_ret, ret_n;
  logic [7:0] ram_cfg, ram_sleep, ram_sd;
  logic [3:0] pcsm_mode;

  // Switch acknowledges. See ppu_pd_top for the PGOOD_EN contract. Declared
  // here because u_pcsm above consumes them.
  logic pg_logic, pg_ret;

  logic dummy_clk, dev_clken_dclk;
  logic wl_rst_n, wl_ret_rst_n, wrap_rst_n;

  tl_h2d_t tl_h2d_dev;
  tl_d2h_t tl_d2h_dev;

  assign dev_qactive_o = dev_qactive;

  ppu_top #(
    .DEF_PWR_POLICY     (DEF_PWR_POLICY),
    .SYNC_STAGES        (SYNC_STAGES),
    .PCSM_RESET_MODESTAT(PCSM_RESET_MODESTAT)
  ) u_ppu (
    .clk(aon_clk), .rst_n(aon_rst_n),
    .reg_waddr(reg_waddr), .reg_wdata(reg_wdata), .reg_wen(reg_wen),
    .reg_wstrb(reg_wstrb), .reg_raddr(reg_raddr), .reg_ren(reg_ren),
    .reg_rdata(reg_rdata), .irq(irq),

    // The single device Q-Channel goes to the GATE.
    .dev_qreqn(dev_qreqn), .dev_qacceptn(dev_qacceptn),
    .dev_qdeny(dev_qdeny), .dev_qactive(dev_qactive),

    .dev_clken(dev_clken), .dev_isolaten(dev_isolaten),
    .dev_poresetn(dev_poresetn), .dev_warmresetn(dev_warmresetn),
    .dev_retresetn(dev_retresetn),

    .pcsm_pstate(pcsm_pstate), .pcsm_preq(pcsm_preq),
    .pcsm_paccept(pcsm_paccept), .pcsm_modestat(pcsm_modestat),

    .ppuclk_qreqn(1'b1), .ppuclk_qacceptn(), .ppuclk_qdeny(), .ppuclk_qactive(),
    .pwakeup(1'b0), .ppuhwstat()
  );

  // ---- The gate. In PD_AON, protecting PD_DEV. ----
  acg_tlul #(
    .RESP_MODEL (RESP_MODEL),
    .SYNC_STAGES(SYNC_STAGES),
    .Outstanding(Outstanding)
  ) u_acg (
    .clk(dclk), .rst_n(wrap_rst_n),
    .qreqn(dev_qreqn), .qacceptn(dev_qacceptn),
    .qdeny(dev_qdeny), .qactive(dev_qactive),
    .tl_h2d_i(tl_h2d_i), .tl_d2h_o(tl_d2h_o),
    .tl_h2d_o(tl_h2d_dev), .tl_d2h_i(tl_d2h_dev),
    // D21's run-time mode stays DEFAULT here: RESP_MODEL alone, as before
    .mode_i(2'd0), .err_valid_o(), .err_addr_o(), .err_source_o(),
    .err_write_o(), .err_overflow_o(), .err_clr_i(1'b0),
    .gated_o(acg_gated), .gate_err_o(acg_err)
  );

  ppu_pcsm #(
    .SYNC_STAGES(0), .TINIT(4),
    .RESET_MODESTAT(PCSM_RESET_MODESTAT), .PGOOD_EN(PGOOD_EN)
  ) u_pcsm (
    .clk(aon_clk), .rst_n(aon_rst_n),
    .pcsm_pstate(pcsm_pstate), .pcsm_preq(pcsm_preq), .pcsm_paccept(pcsm_paccept),
    .ack_logic_on(pg_logic), .ack_logic_ret(pg_ret),
    .logic_on(logic_on), .logic_ret(logic_ret),
    .ram_on(ram_on), .ram_ret(ram_ret), .ram_cfg(ram_cfg),
    .pcsm_mode(pcsm_mode), .ram_sleep(ram_sleep), .ram_sd(ram_sd),
    .ret_n(ret_n), .pcsm_modestat(pcsm_modestat)
  );

  generate
    if (!PGOOD_EN) begin : g_pgood_tie
      assign pg_logic = logic_on;
      assign pg_ret   = logic_ret;
    end
  endgenerate

  // ---- Domain clock and resets ----
  rst_sync u_wrap_rst (.clk(dclk), .rst_in_n(aon_rst_n), .rst_out_n(wrap_rst_n));

  cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_clken_sync (.clk(dclk), .rst_n(wrap_rst_n), .d(dev_clken), .q(dev_clken_dclk));

  clk_gate u_clkctrl (.clk(dclk), .clk_en(dev_clken_dclk), .gated_clk(dummy_clk));

  logic dev_rst_in_n, dev_ret_rst_in_n;
  assign dev_rst_in_n     = dev_poresetn & dev_warmresetn;
  assign dev_ret_rst_in_n = dev_poresetn & dev_retresetn;

  rst_sync u_wl_rst  (.clk(dclk), .rst_in_n(dev_rst_in_n),     .rst_out_n(wl_rst_n));
  rst_sync u_ret_rst (.clk(dclk), .rst_in_n(dev_ret_rst_in_n), .rst_out_n(wl_ret_rst_n));

  // ---- The protected responder, in PD_DEV ----
  acg_resp_tlul u_resp (
    .clk      (dummy_clk),
    .rst_n    (wl_rst_n),
    .ret_rst_n(wl_ret_rst_n),
    .rsp_delay(8'd0),
    .tl_h2d_i (tl_h2d_dev),
    .tl_d2h_o (tl_d2h_dev)
  );

  wire _unused_ok = &{1'b0, ram_on, ram_ret, ram_cfg, ram_sleep, ram_sd,
                      pcsm_mode, ret_n, dev_isolaten, 1'b0};

endmodule
