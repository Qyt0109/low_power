`timescale 1ns/1ps
// PPU package: power-mode encodings, per-mode device-control table, PCSMPSTATE
// and PPUHWSTAT encodings, and the register-map offsets.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E). Section references below are to that document.
//
// This PPU is a SINGLE-Q-CHANNEL PPU (DEVCHAN_CFG = 1) with no operating
// modes, so everything P-Channel-specific is architecturally absent rather
// than merely unimplemented: LOGIC_RET and DBG_RECOV cannot exist here
// (Table 5-26 marks their support bits "Always set to 0b0 for a Q-Channel
// PPU"), and the emulation modes OFF_EMU / MEM_RET_EMU are not built. Their
// encodings are still declared below, because the decode has to RECOGNISE
// them in order to reject them: programming one is an unsupported policy
// (Section 4.1.1 "Programming Unsupported Policies"), which is a defined
// behaviour with its own interrupt event, not a don't-care.
//
// PRIORITY ORDER IS THE ENCODING ORDER. Table 3-2 lists the modes from
// WARM_RST (highest priority) down to OFF (lowest), and their 4-bit encodings
// happen to be monotonic in exactly that order:
//
//   OFF(0) < MEM_RET(2) < FULL_RET(5) < MEM_OFF(6) < FUNC_RET(7) < ON(8) < WARM_RST(9)
//
// so "is this transition to a lower priority mode?" is a plain magnitude
// compare on the encoding. That is a property of the spec's numbering, not a
// coincidence this package invented, and it is the reason no separate priority
// lookup table exists here.

package ppu_pkg;

  // ---------------------------------------------------------------------------
  // Power mode values (Table 3-2)
  // ---------------------------------------------------------------------------
  localparam logic [3:0] PM_OFF         = 4'd0;
  localparam logic [3:0] PM_OFF_EMU     = 4'd1;   // emulation: not built
  localparam logic [3:0] PM_MEM_RET     = 4'd2;
  localparam logic [3:0] PM_MEM_RET_EMU = 4'd3;   // emulation: not built
  localparam logic [3:0] PM_LOGIC_RET   = 4'd4;   // P-Channel only: cannot exist
  localparam logic [3:0] PM_FULL_RET    = 4'd5;
  localparam logic [3:0] PM_MEM_OFF     = 4'd6;
  localparam logic [3:0] PM_FUNC_RET    = 4'd7;
  localparam logic [3:0] PM_ON          = 4'd8;
  localparam logic [3:0] PM_WARM_RST    = 4'd9;
  localparam logic [3:0] PM_DBG_RECOV   = 4'd10;  // P-Channel only: cannot exist

  // ---------------------------------------------------------------------------
  // Supported-policy decode (Section 4.1.1 "Programming Unsupported Policies")
  //
  // "Whether a policy is supported is a combination of the policy setting and
  // the dynamic enables" -- so support is a function of BOTH the mode and
  // PWR_DYN_EN, not of the mode alone. WARM_RST is the case that makes the
  // distinction real here: it is a supported static policy and an unsupported
  // dynamic one, because Section 3.4.3 excludes it from dynamic transitions on
  // a Q-Channel PPU ("Dynamic transitions to and from this power mode are not
  // supported for a Q-Channel PPU"), which is also why PPU_IDR0.DYN_WRM_RST_SPT
  // is hard-wired 0.
  // ---------------------------------------------------------------------------
  // ---------------------------------------------------------------------------
  // Mode support, as a mask rather than a hardwired list
  // ---------------------------------------------------------------------------
  // Section 7.1.7 and Tables 7-1 and 7-4 make mode support a per-mode
  // configuration choice, one parameter per mode for static support and another
  // per mode for dynamic. These used to be two hardwired case statements, which
  // meant the seven modes this build happens to want were the only seven it
  // could ever have.
  //
  // The masks are indexed by the mode encoding itself, which works because
  // Table 3-2's encodings are dense enough to use directly as a bit position and
  // is the same trick PPUHWSTAT uses.
  function automatic bit ppu_mode_spt(input logic [15:0] mask, input logic [3:0] m);
    return mask[m];
  endfunction

  // Section 7.1.7: "The ON, OFF and WARM_RST power modes are always supported,
  // then the PPU can optionally support additional power modes." So those three
  // are not parameters; the other four are.
  function automatic logic [15:0] ppu_sta_mask(input bit func_ret_spt,
                                               input bit mem_off_spt,
                                               input bit full_ret_spt,
                                               input bit mem_ret_spt);
    logic [15:0] v;
    v            = 16'h0000;
    v[PM_ON]     = 1'b1;
    v[PM_OFF]    = 1'b1;
    v[PM_WARM_RST] = 1'b1;
    v[PM_FUNC_RET] = func_ret_spt;
    v[PM_MEM_OFF]  = mem_off_spt;
    v[PM_FULL_RET] = full_ret_spt;
    v[PM_MEM_RET]  = mem_ret_spt;
    return v;
  endfunction

  // Table 7-4 lists the dynamic-support parameters available to a Q-Channel PPU.
  // WARM_RST is deliberately absent: DYN_WRM_RST_SPT_CFG is in Table 7-5, which
  // is P-Channel only, and Section 3.4.3 says dynamic transitions to and from
  // WARM_RST are not supported for a Q-Channel PPU. There is no parameter for it
  // because there is no configuration in which it could be 1.
  function automatic logic [15:0] ppu_dyn_mask(input bit on_spt,
                                               input bit func_ret_spt,
                                               input bit mem_off_spt,
                                               input bit full_ret_spt,
                                               input bit mem_ret_spt,
                                               input bit off_spt);
    logic [15:0] v;
    v              = 16'h0000;
    v[PM_ON]       = on_spt;
    v[PM_FUNC_RET] = func_ret_spt;
    v[PM_MEM_OFF]  = mem_off_spt;
    v[PM_FULL_RET] = full_ret_spt;
    v[PM_MEM_RET]  = mem_ret_spt;
    v[PM_OFF]      = off_spt;
    return v;
  endfunction

  // Section 4.1.1: support is a joint property of the policy and the dynamic
  // enable, so the same encoding can be accepted one way and refused the other.
  function automatic bit ppu_policy_spt(input logic [15:0] sta_mask,
                                        input logic [15:0] dyn_mask,
                                        input logic [3:0]  m,
                                        input bit          dyn_en);
    return dyn_en ? dyn_mask[m] : sta_mask[m];
  endfunction

  // Section 3.4.3 lists OFF, OFF_EMU, MEM_RET and MEM_RET_EMU as lockable. A
  // mode the build does not support cannot be locked in, so the mask gates it --
  // otherwise a PPU built without MEM_RET would still claim MEM_RET is lockable.
  function automatic bit ppu_mode_lockable(input logic [15:0] sta_mask,
                                           input logic [3:0] m);
    return ((m == PM_OFF) || (m == PM_MEM_RET)) && sta_mask[m];
  endfunction

  // Human-readable name, for logging.

  // ---------------------------------------------------------------------------
  // PPUHWSTAT (Section 4.1.4, Table 3-2)
  //
  // One-hot over the mode encoding: bit N is set for mode N. Spec-exact bit
  // positions are kept rather than repacked to the 7 modes this PPU has, so a
  // consumer written against the full encoding works unmodified. Bits 1, 3, 4
  // and 10 are therefore permanently 0 here -- the modes they name cannot be
  // entered.
  // ---------------------------------------------------------------------------
  function automatic logic [15:0] ppu_hwstat(input logic [3:0] m);
    logic [15:0] v;
    v = '0;
    v[m] = 1'b1;
    return v;
  endfunction

  // ---------------------------------------------------------------------------
  // PCSMPSTATE[3:0] (Section 4.1.6, Table 3-2)
  //
  // Identical to the mode encoding except for WARM_RST: Table 3-2 footnote a
  // has the PPU instruct the PCSM to hold the same conditions as ON, because
  // the PCSM has no notion of warm reset -- only the device interface does.
  // That single substitution is what makes ON <-> WARM_RST a transition with
  // NO PCSM handshake at all (Figure 4-26): the requested PCSM state does not
  // change, so there is nothing to request.
  // ---------------------------------------------------------------------------
  function automatic logic [3:0] ppu_pcsm_mode(input logic [3:0] m);
    // Table 3-2 footnote a: "In these power modes the PPU instructs the PCSM to
    // have the same conditions as ON." It marks FOUR modes, not one --
    // DBG_RECOV, WARM_RST, MEM_RET_EMU and OFF_EMU -- and all four are listed
    // with PCSMPSTATE[3:0] = 0b1000.
    //
    // Only WARM_RST is reachable here, because ppu_mode_static_spt accepts just
    // the seven modes this PPU builds, so the other three can never be a hop
    // target. Transcribing the whole footnote anyway is deliberate: the two
    // emulation modes exist precisely to reproduce the FUNCTIONAL conditions of
    // OFF and MEM_RET *without removing power*, so passing them through
    // unmapped would encode 0b0001 / 0b0011 and tell the PCSM to remove the
    // very power the mode exists to keep. That is the failure the footnote is
    // there to prevent, and it would arrive silently the day emulation modes
    // were added.
    return ((m == PM_WARM_RST) || (m == PM_DBG_RECOV)
         || (m == PM_MEM_RET_EMU) || (m == PM_OFF_EMU)) ? PM_ON : m;
  endfunction

  // ---------------------------------------------------------------------------
  // Device controls per power mode (Tables 4-7, 4-9, 4-11)
  //
  //   Power Mode   DEVPORESETn  DEVWARMRESETn  DEVRETRESETn  DEVCLKEN  DEVISOLATEn
  //   WARM_RST          1             0              0           1          1
  //   ON                1             1              1           1          1
  //   FUNC_RET          1             1              1           1          1
  //   MEM_OFF           1             1              1           1          1
  //   FULL_RET          1             0              1           0          0
  //   MEM_RET           0             0              0           0          0
  //   OFF               0             0              0           0          0
  //
  // All resets active LOW, clock enable and isolation active HIGH (Sections
  // 6.1, 6.4).
  //
  // The two rows that assert exactly one of the warm resets are the ones worth
  // reading twice, because they are near-opposites and easy to transcribe into
  // each other. Table 4-8 gives the distinction:
  //
  //   DEVWARMRESETn  "warm reset for NON-RETENTION registers"
  //   DEVRETRESETn   "warm reset for RETENTION registers"
  //
  // so FULL_RET asserts DEVWARMRESETn only -- the non-retained logic resets
  // while retained registers stay live on the retention supply -- and
  // WARM_RST asserts BOTH, because a warm reset of the component resets all of
  // its state, retained included. Table 4-9 groups WARM_RST with the emulation
  // modes at {1, 0, 0} for exactly that reason. Getting WARM_RST's
  // DEVRETRESETn wrong is silent: the component comes out of a warm reset with
  // its retention registers never reset, which no purely functional check on
  // this design would notice.
  //
  // MEM_RET and OFF assert everything because the logic is unpowered in both
  // -- they differ only in what the PCSM does to the RAM.
  //
  // The values are returned as one packed vector so the sequencer can drive
  // all five from a single table lookup and a reader can see the whole row at
  // once. Bit order matches the table columns left to right.
  // ---------------------------------------------------------------------------
  localparam int unsigned DC_PORESETN   = 4;
  localparam int unsigned DC_WARMRESETN = 3;
  localparam int unsigned DC_RETRESETN  = 2;
  localparam int unsigned DC_CLKEN      = 1;
  localparam int unsigned DC_ISOLATEN   = 0;

  function automatic logic [4:0] ppu_devctl(input logic [3:0] m);
    case (m)
      //                    PORESETn WARMRESETn RETRESETn CLKEN ISOLATEn
      PM_WARM_RST: return {  1'b1,     1'b0,     1'b0,    1'b1,  1'b1 };
      PM_ON:       return {  1'b1,     1'b1,     1'b1,    1'b1,  1'b1 };
      PM_FUNC_RET: return {  1'b1,     1'b1,     1'b1,    1'b1,  1'b1 };
      PM_MEM_OFF:  return {  1'b1,     1'b1,     1'b1,    1'b1,  1'b1 };
      PM_FULL_RET: return {  1'b1,     1'b0,     1'b1,    1'b0,  1'b0 };
      PM_MEM_RET:  return {  1'b0,     1'b0,     1'b0,    1'b0,  1'b0 };
      PM_OFF:      return {  1'b0,     1'b0,     1'b0,    1'b0,  1'b0 };
      // Unreachable: the policy decode above rejects every other value before
      // it can become a target. Fall back to the safest row (everything off).
      default:     return {  1'b0,     1'b0,     1'b0,    1'b0,  1'b0 };
    endcase
  endfunction

  // Modes with a power mode entry delay value (PPU_EDTR0/1). Section 4.1.3
  // "Power Mode Entry Delay Timers": the delays "apply for transitions to a
  // lower priority power mode", so ON and WARM_RST have no delay field --
  // WARM_RST is higher priority than ON, and ON is only ever entered from
  // below.
  function automatic bit ppu_mode_has_entry_delay(input logic [3:0] m);
    case (m)
      PM_OFF, PM_MEM_RET, PM_FULL_RET, PM_MEM_OFF, PM_FUNC_RET: return 1'b1;
      default:                                                  return 1'b0;
    endcase
  endfunction

  // Lockable power modes (Section 3.4.3 "Lock"): OFF and MEM_RET, plus their
  // emulated counterparts which this PPU does not build.

  // Human-readable name, for logging.
  function automatic string ppu_mode_name(input logic [3:0] m);
    case (m)
      PM_OFF:         return "OFF";
      PM_OFF_EMU:     return "OFF_EMU";
      PM_MEM_RET:     return "MEM_RET";
      PM_MEM_RET_EMU: return "MEM_RET_EMU";
      PM_LOGIC_RET:   return "LOGIC_RET";
      PM_FULL_RET:    return "FULL_RET";
      PM_MEM_OFF:     return "MEM_OFF";
      PM_FUNC_RET:    return "FUNC_RET";
      PM_ON:          return "ON";
      PM_WARM_RST:    return "WARM_RST";
      PM_DBG_RECOV:   return "DBG_RECOV";
      default:        return "RESERVED";
    endcase
  endfunction

  // ---------------------------------------------------------------------------
  // Register map offsets (Table 5-1)
  //
  // Registers that are reserved BY CONSTRUCTION for a single-Q-Channel,
  // no-operating-mode PPU are listed too, so the decoder can name what it is
  // deliberately not implementing rather than letting the address fall into a
  // default arm indistinguishable from a typo:
  //
  //   PPU_PMER  emulation modes not built
  //   PPU_STSR  Section 5.2.6: "For a Q-Channel PPU with a single Q-Channel
  //             this register is reserved" -- with one channel, DEVQDENY
  //             identifies itself
  //   PPU_OPSR  operating modes are P-Channel only (Section 5.2.15)
  // ---------------------------------------------------------------------------
  localparam logic [11:0] A_PWPR  = 12'h000;
  localparam logic [11:0] A_PMER  = 12'h004;  // reserved here
  localparam logic [11:0] A_PWSR  = 12'h008;
  localparam logic [11:0] A_DISR  = 12'h010;
  localparam logic [11:0] A_MISR  = 12'h014;
  localparam logic [11:0] A_STSR  = 12'h018;  // reserved here
  localparam logic [11:0] A_UNLK  = 12'h01C;
  localparam logic [11:0] A_PWCR  = 12'h020;
  localparam logic [11:0] A_PTCR  = 12'h024;
  localparam logic [11:0] A_IMR   = 12'h030;
  localparam logic [11:0] A_AIMR  = 12'h034;
  localparam logic [11:0] A_ISR   = 12'h038;
  localparam logic [11:0] A_AISR  = 12'h03C;
  localparam logic [11:0] A_IESR  = 12'h040;
  localparam logic [11:0] A_OPSR  = 12'h044;  // reserved here
  localparam logic [11:0] A_FUNRR = 12'h050;
  localparam logic [11:0] A_FULRR = 12'h054;
  localparam logic [11:0] A_MEMRR = 12'h058;
  localparam logic [11:0] A_EDTR0 = 12'h160;
  localparam logic [11:0] A_EDTR1 = 12'h164;
  localparam logic [11:0] A_DCDR0 = 12'h170;
  localparam logic [11:0] A_DCDR1 = 12'h174;
  localparam logic [11:0] A_IDR0  = 12'hFB0;
  localparam logic [11:0] A_IDR1  = 12'hFB4;
  localparam logic [11:0] A_IIDR  = 12'hFC8;
  localparam logic [11:0] A_AIDR  = 12'hFCC;

  // ---------------------------------------------------------------------------
  // Interrupt bit positions
  //
  // PPU_ISR / PPU_IMR (Tables 5-15, 5-13). Only channel 0 exists, so the
  // PWR_ACTIVE_EDGE_IRQ field [18:8] collapses to its bit 8.
  // ---------------------------------------------------------------------------
  localparam int unsigned ISR_PWR_ACTIVE_EDGE = 8;
  localparam int unsigned ISR_OTHER           = 7;
  localparam int unsigned ISR_LOCKED          = 5;
  localparam int unsigned ISR_STA_DENY        = 2;
  localparam int unsigned ISR_STA_ACCEPT      = 1;
  localparam int unsigned ISR_STA_POLICY_TRN  = 0;

  // PPU_AISR / PPU_AIMR (Tables 5-16, 5-14).
  // Both policy-completion-split events are reserved here. Section 4.1.2:
  // "The power policy and operating policy transition completion events are
  // optional. They are NOT SUPPORTED WHEN OPERATING MODES ARE NOT SUPPORTED."
  // With no operating modes the power-policy event would be an exact duplicate
  // of STA_POLICY_TRN, which is presumably why the spec removes it rather than
  // leaving software two ways to learn the same thing. The bit positions are
  // still named so the decoder can show what it is deliberately not building.
  localparam int unsigned AISR_STA_POLICY_OP  = 4;   // reserved: no operating modes
  localparam int unsigned AISR_STA_POLICY_PWR = 3;   // reserved: ditto (Section 4.1.2)
  localparam int unsigned AISR_DYN_DENY       = 2;
  localparam int unsigned AISR_DYN_ACCEPT     = 1;
  localparam int unsigned AISR_UNSPT_POLICY   = 0;

  // PPU_IESR DEVACTIVE00_EDGE encoding (Table 5-17).
  localparam logic [1:0] EDGE_NONE = 2'b00;
  localparam logic [1:0] EDGE_RISE = 2'b01;
  localparam logic [1:0] EDGE_FALL = 2'b10;
  localparam logic [1:0] EDGE_BOTH = 2'b11;

endpackage
