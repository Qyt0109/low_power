`timescale 1ns/1ps
//=============================================================================
// ppu_ip_core -- the device IP's NON-RETAINED logic
//
// Everything in here is reset by DEVPORESETn & DEVWARMRESETn and carries no
// retention cells, so it is the counterpart to ppu_ip_ret: the two blocks
// exist to be told apart. See that file for the per-mode reset table.
//
// It does three jobs.
//
// 1. THE WORKLOAD, which is what the Q-Channel is negotiating about. On a
//    rising start it counts work_len gated clocks with busy HIGH, so the
//    device cannot be quiesced mid-burst; light_work runs the same burst
//    without raising busy, which is how a testbench gets a transition to
//    happen while work is still in flight. Held state survives clock gating,
//    because that is the point of clock gating.
//
// 2. THE RAM SEQUENCER, which gives the memory something to hold. FILL writes
//    a pattern derived from the seed to every word of every bank; VERIFY reads
//    them all back and reports per-bank whether the contents survived.
//
//    All eight banks are driven in parallel -- one address counter, eight
//    data ports -- so a fill or a verify is 16 clocks rather than 128. That
//    matters because these run inside testbench phases that also have to
//    complete a mode transition.
//
// 3. sig_nret, one register whose only purpose is to be readable afterwards.
//    Together with ppu_ip_ret.sig and ram_bank_ok it makes every power mode
//    produce a different observable result:
//
//      mode        sig_nret   ret.sig   bank with cfg=1   bank with cfg=0
//      ON          keep       keep      keep              keep
//      WARM_RST    reset      reset     keep              keep
//      FUNC_RET    keep       keep      keep              LOST
//      MEM_OFF     keep       keep      LOST              LOST
//      FULL_RET    RESET      keep      keep              LOST
//      MEM_RET     corrupt    corrupt   keep              LOST
//      OFF         corrupt    corrupt   LOST              LOST
//
//    "corrupt" rather than "reset" in the last two rows because there the
//    supply is gone: under power-aware simulation those registers read X, and
//    under plain simulation they read their reset value. Both are distinct
//    from FULL_RET, which is the row the whole arrangement exists to isolate.
//
// WHY VERIFY USES THE SEED FROM THE PORT, NOT THE RETAINED COPY
//
// ppu_ip_ret holds a seed too, but VERIFY deliberately compares against the
// seed presented on the input. Otherwise a mode that lost the retained seed
// (MEM_RET, OFF) would make every bank fail the comparison for a reason that
// has nothing to do with the RAM, and the RAM result would stop being an
// independent measurement of the RAM.
//=============================================================================

module ppu_ip_core #(
  parameter int unsigned CNT_W  = 8,
  parameter int unsigned NBANK  = 8,
  parameter int unsigned AW     = 4,
  parameter int unsigned DW     = 32
) (
  input  logic             clk,          // gated device clock
  input  logic             rst_n,        // DEVPORESETn & DEVWARMRESETn, synced

  // ---- Workload ----
  input  logic             start,
  input  logic [CNT_W-1:0] work_len,
  input  logic             light_work,
  output logic             busy,
  output logic             done,

  // ---- IP command ----
  input  logic [1:0]       ip_cmd,       // see IP_CMD_* below
  input  logic [7:0]       ip_seed,

  // ---- RAM ports (one set, broadcast to all banks) ----
  output logic             ram_ce,
  output logic             ram_we,
  output logic [AW-1:0]    ram_addr,
  output logic [DW-1:0]    ram_wdata [NBANK],
  input  logic [DW-1:0]    ram_rdata [NBANK],

  // ---- Retained-block interface ----
  output logic             ret_load,
  output logic [DW-1:0]    ret_sig_in,

  // ---- Observability (read hierarchically; this repo adds no debug ports) ----
  output logic [DW-1:0]    sig_nret,
  output logic [NBANK-1:0] ram_bank_ok,
  output logic             ip_done
);

  localparam logic [1:0] IP_CMD_IDLE   = 2'b00;
  localparam logic [1:0] IP_CMD_FILL   = 2'b01;
  localparam logic [1:0] IP_CMD_VERIFY = 2'b10;

  localparam int unsigned DEPTH = 1 << AW;

  // ---------------------------------------------------------------------------
  // The pattern
  // ---------------------------------------------------------------------------
  // A pure function of (seed, bank, addr), so nothing has to be remembered
  // across a power cycle in order to check the RAM afterwards. The XOR keeps
  // the value from being mostly zeros, which is what a corrupted-to-zero array
  // would also look like.
  function automatic logic [DW-1:0] ip_pattern(input logic [7:0] seed,
                                               input logic [2:0] bank,
                                               input logic [3:0] addr);
    return ({seed, 5'd0, bank, 8'd0, 4'd0, addr}) ^ 32'hA5A5_5A5A;
  endfunction

  // ---------------------------------------------------------------------------
  // Workload FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] { W_IDLE, W_WORK, W_LIGHT } wstate_t;
  wstate_t wstate;

  logic [CNT_W-1:0] wcnt;
  wire              wlast = (wcnt == '0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wstate <= W_IDLE;
      wcnt   <= '0;          // reset, unlike the workload this replaced --
      busy   <= 1'b0;        // see the note at the bottom of this file
      done   <= 1'b0;
    end else begin
      done <= 1'b0;
      case (wstate)
        W_IDLE: begin
          if (start) begin
            wcnt <= work_len;
            if (light_work) begin
              wstate <= W_LIGHT;
            end else begin
              wstate <= W_WORK;
              busy   <= 1'b1;
            end
          end
        end
        W_WORK, W_LIGHT: begin
          wcnt <= wcnt - 1'b1;
          if (wlast) begin
            wcnt   <= '0;
            wstate <= W_IDLE;
            busy   <= 1'b0;
            done   <= 1'b1;
          end
        end
        default: wstate <= W_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // RAM sequencer
  // ---------------------------------------------------------------------------
  // Three states. VERIFY needs a separate compare state because the macro's
  // read is synchronous: the data for address N arrives during address N+1.
  typedef enum logic [1:0] { R_IDLE, R_FILL, R_VERIFY } rstate_t;
  rstate_t rstate;

  logic [AW-1:0] racnt;        // address being presented
  logic [AW-1:0] rcmp;         // address whose data is arriving
  logic          rcmp_vld;
  logic [7:0]    rseed;
  logic          cmd_d;
  wire           cmd_rise = (ip_cmd != IP_CMD_IDLE) && !cmd_d;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rstate      <= R_IDLE;
      racnt       <= '0;
      rcmp        <= '0;
      rcmp_vld    <= 1'b0;
      rseed       <= 8'h00;
      cmd_d       <= 1'b0;
      ram_bank_ok <= '0;
      sig_nret    <= '0;
      ip_done     <= 1'b0;
      ret_load    <= 1'b0;
    end else begin
      cmd_d    <= (ip_cmd != IP_CMD_IDLE);
      ret_load <= 1'b0;
      rcmp_vld <= 1'b0;

      case (rstate)
        R_IDLE: begin
          if (cmd_rise) begin
            racnt   <= '0;
            rseed   <= ip_seed;
            ip_done <= 1'b0;
            if (ip_cmd == IP_CMD_FILL) begin
              rstate      <= R_FILL;
              // The two logic signatures are captured at the same instant as
              // the RAM fill, so one command establishes all three classes of
              // state and a testbench has a single reference point.
              sig_nret    <= ip_pattern(ip_seed, 3'd7, 4'hF);
              ret_load    <= 1'b1;
            end else if (ip_cmd == IP_CMD_VERIFY) begin
              rstate      <= R_VERIFY;
              ram_bank_ok <= {NBANK{1'b1}};   // cleared by any mismatch
            end
          end
        end

        R_FILL: begin
          if (racnt == DEPTH-1) begin
            rstate  <= R_IDLE;
            ip_done <= 1'b1;
          end
          racnt <= racnt + 1'b1;
        end

        R_VERIFY: begin
          rcmp     <= racnt;
          rcmp_vld <= 1'b1;
          if (racnt == DEPTH-1) begin
            rstate <= R_IDLE;
          end
          racnt <= racnt + 1'b1;
        end

        default: rstate <= R_IDLE;
      endcase

      // Compare the data arriving this cycle for the address presented last
      // cycle. A bank that reads X -- because it was shut down, or because it
      // is in retention and cannot be read -- fails the === comparison, which
      // is the intended answer in both cases.
      if (rcmp_vld) begin
        for (int b = 0; b < NBANK; b++) begin
          if (ram_rdata[b] !== ip_pattern(rseed, 3'(b), rcmp))
            ram_bank_ok[b] <= 1'b0;
        end
        if (rcmp == DEPTH-1) ip_done <= 1'b1;
      end
    end
  end

  // ---- RAM port driving ----
  always_comb begin
    ram_ce   = (rstate != R_IDLE);
    ram_we   = (rstate == R_FILL);
    ram_addr = racnt;
    for (int b = 0; b < NBANK; b++)
      ram_wdata[b] = ip_pattern(rseed, 3'(b), racnt);
  end

  assign ret_sig_in = ip_pattern(rseed, 3'd7, 4'hF);

  // ---------------------------------------------------------------------------
  // A note on wcnt's reset
  // ---------------------------------------------------------------------------
  // dummy_workload, which this replaces, left its counter without a reset
  // value. That was a real finding under power-aware simulation: the counter
  // came back X after every power cycle where plain simulation showed the
  // stale pre-shutdown value, and it made the retention strategy look
  // ineffective on that one signal. It was benign there because the FSM
  // reloaded the counter before reading it -- but "benign" was an argument,
  // not a property. wcnt is reset here so it is a property.
endmodule
