`timescale 1ns/1ps
//=============================================================================
// ppu_ip_ret -- the device IP's RETAINED state
//
// A separate module for one reason: it is the element list of the UPF
// retention strategy. upf/ppu_pd_top.upf carries
//
//     set_retention RET_DEV_LOGIC -domain PD_DEV -elements {u_ip/u_ret} ...
//
// and a strategy is only as precise as the list it names. Retention cells cost
// area and leakage on every flop they cover, so "retain the whole IP" would be
// both wrong and expensive; keeping the retained registers in their own
// instance makes the boundary a structural fact rather than a naming
// convention someone has to maintain.
//
// WHY THIS BLOCK IS WHAT MAKES FULL_RET REAL
//
// Table 4-11 gives FULL_RET a device-control row found in no other mode:
// DEVWARMRESETn asserts while DEVPORESETn and DEVRETRESETn stay HIGH. A mode
// that resets some flops and not others is only meaningful if some flops
// retain, and until this block existed the device had none -- so FULL_RET and
// MEM_RET were indistinguishable below the PCSM, and the PPU was sequencing a
// distinction that did not reach anything.
//
// The reset here is DEVPORESETn & DEVRETRESETn, and that product is exactly
// what separates the modes:
//
//   ON         1 & 1 = 1   retained state kept
//   FUNC_RET   1 & 1 = 1   kept
//   MEM_OFF    1 & 1 = 1   kept
//   WARM_RST   1 & 0 = 0   RESET -- a warm reset is meant to clear it
//   FULL_RET   1 & 1 = 1   KEPT, while the non-retained block is reset
//   MEM_RET    0 & 0 = 0   reset, and the supply goes too
//   OFF        0 & 0 = 0   reset, and the supply goes too
//
// FULL_RET is the only row where this block keeps its value and
// ppu_ip_core does not. In MEM_RET and OFF the retention supply is absent as
// well, so the saved value is lost rather than restored -- which is the
// difference between "retained" and "retained ON A RAIL THAT SURVIVES", and
// the reason ppu_pd_top.upf creates VDD_RET as a second switched net.
//=============================================================================

module ppu_ip_ret #(
  parameter int unsigned DW = 32
) (
  input  logic          clk,        // gated device clock
  input  logic          rst_n,      // DEVPORESETn & DEVRETRESETn, synchronised
  input  logic          load,       // capture on a FILL command
  input  logic [7:0]    seed,
  input  logic [DW-1:0] sig_in,
  output logic [7:0]    seed_q,
  output logic [DW-1:0] sig
);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      seed_q <= 8'h00;
      sig    <= {DW{1'b0}};
    end else if (load) begin
      seed_q <= seed;
      sig    <= sig_in;
    end
  end

endmodule
