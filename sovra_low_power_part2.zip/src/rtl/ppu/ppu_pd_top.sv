`timescale 1ns/1ps
// PPU-controlled power domain with its stand-in device.
//
// ppu_dom_top plus ppu_device_ip, and nothing else. This module used to hold
// both halves itself. The PPU, the PCSM, the Q-Channel device agent, the clock
// gate and the reset synchronizers moved into ppu_dom_top so that a real
// device -- a CVA6 core, a DSP, an NPU -- can take ppu_device_ip's place. This
// module is what the PPU testbenches instantiate, and its ports, parameters
// and behaviour are what they were, with one parameter fewer (PGOOD_EN, below).
//
//   ┌──────────────────────────────── ppu_pd_top ────────────────────────────────┐
//   │                                                                            │
//   │  reg_*, ppuclk_* ──► u_dom: ppu_dom_top           u_ip: ppu_device_ip      │
//   │                      PPU, PCSM, Q-Channel agent,  u_core, u_ret and eight  │
//   │                      clock gate, reset syncs      SRAM banks               │
//   │                          dummy_clk ─────────────► clk                      │
//   │                          wl_rst_n, wl_ret_rst_n ► nret_rst_n, ret_rst_n    │
//   │                          ram_sleep, ram_sd ─────► bank_sleep, bank_sd      │
//   │  deny_enb, wake ───────► Q-Channel policy ◄────── busy                     │
//   │  start, work_len, light_work, ip_cmd, ip_seed ──► the IP's stimulus        │
//   └────────────────────────────────────────────────────────────────────────────┘
//
// See ppu_dom_top for the domain -- partition, resets, isolation, switch
// settling -- and ppu_device_ip for the device and its mode table.
//
// THE NETS KEEP THEIR NAMES
//
// Everything that runs between the two halves, and every domain output with no
// RTL consumer here, is declared below under the name it had when this module
// held both halves: dummy_clk, wl_rst_n, wl_ret_rst_n, busy, ram_sleep, ram_sd,
// ppuhwstat, dev_isolaten, logic_on, logic_ret and ret_n. A testbench probe of
// any of them, and of u_ip, therefore still resolves here. Everything else --
// u_ppu, u_pcsm, u_dev, u_clkctrl, the device controls, the Q-Channel and the
// P-Channel -- is one level down, under u_dom.
//
// THE POWER INTENT BINDS HERE
//
// src/upf/ppu_pd_top.upf is written relative to this module because it is the
// one scope that holds both halves of the domain: PD_DEV is u_dom/u_clkctrl,
// u_ip/u_core and u_ip/u_ret, and everything else in here is PD_AON.
//
// THE STAND-IN'S Q-CHANNEL POLICY
//
// ppu_dom_top takes qchannel_device's device-internal contract. The stand-in
// drives it with the three terms this module has always used: busy delays
// quiescence, deny_enb && busy refuses it, and wake | busy is the activity on
// DEVQACTIVE. The terms are evaluated here, in PD_AON, from busy after its
// isolation clamp -- which is why the clamp value is 0.
//
// PGOOD_EN IS GONE
//
// It chose whether ppu_pcsm waits for switch acknowledges. The power intent has
// none, so at 1 the PCSM waited forever, and the switch settling decision of
// 2026-09-29, confirmed 2026-09-30 (D11), keeps it at 0 with the settling in
// PCSM_*_SETTLE. ppu_dom_top fixes it at 0 and does not expose it, and nothing
// in the repository set it here. ppu_lpd_pd_top keeps its own for
// ppu_lpd_pd_tb's PGOOD_EN = 1 runs.

import ppu_pkg::*;

module ppu_pd_top #(
  // ---- Forwarded to ppu_dom_top, and from there to ppu_top and ppu_pcsm ----
  // Same order as before. See ppu_dom_top for what each selects and why it is
  // a parameter at all.

  // ---- PPU_PWPR, 0x000 (Table 5-2) ----
  parameter bit         DEF_PWR_DYN_EN        = 1'b0,     // [8]     PWR_DYN_EN
  parameter logic [3:0] DEF_PWR_POLICY        = PM_ON,    // [3:0]   PWR_POLICY

  // ---- PPU_PTCR, 0x024 (Table 5-12) ----
  parameter bit         WARM_RST_DEVREQEN_CFG = 1'b1,     // [0]     WARM_RST_DEVREQEN

  // ---- PPU_DCDR0, 0x170 (Table 5-24) ----
  parameter logic [7:0] RST_HWSTAT_DLY_CFG    = 8'd2,     // [23:16] RST_HWSTAT_DLY
  parameter logic [7:0] ISO_CLKEN_DLY_CFG     = 8'd2,     // [15:8]  ISO_CLKEN_DLY
  parameter logic [7:0] CLKEN_RST_DLY_CFG     = 8'd2,     // [7:0]   CLKEN_RST_DLY

  // ---- PPU_DCDR1, 0x174 (Table 5-25) ----
  parameter logic [7:0] CLKEN_ISO_DLY_CFG     = 8'd2,     // [15:8]  CLKEN_ISO_DLY
  parameter logic [7:0] ISO_RST_DLY_CFG       = 8'd2,     // [7:0]   ISO_RST_DLY

  // ---- PPU_IDR0, 0xFB0 (Table 5-26) -- Tables 7-4 and 7-1 mode support ----
  parameter bit         DYN_ON_SPT_CFG        = 1'b1,     // [28]    DYN_ON_SPT
  parameter bit         DYN_FUNC_RET_SPT_CFG  = 1'b1,     // [27]    DYN_FUNC_RET_SPT
  parameter bit         DYN_FULL_RET_SPT_CFG  = 1'b1,     // [26]    DYN_FULL_RET_SPT
  parameter bit         DYN_MEM_OFF_SPT_CFG   = 1'b1,     // [25]    DYN_MEM_OFF_SPT
  parameter bit         DYN_MEM_RET_SPT_CFG   = 1'b1,     // [22]    DYN_MEM_RET_SPT
  parameter bit         DYN_OFF_SPT_CFG       = 1'b1,     // [20]    DYN_OFF_SPT
  parameter bit         STA_FUNC_RET_SPT_CFG  = 1'b1,     // [15]    STA_FUNC_RET_SPT
  parameter bit         STA_FULL_RET_SPT_CFG  = 1'b1,     // [14]    STA_FULL_RET_SPT
  parameter bit         STA_MEM_OFF_SPT_CFG   = 1'b1,     // [13]    STA_MEM_OFF_SPT
  parameter bit         STA_MEM_RET_SPT_CFG   = 1'b1,     // [10]    STA_MEM_RET_SPT

  // ---- PPU_IDR1, 0xFB4 (Table 5-27) -- optional features ----
  parameter bit         OFF_MEM_RET_TRANS_CFG = 1'b1,     // [12]    OFF_MEM_RET_TRANS
  parameter bit         FUNC_RET_RAM_REG_CFG  = 1'b1,     // [6]     FUNC_RET_RAM_REG
  parameter bit         FULL_RET_RAM_REG_CFG  = 1'b1,     // [5]     FULL_RET_RAM_REG
  parameter bit         MEM_RET_RAM_REG_CFG   = 1'b1,     // [4]     MEM_RET_RAM_REG
  parameter bit         LOCK_CFG              = 1'b1,     // [2]     LOCK_SPT
  parameter bit         SW_DEV_DEL_CFG        = 1'b1,     // [1]     SW_DEV_DEL_SPT
  parameter bit         PWR_MODE_ENTRY_DEL_CFG= 1'b1,     // [0]     PWR_MODE_ENTRY_DEL_SPT

  // ---- Not visible in any register ----
  parameter int unsigned SYNC_STAGES          = 2,
  parameter bit          PCSM_SYNC_EN         = 1'b0,
  parameter bit          DEV_SYNC_EN          = 1'b1,
  parameter bit          DEV_ACTIVE_SYNC_EN   = 1'b1,
  parameter bit          QCLK_SYNC_EN         = 1'b1,

  // ---- The stand-in device's burst counter width: ppu_device_ip's only ----
  parameter int unsigned CNT_W                = 8,

  // ---- The PCSM ----
  // What it reports on PCSMMODESTAT at reset (Section 4.1.6, Table 4-13); the
  // switches' settling times in aon_clk cycles (0 = ideal switches, such as
  // ppu_pd_top.upf's); and its published tinit in PPU clock cycles (AMBA LPI
  // Section 2.2.2).
  parameter logic [3:0] PCSM_RESET_MODESTAT   = PM_OFF,
  parameter int unsigned PCSM_RET_SETTLE      = 0,
  parameter int unsigned PCSM_LOGIC_SETTLE    = 0,
  parameter int unsigned PCSM_TINIT_WAIT      = 16
) (
  // ---- Always-on domain: PPU and PCSM ----
  input  logic aon_clk,
  input  logic aon_rst_n,     // async, ACTIVE LOW

  // ---- PPU software interface ----
  input  logic [11:0] reg_waddr,
  input  logic [31:0] reg_wdata,
  input  logic        reg_wen,
  input  logic [3:0]  reg_wstrb,
  input  logic [11:0] reg_raddr,
  input  logic        reg_ren,
  output logic [31:0] reg_rdata,
  output logic        irq,

  // ---- PPU clock control interface (PCK-600 Tables A-28, A-29) ----
  // Tie ppuclk_qreqn HIGH and pwakeup LOW to leave the interface parked in
  // Q_RUN, which is what every testbench that is not about clock gating does.
  // See ppu_dom_top.
  input  logic        ppuclk_qreqn,
  output logic        ppuclk_qacceptn,
  output logic        ppuclk_qdeny,
  output logic        ppuclk_qactive,
  input  logic        pwakeup,

  // ---- Device / workload clock domain ----
  input  logic             dclk,
  input  logic             start,       // kick a workload burst
  input  logic [CNT_W-1:0] work_len,    // burst length in gated clocks
  input  logic             light_work,  // 1 = no busy during the burst
  input  logic             wake,        // external wake -> DEVQACTIVE
  input  logic             deny_enb,    // 1 = deny quiescence while busy

  // ---- Device IP command ----
  // 00 idle, 01 fill (seed the RAM and both logic signatures), 10 verify
  // (read every bank back and report per-bank survival). See ppu_device_ip.
  input  logic [1:0]       ip_cmd,
  input  logic [7:0]       ip_seed
);

  // ---- Between the domain and its device ----
  logic        dummy_clk;          // the IP's gated clock
  logic        wl_rst_n;           // IP non-retained reset, synchronized into dclk
  logic        wl_ret_rst_n;       // IP retained reset, synchronized into dclk
  logic        busy;               // the IP's busy flag, after its isolation clamp
  logic [7:0]  ram_sleep, ram_sd;  // registered SRAM macro pins, per bank

  // ---- Domain outputs with no RTL consumer here ----
  // Read hierarchically by the testbenches, this repository's convention for
  // observability (see qchannel_pd_top's header), or consumed by the power
  // intent rather than the RTL: dev_isolaten is the isolation enable, logic_on
  // and logic_ret the switch controls, ret_n the retention save/restore.
  logic        dev_quiescent_ok;
  logic [15:0] ppuhwstat;
  logic        dev_isolaten, logic_on, logic_ret, ret_n;

  // ---- The domain: everything but the device ----
  ppu_dom_top #(
    .DEF_PWR_DYN_EN        (DEF_PWR_DYN_EN),
    .DEF_PWR_POLICY        (DEF_PWR_POLICY),
    .WARM_RST_DEVREQEN_CFG (WARM_RST_DEVREQEN_CFG),
    .RST_HWSTAT_DLY_CFG    (RST_HWSTAT_DLY_CFG),
    .ISO_CLKEN_DLY_CFG     (ISO_CLKEN_DLY_CFG),
    .CLKEN_RST_DLY_CFG     (CLKEN_RST_DLY_CFG),
    .CLKEN_ISO_DLY_CFG     (CLKEN_ISO_DLY_CFG),
    .ISO_RST_DLY_CFG       (ISO_RST_DLY_CFG),
    .DYN_ON_SPT_CFG        (DYN_ON_SPT_CFG),
    .DYN_FUNC_RET_SPT_CFG  (DYN_FUNC_RET_SPT_CFG),
    .DYN_FULL_RET_SPT_CFG  (DYN_FULL_RET_SPT_CFG),
    .DYN_MEM_OFF_SPT_CFG   (DYN_MEM_OFF_SPT_CFG),
    .DYN_MEM_RET_SPT_CFG   (DYN_MEM_RET_SPT_CFG),
    .DYN_OFF_SPT_CFG       (DYN_OFF_SPT_CFG),
    .STA_FUNC_RET_SPT_CFG  (STA_FUNC_RET_SPT_CFG),
    .STA_FULL_RET_SPT_CFG  (STA_FULL_RET_SPT_CFG),
    .STA_MEM_OFF_SPT_CFG   (STA_MEM_OFF_SPT_CFG),
    .STA_MEM_RET_SPT_CFG   (STA_MEM_RET_SPT_CFG),
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG),
    .FUNC_RET_RAM_REG_CFG  (FUNC_RET_RAM_REG_CFG),
    .FULL_RET_RAM_REG_CFG  (FULL_RET_RAM_REG_CFG),
    .MEM_RET_RAM_REG_CFG   (MEM_RET_RAM_REG_CFG),
    .LOCK_CFG              (LOCK_CFG),
    .SW_DEV_DEL_CFG        (SW_DEV_DEL_CFG),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .SYNC_STAGES           (SYNC_STAGES),
    .PCSM_SYNC_EN          (PCSM_SYNC_EN),
    .DEV_SYNC_EN           (DEV_SYNC_EN),
    .DEV_ACTIVE_SYNC_EN    (DEV_ACTIVE_SYNC_EN),
    .QCLK_SYNC_EN          (QCLK_SYNC_EN),
    .PCSM_RESET_MODESTAT   (PCSM_RESET_MODESTAT),
    .PCSM_RET_SETTLE       (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE     (PCSM_LOGIC_SETTLE),
    .PCSM_TINIT_WAIT       (PCSM_TINIT_WAIT)
  ) u_dom (
    .aon_clk  (aon_clk),
    .aon_rst_n(aon_rst_n),

    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wen  (reg_wen),
    .reg_wstrb(reg_wstrb),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren),
    .reg_rdata(reg_rdata),
    .irq      (irq),

    .ppuclk_qreqn   (ppuclk_qreqn),
    .ppuclk_qacceptn(ppuclk_qacceptn),
    .ppuclk_qdeny   (ppuclk_qdeny),
    .ppuclk_qactive (ppuclk_qactive),
    .pwakeup        (pwakeup),

    .dclk      (dclk),

    // ---- The stand-in's Q-Channel policy: the terms this module always used ----
    .dev_quiescent_busy(busy),
    .dev_quiescent_deny(deny_enb && busy),
    .dev_wake          (wake | busy),
    .dev_quiescent_ok  (dev_quiescent_ok),

    // ---- Clock and resets out to the IP ----
    .dev_clk       (dummy_clk),
    .dev_clken_req (),                // DEVCLKEN for a SoC clkgate (H16); unused here
    .dev_nret_rst_n(wl_rst_n),
    .dev_ret_rst_n (wl_ret_rst_n),

    // ---- Isolation, status, and the PCSM's technology-specific controls ----
    .dev_isolaten  (dev_isolaten),
    .ppuhwstat     (ppuhwstat),
    .logic_on      (logic_on),
    .logic_ret     (logic_ret),
    .ret_n         (ret_n),
    .ram_sleep     (ram_sleep),
    .ram_sd        (ram_sd)
  );

  // ---- The device: the stand-in ----
  // Logic in the switched domain on the gated clock; RAM banks on the
  // always-on rail with their own sleep/shutdown pins. See ppu_device_ip.
  ppu_device_ip #(.CNT_W(CNT_W)) u_ip (
    .clk       (dummy_clk),

    // ---- Two resets, because the IP has two classes of logic state ----
    .nret_rst_n(wl_rst_n),
    .ret_rst_n (wl_ret_rst_n),

    // ---- Stimulus in ----
    .start     (start),
    .work_len  (work_len),
    .light_work(light_work),

    // ---- Only busy is consumed: it drives the Q-Channel policy above ----
    .busy      (busy),
    .done      (),

    // ---- Fill/verify command, and the SRAM macro pins from the PCSM ----
    .ip_cmd    (ip_cmd),
    .ip_seed   (ip_seed),
    .bank_sleep(ram_sleep),
    .bank_sd   (ram_sd)
  );

endmodule
