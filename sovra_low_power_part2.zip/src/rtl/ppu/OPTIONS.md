# PPU configuration options: what the specification offers vs what this PPU builds

Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E), Chapter 7,
plus the option-bearing parameters named elsewhere in the document.

Three columns, because they answer three different questions:

- **Spec offers** — the choice the architecture defines.
- **Implemented** — whether this RTL has a knob for it, and what it accepts.
  "Fixed" means the behaviour is hardwired, not parameterised.
- **Elaborated** — which values have actually been *built and simulated*. A knob
  that exists but has only ever been built at one value is not evidence of
  anything; that distinction is what `make ppucfg` was written to close.

Legend: **=** full coverage · **~** narrowed by our requirements · **x** not built

---

## 0. Parameter names follow the specification

Every configuration parameter on `ppu_top` and `ppu_pd_top` now uses the name the
specification gives it. That was not always so, and the way it was wrong is worth
recording.

The specification keeps two things apart that this RTL used to conflate: a
**configuration parameter** ends in `_CFG` and is set at elaboration, and the
`PPU_IDR1` **field** it drives has a different name that software reads back.
`LOCK_CFG` is the parameter; `PPU_IDR1[2]` is `LOCK_SPT`. Four parameters had
taken the field name, so reading `LOCK_SPT` in the RTL suggested it *was* the
`PPU_IDR1` bit rather than the thing that drives it — cause and effect the wrong
way round.

Two others were worse than misnamed. `DYN_SPT` and `RET_RAM_REGS` had no
specification equivalent at all, because each collapsed several parameters into
one switch, and the collapse was a real loss of configurability rather than a
naming choice.

| Was | Now |
|---|---|
| `LOCK_SPT` | `LOCK_CFG` |
| `SW_DEV_DEL_SPT` | `SW_DEV_DEL_CFG` |
| `PWR_MODE_ENTRY_DEL_SPT` | `PWR_MODE_ENTRY_DEL_CFG` |
| `OFF_MEM_RET_TRANS` | `OFF_MEM_RET_TRANS_CFG` |
| `DYN_SPT` (one switch) | `DYN_ON_SPT_CFG`, `DYN_FUNC_RET_SPT_CFG`, `DYN_MEM_OFF_SPT_CFG`, `DYN_FULL_RET_SPT_CFG`, `DYN_MEM_RET_SPT_CFG`, `DYN_OFF_SPT_CFG` |
| `RET_RAM_REGS` (one switch) | `FUNC_RET_RAM_REG_CFG`, `FULL_RET_RAM_REG_CFG`, `MEM_RET_RAM_REG_CFG` |
| *(mode set hardwired)* | `STA_FUNC_RET_SPT_CFG`, `STA_MEM_OFF_SPT_CFG`, `STA_FULL_RET_SPT_CFG`, `STA_MEM_RET_SPT_CFG` |

`ON`, `OFF` and `WARM_RST` are not parameters: §7.1.7 makes them always
supported. There is no `DYN_WRM_RST_SPT_CFG` either — that is Table 7-5, which is
P-Channel only, and §3.4.3 excludes dynamic `WARM_RST` on a Q-Channel PPU, so
there is no configuration in which it could be 1.

**Behaviour follows the parameters, not just `PPU_IDR0`/`IDR1`.** The support
masks feed the policy-acceptance check, so a mode the build does not have is
refused as an unsupported policy and raises `UNSPT_POLICY_IRQ`; the lock consults
the mask too, since a mode that does not exist cannot be locked in. Checked by
`ppucfg` phase M9.

**Dependencies are checked at elaboration**, not left to the integrator:
dynamic support for a mode requires static support for it, all dynamic support
requires `DYN_ON_SPT_CFG` (every Q-Channel route is anchored on `ON`, §3.4.3),
`OFF_MEM_RET_TRANS_CFG` requires `MEM_RET`, and §7.1.5's rule that a retention
register is reserved when its mode is absent is enforced rather than documented.
Each violation is a `$fatal` naming both parameters.

## 1. Device interface (§7.1.1)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `DEVCHAN_CFG` | P-Channel (`0x0`), or 1–8 Q-Channels | **1 Q-Channel only.** Fixed — no parameter | 1 | ~ |

Consequences that follow from the single channel, all deliberate: `PPU_STSR` is
reserved (§5.2.6), `PPU_IESR` has one channel's bits, and denial aggregation
across channels does not exist.

## 2. P-Channel PSTATE lead (§7.1.2)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `DEV_PREQ_DLY` | 0–3 | n/a — the device interface is a Q-Channel | — | ~ |
| `PCSM_PREQ_DLY` | 0–3 | **Fixed at 0.** `ppu_top` passes `PSTATE_LEAD_CYCLES(0)` | 0 | x |

The underlying `pchannel_controller` *does* implement the lead and it is measured
(`pch` phase B-1, at 5) — but the PPU hardwires its PCSM channel to 0, so values
1–3 are unreachable in a PPU build.

## 3. Default power policy (§7.1.3)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `DEF_PWR_POLICY` | `ON` (`0b1000`) or `OFF` (`0b0000`) | **Both** | **Both** — `ppu_reset_tb` rows 1–4 | = |
| `DEF_PWR_DYN_EN` | 0 or 1 | **Both** | **0 only** | ~ |

## 4. Device control delays (§7.1.4)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `ISO_CLKEN_DLY_CFG` | 0–255 | full 8-bit range | 2, 6 | = |
| `CLKEN_RST_DLY_CFG` | 0–255 | full 8-bit range | 2, 7 | = |
| `RST_HWSTAT_DLY_CFG` | 0–255 | full 8-bit range | 2, 5, 60 | = |
| `CLKEN_ISO_DLY_CFG` | 0–255 | full 8-bit range | 2, 3 | = |
| `ISO_RST_DLY_CFG` | 0–255 | full 8-bit range | 2, 4 | = |

All five are also runtime-programmable via `PPU_DCDR0/1`, and all five are
*measured* — collapsing any one to zero fails a named check.

## 5. Retention RAM configuration registers (§7.1.5)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `FUNC_RET_RAM_REG_CFG` | 0 or 1, independently | **Both** | see M9 | = |
| `FULL_RET_RAM_REG_CFG` | 0 or 1, independently | **Both** | see M9 | = |
| `MEM_RET_RAM_REG_CFG` | 0 or 1, independently | **Both** | see M9 | = |

**One parameter each, as the specification defines.** A build can have `PPU_MEMRR`
present and `PPU_FUNRR` reserved. `ppucfg` M9 builds one with `FULL_RET` dropped
and confirms `PPU_FULRR` goes reserved with it, per §7.1.5.

## 6. Transition control (§7.1.6)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `WARM_RST_DEVREQEN_CFG` | 0 or 1 | **Both** | **1 only** (both values tested at *runtime* via `PPU_PTCR`, phase P3) | ~ |
| `DBG_RECOV_PORST_CFG` | 0 or 1 | n/a — no `DBG_RECOV` | — | ~ |

## 7. Power mode support (§7.1.7, Tables 7-1 and 7-3)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `STA_FUNC_RET_SPT_CFG` | 0 or 1 | **Both** | **Both** — `ppucfg` M9 | = |
| `STA_MEM_OFF_SPT_CFG` | 0 or 1 | **Both** | 1 | = |
| `STA_FULL_RET_SPT_CFG` | 0 or 1 | **Both** | **Both** — `ppucfg` M9 | = |
| `STA_MEM_RET_SPT_CFG` | 0 or 1 | **Both** | 1 | = |
| `STA_MEM_RET_EMU_SPT_CFG` | 0 or 1 | **Fixed at 0** — not built | — | x |
| `STA_OFF_EMU_SPT_CFG` | 0 or 1 | **Fixed at 0** — not built | — | x |
| `STA_LGC_RET_SPT_CFG` | P-Channel only | n/a | — | ~ |
| `STA_DBG_RECOV_SPT_CFG` | P-Channel only | n/a | — | ~ |

**Now configurable.** The four optional modes each have their parameter, and the
support decode reads a mask built from them rather than a hardwired list. `ON`,
`OFF` and `WARM_RST` remain fixed because §7.1.7 makes them mandatory. The two
emulation modes stay unbuilt — that is a scope decision, not a missing knob.

## 8. Dynamic transition support (Tables 7-4 and 7-5)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `DYN_ON_SPT_CFG` | 0 or 1 | **Both** | see M9 | = |
| `DYN_FUNC_RET_SPT_CFG` | 0 or 1 | **Both** | see M9 | = |
| `DYN_MEM_OFF_SPT_CFG` | 0 or 1 | **Both** | see M9 | = |
| `DYN_FULL_RET_SPT_CFG` | 0 or 1 | **Both** | see M9 | = |
| `DYN_MEM_RET_SPT_CFG` | 0 or 1 | **Both** | see M9 | = |
| `DYN_OFF_SPT_CFG` | 0 or 1 | **Both** | see M9 | = |
| `DYN_MEM_RET_EMU_SPT_CFG` | 0 or 1 | n/a — no emulation | — | ~ |
| `DYN_OFF_EMU_SPT_CFG` | 0 or 1 | n/a — no emulation | — | ~ |
| `DYN_LGC_RET/WRM_RST_SPT_CFG` | P-Channel only | n/a | — | ~ |

**One parameter per mode, as the specification defines.** The spec's own example —
*"a domain might support dynamic and static transitions to FUNC_RET but only
static transitions to OFF"* (§3.4.3) — is now buildable, and `ppucfg` M9 builds
exactly it: `PPU_IDR0[27]` reads 1, `[20]` reads 0, dynamic `OFF` is refused with
`UNSPT_POLICY_IRQ` while static `OFF` is accepted.

`WARM_RST` is excluded from dynamic transitions by §3.4.3 for a Q-Channel PPU,
which is behaviour rather than an option.

## 9. Remaining feature options

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `OFF_MEM_RET_TRANS_CFG` | 0 or 1 | **Both** | **Both** — `ppucfg` | = |
| `LOCK_CFG` | 0 or 1 | **Both** (`LOCK_SPT`) | **Both** — `ppucfg` | = |
| `SW_DEV_DEL_CFG` | 0 or 1 | **Both** (`SW_DEV_DEL_SPT`) | **Both** — `ppucfg` | = |
| `PWR_MODE_ENTRY_DEL_CFG` | 0 or 1 | **Both** (`PWR_MODE_ENTRY_DEL_SPT`) | **Both** — `ppucfg` | = |
| `STA_POLICY_PWR_IRQ_CFG` | 0 or 1 | **Fixed at 0** | — | ~ |
| `STA_POLICY_OP_IRQ_CFG` | 0 or 1 | **Fixed at 0** | — | ~ |

Both policy-completion interrupt options are fixed at 0 by §4.1.2, not by us:
*"They are not supported when operating modes are not supported."* That was
defect **F2**.

## 10. Operating modes (§3.5, §3.6, §4.3, Table 7-6)

| Spec parameter | Spec offers | Implemented | Elaborated | |
|---|---|---|---|---|
| `OP_ACTIVE_CFG` | ladder (0) or independent (1) | **not built** | — | x |
| `NUM_OPMODE_CFG` | 0–8 (ladder), or 0/1/3/7/15 (independent) | **not built** — fixed 0 | — | x |
| `OPMODE_PCSM_SPT_CFG` | 0 or 1 | **not built** | — | x |

No operating modes. `PPU_PWPR.OP_POLICY`, `OP_DYN_EN`, `PPU_PWSR.OP_STATUS`,
`OP_DYN_STATUS`, `PPU_DISR.OP_DEVACTIVE_STATUS`, `PPU_PWCR.OP_DEVACTIVEEN`,
`PPU_ISR.OP_ACTIVE_EDGE_IRQ` and the whole of `PPU_OPSR` are reserved, and
`PCSMPSTATE[7:4]` is permanently zero (checked by monitor rule U10).

## 11. Implementation-defined identity

| Field | Spec offers | Implemented | |
|---|---|---|---|
| `PPU_IIDR.IMPLEMENTER` | JEP106 code | **`0x000`, deliberately not Arm's `0x43B`** | ~ |
| `PPU_IIDR.PRODUCT_ID` / `VARIANT` / `REVISION` | IMPLEMENTATION DEFINED | parameters, defaults `0x50C` / `0x0` / `0x1` | = |
| `PPU_AIDR` | architecture version | `0x11` (v1.1), fixed | = |

---

## Summary

| | Count |
|---|---|
| Options where we cover the full spec choice | **10** |
| Options narrowed by our stated requirements | **21** |
| Options collapsed (several spec knobs → one of ours) | **9 → 2** |
| Options not built at all (emulation, operating modes, P-Channel PPU) | **12** |

The narrowings are not defects — they follow from the agreed configuration: a
single-Q-Channel PPU, no emulation modes, no operating modes. What this table adds
is that they are now *enumerated* rather than implicit, and the "Elaborated"
column separates a knob that works from a knob that has merely been declared.

**The three worth knowing about, if the configuration ever widens:**

1. **Mode support is frozen** (§7). Seven modes, not selectable. Adding or
   removing one means editing `ppu_mode_static_spt()` and the device-control
   table, not setting a parameter.
2. **Dynamic support is one switch, not six.** The spec's own example of a mixed
   configuration cannot be built.
3. **The three retention-RAM register switches are one.** Mixed configurations
   are not expressible.
