`timescale 1ns/1ps
// PPU interrupt logic -- PPU_IMR / PPU_AIMR / PPU_ISR / PPU_AISR / PPU_IESR.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E) Section 4.1.2 "PPU Interrupt" and Sections 5.2.10-5.2.14.
//
// "The PPU has a single, active HIGH, level sensitive, interrupt output... The
// interrupt output is HIGH when any bit in the Interrupt Status Register
// (PPU_ISR) or Additional Interrupt Status Register (PPU_AISR) is set."
//
// The five registers live here rather than in ppu_regs because their contents
// are not a plain software-write store: every status bit is a race between a
// hardware set and a software write-one-to-clear, and the mask decides whether
// the set happens at all. Keeping the store next to that logic means the
// register file only has to route a write strobe and read back a value.
//
// THREE RULES SHAPE EVERY LINE BELOW
//
//  1. Masking suppresses the STATUS BIT, not just the output. Section 5.2.10:
//     "When an interrupt event is masked an occurrence of the event does not
//     set the corresponding bit in the interrupt status register." So the mask
//     is an AND on the set term, not on the irq output -- unmasking later does
//     not resurrect an event that happened while masked.
//
//  2. Set beats clear in the same cycle. Section 4.1.2: "If an event is
//     cleared in the same cycle that it re-occurs the interrupt status stays
//     HIGH, so the re-occurrence is observed." Hence set is applied after the
//     clear term below, not ORed into the same expression ambiguously.
//
//  3. ISR.OTHER_IRQ is derived, not stored. Section 5.2.12: it "cannot be
//     cleared by writing to this register. It must be cleared by writing to
//     the active event in the Additional Interrupt Status Register". Making it
//     a live OR of PPU_AISR is the only way it can never disagree with the
//     register it summarises.
//
// EVENTS THAT CANNOT OCCUR ON THIS PPU are not wired at all: emulation
// accept/deny (PPU_ISR[4:3]) because no emulation modes are built, and the
// operating-policy completion event (PPU_AISR[4]) because operating modes are
// P-Channel only. Those bits are reserved, i.e. write-ignored and read-as-zero
// (Section 5.2), which is what the write masks below implement.

import ppu_pkg::*;

module ppu_irq #(
  // Lock is an optional feature (PPU_IDR1.LOCK_SPT). When it is not built the
  // LOCKED event and its mask bit are reserved rather than merely unused.
  parameter bit LOCK_CFG = 1'b1
) (
  input logic clk,
  input logic rst_n,

  // ---- Write data and byte lanes, straight off the bus ----
  input logic [31:0] wdata,
  input logic [ 3:0] wstrb,

  // ---- Which register is being written, decoded by ppu_regs ----
  input logic wr_imr ,
  input logic wr_aimr,
  input logic wr_isr ,
  input logic wr_aisr,
  input logic wr_iesr,

  // ---- Register contents, back to ppu_regs for the read mux ----
  output logic [31:0] imr ,
  output logic [31:0] aimr,
  output logic [31:0] isr ,
  output logic [31:0] aisr,
  output logic [31:0] iesr,

  // ---- Events: single-cycle pulses from the sequencer / register file ----
  // There is deliberately NO ev_sta_policy_pwr: see AIMR_WMASK below.
  input logic ev_sta_policy_trn,  // full policy transition completion
  input logic ev_sta_accept    ,  // static transition accepted
  input logic ev_sta_deny      ,  // static transition denied
  input logic ev_locked        ,  // PPU became locked
  input logic ev_dyn_accept    ,  // dynamic transition accepted
  input logic ev_dyn_deny      ,  // dynamic transition denied
  input logic ev_unspt_policy  ,  // unsupported policy programmed

  // DEVQACTIVE, already synchronized into the PPU clock domain. Section 4.1.3
  // "DEVACTIVE Enables": the PPU_PWCR enables "have no effect on the
  // generation of interrupts... This allows DEVACTIVE changes to be monitored
  // by software", so the raw synchronized level is what feeds the edge
  // detector -- deliberately NOT the enable-gated view the sequencer uses.
  input logic dev_qactive,

  // The edge detector's registered copy of dev_qactive: the level it last saw.
  // ppu_top compares the input against it to ask for the PPU clock while an
  // edge is still unseen, because this detector runs on that clock and cannot
  // see anything while it is gated.
  output logic qactive_seen,

  output logic irq
);

  // ---------------------------------------------------------------------------
  // Writable-bit masks. Everything outside them is reserved: write-ignored,
  // read-as-zero (Section 5.2). Spelling them out as constants keeps the
  // "which bits exist on THIS PPU" decision in one visible place instead of
  // scattered across the assignments below.
  // ---------------------------------------------------------------------------
  localparam logic [31:0] IMR_WMASK =
      ((LOCK_CFG ? 32'b1 : 32'b0) << ISR_LOCKED        )
    | ((           32'b1        ) << ISR_STA_DENY      )
    | ((           32'b1        ) << ISR_STA_ACCEPT    )
    | ((           32'b1        ) << ISR_STA_POLICY_TRN);

  // PPU_ISR adds the input-edge event, which has no PPU_IMR bit -- it is masked
  // by the PPU_IESR encoding instead (Section 5.2.14).
  localparam logic [31:0] ISR_WMASK = IMR_WMASK | (32'b1 << ISR_PWR_ACTIVE_EDGE);

  // AISR_STA_POLICY_PWR is absent, not merely unused: Section 4.1.2 makes the
  // power-policy completion event unsupported when operating modes are not
  // supported, so PPU_AISR[3] and PPU_AIMR[3] are reserved here.
  localparam logic [31:0] AIMR_WMASK =
      (32'b1 << AISR_DYN_DENY    )
    | (32'b1 << AISR_DYN_ACCEPT  )
    | (32'b1 << AISR_UNSPT_POLICY);

  localparam logic [31:0] AISR_WMASK = AIMR_WMASK;

  // Only DEVACTIVE00_EDGE exists: one Q-Channel (Section 5.2.14).
  localparam logic [31:0] IESR_WMASK = 32'h0000_0003;

  // Reset values from Tables 5-13 and 5-14. A 1 means MASKED, so the defaults
  // say: report transition completion, denial and unsupported policy; stay
  // quiet about routine acceptances.
  localparam logic [31:0] IMR_RST =
      ((LOCK_CFG ? 32'b1 : 32'b0) << ISR_LOCKED        )   // LOCK_CFG
    | ((                   32'b0) << ISR_STA_DENY      )   // 0
    | ((           32'b1        ) << ISR_STA_ACCEPT    )   // 1
    | ((                   32'b0) << ISR_STA_POLICY_TRN);  // 0
  localparam logic [31:0] AIMR_RST =
      ((           32'b1        ) << AISR_DYN_DENY     )   // 1
    | ((           32'b1        ) << AISR_DYN_ACCEPT   )   // 1
    | ((                   32'b0) << AISR_UNSPT_POLICY );  // 0

  logic [31:0] imr_q, aimr_q, isr_q, aisr_q, iesr_q;

  // ---------------------------------------------------------------------------
  // Input edge detection on DEVQACTIVE (PPU_IESR.DEVACTIVE00_EDGE).
  // ---------------------------------------------------------------------------
  logic dev_qactive_d;
  logic edge_event;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) dev_qactive_d <= 1'b0;
    else        dev_qactive_d <= dev_qactive;
  end

  assign qactive_seen = dev_qactive_d;

  // The edge event's mask IS the PPU_IESR encoding.
  always_comb begin
    unique case (iesr_q[1:0])
      EDGE_RISE: edge_event = (!dev_qactive_d) && ( dev_qactive);
      EDGE_FALL: edge_event = ( dev_qactive_d) && (!dev_qactive);
      EDGE_BOTH: edge_event = ( dev_qactive_d) != ( dev_qactive);
      default:   edge_event = 1'b0;   // EDGE_NONE: event masked
    endcase
  end

  // ---------------------------------------------------------------------------
  // Set terms, each gated by its mask bit (rule 1 above).
  // ---------------------------------------------------------------------------
  logic [31:0] isr_set, aisr_set;

  always_comb begin
    isr_set = '0;
    if (ev_sta_policy_trn && !imr_q[ISR_STA_POLICY_TRN]            ) isr_set[ISR_STA_POLICY_TRN ] = 1'b1;
    if (ev_sta_accept     && !imr_q[ISR_STA_ACCEPT    ]            ) isr_set[ISR_STA_ACCEPT     ] = 1'b1;
    if (ev_sta_deny       && !imr_q[ISR_STA_DENY      ]            ) isr_set[ISR_STA_DENY       ] = 1'b1;
    if (ev_locked         && !imr_q[ISR_LOCKED        ] && LOCK_CFG) isr_set[ISR_LOCKED         ] = 1'b1;
    if (edge_event                                                 ) isr_set[ISR_PWR_ACTIVE_EDGE] = 1'b1;

    aisr_set = '0;
    if (ev_dyn_accept   && !aimr_q[AISR_DYN_ACCEPT  ]) aisr_set[AISR_DYN_ACCEPT  ] = 1'b1;
    if (ev_dyn_deny     && !aimr_q[AISR_DYN_DENY    ]) aisr_set[AISR_DYN_DENY    ] = 1'b1;
    if (ev_unspt_policy && !aimr_q[AISR_UNSPT_POLICY]) aisr_set[AISR_UNSPT_POLICY] = 1'b1;
  end

  // ---------------------------------------------------------------------------
  // Registers. Write-one-to-clear on the two status registers; a write of 0 to
  // a bit has no effect (Sections 5.2.12, 5.2.13). The set term is applied
  // last so a re-occurrence survives a same-cycle clear (rule 2).
  // ---------------------------------------------------------------------------
  // wstrb expanded to a per-bit mask. The two register kinds here use it
  // differently, and the difference is the whole reason it has to reach this
  // module rather than being resolved in ppu_regs:
  //
  //   IMR / AIMR / IESR are ordinary read-write, so an unselected lane must
  //   keep the bits it already has -- a merge.
  //
  //   ISR / AISR are write-1-to-clear, so an unselected lane clears nothing.
  //   Masking wdata to zero there is already the correct behaviour, and a
  //   merge would be wrong: it would feed the register's own set bits back in
  //   as clear requests and wipe the very status software was preserving.
  logic [31:0] be;
  always_comb begin
    for (int i = 0; i < 4; i++) be[i*8+:8] = {8{wstrb[i]}};
  end

  // Ordinary read-write with byte lanes: the selected lanes take wdata, the
  // unselected lanes keep what they already had.
  function automatic logic [31:0] lane_merge(
    input logic [31:0] cur,
    input logic [31:0] wdat,
    input logic [31:0] lanes
  );
    return (wdat & lanes) | (cur & ~lanes);
  endfunction

  // Write-one-to-clear, with Section 4.1.2's collision rule built in: the set
  // term is applied AFTER the clear, so an event that re-occurs in the same
  // cycle it is cleared stays HIGH and is observed.
  //
  // The tempting alternative, (cur | set) & ~clr, silently drops that
  // re-occurrence. Writing the rule as a named function puts the ordering in
  // one place instead of inside an expression where it reads as an accident.
  function automatic logic [31:0] w1c_set_wins(
    input logic [31:0] cur,
    input logic [31:0] clr,
    input logic [31:0] set
  );
    return (cur & ~clr) | set;
  endfunction

  // What a software write is asking to clear this cycle. Three independent
  // gates, each saying something different:
  //
  //   wdata      write-one-to-clear -- a 0 leaves the bit alone (5.2.12, 5.2.13)
  //   be         byte lanes -- an unselected lane clears nothing
  //   *_WMASK    the bits this build implements; the rest are reserved
  //
  // Note this is where `be` belongs for these two registers, and NOT in a
  // lane_merge like the three above. Merging would feed the register's own set
  // bits back in as clear requests and wipe the status software was preserving.
  wire [31:0]  isr_clr = wr_isr  ? (wdata & be &  ISR_WMASK) : 32'b0;
  wire [31:0] aisr_clr = wr_aisr ? (wdata & be & AISR_WMASK) : 32'b0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
       imr_q <= IMR_RST;
      aimr_q <= AIMR_RST;
       isr_q <= '0;
      aisr_q <= '0;
      iesr_q <= '0;
    end else begin
      if (wr_imr )  imr_q <= lane_merge( imr_q, wdata, be) &  IMR_WMASK;
      if (wr_aimr) aimr_q <= lane_merge(aimr_q, wdata, be) & AIMR_WMASK;
      if (wr_iesr) iesr_q <= lane_merge(iesr_q, wdata, be) & IESR_WMASK;

       isr_q <= w1c_set_wins( isr_q,  isr_clr,  isr_set);
      aisr_q <= w1c_set_wins(aisr_q, aisr_clr, aisr_set);
    end
  end

  assign  imr =  imr_q;
  assign aimr = aimr_q;
  assign iesr = iesr_q;
  assign aisr = aisr_q;

  // OTHER_IRQ is a live summary of PPU_AISR, never a stored bit (rule 3).
  always_comb begin
    isr            = isr_q;
    isr[ISR_OTHER] = (|aisr_q);
  end

  assign irq = (|isr_q) || (|aisr_q);

endmodule
