`timescale 1ns/1ps
// Clock Controller (CLK-CTRL) -- high-level clock gating over Q-Channel.
//
// References:
//   AMBA Low Power Interface Specification (ARM IHI 0068C)
//     Section 2.1.2  what each handshake state guarantees about the clock
//     Section 3.1    clock domain crossing, "only remove clock or power when
//                    the interface is in the Q_STOPPED state"
//     Section 4.1.2  interface combining for clock control
//     Section 4.1.3  application of the QACTIVE-only interface
//   Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E)
//     Section 2.1    Figure 2-1 puts a clock controller beside the PPU as a
//                    standard power-control-framework component: "Clock
//                    controllers target components that support high-level
//                    clock gating... This approach enables the clock to be
//                    gated at the clock tree root when components are idle."
//   Arm CoreLink PCK-600 TRM (101150)
//     Section 3.5    the block's function
//     Table 3-7      configuration parameters
//     Tables A-21..A-26  the signal list this module's ports follow
//
// WHAT THIS IS, VERSUS THE ICG THIS REPOSITORY ALREADY HAD
//
// clk_gate is a gate: enable in, gated clock out, nothing else. This
// is the block that DECIDES. It owns a Q-Channel to every device in the clock
// domain, drives them into quiescence when the domain goes idle, and only then
// drops clken_o. On the way back it does the reverse, and the ordering is the
// substance of the block:
//
//   entry   quiesce every device  ->  THEN gate the clock
//   exit    ungate the clock      ->  THEN release the devices
//
// Section 2.1.2 is what forces it. Q_STOPPED "is the only state where the
// controller does not guarantee the availability of any clock or power supply
// that is managed by the interface" -- so gating anywhere else is a protocol
// violation. And Q_EXIT: "Any clock or power supply managed by the interface is
// guaranteed after an implementation-dependent delay" -- so the clock has to be
// back before the device is told to leave. PCK-600 Section 3.5 states the same
// pair as the block's job: "uses the Q-Channels to ensure that the devices are
// in a quiescent state before it gates the clock" and "ensures that the clock
// is running, before it allows a device to exit the quiescent state".
//
// Both halves are enforced by one register, clk_running, and one rule: a device
// channel's request is held asserted until clk_running is HIGH again. See the
// "Clock guarantee" section below.
//
// ONE FSM PER DEVICE, NOT ONE FSM FOR ALL
//
// LPI Section 4.1.2 permits combining device interfaces at a controller and
// then states the constraint that is easy to miss:
//
//   "In all cases the solution must retain dedicated and independent handshake
//    interfaces between each device and the controller or combining functional
//    block. This is important as it ensures that performance limitations or
//    potential deadlock scenarios can be avoided in cases where there are
//    interdependencies between devices with a shared clock."
//
// So NUM_Q_CHL separate qchannel_controller instances, one per device, each
// running its own six-state handshake -- not one handshake fanned out to N
// pins. Figure 4-2 is exactly this arrangement: "the device interfaces are
// connected to dedicated functional blocks within a controller and the only
// shared signal is the CLK signal... the two functional blocks manage the
// devices independently with only a simple internal merge of clock enable
// conditions."
//
// The controllers are the repository's existing qchannel_controller, reused
// unmodified, the same way ppu_top reuses it for the PPU's device interface.
// Their two QACTIVE policy inputs are tied LOW and the request is driven
// centrally, because the decision here is not per-channel: PCK-600 Section 3.5
// says "When any clk_qactive_i goes HIGH, the CLK-CTRL enables the clock and
// moves ALL the device Q-Channels to the running state."
//
// QACTIVE-ONLY DEVICES
//
// clk_qactive_i is NUM_Q_CHL + NUM_QACTIVE_ONLY bits wide (Table A-24). The top
// NUM_QACTIVE_ONLY bits belong to devices with no handshake at all -- LPI
// Section 4.1.3's case, a block that can veto clock removal but cannot
// negotiate. They feed the activity decision and nothing else, which is all
// they can do: there is no channel to request quiescence on.
//
// FOUR PLACES THIS BLOCK INTERPRETS RATHER THAN FOLLOWS
//
// PCK-600 describes the CLK-CTRL in about a page and a half, and four
// behaviours it does not cover had to be decided here. Each is marked at the
// logic that implements it; collected here so a reader knows the list is
// finite.
//
//   1. up_hold vs a literal Section 3.5. The TRM says "When any clk_qactive_i
//      goes HIGH, the CLK-CTRL enables the clock and moves ALL the device
//      Q-Channels to the running state", with no exception. This block does not
//      do that once a hierarchical controller has accepted, because Q-Channel
//      semantics forbid unilaterally leaving a state you accepted and the
//      upstream controller may already be removing the rail. The TRM never
//      describes the interaction, so the sentence and the protocol simply do
//      not meet; the protocol wins. See "The request policy".
//
//   2. How hc_* and pwr_* combine. Not stated for the CLK-CTRL at all. The rule
//      used is the one PCK-600 DOES document, for the LPC-Q: either controller
//      requesting drives entry, and exit waits for BOTH to have withdrawn.
//
//   3. clken_o's reset value. Not specified. HIGH here; see "Clock guarantee".
//
//   4. The denial latch and its retry backoff. Not in the TRM in any form. See
//      DENY_RETRY_DLY and "Downstream denials".
//
// THE DENIAL LATCH
//
// A device that denies leaves the interface back in Q_RUN. Nothing about the
// controller's policy has changed at that instant, so a naive controller
// re-requests immediately and the channel thrashes Q_RUN -> Q_REQUEST ->
// Q_DENIED -> Q_CONTINUE -> Q_RUN forever, burning exactly the power the block
// exists to save. deny_seen latches the refusal per channel and stops asking
// until the situation changes -- activity, or the request being withdrawn. That
// is the "performance limitation" half of what Section 4.1.2 asks the combining
// block to avoid, and it is per-channel so one device's refusal does not stall
// another's handshake.

import qchannel_pkg::*;

module ppu_clk_ctrl #(
  // ---- Table 3-7 ----
  parameter int unsigned NUM_Q_CHL        = 1,      // 1-8  device Q-Channels
  parameter int unsigned NUM_QACTIVE_ONLY = 1,      // 0-32 QACTIVE-only devices
  parameter bit          HC_Q_CH_SYNC     = 1'b1,   // synchronize hc_qreqn_i
  parameter bit          PWR_Q_CH_SYNC    = 1'b1,   // synchronize pwr_qreqn_i
  // Table 3-7: "0 = Synchronizers are not present on the clk_qacceptn_i[N] or
  // clk_qdeny_i[N] inputs."  Reaching INSIDE the per-channel controllers to
  // honour that needs no fork of them: cdc_sync already treats STAGES = 0
  // as a pure combinational passthrough for exactly this case, so the parameter
  // travels down as SYNC_STAGES and the flops disappear.
  //
  // This originally gated only this block's own qdeny copy while the reused
  // qchannel_controller synchronized regardless, which meant clearing the
  // parameter removed nothing on clk_qacceptn_i. Harmless -- extra latency,
  // never wrong -- but the parameter did not do what the table says, and
  // u_min in ppu_clkctrl_tb set it to 0 and passed, proving only that it still
  // worked.
  parameter bit          CLK_Q_CH_SYNC    = 1'b1,
  // 1 = activity arriving during a quiescence entry aborts the entry, which is
  // how a QACTIVE-only device refuses (it has no QDENY to refuse with).
  parameter bit          ACTIVE_DENY_EN   = 1'b1,
  parameter bit          CLK_QACTIVE_SYNC = 1'b1,   // synchronize clk_qactive_i

  // ---- Not in Table 3-7: integration choices, as in every other block here ----
  parameter int unsigned SYNC_STAGES      = 2,

  // clk cycles to wait after a device's denial before asking it again.
  //
  // Table 3-7 has no equivalent and the TRM never says what a CLK-CTRL does
  // with a refusal, so this is ours. It has to exist, because the two obvious
  // policies are both wrong:
  //
  //   re-ask immediately   the channel thrashes Q_RUN -> Q_REQUEST -> Q_DENIED
  //                        -> Q_CONTINUE -> Q_RUN forever, burning exactly the
  //                        power this block exists to save. LPI Section 4.1.2
  //                        names "performance limitations" as something a
  //                        combining block must avoid
  //
  //   never re-ask         a device that refuses once and then becomes willing
  //                        is never asked again, so the clock gating is
  //                        silently dead until something makes QACTIVE move
  //
  // The second was this block's behaviour and it was a real defect: deny_seen
  // only cleared when base_req fell, and base_req stays HIGH for as long as the
  // domain is idle -- which is precisely when gating is wanted.
  parameter int unsigned DENY_RETRY_DLY   = 255
) (
  // ---- Table A-21 ----
  input  logic clk,
  input  logic reset_n,     // async assert, deassert synchronous to clk

  // ---- Table A-22: hierarchical CLOCK control Q-Channel (device side) ----
  input  logic hc_qreqn_i,
  output logic hc_qacceptn_o,
  output logic hc_qdeny_o,
  output logic hc_qactive_o,

  // ---- Table A-23: hierarchical POWER control Q-Channel (device side) ----
  input  logic pwr_qreqn_i,
  output logic pwr_qacceptn_o,
  output logic pwr_qdeny_o,
  output logic pwr_qactive_o,

  // ---- Table A-24: clock device interface (controller side) ----
  output logic [(NUM_Q_CHL                 )-1:0] clk_qreqn_o,
  input  logic [(NUM_Q_CHL                 )-1:0] clk_qacceptn_i,
  input  logic [(NUM_Q_CHL                 )-1:0] clk_qdeny_i,
  input  logic [(NUM_Q_CHL+NUM_QACTIVE_ONLY)-1:0] clk_qactive_i,

  // ---- Table A-25 ----
  output logic       clken_o,        // 1 = the downstream clock may run
  input  logic       clk_force_i,    // 1 = disable the clock gating mechanism
  input  logic [7:0] entry_delay_i,  // 0-255 clk cycles of entry hysteresis

  // ---- Table A-26 ----
  input  logic dftcgen             // 1 = hold the architectural gates open
);

  localparam int unsigned NUM_ACT = NUM_Q_CHL + NUM_QACTIVE_ONLY;

  // Table A-24 makes clk_qacceptn_i/clk_qdeny_i "clk" when CLK_Q_CH_SYNC == 0,
  // i.e. the integration declares them already synchronous. Zero stages is then
  // the correct depth, not a shortcut.
  localparam int unsigned CLK_CH_STAGES = CLK_Q_CH_SYNC ? SYNC_STAGES : 0;

  // Table 3-7's permitted ranges, checked rather than assumed. Same style and
  // same reason as ppu_top's mode-support dependency checks: a parameter set
  // outside its range produces a design that elaborates and is wrong.
  initial begin
    if ((NUM_Q_CHL < 1) || (NUM_Q_CHL > 8))
      $fatal(1, "ppu_clk_ctrl: NUM_Q_CHL must be 1-8 (PCK-600 Table 3-7), got %0d",
             NUM_Q_CHL);
    if (NUM_QACTIVE_ONLY > 32)
      $fatal(1, "ppu_clk_ctrl: NUM_QACTIVE_ONLY must be 0-32 (PCK-600 Table 3-7), got %0d",
             NUM_QACTIVE_ONLY);
  end

  // ---------------------------------------------------------------------------
  // Activity
  //
  // Two views of the same bus, and the split is deliberate.
  //
  // The COMBINATIONAL view drives the two hierarchical QACTIVE outputs. Tables
  // A-22 and A-23 give their Clock column as "Asynchronous", and Table 3-7's
  // note under ACTIVE_DENY_EN is explicit: "The path from a device to the
  // controller QACTIVE is combinatorial, irrespective of whether synchronizers
  // are present." A registered hc_qactive_o would also be wrong for the same
  // reason qchannel_device_comb's header gives -- an upstream controller that has
  // gated THIS block's clk could never be told to ungate it.
  //
  // The INTERNAL view is what this block makes decisions on, and that one is
  // synchronized when CLK_QACTIVE_SYNC is set, because clk_qactive_i arrives
  // from asynchronous device domains and a metastable bit here would corrupt
  // the entry counter.
  // ---------------------------------------------------------------------------
  logic any_active_comb;
  assign any_active_comb = |clk_qactive_i;

  logic [NUM_ACT-1:0] qactive_int;

  generate
    if (CLK_QACTIVE_SYNC) begin : g_act_sync
      for (genvar a = 0; a < NUM_ACT; a++) begin : g_act
        cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
        u_act (.clk(clk), .rst_n(reset_n), .d(clk_qactive_i[a]), .q(qactive_int[a]));
      end
    end else begin : g_act_direct
      assign qactive_int = clk_qactive_i;
    end
  endgenerate

  logic any_active;
  assign any_active = |qactive_int;

  // ---------------------------------------------------------------------------
  // Quiescence entry hysteresis (Table A-25)
  //
  // "You can apply 0-255 clk cycles of hysteresis to the quiescence entry, by
  // altering the state of the entry_delay_i[7:0] configuration input."
  //
  // Counting idle cycles and comparing, rather than loading a down-counter, so
  // that entry_delay_i = 0 genuinely means no hysteresis: the request may
  // assert on the first idle cycle. A down-counter reloaded on activity spends
  // a cycle at zero before it can be read and turns 0 into 1.
  //
  // The counter saturates instead of wrapping. Without that, a domain idle for
  // 256 cycles would look freshly busy again and the request would drop.
  // ---------------------------------------------------------------------------
  // ---------------------------------------------------------------------------
  // The two Table A-25 inputs are ASYNCHRONOUS, and both are sampled by flops
  // ---------------------------------------------------------------------------
  // Table A-25 gives clk_force_i and entry_delay_i[7:0] a Clock column of
  // "Asynchronous", with no parameter to say otherwise. That makes them the
  // only asynchronous inputs on this block with no declared domain: every other
  // one is governed by HC_Q_CH_SYNC, PWR_Q_CH_SYNC, CLK_Q_CH_SYNC or
  // CLK_QACTIVE_SYNC, each of which lets the integration declare the signal
  // synchronous instead.
  //
  // They were previously used raw, straight into idle_cnt and clk_running. A
  // metastable clk_running is a glitch on clken_o, which is a glitch on a GATED
  // CLOCK -- the one output where a transient is not merely a wrong value.
  //
  // clk_force_i is the sharp one: a runtime override, so it genuinely toggles
  // asynchronously. A plain two-flop synchronizer is sufficient, the signal
  // being a level with no coherency requirement.
  //
  // entry_delay_i is a BUS, and synchronizing a bus bit-wise admits a transient
  // mix of old and new bits while it changes. That is acceptable here, and only
  // because of what it is used for: the sole consumer is the threshold compare
  // below, re-evaluated every cycle, which self-corrects the moment the bits
  // settle. A transient wrong threshold shifts one entry by a few cycles; it
  // cannot corrupt anything and leaves no state inconsistent. The signal is a
  // configuration input and quasi-static in any real use.
  //
  // dftcgen is NOT here: Table A-26 gives it a Clock column of "clk", so it is
  // synchronous by contract and needs nothing.
  logic       clk_force_s;
  logic [7:0] entry_delay_s;

  cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_force_sync (.clk(clk), .rst_n(reset_n), .d(clk_force_i), .q(clk_force_s));

  generate
    for (genvar e = 0; e < 8; e++) begin : g_edly
      cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
      u_edly (.clk(clk), .rst_n(reset_n), .d(entry_delay_i[e]), .q(entry_delay_s[e]));
    end
  endgenerate

  logic [7:0] idle_cnt;

  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n)                       idle_cnt <= 8'h00;
    else if (any_active || clk_force_s) idle_cnt <= 8'h00;
    else if (idle_cnt != 8'hFF)         idle_cnt <= idle_cnt + 8'd1;
  end

  logic local_req;
  assign local_req = !any_active && !clk_force_s && (idle_cnt >= entry_delay_s);

  // ---------------------------------------------------------------------------
  // The two hierarchical control channels (Tables A-22, A-23)
  //
  // On these two the CLK-CTRL is a DEVICE, not a controller: an upstream clock
  // or power controller asks IT to become quiescent, and it answers for the
  // whole clock domain. Both are wired identically and differ only in which
  // upstream block owns them, which is why PCK-600 gives them separate names
  // and identical signal tables.
  //
  //   dev_active  any device is active -> straight out on QACTIVE
  //   dev_deny    a downstream device refused, or -- when ACTIVE_DENY_EN --
  //               activity arrived while the entry was in progress
  //   dev_busy    the downstream channels have not all reached Q_STOPPED yet.
  //               This is the load-bearing one: without it the CLK-CTRL would
  //               tell its upstream controller "quiescent" while its own
  //               devices were still running.
  // ---------------------------------------------------------------------------
  logic all_stopped, any_denied;
  logic hc_req, hc_stopped, pwr_req, pwr_stopped;

  logic up_deny;
  assign up_deny = any_denied || (ACTIVE_DENY_EN && any_active);

  qchannel_device_comb #(.Q_CH_SYNC(HC_Q_CH_SYNC), .SYNC_STAGES(SYNC_STAGES)) u_hc (
    .clk  (clk),
    .rst_n(reset_n),

    .qreqn   (hc_qreqn_i),
    .qacceptn(hc_qacceptn_o),
    .qdeny   (hc_qdeny_o),
    .qactive (hc_qactive_o),

    .dev_active      (any_active_comb),
    .dev_deny        (up_deny),
    .dev_busy        (!all_stopped),
    .dev_quiescent_ok(hc_stopped),
    .q_requested     (hc_req)
  );

  qchannel_device_comb #(.Q_CH_SYNC(PWR_Q_CH_SYNC), .SYNC_STAGES(SYNC_STAGES)) u_pwr (
    .clk  (clk),
    .rst_n(reset_n),

    .qreqn   (pwr_qreqn_i),
    .qacceptn(pwr_qacceptn_o),
    .qdeny   (pwr_qdeny_o),
    .qactive (pwr_qactive_o),

    .dev_active      (any_active_comb),
    .dev_deny        (up_deny),
    .dev_busy        (!all_stopped),
    .dev_quiescent_ok(pwr_stopped),
    .q_requested     (pwr_req)
  );

  // ---------------------------------------------------------------------------
  // The request policy
  //
  // Three sources, in priority order:
  //
  //   up_hold   INTERPRETATION 1 (see the header): this is the branch that
  //             contradicts a literal reading of Section 3.5.
  //             An upstream controller has already been told this domain is
  //             quiescent. The devices must STAY down even if one of them goes
  //             active, because the upstream controller may already have acted
  //             on the acceptance -- removing power, in the pwr_ case. The way
  //             out is not to un-quiesce unilaterally; it is hc_qactive_o /
  //             pwr_qactive_o, which is exactly the signal Tables A-22 and A-23
  //             define as "one or more CLK-CTRL devices are active or they are
  //             requesting to exit from quiescence".
  //
  //   up_req    an upstream controller is ASKING. Push the devices down so the
  //             answer can be given, unless ACTIVE_DENY_EN says activity
  //             should abort the attempt instead.
  //
  //   local_req the domain has been idle for entry_delay_i cycles. This is the
  //             ordinary clock-gating path and the only one clk_force_i
  //             disables -- clk_force_i turns off the GATING MECHANISM
  //             (Table A-25), not this block's obligation to answer a
  //             hierarchical controller.
  // ---------------------------------------------------------------------------
  logic up_req, up_hold, abort, base_req;

  // INTERPRETATION 2 (see the header): the OR here and the implicit AND on exit
  // -- devices are released only when NEITHER upstream channel is holding --
  // are LPC-Q's documented rule borrowed. PCK-600 does not give the CLK-CTRL
  // one.
  assign up_req  = hc_req || pwr_req;
  assign up_hold = hc_stopped || pwr_stopped;
  assign abort   = ACTIVE_DENY_EN && any_active;
  assign base_req = up_hold ? 1'b1 : ((up_req || local_req) && !abort);

  // ---------------------------------------------------------------------------
  // Downstream denials
  //
  // Synchronized because clk_qdeny_i comes from the device domains. Latched
  // because a denial is a decision about a request, not a level: by the time
  // the controller has walked Q_DENIED -> Q_CONTINUE -> Q_RUN the pin is LOW
  // again, and without the latch the block would immediately re-ask.
  //
  // Cleared when base_req falls -- activity resumed, the hysteresis restarted,
  // or the upstream controller withdrew -- AND on a retry backoff, which is the
  // half that was missing.
  //
  // WHY THE BACKOFF IS NOT OPTIONAL
  //
  // base_req stays HIGH for as long as the domain is idle, and idle is exactly
  // when gating is wanted. So "clear when base_req falls" alone means a device
  // that refuses once and then becomes willing is never asked again: deny_seen
  // stays set, ch_req stays LOW, all_stopped is never true, and clken_o stays
  // HIGH forever. The clock gating is silently dead.
  //
  // It usually hid because a device that denies typically also asserts QACTIVE,
  // which drops base_req and clears the latch as a side effect. That is a habit
  // of device design, not a guarantee -- qchannel_device_comb deliberately separates
  // dev_deny from dev_active, so the device model in this repository can reach
  // it.
  // ---------------------------------------------------------------------------
  logic [NUM_Q_CHL-1:0] qdeny_int;

  generate
    for (genvar d = 0; d < NUM_Q_CHL; d++) begin : g_deny
      cdc_sync #(.STAGES(CLK_CH_STAGES), .RESET_VAL(1'b0))
      u_deny (.clk(clk), .rst_n(reset_n), .d(clk_qdeny_i[d]), .q(qdeny_int[d]));
    end
  endgenerate

  logic [NUM_Q_CHL-1:0] deny_seen;
  logic [7:0]           retry_cnt;
  logic                 retry_now;

  // The backoff runs from the END of the denied handshake, not from its start:
  // qdeny_int is a level and the device holds it HIGH through Q_DENIED and
  // Q_CONTINUE, so this counter is pinned at zero until the channel is back in
  // Q_RUN and genuinely idle again.
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n)                         retry_cnt <= 8'h00;
    else if (!any_denied || (|qdeny_int)) retry_cnt <= 8'h00;
    else if (retry_cnt != 8'(DENY_RETRY_DLY)) retry_cnt <= retry_cnt + 8'd1;
  end

  assign retry_now = any_denied && (retry_cnt == 8'(DENY_RETRY_DLY));

  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n)                    deny_seen <= '0;
    else if (!base_req || retry_now) deny_seen <= '0;
    else                             deny_seen <= deny_seen | qdeny_int;
  end

  assign any_denied = |deny_seen;

  // ---------------------------------------------------------------------------
  // Clock guarantee
  //
  // clk_running is the whole ordering argument in one flip-flop.
  //
  // ENTRY. It can only go LOW on a cycle where all_stopped was already HIGH,
  // so the gate closes at least one full cycle AFTER every device channel has
  // reached Q_STOPPED. Section 3.1: "Only remove clock or power when the
  // interface is in the Q_STOPPED state."
  //
  // EXIT. ch_req below is held asserted while clk_running is LOW, so no
  // controller may leave Q_STOPPED until the gate is open. The sequence is
  // therefore clken_o HIGH at edge N, QREQn HIGH at edge N+1 -- the clock is
  // running a full cycle before the device is told to come back, which is what
  // Section 2.1.2's Q_EXIT guarantee and PCK-600 Section 3.5 both require.
  //
  // Deriving clken_o combinationally from all_stopped would collapse both
  // margins to zero: the gate would close on the same edge the last device
  // accepted and open on the same edge QREQn rose.
  //
  // Reset value is HIGH. A gate that reset closed would deny the clock to
  // devices whose own reset sequencing needs it, and Section 2.1.2's permitted
  // reset exits both assume the controller is in a position to honour the
  // supply guarantee.
  // ---------------------------------------------------------------------------
  logic [NUM_Q_CHL-1:0] dev_stopped;
  assign all_stopped = &dev_stopped;

  logic clk_running;

  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n) clk_running <= 1'b1;
    else          clk_running <= clk_force_s | dftcgen | !base_req | !all_stopped;
  end

  assign clken_o = clk_running;

  // Per-channel request. The deny_seen term drops the request on a channel that
  // has refused; the clk_running term is the exit interlock above. They cannot
  // conflict: clk_running only goes LOW when every channel is in Q_STOPPED, and
  // a channel that denied is in Q_RUN, so deny_seen is necessarily 0 whenever
  // the second term is active.
  logic [NUM_Q_CHL-1:0] ch_req;
  assign ch_req = (base_req ? ~deny_seen : {NUM_Q_CHL{1'b0}})
                | {NUM_Q_CHL{~clk_running}};

  // ---------------------------------------------------------------------------
  // One controller per device (Table A-24, LPI Section 4.1.2)
  //
  // Both QACTIVE policy inputs are tied LOW and the request comes from ch_req
  // instead. This is the same choice ppu_top makes on its device interface, for
  // a related reason: letting a channel leave Q_STOPPED on its own QACTIVE
  // would put it in a running state before clken_o had been restored, which is
  // the one thing the interlock above exists to prevent.
  // ---------------------------------------------------------------------------
  generate
    for (genvar c = 0; c < NUM_Q_CHL; c++) begin : g_chl
      qchannel_controller #(.SYNC_STAGES(CLK_CH_STAGES)) u_ctrl (
        .clk  (clk),
        .rst_n(reset_n),

        .qreqn   (clk_qreqn_o[c]),
        .qacceptn(clk_qacceptn_i[c]),
        .qdeny   (clk_qdeny_i[c]),
        .qactive (clk_qactive_i[c]),

        .req_dev_quiescence              (ch_req[c]),
        .enb_qactive_led_quiescence_enter(1'b0),
        .enb_qactive_led_quiescence_exit (1'b0),
        .dev_stopped                     (dev_stopped[c])
      );
    end
  endgenerate

endmodule
