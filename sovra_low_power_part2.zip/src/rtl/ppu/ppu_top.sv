`timescale 1ns/1ps
// Power Policy Unit -- top-level integration.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E), Chapter 6 "Signal Descriptions".
//
// Configuration: a SINGLE-Q-CHANNEL PPU (DEVCHAN_CFG = 1) with no operating
// modes, supporting WARM_RST, ON, FUNC_RET, MEM_OFF, FULL_RET, MEM_RET and OFF
// -- exactly the mode set Figure 3-2 makes available to a Q-Channel PPU, minus
// the two optional emulation modes. See rtl/ppu/README.md.
//
//   software ──► ppu_regs ──policy/config──► ppu_seq ──┬──► qchannel_controller ══► device
//                    ▲                          │      │        (DEVQREQn / DEVQACCEPTn
//                    │ status                   │      │         / DEVQDENY / DEVQACTIVE)
//                    └──────────────────────────┘      │
//                    ▲                          │      ├──► DEVCLKEN / DEVISOLATEn
//                 ppu_irq ◄────── events ───────┘      │    / DEV*RESETn / PPUHWSTAT
//                    │                                 │
//                    └──► IRQ                          └──► pchannel_controller ══► PCSM
//                                                              (PCSMPSTATE / PCSMPREQ
//                                                               / PCSMPACCEPT)
//
// TWO PROTOCOL ENGINES, NEITHER OF THEM NEW
//
// The device interface is a Q-Channel and the PCSM interface is a P-Channel --
// independent choices, per Section 2.2: "The interface between the PPU and the
// PCSM is a P-Channel", regardless of what the device interface is. Both
// engines already exist in this repository and are instantiated UNMODIFIED:
//
//   qchannel_controller  its four ports are exactly the PPU's device interface
//   pchannel_controller  generic enough to be configured into a PCSM master,
//                        which is a P-Channel with no PDENY and no PACTIVE
//                        (Section 4.1.6: "It has no PDENY or PACTIVE signals")
//
// The PCSM configuration is three tie-offs rather than a variant module: pdeny
// tied LOW so the denial path is unreachable, pactive tied LOW with
// enb_pactive_led_transition LOW so the Section 2.2.3 activity-led path never
// arbitrates, leaving only the explicit req_state/req_valid path the sequencer
// drives. PSTATE_W = 16 carries the whole PCSMPSTATE, retention configuration
// included.
//
// WHY THIS FILE SYNCHRONIZES SIGNALS THE CONTROLLER ALREADY SYNCHRONIZES
//
// qchannel_controller has its own synchronizers on DEVQACCEPTn, DEVQDENY and
// DEVQACTIVE, but keeps the results private. Three consumers here need them
// too: PPU_DISR and PPU_MISR report the input status to software, ppu_irq
// edge-detects DEVQACTIVE, and ppu_seq needs DEVQACTIVE for dynamic
// transitions and DEVQDENY to notice a denial.
//
// A second synchronizer on the same wire is the right answer rather than a
// duplication to be embarrassed about: independent synchronizers are how
// multi-consumer CDC is normally built, and the alternative -- adding output
// ports to a controller that two other top levels already instantiate and that
// has its own verified testbench -- changes a proven block to save a handful of
// flops. pchannel_controller took the other route for its PACTIVE floor
// (pactive_floor_state), and the difference is that there the export exists
// only because the SAME decode would otherwise be duplicated, not the same
// synchronizer.
//
// The one thing that genuinely cannot be re-derived is the Q-Channel's Q_RUN
// state, so it is decoded here from the wires instead: DEVQREQn is this
// domain's own registered output and the other two are synchronized above, so
// qch_decode sees exactly what the controller's FSM sees.

import ppu_pkg::*;
import qchannel_pkg::*;

module ppu_top #(
  // ---------------------------------------------------------------------------
  // Ordered the way the specification's register tables are: by the offset of
  // the register each parameter is visible in, then by bit position within it,
  // high to low. Chapter 7 lists the configuration options by function, but a
  // parameter's observable effect is a register field, and grouping by that
  // makes "what does software see if I change this" answerable by looking one
  // line to the right. The comment on each line is its field.
  //
  // Parameters with no software-visible register are at the end, marked as such,
  // rather than interleaved where they would have no offset to sort by.
  // ---------------------------------------------------------------------------

  // ---- PPU_PWPR, 0x000 (Table 5-2) -- reset values ----
  // Section 7.1.3. ON means the PPU brings the domain up out of reset itself
  // (Figure 4-18); OFF means it stays down until software asks.
  parameter bit          DEF_PWR_DYN_EN        = 1'b0,    // [8]     PWR_DYN_EN
  parameter logic [3:0]  DEF_PWR_POLICY        = PM_ON,   // [3:0]   PWR_POLICY

  // ---- PPU_PTCR, 0x024 (Table 5-12) -- reset value ----
  // Section 7.1.6: whether ON <-> WARM_RST performs a device handshake at all.
  parameter bit          WARM_RST_DEVREQEN_CFG = 1'b1,    // [0]     WARM_RST_DEVREQEN

  // ---- PPU_DCDR0, 0x170 (Table 5-24) -- reset values ----
  // Section 7.1.4. Table 4-5 defines each as "minimum number of PPU clock
  // cycles ... is <PARAM> + 1", so 0 is legal and means one cycle.
  parameter logic [7:0]  RST_HWSTAT_DLY_CFG    = 8'd2,    // [23:16] RST_HWSTAT_DLY
  parameter logic [7:0]  ISO_CLKEN_DLY_CFG     = 8'd2,    // [15:8]  ISO_CLKEN_DLY
  parameter logic [7:0]  CLKEN_RST_DLY_CFG     = 8'd2,    // [7:0]   CLKEN_RST_DLY

  // ---- PPU_DCDR1, 0x174 (Table 5-25) -- reset values ----
  parameter logic [7:0]  CLKEN_ISO_DLY_CFG     = 8'd2,    // [15:8]  CLKEN_ISO_DLY
  parameter logic [7:0]  ISO_RST_DLY_CFG       = 8'd2,    // [7:0]   ISO_RST_DLY

  // ---- PPU_IDR0, 0xFB0 (Table 5-26) -- mode support ----
  // Table 7-4 for the dynamic half, Table 7-1 for the static half. ON, OFF and
  // WARM_RST have no parameter because Section 7.1.7 makes them always
  // supported, and there is no DYN_WRM_RST_SPT_CFG because that is Table 7-5,
  // which is P-Channel only. Gaps in the bit numbering below are the modes this
  // build does not have: LOGIC_RET and DBG_RECOV are P-Channel only, and the
  // four EMU bits need emulation modes.
  parameter bit          DYN_ON_SPT_CFG        = 1'b1,    // [28]    DYN_ON_SPT
  parameter bit          DYN_FUNC_RET_SPT_CFG  = 1'b1,    // [27]    DYN_FUNC_RET_SPT
  parameter bit          DYN_FULL_RET_SPT_CFG  = 1'b1,    // [26]    DYN_FULL_RET_SPT
  parameter bit          DYN_MEM_OFF_SPT_CFG   = 1'b1,    // [25]    DYN_MEM_OFF_SPT
  parameter bit          DYN_MEM_RET_SPT_CFG   = 1'b1,    // [22]    DYN_MEM_RET_SPT
  parameter bit          DYN_OFF_SPT_CFG       = 1'b1,    // [20]    DYN_OFF_SPT
  parameter bit          STA_FUNC_RET_SPT_CFG  = 1'b1,    // [15]    STA_FUNC_RET_SPT
  parameter bit          STA_FULL_RET_SPT_CFG  = 1'b1,    // [14]    STA_FULL_RET_SPT
  parameter bit          STA_MEM_OFF_SPT_CFG   = 1'b1,    // [13]    STA_MEM_OFF_SPT
  parameter bit          STA_MEM_RET_SPT_CFG   = 1'b1,    // [10]    STA_MEM_RET_SPT

  // ---- PPU_IDR1, 0xFB4 (Table 5-27) -- optional features ----
  // Note the asymmetry the specification deliberately keeps: the parameter ends
  // in _CFG, the field it drives does not. LOCK_CFG is the parameter and
  // PPU_IDR1[2] is LOCK_SPT.
  parameter bit          OFF_MEM_RET_TRANS_CFG = 1'b1,    // [12]    OFF_MEM_RET_TRANS
  parameter bit          FUNC_RET_RAM_REG_CFG  = 1'b1,    // [6]     FUNC_RET_RAM_REG
  parameter bit          FULL_RET_RAM_REG_CFG  = 1'b1,    // [5]     FULL_RET_RAM_REG
  parameter bit          MEM_RET_RAM_REG_CFG   = 1'b1,    // [4]     MEM_RET_RAM_REG
  parameter bit          LOCK_CFG              = 1'b1,    // [2]     LOCK_SPT
  parameter bit          SW_DEV_DEL_CFG        = 1'b1,    // [1]     SW_DEV_DEL_SPT
  parameter bit          PWR_MODE_ENTRY_DEL_CFG= 1'b1,    // [0]     PWR_MODE_ENTRY_DEL_SPT

  // ---- PPU_IIDR, 0xFC8 (Table 5-28) -- IMPLEMENTATION DEFINED identity ----
  // IMPLEMENTER is 0x000 rather than Arm's JEP106 code 0x43B on purpose:
  // claiming 0x43B in a PPU Arm did not produce would misidentify the part to
  // any software that reads it. A real integration sets its own.
  parameter logic [11:0] IIDR_PRODUCT_ID       = 12'h50C, // [31:20] PRODUCT_ID
  parameter logic [3:0]  IIDR_VARIANT          = 4'h0,    // [19:16] VARIANT
  parameter logic [3:0]  IIDR_REVISION         = 4'h1,    // [15:12] REVISION
  parameter logic [11:0] IIDR_IMPLEMENTER      = 12'h000, // [11:0]  IMPLEMENTER

  // ---- Not visible in any register ----
  // Integration choices rather than architectural ones, so no offset to sort by.
  parameter int unsigned SYNC_STAGES           = 2,

  // ---- PCK-600 Table 3-7: WHICH crossings are real ----
  //
  // Three parameters Arm's PPU has and this one did not, with the consequence
  // that every synchronizer here was unconditional -- including the ones on a
  // path that has no clock domain crossing at all.
  //
  // Each says the same thing in a different place: "the integration knows these
  // two ends share a clock, so do not spend two cycles and two flops proving
  // otherwise." cdc_sync takes STAGES = 0 as a combinational passthrough, so
  // clearing one genuinely removes the registers rather than bypassing them.
  //
  //   DEV_SYNC_EN         dev_qacceptn / dev_qdeny
  //   DEV_ACTIVE_SYNC_EN  dev_qactive
  //   PCSM_SYNC_EN        pcsm_paccept, and the PCSM P-Channel generally
  //
  // ALL THREE DEFAULT TO 1, which is the safe answer for a module that cannot
  // see its own integration. ppu_pd_top clears PCSM_SYNC_EN because IT is what
  // wires the PPU and the PCSM to the same aon_clk; nothing architectural does.
  // PCSA 7.2.3 constrains the PCSM's POWER domain -- "a power domain that is
  // relative always-on to the power domain it is controlling" -- and says
  // nothing whatsoever about clocks.
  //
  // DEV_ACTIVE_SYNC_EN HAS A SECOND CONSUMER. u_clkq's dev_deny is built from
  // sync_dev_qactive precisely so an asynchronous DEVQACTIVE is not sampled by
  // a flop; see the note there. Clearing this parameter when the device is
  // genuinely in another clock domain reintroduces that crossing. It is only
  // safe to clear when the device shares the PPU's clock, which is the same
  // condition that makes it worth clearing.
  parameter bit          DEV_SYNC_EN           = 1'b1,
  parameter bit          DEV_ACTIVE_SYNC_EN    = 1'b1,
  parameter bit          PCSM_SYNC_EN          = 1'b1,

  // PCK-600 Table 3-7. Selects whether PPUCLKQREQn is synchronized before the
  // clock Q-Channel FSM samples it. 1 is the safe default and the only correct
  // setting unless the clock controller is provably synchronous to clk.
  parameter bit          QCLK_SYNC_EN          = 1'b1,

  // Section 4.1.6 "PCSM P-Channel Reset": "The PCSMPSTATE output is reset to the
  // default power mode of the PPU... This ensures that the reset value is
  // sampled by the PCSM before any other transition is allowed on the
  // interface."
  //
  // That reset value cannot come from the pcsm_modestat PIN, because it is the
  // RESET_STATE of a module instantiated below and therefore an elaboration
  // constant. It has to be a parameter, and it must agree with however
  // pcsm_modestat is tied off -- which is legitimate, since the pin is "only
  // sampled by the PPU at reset release" and cannot legally change afterwards.
  // The initial block below checks the two agree rather than trusting it.
  parameter logic [3:0]  PCSM_RESET_MODESTAT   = PM_OFF,

  // The PCSM's published tinit, in PPU clock cycles (AMBA LPI Section 2.2.2).
  parameter int unsigned PCSM_TINIT_WAIT       = 16
) (
  // ---- Section 6.1 ----
  input logic clk,
  input logic rst_n,

  // ---- Section 6.2: software interface (generic strobe; see ppu_regs) ----
  // Independent write and read address buses, so an AXI4-Lite bridge can have
  // one of each outstanding without arbitrating between them.
  input  logic [11:0] reg_waddr,
  input  logic [31:0] reg_wdata,
  input  logic [ 3:0] reg_wstrb,  // byte lanes; tie to 4'hF for word-only masters
  input  logic        reg_wen  ,
  input  logic [11:0] reg_raddr,
  input  logic        reg_ren  ,
  output logic [31:0] reg_rdata,

  output logic irq,

  // ---- Clock control interface: the PPU as a Q-Channel DEVICE ----
  //
  // NOT IN DEN 0051E. Table 6-1 gives the PPU one clock and one reset, and the
  // architecture says nothing about gating either. This is the interface Arm's
  // own PPU adds on top -- PCK-600 Section 3.6 lists a "Clock control
  // interface: For high-level clock control" beside the software, device and
  // PCSM interfaces, and Table A-29 names the four signals. It is implemented
  // here because a PPU is idle almost all the time and is in the always-on
  // domain by construction (PCSA 7.2.3), so its own clock is pure leakage
  // between transitions -- and a system with a PPU per domain has one of these
  // running for every domain it manages.
  //
  // The direction is the one that surprises: the PPU is the DEVICE. Its device
  // interface below makes it a Q-Channel controller; this makes it a Q-Channel
  // device to a clock controller sitting above it. Both roles at once is
  // ordinary -- ppu_clk_ctrl does the same thing.
  //
  // PPUCLKQACTIVE is asynchronous and combinational; qchannel_device_comb's header
  // explains at length why it cannot be anything else.
  input  logic ppuclk_qreqn   ,  // async when QCLK_SYNC_EN
  output logic ppuclk_qacceptn,  // registered
  output logic ppuclk_qdeny   ,  // registered
  output logic ppuclk_qactive ,  // combinational

  // PCK-600 Table A-28. On an APB PPU this is the bus's own PWAKEUP, and the
  // TRM's constraint travels with it: "This signal must be driven from a
  // register." This PPU's software interface is a generic strobe rather than
  // APB (Section 6.2 leaves the bus choice open), so the signal is exposed as
  // a port for the bus adapter to drive.
  //
  // It has to lead the access it announces. With the clock gated the register
  // file cannot capture a write or answer a read, and nothing in the Q-Channel
  // handshake is fast enough to be discovered at the same instant as REG_WEN.
  input  logic pwakeup,

  // ---- Section 6.3: device interface, one Q-Channel ----
  output logic dev_qreqn   ,  // registered by qchannel_controller
  input  logic dev_qacceptn,  // async
  input  logic dev_qdeny   ,  // async
  input  logic dev_qactive ,  // async

  // ---- Section 6.4: device control signals ----
  output logic [15:0] ppuhwstat    ,
  output logic        dev_clken     ,
  output logic        dev_poresetn  ,
  output logic        dev_retresetn ,
  output logic        dev_warmresetn,
  output logic        dev_isolaten  ,

  // ---- Section 6.5: PCSM interface ----
  output logic [15:0] pcsm_pstate,
  output logic        pcsm_preq,
  input  logic        pcsm_paccept,   // async
  // Section 4.1.6: present only when OFF -> MEM_RET direct transitions are
  // supported, sampled once at reset release, and only the OFF (0x0) and
  // MEM_RET (0x2) encodings are legal on [3:0].
  input logic [7:0] pcsm_modestat
);

  // ---------------------------------------------------------------------------
  // Device-interface signals brought into the PPU clock domain
  // ---------------------------------------------------------------------------
  // Zero stages is not "no synchronizer bypassed" -- cdc_sync collapses to a
  // wire, so the flops are genuinely absent from synthesis.
  localparam int unsigned DEV_STAGES    = DEV_SYNC_EN        ? SYNC_STAGES : 0;
  localparam int unsigned DEVACT_STAGES = DEV_ACTIVE_SYNC_EN ? SYNC_STAGES : 0;
  localparam int unsigned PCSM_STAGES   = PCSM_SYNC_EN       ? SYNC_STAGES : 0;

  logic sync_dev_qacceptn, sync_dev_qdeny, sync_dev_qactive;

  cdc_sync #(.STAGES(DEV_STAGES), .RESET_VAL(1'b0))
  sync_acc (.clk(clk), .rst_n(rst_n), .d(dev_qacceptn), .q(sync_dev_qacceptn)),
  sync_den (.clk(clk), .rst_n(rst_n), .d(dev_qdeny   ), .q(sync_dev_qdeny   ));

  cdc_sync #(.STAGES(DEVACT_STAGES), .RESET_VAL(1'b0))
  sync_act (.clk(clk), .rst_n(rst_n), .d(dev_qactive ), .q(sync_dev_qactive ));

  logic sync_pcsm_paccept;
  cdc_sync #(.WIDTH(1), .STAGES(PCSM_STAGES), .RESET_VAL(1'b0))
  sync_pacc (.clk(clk), .rst_n(rst_n), .d(pcsm_paccept), .q(sync_pcsm_paccept));

  // Q_RUN, decoded from the same three bits the controller's own FSM sees.
  logic dev_q_run;
  assign dev_q_run = (qch_decode(dev_qreqn, sync_dev_qacceptn, sync_dev_qdeny) == Q_RUN);

  // ---------------------------------------------------------------------------
  // PCSMMODESTAT (Section 4.1.6, Table 4-13)
  //
  // Sampled at reset release only. Only OFF and MEM_RET are legal, so anything
  // else is read as OFF -- which is also the defined behaviour when the signal
  // is absent entirely ("Where the PCSMMODESTAT is not present the behavior is
  // as if it is set to OFF"). When the direct OFF -> MEM_RET hop is not built
  // the input does not exist and the reset mode is unconditionally OFF.
  // ---------------------------------------------------------------------------
  // The two support masks, built once from the Table 7-1 / Table 7-4 parameters
  // and handed down. Everything that asks "is this mode supported" consults
  // these rather than a hardwired list.
  localparam logic [15:0] STA_MASK = ppu_sta_mask(STA_FUNC_RET_SPT_CFG,
                                                  STA_MEM_OFF_SPT_CFG,
                                                  STA_FULL_RET_SPT_CFG,
                                                  STA_MEM_RET_SPT_CFG);
  localparam logic [15:0] DYN_MASK = ppu_dyn_mask(DYN_ON_SPT_CFG,
                                                  DYN_FUNC_RET_SPT_CFG,
                                                  DYN_MEM_OFF_SPT_CFG,
                                                  DYN_FULL_RET_SPT_CFG,
                                                  DYN_MEM_RET_SPT_CFG,
                                                  DYN_OFF_SPT_CFG);

  // Elaboration checks for the dependencies the specification states.
  //
  // Section 3.4.3: "To allow a dynamic transition to a power mode that must pass
  // through intermediate power modes, these intermediate power modes must also
  // support dynamic transitions." On a Q-Channel PPU every route is anchored on
  // ON, so dynamic support for anything at all requires dynamic ON.
  //
  // And a mode cannot support dynamic transitions without supporting static
  // ones -- Table 7-4's parameters select transitions TO a mode Table 7-1 had to
  // provide first.
  initial begin
    if ((DYN_MASK != 16'h0) && !DYN_ON_SPT_CFG)
      $fatal(1, "ppu_top: dynamic support requires DYN_ON_SPT_CFG -- every dynamic route on a Q-Channel PPU passes through ON (Section 3.4.3)");
    if (DYN_FUNC_RET_SPT_CFG && !STA_FUNC_RET_SPT_CFG)
      $fatal(1, "ppu_top: DYN_FUNC_RET_SPT_CFG set without STA_FUNC_RET_SPT_CFG");
    if (DYN_MEM_OFF_SPT_CFG  && !STA_MEM_OFF_SPT_CFG)
      $fatal(1, "ppu_top: DYN_MEM_OFF_SPT_CFG set without STA_MEM_OFF_SPT_CFG");
    if (DYN_FULL_RET_SPT_CFG && !STA_FULL_RET_SPT_CFG)
      $fatal(1, "ppu_top: DYN_FULL_RET_SPT_CFG set without STA_FULL_RET_SPT_CFG");
    if (DYN_MEM_RET_SPT_CFG  && !STA_MEM_RET_SPT_CFG)
      $fatal(1, "ppu_top: DYN_MEM_RET_SPT_CFG set without STA_MEM_RET_SPT_CFG");
    // Section 7: the direct hop and PCSMMODESTAT only mean anything if MEM_RET
    // exists to hop into.
    if (OFF_MEM_RET_TRANS_CFG && !STA_MEM_RET_SPT_CFG)
      $fatal(1, "ppu_top: OFF_MEM_RET_TRANS_CFG set without STA_MEM_RET_SPT_CFG");
    // Section 7.1.5: "When the power mode related to the register is not
    // supported then the register is always reserved regardless of these
    // parameters."
    if (FUNC_RET_RAM_REG_CFG && !STA_FUNC_RET_SPT_CFG)
      $fatal(1, "ppu_top: FUNC_RET_RAM_REG_CFG set without STA_FUNC_RET_SPT_CFG");
    if (FULL_RET_RAM_REG_CFG && !STA_FULL_RET_SPT_CFG)
      $fatal(1, "ppu_top: FULL_RET_RAM_REG_CFG set without STA_FULL_RET_SPT_CFG");
    if (MEM_RET_RAM_REG_CFG  && !STA_MEM_RET_SPT_CFG)
      $fatal(1, "ppu_top: MEM_RET_RAM_REG_CFG set without STA_MEM_RET_SPT_CFG");
  end

  logic [3:0] reset_mode;
  assign reset_mode = (
    OFF_MEM_RET_TRANS_CFG &&
    (pcsm_modestat[3:0] == PM_MEM_RET)
  ) ? PM_MEM_RET : PM_OFF;

  // The pin drives the sequencer's initial mode; the parameter drives the PCSM
  // controller's reset PSTATE. They describe the same thing and MUST agree --
  // if they diverge, the PPU and the PCSM start with different ideas of the
  // domain's state, which is precisely the failure Section 4.1.6's reset rule
  // exists to prevent. Checked at time zero rather than assumed.
  initial begin
    if ((PCSM_RESET_MODESTAT != PM_OFF) && (PCSM_RESET_MODESTAT != PM_MEM_RET))
      $fatal(1, "ppu_top: PCSM_RESET_MODESTAT must be OFF or MEM_RET (Section 4.1.6), got %0d",
             PCSM_RESET_MODESTAT);
  end

  // Level-triggered on the pin, with no clock and no reset in the sensitivity.
  // An earlier version wrote this as `always @(posedge clk) if (rst_n && ...)`,
  // which used rst_n SYNCHRONOUSLY while every other block uses it as an
  // asynchronous reset -- Verilator's SYNCASYNCNET caught it, and rightly: a net
  // flopped both ways is a genuine hazard, not a style question. The pin is a
  // constant tie-off, so watching it directly is both simpler and safer.
  always @(pcsm_modestat) begin
    if (!$isunknown(pcsm_modestat[3:0])
        && (pcsm_modestat[3:0] !== PCSM_RESET_MODESTAT))
      $fatal(1, "ppu_top: PCSMMODESTAT pin (%0d) disagrees with PCSM_RESET_MODESTAT (%0d) -- the PPU and the PCSM would start from different states",
             pcsm_modestat[3:0], PCSM_RESET_MODESTAT);
  end

  // ---------------------------------------------------------------------------
  // Register file, interrupt logic, sequencer
  // ---------------------------------------------------------------------------
  logic [3:0] pwr_policy;
  logic       pwr_dyn_en, lock_en, unlock_wr, policy_wr;
  logic       devreqen, devactiveen, warm_rst_devreqen;
  logic [7:0] rst_hwstat_dly, iso_clken_dly, clken_rst_dly, clken_iso_dly, iso_rst_dly;
  logic [7:0] off_del, mem_ret_del, full_ret_del, func_ret_del, mem_off_del;
  logic [7:0] funrr, fulrr, memrr;

  logic [3:0] pwr_status;
  logic       pwr_dyn_status, lock_status;
  logic       revert_vld, revert_dyn_en;
  logic [3:0] revert_policy;

  logic        wr_imr, wr_aimr, wr_isr, wr_aisr, wr_iesr;
  logic [31:0] imr, aimr, isr, aisr, iesr;
  logic        qactive_seen;   // ppu_irq's edge detector's view; see u_clkq
  logic        edge_armed;     // PPU_IESR selects an edge; see u_clkq

  logic ev_unspt_policy;

  ppu_regs #(
    .DEF_PWR_POLICY        (DEF_PWR_POLICY        ),
    .DEF_PWR_DYN_EN        (DEF_PWR_DYN_EN        ),
    .WARM_RST_DEVREQEN_CFG (WARM_RST_DEVREQEN_CFG ),
    .LOCK_CFG              (LOCK_CFG              ),
    .SW_DEV_DEL_CFG        (SW_DEV_DEL_CFG        ),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG ),
    .FUNC_RET_RAM_REG_CFG  (FUNC_RET_RAM_REG_CFG  ),
    .FULL_RET_RAM_REG_CFG  (FULL_RET_RAM_REG_CFG  ),
    .MEM_RET_RAM_REG_CFG   (MEM_RET_RAM_REG_CFG   ),
    .STA_MASK              (STA_MASK              ),
    .DYN_MASK              (DYN_MASK              ),
    .RST_HWSTAT_DLY_CFG    (RST_HWSTAT_DLY_CFG    ),
    .ISO_CLKEN_DLY_CFG     (ISO_CLKEN_DLY_CFG     ),
    .CLKEN_RST_DLY_CFG     (CLKEN_RST_DLY_CFG     ),
    .CLKEN_ISO_DLY_CFG     (CLKEN_ISO_DLY_CFG     ),
    .ISO_RST_DLY_CFG       (ISO_RST_DLY_CFG       ),
    .IIDR_PRODUCT_ID       (IIDR_PRODUCT_ID       ),
    .IIDR_VARIANT          (IIDR_VARIANT          ),
    .IIDR_REVISION         (IIDR_REVISION         ),
    .IIDR_IMPLEMENTER      (IIDR_IMPLEMENTER      )
  )
  u_regs (
    .clk  (clk),
    .rst_n(rst_n),

    // Section 4.1.6: PCSMMODESTAT decides this register file's RESET VALUE.
    .reset_mode (reset_mode),

    // ---- Software interface (Section 6.2), write and read fully independent ----
    .waddr (reg_waddr),
    .wdata (reg_wdata),
    .wstrb (reg_wstrb),
    .wen   (reg_wen  ),
    .raddr (reg_raddr),
    .ren   (reg_ren  ),
    .rdata (reg_rdata),

    // ---- PPU_PWPR out to the sequencer ----
    .pwr_policy(pwr_policy),
    .pwr_dyn_en(pwr_dyn_en),
    .lock_en   (lock_en   ),

    // ---- Single-cycle pulses: PPU_UNLK written, PPU_PWPR accepted ----
    .unlock_wr(unlock_wr),
    .policy_wr(policy_wr),

    // ---- PPU_PWCR / PPU_PTCR: per-transition channel and DEVACTIVE enables ----
    .devreqen         (devreqen         ),
    .devactiveen      (devactiveen      ),
    .warm_rst_devreqen(warm_rst_devreqen),

    // ---- PPU_DCDR0 / PPU_DCDR1: device control delays (Table 4-5) ----
    .rst_hwstat_dly(rst_hwstat_dly),
    .iso_clken_dly (iso_clken_dly ),
    .clken_rst_dly (clken_rst_dly ),
    .clken_iso_dly (clken_iso_dly ),
    .iso_rst_dly   (iso_rst_dly   ),

    // ---- PPU_EDTR0 / PPU_EDTR1: per-mode entry delays ----
    .off_del     (off_del     ),
    .mem_ret_del (mem_ret_del ),
    .full_ret_del(full_ret_del),
    .func_ret_del(func_ret_del),
    .mem_off_del (mem_off_del ),

    // ---- Retention RAM configuration, forwarded into PCSMPSTATE ----
    .funrr(funrr),
    .fulrr(fulrr),
    .memrr(memrr),

    // ---- PPU_PWSR: status back from the sequencer ----
    .pwr_status    (pwr_status    ),
    .pwr_dyn_status(pwr_dyn_status),
    .lock_status   (lock_status   ),

    // ---- Section 4.1.1 denial revert: the sequencer overrides PPU_PWPR ----
    .revert_vld    (revert_vld    ),
    .revert_policy (revert_policy ),
    .revert_dyn_en (revert_dyn_en ),

    // ---- PPU_DISR / PPU_MISR: live pin views, already synchronized ----
    .dev_qactive (sync_dev_qactive ),
    .dev_qacceptn(sync_dev_qacceptn),
    .dev_qdeny   (sync_dev_qdeny   ),
    .pcsm_paccept(sync_pcsm_paccept),

    // ---- Interrupt register write strobes, decoded here and used in ppu_irq ----
    .wr_imr (wr_imr ),
    .wr_aimr(wr_aimr),
    .wr_isr (wr_isr ),
    .wr_aisr(wr_aisr),
    .wr_iesr(wr_iesr),

    // ---- Interrupt register contents, read back through the read mux ----
    .imr (imr ),
    .aimr(aimr),
    .isr (isr ),
    .aisr(aisr),
    .iesr(iesr),

    // ---- The one event the register file raises itself (Section 4.1.1) ----
    .ev_unspt_policy(ev_unspt_policy)
  );

  logic ev_sta_policy_trn, ev_sta_accept, ev_sta_deny;
  logic ev_dyn_accept, ev_dyn_deny, ev_locked;

  ppu_irq #(
    .LOCK_CFG(LOCK_CFG)
  )
  u_irq (
    .clk  (clk),
    .rst_n(rst_n),

    // ---- Write data and byte lanes, straight off the bus ----
    .wdata(reg_wdata),
    .wstrb(reg_wstrb),

    // ---- Which register is being written, decoded by ppu_regs ----
    .wr_imr (wr_imr ),
    .wr_aimr(wr_aimr),
    .wr_isr (wr_isr ),
    .wr_aisr(wr_aisr),
    .wr_iesr(wr_iesr),

    // ---- Register contents, back to ppu_regs for the read mux ----
    .imr (imr ),
    .aimr(aimr),
    .isr (isr ),
    .aisr(aisr),
    .iesr(iesr),

    // ---- Event pulses from the sequencer (Tables 5-15, 5-16) ----
    .ev_sta_policy_trn(ev_sta_policy_trn),
    .ev_sta_accept    (ev_sta_accept    ),
    .ev_sta_deny      (ev_sta_deny      ),
    .ev_locked        (ev_locked        ),
    .ev_dyn_accept    (ev_dyn_accept    ),
    .ev_dyn_deny      (ev_dyn_deny      ),
    .ev_unspt_policy  (ev_unspt_policy  ),

    // ---- DEVACTIVE edge source (PPU_IESR) and the interrupt output ----
    .dev_qactive (sync_dev_qactive),
    .qactive_seen(qactive_seen),
    .irq         (irq)
  );

  logic        req_dev_quiescence, dev_stopped;
  logic [15:0] pcsm_req_state, pcsm_cur_state;
  logic        pcsm_req_valid, pcsm_init_done;

  // The clock Q-Channel's device-internal condition; u_clkq below is where it
  // is explained and used.
  logic        seq_active, ppuclk_needed, ppuclk_deny;

  ppu_seq #(
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG ),
    .LOCK_CFG              (LOCK_CFG              ),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .STA_MASK              (STA_MASK              )
  )
  u_seq (
    .clk  (clk),
    .rst_n(rst_n),

    // ---- Section 4.1.6: the mode the sequencer STARTS in, from PCSMMODESTAT ----
    .reset_mode(reset_mode),

    // ======== In from the register file: everything programmable ========

    // ---- PPU_PWPR: the policy the sequencer is chasing ----
    .pwr_policy(pwr_policy),
    .pwr_dyn_en(pwr_dyn_en),
    .lock_en   (lock_en   ),

    // ---- Single-cycle pulses: PPU_UNLK written, PPU_PWPR accepted ----
    .unlock_wr(unlock_wr),
    .policy_wr(policy_wr),

    // ---- PPU_PWCR / PPU_PTCR: per-transition channel and DEVACTIVE enables ----
    .devreqen         (devreqen         ),
    .devactiveen      (devactiveen      ),
    .warm_rst_devreqen(warm_rst_devreqen),

    // ---- PPU_DCDR0 / PPU_DCDR1: device control delays (Table 4-5) ----
    .rst_hwstat_dly(rst_hwstat_dly),
    .iso_clken_dly (iso_clken_dly ),
    .clken_rst_dly (clken_rst_dly ),
    .clken_iso_dly (clken_iso_dly ),
    .iso_rst_dly   (iso_rst_dly   ),

    // ---- PPU_EDTR0 / PPU_EDTR1: per-mode entry delays ----
    .off_del     (off_del     ),
    .mem_ret_del (mem_ret_del ),
    .full_ret_del(full_ret_del),
    .func_ret_del(func_ret_del),
    .mem_off_del (mem_off_del ),

    // ---- Retention RAM configuration, forwarded into PCSMPSTATE ----
    .funrr(funrr),
    .fulrr(fulrr),
    .memrr(memrr),

    // ======== Out to the register file: status ========

    // ---- PPU_PWSR ----
    .pwr_status    (pwr_status    ),
    .pwr_dyn_status(pwr_dyn_status),
    .lock_status   (lock_status   ),

    // ---- Section 4.1.1 denial revert: the sequencer overrides PPU_PWPR ----
    .revert_vld    (revert_vld   ),
    .revert_policy (revert_policy),
    .revert_dyn_en (revert_dyn_en),

    // ---- Event pulses out to ppu_irq ----
    .ev_sta_policy_trn(ev_sta_policy_trn),
    .ev_sta_accept    (ev_sta_accept    ),
    .ev_sta_deny      (ev_sta_deny      ),
    .ev_dyn_accept    (ev_dyn_accept    ),
    .ev_dyn_deny      (ev_dyn_deny      ),
    .ev_locked        (ev_locked        ),

    // ---- Device Q-Channel, through u_devq below ----
    .req_dev_quiescence(req_dev_quiescence),
    .dev_stopped       (dev_stopped       ),
    .dev_q_run         (dev_q_run         ),
    .dev_qdeny          (sync_dev_qdeny     ),
    .dev_qactive        (sync_dev_qactive   ),

    // ---- PCSM P-Channel, through u_pcsm below ----
    .pcsm_req_state (pcsm_req_state),
    .pcsm_req_valid (pcsm_req_valid),
    .pcsm_cur_state (pcsm_cur_state),
    .pcsm_init_done (pcsm_init_done),

    // ---- Section 6.4 device controls, driven straight out of the PPU ----
    .ppuhwstat    (ppuhwstat    ),
    .dev_clken     (dev_clken     ),
    .dev_isolaten  (dev_isolaten  ),
    .dev_poresetn  (dev_poresetn  ),
    .dev_warmresetn(dev_warmresetn),
    .dev_retresetn (dev_retresetn ),

    // ---- The clock Q-Channel's device-internal condition; see u_clkq ----
    .ppu_active   (seq_active   )
  );

  // ---------------------------------------------------------------------------
  // Clock control interface (PCK-600 Section 3.6, Table A-29)
  //
  // WHAT "THE PPU NEEDS ITS CLOCK" MEANS, TERM BY TERM
  //
  // seq_active covers everything the sequencer knows about: a transition in
  // flight, a transition due, or the reset-time PCSM handshake unfinished. The
  // other two terms cover the two ways work can ARRIVE at a PPU whose clock has
  // already stopped, and both of them have to be combinational paths off pins,
  // because every flip-flop in this module is frozen in that state.
  //
  //   pwakeup       software is about to touch the register file. Table A-28
  //                 gives this exact role: "The PPU uses this wakeup signal as
  //                 an input for the generation of the ppuclk_qactive_o
  //                 signal."
  //
  //   dev_qactive    the device is asking to come back. This must be the RAW
  //                 pin, not sync_dev_qactive. The synchronizer is clocked by
  //                 clk, so with the clock gated its output can never change --
  //                 the wake would be invisible to ppu_seq's hop_needed and
  //                 the domain would be stranded off with its device asking to
  //                 run. Reading the pin directly is the resolution AMBA LPI
  //                 Section 4.1.1 prescribes for exactly this dependency: "a
  //                 QACTIVE contribution from the power control interface logic
  //                 that is active whenever P-Channel transitions require CLK
  //                 to be active."
  //
  //                 devactiveen qualifies it because PPU_PWCR is what decides
  //                 whether DEVQACTIVE means anything to this PPU at all
  //                 (Section 4.1.3). It is a register bit, held in flops that
  //                 the gate freezes at their current value, so it stays
  //                 readable with the clock stopped -- what a gated flop cannot
  //                 do is CHANGE, and this one has no reason to.
  //
  // DENYING RATHER THAN STALLING
  //
  // dev_deny and dev_active are the same expression, and dev_busy is tied LOW.
  // The PPU either needs its clock, in which case it refuses and says so within
  // two cycles, or it does not, in which case it accepts. There is no third
  // case worth a Q_REQUEST stall: a transition already under way can run for
  // hundreds of cycles (five device-control delays, an entry delay up to 255,
  // and the PCSM's tinit), and AMBA LPI Section 2.1.1 gives denial as the
  // mechanism for precisely that -- "a device can maintain an operational state
  // while having a mechanism by which it can promptly complete the handshake".
  //
  // dev_quiescent_ok is left unconnected on purpose. Nothing inside the PPU
  // behaves differently when its clock channel is quiescent; the consequence of
  // Q_STOPPED is that the clock stops, and that is the clock controller's to
  // apply, not this module's. Wiring it to anything here would make the PPU's
  // function depend on its own gating, which is the coupling the Q-Channel
  // exists to avoid.
  // ---------------------------------------------------------------------------
  // THE SAME FOUR TERMS, TWICE, AND THE DIFFERENCE IS DELIBERATE
  //
  // ppuclk_needed drives the QACTIVE PIN, which leaves this module as a wire.
  // It must use the RAW DEVQACTIVE for the reason given above -- the
  // synchronizer is clocked by the clock being asked for.
  //
  // ppuclk_deny is the value the FSM SAMPLES, in Q_REQUEST, on a flip-flop
  // clocked by clk. Feeding an asynchronous pin into that would be an
  // unsynchronized clock-domain crossing straight into a state enum, and a
  // metastable `state` is not a wrong value, it is an undefined one. So the
  // sampled copy takes DEVQACTIVE through sync_dev_qactive, which this module
  // already has for ppu_seq and ppu_irq.
  //
  // The skew between the two is harmless, and the direction is the safe one.
  // The worst case is that the raw pin says "active" a couple of cycles before
  // the sampled copy does, so the PPU accepts a request it would have denied.
  // The clock is not lost: the controller has ALREADY seen the raw QACTIVE
  // rise, so its own request drops and clken_o never falls (ppu_clk_ctrl's
  // clk_running only clears while base_req is HIGH). The cost is one wasted
  // Q_STOPPED -> Q_EXIT round trip.
  //
  // PWAKEUP is in neither category: PCK-600 Table A-28 lists it in the APB
  // group whose Clock column is "clk", so it is synchronous to this domain
  // already -- launched from an ungated leaf of the same tree, which is also
  // why the TRM requires it be "driven from a register". seq_active is
  // ppu_seq's own output and is synchronous by construction.
  //
  // THE FOURTH TERM IS THE EDGE INTERRUPT, WHICH THE ENABLE DOES NOT GATE.
  //
  // Section 4.1.3, DEVACTIVE Enables: "These enables have no effect on the
  // generation of interrupts. If an interrupt for a DEVACTIVE is unmasked it
  // still generates an interrupt event when the input changes." Table 5-9 says
  // the same of PPU_PWCR: its enables control "the ability of the DEVACTIVE
  // inputs to initiate power mode transitions, but not the ability to generate
  // input edge interrupt events."
  //
  // ppu_irq's edge detector runs on this clock. With only the third term, a
  // DEVQACTIVE edge arriving while PWR_DEVACTIVEEN is 0 asked for nothing, so
  // the detector could not see it until some unrelated register access ran
  // the clock -- measured at 4,950 cycles in the SCP stress test, and pinned
  // by ppu_clkq_tb G9. So while PPU_IESR selects an edge, the PPU asks for its
  // clock whenever the input differs from the level the detector last saw.
  //
  // ANY difference, not only the selected direction: with rising edges
  // selected, a fall made while the clock is gated must still be tracked, or
  // the next rise looks like no change at all. Once the detector has taken the
  // new level both terms drop again, so a DEVQACTIVE held steady costs no
  // clock, and with PPU_IESR at its reset value of none the term is 0. The raw
  // and synchronized copies split exactly as the third term's do, for the same
  // reasons.
  assign edge_armed = (iesr[1:0] != EDGE_NONE);

  assign ppuclk_needed = seq_active | pwakeup | (dev_qactive      & devactiveen)
                       | (edge_armed & (dev_qactive      != qactive_seen));
  assign ppuclk_deny   = seq_active | pwakeup | (sync_dev_qactive & devactiveen)
                       | (edge_armed & (sync_dev_qactive != qactive_seen));

  qchannel_device_comb #(
    .Q_CH_SYNC  (QCLK_SYNC_EN),
    .SYNC_STAGES(SYNC_STAGES)
  ) u_clkq (
    .clk  (clk),
    .rst_n(rst_n),

    // ---- The four Table A-29 wires ----
    .qreqn   (ppuclk_qreqn   ),
    .qacceptn(ppuclk_qacceptn),
    .qdeny   (ppuclk_qdeny   ),
    .qactive (ppuclk_qactive ),

    // ---- Device-internal ----
    .dev_active(ppuclk_needed),   // raw:          -> the QACTIVE pin
    .dev_deny  (ppuclk_deny  ),   // synchronized: -> a flop in Q_REQUEST
    .dev_busy  (1'b0),

    .dev_quiescent_ok(),   // see the note above
    .q_requested     ()
  );

  // ---------------------------------------------------------------------------
  // Device interface Q-Channel controller (Section 6.3)
  //
  // Both QACTIVE policy inputs are tied LOW, which is NOT the Figure 2-8
  // default this repository's other integrations use. See point 5 of the
  // ppu_seq header: in a PPU the domain behind this interface may be
  // unpowered, and letting the controller leave Q_STOPPED on its own would put
  // the interface in a running state while the supply is still off -- an AMBA
  // LPI Section 2.1.2 violation. DEVQACTIVE goes to the sequencer instead,
  // where it is a wake REQUEST that gets serviced by restoring the PCSM state
  // and the device controls first.
  // ---------------------------------------------------------------------------
  // DEV_STAGES, not DEVACT_STAGES: this controller synchronizes qacceptn, qdeny
  // and qactive with one parameter, and its two QACTIVE policy inputs are tied
  // LOW below, so its internal qactive copy feeds nothing. DEV_SYNC_EN is the
  // one that describes what it actually uses.
  qchannel_controller #(.SYNC_STAGES(DEV_STAGES)) u_devq (
    .clk      (clk),
    .rst_n    (rst_n),

    // ---- The four Q-Channel wires ARE the PPU's device interface ----
    .qreqn    (dev_qreqn),
    .qacceptn (dev_qacceptn),
    .qdeny    (dev_qdeny),
    .qactive  (dev_qactive),

    // ---- Sequencer control. Both QACTIVE policies OFF; see the note above ----
    .req_dev_quiescence              (req_dev_quiescence),
    .enb_qactive_led_quiescence_enter(1'b0),
    .enb_qactive_led_quiescence_exit (1'b0),
    .dev_stopped                     (dev_stopped)
  );

  // ---------------------------------------------------------------------------
  // PCSM interface P-Channel master (Sections 4.1.6, 6.5)
  //
  // RESET_STATE is OFF's PCSMPSTATE unconditionally, even though the sequencer
  // may start in MEM_RET because PCSMMODESTAT said so. The two only disagree
  // in that one case, and the disagreement is self-correcting: the sequencer
  // asks for a PCSM transition whenever its target differs from the
  // controller's cur_state, so the first hop -- which for a MEM_RET start is
  // necessarily a hop to ON, MEM_RET having no direct route anywhere else --
  // re-establishes agreement before any state that depends on it.
  //
  // Deriving RESET_STATE from the pin instead is not possible: it is an
  // elaboration-time parameter of a module this file does not own, and the
  // pin's whole point is that it is not known until reset release.
  // ---------------------------------------------------------------------------
  pchannel_controller #(
    .PSTATE_W          (16),
    .PACTIVE_W         (1),
    .SYNC_STAGES       (PCSM_STAGES),
    .PSTATE_LEAD_CYCLES(0),
    // Section 4.1.6: reset to the mode the PPU believes the domain is already
    // in, so that the value the PCSM captures during its tinit AGREES with
    // PWR_STATUS. Hardcoding OFF here was a real bug: with
    // PCSMMODESTAT = MEM_RET the PPU reported MEM_RET while the PCSM captured
    // OFF and dropped RAM retention -- and because policy then equalled status,
    // no transition ever ran to correct it. Only OFF and MEM_RET are legal on
    // PCSMMODESTAT, and neither maps through ppu_pcsm_mode, so the encoding is
    // used directly.
    .RESET_STATE       ({8'h00, 4'h0, PCSM_RESET_MODESTAT}),
    .TINIT_WAIT        (PCSM_TINIT_WAIT)
  ) u_pcsm (
    .clk    (clk),
    .rst_n  (rst_n),

    // ---- Section 6.5 PCSM interface ----
    .pstate (pcsm_pstate),
    .preq   (pcsm_preq),
    .paccept(pcsm_paccept),
    // Section 4.1.6: the PCSM P-Channel "has no PDENY or PACTIVE signals".
    .pdeny  (1'b0),
    .pactive(1'b0),

    // ---- Sequencer control ----
    .req_state                 (pcsm_req_state),
    .req_valid                 (pcsm_req_valid),
    .enb_pactive_led_transition(1'b0),

    // ---- Status back to the sequencer ----
    .cur_state                 (pcsm_cur_state),
    .ctrl_init_done            (pcsm_init_done),

    // ---- Deliberately unconnected, each for its own reason ----
    .pactive_floor_state       (),  // no PACTIVE, so the floor is always 0
    .dev_stable                (),  // the sequencer gates on cur_state instead
    // The sequencer tracks completion through cur_state too; see the note on
    // its PCSM ports for why a level beats a pulse here.
    .xfer_done                 (),
    .xfer_denied               ()   // unreachable: pdeny is tied LOW
  );

endmodule
