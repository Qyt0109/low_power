`timescale 1ns/1ps
/*
ppu_top_axi_lite
├── u_axi ................ ppu_axi_lite_adapter    ← AXI4-Lite ↔ generic strobe
│                                                     (aclk, free-running)
└── u_ppu ................ ppu_top                  ← the PPU (clk, may be gated)
    │
    ├── sync_acc/gen_sync  cdc_sync   DEVQACCEPTn → PPU_DISR/MISR, ppu_seq
    ├── sync_den/gen_sync  cdc_sync   DEVQDENY    → ppu_seq
    ├── sync_act/gen_sync  cdc_sync   DEVQACTIVE  → ppu_seq, ppu_irq
    ├── sync_pacc/gen_sync cdc_sync   PCSMPACCEPT → PPU_MISR
    │
    ├── u_regs ........... ppu_regs        the register file
    ├── u_irq ............ ppu_irq         PPU_IMR/AIMR/ISR/AISR/IESR
    ├── u_seq ............ ppu_seq         the mode sequencer
    │
    ├── u_clkq ........... qchannel_device_comb    PPUCLK* — the PPU as a Q-Channel device
    │   └── g_sync/u_qreqn_sync/gen_sync   cdc_sync   (QCLK_SYNC_EN=1)
    │
    ├── u_devq ........... qchannel_controller   the device interface
    │   ├── u_acc_sync/gen_sync            cdc_sync
    │   ├── u_den_sync/gen_sync            cdc_sync
    │   └── u_act_sync/gen_sync            cdc_sync
    │
    └── u_pcsm ........... pchannel_controller   the PCSM P-Channel master
        ├── u_acc_sync/gen_sync            cdc_sync
        ├── u_den_sync/gen_sync            cdc_sync
        └── u_act_sync/gen_sync            cdc_sync
*/

// The PPU with an AXI4-Lite software interface.
//
// References: Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN
// 0051E) Sections 6.2-6.5; Arm CoreLink PCK-600 TRM (101150) Tables A-28, A-29;
// AMBA Low Power Interface Specification (ARM IHI 0068C) Section 2.1.2.
//
//              ┌──────────────── ppu_top_axi_lite ────────────────┐
//   AXI4-Lite ─┼─► ppu_axi_lite_adapter ──reg_*──► ppu_top ───────┼─► device
//              │      (aclk, free-running)   (clk, may be gated)  │   Q-Channel
//              │            ▲                      │              │
//              │            │ pwakeup ─────────────┤              ├─► PCSM
//              │            │                      ▼              │   P-Channel
//              │            └── ppu_clk_ok ◄── PPUCLK* decoded ───┼─► PPUCLK*
//              └──────────────────────────────────────────────────┘
//
// DEN 0051E Section 6.2 says only that "The type of bus interface used is
// IMPLEMENTATION DEFINED" and Table 6-2 offers APB as an example, so ppu_top
// exposes a generic strobe and leaves the bus to a wrapper. This is that
// wrapper for AXI4-Lite.
//
// -----------------------------------------------------------------------------
// TWO CLOCKS, AND THEY ARE THE SAME CLOCK
//
// aclk is free-running. clk is the PPU's, and an integration that puts a clock
// controller in front of it (see ppu_clkq_top) will stop it whenever the PPU is
// idle. Both ports exist because the adapter must keep running while the PPU
// does not -- ppu_axi_lite_adapter's header works through the data-loss hazard
// that a gated bridge has, and PCK-600 puts the wakeup logic outside the PPU
// for the same reason.
//
// They must be THE SAME CLOCK: clk a gated leaf, aclk an ungated leaf, of one
// tree. They are not treated as asynchronous anywhere in this module and there
// are no synchronizers between them, because between two leaves of one tree
// there is nothing to synchronize. Tie them together in an integration that
// does not gate.
//
// An integration that genuinely needs an asynchronous AXI clock needs a CDC
// bridge in FRONT of this module. Do not reach for this one and hope.
//
// -----------------------------------------------------------------------------
// WHAT THIS MODULE ADDS BEYOND INSTANTIATING TWO THINGS
//
// One line: the Q_RUN decode. It is the piece that cannot live in either block.
//
// The adapter must not strobe reg_wen at a PPU whose clock has stopped, and
// pwakeup cannot tell it when that has been fixed -- pwakeup is a request with
// no acknowledgement. What CAN tell it is the PPUCLK* handshake reaching Q_RUN,
// and the reason that is trustworthy rather than merely conventional is that
// PPUCLKQACCEPTn is registered on the PPU's clk. The PPU could only have driven
// it HIGH if it was being clocked. Q_RUN is not a state you take on faith; it
// is evidence the clock arrived.
//
// AMBA LPI Section 2.1.2 makes Q_STOPPED "the only state where the controller
// does not guarantee the availability of any clock", so Q_DENIED and
// Q_CONTINUE would also be safe. Waiting for Q_RUN is deliberately the
// conservative choice: it costs at most a couple of cycles in the rare case
// where the PPU has just refused a gating request, and it removes a whole class
// of "which states are safe again?" reasoning from the integration.
//
// AND NOT THE CLOCK CONTROLLER'S clken_o, WHICH IS THE OBVIOUS ALTERNATIVE
//
// A clock controller's gate enable says whether the clock is RUNNING. Q_RUN
// says whether it is GUARANTEED. Those come apart in one state -- see
// ppu_axi_pd_top, where the controller is in scope and the temptation is real,
// and ppu_axi_lite_tb group L12, which is the check that tells them apart. The
// short version: clk_force_i is asynchronous and can deassert mid-access, so a
// present clock is not a promise, whereas leaving Q_RUN needs a Q_REQUEST the
// PPU will deny while PWAKEUP is HIGH.

import ppu_pkg::*;
import qchannel_pkg::*;

module ppu_top_axi_lite #(
  // ---- Forwarded verbatim to ppu_top; see there for what each one selects ----
  parameter bit          DEF_PWR_DYN_EN        = 1'b0,
  parameter logic [3:0]  DEF_PWR_POLICY        = PM_ON,
  parameter bit          WARM_RST_DEVREQEN_CFG = 1'b1,
  parameter logic [7:0]  RST_HWSTAT_DLY_CFG    = 8'd2,
  parameter logic [7:0]  ISO_CLKEN_DLY_CFG     = 8'd2,
  parameter logic [7:0]  CLKEN_RST_DLY_CFG     = 8'd2,
  parameter logic [7:0]  CLKEN_ISO_DLY_CFG     = 8'd2,
  parameter logic [7:0]  ISO_RST_DLY_CFG       = 8'd2,
  parameter bit          DYN_ON_SPT_CFG        = 1'b1,
  parameter bit          DYN_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit          DYN_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit          DYN_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit          DYN_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit          DYN_OFF_SPT_CFG       = 1'b1,
  parameter bit          STA_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit          STA_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit          STA_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit          STA_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit          OFF_MEM_RET_TRANS_CFG = 1'b1,
  parameter bit          FUNC_RET_RAM_REG_CFG  = 1'b1,
  parameter bit          FULL_RET_RAM_REG_CFG  = 1'b1,
  parameter bit          MEM_RET_RAM_REG_CFG   = 1'b1,
  parameter bit          LOCK_CFG              = 1'b1,
  parameter bit          SW_DEV_DEL_CFG        = 1'b1,
  parameter bit          PWR_MODE_ENTRY_DEL_CFG= 1'b1,
  parameter logic [11:0] IIDR_PRODUCT_ID       = 12'h50C,
  parameter logic [3:0]  IIDR_VARIANT          = 4'h0,
  parameter logic [3:0]  IIDR_REVISION         = 4'h1,
  parameter logic [11:0] IIDR_IMPLEMENTER      = 12'h000,
  parameter int unsigned SYNC_STAGES           = 2,
  parameter bit          QCLK_SYNC_EN          = 1'b1,
  parameter logic [3:0]  PCSM_RESET_MODESTAT   = PM_OFF,
  parameter int unsigned PCSM_TINIT_WAIT       = 16,

  // ---- The bridge's own ----
  parameter int unsigned AXI_ADDR_W            = 32,
  parameter int unsigned WAKE_TIMEOUT          = 1024
) (
  // ---- The AXI4-Lite clock: free-running. See the header ----
  input  logic aclk,
  input  logic aresetn,

  // ---- The PPU's clock: may be gated by a clock controller ----
  input  logic clk,
  input  logic rst_n,

  // ---- AXI4-Lite subordinate ----
  input  logic [AXI_ADDR_W-1:0] s_axi_awaddr,
  input  logic [2:0]            s_axi_awprot,
  input  logic                  s_axi_awvalid,
  output logic                  s_axi_awready,
  input  logic [31:0]           s_axi_wdata,
  input  logic [3:0]            s_axi_wstrb,
  input  logic                  s_axi_wvalid,
  output logic                  s_axi_wready,
  output logic [1:0]            s_axi_bresp,
  output logic                  s_axi_bvalid,
  input  logic                  s_axi_bready,
  input  logic [AXI_ADDR_W-1:0] s_axi_araddr,
  input  logic [2:0]            s_axi_arprot,
  input  logic                  s_axi_arvalid,
  output logic                  s_axi_arready,
  output logic [31:0]           s_axi_rdata,
  output logic [1:0]            s_axi_rresp,
  output logic                  s_axi_rvalid,
  input  logic                  s_axi_rready,

  output logic irq,

  // ---- Clock control interface (PCK-600 Table A-29) ----
  // PWAKEUP is NOT a port: it is generated inside, by the adapter, which is the
  // block that knows when a transaction is outstanding. That is the whole point
  // of putting the two together in one wrapper.
  input  logic ppuclk_qreqn,
  output logic ppuclk_qacceptn,
  output logic ppuclk_qdeny,
  output logic ppuclk_qactive,

  // ---- Section 6.3: device interface, one Q-Channel ----
  output logic dev_qreqn,
  input  logic dev_qacceptn,
  input  logic dev_qdeny,
  input  logic dev_qactive,

  // ---- Section 6.4: device control signals ----
  output logic [15:0] ppuhwstat,
  output logic        dev_clken,
  output logic        dev_poresetn,
  output logic        dev_retresetn,
  output logic        dev_warmresetn,
  output logic        dev_isolaten,

  // ---- Section 6.5: PCSM interface ----
  output logic [15:0] pcsm_pstate,
  output logic        pcsm_preq,
  input  logic        pcsm_paccept,
  input  logic [7:0]  pcsm_modestat
);

  // The PPU's software interface, between the two blocks below.
  logic [11:0] reg_waddr, reg_raddr;
  logic [31:0] reg_wdata, reg_rdata;
  logic [ 3:0] reg_wstrb;
  logic        reg_wen, reg_ren;

  logic pwakeup, ppu_clk_ok;

  // ---------------------------------------------------------------------------
  // The one piece of logic in this file. See the header for why Q_RUN is
  // evidence rather than convention, and why the two other clock-guaranteed
  // states are deliberately not accepted.
  //
  // Read from the PINS rather than from anything inside u_ppu: PPUCLKQREQn is
  // an input to this module and the other two are u_ppu's registered outputs,
  // so this decodes exactly what a clock controller on the other end sees.
  // ---------------------------------------------------------------------------
  assign ppu_clk_ok = (qch_decode(ppuclk_qreqn, ppuclk_qacceptn, ppuclk_qdeny) == Q_RUN);

  ppu_axi_lite_adapter #(
    .REG_ADDR_W  (12),
    .AXI_ADDR_W  (AXI_ADDR_W),
    .WAKE_TIMEOUT(WAKE_TIMEOUT)
  ) u_axi (
    .aclk   (aclk),
    .aresetn(aresetn),

    .s_axi_awaddr (s_axi_awaddr ),
    .s_axi_awprot (s_axi_awprot ),
    .s_axi_awvalid(s_axi_awvalid),
    .s_axi_awready(s_axi_awready),
    .s_axi_wdata  (s_axi_wdata  ),
    .s_axi_wstrb  (s_axi_wstrb  ),
    .s_axi_wvalid (s_axi_wvalid ),
    .s_axi_wready (s_axi_wready ),
    .s_axi_bresp  (s_axi_bresp  ),
    .s_axi_bvalid (s_axi_bvalid ),
    .s_axi_bready (s_axi_bready ),
    .s_axi_araddr (s_axi_araddr ),
    .s_axi_arprot (s_axi_arprot ),
    .s_axi_arvalid(s_axi_arvalid),
    .s_axi_arready(s_axi_arready),
    .s_axi_rdata  (s_axi_rdata  ),
    .s_axi_rresp  (s_axi_rresp  ),
    .s_axi_rvalid (s_axi_rvalid ),
    .s_axi_rready (s_axi_rready ),

    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wstrb(reg_wstrb),
    .reg_wen  (reg_wen  ),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren  ),
    .reg_rdata(reg_rdata),

    .pwakeup   (pwakeup),
    .ppu_clk_ok(ppu_clk_ok)
  );

  ppu_top #(
    .DEF_PWR_DYN_EN        (DEF_PWR_DYN_EN),
    .DEF_PWR_POLICY        (DEF_PWR_POLICY),
    .WARM_RST_DEVREQEN_CFG (WARM_RST_DEVREQEN_CFG),
    .RST_HWSTAT_DLY_CFG    (RST_HWSTAT_DLY_CFG),
    .ISO_CLKEN_DLY_CFG     (ISO_CLKEN_DLY_CFG),
    .CLKEN_RST_DLY_CFG     (CLKEN_RST_DLY_CFG),
    .CLKEN_ISO_DLY_CFG     (CLKEN_ISO_DLY_CFG),
    .ISO_RST_DLY_CFG       (ISO_RST_DLY_CFG),
    .DYN_ON_SPT_CFG        (DYN_ON_SPT_CFG),
    .DYN_FUNC_RET_SPT_CFG  (DYN_FUNC_RET_SPT_CFG),
    .DYN_FULL_RET_SPT_CFG  (DYN_FULL_RET_SPT_CFG),
    .DYN_MEM_OFF_SPT_CFG   (DYN_MEM_OFF_SPT_CFG),
    .DYN_MEM_RET_SPT_CFG   (DYN_MEM_RET_SPT_CFG),
    .DYN_OFF_SPT_CFG       (DYN_OFF_SPT_CFG),
    .STA_FUNC_RET_SPT_CFG  (STA_FUNC_RET_SPT_CFG),
    .STA_FULL_RET_SPT_CFG  (STA_FULL_RET_SPT_CFG),
    .STA_MEM_OFF_SPT_CFG   (STA_MEM_OFF_SPT_CFG),
    .STA_MEM_RET_SPT_CFG   (STA_MEM_RET_SPT_CFG),
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG),
    .FUNC_RET_RAM_REG_CFG  (FUNC_RET_RAM_REG_CFG),
    .FULL_RET_RAM_REG_CFG  (FULL_RET_RAM_REG_CFG),
    .MEM_RET_RAM_REG_CFG   (MEM_RET_RAM_REG_CFG),
    .LOCK_CFG              (LOCK_CFG),
    .SW_DEV_DEL_CFG        (SW_DEV_DEL_CFG),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .IIDR_PRODUCT_ID       (IIDR_PRODUCT_ID),
    .IIDR_VARIANT          (IIDR_VARIANT),
    .IIDR_REVISION         (IIDR_REVISION),
    .IIDR_IMPLEMENTER      (IIDR_IMPLEMENTER),
    .SYNC_STAGES           (SYNC_STAGES),
    .QCLK_SYNC_EN          (QCLK_SYNC_EN),
    .PCSM_RESET_MODESTAT   (PCSM_RESET_MODESTAT),
    .PCSM_TINIT_WAIT       (PCSM_TINIT_WAIT)
  ) u_ppu (
    .clk  (clk  ),
    .rst_n(rst_n),

    // ---- Section 6.2, now driven by the bridge ----
    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wstrb(reg_wstrb),
    .reg_wen  (reg_wen  ),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren  ),
    .reg_rdata(reg_rdata),
    .irq      (irq      ),

    // ---- Clock control. PWAKEUP comes from the adapter, not from a port ----
    .ppuclk_qreqn   (ppuclk_qreqn   ),
    .ppuclk_qacceptn(ppuclk_qacceptn),
    .ppuclk_qdeny   (ppuclk_qdeny   ),
    .ppuclk_qactive (ppuclk_qactive ),
    .pwakeup        (pwakeup        ),

    .dev_qreqn   (dev_qreqn   ),
    .dev_qacceptn(dev_qacceptn),
    .dev_qdeny   (dev_qdeny   ),
    .dev_qactive (dev_qactive ),

    .ppuhwstat    (ppuhwstat    ),
    .dev_clken     (dev_clken     ),
    .dev_poresetn  (dev_poresetn  ),
    .dev_retresetn (dev_retresetn ),
    .dev_warmresetn(dev_warmresetn),
    .dev_isolaten  (dev_isolaten  ),

    .pcsm_pstate  (pcsm_pstate  ),
    .pcsm_preq    (pcsm_preq    ),
    .pcsm_paccept (pcsm_paccept ),
    .pcsm_modestat(pcsm_modestat)
  );

endmodule
