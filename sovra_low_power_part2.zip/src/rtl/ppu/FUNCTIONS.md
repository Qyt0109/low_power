# PPU function checklist: spec surface vs this implementation

Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E).

Organised by **what the PPU does**, not by configuration parameter — the
parameter view is in [OPTIONS.md](OPTIONS.md). Much of the specification's
optionality is not a Chapter 7 knob at all: whole functions, signals, registers
and interrupt events are present or absent depending on the configuration, and
this is that list.

Status: **●** implemented · **◐** implemented, narrowed · **○** not built ·
**—** not applicable to this configuration

---

## 1. Power modes (§3.1.1, Table 3-1)

Eleven modes defined. `ON`, `OFF` and `WARM_RST` are mandatory; the rest optional.

| Mode | Logic / RAM | | Note |
|---|---|---|---|
| `ON` | ON / ON | ● | mandatory |
| `OFF` | OFF / OFF | ● | mandatory |
| `WARM_RST` | ON / ON | ● | mandatory |
| `FUNC_RET` | ON / RET | ● | |
| `MEM_OFF` | ON / OFF | ● | |
| `FULL_RET` | RET / RET | ● | |
| `MEM_RET` | OFF / RET | ● | |
| `LOGIC_RET` | RET / OFF | — | P-Channel PPU only |
| `DBG_RECOV` | ON / ON | ○ | needs `DEVPORESETn` configurability, §4.2.8 sequences |
| `OFF_EMU` | ON / ON | ○ | emulation |
| `MEM_RET_EMU` | ON / ON | ○ | emulation |

**7 of 11 built.** All four absences are either P-Channel-only or descoped
emulation/debug.

## 2. Operating modes (§3.1.2, §3.5, §3.6, §4.3)

| Function | | Note |
|---|---|---|
| Operating mode support | ○ | `NUM_OPMODE_CFG = 0` |
| Ladder use model (§4.3.2) | ○ | |
| Independent use model (§4.3.3) | ○ | |
| Operating-mode `DEVPACTIVE` inputs (§3.6.1) | ○ | |

**Entirely absent, by requirement.** Consequences are checked, not assumed:
`PCSMPSTATE[7:4]` is permanently zero (monitor rule **U10**), `PPU_OPSR` is
reserved, and the operating-mode fields of `PPU_PWPR`/`PWSR`/`DISR`/`PWCR`/`ISR`
read zero.

## 3. Mode values and status (§3.2, §4.1.4)

| Function | Spec | | Note |
|---|---|---|---|
| `PWR_POLICY` / `PWR_STATUS` encoding | Table 3-2, 11 values | ● | all 11 encodings defined, 7 reachable |
| `PPUHWSTAT` one-hot | `[15:0]`, `[15:11]` reserved | ● | width reduced from `[31:0]`; §6.4 footnote permits it |
| `PCSMPSTATE` mode field | Table 3-2, incl. footnote a | ● | all four footnote-a modes mapped |
| `PCSMPSTATE[15:8]` RAM config | IMPLEMENTATION DEFINED | ● | routed per mode from `PPU_FUNRR`/`FULRR`/`MEMRR` |
| `PCSMPSTATE[7:4]` operating mode | — | — | permanently 0 |

## 4. Power mode transitions (§3.3)

| Function | | Note |
|---|---|---|
| Static transitions (§3.3.1) | ● | |
| Dynamic transitions (§3.3.1) | ◐ | one global switch, not per-mode — see OPTIONS §8 |
| Q-Channel transition set (§3.3.2) | ● | ON-anchored, plus the `OFF → MEM_RET` exception |
| `OFF → MEM_RET` direct hop | ● | configurable, both values built |
| P-Channel transition set (§3.3.3) | — | |
| Intermediate transitions (§3.3, p3-19) | ● | route via `ON`; gating applies before the intermediate hop (**F9**) |

## 5. Transition rules (§3.4)

| Rule | | Note |
|---|---|---|
| `DEVACTIVE` input enables (§3.4.1) | ● | disabled inputs assumed LOW |
| Emulation effect on `DEVACTIVE` (§3.4.1) | — | *"no effect for a Q-Channel PPU"* regardless |
| Static: lower-priority gating (§3.4.2) | ● | incl. before intermediate hops |
| Static: higher-priority not delayed | ● | |
| Static: `ON ↔ WARM_RST` exempt | ● | both directions |
| Dynamic: `ON ↔ policy` on `DEVQACTIVE` (§3.4.3) | ● | |
| Dynamic: enable waits for in-flight transition | ● | `PWR_DYN_STATUS` reports it |
| Dynamic: `WARM_RST` excluded | ● | to and from |
| Lock (§3.4.3) | ● | configurable; both values built |
| Lock: 3 set conditions | ● | third is unreachable — up-transitions cannot be denied |
| Lock: 3 unlock conditions | ● | |
| P-Channel power-mode initialization (§3.4.4) | — | |

## 6. Software interface (§4.1.1, Chapter 5)

Bus type is IMPLEMENTATION DEFINED (§6.2.1); APB is the spec's example. We use a
generic strobe bus with two extensions the example does not have.

The address is **split**: `reg_waddr` and `reg_raddr` are separate buses, so an
AXI4-Lite bridge can have a write and a read outstanding simultaneously — AXI
orders AW/W/B against AR/R not at all — instead of arbitrating them onto one
bus. A read concurrent with a write to the same register returns the pre-write
value; no read in this file has a side effect, so nothing else is at stake.

The second extension is a `reg_wstrb`
byte lane per byte of write data, so the register file can sit behind an APB4
`PSTRB` or an AXI4-Lite `WSTRB` without a shim faking read-modify-write. Word-only
masters tie it to `4'hF`. The two places it is not merely a per-field gate are
`PPU_PWPR`, where §4.1.1 admits the policy and the dynamic enable as a pair
though they sit in different lanes, and `PPU_ISR`, which is write-1-to-clear so a
masked lane must clear nothing rather than write back what it read. See
REGISTERS.md §1 and the `ppube` suite.

**All 27 register addresses are decoded.** Three are reserved — each for a reason
the spec states, not by omission:

| Offset | Register | | Note |
|---|---|---|---|
| `0x000` | `PPU_PWPR` | ● | `LOCK_EN`/`PWR_DYN_EN` reserved when their features are not built |
| `0x004` | `PPU_PMER` | — | reserved: *"If neither OFF_EMU nor MEM_RET_EMU is supported"* |
| `0x008` | `PPU_PWSR` | ● | |
| `0x010` | `PPU_DISR` | ● | one channel's bits |
| `0x014` | `PPU_MISR` | ● | |
| `0x018` | `PPU_STSR` | — | reserved: *"a Q-Channel PPU with a single Q-Channel"* (§5.2.6) |
| `0x01C` | `PPU_UNLK` | ● | reserved when `LOCK_SPT = 0` |
| `0x020` | `PPU_PWCR` | ● | `DEVREQEN`, `PWR_DEVACTIVEEN` |
| `0x024` | `PPU_PTCR` | ● | `WARM_RST_DEVREQEN`; `DBG_RECOV_PORST_EN` reserved |
| `0x030` | `PPU_IMR` | ● | |
| `0x034` | `PPU_AIMR` | ● | |
| `0x038` | `PPU_ISR` | ● | |
| `0x03C` | `PPU_AISR` | ● | bit 3 reserved (§4.1.2) |
| `0x040` | `PPU_IESR` | ◐ | one channel's bits, `[15:2]` reserved |
| `0x044` | `PPU_OPSR` | — | reserved: no operating modes |
| `0x050` | `PPU_FUNRR` | ● | present/reserved via `RET_RAM_REGS` |
| `0x054` | `PPU_FULRR` | ● | " |
| `0x058` | `PPU_MEMRR` | ● | " |
| `0x160` | `PPU_EDTR0` | ● | present/reserved via `PWR_MODE_ENTRY_DEL_SPT` |
| `0x164` | `PPU_EDTR1` | ● | " |
| `0x170` | `PPU_DCDR0` | ● | read-only when `SW_DEV_DEL_SPT = 0` |
| `0x174` | `PPU_DCDR1` | ● | " |
| `0xFB0` | `PPU_IDR0` | ● | describes the build |
| `0xFB4` | `PPU_IDR1` | ● | " |
| `0xFC8` | `PPU_IIDR` | ● | `IMPLEMENTER` deliberately not Arm's `0x43B` |
| `0xFCC` | `PPU_AIDR` | ● | `0x11` = v1.1 |

## 7. Interrupts (§4.1.2)

Twelve event types defined:

| Event | | Note |
|---|---|---|
| Full policy transition completion | ● | all four completion conditions |
| Power policy transition completion | — | *"not supported when operating modes are not supported"* (**F2**) |
| Operating policy transition completion | — | " |
| Static transition acceptance | ● | fires at completion, per hop |
| Static transition denial | ● | |
| Dynamic transition acceptance | ● | |
| Dynamic transition denial | ● | |
| Unsupported policy | ● | |
| Input edge | ● | `PPU_IESR` rise/fall/both/none |
| Locked | ● | present/reserved via `LOCK_SPT` |
| Emulation transition acceptance | ○ | no emulation |
| Emulation transition denial | ○ | " |

**8 of 12 built**; 2 are spec-forbidden here, 2 need emulation. Also implemented:
level-sensitive output, masking suppresses the *status bit*, set-beats-clear on a
same-cycle collision, and `PPU_ISR.OTHER_IRQ` derived from `PPU_AISR`.

## 8. Device interface (§4.1.3)

| Function | | Note |
|---|---|---|
| Q-Channel, 1 channel | ● | |
| Q-Channel, 2–8 channels | ○ | `DEVCHAN_CFG` fixed at 1 |
| P-Channel device interface | — | |
| `DEVREQEN` per-channel enable | ● | disabled ⇒ `DEVQREQn` driven HIGH |
| `PWR_DEVACTIVEEN` enable | ● | disabled inputs assumed LOW; no effect on interrupts |
| `WARM_RST_DEVREQEN` | ● | separate enable for `ON ↔ WARM_RST` |
| Denial handling | ● | return to `Q_RUN`, no mode change, policy reverts |
| AXI LPI attachment (Chapter 8) | ● | no PPU-side change required |

## 9. Device controls (§4.1.5)

| Signal | | Note |
|---|---|---|
| `DEVCLKEN` | ● | |
| `DEVPORESETn` | ● | |
| `DEVWARMRESETn` | ● | |
| `DEVRETRESETn` | ● | |
| `DEVISOLATEn` | ● | |
| `DEVEMUCLKEN` | ○ | emulation |
| `DEVEMUISOLATEn` | ○ | emulation |

**5 of 7.** Both orderings implemented (up: PCSM → iso → clock → reset → handshake;
down: handshake → clock → iso → reset → PCSM), all five delays present, runtime
programmable, and each measured.

## 10. PCSM interface (§4.1.6)

| Function | | Note |
|---|---|---|
| `PCSMPSTATE` / `PCSMPREQ` / `PCSMPACCEPT` | ● | |
| `PCSMMODESTAT` | ● | present because `OFF_MEM_RET_TRANS = 1` |
| Reset value = the PPU's default mode | ● | **F8** |
| No request before the PCSM's `tinit` | ● | |
| `PCSMPSTATE` early assertion (`PCSM_PREQ_DLY`) | ○ | hardwired to 0; spec allows 0–3 |

## 11. Transition sequences (§4.2)

| Sequence | | |
|---|---|---|
| §4.2.1 Reset behaviour | ● | all four Table 4-13 rows built |
| §4.2.2 From `OFF`/`MEM_RET` to higher priority | ● | |
| §4.2.3 To a higher priority mode | ● | |
| §4.2.4 To a lower priority mode | ● | |
| §4.2.5 `ON ↔ WARM_RST` | ● | both `WARM_RST_DEVREQEN` settings |
| §4.2.6 `OFF → MEM_RET` | ● | PCSM-only, no device handshake |
| §4.2.7 `OFF_EMU ↔ MEM_RET_EMU` | ○ | emulation |
| §4.2.8 `DBG_RECOV` | ○ | |
| §4.2.9 Transition denials | ● | reversal requirement vacuous here — handshake precedes sequencing |

**7 of 9.**

---

## Summary by function

| Function | Spec items | Built | Not built |
|---|---|---|---|
| Power modes | 11 | 7 | 4 (2 emulation, 1 debug, 1 P-Channel) |
| Operating modes | 4 | 0 | 4 |
| Transition rules | 12 | 11 | 1 (P-Channel only) |
| Registers | 27 | 24 | 3 reserved, each for a stated reason |
| Interrupt events | 12 | 8 | 2 spec-forbidden, 2 emulation |
| Device-control signals | 7 | 5 | 2 emulation |
| Transition sequences | 9 | 7 | 2 |
| Device interface channels | 1–8 or P | 1 | — |

**Nothing in the "not built" column is a conformance gap.** Every entry is either
excluded by the agreed configuration (single Q-Channel, no emulation, no operating
modes) or *required* to be absent by the specification given that configuration —
`PPU_STSR`, `PPU_PMER`, `PPU_OPSR` and the two policy-completion interrupts are in
the second category, and getting one of them wrong was defect **F2**.

The two entries worth a second look, because neither is forced by the
configuration:

1. **`PCSM_PREQ_DLY` hardwired to 0** (§10). The spec allows 0–3 and the
   underlying `pchannel_controller` implements the lead — `ppu_top` simply does
   not expose it.
2. **Dynamic support is one switch, not six** (§4). The spec's own example of a
   mixed configuration cannot be expressed.
