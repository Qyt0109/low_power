`timescale 1ns/1ps
// AXI4-Lite -> a PPU with a real power domain, a gated clock and the stand-in
// device.
//
// References: Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN
// 0051E) Section 6.2; Arm CoreLink PCK-600 TRM (101150) Sections 3.5, 3.6;
// AMBA Low Power Interface Specification (ARM IHI 0068C) Section 2.1.2.
//
//   ┌──────────────────────────── ppu_axi_pd_top ────────────────────────────┐
//   │                                                                        │
//   │  AXI4-Lite ──► u_dom: ppu_axi_dom_top ── device side ──► u_ip:         │
//   │                bridge, PPU clock controller              ppu_device_ip │
//   │                and gate, ppu_dom_top (u_pd)                            │
//   └────────────────────────────────────────────────────────────────────────┘
//
// ppu_axi_dom_top plus ppu_device_ip, and nothing else: the same relationship
// ppu_pd_top has to ppu_dom_top. The bridge, the clock arrangement and the
// Q_RUN decode are ppu_axi_dom_top's; see its header. Ports and default
// behaviour are what they were before either wrapper existed.
//
// WHY THIS EXISTS ALONGSIDE ppu_top_axi_lite
//
// ppu_top_axi_lite is the answer to "put an AXI4-Lite interface on a PPU", and
// it contains ppu_top -- the PPU and nothing else. That is the right shape for
// integration and it is what ppu_axi_lite_tb's groups L1-L10 exercise.
//
// It has one consequence that only shows up when you try to run it under IEEE
// 1801: ppu_top has no power domain, so a testbench holding only a ppu_top has
// nothing for the power intent to bind to, and "make ppuaxi" was therefore the
// one bridge test with no power-aware counterpart.
//
// That left a three-way gap. Clock gating with a genuinely unpowered PD_DEV was
// covered (ppu_clkq_tb, under UPF) but over the generic strobe; AXI with a
// gated clock was covered (ppu_axi_lite_tb) but with no power domain at all.
// Nothing put all three together, which is the combination a real SoC runs in
// every day: software reaching a PPU over AXI, the PPU's own clock stopped, and
// the domain it manages with its supply removed.
//
// So this module is the same bridge with a domain and a device behind it, and
// it exists to be somewhere the power intent can be applied:
// src/upf/ppu_axi_pd_top.upf, bound by upf/ppu_axi_lite_tb.upf.
//
// THE STAND-IN'S Q-CHANNEL POLICY
//
// The same three terms as ppu_pd_top: busy delays quiescence, deny_enb && busy
// refuses it, and wake | busy is the activity on DEVQACTIVE, evaluated here
// from busy after its isolation clamp.

import ppu_pkg::*;

module ppu_axi_pd_top #(
  // ---- Forwarded to ppu_axi_dom_top, and on to ppu_dom_top ----
  parameter bit          DEF_PWR_DYN_EN        = 1'b0,
  parameter logic [3:0]  DEF_PWR_POLICY        = PM_ON,
  parameter bit          WARM_RST_DEVREQEN_CFG = 1'b1,
  parameter int unsigned SYNC_STAGES           = 2,

  // ---- The PPU's clock is a gated leaf; see ppu_axi_dom_top ----
  parameter bit          CLK_Q_CH_SYNC         = 1'b0,
  parameter bit          CLK_QACTIVE_SYNC      = 1'b0,
  parameter bit          QCLK_SYNC_EN          = 1'b0,
  // The stand-in device's burst counter width: ppu_device_ip's only.
  parameter int unsigned CNT_W                 = 8,
  parameter logic [3:0]  PCSM_RESET_MODESTAT   = PM_OFF,
  parameter int unsigned PCSM_TINIT_WAIT       = 16,

  // ---- The clock controller's (PCK-600 Table 3-7) ----
  parameter int unsigned NUM_QACTIVE_ONLY      = 1,
  parameter bit          ACTIVE_DENY_EN        = 1'b1,

  // ---- The bridge's ----
  parameter int unsigned AXI_ADDR_W            = 32,
  parameter int unsigned WAKE_TIMEOUT          = 1024,

  // ---- The rest of ppu_dom_top's, forwarded since W1.1 ----
  // Mode support (*_SPT_CFG) and switch settling (PCSM_*_SETTLE) above all;
  // the device control delays and optional features come along so the domain
  // can be configured here exactly as through ppu_pd_top. Defaults are
  // ppu_dom_top's, which are what this module built with before.
  parameter logic [7:0]  RST_HWSTAT_DLY_CFG    = 8'd2,
  parameter logic [7:0]  ISO_CLKEN_DLY_CFG     = 8'd2,
  parameter logic [7:0]  CLKEN_RST_DLY_CFG     = 8'd2,
  parameter logic [7:0]  CLKEN_ISO_DLY_CFG     = 8'd2,
  parameter logic [7:0]  ISO_RST_DLY_CFG       = 8'd2,
  parameter bit          DYN_ON_SPT_CFG        = 1'b1,
  parameter bit          DYN_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit          DYN_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit          DYN_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit          DYN_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit          DYN_OFF_SPT_CFG       = 1'b1,
  parameter bit          STA_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit          STA_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit          STA_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit          STA_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit          OFF_MEM_RET_TRANS_CFG = 1'b1,
  parameter bit          FUNC_RET_RAM_REG_CFG  = 1'b1,
  parameter bit          FULL_RET_RAM_REG_CFG  = 1'b1,
  parameter bit          MEM_RET_RAM_REG_CFG   = 1'b1,
  parameter bit          LOCK_CFG              = 1'b1,
  parameter bit          SW_DEV_DEL_CFG        = 1'b1,
  parameter bit          PWR_MODE_ENTRY_DEL_CFG= 1'b1,
  parameter bit          PCSM_SYNC_EN          = 1'b0,
  parameter bit          DEV_SYNC_EN           = 1'b1,
  parameter bit          DEV_ACTIVE_SYNC_EN    = 1'b1,
  parameter int unsigned PCSM_RET_SETTLE       = 0,
  parameter int unsigned PCSM_LOGIC_SETTLE     = 0
) (
  // ---- Free-running: the AXI bridge and the clock controller ----
  input  logic aclk,
  input  logic aresetn,

  // ---- AXI4-Lite subordinate ----
  input  logic [AXI_ADDR_W-1:0] s_axi_awaddr,
  input  logic [2:0]            s_axi_awprot,
  input  logic                  s_axi_awvalid,
  output logic                  s_axi_awready,
  input  logic [31:0]           s_axi_wdata,
  input  logic [3:0]            s_axi_wstrb,
  input  logic                  s_axi_wvalid,
  output logic                  s_axi_wready,
  output logic [1:0]            s_axi_bresp,
  output logic                  s_axi_bvalid,
  input  logic                  s_axi_bready,
  input  logic [AXI_ADDR_W-1:0] s_axi_araddr,
  input  logic [2:0]            s_axi_arprot,
  input  logic                  s_axi_arvalid,
  output logic                  s_axi_arready,
  output logic [31:0]           s_axi_rdata,
  output logic [1:0]            s_axi_rresp,
  output logic                  s_axi_rvalid,
  input  logic                  s_axi_rready,

  output logic irq,

  // ---- Table A-22: hierarchical clock control, into the clock controller ----
  input  logic hc_qreqn_i,
  output logic hc_qacceptn_o,
  output logic hc_qdeny_o,
  output logic hc_qactive_o,

  // ---- Table A-24's QACTIVE-only bits, and Table A-25's two controls ----
  input  logic [NUM_QACTIVE_ONLY-1:0] qactive_only_i,
  input  logic                        clk_force_i,
  input  logic [7:0]                  entry_delay_i,

  // ---- The device domain: the stand-in's stimulus, as on ppu_pd_top ----
  input  logic             dclk,
  input  logic             start,
  input  logic [CNT_W-1:0] work_len,
  input  logic             light_work,
  input  logic             wake,
  input  logic             deny_enb,
  input  logic [1:0]       ip_cmd,
  input  logic [7:0]       ip_seed
);

  // ---- Between the domain and its device ----
  logic        dummy_clk;          // the IP's gated clock
  logic        wl_rst_n;           // IP non-retained reset, synchronized into dclk
  logic        wl_ret_rst_n;       // IP retained reset, synchronized into dclk
  logic        busy;               // the IP's busy flag, after its isolation clamp
  logic [7:0]  ram_sleep, ram_sd;  // registered SRAM macro pins, per bank

  // ---- Domain outputs with no RTL consumer here: see ppu_pd_top ----
  logic        dev_quiescent_ok;
  logic [15:0] ppuhwstat;
  logic        dev_isolaten, logic_on, logic_ret, ret_n;

  ppu_axi_dom_top #(
    .DEF_PWR_DYN_EN        (DEF_PWR_DYN_EN),
    .DEF_PWR_POLICY        (DEF_PWR_POLICY),
    .WARM_RST_DEVREQEN_CFG (WARM_RST_DEVREQEN_CFG),
    .RST_HWSTAT_DLY_CFG    (RST_HWSTAT_DLY_CFG),
    .ISO_CLKEN_DLY_CFG     (ISO_CLKEN_DLY_CFG),
    .CLKEN_RST_DLY_CFG     (CLKEN_RST_DLY_CFG),
    .CLKEN_ISO_DLY_CFG     (CLKEN_ISO_DLY_CFG),
    .ISO_RST_DLY_CFG       (ISO_RST_DLY_CFG),
    .DYN_ON_SPT_CFG        (DYN_ON_SPT_CFG),
    .DYN_FUNC_RET_SPT_CFG  (DYN_FUNC_RET_SPT_CFG),
    .DYN_FULL_RET_SPT_CFG  (DYN_FULL_RET_SPT_CFG),
    .DYN_MEM_OFF_SPT_CFG   (DYN_MEM_OFF_SPT_CFG),
    .DYN_MEM_RET_SPT_CFG   (DYN_MEM_RET_SPT_CFG),
    .DYN_OFF_SPT_CFG       (DYN_OFF_SPT_CFG),
    .STA_FUNC_RET_SPT_CFG  (STA_FUNC_RET_SPT_CFG),
    .STA_FULL_RET_SPT_CFG  (STA_FULL_RET_SPT_CFG),
    .STA_MEM_OFF_SPT_CFG   (STA_MEM_OFF_SPT_CFG),
    .STA_MEM_RET_SPT_CFG   (STA_MEM_RET_SPT_CFG),
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG),
    .FUNC_RET_RAM_REG_CFG  (FUNC_RET_RAM_REG_CFG),
    .FULL_RET_RAM_REG_CFG  (FULL_RET_RAM_REG_CFG),
    .MEM_RET_RAM_REG_CFG   (MEM_RET_RAM_REG_CFG),
    .LOCK_CFG              (LOCK_CFG),
    .SW_DEV_DEL_CFG        (SW_DEV_DEL_CFG),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .SYNC_STAGES           (SYNC_STAGES),
    .PCSM_SYNC_EN          (PCSM_SYNC_EN),
    .DEV_SYNC_EN           (DEV_SYNC_EN),
    .DEV_ACTIVE_SYNC_EN    (DEV_ACTIVE_SYNC_EN),
    .PCSM_RESET_MODESTAT   (PCSM_RESET_MODESTAT),
    .PCSM_RET_SETTLE       (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE     (PCSM_LOGIC_SETTLE),
    .PCSM_TINIT_WAIT       (PCSM_TINIT_WAIT),
    .CLK_Q_CH_SYNC         (CLK_Q_CH_SYNC),
    .CLK_QACTIVE_SYNC      (CLK_QACTIVE_SYNC),
    .QCLK_SYNC_EN          (QCLK_SYNC_EN),
    .NUM_QACTIVE_ONLY      (NUM_QACTIVE_ONLY),
    .ACTIVE_DENY_EN        (ACTIVE_DENY_EN),
    .AXI_ADDR_W            (AXI_ADDR_W),
    .WAKE_TIMEOUT          (WAKE_TIMEOUT)
  ) u_dom (
    .aclk          (aclk),
    .aresetn       (aresetn),

    .s_axi_awaddr  (s_axi_awaddr ),
    .s_axi_awprot  (s_axi_awprot ),
    .s_axi_awvalid (s_axi_awvalid),
    .s_axi_awready (s_axi_awready),
    .s_axi_wdata   (s_axi_wdata  ),
    .s_axi_wstrb   (s_axi_wstrb  ),
    .s_axi_wvalid  (s_axi_wvalid ),
    .s_axi_wready  (s_axi_wready ),
    .s_axi_bresp   (s_axi_bresp  ),
    .s_axi_bvalid  (s_axi_bvalid ),
    .s_axi_bready  (s_axi_bready ),
    .s_axi_araddr  (s_axi_araddr ),
    .s_axi_arprot  (s_axi_arprot ),
    .s_axi_arvalid (s_axi_arvalid),
    .s_axi_arready (s_axi_arready),
    .s_axi_rdata   (s_axi_rdata  ),
    .s_axi_rresp   (s_axi_rresp  ),
    .s_axi_rvalid  (s_axi_rvalid ),
    .s_axi_rready  (s_axi_rready ),

    .irq           (irq),

    .hc_qreqn_i    (hc_qreqn_i),
    .hc_qacceptn_o (hc_qacceptn_o),
    .hc_qdeny_o    (hc_qdeny_o),
    .hc_qactive_o  (hc_qactive_o),
    .qactive_only_i(qactive_only_i),
    .clk_force_i   (clk_force_i),
    .entry_delay_i (entry_delay_i),

    .dclk              (dclk),
    .dev_quiescent_busy(busy),
    .dev_quiescent_deny(deny_enb && busy),
    .dev_wake          (wake | busy),
    .dev_quiescent_ok  (dev_quiescent_ok),
    .dev_clk           (dummy_clk),
    .dev_clken_req     (),            // DEVCLKEN for a SoC clkgate (H16); unused here
    .dev_nret_rst_n    (wl_rst_n),
    .dev_ret_rst_n     (wl_ret_rst_n),
    .dev_isolaten      (dev_isolaten),
    .ppuhwstat         (ppuhwstat),
    .logic_on          (logic_on),
    .logic_ret         (logic_ret),
    .ret_n             (ret_n),
    .ram_sleep         (ram_sleep),
    .ram_sd            (ram_sd)
  );

  ppu_device_ip #(.CNT_W(CNT_W)) u_ip (
    .clk       (dummy_clk),
    .nret_rst_n(wl_rst_n),
    .ret_rst_n (wl_ret_rst_n),
    .start     (start),
    .work_len  (work_len),
    .light_work(light_work),
    .busy      (busy),
    .done      (),
    .ip_cmd    (ip_cmd),
    .ip_seed   (ip_seed),
    .bank_sleep(ram_sleep),
    .bank_sd   (ram_sd)
  );

endmodule
