`timescale 1ns/1ps
// AXI4-Lite -> a PPU-controlled power domain with a gated PPU clock, with the
// device outside it.
//
// References: Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN
// 0051E) Section 6.2; Arm CoreLink PCK-600 TRM (101150) Sections 3.5, 3.6;
// AMBA Low Power Interface Specification (ARM IHI 0068C) Section 2.1.2.
//
//   ┌──────────────────────── ppu_axi_dom_top ───────────────────────┐
//   │                                                                │
//   │  AXI4-Lite ──► ppu_axi_lite_adapter ──reg_*──┐                 │
//   │   (aclk)              ▲       │ pwakeup      │                 │
//   │                       │       ▼              ▼                 │
//   │                  ppu_clk_ok  ppu_clk_ctrl ──► ppu_dom_top ──────┼──► device side
//   │                       ▲           │ ppu_clken (ppu_clk)        │
//   │                       │           ▼                            │
//   │                       └── PPUCLK* ◄─ gate ───┘                 │
//   └────────────────────────────────────────────────────────────────┘
//
// This is what soc4 instantiates for each of its four domains (u_dom in
// soc4_cpu_dom and soc4_acc_dom), with the
// device -- ppu_device_ip in simulation, a CVA6 core, a DSP or an NPU in the
// SoC -- on the device-side ports, which are ppu_dom_top's, passed through
// unchanged. ppu_axi_pd_top is this module plus ppu_device_ip.
//
// It adds no logic beyond what ppu_axi_pd_top had: the AXI bridge, the PPU's
// clock controller and its gate, over ppu_dom_top instead of ppu_pd_top. The
// inner instance keeps the name u_pd, so a path that reached the PPU or the
// PCSM through ppu_axi_pd_top's u_pd reaches the same logic through this
// module's.
//
// THE CLOCK ARRANGEMENT IS ppu_clkq_top's
//
// aclk free-running for the adapter and the clock controller; ppu_clk gated for
// ppu_dom_top, which puts the PPU and the PCSM together behind one gate. See
// ppu_clkq_top's header for why sharing the gate between those two is right
// rather than merely convenient, and ppu_axi_lite_adapter's for why the bridge
// must not be behind it.
//
// PARAMETERS
//
// Every ppu_dom_top parameter is forwarded, so each of soc4's domains can
// set its own mode support (*_SPT_CFG) and switch settling (PCSM_*_SETTLE).
// The defaults are the values ppu_axi_pd_top built with before, so nothing
// that does not set them changes. PGOOD_EN is not among them: ppu_dom_top
// fixes it at 0 (see its header).

import ppu_pkg::*;
import qchannel_pkg::*;

module ppu_axi_dom_top #(
  // ---- Forwarded to ppu_dom_top; see there, and ppu_top, for each ----
  parameter bit          DEF_PWR_DYN_EN        = 1'b0,
  parameter logic [3:0]  DEF_PWR_POLICY        = PM_ON,
  parameter bit          WARM_RST_DEVREQEN_CFG = 1'b1,
  parameter logic [7:0]  RST_HWSTAT_DLY_CFG    = 8'd2,
  parameter logic [7:0]  ISO_CLKEN_DLY_CFG     = 8'd2,
  parameter logic [7:0]  CLKEN_RST_DLY_CFG     = 8'd2,
  parameter logic [7:0]  CLKEN_ISO_DLY_CFG     = 8'd2,
  parameter logic [7:0]  ISO_RST_DLY_CFG       = 8'd2,
  parameter bit          DYN_ON_SPT_CFG        = 1'b1,
  parameter bit          DYN_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit          DYN_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit          DYN_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit          DYN_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit          DYN_OFF_SPT_CFG       = 1'b1,
  parameter bit          STA_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit          STA_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit          STA_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit          STA_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit          OFF_MEM_RET_TRANS_CFG = 1'b1,
  parameter bit          FUNC_RET_RAM_REG_CFG  = 1'b1,
  parameter bit          FULL_RET_RAM_REG_CFG  = 1'b1,
  parameter bit          MEM_RET_RAM_REG_CFG   = 1'b1,
  parameter bit          LOCK_CFG              = 1'b1,
  parameter bit          SW_DEV_DEL_CFG        = 1'b1,
  parameter bit          PWR_MODE_ENTRY_DEL_CFG= 1'b1,
  parameter int unsigned SYNC_STAGES           = 2,
  parameter bit          PCSM_SYNC_EN          = 1'b0,
  parameter bit          DEV_SYNC_EN           = 1'b1,
  parameter bit          DEV_ACTIVE_SYNC_EN    = 1'b1,
  parameter logic [3:0]  PCSM_RESET_MODESTAT   = PM_OFF,
  parameter int unsigned PCSM_RET_SETTLE       = 0,
  parameter int unsigned PCSM_LOGIC_SETTLE     = 0,
  parameter int unsigned PCSM_TINIT_WAIT       = 16,

  // ---- The PPU's clock is a GATED LEAF, not another domain ----
  //
  // ppu_clk_ctrl runs on the ungated clock and ppu_dom_top on the leaf that
  // u_gate produces from it. While the gate is open the two are edge-aligned;
  // while it is shut the PPU receives no edges at all and therefore samples
  // nothing. Neither state is a clock domain crossing, and a frozen clock is
  // not an asynchronous clock -- there is no edge for a flop to be metastable
  // on.
  //
  // An earlier version of this comment defaulted these to 1 and justified it as
  // "the two are only synchronous while the gate is open, and the whole point
  // of the block is that sometimes it is not." That conflated "no clock" with
  // "different clock" and cost two cycles on every wake and every gate entry,
  // plus six flops, for nothing.
  //
  // PCSA 7.1.3 sanctions the arrangement and names its price, which is a
  // physical one rather than a logical one: "It is also possible to implement
  // high-level clock gating for multiple synchronous clock domains with
  // communication between them. However, this creates non-common clock
  // insertion paths that places pressure on clock tree balancing... These
  // circumstances also occur if a free-running clock domain has synchronous
  // interfaces to a high-level clock gated domain." Its mitigation is to place
  // the gate lower in the tree to lengthen the common path. Nothing in the RTL
  // can do that; it is a constraint on whoever runs CTS.
  //
  // HC_Q_CH_SYNC and PWR_Q_CH_SYNC stay 1. Those channels come from a
  // controller ABOVE this subsystem, whose clock this module cannot know.
  //
  // CLK_QACTIVE_SYNC = 0 is right only while dclk is aclk (soc4). PPUCLKQACTIVE
  // carries the device's RAW DEVQACTIVE (ppu_top: "This must be the RAW pin"),
  // so with a dclk asynchronous to aclk the clock controller must synchronise
  // it: set CLK_QACTIVE_SYNC = 1 (VC CDC, make vccdc configuration ppudom,
  // finding CDC-1 in signoff/SIGNOFF_REPORT.md).
  parameter bit          CLK_Q_CH_SYNC         = 1'b0,
  parameter bit          CLK_QACTIVE_SYNC      = 1'b0,
  parameter bit          QCLK_SYNC_EN          = 1'b0,

  // ---- The clock controller's (PCK-600 Table 3-7) ----
  parameter int unsigned NUM_QACTIVE_ONLY      = 1,
  parameter bit          ACTIVE_DENY_EN        = 1'b1,

  // ---- The bridge's ----
  parameter int unsigned AXI_ADDR_W            = 32,
  parameter int unsigned WAKE_TIMEOUT          = 1024
) (
  // ---- Free-running: the AXI bridge and the clock controller ----
  input  logic aclk,
  input  logic aresetn,

  // ---- AXI4-Lite subordinate ----
  input  logic [AXI_ADDR_W-1:0] s_axi_awaddr,
  input  logic [2:0]            s_axi_awprot,
  input  logic                  s_axi_awvalid,
  output logic                  s_axi_awready,
  input  logic [31:0]           s_axi_wdata,
  input  logic [3:0]            s_axi_wstrb,
  input  logic                  s_axi_wvalid,
  output logic                  s_axi_wready,
  output logic [1:0]            s_axi_bresp,
  output logic                  s_axi_bvalid,
  input  logic                  s_axi_bready,
  input  logic [AXI_ADDR_W-1:0] s_axi_araddr,
  input  logic [2:0]            s_axi_arprot,
  input  logic                  s_axi_arvalid,
  output logic                  s_axi_arready,
  output logic [31:0]           s_axi_rdata,
  output logic [1:0]            s_axi_rresp,
  output logic                  s_axi_rvalid,
  input  logic                  s_axi_rready,

  output logic irq,

  // ---- Table A-22: hierarchical clock control, into the clock controller ----
  input  logic hc_qreqn_i,
  output logic hc_qacceptn_o,
  output logic hc_qdeny_o,
  output logic hc_qactive_o,

  // ---- Table A-24's QACTIVE-only bits, and Table A-25's two controls ----
  input  logic [NUM_QACTIVE_ONLY-1:0] qactive_only_i,
  input  logic                        clk_force_i,
  input  logic [7:0]                  entry_delay_i,

  // ---- The device side: ppu_dom_top's, passed through unchanged ----
  input  logic        dclk,
  input  logic        dev_quiescent_busy,
  input  logic        dev_quiescent_deny,
  input  logic        dev_wake,
  output logic        dev_quiescent_ok,
  output logic        dev_clk,
  output logic        dev_clken_req,      // DEVCLKEN in dclk (ppu_dom_top; H16)
  output logic        dev_nret_rst_n,
  output logic        dev_ret_rst_n,
  output logic        dev_isolaten,
  output logic [15:0] ppuhwstat,
  output logic        logic_on,
  output logic        logic_ret,
  output logic        ret_n,
  output logic [7:0]  ram_sleep,
  output logic [7:0]  ram_sd
);

  // The PPU's software interface, between the bridge and the domain.
  logic [11:0] reg_waddr, reg_raddr;
  logic [31:0] reg_wdata, reg_rdata;
  logic [ 3:0] reg_wstrb;
  logic        reg_wen, reg_ren;
  logic        pwakeup, ppu_clk_ok;

  // The PPU's clock Q-Channel, and the clock it controls.
  logic ppuclk_qreqn, ppuclk_qacceptn, ppuclk_qdeny, ppuclk_qactive;
  logic ppu_clken, ppu_clk;

  // The same decode as ppu_top_axi_lite, off the same four wires. Q_RUN is
  // evidence rather than convention: PPUCLKQACCEPTn is registered on the PPU's
  // clk, so it could only be HIGH if the PPU was being clocked.
  //
  // NOT ppu_clken. u_clkctrl's gate enable is right there and driving ppu_clk_ok
  // from it is the obvious simplification -- it was tried, and it passes every
  // other check in ppu_axi_lite_tb. The two definitions differ in exactly one
  // state, which is what group L12 now pins down:
  //
  //     clk_running <= clk_force_i | dftcgen | !base_req | !all_stopped;
  //
  // so with an upstream controller holding the domain quiescent (up_hold
  // pinning base_req HIGH) AND clk_force_i asserted, ppu_clken is HIGH while this
  // channel sits in Q_STOPPED. The clock is PRESENT. It is not GUARANTEED.
  //
  // The difference matters because Table A-25 makes clk_force_i asynchronous
  // and nothing coordinates it with an access in flight: it can deassert
  // mid-transaction and the clock vanishes with no handshake. Q_RUN cannot do
  // that -- removing the clock requires Q_REQUEST, and the PPU denies that
  // while PWAKEUP is HIGH, so the bridge holds a veto over its own clock.
  //
  // The cost is latency: Q_RUN lags ppu_clken by the exit handshake, so every
  // access to a gated PPU pays a few extra cycles. That is the trade, and it is
  // the right way round for a bus bridge.
  assign ppu_clk_ok = (qch_decode(ppuclk_qreqn, ppuclk_qacceptn, ppuclk_qdeny) == Q_RUN);

  ppu_axi_lite_adapter #(
    .REG_ADDR_W  (12),
    .AXI_ADDR_W  (AXI_ADDR_W),
    .WAKE_TIMEOUT(WAKE_TIMEOUT)
  ) u_axi (
    .aclk   (aclk),
    .aresetn(aresetn),

    .s_axi_awaddr (s_axi_awaddr ),
    .s_axi_awprot (s_axi_awprot ),
    .s_axi_awvalid(s_axi_awvalid),
    .s_axi_awready(s_axi_awready),
    .s_axi_wdata  (s_axi_wdata  ),
    .s_axi_wstrb  (s_axi_wstrb  ),
    .s_axi_wvalid (s_axi_wvalid ),
    .s_axi_wready (s_axi_wready ),
    .s_axi_bresp  (s_axi_bresp  ),
    .s_axi_bvalid (s_axi_bvalid ),
    .s_axi_bready (s_axi_bready ),
    .s_axi_araddr (s_axi_araddr ),
    .s_axi_arprot (s_axi_arprot ),
    .s_axi_arvalid(s_axi_arvalid),
    .s_axi_arready(s_axi_arready),
    .s_axi_rdata  (s_axi_rdata  ),
    .s_axi_rresp  (s_axi_rresp  ),
    .s_axi_rvalid (s_axi_rvalid ),
    .s_axi_rready (s_axi_rready ),

    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wstrb(reg_wstrb),
    .reg_wen  (reg_wen  ),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren  ),
    .reg_rdata(reg_rdata),

    .pwakeup   (pwakeup),
    .ppu_clk_ok(ppu_clk_ok)
  );

  ppu_clk_ctrl #(
    .NUM_Q_CHL       (1),
    .NUM_QACTIVE_ONLY(NUM_QACTIVE_ONLY),
    .ACTIVE_DENY_EN  (ACTIVE_DENY_EN),
    .CLK_Q_CH_SYNC   (CLK_Q_CH_SYNC),
    .CLK_QACTIVE_SYNC(CLK_QACTIVE_SYNC),
    .SYNC_STAGES     (SYNC_STAGES)
  ) u_clkctrl (
    .clk    (aclk),
    .reset_n(aresetn),

    .hc_qreqn_i    (hc_qreqn_i),
    .hc_qacceptn_o (hc_qacceptn_o),
    .hc_qdeny_o    (hc_qdeny_o),
    .hc_qactive_o  (hc_qactive_o),

    // The power channel is tied to Q_RUN here. ppu_clkctrl_tb group K12 runs the
    // whole sequence on pwr_* and ppu_clkq_tb G5 runs it in a system, so the
    // path is covered; bringing it out again would be a fourth copy of the same
    // four ports with nothing new to say.
    .pwr_qreqn_i   (1'b1),
    .pwr_qacceptn_o(),
    .pwr_qdeny_o   (),
    .pwr_qactive_o (),

    .clk_qreqn_o   (ppuclk_qreqn),
    .clk_qacceptn_i(ppuclk_qacceptn),
    .clk_qdeny_i   (ppuclk_qdeny),
    .clk_qactive_i ({qactive_only_i, ppuclk_qactive}),

    .clken_o      (ppu_clken),
    .clk_force_i  (clk_force_i),
    .entry_delay_i(entry_delay_i),
    .dftcgen      (1'b0)
  );

  clk_gate u_gate (
    .clk      (aclk),
    .clk_en   (ppu_clken),
    .gated_clk(ppu_clk)
  );

  ppu_dom_top #(
    .DEF_PWR_DYN_EN        (DEF_PWR_DYN_EN),
    .DEF_PWR_POLICY        (DEF_PWR_POLICY),
    .WARM_RST_DEVREQEN_CFG (WARM_RST_DEVREQEN_CFG),
    .RST_HWSTAT_DLY_CFG    (RST_HWSTAT_DLY_CFG),
    .ISO_CLKEN_DLY_CFG     (ISO_CLKEN_DLY_CFG),
    .CLKEN_RST_DLY_CFG     (CLKEN_RST_DLY_CFG),
    .CLKEN_ISO_DLY_CFG     (CLKEN_ISO_DLY_CFG),
    .ISO_RST_DLY_CFG       (ISO_RST_DLY_CFG),
    .DYN_ON_SPT_CFG        (DYN_ON_SPT_CFG),
    .DYN_FUNC_RET_SPT_CFG  (DYN_FUNC_RET_SPT_CFG),
    .DYN_FULL_RET_SPT_CFG  (DYN_FULL_RET_SPT_CFG),
    .DYN_MEM_OFF_SPT_CFG   (DYN_MEM_OFF_SPT_CFG),
    .DYN_MEM_RET_SPT_CFG   (DYN_MEM_RET_SPT_CFG),
    .DYN_OFF_SPT_CFG       (DYN_OFF_SPT_CFG),
    .STA_FUNC_RET_SPT_CFG  (STA_FUNC_RET_SPT_CFG),
    .STA_FULL_RET_SPT_CFG  (STA_FULL_RET_SPT_CFG),
    .STA_MEM_OFF_SPT_CFG   (STA_MEM_OFF_SPT_CFG),
    .STA_MEM_RET_SPT_CFG   (STA_MEM_RET_SPT_CFG),
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG),
    .FUNC_RET_RAM_REG_CFG  (FUNC_RET_RAM_REG_CFG),
    .FULL_RET_RAM_REG_CFG  (FULL_RET_RAM_REG_CFG),
    .MEM_RET_RAM_REG_CFG   (MEM_RET_RAM_REG_CFG),
    .LOCK_CFG              (LOCK_CFG),
    .SW_DEV_DEL_CFG        (SW_DEV_DEL_CFG),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .SYNC_STAGES           (SYNC_STAGES),
    .PCSM_SYNC_EN          (PCSM_SYNC_EN),
    .DEV_SYNC_EN           (DEV_SYNC_EN),
    .DEV_ACTIVE_SYNC_EN    (DEV_ACTIVE_SYNC_EN),
    .QCLK_SYNC_EN          (QCLK_SYNC_EN),
    .PCSM_RESET_MODESTAT   (PCSM_RESET_MODESTAT),
    .PCSM_RET_SETTLE       (PCSM_RET_SETTLE),
    .PCSM_LOGIC_SETTLE     (PCSM_LOGIC_SETTLE),
    .PCSM_TINIT_WAIT       (PCSM_TINIT_WAIT)
  ) u_pd (
    // The gated leaf. aon_rst_n is not gated with it -- see ppu_clkq_top.
    .aon_clk  (ppu_clk),
    .aon_rst_n(aresetn),

    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wen  (reg_wen  ),
    .reg_wstrb(reg_wstrb),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren  ),
    .reg_rdata(reg_rdata),
    .irq      (irq),

    .ppuclk_qreqn   (ppuclk_qreqn),
    .ppuclk_qacceptn(ppuclk_qacceptn),
    .ppuclk_qdeny   (ppuclk_qdeny),
    .ppuclk_qactive (ppuclk_qactive),
    .pwakeup        (pwakeup),

    .dclk              (dclk),
    .dev_quiescent_busy(dev_quiescent_busy),
    .dev_quiescent_deny(dev_quiescent_deny),
    .dev_wake          (dev_wake),
    .dev_quiescent_ok  (dev_quiescent_ok),
    .dev_clk           (dev_clk),
    .dev_clken_req     (dev_clken_req),
    .dev_nret_rst_n    (dev_nret_rst_n),
    .dev_ret_rst_n     (dev_ret_rst_n),
    .dev_isolaten      (dev_isolaten),
    .ppuhwstat         (ppuhwstat),
    .logic_on          (logic_on),
    .logic_ret         (logic_ret),
    .ret_n             (ret_n),
    .ram_sleep         (ram_sleep),
    .ram_sd            (ram_sd)
  );

endmodule
