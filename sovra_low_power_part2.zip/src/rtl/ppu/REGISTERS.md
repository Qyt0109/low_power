# PPU programmer's reference

Every register this PPU implements, the values each field accepts, and how to
drive them. Field layouts and reset values below are taken from
[`ppu_regs.sv`](ppu_regs.sv) and [`ppu_pkg.sv`](ppu_pkg.sv), not from the
specification — where the two differ the reason is stated.

Scope reminder: one device Q-Channel, no emulation modes, no operating modes. See
[FUNCTIONS.md](FUNCTIONS.md) for what that excludes and [OPTIONS.md](OPTIONS.md)
for which build parameters move.

---

## 1. The bus

Not APB. §6.2.1 makes the bus type IMPLEMENTATION DEFINED and gives APB only as an
example, so this is a plain strobe interface:

| Signal | Dir | Description |
|---|---|---|
| `reg_waddr[11:0]` | in | write offset from the register base |
| `reg_wdata[31:0]` | in | write data |
| `reg_wen` | in | write strobe, one cycle |
| `reg_wstrb[3:0]` | in | byte lanes, one bit per byte of `reg_wdata` |
| `reg_raddr[11:0]` | in | read offset, **independent of `reg_waddr`** |
| `reg_ren` | in | read strobe, one cycle |
| `reg_rdata[31:0]` | out | read data, **registered — valid the cycle after `reg_ren`** |

Reads are always 32-bit. Writes are synchronous to `aon_clk`, and there is no
wait state and no error response.

```systemverilog
// write -- all four lanes
@(negedge aon_clk); reg_waddr <= 12'h000; reg_wdata <= 32'd8;
                    reg_wstrb <= 4'hF;    reg_wen   <= 1'b1;
@(negedge aon_clk); reg_wen <= 1'b0;

// read -- rdata is valid one clock after ren
@(negedge aon_clk); reg_raddr <= 12'h008; reg_ren <= 1'b1;
@(negedge aon_clk); reg_ren <= 1'b0;
@(negedge aon_clk); value = reg_rdata;

// both at once -- legal, and the point of the split
@(negedge aon_clk); reg_waddr <= 12'h000; reg_wdata <= 32'd8;
                    reg_wstrb <= 4'hF;    reg_wen   <= 1'b1;
                    reg_raddr <= 12'h008; reg_ren   <= 1'b1;
@(negedge aon_clk); reg_wen <= 1'b0; reg_ren <= 1'b0;
```

**Reserved bits are WI/RAZ** (§5.2): writes are ignored, reads return zero. That
applies to whole registers that are reserved in this configuration as well as to
reserved fields inside implemented registers.

### Concurrent read and write

`reg_waddr` and `reg_raddr` are **separate buses**, not one address with a
direction bit. AXI4-Lite places no ordering between AW/W/B and AR/R, so a bridge
may have a write and a read outstanding at the same time; a shared address bus
would force it to arbitrate and serialise them. With two buses the register file
decodes twice and the bridge needs no arbiter at all.

Asserting `reg_wen` and `reg_ren` on the same cycle is legal, at any pair of
addresses. Reads have no side effects anywhere in this register file — nothing
is read-to-clear — so there is no case where a concurrent read disturbs a write.

**A read concurrent with a write to the same register returns the value from
before the write.** `reg_rdata` is combinational from the register state and the
write commits on the same edge that captures it. That is the only ordering
statable as a rule, since AXI4-Lite would not have told the bridge which the
master intended first. It matters most for `PPU_ISR`/`PPU_AISR`: a read
concurrent with a write-1-to-clear returns the bits that were just cleared, and
the clear still happens. The usual read-then-write-back service sequence is a
sequence, not a concurrency, so it is unaffected.

Checked by `ppuregdoc` §1 — different addresses, same address, and that the
write address never reaches the read decode.

### Byte lanes

`reg_wstrb` is an extension — §6.2.1's APB3 example has no strobe — added so the
register file can sit directly behind an APB4 `PSTRB` or an AXI4-Lite `WSTRB`.
**A master that only ever writes whole words ties it to `4'hF` and can ignore the
rest of this section.**

Bit *n* enables byte *n* of `reg_wdata`. A byte whose lane is clear is not
written, and every register keeps the bits it already held there. Three
consequences are worth knowing before using it:

- **`reg_wstrb == 0` is not a write.** It changes nothing, clears no
  write-1-to-clear bit, and raises no interrupt — including the
  `STA_POLICY_TRN_IRQ` that a `PPU_PWPR` write would otherwise raise.

- **`PPU_PWPR` is admitted as a merged pair.** `PWR_POLICY` is in lane 0 and
  `PWR_DYN_EN` is in lane 1, but §4.1.1 validates the two together. A lane-0-only
  write is checked against the `PWR_DYN_EN` **the register already holds**, so
  whatever the master leaves on `reg_wdata[8]` in an unselected lane is ignored
  entirely — it can neither cause a rejection nor sneak a dynamic enable
  through. The same holds in reverse for a lane-1-only write, and `LOCK_EN` [12]
  rides with lane 1.

- **`PPU_ISR` clears per lane.** The four event bits are in lane 0 and
  `PWR_ACTIVE_EDGE_IRQ` [8] is in lane 1. Writing `0x101` with `reg_wstrb =
  4'b0001` clears the event bit and leaves the edge bit set. A masked lane
  clears nothing — it is not a read-modify-write.

Every implemented field lies wholly within one byte lane, so a lane never
half-writes a field. `PPU_PWCR.PWR_DEVACTIVEEN` is the one whose *architectural*
extent [18:8] crosses lanes, but with a single Q-Channel only bit [8] exists, so
lane 1 covers it.

`ppube` is the suite for this. Every other suite drives `4'hF`, so all of them
would keep passing if the strobe were ignored outright; `ppube` only ever writes
with lanes masked.

## 2. Address map

| Offset | Register | Access | Default | Present? |
|---|---|---|---|---|
| `0x000` | `PPU_PWPR` | R/W | `DEF_PWR_POLICY` | yes |
| `0x004` | `PPU_PMER` | — | `0x0` | **reserved** — no emulation modes |
| `0x008` | `PPU_PWSR` | RO | tracks hardware | yes |
| `0x010` | `PPU_DISR` | RO | — | yes |
| `0x014` | `PPU_MISR` | RO | — | yes |
| `0x018` | `PPU_STSR` | — | `0x0` | **reserved** — single Q-Channel (§5.2.6) |
| `0x01C` | `PPU_UNLK` | WO | reads `0x0` | yes, if `LOCK_SPT` |
| `0x020` | `PPU_PWCR` | R/W | `0x0000_0101` | yes |
| `0x024` | `PPU_PTCR` | R/W | `WARM_RST_DEVREQEN_CFG` | yes |
| `0x030` | `PPU_IMR` | R/W | `0x0000_0022` | yes |
| `0x034` | `PPU_AIMR` | R/W | `0x0000_0006` | yes |
| `0x038` | `PPU_ISR` | R/W1C | `0x0` | yes |
| `0x03C` | `PPU_AISR` | R/W1C | `0x0` | yes |
| `0x040` | `PPU_IESR` | R/W | `0x0` | yes |
| `0x044` | `PPU_OPSR` | — | `0x0` | **reserved** — no operating modes |
| `0x050` | `PPU_FUNRR` | R/W | `0x00` | yes, if `RET_RAM_REGS` |
| `0x054` | `PPU_FULRR` | R/W | `0x00` | yes, if `RET_RAM_REGS` |
| `0x058` | `PPU_MEMRR` | R/W | `0x00` | yes, if `RET_RAM_REGS` |
| `0x160` | `PPU_EDTR0` | R/W | `0x0` | yes, if `PWR_MODE_ENTRY_DEL_SPT` |
| `0x164` | `PPU_EDTR1` | R/W | `0x0` | yes, if `PWR_MODE_ENTRY_DEL_SPT` |
| `0x170` | `PPU_DCDR0` | R/W* | from parameters | yes; **RO** if `!SW_DEV_DEL_SPT` |
| `0x174` | `PPU_DCDR1` | R/W* | from parameters | yes; **RO** if `!SW_DEV_DEL_SPT` |
| `0xFB0` | `PPU_IDR0` | RO | `0x1E53_E501` | yes |
| `0xFB4` | `PPU_IDR1` | RO | `0x0000_1077` | yes |
| `0xFC8` | `PPU_IIDR` | RO | `0x50C0_1000` | yes |
| `0xFCC` | `PPU_AIDR` | RO | `0x0000_0011` | yes |

Defaults shown are for the default build. Any unmapped offset reads zero.

The specification calls this column **Default** in its own register tables
(Chapter 5), and it means the value after reset. This document uses the same word
throughout, including in the per-field tables in §4.

### Defaults that are not constants

Most of the column above is a plain number, but six entries are not, and a driver
that hardcodes them will be wrong on some builds. They fall into four kinds.
The same caveat applies to the per-field defaults in §4, which name the parameter
where one is involved.

| Register / field | Default is… | Expression |
|---|---|---|
| `PPU_PWPR.PWR_POLICY` | **sampled from a pin** | `(DEF_PWR_POLICY == OFF && PCSMMODESTAT[3:0] == MEM_RET) ? MEM_RET : DEF_PWR_POLICY` |
| `PPU_PWPR.PWR_DYN_EN` | a build parameter | `DEF_PWR_DYN_EN` |
| `PPU_PTCR.WARM_RST_DEVREQEN` | a build parameter | `WARM_RST_DEVREQEN_CFG` |
| `PPU_DCDR0` / `PPU_DCDR1` | build parameters | the five `*_DLY_CFG` values |
| `PPU_IMR` | **changes shape with a parameter** | `0x22` normally, `0x02` when `LOCK_SPT = 0` |
| `PPU_IDR0` / `IDR1` / `IIDR` | computed from the whole configuration | — |

**1. Sampled from a pin — the one that surprises people.**

`PPU_PWPR.PWR_POLICY` does not always reset to `DEF_PWR_POLICY`. If the build has
`OFF → MEM_RET` transitions enabled and the `PCSMMODESTAT` pin reports `MEM_RET`
at reset release, the PPU comes up in `MEM_RET` — and §4.1.6 requires the
**policy** to be set to `MEM_RET` too, not just the status.

The reason is Table 4-13. The PCSM is telling the PPU that the domain is already
in `MEM_RET`, so leaving the policy at `OFF` would make the PPU immediately walk
the domain down to `OFF` — dropping the RAM retention the PCSM just said it was
holding, for a mode the software never asked to leave. Setting the policy to
match is what makes the PPU **stay** there, which is what the table specifies.

Practical consequence: **read `PPU_PWPR` after reset rather than assuming it.**
`PCSMMODESTAT` is a board-level input, so the same RTL build can come up with two
different policies. Getting this wrong was defect **F5**.

**2. Set by a build parameter.** `PWR_DYN_EN`, `WARM_RST_DEVREQEN` and the five
device-control delays all reset to values chosen at elaboration. The delays are
the ones that matter in practice: a driver that assumes `PPU_DCDR0` resets to
zero, or to any particular number, is assuming a build.

**3. Changes shape with a parameter.** `PPU_IMR` resets to `0x22` — `LOCKED` and
`STA_ACCEPT` masked — but bit 5 does not exist when `LOCK_SPT = 0`, so the reset
value is `0x02` there. Read-modify-write is safe; writing a remembered constant
is not. (`PPU_AIMR` is unconditional at `0x06`.)

**4. Computed from the configuration.** `PPU_IDR0`, `PPU_IDR1` and `PPU_IIDR`
describe the build and change with almost every parameter — that is their whole
purpose. See §4.

### Registers with no default at all

Four entries in the table have no stored state, so "default" does not apply to
them in the usual sense — the §4 tables say what they read instead:

| Register | What it actually is |
|---|---|
| `PPU_PWSR` | a live view of the sequencer — `PWR_STATUS`, `PWR_DYN_STATUS` and `LOCK_STATUS` are wires, not flops. After reset it reads whatever mode the PPU came up in |
| `PPU_DISR` | a live view of `DEVQACTIVE`, before the `PWR_DEVACTIVEEN` gate |
| `PPU_MISR` | a live view of `DEVQDENY`, `DEVQACCEPTn` and `PCSMPACCEPT` |
| `PPU_UNLK` | decoded for **writes only**. It has no read path, so reads fall through to the default arm and return zero — always, not just after reset |

`PPU_ISR.OTHER_IRQ` is in the same category one level down: it is derived from
`PPU_AISR` rather than stored, which is why writing 1 to it does not clear it.

And the three reserved registers — `PPU_PMER`, `PPU_STSR`, `PPU_OPSR` — read zero
permanently, not merely out of reset.

## 3. Power mode values

Used by `PPU_PWPR.PWR_POLICY` and reported by `PPU_PWSR.PWR_STATUS`.

| Value | Mode | Static policy? | Dynamic policy? | Lockable? |
|---|---|---|---|---|
| `0x0` | `OFF` | yes | yes | **yes** |
| `0x2` | `MEM_RET` | yes | yes | **yes** |
| `0x5` | `FULL_RET` | yes | yes | no |
| `0x6` | `MEM_OFF` | yes | yes | no |
| `0x7` | `FUNC_RET` | yes | yes | no |
| `0x8` | `ON` | yes | yes | no |
| `0x9` | `WARM_RST` | yes | **no** — §3.4.3 | no |
| `0x1`, `0x3`, `0x4`, `0xA`–`0xF` | not built | no | no | — |

Writing an unsupported combination is **ignored** and raises
`PPU_AISR.UNSPT_POLICY_IRQ`. Note `WARM_RST` is legal as a *static* policy and
illegal as a *dynamic* one — the same value is accepted or rejected depending on
`PWR_DYN_EN` in the same write.

## 4. Register detail

> **The parameter names in the Notes columns are the specification's.**
> `LOCK_CFG`, `SW_DEV_DEL_CFG`, `PWR_MODE_ENTRY_DEL_CFG`, `OFF_MEM_RET_TRANS_CFG`,
> the per-mode `STA_*_SPT_CFG` and `DYN_*_SPT_CFG`, and the three
> `*_RAM_REG_CFG` all come from Chapter 7. Field names inside the register tables
> are the specification's too, and `make ppuspec` checked them against Tables 5-2
> to 5-29 until it was retired with `src/lint` on 2026-10-05 (`make ppuregdoc`
> still checks this document's behavioural claims in simulation). See
> [OPTIONS.md](OPTIONS.md) for which values have actually been built.

Grouped by what the registers are *for*, and the groups ordered by the lowest
address in each, so this chapter tracks the memory map as closely as grouping
allows. §2 remains the flat lookup table if you have an offset and want the
register.

| | From | Group | Registers |
|---|---|---|---|
| §4.1 | `0x000` | Power mode control and status | `PPU_PWPR` `0x000` · `PPU_PWSR` `0x008` · `PPU_UNLK` `0x01C` |
| §4.2 | `0x010` | Input status | `PPU_DISR` `0x010` · `PPU_MISR` `0x014` |
| §4.3 | `0x020` | Interface configuration | `PPU_PWCR` `0x020` · `PPU_PTCR` `0x024` |
| §4.4 | `0x030` | Interrupts | `PPU_IMR` `0x030` · `PPU_AIMR` `0x034` · `PPU_ISR` `0x038` · `PPU_AISR` `0x03C` · `PPU_IESR` `0x040` |
| §4.5 | `0x050` | Retention RAM configuration | `PPU_FUNRR` `0x050` · `PPU_FULRR` `0x054` · `PPU_MEMRR` `0x058` |
| §4.6 | `0x160` | Transition timing | `PPU_EDTR0` `0x160` · `PPU_EDTR1` `0x164` · `PPU_DCDR0` `0x170` · `PPU_DCDR1` `0x174` |
| §4.7 | `0xFB0` | Identification | `PPU_IDR0` `0xFB0` · `PPU_IDR1` `0xFB4` · `PPU_IIDR` `0xFC8` · `PPU_AIDR` `0xFCC` |

Arm laid the map out functionally, so the two orders very nearly agree. The one
inversion is `PPU_UNLK` at `0x01C`, which sits in §4.1 because it exists only to
release the lock that `PPU_PWPR.LOCK_EN` arms and `PPU_PWSR.LOCK_STATUS` reports
— splitting it from those two to gain strict address order would cost more than
it is worth.

### 4.1 Power mode control and status
The core loop: set a policy, read where the PPU actually is, and release the lock when one is held. These three are the registers a driver touches on every power transition; everything else configures or reports on what they set in motion.
#### `PPU_PWPR` — Power Policy (`0x000`, R/W)

| Bits | Field | Default | Values |
|---|---|---|---|
| `[12]` | `LOCK_EN` | `0` | `0` unlocked, `1` lock enabled. Reserved if `LOCK_SPT = 0` |
| `[8]` | `PWR_DYN_EN` | `DEF_PWR_DYN_EN` (`0`) | `0` static, `1` dynamic. Reserved if `DYN_SPT = 0` |
| `[3:0]` | `PWR_POLICY` | `DEF_PWR_POLICY`, **or `MEM_RET` if `PCSMMODESTAT` says so** | a mode from §3 |
| others | — | `0` | reserved, WI/RAZ |

The whole register is written at once, so policy, dynamic enable and lock enable
change together. That matters more than it first looks: `{PWR_DYN_EN=1,
PWR_POLICY=WARM_RST}` is rejected as a unit, and rejection means **the entire
write is discarded** — `LOCK_EN` and `PWR_DYN_EN` included, not just the offending
policy field.

So a driver cannot set `LOCK_EN` in the same write as a policy it is not sure of;
if the policy is unsupported it loses both. Measured: writing `0xFFFFFFFF` to
`PPU_PWPR` leaves it reading `0x00000008`, unchanged, because policy `0xF` is not
a supported encoding.

#### `PPU_PWSR` — Power Status (`0x008`, RO)

| Bits | Field | Default | Meaning |
|---|---|---|---|
| `[12]` | `LOCK_STATUS` | `0` | `1` = the PPU is locked in its current mode |
| `[8]` | `PWR_DYN_STATUS` | `DEF_PWR_DYN_EN` (`0`) | dynamic mode **in effect** — lags `PWR_DYN_EN` until any in-flight transition completes (§3.4.3) |
| `[3:0]` | `PWR_STATUS` | the mode the PPU comes up in | the mode the PPU is in now |

Not stored — these are wires onto the sequencer, so "default" here means what
they read immediately after reset, not a value that was loaded.

`PWR_STATUS` reads the *current* mode, which during a multi-hop route is an
intermediate mode, not the policy. Poll until it equals the policy **and** the
PPU is idle.

#### `PPU_UNLK` — Unlock (`0x01C`, WO)

Write `0x1` to bit 0 to unlock. **Reads always return `0x0`** — this is a
write-only strobe, not a state bit; read `PPU_PWSR.LOCK_STATUS` for the state.

Unlocking once does not disable the feature: the PPU locks again the next time it
enters a lockable mode. To stop it locking, clear `LOCK_EN` or `PWR_DYN_EN`.



### 4.2 Input status
Read-only views of the interface pins, for diagnosis rather than control. Neither has any storage: they show what the interface is presenting right now, including inputs that `PPU_PWCR` is currently gating out of transition decisions.
#### `PPU_DISR` — Device Interface Current Status (`0x010`, RO)

Spec Table 5-5.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:24]` | `OP_DEVACTIVE_STATUS` | **reserved** | no operating modes |
| `[23:11]` | reserved | `0` | |
| `[10:0]` | `PWR_DEVACTIVE_STATUS` | the pin | one bit per device Q-Channel `DEVQACTIVE`. **Only `[0]` exists here**; `[10:1]` reserved |

Shows the **raw** input, before the `PWR_DEVACTIVEEN` gate — so this reads HIGH
even when the enable is clearing it for transition purposes.

#### `PPU_MISR` — Miscellaneous Input Current Status (`0x014`, RO)

Spec Table 5-6.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:24]` | reserved | `0` | |
| `[23:16]` | `DEVDENY_STATUS` | the pin | one bit per `DEVQDENY`. **Only `[16]` exists here** |
| `[15:8]` | `DEVACCEPT_STATUS` | the pin | one bit per `DEVQACCEPTn`. **Only `[8]` exists here** |
| `[7:1]` | reserved | `0` | |
| `[0]` | `PCSMPACCEPT_STATUS` | the pin | the PCSM's `PCSMPACCEPT` |

Both registers are direct views of input pins with no storage, so "default" means
whatever the interface is presenting — there is no value to reset.

`PPU_DISR` shows the **raw** input, before `PWR_DEVACTIVEEN` gating.



### 4.3 Interface configuration
Which handshakes actually run, and which inputs are allowed to influence a transition. Both carry ordering requirements from §4.1.3 -- change them only with the PPU static and settled.
#### `PPU_PWCR` — Power Configuration (`0x020`, R/W, reset `0x0000_0101`)

| Bits | Field | Default | Values |
|---|---|---|---|
| `[31:24]` | `OP_DEVACTIVEEN` | **reserved** | no operating modes |
| `[23:19]` | reserved | `0` | |
| `[18:8]` | `PWR_DEVACTIVEEN` | `1` | one bit per power mode `DEVACTIVE` input. **Only `[8]` exists here**; `[18:9]` reserved. `1` = the input affects transitions, `0` = treated as LOW |
| `[7:0]` | `DEVREQEN` | `1` | one bit per device interface channel. **Only `[0]` exists here**; `[7:1]` reserved. `1` = the handshake runs, `0` = `DEVQREQn` held HIGH and responses ignored |

Both default HIGH, which §4.1.3 requires: *"All PPU device interface channels are
enabled at reset"* and *"All DEVACTIVE inputs are enabled at reset."*

> **Ordering requirement (§4.1.3).** Before changing `DEVREQEN`, put the PPU in
> static mode and let the requested mode be reached, so no transition can be in
> flight — otherwise behaviour is UNPREDICTABLE. And **the PPU must be in `ON`
> before re-enabling a previously disabled channel.**

Clearing `PWR_DEVACTIVEEN` does **not** suppress the `DEVQACTIVE` edge interrupt;
§4.1.3 requires the enables to have no effect on interrupt generation.

#### `PPU_PTCR` — Transition Configuration (`0x024`, R/W)

| Bits | Field | Default | Values |
|---|---|---|---|
| `[0]` | `WARM_RST_DEVREQEN` | `WARM_RST_DEVREQEN_CFG` (`1`) | `1` = handshake with the device on `ON ↔ WARM_RST`. `0` = warm-reset it without asking |

Reset value comes from `WARM_RST_DEVREQEN_CFG`. Use `0` for components with no
`WARM_RST` support of their own.



### 4.4 Interrupts
Five registers that work as a set: two masks, two status registers, and the edge selector. `PPU_AIMR`/`PPU_AISR` are not a second-class copy -- they carry the dynamic-transition and unsupported-policy events, and `PPU_ISR.OTHER_IRQ` is the only link between the two halves.
#### `PPU_IMR` — Interrupt Mask (`0x030`, R/W)

Spec Table 5-13. A `1` **masks** the event. Note the register is only `[5:0]`
wide: there is no mask bit for the input-edge event, which is masked through
`PPU_IESR` instead (§5.2.11).

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:6]` | reserved | `0` | |
| `[5]` | `LOCKED_IRQ_MASK` | `1` **masked** | reserved if `LOCK_SPT = 0` |
| `[4]` | `EMU_DENY_IRQ_MASK` | **reserved** | spec default `0x1`; reserved *"for a Q-Channel PPU"* regardless of emulation |
| `[3]` | `EMU_ACCEPT_IRQ_MASK` | **reserved** | spec default `0x1`; no emulation modes |
| `[2]` | `STA_DENY_IRQ_MASK` | `0` unmasked | static transition denial |
| `[1]` | `STA_ACCEPT_IRQ_MASK` | `1` **masked** | static transition acceptance |
| `[0]` | `STA_POLICY_TRN_IRQ_MASK` | `0` unmasked | full policy transition completion |

Register default `0x22`, or `0x02` when `LOCK_SPT = 0`.

#### `PPU_AIMR` — Additional Interrupt Mask (`0x034`, R/W)

Spec Table 5-14.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:5]` | reserved | `0` | |
| `[4]` | `STA_POLICY_OP_IRQ_MASK` | **reserved** | spec default `0x1` — see below |
| `[3]` | `STA_POLICY_PWR_IRQ_MASK` | **reserved** | spec default `0x1` — see below |
| `[2]` | `DYN_DENY_IRQ_MASK` | `1` **masked** | dynamic transition denial |
| `[1]` | `DYN_ACCEPT_IRQ_MASK` | `1` **masked** | dynamic transition acceptance |
| `[0]` | `UNSPT_POLICY_IRQ_MASK` | `0` unmasked | unsupported policy |

Register default `0x06` in every build.

#### `PPU_ISR` — Interrupt Status (`0x038`, R/W1C)

Spec Table 5-15. Every implemented bit resets to `0`.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:24]` | `OP_ACTIVE_EDGE_IRQ` | **reserved** | no operating modes |
| `[18:8]` | `PWR_ACTIVE_EDGE_IRQ` | `0` | one bit per device Q-Channel. **Only `[8]` exists here**; `[18:9]` reserved. Selected by `PPU_IESR`, not by `PPU_IMR` |
| `[7]` | `OTHER_IRQ` | `0` | **RO, derived** — set while any `PPU_AISR` bit is set. Writing `1` does nothing |
| `[6]` | reserved | `0` | |
| `[5]` | `LOCKED_IRQ` | `0` | the PPU became locked. Reserved if `LOCK_SPT = 0` |
| `[4]` | `EMU_DENY_IRQ` | **reserved** | no emulation modes |
| `[3]` | `EMU_ACCEPT_IRQ` | **reserved** | no emulation modes |
| `[2]` | `STA_DENY_IRQ` | `0` | a static transition was denied |
| `[1]` | `STA_ACCEPT_IRQ` | `0` | a static transition completed |
| `[0]` | `STA_POLICY_TRN_IRQ` | `0` | the programmed policy has been reached |

Register default `0x0`. Writable bits are `[8]`, `[5]`, `[2:0]` — write `1` to
clear.

#### `PPU_AISR` — Additional Interrupt Status (`0x03C`, R/W1C)

Spec Table 5-16. Every implemented bit resets to `0`.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:5]` | reserved | `0` | |
| `[4]` | `STA_POLICY_OP_IRQ` | **reserved** | operating policy transition completion |
| `[3]` | `STA_POLICY_PWR_IRQ` | **reserved** | power policy transition completion |
| `[2]` | `DYN_DENY_IRQ` | `0` | a dynamic transition was denied |
| `[1]` | `DYN_ACCEPT_IRQ` | `0` | a dynamic transition completed |
| `[0]` | `UNSPT_POLICY_IRQ` | `0` | an unsupported policy was written |

Register default `0x0`. Writable bits are `[2:0]` — write `1` to clear.

#### Why `PPU_AIMR[4:3]` and `PPU_AISR[4:3]` are reserved

Worth its own note, because the specification gives both mask bits a default of
`0x1`, so a reader will expect `PPU_AIMR` to reset to `0x1E` and finds `0x06`.

Each bit's own description carries the condition — *"If the power policy
transition completion event is not supported this bit is reserved"* — and §4.1.2
settles when that is:

> *"The power policy and operating policy transition completion events are
> optional. **They are not supported when operating modes are not supported.**"*

This PPU has no operating modes, so **neither** event exists, not just the
operating-mode one. With no operating modes the power-policy event would carry
exactly the information `STA_POLICY_TRN_IRQ` already carries, which is why the
specification drops both together rather than keeping the power half.

Implementing bit 3 anyway was defect **F2**: the first version had a working
`STA_POLICY_PWR_IRQ` and advertised it in `PPU_IDR1[8]`. Both were removed, and
P20 checks it — writing all ones to `PPU_AIMR` yields `0x07`.

Three behaviours worth knowing:

- **Masking suppresses the status bit itself**, not just the output. A masked
  event leaves no trace, so you cannot mask an interrupt and poll for it later.
- **Status registers are write-1-to-clear**, and **set beats clear**: if an event
  re-occurs on the same cycle you clear it, the bit stays set (§4.1.2).
- **`PPU_ISR.OTHER_IRQ` cannot be cleared directly.** It is derived from `PPU_AISR` —
  clear the `PPU_AISR` bit and `OTHER` follows.

`IRQ` is level-sensitive and HIGH while any `PPU_ISR` or `PPU_AISR` bit is set.

#### `PPU_IESR` — Input Edge Sensitivity (`0x040`, R/W)

| Bits | Field | Default | Values |
|---|---|---|---|
| `[1:0]` | `DEVACTIVE00_EDGE` | `00` | `00` none · `01` rising · `10` falling · `11` both |
| `[15:2]` | reserved | `0` | only one channel exists |

Selects which `DEVQACTIVE` edge sets `PPU_ISR.PWR_ACTIVE_EDGE`. Reset is `00`, so
no edge interrupt until programmed.



### 4.5 Retention RAM configuration
What the PCSM is told to do with RAM in each retention mode. One register per mode, each driving `PCSMPSTATE[15:8]` while that mode is current.
#### `PPU_FUNRR` — Functional Retention RAM Config (`0x050`, R/W)

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:8]` | reserved | `0` | |
| `[7:0]` | `FUNC_RET_RAM_CFG` | `0x00` | drives `PCSMPSTATE[15:8]` while in `FUNC_RET` |

#### `PPU_FULRR` — Full Retention RAM Config (`0x054`, R/W)

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:8]` | reserved | `0` | |
| `[7:0]` | `FULL_RET_RAM_CFG` | `0x00` | drives `PCSMPSTATE[15:8]` while in `FULL_RET` |

#### `PPU_MEMRR` — Memory Retention RAM Config (`0x058`, R/W)

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:8]` | reserved | `0` | |
| `[7:0]` | `MEM_RET_RAM_CFG` | `0x00` | drives `PCSMPSTATE[15:8]` while in `MEM_RET` |

All three behave the same way. The byte is passed through to `PCSMPSTATE[15:8]`
while the PPU is in that register's mode, and its meaning is IMPLEMENTATION
DEFINED — the PPU attaches none. In every other mode `PCSMPSTATE[15:8]` reads
zero. Program the register **before** entering the mode; a change made while
already in it is not re-sent. All three are reserved when `RET_RAM_REGS = 0`.

#### What `PCSMPSTATE` is

The three registers above exist only to fill in part of one output signal, so it
is worth knowing what that signal is.

`PCSMPSTATE` is the `PSTATE` of the **PCSM P-Channel** — the interface the PPU
uses to tell the Power Control State Machine what to do with the domain's
supplies and RAM. It is not a register and software cannot write it directly;
the PPU composes it from the mode being entered plus whichever retention register
belongs to that mode. Table 4-12 gives three fields:

| Bits | Source | In this PPU |
|---|---|---|
| `[15:8]` | RAM retain value for the mode being requested | `PPU_FUNRR`, `PPU_FULRR` or `PPU_MEMRR`; `0x00` for every other mode |
| `[7:4]` | the operating mode being requested | permanently `0` — *"If the PPU is configured as a Q-Channel PPU, or operating modes are not supported, this field is reserved"* |
| `[3:0]` | the power mode being requested (Table 3-2) | the mode, with the footnote-a mapping applied |

So the whole 16-bit value per mode is:

| Mode | `[15:8]` | `[3:0]` | `PCSMPSTATE` |
|---|---|---|---|
| `ON` | `0x00` | `0x8` | `0x0008` |
| `WARM_RST` | `0x00` | `0x8` | `0x0008` |
| `FUNC_RET` | `PPU_FUNRR` | `0x7` | `FUNRR`·`0x07` |
| `MEM_OFF` | `0x00` | `0x6` | `0x0006` |
| `FULL_RET` | `PPU_FULRR` | `0x5` | `FULRR`·`0x05` |
| `MEM_RET` | `PPU_MEMRR` | `0x2` | `MEMRR`·`0x02` |
| `OFF` | `0x00` | `0x0` | `0x0000` |

#### What to write in the RAM retain byte

Nothing in the architecture tells you. §5.2.16 is explicit — *"The enumeration of
this register is IMPLEMENTATION DEFINED"* — and the only thing it says about
purpose is that the bits *"are used by the PCSM to configure the RAMs that are
retained."*

That is not an omission in this document; it is the architecture deliberately
leaving the field open. The meaning of the eight bits is a contract between the
**PCSM implementation** and software, and a driver has to get it from the
integration rather than from the specification. The common convention is one bit
per retainable RAM bank with `1` meaning retain, but that is convention, not
something you can rely on without checking.

#### What the RTL actually does with it

The byte is opaque the whole way. Nothing decodes it:

| Stage | What happens |
|---|---|
| `ppu_regs` | held in `funrr_q` / `fulrr_q` / `memrr_q`, 8 bits each, reset `0x00` |
| `ppu_seq` | `hop_ram_cfg` picks the register belonging to the **mode being entered**; `0x00` for any other mode |
| `ppu_seq` | concatenated as `{hop_ram_cfg, 4'h0, mode}` into the PCSM request |
| `ppu_pcsm` | captured on an accepted handshake, re-exposed as `ram_cfg = cur_state[15:8]` |
| `ppu_pd_top` | **nothing consumes it** |

That last row is the honest limitation. `ram_cfg` — and `ram_on` with it — is a
dangling output in `ppu_pd_top`, because in silicon it would drive RAM macros and
there is no RAM in this domain: `dummy_workload` is flops. Adding a memory macro
means wiring `ram_cfg` to its per-bank enables and gating retention on
`u_pcsm/ram_ret`, which `upf/ppu_pd_top.upf` §9 sets out.

So the **routing** is verified — P34a writes three distinct values and confirms
each reaches `PCSMPSTATE[15:8]` in its own mode, and U11 confirms the field is
zero everywhere else — but the **effect** is not, because there is nothing for it
to have an effect on. A bug in how a RAM macro interprets the byte could not be
caught here. The same is true of `MEM_OFF`, which exists solely to express "logic
on, RAM off" and has no observable consequence below the PCSM.

#### Writes while already in the mode are not re-sent

The value is sampled from the mode being **entered**, so changing a retention
register while the PPU is already sitting in that mode does nothing until the
mode is left and re-entered. Measured, entering `FUNC_RET` with
`PPU_FUNRR = 0x71`:

```
entered FUNC_RET   PCSMPSTATE=0x7107   ram_cfg=0x71
FUNRR <- 0xAA      PCSMPSTATE=0x7107   ram_cfg=0x71   PCSMPREQ rises = 0
left and re-entered PCSMPSTATE=0xAA07  ram_cfg=0xAA
```

The PPU only issues a PCSM request as part of a transition, and no transition is
needed when the mode is not changing — so the new byte simply waits.

#### Can a same-mode write force the update? No

The obvious workaround is to re-write the policy with the mode it is already in,
hoping the PPU re-issues the PCSM request with the new byte. It does not. Measured,
sitting in `FUNC_RET` with `PPU_FUNRR` changed from `0x71` to `0xAA` and then
`PPU_PWPR` written with `FUNC_RET` again:

```
sequencer left idle : 0 times
PCSMPREQ rises      : 0
DEVQREQn falls      : 0
PCSMPSTATE          : 0x7107   (unchanged)
PPU_ISR             : 0x00000001
```

**Nothing moves — but an interrupt fires.** That combination is the trap. `PPU_ISR
bit 0` is `STA_POLICY_TRN_IRQ`, and it is correct per §4.1.2, whose first
completion condition is *"Following the write of a supported policy to PPU_PWPR
when the PPU is not in transition, and both PPU_PWPR.PWR_DYN_EN and the
PPU_PWPR.OP_DYN_EN are set to `0b0`."* The policy has been reached, so the event
is due. A driver that treats "policy transition complete" as "my new retention
configuration is live" will be wrong.

Why the PPU behaves this way is worth being precise about, because it is a
choice at the PPU level rather than a limitation of the PCSM. `pcsm_needed`
compares the full 16-bit vector and *would* be true here — `0xAA07` differs from
`0x7107`. But nothing consults it, because admission to any transition is gated
on `hop_needed`, which compares **modes**, and the mode has not changed.

The architecture offers no mechanism either. Table 4-12 ties the byte to *"the
mode being entered"*, §3.3 defines transitions only between different modes, and
the specification tells the PCSM that *"Whenever the PCSM sees a transition
request to its current mode it must accept the request and take no further
action."*

**So the only way to change a live retention configuration is to leave the mode
and come back** — for `FUNC_RET`, `FULL_RET` and `MEM_RET` that means routing
through `ON`, since none of them can reach another retention mode directly. In
practice: program the register before you enter, which is what it is for.

That opacity is why **U11** is worded the way it is. The only property the PPU can
meaningfully police about a field whose values it does not understand is *where*
it may be non-zero: in `FUNC_RET`, `FULL_RET` or `MEM_RET` and nowhere else. What
the bits mean once they are there is not the PPU's business.

**`ON` and `WARM_RST` produce the same value**, and that is the point of Table
3-2's footnote a — *"In these power modes the PPU instructs the PCSM to have the
same conditions as ON."* A warm reset holds the device in reset without touching
its power, so the PCSM has nothing to do. The PPU only runs a PCSM handshake when
the requested value actually differs from the current one, so the PCSM interface
stays completely idle across `ON ↔ WARM_RST` — measured, `PCSMPREQ` rises
**zero** times across `ON → WARM_RST → ON`, while `DEVWARMRESETn` asserts and
releases. `make ppudemo` step 6 walks exactly that.

Two monitor rules police the fields that software cannot reach: **U10** fails if
`[7:4]` is ever non-zero, and **U11** fails if `[15:8]` is non-zero in a mode
that has no retention register. The reset value is a separate rule again — §4.1.6
requires it to match the mode the PPU reports at reset, which is where defect
**F8** was.



### 4.6 Transition timing
Two different delays, easy to confuse. The entry delays decide **when a transition starts** once its conditions are met; the device control delays decide **how far apart the control signals move** once it is under way. They also default differently -- entry delays are off out of reset, device control delays are not.
#### `PPU_EDTR0` — Power Mode Entry Delay 0 (`0x160`, R/W)

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:24]` | `FULL_RET_DEL` | `0x00` | delay before entering `FULL_RET` |
| `[23:16]` | `LOGIC_RET_DEL` | **reserved** | `LOGIC_RET` is P-Channel only |
| `[15:8]` | `MEM_RET_DEL` | `0x00` | delay before entering `MEM_RET` |
| `[7:0]` | `OFF_DEL` | `0x00` | delay before entering `OFF` |

#### `PPU_EDTR1` — Power Mode Entry Delay 1 (`0x164`, R/W)

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:16]` | reserved | `0` | |
| `[15:8]` | `FUNC_RET_DEL` | `0x00` | delay before entering `FUNC_RET` |
| `[7:0]` | `MEM_OFF_DEL` | `0x00` | delay before entering `MEM_OFF` |

Every field defaults to `0`, so **entry delays are off until programmed** — the
timer exists but does nothing out of reset.

PPU clock cycles to wait *after the conditions are met* before starting a
transition **to a lower-priority mode**. `0` disables the timer. If conditions
stop being met while the timer runs, the entry is abandoned. There is no field for
`ON` or `WARM_RST` — they are higher priority and take no entry delay.

#### `PPU_DCDR0` — Device Control Delay Config 0 (`0x170`, R/W*)

| Bits | Field | Default | Spacing controlled |
|---|---|---|---|
| `[31:24]` | reserved | `0` | |
| `[23:16]` | `RST_HWSTAT_DLY` | `RST_HWSTAT_DLY_CFG` (`2`) | reset release → `PPUHWSTAT` update |
| `[15:8]` | `ISO_CLKEN_DLY` | `ISO_CLKEN_DLY_CFG` (`2`) | isolation release → clock enable |
| `[7:0]` | `CLKEN_RST_DLY` | `CLKEN_RST_DLY_CFG` (`2`) | clock enable → reset release |

Register default `0x0002_0202`.

#### `PPU_DCDR1` — Device Control Delay Config 1 (`0x174`, R/W*)

| Bits | Field | Default | Spacing controlled |
|---|---|---|---|
| `[31:16]` | reserved | `0` | |
| `[15:8]` | `CLKEN_ISO_DLY` | `CLKEN_ISO_DLY_CFG` (`2`) | clock disable → isolation assert |
| `[7:0]` | `ISO_RST_DLY` | `ISO_RST_DLY_CFG` (`2`) | isolation assert → reset assert |

Register default `0x0000_0202`.

Unlike the entry delays these default **non-zero**, so device-control spacing is
active out of reset. The bracketed number is this build's parameter value; a
different build has different defaults, which is why a driver should not assume
them.

**Minimum spacing is `value + 1` PPU cycles** (Table 4-5). Range `0`–`255`. Reset
values come from build parameters.

Two things to hold in mind: `RST_HWSTAT_DLY` also waits for the device handshake
to complete, so the observed delay is the *longer* of the two; and the values are
in **PPU** clocks while the thing being spaced lives in the **device's** domain,
so allow for the clock ratio and for resynchronization (§4.1.5).

If `SW_DEV_DEL_SPT = 0` these registers are **read-only** — they still read the
configured values, and those values still apply. They do not become reserved.



### 4.7 Identification
Read these first. They describe the build, and in a reduced configuration the optional registers above are reserved and read zero -- a driver that assumes a feature exists will silently do nothing.
#### `PPU_IDR0` — PPU Identification 0 (`0xFB0`, RO)

Spec Table 5-26. Which power modes this build supports, statically and
dynamically. Every bit is fixed at elaboration.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:30]` | reserved | `0` | |
| `[29]` | `DYN_WRM_RST_SPT` | `0` | dynamic `WARM_RST` — §3.4.3 excludes it on a Q-Channel PPU |
| `[28]` | `DYN_ON_SPT` | `1` | |
| `[27]` | `DYN_FUNC_RET_SPT` | `1` | |
| `[26]` | `DYN_FULL_RET_SPT` | `1` | |
| `[25]` | `DYN_MEM_OFF_SPT` | `1` | |
| `[24]` | `DYN_LGC_RET_SPT` | `0` | `LOGIC_RET` is P-Channel only |
| `[23]` | `DYN_MEM_RET_EMU_SPT` | `0` | no emulation modes |
| `[22]` | `DYN_MEM_RET_SPT` | `1` | |
| `[21]` | `DYN_OFF_EMU_SPT` | `0` | no emulation modes |
| `[20]` | `DYN_OFF_SPT` | `1` | |
| `[18]` | `STA_DBG_RECOV_SPT` | `0` | `DBG_RECOV` not built |
| `[17]` | `STA_WRM_RST_SPT` | `1` | mandatory |
| `[16]` | `STA_ON_SPT` | `1` | mandatory |
| `[15]` | `STA_FUNC_RET_SPT` | `1` | |
| `[14]` | `STA_FULL_RET_SPT` | `1` | |
| `[13]` | `STA_MEM_OFF_SPT` | `1` | |
| `[12]` | `STA_LGC_RET_SPT` | `0` | P-Channel only |
| `[11]` | `STA_MEM_RET_EMU_SPT` | `0` | no emulation modes |
| `[10]` | `STA_MEM_RET_SPT` | `1` | |
| `[9]` | `STA_OFF_EMU_SPT` | `0` | no emulation modes |
| `[8]` | `STA_OFF_SPT` | `1` | mandatory |
| `[7:4]` | `NUM_OPMODE` | `0x0` | no operating modes |
| `[3:0]` | `DEVCHAN` | `0x1` | one device Q-Channel |

Register default **`0x1E53_E501`**.

Each bit comes from its own `DYN_*_SPT_CFG` parameter, so they need not read as a
set. A build supporting dynamic `FUNC_RET` but only static `OFF` — the
specification's own example in §3.4.3 — reads `[27]` as 1 and `[20]` as 0, and
refuses a dynamic `OFF` policy with `UNSPT_POLICY_IRQ` while still accepting a
static one. Built and checked by `ppucfg` M9.

#### `PPU_IDR1` — PPU Identification 1 (`0xFB4`, RO)

Spec Table 5-27. Which optional *features* this build has, as opposed to which
modes. **Read this before using any optional register** — in a reduced build the
corresponding registers are reserved and read zero, and a driver that assumes one
exists will silently do nothing.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:13]` | reserved | `0` | |
| `[12]` | `OFF_MEM_RET_TRANS` | `1` | the direct `OFF → MEM_RET` hop, and `PCSMMODESTAT` |
| `[10]` | `OP_ACTIVE` | `0` | no operating modes |
| `[9]` | `STA_POLICY_OP_IRQ_SPT` | `0` | no operating modes |
| `[8]` | `STA_POLICY_PWR_IRQ_SPT` | `0` | §4.1.2 — unsupported without operating modes (defect **F2**) |
| `[6]` | `FUNC_RET_RAM_REG` | `1` | `PPU_FUNRR` present — `FUNC_RET_RAM_REG_CFG` |
| `[5]` | `FULL_RET_RAM_REG` | `1` | `PPU_FULRR` present — `FULL_RET_RAM_REG_CFG` |
| `[4]` | `MEM_RET_RAM_REG` | `1` | `PPU_MEMRR` present — `MEM_RET_RAM_REG_CFG` |
| `[2]` | `LOCK_SPT` | `1` | `PPU_UNLK`, `LOCK_EN`, `LOCK_STATUS` |
| `[1]` | `SW_DEV_DEL_SPT` | `1` | `PPU_DCDR0/1` writable rather than read-only |
| `[0]` | `PWR_MODE_ENTRY_DEL_SPT` | `1` | `PPU_EDTR0/1` present |

Register default **`0x0000_1077`**.

#### `PPU_IIDR` — Implementation Identification (`0xFC8`, RO)

Spec Table 5-28. Who built this PPU. Every field is IMPLEMENTATION DEFINED and
set by parameter.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:20]` | `PRODUCT_ID` | `0x50C` | `IIDR_PRODUCT_ID` |
| `[19:16]` | `VARIANT` | `0x0` | `IIDR_VARIANT` |
| `[15:12]` | `REVISION` | `0x1` | `IIDR_REVISION` |
| `[11:0]` | `IMPLEMENTER` | `0x000` | `IIDR_IMPLEMENTER` — **deliberately not Arm's `0x43B`** |

Register default **`0x50C0_1000`**.

The implementer code is the one field worth a second look. `0x43B` is Arm's JEP106
code, and claiming it in a PPU Arm did not produce would misidentify the part to
any software that reads it. `0x000` is used instead, and a real integration should
set its own.

#### `PPU_AIDR` — Architecture Identification (`0xFCC`, RO)

Spec Table 5-29. Which version of the PPU architecture this implements.

| Bits | Field | Default | Notes |
|---|---|---|---|
| `[31:8]` | reserved | `0` | |
| `[7:4]` | `ARCH_REV_MAJOR` | `0x1` | |
| `[3:0]` | `ARCH_REV_MINOR` | `0x1` | |

Register default **`0x0000_0011`** — architecture v1.1, which is ARM DEN 0051E.

Unlike the other three this is fixed, not parameterised: it states which document
the PPU conforms to, and changing it would be a claim about conformance rather
than about the build.

## 5. How to use it

### Change power mode (static)

```
1. write  PPU_PWPR = {PWR_DYN_EN=0, PWR_POLICY=<mode>}
2. poll   PPU_PWSR until PWR_STATUS == <mode>
3. read   PPU_ISR -- STA_POLICY_TRN[0] confirms the policy was reached
```

The PPU may pass through `ON` on the way; `PWR_STATUS` shows that intermediate
mode, so wait for the final value rather than the first change.

**A transition to a lower-priority mode does not start while `DEVQACTIVE` is
HIGH** — including before any intermediate hop. If the mode is not moving, read
`PPU_DISR[0]`. That is the design working, not a hang.

### Enable dynamic transitions

```
1. write  PPU_PWPR = {PWR_DYN_EN=1, PWR_POLICY=<minimum mode>}
2. poll   PPU_PWSR.PWR_DYN_STATUS until it reads 1
```

The policy is now a **floor**: the PPU sits in it while `DEVQACTIVE` is LOW and
rises to `ON` when it goes HIGH. Step 2 is not optional — the setting does not
take effect until any in-flight transition finishes.

### Lock a domain off

```
1. write  PPU_PWPR = {LOCK_EN=1, PWR_DYN_EN=1, PWR_POLICY=OFF}
2. poll   PPU_PWSR.LOCK_STATUS -- 1 once OFF is reached
   ...the PPU now ignores DEVQACTIVE and stays put...
3. write  PPU_UNLK = 1        to release it once
```

Lock needs **both** enables and only engages in `OFF` or `MEM_RET`. In any other
mode `LOCK_STATUS` stays `0` — that is not a failure.

### Configure device control delays

```
1. read   PPU_IDR1[1] -- if 0, the registers are read-only; the built-in
                         values still apply, so there is nothing to do
2. write  PPU_DCDR0 = {RST_HWSTAT_DLY, ISO_CLKEN_DLY, CLKEN_RST_DLY}
3. write  PPU_DCDR1 = {CLKEN_ISO_DLY, ISO_RST_DLY}
```

Do this while the PPU is idle. Each field gives `value + 1` cycles minimum.

### Service an interrupt

```
1. read   PPU_ISR and PPU_AISR
2. if ISR[7] OTHER_IRQ is set, the cause is in PPU_AISR
3. write  1 to the bits you handled, in the register that owns them
4. re-read -- a bit still set means the event re-occurred, not that the
             clear failed
```

### Disable the device channel

```
1. put the PPU in static mode and let the target mode be reached
2. write  PPU_PWCR.DEVREQEN = 0
   ...transitions now sequence without the handshake; DEVQREQn stays HIGH...
3. to re-enable: bring the PPU to ON first, then set DEVREQEN = 1
```

Both ordering rules are §4.1.3 requirements; ignoring either is UNPREDICTABLE.
