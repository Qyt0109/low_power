`timescale 1ns/1ps
// AXI4-Lite to the PPU's software interface, with the clock-gating interlock.
//
// References:
//   AMBA AXI and ACE Protocol Specification (ARM IHI 0022), Section A3.3.1
//     "Dependencies between channel handshake signals", and Chapter B for
//     AXI4-Lite
//   Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN 0051E)
//     Section 6.2  "The type of bus interface used is IMPLEMENTATION DEFINED"
//     Section 5.2  reserved and unmapped registers are write-ignored and
//                  read-as-zero, which is why this bridge has almost nothing to
//                  report an error about
//   Arm CoreLink PCK-600 TRM (101150) Table A-28  pwakeup_i
//
// Reference implementation: pulp-platform/axi_lite_to_reg (see
// vendor/pulp/README.md). The shape of the AW/W acceptance and the
// response-channel handling follow it; the three things that differ are
// explained below, and each one is a consequence of what the PPU's interface
// is rather than a preference.
//
// -----------------------------------------------------------------------------
// THREE DIFFERENCES FROM axi_lite_to_reg
//
// 1. NO ARBITER. PULP's converter arbitrates reads against writes, because a
//    reg_bus has one address, one valid and one ready. The PPU does not: it has
//    reg_waddr/reg_wen and reg_raddr/reg_ren as independent buses, and
//    ppu_top's port comment says why -- "so an AXI4-Lite bridge can have one of
//    each outstanding without arbitrating between them". So there are two
//    independent state machines here and a write and a read can be in flight at
//    the same time. Arbitrating would throw away a property the register file
//    was deliberately built to have.
//
// 2. NO FIFOs, DEPTH ONE. PULP parameterises BUFFER_DEPTH for slaves that take
//    many cycles to answer. The PPU register file accepts a write on the cycle
//    reg_wen is high and answers a read one cycle after reg_ren, unconditionally
//    -- there is no ready and no backpressure to buffer against. A FIFO would
//    add area and latency and could never hold more than one entry.
//
// 3. NO ERROR PATH FROM THE REGISTER FILE. A reg_bus has reg_rsp_i.error and
//    PULP maps it to RESP_SLVERR. The PPU has no such output, and that is
//    correct rather than missing: Section 5.2 makes every reserved field,
//    reserved register and unmapped address write-ignored and read-as-zero, so
//    there is no access this bridge can be given that the register file
//    considers an error. The one SLVERR it can return is its own, and it is
//    about the clock -- see the timeout below.
//
// -----------------------------------------------------------------------------
// THE CLOCK INTERLOCK, WHICH IS THE REASON THIS IS NOT JUST axi_lite_to_reg
//
// The PPU's clock can be stopped, by a clock controller, over the PPUCLK*
// Q-Channel (PCK-600 Table A-29; see qchannel_device_comb.sv). While it is stopped:
//
//   * a write pulsed onto reg_wen reaches no clock edge and is silently lost
//   * a read is worse than lost -- ppu_regs latches rdata with
//     "if (ren) rdata <= rdata_next", so it returns whatever the LAST read
//     produced, which looks like a successful access and is not
//
// So this bridge owes the PPU two things, and they are separate:
//
//   pwakeup       the REQUEST. Asserted the moment a transaction is captured
//                 and held until its response has been accepted. PCK-600 Table
//                 A-28: "The PPU uses this wakeup signal as an input for the
//                 generation of the ppuclk_qactive_o signal. This signal must
//                 be driven from a register" -- so it is a flip-flop output
//                 here, not a decode of the AXI valid signals.
//
//   ppu_clk_ok    the EVIDENCE. pwakeup is a level with no acknowledgement; it
//                 cannot tell anyone the clock arrived. What can is the
//                 Q-Channel reaching Q_RUN, and the caller decodes that and
//                 passes it in. The W_WAIT and R_WAIT states below exist for
//                 exactly this and nothing else.
//
// Tie ppu_clk_ok HIGH in an integration whose PPU clock is never gated. The
// wait states then fall through in one cycle and cost one cycle of latency.
//
// -----------------------------------------------------------------------------
// WHY THIS BLOCK IS ON THE FREE-RUNNING CLOCK
//
// aclk must NOT be the gated clock, and the reason is a data-loss hazard rather
// than a preference. AXI READY is sampled by the master on the master's clock,
// which is not gated. If this block ran on the gated clock and were frozen with
// AWREADY HIGH, the master would see AWVALID and AWREADY both HIGH at its own
// clock edge, consider the transfer complete, and move on -- while this block,
// unclocked, captured nothing.
//
// Putting the bridge on the free-running clock removes the hazard entirely
// rather than working around it, and it is also what PCK-600 does: Table A-28
// gives the PPU's whole APB group a Clock column of "clk" and makes pwakeup_i
// an INPUT, which means the wakeup logic lives outside the PPU, in the bus
// infrastructure, on a clock that is still running.
//
// -----------------------------------------------------------------------------
// NO PROT FILTERING, AND WHAT THAT DELEGATES
//
// AWPROT and ARPROT are accepted and ignored. Any master that can address this
// block can therefore reprogram the power policy of the domain behind it, and
// a write of PPU_PWPR = OFF is a denial of service on everything in PD_DEV.
//
// That is consistent with Arm rather than a departure from it: DEN 0051E
// Section 6.2 leaves the bus interface entirely IMPLEMENTATION DEFINED, and
// PCK-600's own PPU defers its programming interface to AMBA 3 APB, which has
// no protection signal at all. Neither document gives a PPU any privilege or
// security model.
//
// So it is stated here rather than filtered here: access control to a power
// controller is an INTEGRATION responsibility, belonging to the interconnect
// decode or a firewall in front of this bridge. An integration that needs it
// and assumes this block provides it will not find out from the RTL, which is
// the only reason this paragraph exists.
//
// -----------------------------------------------------------------------------
// aclk and the PPU's clk are NOT asynchronous and must not be. They are the same
// clock: clk is a gated leaf of the tree aclk is an ungated leaf of. An
// integration that genuinely needs an asynchronous AXI clock needs a CDC bridge
// in front of this one -- that is a different block, and nothing here would make
// it safe.

module ppu_axi_lite_adapter #(
  // The PPU's register space. DEN 0051E puts the whole map inside 12 bits
  // (PPU_AIDR is at 0xFCC), and ppu_regs takes a 12-bit address.
  parameter int unsigned REG_ADDR_W = 12,

  // The AXI address width. Bits above REG_ADDR_W are IGNORED, not decoded and
  // not errored: an AXI4-Lite slave sees only the offsets its interconnect
  // routed to it, and deciding that 0x1_0000 is out of range is the
  // interconnect's job, not this block's.
  parameter int unsigned AXI_ADDR_W = 32,

  // aclk cycles to wait for ppu_clk_ok before giving up and answering SLVERR.
  // 0 means wait forever.
  //
  // WHAT LEADS TO THE CASE
  //
  // ppu_clk_ctrl's up_hold. Once a hierarchical clock or power controller has
  // asked for quiescence and the CLK-CTRL has ACCEPTED, base_req is pinned:
  //
  //     assign base_req = up_hold ? 1'b1 : ((up_req || local_req) && !abort);
  //
  // so clk_running stays LOW no matter what QACTIVE does. That is deliberate
  // and correct -- the upstream controller may already have acted on the
  // acceptance, and in the pwr_ case that means the supply is on its way out.
  // Un-gating unilaterally after saying "quiescent" would be a protocol
  // violation on a rail that is disappearing.
  //
  // The escape is hc_qactive_o / pwr_qactive_o, which pwakeup does raise. But
  // that is a REQUEST to the controller above, and how long it takes to act is
  // not a hardware property: it may be another controller, or it may be SCP
  // firmware. There is no cycle count that bounds it.
  //
  // WHY NOT JUST WAIT
  //
  // AXI4-Lite has no cancellation. A master that has asserted AWVALID must hold
  // it until AWREADY, so a bridge that never answers does not stall one access
  // -- it stalls that master, then anything sharing the interconnect behind it,
  // and ends at a watchdog reset. Answering is strictly better than that even
  // when the answer is bad news.
  //
  // WHICH PCSA MODEL THIS IS
  //
  // PCSA (DEN 0050) Section 7.2.8 names three response models for a gated
  // access. This bridge is "Stall and wake" -- "A transaction arriving at a
  // gated access control component is initially stalled. A wake-up signal is
  // asserted indicating that the downstream power domain must be made
  // available" -- which is pwakeup and the wait states exactly.
  //
  // The timeout is a FALLBACK, not a different model. Section 7.2.8's "Error"
  // model is a different thing: "There is no request to change any power domain
  // mode", i.e. it never asks. This one always asks, and only gives up when
  // asking demonstrably did not work. Setting WAKE_TIMEOUT to 0 gives the pure
  // stall-and-wake behaviour, which is right when the system can guarantee the
  // hold is short -- a local clock controller and no hierarchical power one.
  //
  // 1024 IS NOT DERIVED FROM ANYTHING
  //
  // The ordinary wake takes about four cycles, so this is ~250x margin, which
  // is a guess dressed as a number. The right value is the system's worst-case
  // upstream release latency and this module cannot know it. Treat it as an
  // integration parameter, not a default that has been thought about.
  parameter int unsigned WAKE_TIMEOUT = 1024
) (
  // The free-running clock. See the header: this must not be the PPU's gated
  // clock, and it must not be asynchronous to it either.
  input  logic aclk,
  input  logic aresetn,

  // ---- AXI4-Lite subordinate: write address ----
  input  logic [AXI_ADDR_W-1:0] s_axi_awaddr,
  // AWPROT/ARPROT are accepted and IGNORED -- see the header note on what that
  // delegates to the integration.
  input  logic [2:0]            s_axi_awprot,
  input  logic                  s_axi_awvalid,
  output logic                  s_axi_awready,

  // ---- AXI4-Lite subordinate: write data ----
  input  logic [31:0]           s_axi_wdata,
  input  logic [3:0]            s_axi_wstrb,
  input  logic                  s_axi_wvalid,
  output logic                  s_axi_wready,

  // ---- AXI4-Lite subordinate: write response ----
  output logic [1:0]            s_axi_bresp,
  output logic                  s_axi_bvalid,
  input  logic                  s_axi_bready,

  // ---- AXI4-Lite subordinate: read address ----
  input  logic [AXI_ADDR_W-1:0] s_axi_araddr,
  input  logic [2:0]            s_axi_arprot,
  input  logic                  s_axi_arvalid,
  output logic                  s_axi_arready,

  // ---- AXI4-Lite subordinate: read data ----
  output logic [31:0]           s_axi_rdata,
  output logic [1:0]            s_axi_rresp,
  output logic                  s_axi_rvalid,
  input  logic                  s_axi_rready,

  // ---- The PPU's software interface (DEN 0051E Section 6.2) ----
  output logic [REG_ADDR_W-1:0] reg_waddr,
  output logic [31:0]           reg_wdata,
  output logic [3:0]            reg_wstrb,
  output logic                  reg_wen,
  output logic [REG_ADDR_W-1:0] reg_raddr,
  output logic                  reg_ren,
  input  logic [31:0]           reg_rdata,

  // ---- The clock interlock ----
  output logic                  pwakeup,      // registered; PCK-600 Table A-28
  input  logic                  ppu_clk_ok    // 1 = the PPU's clock is guaranteed
);

  // AXI response encodings (IHI 0022 Table A3-4). Spelled out rather than
  // imported from a package, because the only package that has them is the
  // vendored PULP one and that is verification-only -- see vendor/pulp/README.md.
  localparam logic [1:0] RESP_OKAY   = 2'b00;
  localparam logic [1:0] RESP_SLVERR = 2'b10;

  // Wide enough for WAKE_TIMEOUT, and at least one bit so the declaration is
  // legal when the timeout is disabled.
  localparam int unsigned TO_W = (WAKE_TIMEOUT < 2) ? 1 : $clog2(WAKE_TIMEOUT + 1);

  typedef enum logic [1:0] {
    W_IDLE,    // ready for AW and W
    W_WAIT,    // captured; waiting for the PPU's clock
    W_ACCESS,  // reg_wen HIGH for one cycle
    W_RESP     // BVALID, waiting for BREADY
  } wstate_e;

  typedef enum logic [2:0] {
    R_IDLE,    // ready for AR
    R_WAIT,    // captured; waiting for the PPU's clock
    R_ACCESS,  // reg_ren HIGH for one cycle
    R_CAP,     // reg_rdata is valid this cycle; capture it
    R_RESP     // RVALID, waiting for RREADY
  } rstate_e;

  wstate_e wstate;
  rstate_e rstate;

  logic [REG_ADDR_W-1:0] waddr_q, raddr_q;
  logic [31:0]           wdata_q, rdata_q;
  logic [3:0]            wstrb_q;
  logic [1:0]            bresp_q, rresp_q;
  logic [TO_W-1:0]       wto_q, rto_q;

  // ---------------------------------------------------------------------------
  // Handshake outputs
  //
  // AW and W are accepted TOGETHER, in one cycle. IHI 0022 Section A3.3.1's
  // handshake dependency rules permit this: the constraint runs the other way,
  // binding the MASTER not to wait for AWREADY before asserting WVALID, and
  // leaving a subordinate free to wait for either or both. pulp-platform's
  // axi_lite_to_reg relies on the same asymmetry (its write_fifo_push is
  // aw_valid & w_valid & ~full), which is the second-hand confirmation that
  // matters here, because the AXI specification is NOT in
  // references/standards -- see the note in tb/ppu/ppu_axi_lite_tb.sv.
  //
  // Taking them separately would mean two more state bits and two more
  // registers to hold whichever arrived first, for a slave that has nothing to
  // do with the address until the data is there anyway.
  // ---------------------------------------------------------------------------
  assign s_axi_awready = (wstate == W_IDLE) && s_axi_awvalid && s_axi_wvalid;
  assign s_axi_wready  = s_axi_awready;
  assign s_axi_bvalid  = (wstate == W_RESP);
  assign s_axi_bresp   = bresp_q;

  assign s_axi_arready = (rstate == R_IDLE);
  assign s_axi_rvalid  = (rstate == R_RESP);
  assign s_axi_rdata   = rdata_q;
  assign s_axi_rresp   = rresp_q;

  // reg_wen and reg_ren are one-cycle pulses out of a state, not decodes of the
  // AXI valid signals. ppu_regs treats them as strobes and acts on every cycle
  // they are HIGH, so a level that outlived its access would write twice.
  assign reg_wen   = (wstate == W_ACCESS);
  assign reg_waddr = waddr_q;
  assign reg_wdata = wdata_q;
  assign reg_wstrb = wstrb_q;

  assign reg_ren   = (rstate == R_ACCESS);
  assign reg_raddr = raddr_q;

  // ---------------------------------------------------------------------------
  // PWAKEUP
  //
  // Registered, per Table A-28's "This signal must be driven from a register."
  // The AXI valid terms are in the expression so that it rises on the SAME edge
  // the transaction is captured rather than a cycle later -- it has to lead the
  // access, and every cycle it lags is a cycle added to every access's latency.
  //
  // It stays HIGH until both machines are idle, which is until the last
  // response has been accepted, not until the register access completed. A
  // bridge that dropped it at W_ACCESS would let the clock controller start
  // counting entry_delay_i again while B was still outstanding.
  // ---------------------------------------------------------------------------
  logic busy_next;
  assign busy_next = (wstate != W_IDLE) || (rstate != R_IDLE)
                  || (s_axi_awvalid && s_axi_wvalid) || s_axi_arvalid;

  always_ff @(posedge aclk or negedge aresetn) begin
    if (!aresetn) pwakeup <= 1'b0;
    else          pwakeup <= busy_next;
  end

  // ---------------------------------------------------------------------------
  // Write channel
  // ---------------------------------------------------------------------------
  always_ff @(posedge aclk or negedge aresetn) begin
    if (!aresetn) begin
      wstate  <= W_IDLE;
      waddr_q <= '0;
      wdata_q <= '0;
      wstrb_q <= '0;
      bresp_q <= RESP_OKAY;
      wto_q   <= '0;
    end else begin
      unique case (wstate)
        W_IDLE: begin
          if (s_axi_awvalid && s_axi_wvalid) begin
            // Bits above REG_ADDR_W are the base address the interconnect
            // already decoded; see the parameter comment.
            waddr_q <= s_axi_awaddr[REG_ADDR_W-1:0];
            wdata_q <= s_axi_wdata;
            wstrb_q <= s_axi_wstrb;
            bresp_q <= RESP_OKAY;
            wto_q   <= TO_W'(WAKE_TIMEOUT);
            wstate  <= W_WAIT;
          end
        end

        // Hold until the PPU's clock is guaranteed. With no gating in the
        // system ppu_clk_ok is tied HIGH and this is one cycle.
        W_WAIT: begin
          if (ppu_clk_ok) begin
            wstate <= W_ACCESS;
          end else if (WAKE_TIMEOUT != 0) begin
            if (wto_q == '0) begin
              // The clock never came. Report it rather than hanging the bus.
              bresp_q <= RESP_SLVERR;
              wstate  <= W_RESP;
            end else begin
              wto_q <= wto_q - TO_W'(1);
            end
          end
        end

        // One cycle of reg_wen. ppu_regs commits on this edge.
        W_ACCESS: wstate <= W_RESP;

        W_RESP: if (s_axi_bready) wstate <= W_IDLE;

        default: wstate <= W_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // Read channel
  //
  // Independent of the write channel above -- no shared state, no arbitration.
  // See difference 1 in the header.
  // ---------------------------------------------------------------------------
  always_ff @(posedge aclk or negedge aresetn) begin
    if (!aresetn) begin
      rstate  <= R_IDLE;
      raddr_q <= '0;
      rdata_q <= '0;
      rresp_q <= RESP_OKAY;
      rto_q   <= '0;
    end else begin
      unique case (rstate)
        R_IDLE: begin
          if (s_axi_arvalid) begin
            raddr_q <= s_axi_araddr[REG_ADDR_W-1:0];
            rresp_q <= RESP_OKAY;
            rto_q   <= TO_W'(WAKE_TIMEOUT);
            rstate  <= R_WAIT;
          end
        end

        R_WAIT: begin
          if (ppu_clk_ok) begin
            rstate <= R_ACCESS;
          end else if (WAKE_TIMEOUT != 0) begin
            if (rto_q == '0) begin
              // Returning stale rdata here would be worse than the error: the
              // register file's read latch still holds the PREVIOUS access's
              // value, so a wrong answer would be indistinguishable from a
              // right one. Zero it and say SLVERR.
              rresp_q <= RESP_SLVERR;
              rdata_q <= 32'h0;
              rstate  <= R_RESP;
            end else begin
              rto_q <= rto_q - TO_W'(1);
            end
          end
        end

        // One cycle of reg_ren.
        R_ACCESS: rstate <= R_CAP;

        // ppu_regs does "if (ren) rdata <= rdata_next", so the value lands on
        // the edge that LEFT R_ACCESS and is readable here -- one state later,
        // not in the same always_ff arm that issued the strobe. This state
        // exists for that one cycle of non-blocking assignment and nothing
        // else; deleting it would sample the previous read's data.
        R_CAP: begin
          rdata_q <= reg_rdata;
          rstate  <= R_RESP;
        end

        R_RESP: if (s_axi_rready) rstate <= R_IDLE;

        default: rstate <= R_IDLE;
      endcase
    end
  end

endmodule
