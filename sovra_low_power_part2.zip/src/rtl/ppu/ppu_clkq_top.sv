`timescale 1ns/1ps
// A PPU-controlled power domain whose PPU has its OWN clock gated.
//
// References: Arm CoreLink PCK-600 TRM (101150) Sections 3.5 and 3.6, Figures
// 3-8 and 3-9; Arm Power Policy Unit Architecture Specification v1.1 (ARM DEN
// 0051E) Section 2.1, Figure 2-1; AMBA Low Power Interface Specification (ARM
// IHI 0068C) Sections 2.1.2, 3.1, 4.1.1, 4.1.3.
//
//                       ┌──────────────── ppu_clk_ctrl ────────────────┐
//   hc_* ──────────────►│ hierarchical clock control                   │
//   pwr_* ─────────────►│ hierarchical power control                   │
//   qactive_only ──────►│ clk_qactive_i[1]  (LPI 4.1.3, no handshake)  │
//                       │                                              │
//                       │  clk_qreqn_o[0] ═══► ┐                       │
//                       │  clk_qacceptn_i[0] ◄═╪═ the PPU's ppuclk_*   │
//                       │  clk_qdeny_i[0]    ◄═╪═ Q-Channel            │
//                       │  clk_qactive_i[0]  ◄═┘                       │
//                       │                                              │
//                       │  clken_o ───► u_gate ───► ppu_clk            │
//                       └──────────────────────────────────────────────┘
//                                                    │
//                                   ┌────────────────▼────────────────┐
//                                   │           ppu_pd_top            │
//                                   │  PPU + PCSM on ppu_clk          │
//                                   │  device IP on dclk, unaffected  │
//                                   └─────────────────────────────────┘
//
// WHY THE PPU'S CLOCK IS WORTH GATING AT ALL
//
// The PPU lives in the always-on domain by construction. PCSA 7.2.3 requires it
// ("the PPU must be placed in a power domain that is relative always-on to the
// power domain it is controlling"), and ppu_pd_top's header records the same
// thing for the PCSM. So its supply is never removed, and between transitions
// it does nothing but clock a register file and an idle sequencer. In a SoC
// with a PPU per power domain that is a dozen permanently-clocked controllers
// whose entire purpose is saving power.
//
// DEN 0051E does not offer a way out -- Table 6-1 is one clock and one reset.
// PCK-600 does: Section 3.6 lists a "Clock control interface: For high-level
// clock control" among the PPU's four interfaces, and Table A-29 gives it four
// signals. This module is the other end of those four signals.
//
// WHAT IS GATED, AND WHAT IS NOT
//
// aon_clk feeds the PPU and the PCSM together inside ppu_pd_top, so the gate
// covers both, and that is the right answer rather than a compromise:
//
//   * the PPU only accepts quiescence when ppu_seq is in S_IDLE with nothing
//     due, which means no PCSM handshake is in flight and PCSMPREQ is stable,
//     so the PCSM has nothing to do either
//   * gating them separately would put a skewed clock across the P-Channel
//     between them, which is a synchronous interface in this design
//
// dclk is a separate port and is not touched. The device domain's clock is
// DEVCLKEN's business (Section 4.1.5) and it is gated inside ppu_pd_top by a
// mechanism that predates this one.
//
// The QACTIVE-ONLY INPUT
//
// qactive_only_i is the LPI Section 4.1.3 case wired up for real: a block in
// the same clock domain that can veto clock removal but has no handshake to
// negotiate with. In an integration it would be an asynchronous bridge's far
// side, or a debug block. Here it is a port, so the veto path is drivable and
// therefore testable -- see ppu_clkq_tb group K7.
//
// THE HIERARCHICAL CHANNELS ARE PORTS, NOT TIE-OFFS
//
// hc_* and pwr_* are brought out rather than tied to Q_RUN inside. A tie-off
// would make the two upstream paths unreachable and their logic dead code, and
// this repository has been bitten by exactly that before -- ppu_pd_top's
// parameter block records why every Chapter 7 option is forwarded to the
// boundary rather than fixed inside. Tie hc_qreqn_i and pwr_qreqn_i HIGH in an
// integration that has no controller above this one.

import ppu_pkg::*;

module ppu_clkq_top #(
  // ---- Forwarded verbatim to ppu_pd_top; see there and ppu_top ----
  parameter bit         DEF_PWR_DYN_EN        = 1'b0,
  parameter logic [3:0] DEF_PWR_POLICY        = PM_ON,
  parameter bit         WARM_RST_DEVREQEN_CFG = 1'b1,
  parameter logic [7:0] RST_HWSTAT_DLY_CFG    = 8'd2,
  parameter logic [7:0] ISO_CLKEN_DLY_CFG     = 8'd2,
  parameter logic [7:0] CLKEN_RST_DLY_CFG     = 8'd2,
  parameter logic [7:0] CLKEN_ISO_DLY_CFG     = 8'd2,
  parameter logic [7:0] ISO_RST_DLY_CFG       = 8'd2,
  parameter bit         DYN_ON_SPT_CFG        = 1'b1,
  parameter bit         DYN_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit         DYN_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit         DYN_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit         DYN_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit         DYN_OFF_SPT_CFG       = 1'b1,
  parameter bit         STA_FUNC_RET_SPT_CFG  = 1'b1,
  parameter bit         STA_FULL_RET_SPT_CFG  = 1'b1,
  parameter bit         STA_MEM_OFF_SPT_CFG   = 1'b1,
  parameter bit         STA_MEM_RET_SPT_CFG   = 1'b1,
  parameter bit         OFF_MEM_RET_TRANS_CFG = 1'b1,
  parameter bit         FUNC_RET_RAM_REG_CFG  = 1'b1,
  parameter bit         FULL_RET_RAM_REG_CFG  = 1'b1,
  parameter bit         MEM_RET_RAM_REG_CFG   = 1'b1,
  parameter bit         LOCK_CFG              = 1'b1,
  parameter bit         SW_DEV_DEL_CFG        = 1'b1,
  parameter bit         PWR_MODE_ENTRY_DEL_CFG= 1'b1,
  parameter int unsigned SYNC_STAGES          = 2,
  parameter int unsigned CNT_W                = 8,
  parameter logic [3:0] PCSM_RESET_MODESTAT   = PM_OFF,
  parameter int unsigned PCSM_TINIT_WAIT      = 16,

  // ---- The clock controller's own configuration (PCK-600 Table 3-7) ----
  //
  // NUM_Q_CHL is 1 and stays 1 here: this integration has exactly one
  // handshake-capable device in the clock domain, the PPU. ppu_clk_ctrl itself
  // supports 1-8, and ppu_clkctrl_tb elaborates it at 4 -- putting a second PPU
  // on this top would be a different module, not a parameter.
  parameter int unsigned NUM_QACTIVE_ONLY     = 1,
  parameter bit          HC_Q_CH_SYNC         = 1'b1,
  parameter bit          PWR_Q_CH_SYNC        = 1'b1,
  parameter bit          ACTIVE_DENY_EN       = 1'b1,

  // ---- The PPU's clock is a GATED LEAF, not another domain ----
  //
  // ppu_clk_ctrl runs on the ungated clock and ppu_pd_top on the leaf that
  // u_gate produces from it. While the gate is open the two are edge-aligned;
  // while it is shut the PPU receives no edges at all and therefore samples
  // nothing. Neither state is a clock domain crossing, and a frozen clock is
  // not an asynchronous clock -- there is no edge for a flop to be metastable
  // on.
  //
  // An earlier version of this comment defaulted these to 1 and justified it as
  // "the two are only synchronous while the gate is open, and the whole point
  // of the block is that sometimes it is not." That conflated "no clock" with
  // "different clock" and cost two cycles on every wake and every gate entry,
  // plus six flops, for nothing.
  //
  // PCSA 7.1.3 sanctions the arrangement and names its price, which is a
  // physical one rather than a logical one: "It is also possible to implement
  // high-level clock gating for multiple synchronous clock domains with
  // communication between them. However, this creates non-common clock
  // insertion paths that places pressure on clock tree balancing... These
  // circumstances also occur if a free-running clock domain has synchronous
  // interfaces to a high-level clock gated domain." Its mitigation is to place
  // the gate lower in the tree to lengthen the common path. Nothing in the RTL
  // can do that; it is a constraint on whoever runs CTS.
  //
  // HC_Q_CH_SYNC and PWR_Q_CH_SYNC stay 1. Those channels come from a
  // controller ABOVE this subsystem, whose clock this module cannot know.
  parameter bit          CLK_Q_CH_SYNC        = 1'b0,
  parameter bit          CLK_QACTIVE_SYNC     = 1'b0,
  parameter bit          QCLK_SYNC_EN         = 1'b0
) (
  // ---- The free-running always-on clock, before the gate ----
  input  logic aon_clk,
  input  logic aon_rst_n,     // async, ACTIVE LOW

  // ---- PPU software interface ----
  input  logic [11:0] reg_waddr,
  input  logic [31:0] reg_wdata,
  input  logic        reg_wen,
  input  logic [3:0]  reg_wstrb,
  input  logic [11:0] reg_raddr,
  input  logic        reg_ren,
  output logic [31:0] reg_rdata,
  output logic        irq,
  // PCK-600 Table A-28: must lead the access it announces, and must be driven
  // from a register.
  input  logic        pwakeup,

  // ---- Table A-22: hierarchical clock control ----
  input  logic hc_qreqn_i,
  output logic hc_qacceptn_o,
  output logic hc_qdeny_o,
  output logic hc_qactive_o,

  // ---- Table A-23: hierarchical power control ----
  input  logic pwr_qreqn_i,
  output logic pwr_qacceptn_o,
  output logic pwr_qdeny_o,
  output logic pwr_qactive_o,

  // ---- Table A-24, top NUM_QACTIVE_ONLY bits: devices with no handshake ----
  input  logic [NUM_QACTIVE_ONLY-1:0] qactive_only_i,

  // ---- Table A-25 ----
  input  logic       clk_force_i,
  input  logic [7:0] entry_delay_i,

  // ---- Table A-26 ----
  input  logic dftcgen,

  // ---- Device / workload clock domain, passed through unchanged ----
  input  logic             dclk,
  input  logic             start,
  input  logic [CNT_W-1:0] work_len,
  input  logic             light_work,
  input  logic             wake,
  input  logic             deny_enb,
  input  logic [1:0]       ip_cmd,
  input  logic [7:0]       ip_seed
);

  // The PPU's clock Q-Channel, between u_clkctrl and u_pd.
  logic ppuclk_qreqn, ppuclk_qacceptn, ppuclk_qdeny, ppuclk_qactive;

  // The gate's enable, and the gated clock the PPU and PCSM run on.
  logic ppu_clken, ppu_clk;

  // ---------------------------------------------------------------------------
  // The clock controller
  //
  // clk_qactive_i is the concatenation Table A-24 describes: the handshaking
  // devices in the low NUM_Q_CHL bits, the QACTIVE-only devices above them.
  // ---------------------------------------------------------------------------
  ppu_clk_ctrl #(
    .NUM_Q_CHL       (1),
    .NUM_QACTIVE_ONLY(NUM_QACTIVE_ONLY),
    .HC_Q_CH_SYNC    (HC_Q_CH_SYNC),
    .PWR_Q_CH_SYNC   (PWR_Q_CH_SYNC),
    .CLK_Q_CH_SYNC   (CLK_Q_CH_SYNC),
    .ACTIVE_DENY_EN  (ACTIVE_DENY_EN),
    .CLK_QACTIVE_SYNC(CLK_QACTIVE_SYNC),
    .SYNC_STAGES     (SYNC_STAGES)
  ) u_clkctrl (
    .clk    (aon_clk),
    .reset_n(aon_rst_n),

    // ---- Upstream ----
    .hc_qreqn_i    (hc_qreqn_i),
    .hc_qacceptn_o (hc_qacceptn_o),
    .hc_qdeny_o    (hc_qdeny_o),
    .hc_qactive_o  (hc_qactive_o),
    .pwr_qreqn_i   (pwr_qreqn_i),
    .pwr_qacceptn_o(pwr_qacceptn_o),
    .pwr_qdeny_o   (pwr_qdeny_o),
    .pwr_qactive_o (pwr_qactive_o),

    // ---- Downstream: the PPU is device 0 ----
    .clk_qreqn_o   (ppuclk_qreqn),
    .clk_qacceptn_i(ppuclk_qacceptn),
    .clk_qdeny_i   (ppuclk_qdeny),
    .clk_qactive_i ({qactive_only_i, ppuclk_qactive}),

    .clken_o      (ppu_clken),
    .clk_force_i  (clk_force_i),
    .entry_delay_i(entry_delay_i),
    .dftcgen      (dftcgen)
  );

  // ---------------------------------------------------------------------------
  // The gate
  //
  // Reused unmodified from the Q-Channel design, where it gates a workload's
  // clock off DEVCLKEN. The role is identical here and so is the requirement:
  // ppu_clken is in the same domain as the clock it gates, so no synchronizer, and
  // the latch keeps the enable stable across the HIGH phase so the gated clock
  // cannot glitch. In a real flow this is the library ICG cell.
  // ---------------------------------------------------------------------------
  clk_gate u_gate (
    .clk      (aon_clk),
    .clk_en   (ppu_clken),
    .gated_clk(ppu_clk)
  );

  // ---------------------------------------------------------------------------
  // The power domain, on the gated clock
  // ---------------------------------------------------------------------------
  ppu_pd_top #(
    .DEF_PWR_DYN_EN        (DEF_PWR_DYN_EN),
    .DEF_PWR_POLICY        (DEF_PWR_POLICY),
    .WARM_RST_DEVREQEN_CFG (WARM_RST_DEVREQEN_CFG),
    .RST_HWSTAT_DLY_CFG    (RST_HWSTAT_DLY_CFG),
    .ISO_CLKEN_DLY_CFG     (ISO_CLKEN_DLY_CFG),
    .CLKEN_RST_DLY_CFG     (CLKEN_RST_DLY_CFG),
    .CLKEN_ISO_DLY_CFG     (CLKEN_ISO_DLY_CFG),
    .ISO_RST_DLY_CFG       (ISO_RST_DLY_CFG),
    .DYN_ON_SPT_CFG        (DYN_ON_SPT_CFG),
    .DYN_FUNC_RET_SPT_CFG  (DYN_FUNC_RET_SPT_CFG),
    .DYN_FULL_RET_SPT_CFG  (DYN_FULL_RET_SPT_CFG),
    .DYN_MEM_OFF_SPT_CFG   (DYN_MEM_OFF_SPT_CFG),
    .DYN_MEM_RET_SPT_CFG   (DYN_MEM_RET_SPT_CFG),
    .DYN_OFF_SPT_CFG       (DYN_OFF_SPT_CFG),
    .STA_FUNC_RET_SPT_CFG  (STA_FUNC_RET_SPT_CFG),
    .STA_FULL_RET_SPT_CFG  (STA_FULL_RET_SPT_CFG),
    .STA_MEM_OFF_SPT_CFG   (STA_MEM_OFF_SPT_CFG),
    .STA_MEM_RET_SPT_CFG   (STA_MEM_RET_SPT_CFG),
    .OFF_MEM_RET_TRANS_CFG (OFF_MEM_RET_TRANS_CFG),
    .FUNC_RET_RAM_REG_CFG  (FUNC_RET_RAM_REG_CFG),
    .FULL_RET_RAM_REG_CFG  (FULL_RET_RAM_REG_CFG),
    .MEM_RET_RAM_REG_CFG   (MEM_RET_RAM_REG_CFG),
    .LOCK_CFG              (LOCK_CFG),
    .SW_DEV_DEL_CFG        (SW_DEV_DEL_CFG),
    .PWR_MODE_ENTRY_DEL_CFG(PWR_MODE_ENTRY_DEL_CFG),
    .SYNC_STAGES           (SYNC_STAGES),
    .QCLK_SYNC_EN          (QCLK_SYNC_EN),
    .CNT_W                 (CNT_W),
    .PCSM_RESET_MODESTAT   (PCSM_RESET_MODESTAT),
    .PCSM_TINIT_WAIT       (PCSM_TINIT_WAIT)
  ) u_pd (
    // The gated clock. aon_rst_n is NOT gated with it: a reset must reach the
    // PPU whether or not its clock is running, and rst_sync releases it
    // synchronously once the clock returns.
    .aon_clk  (ppu_clk),
    .aon_rst_n(aon_rst_n),

    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wen  (reg_wen),
    .reg_wstrb(reg_wstrb),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren),
    .reg_rdata(reg_rdata),
    .irq      (irq),

    .ppuclk_qreqn   (ppuclk_qreqn),
    .ppuclk_qacceptn(ppuclk_qacceptn),
    .ppuclk_qdeny   (ppuclk_qdeny),
    .ppuclk_qactive (ppuclk_qactive),
    .pwakeup        (pwakeup),

    .dclk      (dclk),
    .start     (start),
    .work_len  (work_len),
    .light_work(light_work),
    .wake      (wake),
    .deny_enb  (deny_enb),
    .ip_cmd    (ip_cmd),
    .ip_seed   (ip_seed)
  );

endmodule
