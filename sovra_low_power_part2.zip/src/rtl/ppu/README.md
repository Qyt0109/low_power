# Power Policy Unit (PPU) — Arm PPU Architecture v1.1

A synthesizable SystemVerilog implementation of a **single-Q-Channel Power
Policy Unit** from the **Arm Power Policy Unit Architecture Specification v1.1**
(ARM DEN 0051E), driving its own power domain end to end: software programs a
power policy, and the PPU sequences the device Q-Channel handshake, the clock
enable, isolation and reset controls, and the PCSM P-Channel in the order the
specification requires.

It does not reimplement either low-power protocol. The device interface is the
existing [`qchannel_controller`](../qchannel/qchannel_controller.sv) and the
PCSM interface is the existing
[`pchannel_controller`](../pchannel/pchannel_controller.sv), both instantiated
**unmodified** — the PPU is the policy layer above them, which is exactly the
architectural relationship PCSA describes.

Section references below are to ARM DEN 0051E unless marked otherwise.

> Verified with **Icarus Verilog 14.0**. `make ppu` → **477 checks, PASS**, with
> exactly **three** Q-Channel protocol violations, all deliberate and measured
> rather than tolerated — see [§9.2](#92-the-expected-protocol-violations).

For a feature-by-feature account of what is and is not implemented against the
specification, which built features are not yet covered by a test, and a
prioritised roadmap, see **[`CONFORMANCE.md`](CONFORMANCE.md)**.

---

## Contents

1. [What a PPU is, and what this one is](#1-what-a-ppu-is-and-what-this-one-is)
2. [Configuration — what was built and why](#2-configuration--what-was-built-and-why)
3. [Power modes](#3-power-modes)
4. [Allowed transitions](#4-allowed-transitions)
5. [Device control sequencing](#5-device-control-sequencing)
6. [Interfaces](#6-interfaces)
7. [Register map](#7-register-map)
8. [Module reference](#8-module-reference)
9. [Verification](#9-verification)
10. [Design decisions worth knowing about](#10-design-decisions-worth-knowing-about)
11. [Known gaps](#11-known-gaps)
12. [Running](#12-running)

---

## 1. What a PPU is, and what this one is

A Q-Channel or P-Channel tells you *whether a component is willing to be
stopped*. It does not tell you what "stopped" means, in what order to remove
things, or how to get back. That is a PPU's job: it owns the power **policy**
for one domain, and turns a programmed mode into an ordered sequence of
operations across three interfaces.

```
   software  ──►  ppu_regs ──policy──► ppu_seq ──┬──► qchannel_controller ══► device
                     ▲                     │     │       DEVQREQn / DEVQACCEPTn
                     │ status              │     │       / DEVQDENY / DEVQACTIVE
                     └─────────────────────┘     │
                     ▲                     │     ├──► DEVCLKEN, DEVISOLATEn,
                  ppu_irq ◄─── events ─────┘     │    DEV*RESETn, PPUHWSTAT
                     │                           │
                     └──► IRQ                    └──► pchannel_controller ══► PCSM
                                                       PCSMPSTATE / PCSMPREQ
                                                       / PCSMPACCEPT
```

The device interface is a **Q-Channel** and the PCSM interface is a
**P-Channel**. Those are independent choices, not a contradiction — §2.2 states
plainly that *"The interface between the PPU and the PCSM is a P-Channel"*
regardless of what the device interface is. `MEM_RET`, `FULL_RET` and
`FUNC_RET` all need it, because retention is something the PCSM does, not
something a Q-Channel can express.

This is the runnable counterpart to the PPU specification,
[`references/standards/arm-power-policy-unit-architecture-spec-v1.1.pdf`](../../../references/standards/arm-power-policy-unit-architecture-spec-v1.1.pdf)
(DEN 0051E), and it is the
"sequencer that PCSA calls the PPU" that
[`src/upf/README.md`](../../upf/README.md) names as the missing piece in the
Q-Channel design's known gaps.

---

## 2. Configuration — what was built and why

### 2.1 Scope

- **Device interface: exactly one Q-Channel** (`DEVCHAN_CFG = 1`, §7.1.1). This
  is the single biggest scope reduction the specification allows, and it is a
  reduction in *what can exist*, not merely in what was requested: operating
  modes, `DBG_RECOV` and `LOGIC_RET` are P-Channel-only extensions (§3.1.1,
  §3.1.2), and Table 5-26 hard-wires their support bits to 0 *"for a Q-Channel
  PPU"*. They are architecturally absent.
- **Power modes:** `WARM_RST`, `ON`, `FUNC_RET`, `MEM_OFF`, `FULL_RET`,
  `MEM_RET`, `OFF` — exactly the set Figure 3-2 makes available to a Q-Channel
  PPU, minus the two optional emulation modes (`OFF_EMU`, `MEM_RET_EMU`), which
  are not built.

### 2.2 Optional features

The specification is heavily optional-feature-driven (§7 lists the axes). This
instance is built at the **full-feature tier**, and every choice is reported
back to software in `PPU_IDR0`/`PPU_IDR1` so the identification registers can
never disagree with what was actually elaborated.

| Feature | Built? | Where it shows up |
|---|:---:|---|
| Dynamic transitions (`PWR_DYN_EN`) | yes | `ppu_seq` target selection, `PPU_IDR0[28:20]` |
| Retention scope registers (`PPU_FUNRR`/`FULRR`/`MEMRR`) | yes | `PCSMPSTATE[15:8]`, `PPU_IDR1[6:4]` |
| Software device-control delays (`PPU_DCDR0/1`) | yes | the `*_DLY` counters, `PPU_IDR1[1]` |
| Power mode entry delay timers (`PPU_EDTR0/1`) | yes | `S_DELAY`, `PPU_IDR1[0]` |
| Lock (`PPU_UNLK`, `LOCK_EN`/`LOCK_STATUS`) | yes | `PPU_IDR1[2]` |
| `OFF → MEM_RET` direct transition | yes | `S_PCSM_ONLY`, `PPU_IDR1[12]` |
| Emulation modes (`OFF_EMU`, `MEM_RET_EMU`) | no | `PPU_PMER` reserved |
| Operating modes | **cannot exist** | `PPU_OPSR` reserved, `NUM_OPMODE = 0` |

Every one of them is a parameter on [`ppu_top`](ppu_top.sv), so a smaller PPU is
a parameter change rather than a fork.

### 2.3 Choices the specification left open

| Question | Choice | Reasoning |
|---|---|---|
| Software bus protocol (§6.2.1 — IMPLEMENTATION DEFINED) | **generic strobe** (`addr`/`wdata`/`wen`/`ren`/`rdata`, one-cycle registered read) | The spec offers APB only as an example. Nothing in `ppu_regs` depends on the handshake, so an APB wrapper is additive. |
| Default power policy (§7.1.3) | **`ON`** | The PPU brings the domain up out of reset unaided (Figure 4-18), which makes the reset sequence itself a testable behaviour rather than a special case. |
| `PPUHWSTAT` layout (§4.1.4) | **spec-exact bit positions** | Bit *N* is set for mode *N*, so a consumer written against the full encoding works unmodified. Bits 1, 3, 4 and 10 are permanently 0 here. |
| `PPU_IIDR.IMPLEMENTER` (§5.2.25) | **`0x000`** | Explicitly **not** `0x43B` — that is Arm's registered JEP106 identity code and this is not an Arm-licensed implementation. |
| Retention scope bits (§5.2.16–18) | **opaque pass-through** | The spec marks them IMPLEMENTATION DEFINED. The PPU routes the register belonging to the mode being entered to `PCSMPSTATE[15:8]` and attaches no meaning. |
| Integration | **standalone domain** | A new power domain with its own workload, rather than retrofitting `qchannel_pd_top`'s hand-written controllers. See [§11](#11-known-gaps). |
| UPF | **in scope** | [`src/upf/ppu_pd_top.upf`](../../upf/ppu_pd_top.upf), matching the Q-Channel block's precedent that power intent is a real deliverable even where no installed simulator can execute it. |

---

## 3. Power modes

Table 3-1 and Table 3-2, trimmed to this PPU's seven modes. Encoding values are
unchanged from the specification, so `PWR_POLICY` stays forward-compatible if
emulation modes are added later.

| Power Mode | Logic | RAM | `PWR_POLICY[3:0]` | `PCSMPSTATE[3:0]` | `PPUHWSTAT` | Priority |
|---|---|---|---|---|---|---|
| `WARM_RST` | ON | ON  | `0b1001` (9) | `0b1000`ᵃ | bit 9 | High |
| `ON`       | ON | ON  | `0b1000` (8) | `0b1000`  | bit 8 | │ |
| `FUNC_RET` | ON | RET | `0b0111` (7) | `0b0111`  | bit 7 | │ |
| `MEM_OFF`  | ON | OFF | `0b0110` (6) | `0b0110`  | bit 6 | │ |
| `FULL_RET` | RET| RET | `0b0101` (5) | `0b0101`  | bit 5 | │ |
| `MEM_RET`  | OFF| RET | `0b0010` (2) | `0b0010`  | bit 2 | │ |
| `OFF`      | OFF| OFF | `0b0000` (0) | `0b0000`  | bit 0 | Low |

ᵃ In `WARM_RST` the PPU instructs the PCSM to hold the same conditions as `ON`
(Table 3-2 footnote a — the PCSM has no notion of warm reset, only the device
interface does). That single substitution is what makes `ON ↔ WARM_RST` a
transition with **no PCSM handshake at all**: the requested state does not
change, so there is nothing to request.

### Priority *is* the encoding

The modes are listed in priority order and their encodings are monotonic in
exactly that order:

```
OFF(0) < MEM_RET(2) < FULL_RET(5) < MEM_OFF(6) < FUNC_RET(7) < ON(8) < WARM_RST(9)
```

so "is this a transition to a lower priority mode?" is a plain magnitude
compare. That is a property of the specification's numbering, and it is why
there is no separate priority lookup table anywhere in the RTL.

### Unsupported policies

Values `1` (`OFF_EMU`), `3` (`MEM_RET_EMU`), `4` (`LOGIC_RET`), `10`
(`DBG_RECOV`) and `11`–`15` are decoded in order to be **rejected**. Programming
one leaves `PPU_PWPR` unchanged and raises `UNSPT_POLICY_IRQ` (§4.1.1
"Programming Unsupported Policies").

Support is a joint property of the policy **and** the dynamic enable — *"Whether
a policy is supported is a combination of the policy setting and the dynamic
enables"*. `WARM_RST` is the case that makes the distinction real: it is a legal
static policy and an illegal dynamic one, because §3.4.3 excludes it from
dynamic transitions on a Q-Channel PPU. Both halves are tested in P9.

---

## 4. Allowed transitions

Per §3.3.2, verbatim: *"Although multiple power modes are supported with a
Q-Channel PPU it only transitions between ON and the power mode programmed in
the PPU_PWPR register."* Every hop has `ON` at one end, so the transition graph
collapses to one decision rather than a table:

```
ON(8) <──────────► WARM_RST(9)   handshake optional (PPU_PTCR.WARM_RST_DEVREQEN)
ON(8) <──────────► FUNC_RET(7)   full device + PCSM handshake
ON(8) <──────────► MEM_OFF(6)    full device + PCSM handshake
ON(8) <──────────► FULL_RET(5)   full device + PCSM handshake
ON(8) <──────────► MEM_RET(2)    full device + PCSM handshake
ON(8) <──────────► OFF(0)        full device + PCSM handshake

OFF(0) ──────────► MEM_RET(2)    ONE WAY. PCSM only, no device handshake
```

Every other pair of non-`ON` modes connects only through `ON`. `FULL_RET →
MEM_OFF` is `FULL_RET → ON → MEM_OFF`: two full device-control sequences back to
back, and P4 counts the handshakes to prove it.

**The `OFF → MEM_RET` shortcut is one-way.** §3.3.2 lists it among the
transitions that perform no device handshake *"as the component is not aware the
transition is taking place"*, and Table 4-14 gives `MEM_RET` only `ON` (and
`DBG_RECOV`) as end modes — so `MEM_RET → OFF` routes through `ON` like anything
else. P8 exercises both directions and checks the asymmetry.

### Static vs dynamic

- **Static** (`PWR_DYN_EN = 0`): `PPU_PWPR.PWR_POLICY` is the target.
- **Dynamic** (`PWR_DYN_EN = 1`, §3.4.3): the policy is a **minimum**. In `ON`,
  all enabled `DEVQACTIVE` LOW starts a transition to the policy; in the policy
  mode, any enabled `DEVQACTIVE` HIGH starts a transition back to `ON`.
  `WARM_RST` is excluded entirely — static-only, always.

Both directions collapse into a single expression in `ppu_seq`:

```systemverilog
if (locked_q)          final_tgt = cur_mode;
else if (dyn_status_q) final_tgt = qactive_eff ? PM_ON : pwr_policy;
else                   final_tgt = pwr_policy;
```

### Lock

With `LOCK_EN` and `PWR_DYN_EN` both set, reaching a lockable mode (`OFF` or
`MEM_RET`) pins the PPU there *"even if the DEVACTIVE inputs, or software set
minimum policy, are requesting a higher priority power mode"* (§3.4.3), until
`PPU_UNLK.UNLOCK` is written or either enable is cleared. P10 raises a wake
against a locked PPU and checks nothing happens.

---

## 5. Device control sequencing

Device control values per mode, from Tables 4-7, 4-9 and 4-11:

| Power Mode | `DEVPORESETn` | `DEVWARMRESETn` | `DEVRETRESETn` | `DEVCLKEN` | `DEVISOLATEn` |
|---|---|---|---|---|---|
| `WARM_RST` | 1 | **0** | **0** | 1 | 1 |
| `ON`       | 1 | 1 | 1 | 1 | 1 |
| `FUNC_RET` | 1 | 1 | 1 | 1 | 1 |
| `MEM_OFF`  | 1 | 1 | 1 | 1 | 1 |
| `FULL_RET` | 1 | **0** | 1 | **0** | **0** |
| `MEM_RET`  | **0** | **0** | **0** | **0** | **0** |
| `OFF`      | **0** | **0** | **0** | **0** | **0** |

All resets active LOW, clock enable and isolation active HIGH (§6.1, §6.4).

The two rows asserting exactly one warm reset are near-opposites and easy to
transcribe into each other — which is exactly what happened once, and what
[`CONFORMANCE.md`](CONFORMANCE.md) F1 records. Table 4-8 gives the distinction:
`DEVWARMRESETn` is the warm reset for **non-retention** registers and
`DEVRETRESETn` for **retention** ones. So:

- **`FULL_RET`** asserts `DEVWARMRESETn` only. The non-retained logic resets
  while retained registers stay live on the retention supply. A mode that
  resets some flops and not others is only meaningful if some flops retain —
  which is why the UPF carries a retention strategy the Q-Channel design
  correctly did without.
- **`WARM_RST`** asserts **both**, because a warm reset of the component resets
  all of its state, retained included. Table 4-9 groups it with the emulation
  modes for that reason.

`FUNC_RET` and `MEM_OFF` share `ON`'s entire row. The whole distinction between
those modes and `ON` lives on the PCSM interface.

### 5.1 Ordering (§4.1.5)

**Leaving `ON`** — device handshake first, *then*:

1. Clock enables de-asserted
2. Isolation asserted, after `CLKEN_ISO_DLY` cycles
3. Resets asserted, after `ISO_RST_DLY` cycles
4. PCSM handshake to the target's `PCSMPSTATE`

**Returning to `ON`** — PCSM handshake first, *then*:

1. Isolation de-asserted
2. Clock enables asserted, after `ISO_CLKEN_DLY` cycles
3. Resets de-asserted, after `CLKEN_RST_DLY` cycles
4. Device handshake to exit quiescence, concurrently with
5. `PPUHWSTAT` update, after `RST_HWSTAT_DLY` cycles *and* the device handshake
   completing — Table 4-5 makes that delay *"also dependant on the completion of
   the device interface"*

Each delay is *"minimum cycles = N + 1"* (Table 4-5), so 0 is a legal value
meaning one cycle. P2 checks the whole ordering as edge timestamps in both
directions.

`ON → WARM_RST` uses the *departure* order even though `WARM_RST` is higher
priority than `ON` (Figure 4-26: handshake, then assert `DEVWARMRESETn`). What
decides the order is which end of the hop is `ON`, not which mode is nominally
higher up the ladder — a priority compare would get that case wrong.

### 5.2 Denial (§4.1.1, §4.2.9)

A Q-Channel transition to a higher priority mode cannot be denied, and on the
departure path the device handshake runs *before* any device control moves.

That un-deniability is a PPU-spec statement, §4.2.9: *"Q-Channel PPU
transitions to higher priority power modes, except for those to warm reset,
cannot be denied."* The same section's Figure 4-36 shows a P-Channel
PPU *being* denied on `FULL_RET → ON`. What makes it true here is AMBA LPI (ARM IHI 0068C) Table 2-1:
`Q_DENIED` is reachable only from `Q_REQUEST`, and the exit path
`Q_STOPPED → Q_EXIT → Q_RUN` has no denial state, so a device cannot refuse to
come back up. Every return to `ON` is an exit handshake.
So by construction the only state that can observe `DEVQDENY` is the one waiting
for quiescence, and at that point nothing has been sequenced yet.

That makes §4.1.1's *"reverse whatever device controls were already sequenced"*
vacuous in this ordering — there is nothing to reverse, and P5 checks that no
clock, isolation or reset control was touched. What the denial path actually
does is the other half of §4.1.1: revert `PWR_POLICY` to the current mode per
Table 4-1, raise the denial event, and wait for the Q-Channel's own
`Q_DENIED → Q_CONTINUE → Q_RUN` recovery before going idle.

---

## 6. Interfaces

### 6.1 Clock and reset (§6.1)

| Signal | Dir | Description |
|---|---|---|
| `clk` | in | PPU clock |
| `rst_n` | in | PPU reset, active LOW |

### 6.1.1 Clock control interface (`PPUCLK*`) — **not in DEN 0051E**

Table 6-1 gives the PPU one clock and one reset, and the architecture says
nothing about gating either. This is the interface Arm's own PPU adds on top:
PCK-600 §3.6 lists a *"Clock control interface: For high-level clock control"*
beside the software, device and PCSM interfaces, and Table A-29 names it.

| Signal | Dir | Clock | Description |
|---|---|---|---|
| `ppuclk_qreqn` | in | async when `QCLK_SYNC_EN` | a clock controller asking the PPU to let its clock be gated |
| `ppuclk_qacceptn` | out | `clk` | the PPU accepts |
| `ppuclk_qdeny` | out | `clk` | the PPU refuses |
| `ppuclk_qactive` | out | **asynchronous** | the PPU requires `clk` |
| `pwakeup` | in | — | Table A-28: software is about to touch the register file. *"This signal must be driven from a register."* |

**The direction is the one that surprises.** The device interface below makes
the PPU a Q-Channel *controller*; this makes it a Q-Channel *device* to a clock
controller sitting above it.

**Why it is worth having.** A PPU is in the always-on domain by construction
(PCSA §7.2.3) and idle almost all the time, so its clock is pure leakage between
transitions — and a SoC with a PPU per domain has one of these running for every
domain it manages.

**`PPUCLKQACTIVE` is a wire, not a flip-flop, and it has to be.** The clock that
would register it is the clock it is asking for, so once the interface reaches
`Q_STOPPED` and the controller gates, a flopped `QACTIVE` can never rise again
and the PPU can never be woken. LPI §4.1.1 works the dependency through, Table
A-29 marks the signal *"Asynchronous"* while the acknowledges are `clk`, and
Table 3-7 says outright that *"The path from a device to the controller QACTIVE
is combinatorial, irrespective of whether synchronizers are present."*

It is driven from three terms, and each covers a different way work reaches an
idle PPU:

| Term | Covers |
|---|---|
| `ppu_seq.ppu_active` | a transition in flight, a transition due, or §4.1.6's reset-time PCSM handshake unfinished |
| `pwakeup` | software, per Table A-28 |
| `dev_qactive & devactiveen` | the device asking to wake. The **raw** pin, because `sync_dev_qactive` is clocked by the clock that has stopped |

**The expression exists twice, and the difference is the point.** It feeds two
consumers with opposite requirements:

| Copy | Goes to | `DEVQACTIVE` used |
|---|---|---|
| `ppuclk_needed` | `assign qactive = dev_active;` — out the pin as a wire | **raw** — a synchroniser here is the deadlock |
| `ppuclk_deny` | `if (dev_deny) state <= Q_DENIED;` — a flop on `clk` | **`sync_dev_qactive`** — otherwise this is an unsynchronised crossing into a state enum, and a metastable `state` is undefined rather than merely wrong |

The skew between them is harmless and in the safe direction: the worst case is
the PPU accepting a request it would have denied, and the clock is not lost
because the controller has already seen the raw `QACTIVE` rise, so its own
request drops before `clken_o` can fall. `pwakeup` is in neither category —
Table A-28 puts it in the APB group whose Clock column is `clk`.

**Denial rather than stalling.** A transition can run for hundreds of cycles —
five device-control delays, an entry delay up to 255, and the PCSM's tinit — and
LPI §2.1.1 gives denial as the mechanism for exactly that: *"a device can
maintain an operational state while having a mechanism by which it can promptly
complete the handshake."*

Nothing inside the PPU consumes the channel's state. Tie `ppuclk_qreqn` HIGH and
`pwakeup` LOW to park it in `Q_RUN` and the design behaves exactly as it did
before the interface existed, which is what every suite other than `ppuclkq`
does.

### 6.2 Software interface (§6.2)

Generic strobe. One-cycle registered read, no wait states.

| Signal | Dir | Description |
|---|---|---|
| `reg_waddr[11:0]` | in | write offset |
| `reg_raddr[11:0]` | in | read offset, independent of `reg_waddr` |
| `reg_wdata[31:0]` | in | write data |
| `reg_wen` / `reg_ren` | in | write / read strobe |
| `reg_wstrb[3:0]` | in | byte lanes for `reg_wdata`; tie to `4'hF` for word-only masters |
| `reg_rdata[31:0]` | out | read data, valid the cycle after `reg_ren` |
| `irq` | out | active-HIGH level interrupt |

### 6.2.1 Signal naming — `dev_*` and `pcsm_*`, not `dev*` and `pcsm*`

The device-control and PCSM ports carry an underscore after the block prefix:
`dev_qreqn`, `dev_clken`, `dev_poresetn`, `pcsm_pstate`, `pcsm_preq`.

That is a choice between two Arm conventions rather than a departure from one.
DEN 0051E names them `DEVQREQn`, `DEVCLKEN`, `PCSMPSTATE` — the concatenated
uppercase form — and every reference to the **specification's** name in this
repository still uses it, in comments, tables and documents. PCK-600, which is
Arm implementing the same architecture in RTL, spells the ports
`dev_preq_o`, `dev_pstate_o`, `dev_qacceptn_i`, `pcsm_paccept_i`,
`ppuclk_qreqn_i`. The underscore form is Arm's own for signal names; the
concatenated form is Arm's own for spec text. Both are used here, for the thing
each is used for.

The practical gain is that a name now splits at its interface boundary:
`dev_` / `pcsm_` / `ppuclk_` is the interface, the rest is the signal. That
already mattered once — `ppuclk_qreqn` and `dev_qreqn` are different Q-Channels
in opposite directions, and reading them as `ppuclkqreqn` and `devqreqn` makes
that a matter of noticing four characters.

### 6.3 Device interface — one Q-Channel (§6.3)

`DEVQREQn`, `DEVQACCEPTn`, `DEVQDENY`, `DEVQACTIVE` — exactly the port set of
[`qchannel_controller`](../qchannel/qchannel_controller.sv), which is why it is
instantiated rather than reimplemented.

### 6.4 Device control signals (§6.4)

| Signal | Dir | Description |
|---|---|---|
| `ppuhwstat[15:0]` | out | one-hot current power mode, hardware-qualifiable by other blocks (§4.1.4) |
| `dev_clken` | out | domain clock enable, active HIGH |
| `dev_poresetn` | out | power-on reset, active LOW |
| `dev_retresetn` | out | retention reset, active LOW |
| `dev_warmresetn` | out | warm reset, active LOW |
| `dev_isolaten` | out | isolation control, active LOW |

### 6.5 PCSM interface (§6.5)

| Signal | Dir | Description |
|---|---|---|
| `pcsm_pstate[15:0]` | out | `[3:0]` power mode, `[7:4]` reserved 0 (no operating modes), `[15:8]` RAM retention config |
| `pcsm_preq` | out | P-Channel request |
| `pcsm_paccept` | in | P-Channel accept |
| `pcsm_modestat[7:0]` | in | PCSM mode at reset release; only `0x0` (OFF) and `0x2` (MEM_RET) legal (§4.1.6) |

**No `PCSMPDENY` or `PCSMPACTIVE`** — §4.1.6 excludes them: *"It has no PDENY or
PACTIVE signals."* A PCSM cannot refuse; refusing to remove power is not the
actuator's decision, it is one the PPU already made on the device's behalf over
the Q-Channel.

---

## 7. Register map

Table 5-1, restricted to a single-Q-Channel, no-operating-mode PPU. Registers
reserved *by construction* are decoded and dropped rather than left to a default
arm, so an access to one is visibly "a register this PPU does not have" rather
than indistinguishable from a mistyped address.

| Offset | Name | Access | Notes |
|---|---|---|---|
| `0x000` | `PPU_PWPR` | R/W | `[12]` `LOCK_EN`, `[8]` `PWR_DYN_EN`, `[3:0]` `PWR_POLICY`. The only register whose write can be **refused** — see §3. |
| `0x004` | `PPU_PMER` | — | **Reserved**: no emulation modes |
| `0x008` | `PPU_PWSR` | RO | `[12]` `LOCK_STATUS`, `[8]` `PWR_DYN_STATUS`, `[3:0]` `PWR_STATUS` |
| `0x010` | `PPU_DISR` | RO | `[0]` `DEVQACTIVE` status; one channel, so `[10:1]` reserved |
| `0x014` | `PPU_MISR` | RO | `[16]` `DEVQDENY`, `[8]` `DEVQACCEPTn`, `[0]` `PCSMPACCEPT` — pin values, not decoded meanings |
| `0x018` | `PPU_STSR` | — | **Reserved**: §5.2.6, *"For a Q-Channel PPU with a single Q-Channel this register is reserved"* |
| `0x01C` | `PPU_UNLK` | WO | `[0]` `UNLOCK`; reads as 0 |
| `0x020` | `PPU_PWCR` | R/W | `[8]` `PWR_DEVACTIVEEN[0]`, `[0]` `DEVREQEN[0]`; both reset HIGH (Table 5-10) |
| `0x024` | `PPU_PTCR` | R/W | `[0]` `WARM_RST_DEVREQEN`; `[1]` reserved (no `DBG_RECOV`) |
| `0x030` | `PPU_IMR` | R/W | `[5]` `LOCKED`, `[2]` `STA_DENY`, `[1]` `STA_ACCEPT`, `[0]` `STA_POLICY_TRN`; `[4:3]` reserved (emulation) |
| `0x034` | `PPU_AIMR` | R/W | `[2]` `DYN_DENY`, `[1]` `DYN_ACCEPT`, `[0]` `UNSPT_POLICY`; `[4:3]` reserved — §4.1.2 makes **both** policy-split completion events unsupported without operating modes |
| `0x038` | `PPU_ISR` | R/W1C | mirrors `PPU_IMR`, plus `[8]` input edge and `[7]` `OTHER_IRQ` (derived) |
| `0x03C` | `PPU_AISR` | R/W1C | mirrors `PPU_AIMR` |
| `0x040` | `PPU_IESR` | R/W | `[1:0]` `DEVACTIVE00_EDGE` only; the rest are P-Channel |
| `0x044` | `PPU_OPSR` | — | **Reserved**: operating modes are P-Channel only (§5.2.15) |
| `0x050` | `PPU_FUNRR` | R/W | `[7:0]` → `PCSMPSTATE[15:8]` in `FUNC_RET` |
| `0x054` | `PPU_FULRR` | R/W | ditto for `FULL_RET` |
| `0x058` | `PPU_MEMRR` | R/W | ditto for `MEM_RET` |
| `0x160` | `PPU_EDTR0` | R/W | `FULL_RET_DEL[31:24]`, `MEM_RET_DEL[15:8]`, `OFF_DEL[7:0]`; `[23:16]` reserved (no `LOGIC_RET`) |
| `0x164` | `PPU_EDTR1` | R/W | `FUNC_RET_DEL[15:8]`, `MEM_OFF_DEL[7:0]` |
| `0x170` | `PPU_DCDR0` | R/W | `RST_HWSTAT_DLY[23:16]`, `ISO_CLKEN_DLY[15:8]`, `CLKEN_RST_DLY[7:0]` |
| `0x174` | `PPU_DCDR1` | R/W | `CLKEN_ISO_DLY[15:8]`, `ISO_RST_DLY[7:0]` |
| `0xFB0` | `PPU_IDR0` | RO | `0x1E53_E501` for this build |
| `0xFB4` | `PPU_IDR1` | RO | `0x0000_1077` for this build |
| `0xFC8` | `PPU_IIDR` | RO | `0x50C0_1000` — `IMPLEMENTER = 0x000`, deliberately not Arm's `0x43B` |
| `0xFCC` | `PPU_AIDR` | RO | `0x0000_0011` — architecture v1.1 |

All reserved bits are write-ignored and read-as-zero (§5.2).

### Interrupt behaviour

Three rules shape all of [`ppu_irq`](ppu_irq.sv):

1. **Masking suppresses the status bit, not just the output** (§5.2.10) — so the
   mask is an AND on the *set* term. Unmasking later does not resurrect an event
   that occurred while masked.
2. **Set beats clear in the same cycle** (§4.1.2) — *"If an event is cleared in
   the same cycle that it re-occurs the interrupt status stays HIGH."*
3. **`OTHER_IRQ` is derived, never stored** (§5.2.12) — it is a live OR of
   `PPU_AISR`, so it can never disagree with the register it summarises.

Default masks (Tables 5-13, 5-14) report completion, denial and unsupported
policy, and stay quiet about routine acceptances.

---

## 8. Module reference

| Module | File | Role |
|---|---|---|
| `ppu_pkg` | [`ppu_pkg.sv`](ppu_pkg.sv) | mode encodings, the Table 4-7/4-9/4-11 device-control lookup, `PPUHWSTAT`/`PCSMPSTATE` encodings, register offsets, support decode |
| `ppu_regs` | [`ppu_regs.sv`](ppu_regs.sv) | the register file; owns the one place a write can be refused |
| `ppu_irq` | [`ppu_irq.sv`](ppu_irq.sv) | `PPU_IMR`/`AIMR`/`ISR`/`AISR`/`IESR` and the event set/clear arbitration |
| `ppu_seq` | [`ppu_seq.sv`](ppu_seq.sv) | **the mode sequencer** — the only genuinely new design work |
| `ppu_top` | [`ppu_top.sv`](ppu_top.sv) | the PPU: the three above plus the two reused protocol controllers |
| `ppu_pcsm` | [`ppu_pcsm.sv`](ppu_pcsm.sv) | PCSM model — P-Channel device end plus the Table 3-1 actuation decode |
| `rst_sync` | [`rst_sync.sv`](../common/rst_sync.sv) | **`rtl/common`** — async-assert / sync-release reset synchroniser, deliberately *without* the interlock `qchannel_devrst_ctrl` bundles in |
| `ppu_monitor` | [`ppu_monitor.sv`](ppu_monitor.sv) | protocol monitor for the PPU's **own** rules (`U1`–`U9`), blind to the sequencer |
| `ppu_pd_top` | [`ppu_pd_top.sv`](ppu_pd_top.sv) | the standalone power domain: `ppu_dom_top` + `ppu_device_ip` (it held PPU + PCSM + Q-Channel wrapper + workload itself until the split below) |
| `qchannel_device_comb` | [`qchannel_device_comb.sv`](../qchannel/qchannel_device_comb.sv) | Q-Channel **device** FSM for a *clock*-control interface: registered `QACCEPTn`/`QDENY`, **combinational** `QACTIVE` |
| `ppu_clk_ctrl` | [`ppu_clk_ctrl.sv`](ppu_clk_ctrl.sv) | the clock controller (PCK-600 CLK-CTRL): 1–8 device Q-Channels, 0–32 QACTIVE-only vetoes, two hierarchical channels, `clken_o` |
| `ppu_clkq_top` | [`ppu_clkq_top.sv`](ppu_clkq_top.sv) | `ppu_clk_ctrl` + gate + `ppu_pd_top`: a PPU whose **own** clock is gated when it is idle |
| `ppu_axi_lite_adapter` | [`ppu_axi_lite_adapter.sv`](ppu_axi_lite_adapter.sv) | AXI4-Lite to the generic strobe, with `PWAKEUP` and the clock interlock. Modelled on pulp-platform's `axi_lite_to_reg`; three documented differences |
| `ppu_top_axi_lite` | [`ppu_top_axi_lite.sv`](ppu_top_axi_lite.sv) | the adapter + `ppu_top`. Its one piece of logic is the `Q_RUN` decode that tells the bridge the clock arrived |

Added since this table was written (note of 2026-10-06; each file's header is
the reference):

| Module | File | Role |
|---|---|---|
| `ppu_dom_top` | [`ppu_dom_top.sv`](ppu_dom_top.sv) | the domain **without** the device: PPU, PCSM (`PGOOD_EN = 0`, switch settling by `PCSM_*_SETTLE`), the always-on Q-Channel device agent, the device clock gate and reset synchronisers. Device-side ports `dev_quiescent_busy/deny`, `dev_wake`, `dev_quiescent_ok`, `dev_clk`, `dev_clken_req` (DEVCLKEN resynchronised into `dclk`, the request for a SoC clock gate; platform plan H16, see `../ckrst`), `dev_nret_rst_n`, `dev_ret_rst_n`, `dev_isolaten`, `ppuhwstat`, `logic_on`, `logic_ret`, `ret_n`, `ram_sleep`, `ram_sd` |
| `ppu_axi_dom_top` | [`ppu_axi_dom_top.sv`](ppu_axi_dom_top.sv) | AXI4-Lite bridge + PPU clock controller and gate over `ppu_dom_top`: the per-domain unit soc4 instantiates four times. Set `CLK_QACTIVE_SYNC = 1` when `dclk` is asynchronous to `aclk` (CDC-1, requirement R3, `src/signoff/SIGNOFF_REPORT.md`) |
| `ppu_axi_pd_top` | [`ppu_axi_pd_top.sv`](ppu_axi_pd_top.sv) | `ppu_axi_dom_top` + `ppu_device_ip` |
| `ppu_device_ip` | [`ppu_device_ip.sv`](ppu_device_ip.sv) | the stand-in device that replaced `dummy_workload`: `ppu_ip_core` (non-retained), `ppu_ip_ret` (retained), eight `ppu_ip_sram` banks on `ram_sleep` / `ram_sd` pins |
| `ppu_acg_pd_top` | [`ppu_acg_pd_top.sv`](ppu_acg_pd_top.sv) | a PPU domain reached through the TL-UL access control gate (`../acg`) |
| `ppu_lpd_pd_top` | [`ppu_lpd_pd_top.sv`](ppu_lpd_pd_top.sv) | one PPU, one LPD-Q (`../qchannel/qchannel_lpd.sv`), N devices |

### The sequencer

Thirteen states, in three chains plus two special cases:

```
S_IDLE ──► S_DELAY ──► S_DN_QREQ ──► S_DN_CLKEN ──► S_DN_ISO ──► S_DN_RST ──► S_DN_PCSM
              (entry       │  denial                                                  │
               delay)      ▼                                                          │
                        S_DENIED ──────────────────────────────────────────────────┐  │
                                                                                    ▼  ▼
S_IDLE ◄── S_UP_RST ◄── S_UP_CLKEN ◄── S_UP_ISO ◄── S_UP_PCSM ◄── S_IDLE          S_IDLE
                                                                                       
S_IDLE ──► S_PCSM_ONLY ──► S_IDLE        (OFF → MEM_RET: PCSM handshake and nothing else)
```

The two orderings of §4.1.5 are separate state chains rather than one shared
chain with a direction flag: they are reverses of each other only in the signal
names, not in what each step waits for, and merging them would hide that.

**The device control sequence is walked unconditionally**, including on hops
where a given signal does not change value (`ON ↔ FUNC_RET` is a complete no-op
on the wires). That is deliberate — skipping steps would make the observable
timing of a transition depend on which pair of modes it connects, which is much
harder to verify than "the sequence is always the same shape", and Table 4-5
constrains a *minimum* separation that an extra delay cannot violate.

---

## 9. Verification

[`../../tb/ppu/ppu_pd_tb.sv`](../../tb/ppu/ppu_pd_tb.sv), eleven phases, with a
`qchannel_monitor` running throughout. Full phase-by-phase breakdown in
[`TEST_MATRIX.md`](../../tb/ppu/TEST_MATRIX.md).

| Phase | Proves |
|---|---|
| P0 | reset to `ON` unaided, and §4.2.1's *"This default transition does not generate an interrupt event"* |
| P1 | every register's **reset value** against its Chapter 5 Default; `PPU_IDR0`/`IDR1`/`IIDR`/`AIDR` describe what was built |
| P2 | every `ON ↔ X` hop, with §4.1.5 ordering checked as timestamps both ways |
| P3 | `ON ↔ WARM_RST` with `WARM_RST_DEVREQEN` both 1 and 0 (Table 4-4) |
| P4 | `FULL_RET → MEM_OFF` is two handshakes through `ON`, and **one** completion interrupt |
| P5 | denial reverts the policy, raises `STA_DENY_IRQ`, touches no device control |
| P6 | the PCSM handshake gates the sequence in both directions |
| P7 | dynamic transitions via `DEVQACTIVE`, both directions, including a wake from a powered-down domain |
| P8 | `OFF → MEM_RET` is PCSM-only; the reverse routes through `ON` |
| P9 | unsupported policies refused, and support depends on policy **and** dynamic enable |
| P10 | a locked PPU ignores `DEVQACTIVE` until `PPU_UNLK` is written |
| P11–P20 | delay *separation* in cycles, entry delay timers, input edge interrupts, both `PPU_PWCR` enables, policy writes landing mid-transition, interrupt semantics, dynamic denial, lock corners, and a systematic **writable-mask** sweep over every writable register |
| — | **reset behaviour** lives in [`ppu_reset_tb.sv`](../../tb/ppu/ppu_reset_tb.sv): both inputs that decide it are elaboration-time, so covering Table 4-13 takes four DUTs rather than four phases |
| P27 | the two §4.1.2 completion conditions that need `PPU_PWPR` written *mid-transition*, with a negative contrast for each |
| P28 | §3.4.2: `DEVQACTIVE` gates **static** departures from `ON` too, and `WARM_RST` is exempt |
| P29 | §4.1.3: an entry delay reprogrammed mid-count keeps the value it was loaded with |
| P30 | §4.1.2: acceptance events fire **per hop, at completion**, including hops with no handshake |
| `ppurst` | §4.1.6: the PCSM captures the **same** mode the PPU reports at reset, so `MEM_RET` keeps its RAM retained |
| `ppuratio` | §4.1.5: the PPU conforms at four PPU:device clock ratios from 10× faster to 6.7× **slower** |
| `ppucfg` | Chapter 7: five optional-feature parameters cleared, and the reduced build's register map matches what its `PPU_IDR` advertises |
| `ppurstf` | §4.2.1: an asynchronous `RESETn` landing anywhere in a transition recovers cleanly and never produces an illegal power sequence |
| `ppuirq` | §4.1.2 at the unit level: the collision rule the system testbench structurally cannot produce |
| `ppube` | byte-lane write strobes: the only suite that ever writes with lanes masked, so the only one that would notice `reg_wstrb` being ignored |
| `ppudeny` | the denial path at the `ppu_seq` unit level: where `DEVQDENY` can be presented, and what the sequencer does with it. Found **F10** |
| `ppudevif` | the PPU ↔ device interaction, organised by **specification statement** rather than by behaviour — §3.4.1–3.4.3, §4.1.3, Table 4-4 |
| P26 | constrained-random policy sequencing, with an asserted coverage tally — see [`TEST_MATRIX.md`](../../tb/ppu/TEST_MATRIX.md) |
| P21–P25 | the **physical effect** of every mode: full nine-signal actuation vector, gated-clock edge counts, retention vs corruption, isolation clamp, and continuous power-sequencing rules — see [§9.4](#94-the-power-intent-model) |

### 9.1 Two bugs this testbench caught

Worth recording, because both were silent:

- **`pcsm_req_valid` was never cleared.** `pchannel_controller` commits
  `cur_state` and pulses `xfer_done` on the same edge, so on the completing
  cycle "the PCSM is already where I want it" is *also* true — whichever branch
  tested that first won, and the request stayed asserted, firing the *next*
  transition's PCSM handshake early. The fix was to derive both the exit and the
  request from one expression (`pcsm_needed`), making the skew unrepresentable.
- **`revert_policy` was registered on the same edge as its own valid**, so
  `ppu_regs` sampled the value it held *before* the denial. It is combinational
  now, with only the strobe registered.

### 9.2 The expected protocol violations

`qchannel_monitor` reports **exactly three** violations across the whole run —
one in P3, two in P15 — and both phases assert the exact count rather than
ignoring it. Both are cases where the PPU specification deliberately overrides
AMBA LPI §2.1.2, *"a controller must only assert a device reset when the
interface is in the Q_STOPPED state"*:

- **P3, one violation.** Table 4-4 lets `WARM_RST_DEVREQEN = 0` skip the device
  handshake for `ON ↔ WARM_RST`, so `DEVWARMRESETn` asserts while the interface
  is still in `Q_RUN`. That is the entire point of the option: a component with
  *no* `WARM_RST` support can still be warm reset, and is not consulted.
- **P15, two violations.** Clearing `PPU_PWCR.DEVREQEN` is software opting the
  component out of the LPI contract entirely (§4.1.3), so the clock gate (R10)
  and the reset (R8) both land in `Q_RUN`.

A sanctioned protocol exception that nothing measures is indistinguishable from
a bug; one that is measured is a documented result.

### 9.3 The PPU protocol monitor

[`ppu_monitor.sv`](ppu_monitor.sv) checks nine of the PPU's own architectural
rules on **every** monitor edge of the run, not just where a directed phase
samples — which is where an ordering bug is most likely to hide. It is
deliberately blind to the sequencer: it sees only `PPUHWSTAT`, the five device
controls, the PCSM request and the Q-Channel wires, exactly what a neighbouring
block sees.

| Rule | Property | Spec |
|---|---|---|
| `U1` | `PPUHWSTAT` is one-hot at all times | §4.1.4 |
| `U2` | `PPUHWSTAT` only encodes a supported mode | Table 3-2 |
| `U3` | once settled, the five controls match the mode `PPUHWSTAT` reports | Tables 4-7/4-9/4-11 |
| `U4` | `DEVISOLATEn` asserts only once `DEVCLKEN` is LOW | §4.1.5 |
| `U5` | `DEVCLKEN` asserts only once `DEVISOLATEn` is HIGH | §4.1.5 |
| `U6` | a reset is released only once `DEVCLKEN` is HIGH | §4.1.5 |
| `U7` | `DEVPORESETn` asserts only once `DEVISOLATEn` is LOW | §4.1.5 |
| `U8` | `PCSMPSTATE` changes only while `PCSMPREQ` is LOW | AMBA LPI §2.2.2 rule 3 |
| `U9` | every mode pair has `ON` at one end, or is `OFF → MEM_RET` | §3.3.2 |
| `U10` | `PCSMPSTATE[7:4]` is always zero — the operating-mode field cannot exist here | Table 4-12 |
| `U11` | `PCSMPSTATE[15:8]` is zero unless the vector's own mode field is `FUNC_RET`/`FULL_RET`/`MEM_RET` | Table 4-12 |

Two rules are deliberately **absent**, and both for the same reason — a naive
version would fire on legal behaviour. "Any reset asserts only under isolation"
is wrong because `WARM_RST` resets a *powered* component (Table 4-9), which is
why `U7` is narrowed to `DEVPORESETn`, the only reset exclusive to the unpowered
modes. "The device must be quiesced before any control moves" is wrong because
Table 4-4 and §4.1.3 both let software switch the handshake off; `qchannel_monitor`
already flags those windows from the AMBA side and the testbench measures the
exact expected count.

`U3` is the subtle one. During a transition the controls step through the §4.1.5
sequence while `PPUHWSTAT` still reports the mode being *left*, so it can only
fire once things settle — and a plain quiet-period timer is not enough, because
`RST_HWSTAT_DLY` is software-programmable up to 255 and a legal transition can
be quiet for longer than any fixed threshold. The discriminator is which event
happened **last**: the commit is by construction the final event of a
transition, so `U3` evaluates only while the most recent change was to
`PPUHWSTAT`. That needs no knowledge of the sequencer and holds for any delay
setting.

**Proven non-vacuous** by [`ppu_monitor_negtest.sv`](../../tb/ppu/ppu_monitor_negtest.sv)
(`make ppuneg`), which drives the monitor directly through one deliberate
violation of each rule and confirms all nine fire — plus four legal sequences,
including the sanctioned `OFF → MEM_RET` hop, that must stay silent.

### 9.3.1 The clock-ratio sweep

Every other testbench runs at **one** ratio: `aon_clk` 4.3 ns against `dclk`
13.7 ns, so the PPU is ~3.2× faster than the domain it sequences. That is
realistic, and it is also an untested assumption underneath every other result.

§4.1.5 says the ratio matters in as many words — *"allowances must be made for
differences in clock frequencies between the PPU and the controlled device"* —
because every device-control delay is counted in **PPU** cycles (Table 4-5) while
the thing being spaced lives in the **device's** domain. The case the spec really
warns about, a PPU *slower* than its device, had never run.

[`ppu_clkratio_tb.sv`](../../tb/ppu/ppu_clkratio_tb.sv) (`make ppuratio`) runs the
same DUT at four ratios from one compiled image, half-periods passed as plusargs:

| `aon_clk` | `dclk` | Ratio | Result |
|---|---|---|---|
| 4.30 ns | 13.70 ns | 3.19 | PASS |
| 2.00 ns | 20.00 ns | 10.00 | PASS |
| 10.00 ns | 11.00 ns | 1.10 | PASS |
| 20.00 ns | 3.00 ns | **0.15** — PPU 6.7× slower | PASS |

It asserts **conformance**, not timing: every mode reachable, every transition
completing, the nine-signal actuation matching the mode, and both monitors at
zero. Those are the properties that must hold at any ratio, and a latent
assumption about relative clock speed would surface here as a hang or a protocol
violation rather than as a slow transition.

The same transition costs **30 PPU cycles at the slow-PPU ratio and 67 at the
fast one** — exactly right, since the device handshake costs a fixed number of
*device* cycles. Behaviour is ratio-independent; only latency moves.

One thing could not be reused from `ppu_pd_tb`: its timeouts are absolute
nanoseconds, which silently become too short the moment the PPU clock slows. A
timeout in nanoseconds is a hidden ratio assumption of precisely the kind this
file exists to remove, so every wait here — including the watchdog — is a budget
of `aon_clk` **edges**.

### 9.3.2 The reduced-configuration builds

> Three reference documents sit alongside this one:
> [REGISTERS.md](REGISTERS.md) is the programmer's reference — every register,
> its fields, valid values and usage recipes.
>
> Two reference checklists:
> [FUNCTIONS.md](FUNCTIONS.md) covers the specification surface function by
> function — modes, rules, registers, interrupts, signals, sequences — and
> [OPTIONS.md](OPTIONS.md) covers the Chapter 7 configuration parameters,
> including which values have actually been elaborated rather than merely
> declared.
>
> <!-- -->
> A full option-by-option checklist of what the specification offers against what
> this PPU builds — including which parameter values have actually been
> elaborated rather than merely declared — is in [OPTIONS.md](OPTIONS.md).

The same question the clock ratio asked, pointed at a different axis. The PPU has
seven Chapter 7 optional-feature parameters, and until `make ppucfg` **five of
them had never been elaborated to anything but `1`**:

`LOCK_SPT`, `SW_DEV_DEL_SPT`, `PWR_MODE_ENTRY_DEL_SPT`, `DYN_SPT`,
`RET_RAM_REGS`

Seventeen guards in the synthesizable RTL depend on them, and the false arm of
every one was dead code — written, reviewed, never simulated.

This matters more than "an untested branch". A reduced PPU is not a full PPU with
a feature switched off at runtime; it is a **different PPU with a different
register map**, and software discovers that map only by reading `PPU_IDR0/IDR1`.
A build that advertises a feature it lacks is broken in a way that no amount of
testing the full build can reveal.

[`ppu_minconfig_tb.sv`](../../tb/ppu/ppu_minconfig_tb.sv) runs three DUTs on one
shared register bus — everything on, everything off, and `LOCK_SPT` cleared alone
— and **every check demands that the builds disagree**. That is the non-vacuity
argument built into the structure rather than bolted on: reading zero from the
reduced build proves nothing by itself, since an undecoded address reads zero and
so does a broken bus. Reading `0xA5` from the full build through the *same*
transaction at the *same instant* proves the read worked and the difference is
the parameter.

The third DUT earns its place. In the fully reduced build, lock is unsupported
*and* dynamic transitions are unsupported — and §3.4.3 releases the lock whenever
`PWR_DYN_EN` is `0`. So "it never locks" would be true for two independent
reasons and would test neither. `u_nlk` keeps dynamic and removes only lock.

The distinction the spec draws that is easiest to get wrong:

| Parameter cleared | Registers become | Reads |
|---|---|---|
| `PWR_MODE_ENTRY_DEL_SPT` | **reserved** (§5.2.19) | `0` |
| `SW_DEV_DEL_SPT` | **read-only** (§5.2.21) | the configured values — and §7.1.4 makes those "the fixed values for the device control delays", still applied |

Treating both as reserved would read zero from `PPU_DCDR0` and, worse, could pass
a register test while running with no device-control spacing at all. So phase M6
checks the read values *and* times a real transition. Removing the write guard as
a mutation breaks exactly three checks — both register reads and the timed
transition — which is why the timing check is there.

### 9.3.3 Reset in flight

The third axis held constant. Every other PPU testbench drives `aon_rst_n`
exactly once, at time zero, and releases it before anything happens — so
`RESETn` had never landed *while the PPU was doing something*. `ppu_reset_tb`
covers reset **release** (Table 4-13, which mode the PPU comes up in) and says
nothing about assertion.

That matters because an asynchronous reset is the one event that can take the
PPU's outputs somewhere the sequencer never chose — and those outputs are a clock
enable, an isolation enable, three resets and a power-switch request. Getting the
reset *values* right is necessary but not sufficient; what matters is whether the
resulting jump is a legal move from wherever the PPU happened to be.

[`ppu_rstflight_tb.sv`](../../tb/ppu/ppu_rstflight_tb.sv) (`make ppurstf`)
asserts `RESETn` 1–60 cycles into a transition, for three destinations — 180
iterations — with all three checkers watching **across** the reset. Results:

| Property | Result |
|---|---|
| Recovered to the Table 4-13 mode | 180/180 |
| PPU and PCSM agreed on the domain afterwards | 180/180 |
| Recovery to `ON` actually powered, unisolated and unreset the domain | 180/180 |
| Still transitioned normally afterwards | 180/180 |
| `ppu_monitor` device-control violations | **0** |
| `ppu_power_model` power-ordering violations | **0** |

The Q-Channel violations are **classified, not muted**. Muting them would discard
the only checker that knows this scenario is dangerous, so the counter is sampled
around each reset and each recovery and the delta checked against the channel
state: a reset taken in `Q_STOPPED` must be silent (142 cases), a reset into a
live handshake must be noticed (38 cases), and *after recovery normal running must
be completely clean* (180 cases). That last one is the sharpest check in the file
— a Q-Channel that has just had a handshake torn up underneath it runs a full
round trip with the monitor silent.

That **R8 fires alongside R9** is the topology and is correct: both channel ends
share `aon_rst_n` by design, which is the AMBA LPI-legal way to interrupt a
handshake. A build where only R9 fired would be the broken one — a controller
that forgot a request the device is still waiting on.

### 9.4 The power-intent model

Phases P21–P25 use [`ppu_power_model.sv`](../../tb/ppu/ppu_power_model.sv), a
behavioural stand-in for [`src/upf/ppu_pd_top.upf`](../../upf/ppu_pd_top.upf).
It exists because Icarus has no notion of power intent, and without it the three
low-power modes are indistinguishable — all hold the workload in reset, so all
read back reset values.

It models `create_power_switch`, `-simstate CORRUPT`, `set_isolation` and
`set_retention` behaviourally, and adds eight continuous sequencing rules
(`PU1`–`PU8`) that are the power-aware counterpart of `qchannel_monitor`'s
`R`-rules. That turns "the PPU drives the right control signals in the right
order" into "the domain actually loses and regains power correctly".

It caught **F1** ([`CONFORMANCE.md`](CONFORMANCE.md) §3.4) on its first run, and
it demonstrates the `dummy_workload.cnt` missing-reset finding that
`src/upf/README.md` predicted. Its own three modelling traps — an undeclared
implicit wire, a delta-cycle glitch, and the difference between releasing a
force and restoring a value — are written up in
[`TEST_MATRIX.md`](../../tb/ppu/TEST_MATRIX.md), because each produced a
confusing failure rather than an obvious one.

It is a stand-in, not a substitute: it reaches only what a testbench can force,
and cannot check the UPF file itself. `make ppupa` remains the authority.

### 9.3 What this cannot show

`FULL_RET`, `MEM_RET` and `OFF` all reduce the domain to "not running", and
Icarus has no notion of power intent — it cannot distinguish a domain that lost
its supply from one held in reset, because in this design they produce the same
values. Every check above is about **control-signal sequencing and register
behaviour**, which is what the PPU is responsible for.

Separating the three needs a UPF-aware simulator and
[`src/upf/ppu_pd_top.upf`](../../upf/ppu_pd_top.upf); `make ppupa` runs it, and
fails cleanly with a pointer if no such simulator is installed.

---

## 10. Design decisions worth knowing about

### `DEVQACTIVE` is the PPU's to act on, not the Q-Channel controller's

`qchannel_controller` can be told to leave `Q_STOPPED` by itself when `QACTIVE`
rises — its `enb_qactive_led_quiescence_exit` input, the Figure 2-8 policy that
both other integrations in this repository use. [`ppu_top`](ppu_top.sv) ties it
**LOW** and routes `DEVQACTIVE` into the sequencer instead.

The reason is a protocol violation waiting to happen. In a PPU the domain behind
the Q-Channel may be genuinely unpowered, and AMBA LPI §2.1.2 only permits power
to be absent in `Q_STOPPED`. A controller that un-quiesced on its own would take
the interface out of `Q_STOPPED` while the supply was still off and the PCSM had
not been asked for anything. Routing `DEVQACTIVE` into the policy makes it a
wake **request**: the sequencer restores the PCSM state and the device controls
first, and only then releases quiescence.

That is what §3.4.3 means by a dynamic transition, and it is the same sequencing
obligation [`src/upf/README.md`](../../upf/README.md) identifies as needing a
PPU to discharge.

### The device wrapper is not held in the domain's reset

Following directly from the above, [`ppu_pd_top`](ppu_pd_top.sv) gives the
Q-Channel device wrapper `aon_rst_n` resynchronised into `dclk`, rather than the
PPU's device resets. The interface therefore stays alive while the domain is
down, and a wake genuinely revives it — P7 measures exactly that.

`qchannel_pd_top` cannot do this: its wrapper shares `drst_n` with the workload,
so `DEVQACTIVE` is pinned LOW while the domain is down and its `wake` port is
inert. The UPF README records why the fix could not be applied there in
isolation, and that *"the two belong in one change"*. This is that change.

### The PPU synchronises signals the controller already synchronises

`qchannel_controller` has its own synchronisers on `DEVQACCEPTn`, `DEVQDENY` and
`DEVQACTIVE`, but keeps the results private. Three consumers here need them:
`PPU_DISR`/`PPU_MISR`, `ppu_irq`'s edge detector, and `ppu_seq`.

A second synchroniser on the same wire is the right answer rather than a
duplication to apologise for — independent synchronisers are how multi-consumer
CDC is normally built, and the alternative is modifying a verified block that
two other top levels instantiate, to save a handful of flops. The one thing that
genuinely cannot be re-derived is the Q-Channel's `Q_RUN` state, which `ppu_top`
decodes from the wires with `qch_decode`.

---

## 11. Known gaps

> **2026-10-06:** the next two items are partly history. `ppu_pcsm` now has
> `RET_SETTLE` / `LOGIC_SETTLE` counters (forwarded as `PCSM_*_SETTLE`) and is
> built with `PGOOD_EN = 0`, with no switch acknowledge port, by decision
> (see `ppu_dom_top.sv`, "SWITCH SETTLING"). `dummy_workload` was replaced by
> `ppu_device_ip`, whose eight SRAM banks take `ram_sleep` / `ram_sd` on their
> pins, so `MEM_OFF` and the retention RAM registers now have an observable
> effect.

**No power-good acknowledge.** The PPU architecture has no such input (§6.5
lists none), so the obligation sits on the PCSM: a real one must not assert
`PCSMPACCEPT` until its rails have settled. [`ppu_pcsm`](ppu_pcsm.sv) states
this explicitly and stands in for it with the handshake latency it does have.
Adding a real acknowledge changes the PCSM and the UPF — notably *not* the PPU,
which already waits for `PCSMPACCEPT` before doing anything else.

**No RAM in the domain.** Table 3-1 gives every mode a RAM column independent of
its Logic column, and `ppu_pcsm` decodes both — including the IMPLEMENTATION
DEFINED per-bank configuration that `PPU_FUNRR`/`FULRR`/`MEMRR` drive through
`PCSMPSTATE[15:8]`. Nothing consumes them, because `dummy_workload` is flops.
That is a property of the workload, not a gap in the PPU: `MEM_OFF` exists
solely to express "logic on, RAM off" and currently has no observable effect
below the PCSM for exactly this reason.

**Two power control schemes now coexist.** `qchannel_pd_top` still sequences its
domain with hand-written `clk_gate` + `qchannel_devrst_ctrl` logic;
this domain uses the PPU. Building standalone was the deliberate choice (§2.3) —
it avoids coupling the PPU's design to that top level's existing interlock
behaviour — but retiring the ad hoc path would need a follow-up that retrofits
`qchannel_pd_top` onto `ppu_top`.

**No negative test for the PPU's own behaviour.** The Q-Channel protocol is
checked by a monitor that has its own negative test
(`pchannel_monitor_negtest`); the PPU's sequencing rules are checked only by the
directed phases above. A `ppu_monitor` asserting the §4.1.5 ordering
independently of the stimulus would be the natural next step, and would let the
ordering checks in P2 stop being timestamp comparisons in the testbench.

---

## 12. Running

```sh
make ppu       # run the PPU power-domain testbench (477 checks)
make ppuneg    # run the monitor's negative test
make ppurst    # run the reset-behaviour testbench (Table 4-13, four configs)
make ppuratio  # run the same PPU at four PPU:device clock ratios
make ppucfg    # run reduced-configuration builds (Chapter 7 options)
make ppudemo   # guided tour: every feature once, built to WATCH on a waveform
make ppurstf   # assert RESETn mid-transition, swept across the sequence
make ppuirq    # ppu_irq unit test (cycle-exact Section 4.1.2 rules)
make ppube     # byte-lane write strobes -- every write masks some lane
make ppudeny   # the denial path, at the ppu_seq unit level
make ppudevif  # PPU <-> device interaction, one group per spec statement
make ppuall    # every PPU suite above

make ppucheck  # synthesis-readiness gate that runs HERE:
               #   ppuvlint - Verilator -Wall over the synthesizable RTL

# The constrained-random phase is reproducible and soakable:
cd ../build && vvp ppu_pd_tb +seed=999      # replay a seed
cd ../build && vvp ppu_pd_tb +iters=500     # long soak
make ppulint   # compile-only elaboration check
make wave-ppu  # run and open the waveform in GTKWave
make ppupa     # power-aware run (needs Xcelium/VCS/Questa; see src/upf/README.md)
```

2026-10-06: `ppuupf`, `ppusrc`, `ppulatch` (and `ppudecl`, `ppuspec`) were
retired on 2026-10-05 with `src/lint`, and `ppusynth` on 2026-10-06 with the
Vivado flow and `src/constraints`. Static sign-off is now `make vclp vccdc
vcrdc vclint vcformal` (`src/signoff/SIGNOFF_REPORT.md`).

The waveform carries the current phase name as ASCII in the `test_phase` signal
— set that trace's Data Format to ASCII in GTKWave.
