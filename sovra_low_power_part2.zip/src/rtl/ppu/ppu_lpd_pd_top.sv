`timescale 1ns/1ps
// One PPU, one LPD-Q, N devices -- a power domain with more than one thing in it.
//
// Reference: Arm PCSA (DEN 0050 D) Section 6.5.3; Arm CoreLink PCK-600 TRM
// (101150 r0p5) Section 3.1; Arm PPU Architecture Specification v1.1
// (ARM DEN 0051E) Sections 4.1.3 and 4.1.5.
//
// WHY THIS EXISTS
//
// qchannel_lpd is verified against PCK-600 Section 3.1 in isolation, by
// qchannel_lpd_tb, and until this file existed that was the whole story: it had
// never been driven by a real ppu_top, and no domain had ever actually lost
// power with one in the path.
//
// Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Section 5.2 rests on a claim this
// module is here to make true rather than argue -- that an LPD-Q gives a
// multi-device domain WITHOUT touching ppu_seq. ppu_top below is instantiated
// at its ordinary single-channel configuration. Nothing about it knows there is
// more than one device.
//
//        ppu_top                 qchannel_lpd                 N devices
//    DEVQREQn    ------------> ctrl_qreqn_i   dev_qreqn_o[0] -----> u_dev[0] -> u_ip[0]
//    DEVQACCEPTn <------------ ctrl_qacceptn_o dev_qreqn_o[1] -----> u_dev[1] -> u_ip[1]
//    DEVQDENY    <------------ ctrl_qdeny_o             ...
//    DEVQACTIVE  <------------ ctrl_qactive_o dev_qreqn_o[N-1] ---> u_dev[N-1] -> u_ip[N-1]
//
// SEQUENCER selects which of PCK-600's two modes is under test:
//   0  expander  -- all N asked together, any completion order
//   1  sequencer -- asked one at a time, each completing before the next
//
// -----------------------------------------------------------------------------
// WHAT IS SHARED AND WHAT IS PER-DEVICE
//
// Shared, because they are properties of the DOMAIN rather than of a device:
// the gated clock, both device resets, the PCSM and its rails, isolation.
// Per-device: the Q-Channel, the workload, and the RAM banks.
//
// That split is the point. The PPU still sequences ONE domain -- DEVCLKEN,
// DEVISOLATEn and the three resets are single wires exactly as in ppu_pd_top.
// The only thing that fanned out is quiescence, and that is the LPD-Q's job.
//
// -----------------------------------------------------------------------------
// THE PARAMETER LIST IS DELIBERATELY SHORT
//
// ppu_pd_top forwards about forty parameters so that every `0` behaviour the
// specification defines stays reachable from a testbench. This module forwards
// only what its own tests vary and leaves the rest at ppu_top's defaults,
// because it is an INTEGRATION vehicle for the LPD-Q rather than a second
// general-purpose domain wrapper. ppu_pd_top remains the one to reach for when
// the PPU itself is what is being configured.

import ppu_pkg::*;

module ppu_lpd_pd_top #(
  // 2-32, per PCK-600 Table 3-1. qchannel_lpd checks the bound itself.
  parameter int unsigned NUM_DEV       = 3,
  parameter bit          SEQUENCER     = 1'b0,
  parameter bit          ACTIVE_DENY   = 1'b0,
  parameter int unsigned SYNC_STAGES   = 2,
  parameter int unsigned CNT_W         = 8,
  parameter logic [3:0]  DEF_PWR_POLICY = PM_ON,
  parameter logic [3:0]  PCSM_RESET_MODESTAT = PM_OFF,
  // 1 = the PCSM waits for the UPF switch acknowledges. See ppu_pcsm.
  parameter bit          PGOOD_EN            = 1'b0
) (
  // ---- Always-on ----
  input  logic aon_clk,
  input  logic aon_rst_n,        // async assert, ACTIVE LOW

  // ---- Section 6.2 software interface ----
  input  logic [11:0] reg_waddr,
  input  logic [31:0] reg_wdata,
  input  logic        reg_wen,
  input  logic [3:0]  reg_wstrb,
  input  logic [11:0] reg_raddr,
  input  logic        reg_ren,
  output logic [31:0] reg_rdata,
  output logic        irq,

  // ---- Domain clock ----
  input  logic dclk,

  // ---- Per-device stimulus ----
  input  logic [NUM_DEV-1:0]             start,
  input  logic [CNT_W-1:0]               work_len,
  input  logic [NUM_DEV-1:0]             light_work,
  input  logic [NUM_DEV-1:0]             wake,
  input  logic [NUM_DEV-1:0]             deny_enb,
  input  logic [1:0]                     ip_cmd,
  input  logic [7:0]                     ip_seed,

  // ---- Observability, for the testbench ----
  output logic [NUM_DEV-1:0] dev_qreqn_o,
  output logic [NUM_DEV-1:0] dev_qacceptn_o,
  output logic [NUM_DEV-1:0] dev_qdeny_o,
  output logic [NUM_DEV-1:0] dev_qactive_o,
  output logic               lpd_clk_qactive
);

  // ---------------------------------------------------------------------------
  // PPU <-> LPD-Q, and LPD-Q <-> devices
  // ---------------------------------------------------------------------------
  logic dev_qreqn, dev_qacceptn, dev_qdeny, dev_qactive;

  logic dev_clken, dev_isolaten, dev_poresetn, dev_warmresetn, dev_retresetn;
  logic pcsm_preq, pcsm_paccept;
  logic [15:0] pcsm_pstate;
  logic [7:0]  pcsm_modestat;

  logic logic_on, logic_ret, ram_on, ram_ret, ret_n;
  logic [7:0] ram_cfg, ram_sleep, ram_sd;
  logic [3:0] pcsm_mode;

  logic dummy_clk, dev_clken_dclk;
  logic wl_rst_n, wl_ret_rst_n, wrap_rst_n;

  // ---- The PPU, at its ordinary single-channel configuration ----
  ppu_top #(
    .DEF_PWR_POLICY     (DEF_PWR_POLICY),
    .SYNC_STAGES        (SYNC_STAGES),
    .PCSM_RESET_MODESTAT(PCSM_RESET_MODESTAT)
  ) u_ppu (
    .clk      (aon_clk),
    .rst_n    (aon_rst_n),

    .reg_waddr(reg_waddr),
    .reg_wdata(reg_wdata),
    .reg_wen  (reg_wen),
    .reg_wstrb(reg_wstrb),
    .reg_raddr(reg_raddr),
    .reg_ren  (reg_ren),
    .reg_rdata(reg_rdata),
    .irq      (irq),

    // ---- The single device Q-Channel. It goes to the LPD-Q, not a device. ----
    .dev_qreqn   (dev_qreqn),
    .dev_qacceptn(dev_qacceptn),
    .dev_qdeny   (dev_qdeny),
    .dev_qactive (dev_qactive),

    .dev_clken     (dev_clken),
    .dev_isolaten  (dev_isolaten),
    .dev_poresetn  (dev_poresetn),
    .dev_warmresetn(dev_warmresetn),
    .dev_retresetn (dev_retresetn),

    .pcsm_pstate  (pcsm_pstate),
    .pcsm_preq    (pcsm_preq),
    .pcsm_paccept (pcsm_paccept),
    .pcsm_modestat(pcsm_modestat),

    // ---- The PPU's own clock Q-Channel is not under test here ----
    .ppuclk_qreqn   (1'b1),
    .ppuclk_qacceptn(),
    .ppuclk_qdeny   (),
    .ppuclk_qactive (),
    .pwakeup        (1'b0),
    .ppuhwstat      ()
  );

  // ---- The distributor ----
  // CTRL_Q_CH_SYNC is 0: both ends of this Q-Channel are in aon_clk, because
  // u_ppu and u_lpd are wired to the same clock here. The DEVICE side keeps its
  // synchronizers -- those channels do cross into dclk.
  qchannel_lpd #(
    .NUM_QCHL        (NUM_DEV),
    .SEQUENCER       (SEQUENCER),
    .CTRL_Q_CH_SYNC  (1'b0),
    .DEV_Q_CH_SYNC   (1'b1),
    .ACTIVE_DENY     (ACTIVE_DENY),
    .DEV_QACTIVE_SYNC(ACTIVE_DENY),
    .SYNC_STAGES     (SYNC_STAGES)
  ) u_lpd (
    .clk            (aon_clk),
    .reset_n        (aon_rst_n),
    .ctrl_qreqn_i   (dev_qreqn),
    .ctrl_qacceptn_o(dev_qacceptn),
    .ctrl_qdeny_o   (dev_qdeny),
    .ctrl_qactive_o (dev_qactive),
    .dev_qreqn_o    (dev_qreqn_o),
    .dev_qacceptn_i (dev_qacceptn_o),
    .dev_qdeny_i    (dev_qdeny_o),
    .dev_qactive_i  (dev_qactive_o),
    .clk_qactive_o  (lpd_clk_qactive),
    .dftcgen        (1'b0)
  );

  // ---- The PCSM ----

  // ---------------------------------------------------------------------------
  // Switch acknowledges
  // ---------------------------------------------------------------------------
  // With PGOOD_EN, these are OUTPUTS OF THE UPF POWER SWITCHES -- the -ack_port
  // of create_power_switch -- and have no RTL driver at all. That is the whole
  // point: the settling delay lives with the switch that causes it, in the same
  // model synthesis and power-aware sign-off consume, rather than in a
  // testbench pin that evaporates outside simulation.
  //
  // Without it they are tied to the controls, so the acknowledge is immediate
  // and the timing is exactly what it was before these ports existed. That is
  // the default, which is why every existing testbench is unaffected.
  logic pg_logic, pg_ret;

  generate
    if (!PGOOD_EN) begin : g_pgood_tie
      assign pg_logic = logic_on;
      assign pg_ret   = logic_ret;
    end
    // PGOOD_EN: deliberately no driver here. UPF supplies one.
  endgenerate

  ppu_pcsm #(
    .SYNC_STAGES   (0),      // both ends in aon_clk -- see ppu_pd_top
    .TINIT         (4),
    .RESET_MODESTAT(PCSM_RESET_MODESTAT),
    .PGOOD_EN      (PGOOD_EN)
  ) u_pcsm (
    .clk   (aon_clk),
    .rst_n (aon_rst_n),
    .pcsm_pstate (pcsm_pstate),
    .pcsm_preq   (pcsm_preq),
    .pcsm_paccept(pcsm_paccept),

    .ack_logic_on (pg_logic),
    .ack_logic_ret(pg_ret),
    .logic_on  (logic_on),
    .logic_ret (logic_ret),
    .ram_on    (ram_on),
    .ram_ret   (ram_ret),
    .ram_cfg   (ram_cfg),
    .pcsm_mode (pcsm_mode),
    .ram_sleep (ram_sleep),
    .ram_sd    (ram_sd),
    .ret_n     (ret_n),
    .pcsm_modestat(pcsm_modestat)
  );

  // ---------------------------------------------------------------------------
  // Domain-wide clock and reset -- ONE of each, for all N devices
  // ---------------------------------------------------------------------------
  rst_sync u_wrap_rst (
    .clk(dclk), .rst_in_n(aon_rst_n), .rst_out_n(wrap_rst_n)
  );

  cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_clken_sync (.clk(dclk), .rst_n(wrap_rst_n), .d(dev_clken), .q(dev_clken_dclk));

  clk_gate u_clkctrl (
    .clk(dclk), .clk_en(dev_clken_dclk), .gated_clk(dummy_clk)
  );

  logic dev_rst_in_n, dev_ret_rst_in_n;
  assign dev_rst_in_n     = dev_poresetn & dev_warmresetn;
  assign dev_ret_rst_in_n = dev_poresetn & dev_retresetn;

  rst_sync u_wl_rst  (.clk(dclk), .rst_in_n(dev_rst_in_n),     .rst_out_n(wl_rst_n));
  rst_sync u_ret_rst (.clk(dclk), .rst_in_n(dev_ret_rst_in_n), .rst_out_n(wl_ret_rst_n));

  // ---------------------------------------------------------------------------
  // N devices, each with its own Q-Channel and its own workload
  // ---------------------------------------------------------------------------
  // The instance names are g_dev[i].u_dev and g_dev[i].u_ip, and the UPF names
  // them element by element -- see upf/ppu_lpd_pd_top.upf. A generate loop is
  // used rather than N hand-written instances so NUM_DEV stays a parameter, at
  // the cost of the UPF having to spell the indices out.
  logic [NUM_DEV-1:0] busy;

  generate
    for (genvar i = 0; i < NUM_DEV; i++) begin : g_dev
      qchannel_device #(.SYNC_STAGES(SYNC_STAGES)) u_dev (
        .clk     (dclk),
        .rst_n   (wrap_rst_n),
        .qreqn   (dev_qreqn_o[i]),
        .qacceptn(dev_qacceptn_o[i]),
        .qdeny   (dev_qdeny_o[i]),
        .qactive (dev_qactive_o[i]),
        .dev_quiescent_busy(busy[i]),
        .dev_quiescent_deny(deny_enb[i] && busy[i]),
        .dev_wake          (wake[i]),
        .dev_quiescent_ok  ()
      );

      ppu_device_ip #(.CNT_W(CNT_W)) u_ip (
        .clk       (dummy_clk),
        .nret_rst_n(wl_rst_n),
        .ret_rst_n (wl_ret_rst_n),
        .start     (start[i]),
        .work_len  (work_len),
        .light_work(light_work[i]),
        .busy      (busy[i]),
        .done      (),
        .ip_cmd    (ip_cmd),
        .ip_seed   (ip_seed),
        .bank_sleep(ram_sleep),
        .bank_sd   (ram_sd)
      );
    end
  endgenerate

  // Kept for readability at the instantiation site and for UPF supply-set
  // expressions; no RTL below consumes them.
  wire _unused_ok = &{1'b0, logic_on, logic_ret, ram_on, ram_ret,
                      ram_cfg, pcsm_mode, ret_n, 1'b0};

endmodule
