`timescale 1ns/1ps
//=============================================================================
// ppu_ip_sram -- behavioural model of one SRAM bank with retention and
//                shutdown pins
//
// WHY THE POWER CONTROL IS PINS AND NOT UPF
//
// A compiled SRAM macro does not get its array power from the standard-cell
// rail, and it is not power-gated by a UPF switch. It carries its own control
// pins -- names vary by vendor (SLEEP/RET1N/PWRGATE, SD/SHUTDOWN/NAP) -- and
// the memory compiler's model implements what they do:
//
//   sleep    = 1   the array holds its contents but CANNOT be read or written.
//                  Periphery is off; only the bit cells stay biased.
//   shutdown = 1   the array loses power. Contents are gone, and they do not
//                  come back when power returns.
//   both = 0       normal synchronous read/write.
//
// So this module's power behaviour lives in RTL, and upf/ppu_pd_top.upf
// deliberately leaves the RAM out of PD_DEV entirely -- it stays on the
// always-on rail, where -simstate CORRUPT cannot reach it, and these two pins
// are the only thing that decides whether data survives. Putting the array in
// the switched domain instead would corrupt it in MEM_RET, which is the one
// mode whose entire definition ("Logic OFF, RAM RET", Table 3-1) is that it
// does not.
//
// WHAT DRIVES THE PINS
//
// The PCSM's decode of PCSMPSTATE, per bank (ppu_device_ip):
//
//   sleep_i    = ram_ret && ram_cfg[i]
//   shutdown_i = !ram_on && !(ram_ret && ram_cfg[i])
//
// ram_cfg is PCSMPSTATE[15:8], which the PPU drives from PPU_FUNRR/PPU_FULRR/
// PPU_MEMRR. The specification calls that field IMPLEMENTATION DEFINED; this
// design defines it as one retention enable per bank, so a bank whose bit is
// clear is shut down even in a RAM-retaining mode and loses its contents.
//
// ACCESS IS BLOCKED, NOT MERELY IGNORED
//
// "ce && accessible" rather than "ce" matters for more than realism. The
// address, write-enable and write-data all originate in PD_DEV and cross into
// this always-on macro, so they are off-to-on crossings; while the domain is
// unpowered they are X until the isolation cells clamp them. Gating every
// access on the macro's own pins means a corrupted write-enable can never
// reach the array -- which is true of real macros too, and is why an unpowered
// domain cannot scribble on a retained memory.
//=============================================================================

module ppu_ip_sram #(
  parameter int unsigned AW = 4,          // 16 words
  parameter int unsigned DW = 32
) (
  input  logic          clk,
  input  logic          sleep,            // retention: hold contents, no access
  input  logic          shutdown,         // power removed: contents lost
  input  logic          ce,
  input  logic          we,
  input  logic [AW-1:0] addr,
  input  logic [DW-1:0] wdata,
  output logic [DW-1:0] rdata
);

  localparam int unsigned DEPTH = 1 << AW;

  logic [DW-1:0] mem [0:DEPTH-1];

  // Readable and writable only when both pins are deasserted.
  wire accessible = (sleep === 1'b0) && (shutdown === 1'b0);

  // ---- Losing power ----
  // Modelled on the ASSERTION of shutdown rather than on its level, because
  // that is when the data goes: the array is destroyed once, and re-powering
  // does not restore it. A level-sensitive clear would keep re-clearing and
  // hide a write that arrived while shutdown was still high -- which should be
  // impossible, and this way stays impossible for a reason the model states
  // rather than one it assumes.
  //
  // "posedge" also catches x->1, which is what happens if the PCSM's decode is
  // ever undriven; corrupting on an unknown shutdown is the safe direction.
  always @(posedge shutdown) begin
    for (int i = 0; i < DEPTH; i++) mem[i] <= 'x;
  end

  // ---- Normal operation ----
  // Synchronous read, no write-through: a read in the same cycle as a write to
  // the same address returns X rather than either value, so a testbench cannot
  // accidentally depend on behaviour a real macro does not guarantee.
  //
  // A plain always, not always_ff: mem has two writers, this block and the
  // shutdown block above, and IEEE 1800 Section 9.2.2.4 forbids any other
  // process writing a variable an always_ff writes. Xcelium let it pass; VCS
  // rejects it (Error-[ICPD]). The behaviour is identical either way -- the
  // keyword only adds the check -- and this is a model of a compiled macro, so
  // nothing synthesizes from it.
  always @(posedge clk) begin
    if (ce && accessible) begin
      if (we) mem[addr] <= wdata;
      rdata <= we ? {DW{1'bx}} : mem[addr];
    end else begin
      // Inaccessible, or not selected. A retained bank reads X -- the contents
      // are intact but the periphery that would fetch them is not powered.
      rdata <= {DW{1'bx}};
    end
  end

endmodule
