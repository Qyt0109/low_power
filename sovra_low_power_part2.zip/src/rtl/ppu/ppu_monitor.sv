`timescale 1ns/1ps
// PPU protocol monitor -- checks the PPU's own architectural rules on the wires,
// independently of the stimulus that produced them.
//
// Reference: Arm Power Policy Unit Architecture Specification v1.1
// (ARM DEN 0051E), Sections 3.3.2, 4.1.4 and 4.1.5.
//
// This is the PPU-level counterpart of qchannel_monitor and pchannel_monitor,
// and it exists for the same reason: the directed phases in ppu_pd_tb check
// ordering by comparing timestamps and cycle counts at the specific moments a
// phase remembered to look. A monitor checks the same properties on EVERY edge
// of the whole run, including in phases written to exercise something else
// entirely -- which is where an ordering bug is most likely to hide.
//
// It is deliberately BLIND to the sequencer. It sees only what a neighbouring
// block sees: PPUHWSTAT, the five device controls, the PCSM request, and the
// device Q-Channel wires. It never predicts what the PPU should do next; it
// only rejects orderings the specification forbids.
//
// -----------------------------------------------------------------------------
// RULES
//
//   U1  PPUHWSTAT is one-hot at all times (Section 4.1.4: "The PPUHWSTAT field
//       is one-hot encoded to simplify its use in hardware qualification").
//   U2  PPUHWSTAT only ever encodes a mode this PPU supports.
//   U3  Once settled, the five device controls match the mode PPUHWSTAT reports
//       (Tables 4-7/4-9/4-11).
//   U4  DEVISOLATEn may only assert once DEVCLKEN is already LOW
//       (Section 4.1.5 departure order: clock enables, then isolation).
//   U5  DEVCLKEN may only assert once DEVISOLATEn is already HIGH
//       (Section 4.1.5 return order: isolation, then clock enables).
//   U6  A reset may only be RELEASED once DEVCLKEN is already HIGH
//       (Section 4.1.5 return order: clock enables, then resets).
//   U7  DEVPORESETn may only assert once DEVISOLATEn is already LOW
//       (Section 4.1.5 departure order: isolation, then resets).
//   U8  PCSMPSTATE may only change while PCSMPREQ is LOW (AMBA LPI Section
//       2.2.2 rule 3, which the PPU owes the PCSM as the P-Channel master).
//   U9  PPUHWSTAT only moves between legal mode pairs: one end is ON, or it is
//       the OFF -> MEM_RET direct hop (Section 3.3.2).
//   U10 PCSMPSTATE[7:4] is always zero. Table 4-12: "If the PPU is configured as
//       a Q-Channel PPU, or operating modes are not supported, this field is
//       reserved and is always set to 0b0000." Both conditions hold here.
//   U12 PPUHWSTAT does not change while the device Q-Channel is in Q_EXIT --
//       Table 4-5 makes the HWSTAT update dependent on completion of the device
//       interface, not only on RST_HWSTAT_DLY.
//   U11 PCSMPSTATE[15:8] is zero unless PCSMPSTATE[3:0] is one of the three
//       modes with a retention configuration register. Table 4-12 lists
//       FUNC_RET, FULL_RET and MEM_RET as carrying a RAM retain value and adds
//       "For all other transitions these bits are set to 0b00000000". The three
//       that DO carry one are software-programmable, so the monitor cannot
//       predict their value and does not try.
//
//       Note this is checked WITHIN the PCSMPSTATE vector -- the retain field
//       against the mode field beside it -- and not against PPUHWSTAT. The first
//       version of this rule compared it to the settled mode and was WRONG:
//       PCSMPSTATE carries the mode being REQUESTED, which legitimately leads
//       the committed one, and Table 4-12 describes the field per transition
//       rather than per settled mode. On the OFF -> MEM_RET direct path nothing
//       else moves either, so no device-control change invalidated the settle
//       and the rule fired on correct hardware. Comparing the vector against
//       itself needs no settle condition at all.
//
// -----------------------------------------------------------------------------
// TWO RULES THAT ARE NOT HERE, AND WHY
//
// "Any reset may only assert once isolation is active" is the natural mirror of
// U6, and it is WRONG as a general rule -- U7 is deliberately narrowed to
// DEVPORESETn because of it. WARM_RST asserts DEVWARMRESETn and DEVRETRESETn
// with the domain fully powered, the clock running and isolation released
// (Table 4-9); a component being warm reset is not being powered down. Only
// DEVPORESETn is exclusive to the unpowered modes, so only DEVPORESETn can
// carry that ordering rule.
//
// "The device interface must be quiesced before any control moves" is likewise
// not checkable here, because Table 4-4 and Section 4.1.3 both let software
// switch the handshake off -- PPU_PTCR.WARM_RST_DEVREQEN and
// PPU_PWCR.DEVREQEN. qchannel_monitor's R8/R10 already flag those windows from
// the AMBA side, and ppu_pd_tb measures the exact expected count rather than
// muting them.
//
// -----------------------------------------------------------------------------
// WHY U3 NEEDS A SETTLE CONDITION, AND WHY "LAST EVENT" IS PART OF IT
//
// During a transition the controls step through the Section 4.1.5 sequence
// while PPUHWSTAT still reports the mode being LEFT -- Section 4.1.4 and
// Table 4-5 make the HWSTAT update the last thing that happens on the way up.
// So the controls legitimately disagree with PPUHWSTAT for most of a
// transition, and U3 can only fire once the dust has settled.
//
// A plain quiet-period timer is not enough. On the return path the controls
// reach their final values and then NOTHING changes for RST_HWSTAT_DLY + 1
// cycles plus however long the device handshake takes, and that field is
// software-programmable up to 255 -- so any fixed quiet threshold can be
// exceeded by a legal transition, and the monitor would report a violation
// against a mode the PPU has not claimed to be in yet.
//
// The discriminator is which event happened LAST. The commit -- the PPUHWSTAT
// update -- is by construction the final event of a transition. So U3 checks
// only while the most recent change was to PPUHWSTAT, never while it was to a
// control. That is robust to any delay setting, and it needs no knowledge of
// the sequencer's state.

import ppu_pkg::*;
import qchannel_pkg::*;

module ppu_monitor #(
  // Quiet period, in MONITOR clocks, before U3 evaluates. This only debounces
  // the one-cycle skew between a commit and the controls that accompany it; the
  // ordering guarantee comes from the last-event test described above, not from
  // this number.
  parameter int unsigned SETTLE_CYCLES = 16,
  // Which modes may legally appear in PPUHWSTAT, from the build's Table 7-1
  // parameters. Default is this repository's own configuration.
  parameter logic [15:0] STA_MASK = 16'h03E5
) (
  input  logic clk,        // monitor's own clock, typically faster than the PPU
  input  logic rst_n,      // monitor's operating reset

  // The PPU's reset. Checks are suspended while it is asserted: the PPU's
  // outputs are then reset values rather than the result of a transition.
  input  logic ppu_rst_n,

  // ---- PPU outputs, exactly as a neighbouring block would see them ----
  input  logic [15:0] ppuhwstat,
  input  logic        dev_clken,
  input  logic        dev_isolaten,
  input  logic        dev_poresetn,
  input  logic        dev_warmresetn,
  input  logic        dev_retresetn,
  input  logic [15:0] pcsm_pstate,
  input  logic        pcsm_preq,

  // ---- Device Q-Channel wires, used only to tell "mid-handshake" from "idle" ----
  input  logic dev_qreqn,
  input  logic dev_qacceptn,
  input  logic dev_qdeny,

  output int unsigned violations
);

  int unsigned viol;
  assign violations = viol;

  task automatic flag(input string rule, input string msg);
    begin
      viol = viol + 1;
      $display("[%0t] PPU-VIOLATION %s: %s  {hwstat=%04h dev_clken=%0b dev_iso_n=%0b dev_pore_n=%0b dev_warm_n=%0b dev_ret_n=%0b}",
               $time, rule, msg, ppuhwstat, dev_clken, dev_isolaten,
               dev_poresetn, dev_warmresetn, dev_retresetn);
    end
  endtask

  // ---------------------------------------------------------------------------
  // Decode the mode PPUHWSTAT claims, and what that mode implies
  // ---------------------------------------------------------------------------
  logic [3:0] hw_mode;
  logic       hw_valid;

  always_comb begin
    hw_mode  = 4'd0;
    hw_valid = 1'b0;
    for (int unsigned i = 0; i < 16; i++) begin
      if (ppuhwstat[i]) begin
        hw_mode  = i[3:0];
        hw_valid = ppu_mode_spt(STA_MASK, i[3:0]);
      end
    end
  end

  wire [4:0] dc_exp = ppu_devctl(hw_mode);
  wire [4:0] dc_act = {dev_poresetn, dev_warmresetn, dev_retresetn,
                       dev_clken, dev_isolaten};

  // The interface is "idle" in the two states that are not mid-handshake.
  wire qch_state_e q_state = qch_decode(dev_qreqn, dev_qacceptn, dev_qdeny);
  wire q_idle = (q_state == Q_RUN) || (q_state == Q_STOPPED);

  // ---------------------------------------------------------------------------
  // Change detection and the settle condition
  // ---------------------------------------------------------------------------
  logic [15:0] hwstat_d, pcsm_pstate_d;
  logic        clken_d, iso_d, pore_d, warm_d, retn_d;
  logic        last_event_hwstat;
  int unsigned quiet;
  logic        u3_done;

  wire ctrl_changed = (dev_clken      !== clken_d)
                   || (dev_isolaten   !== iso_d)
                   || (dev_poresetn   !== pore_d)
                   || (dev_warmresetn !== warm_d)
                   || (dev_retresetn  !== retn_d);
  wire hwstat_changed = (ppuhwstat !== hwstat_d);

  // Plain `always`, not `always_ff`: the block reports through $display with
  // string arguments, which no synthesis tool would accept inside an always_ff,
  // and a monitor is verification collateral rather than RTL. Same convention as
  // qchannel_monitor and pchannel_monitor.
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      viol         <= 0;
      hwstat_d     <= '0;
      pcsm_pstate_d <= '0;
      clken_d      <= 1'b0;
      iso_d        <= 1'b0;
      pore_d       <= 1'b0;
      warm_d       <= 1'b0;
      retn_d       <= 1'b0;
      // The reset state is itself a legitimate thing to check: the PPU comes
      // out of reset with PPUHWSTAT and the controls both describing
      // reset_mode, so U3 should hold there too.
      last_event_hwstat <= 1'b1;
      quiet             <= 0;
      u3_done           <= 1'b0;
    end else if (!ppu_rst_n) begin
      // Suspended, and the history is reloaded so the first post-reset change
      // is not mistaken for a transition.
      hwstat_d     <= ppuhwstat;
      pcsm_pstate_d <= pcsm_pstate;
      clken_d      <= dev_clken;
      iso_d        <= dev_isolaten;
      pore_d       <= dev_poresetn;
      warm_d       <= dev_warmresetn;
      retn_d       <= dev_retresetn;
      last_event_hwstat <= 1'b1;
      quiet             <= 0;
      u3_done           <= 1'b0;
    end else begin
      // ---- U1 / U2: PPUHWSTAT is always a valid one-hot mode ----
      if ($countones(ppuhwstat) != 1)
        flag("U1", $sformatf("PPUHWSTAT is not one-hot (%0d bits set)",
                             $countones(ppuhwstat)));
      else if (!hw_valid)
        flag("U2", $sformatf("PPUHWSTAT encodes unsupported mode %0d", hw_mode));

      // ---- U4 / U5: isolation and clock order (Section 4.1.5) ----
      if (iso_d && !dev_isolaten && clken_d)
        flag("U4", "DEVISOLATEn asserted while DEVCLKEN was still HIGH");
      if (!clken_d && dev_clken && !iso_d)
        flag("U5", "DEVCLKEN asserted while DEVISOLATEn was still LOW");

      // ---- U6: reset release order ----
      if (((!pore_d && dev_poresetn) || (!warm_d && dev_warmresetn) ||
           (!retn_d && dev_retresetn)) && !clken_d)
        flag("U6", "reset released while DEVCLKEN was still LOW");

      // ---- U7: DEVPORESETn is exclusive to the unpowered modes ----
      if (pore_d && !dev_poresetn && iso_d)
        flag("U7", "DEVPORESETn asserted while DEVISOLATEn was still HIGH");

      // ---- U10: the operating-mode field is reserved and always zero ----
      // Cheap, absolute, and previously unverified anywhere: the field exists in
      // the encoding only for a P-Channel PPU with operating modes, and this PPU
      // is neither.
      if (pcsm_pstate[7:4] !== 4'h0)
        flag("U10", $sformatf("PCSMPSTATE[7:4] is %01h, must be 0 on a Q-Channel PPU",
                              pcsm_pstate[7:4]));

      // ---- U11: the RAM retain field belongs only to three modes ----
      // Checked against the mode field in the SAME vector, so no settle
      // condition is needed and a requested state that leads the committed one
      // cannot produce a false positive.
      if ((pcsm_pstate[3:0] != PM_FUNC_RET) && (pcsm_pstate[3:0] != PM_FULL_RET)
                                           && (pcsm_pstate[3:0] != PM_MEM_RET)
          && (pcsm_pstate[15:8] !== 8'h00))
        flag("U11", $sformatf("PCSMPSTATE[15:8] is %02h with mode field %0s, must be 0 -- only FUNC_RET, FULL_RET and MEM_RET carry a retain value",
                              pcsm_pstate[15:8], ppu_mode_name(pcsm_pstate[3:0])));

      // ---- U12 lives inside the U9 block below: it needs the decoded modes ----
      // (placeholder removed)
      // ---- U12 rationale ----
      // Table 4-5, RST_HWSTAT_DLY: "The minimum number of PPU clock cycles
      // between DEV*RESETn de-assertion and PPUHWSTAT updating is
      // RST_HWSTAT_DLY + 1. THIS DELAY IS ALSO DEPENDANT ON THE COMPLETION OF
      // THE DEVICE INTERFACE."
      //
      // The second sentence is the one with no other checker behind it. Timing
      // the delay alone cannot see it, because both conditions are usually
      // satisfied together -- the device normally accepts the exit well before
      // a long delay expires. It only separates when the handshake is the
      // slower of the two, which is exactly the case a fast PPU driving a slow
      // device produces.
      //
      // The first attempt at this rule watched for Q_EXIT and caught nothing:
      // at the moment the mode commits, QREQn has not yet been driven HIGH, so
      // the channel is still in Q_STOPPED rather than Q_EXIT. The window is not
      // "the handshake is in progress" but "the handshake has not finished",
      // and the way to express that is on the DESTINATION -- see below.

      // ---- U8: PCSMPSTATE stability (AMBA LPI Section 2.2.2 rule 3) ----
      if ((pcsm_pstate !== pcsm_pstate_d) && pcsm_preq)
        flag("U8", $sformatf("PCSMPSTATE changed %04h -> %04h while PCSMPREQ was HIGH",
                             pcsm_pstate_d, pcsm_pstate));

      // ---- U9: legal mode pairs (Section 3.3.2) ----
      // "it only transitions between ON and the power mode programmed in the
      // PPU_PWPR register", plus the one named exception, OFF -> MEM_RET.
      if (hwstat_changed && ($countones(ppuhwstat) == 1)
                         && ($countones(hwstat_d) == 1)) begin
        logic [3:0] from_mode, to_mode;
        from_mode = 4'd0;
        to_mode   = 4'd0;
        for (int unsigned i = 0; i < 16; i++) begin
          if (hwstat_d[i])  from_mode = i[3:0];
          if (ppuhwstat[i]) to_mode   = i[3:0];
        end
        if ((from_mode != PM_ON) && (to_mode != PM_ON)
            && !((from_mode == PM_OFF) && (to_mode == PM_MEM_RET)))
          flag("U9", $sformatf("illegal mode transition %0s -> %0s (neither end is ON)",
                               ppu_mode_name(from_mode), ppu_mode_name(to_mode)));

        // ---- U12: the mode may not commit before the device is running ----
        // Table 4-5, RST_HWSTAT_DLY: "The minimum number of PPU clock cycles
        // between DEV*RESETn de-assertion and PPUHWSTAT updating is
        // RST_HWSTAT_DLY + 1. THIS DELAY IS ALSO DEPENDANT ON THE COMPLETION OF
        // THE DEVICE INTERFACE."
        //
        // Nothing else checks the second sentence. Timing the delay cannot see
        // it, because both conditions are normally satisfied together -- they
        // only separate when the handshake is the slower of the two.
        //
        // Stated on the pair, not on the priority encoding. "Higher priority"
        // is the wrong discriminator and produced false positives on
        // ON -> WARM_RST: WARM_RST is encoded ABOVE ON (Table 3-1) yet the
        // device is quiesced there, not returned to service, so the channel is
        // legitimately in Q_STOPPED when that mode commits.
        //
        // The condition that actually requires an exit handshake is the device
        // being restarted: leaving a mode whose device controls stop the clock
        // (OFF, MEM_RET, FULL_RET -- Table 4-9) for ON. Only then must the
        // channel be in Q_RUN {QREQn=1, QACCEPTn=1, QDENY=0} at commit.
        //
        //   OFF -> MEM_RET      excluded: device stays stopped in both
        //   ON -> WARM_RST      excluded: device is being stopped, not started
        //   MEM_OFF/FUNC_RET    excluded: device never stopped, channel stays
        //     -> ON             in Q_RUN throughout
        //   channel disabled    satisfies it anyway -- never leaves Q_RUN
        if (((from_mode == PM_OFF) || (from_mode == PM_MEM_RET)
                                   || (from_mode == PM_FULL_RET))
            && (to_mode == PM_ON)
            && !(dev_qreqn && dev_qacceptn && !dev_qdeny))
          flag("U12", $sformatf("PPUHWSTAT committed %0s -> %0s with the device Q-Channel at {QREQn=%0b QACCEPTn=%0b QDENY=%0b} -- a higher-priority mode may not commit before the device interface handshake completes",
                                ppu_mode_name(from_mode), ppu_mode_name(to_mode),
                                dev_qreqn, dev_qacceptn, dev_qdeny));
      end

      // ---- U3: settled device controls match the reported mode ----
      if (hwstat_changed) begin
        last_event_hwstat <= 1'b1;
        quiet             <= 0;
        u3_done           <= 1'b0;
      end else if (ctrl_changed || pcsm_preq || !q_idle) begin
        // A control moved, or a handshake is outstanding: the PPU is mid
        // transition and PPUHWSTAT is still reporting the mode being left.
        if (ctrl_changed) last_event_hwstat <= 1'b0;
        quiet   <= 0;
        u3_done <= 1'b0;
      end else if (quiet < SETTLE_CYCLES) begin
        quiet <= quiet + 1;
      end else if (!u3_done && last_event_hwstat && hw_valid) begin
        u3_done <= 1'b1;
        if (dc_act !== dc_exp)
          flag("U3", $sformatf("settled controls do not match %0s (expected %05b, got %05b)",
                               ppu_mode_name(hw_mode), dc_exp, dc_act));
      end

      hwstat_d     <= ppuhwstat;
      pcsm_pstate_d <= pcsm_pstate;
      clken_d      <= dev_clken;
      iso_d        <= dev_isolaten;
      pore_d       <= dev_poresetn;
      warm_d       <= dev_warmresetn;
      retn_d       <= dev_retresetn;
    end
  end

endmodule
