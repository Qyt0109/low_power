# PPU and PCSM findings: root causes and fix plan

The five findings of [`src/pmu/README.md` §10.2](../../pmu/README.md#102-findings-in-the-ppu-and-pcsm-hardware),
each traced to the RTL line that causes it, with the change that removes it and
how the change will be proven. Written 2026-09-29, before any fix.

## Status: applied 2026-09-29

All five fixes are in, including 4(d). Each fix has a check that was run
against the unfixed RTL first and failed there. Results, all under VCS:

| What | Result |
|---|---|
| Plain-RTL PPU regression, 21 suites (`ppuall`, `pchall`, `lpdq`, `lpdpd`, `acgpd`) | all PASS; `ppu` 584 → 617 checks (P35, P36), `ppuclkq` 72 → 81 (G9) |
| `make ppupcsmpg` | now a regression: 15 of 15 runs PASS |
| PCSM mutation set | 12 of 12 mutants killed |
| `scphello`, `scppd`, `scpstress` | PASS; stress 35 PASS, 0 DEVIATION (was 32 / 3) |
| `ppu_lock_probe`, `ppu_edge_probe` | CONFORMANT, TIMELY (were DEVIATION REPRODUCED) |
| `scppdpa`, `scpstresspa` (UPF) | PASS, zero low-power checker errors (were 50+39 and 606+594 `*_RETPWRDN`) |

**Superseded (2026-10-02).** `pmu_top`, `pmu_tb`, the SCP targets above and the
two probes (`ppu_lock_probe`, `ppu_edge_probe`) were retired with the 12-domain
system ([`docs/SOC4_DESIGN.md`](../../../docs/SOC4_DESIGN.md) Section 12). The PPU-suite
regression checks of each fix stay and still fail without it; the firmware-side
check now runs on soc4 (`make soc4stress`, `soc4stresspa`: 33 PASS and 1
recorded driver DEVIATION on four static-only PPUs; `pmu/PPU_FW_CONFORMANCE.md`).
This record is kept as written.

Where the implementation departs from this plan, and why:

- **4(c) restore.** The plan said to restore on the committed decode. Figure
  4-15 puts t4 at `PCSMPACCEPT` *falling*, and `pchannel_device` commits
  `cur_state` on that edge, so that would have restored one cycle after the
  handshake. Instead the restore waits for the logic supply to be confirmed,
  and `hold_restore` keeps the accept until it is done.
- **Down-leg at `PGOOD_EN = 1`.** Cross-checking 4(c) showed a power-up
  soon after a power-down could restore on a stale acknowledge from a switch
  still turning off. So at `PGOOD_EN = 1` the PCSM also drops the logic rail
  inside the handshake (`early_off`, `hold_off`) and confirms the retention
  rail off before accepting a non-retaining request (`hold_ret_off`). An
  independent review then found the same stale-acknowledge case after a reset
  with the domain ON; `ack_on_fresh` closes it (reproducer scenario Z).
- **`hold_restore`.** Removing it is not observable against §4.1.6 in any
  reachable configuration: the restore still beats t4 by the controller's
  one-cycle reaction. It stays so that the ordering is enforced rather than
  emergent, and the reproducer's C8 check pins it. That is a design invariant,
  stricter than the spec.
- **`ppu_power_model` PU9** is the full rule again ("a save with no retention
  supply"), since `OFF` and `MEM_RET` no longer save. Against the unfixed PCSM
  it fires 54 times in `ppu_pd_tb`, so the plain-RTL suite now guards fix 3.
- **4(d)** is plumbed to `ppu_pd_top` as `PCSM_RET_SETTLE` and
  `PCSM_LOGIC_SETTLE`, default 0. The SoC keeps 0: its UPF switches are ideal.
  Silicon values would come from the switches.

Not done: the PPU's own power-aware suites (`ppupa` and the rest) still need
Xcelium. A VCS form for `ppu_pd_tb` was drafted and not run, and was removed.

Left as found, from the review. `ppu_regs` pulses `policy_wr` even when a
same-cycle denial revert wins the register, a one-cycle window that predates
these fixes. `!init_pending` in completion condition 1 has no counterpart in
§4.1.2's text.

The rest of this document is the plan as written before the fixes.

Section references are to the PPU architecture, ARM DEN 0051E.

---

## 1. Verdicts

| # | Block | Root cause | Evidence | Status of the finding |
|---|---|---|---|---|
| 1 | `ppu_seq` | The write-time lock is a registered decision (`locked_q`), but the hop launch reads it combinationally, so on the one cycle the lock is being set the sequencer still sees it clear and starts the hop | Cycle trace: both happen on the same edge | Confirmed, PPU deviation from §3.4.3 |
| 2 | `ppu_top` | The PPU's clock request counts `DEVQACTIVE` only when `PWR_DEVACTIVEEN` is set, which is the transition-control condition; the input edge interrupt, which §4.1.3 makes independent of that enable, has no say in it | Cycle trace: the edge arrives, the clock is not requested, the event waits ~4,950 cycles for an unrelated register access | Confirmed, PPU deviation from §4.1.3 |
| 3 | `ppu_pcsm` | The *logic-state* retention machine (`ret_n`, the save/restore of `u_ip/u_ret`) runs for every logic power-down, `OFF` and `MEM_RET` included. Its supply, `SW_RET`, is raised only for `FULL_RET`. This was a deliberate modelling choice, and it contradicts the power intent. RAM retention is a separate path and is not involved | Low-power checker counts match the mechanism exactly | Confirmed, PCSM model; no DEN 0051E rule |
| 4 | `ppu_pcsm` | The P-Channel was deliberately left free to complete without the retention machine, on the argument that `RET_ARM` takes one cycle. `PGOOD_EN = 1` made `RET_ARM` wait for an acknowledge and nothing tied the handshake back to it. Hence: (a) a `FULL_RET` entry completes before its save; (b) a request that supersedes it is never seen; (c) the restore fires on `logic_on`, which since `early_on` was added rises at the request, not when the supply is back; (d) at `PGOOD_EN = 0` nothing waits for either switch | `make ppupcsmpg SIM=vcs`, rerun, table below | Confirmed, PCSM model: (a)–(c) against §4.1.6, (d) an ideal-switch assumption. **(c) is new**, not yet in README §10.2 |
| 5 | `ppu_seq` | The first `STA_POLICY_TRN` condition tests `dyn_status_q` (the status) where §4.1.2 names `PPU_PWPR.PWR_DYN_EN` (the register); on the cycle the write is judged, the status still holds the pre-write value | Trace over the whole stress run: 99 of 99 same-mode writes that flip the enable give the wrong answer | Confirmed, PPU deviation from §4.1.2 |

### Finding 1 — the write-time lock launches the hop it should prevent

`ppu_seq.sv`:

```systemverilog
// 366: the only thing that stops a hop is locked_q
if (locked_q)          final_tgt = cur_mode;
...
// 543-548: the write-time lock is REGISTERED
if (LOCK_CFG && !(unlock_wr || !lock_en || !pwr_dyn_en)) begin
  if (!locked_q && ( ... : (policy_wr_d && (state == S_IDLE)
                            && ppu_mode_lockable(STA_MASK, cur_mode))))
    locked_q <= 1'b1;
...
// 591: ...while the hop is launched from final_tgt on the SAME edge
if (hop_needed && pcsm_init_done && !revert_vld) begin
```

Trace, DSP2 in `MEM_RET`, `PPU_PWPR := {OFF, PWR_DYN_EN, LOCK_EN}` (`ppu_lock_probe`):

```
179835 ns  policy_wr_d=1  cur=MEM_RET  locked_q=0  hop_needed=1 hop_tgt=ON  state=S_IDLE
179845 ns  policy_wr_d=0  cur=MEM_RET  locked_q=1                           state=S_UP_PCSM  ev_locked   <- both on one edge
180275 ns                 cur=ON       locked_q=1  hop_needed=0             state=S_IDLE                 <- locked in ON
```

`ev_locked` fires on the same edge on which the PPU starts leaving the mode it
locked in.

The arrival lock (commit into `OFF`/`MEM_RET`) is not affected: it is set on
the commit edge, and the sequencer is back in `S_IDLE` only a cycle later.

### Finding 2 — a disarmed PPU's edge interrupt waits for a bus access

`ppu_top.sv`:

```systemverilog
// 736-737
assign ppuclk_needed = seq_active | pwakeup | (dev_qactive      & devactiveen);
assign ppuclk_deny   = seq_active | pwakeup | (sync_dev_qactive & devactiveen);
```

The edge detector (`ppu_irq.sv` 137–153) compares the synchronized input with
its own registered copy. The synchronizer and the copy both run on the gated
PPU clock: in the trace, `sync` follows the pin only once the clock is back. With
`PWR_DEVACTIVEEN = 0` a `DEVQACTIVE` edge does not request that clock, so
neither register moves. Trace, CPU2, `PPU_IESR` = rising (`ppu_edge_probe`):

```
182855 ns  DEVQACTIVE raw=1 sync=0  PWR_DEVACTIVEEN=0  ppuclk_needed=0  PPU clock enable=0  ISR.edge=0
232315 ns  DEVQACTIVE raw=1 sync=0                     ppuclk_needed=1  <- the firmware's next access (PWAKEUP)
232325 ns  DEVQACTIVE raw=1 sync=0                                      PPU clock enable=1
232345 ns  DEVQACTIVE raw=1 sync=1
232355 ns                                                               ISR.edge=1  irq=1
```

49,500 ns from the edge to the event: 4,950 cycles, all of them spent waiting
for a bus access that had nothing to do with it.

PCK-600, where the clock Q-Channel comes from, defines `ppuclk_qactive_o`
only as "when the PPU requires the clk signal" — the PPU requires it to see
an edge it has been told to report.

### Finding 3 — retention strobes on every power cycle

`ppu_pcsm.sv` 475–485 enters `RET_ARM` on any request that removes the logic
supply and takes the save (`ret_n` LOW) in all three cases; 463–465 raise the
retention rail only for `FULL_RET`. So `OFF` and `MEM_RET` save into, and
later restore from, retention cells with no supply. Comments at 360–363 and
504–507 say this is intended. VCS native low power reports each one as an
error, `LP_SAVE_RETPWRDN` and `LP_RESTORE_RETPWRDN`, and the counts in
`pd_multi` under UPF are exactly the mechanism: 50 saves = 53 entries into
`OFF`/`MEM_RET` less 3 direct `OFF → MEM_RET` hops (the machine is already in
`RET_DOWN`); 39 restores = 51 power-ups less each domain's first. The stress
run under UPF gives 606 and 594.

### Finding 4 — `FULL_RET` retention sequencing

Figure 4-15 puts t1 at `PCSMPREQ` rising and t4 at `PCSMPACCEPT` falling,
so §4.1.6 wants the whole power transition, switches and save and restore,
between the PPU's request and the PCSM dropping its accept.
`pchannel_device` commits `cur_state` on the same edge it drops `PACCEPT`
(its `D_ACCEPT` state), so anything decoded from the committed state happens
after t4.

`ppu_pcsm.sv`:

```systemverilog
// 383: the accept is held only for a request that RAISES the logic rail
assign pgood_hold = PGOOD_EN && req_wants_logic && !ack_logic_on_s;
// 513: RET_ARM waits for the retention switch, and watches nothing else
if (!PGOOD_EN || !ret_keep || ack_logic_ret_s) ... ret_state <= RET_SAVED;
// 531-537: RET_DOWN restores on logic_on ...
// 233, 237: ... which early_on raises at the REQUEST, before any acknowledge
```

How it got here is written in the code:

- **The save was left out of the handshake on purpose.**
  `pchannel_device.sv` 131–135 says of `dev_busy`: "THIS PORT WAS BUILT ONCE
  BEFORE AND REVERTED. The case then was the retention save ... the save
  always leads the supply removal by at least a cycle whether or not anything
  enforces it." `ppu_pcsm.sv` 338–358 gives the same argument. It was true
  while `RET_ARM` took one cycle. `PGOOD_EN = 1` made `RET_ARM` wait for
  `ack_logic_ret` behind a two-flop synchronizer, and the argument was not
  revisited. The port it avoided exists now anyway, for the logic switch.
- **The restore was meant to follow the committed state.** Its comments
  (365–366, 532–533) say `logic_on` "is the committed decode, so this cannot
  fire before the rail returns". `early_on` (219–237) was added later to stop
  the rail pulsing 1-0-1 across the accept. It makes `logic_on` rise at the
  request, and the restore moved with it.
- **Only `RET_SAVED` handles a superseding request** (519–527). `RET_ARM`
  did not need to while it lasted one cycle.

`make ppupcsmpg SIM=vcs` drives `ppu_pcsm` through the PPU's own P-Channel
controller. The switch acknowledges trail their controls by the number of
cycles shown. Rerun 2026-09-29 against the current RTL:

| PGOOD_EN | PCSM channel as in | logic / retention switch (cycles) | A: save before logic off | R: save after retention up | S: restore after logic up | B: superseded entry |
|---|---|---|---|---|---|---|
| 1 | `ppu_pd_top` | 0 / 0 | FAIL, 1 late | PASS | PASS | PASS |
| 1 | `ppu_pd_top` | 4 / 3 | FAIL, 4 late | PASS | FAIL, 3 early | PASS |
| 1 | `ppu_pd_top` | 4 / 30 | FAIL, 31 late | PASS | FAIL, 3 early | FAIL: stuck in `RET_SAVED`, `ret_n` LOW, rail on |
| 1 | `ppu_pd_top` | 20 / 3 | FAIL, 4 late | PASS | FAIL, 19 early | PASS |
| 1 | `ppu_lpd_pd_top` | 0 / 0 | PASS | PASS | PASS | PASS |
| 1 | `ppu_lpd_pd_top` | 4 / 30 | FAIL, 29 late | PASS | FAIL, 3 early | FAIL |
| 0 | `ppu_pd_top` | 0 / 0 | PASS | PASS | PASS | PASS |
| 0 | `ppu_pd_top` | 4 / 3 | PASS | FAIL, 2 early | FAIL, 3 early | PASS |
| 0 | `ppu_pd_top` | 4 / 30 | PASS | FAIL, 29 early | FAIL, 3 early | PASS |

Thresholds:
- B fails with a retention switch of 5 cycles or more on `ppu_pd_top`'s
  channel, and 16 or more on `ppu_lpd_pd_top`'s.
- At `PGOOD_EN = 0`, R fails from 2 cycles.
- S fails from a 2-cycle logic switch in every configuration. That includes
  `PGOOD_EN = 1`, where the PCSM has the acknowledge but does not use it for
  the restore.

At `PGOOD_EN = 1`, (a), (b) and (c) are defects. At `PGOOD_EN = 0`, this
SoC's setting, every check passes with ideal switches, which is what the UPF
has. R and S fail with real switches: that is (d).

### Finding 5 — `STA_POLICY_TRN`'s first condition

`ppu_seq.sv` 620:

```systemverilog
if (policy_wr_d && !dyn_status_q && !init_pending && (pwr_policy == cur_mode))
  ev_sta_policy_trn <= 1'b1;
```

`dyn_status_q` is updated in `S_IDLE` on the same edge, from the value the
write just put in `PPU_PWPR`, so on this cycle it holds the old enable. Traced
over the whole `ppu_stress` run:

| Same-mode write | Count | Event | §4.1.2 |
|---|---:|---|---|
| static → dynamic (`PWR_DYN_EN` 1, status still 0) | 50 | always | never |
| dynamic → static (`PWR_DYN_EN` 0, status still 1) | 49 | never | always |

---

## 2. Fixes

### Fix 5 — one term (`ppu_seq.sv` 620)

Test `!pwr_dyn_en` instead of `!dyn_status_q`. On the `policy_wr_d` cycle
`pwr_dyn_en` already holds the value written, which is what §4.1.2's first
condition names. Nothing else reads this condition. Risk: low. A test that
encoded the old answer (a same-mode write that also flips the enable) must be
updated, citing the clause.

### Fix 1 — make the write-time lock effective on its own cycle (`ppu_seq.sv`)

One combinational term, used in both places that need it:

```systemverilog
// Section 3.4.3, "Locking the PPU": the PPU is locked when "The PPU_PWPR is
// written with LOCK_EN and PWR_DYN_EN set to 0b1 and" it "is in a lockable
// power mode". The write itself is the condition, and a locked PPU may make
// only the two _EMU transitions the section lists. So the hop the same write
// asks for must not start.
assign lock_on_write = LOCK_CFG && lock_en && pwr_dyn_en && !unlock_wr
                    && policy_wr_d && (state == S_IDLE)
                    && ppu_mode_lockable(STA_MASK, cur_mode);

if (locked_q || lock_on_write) final_tgt = cur_mode;   // 366
... locked_q set from lock_on_write in the lock block    // 543-548
```

`hop_needed` is then 0 on the write cycle and `locked_q` holds it from the
next. The arrival path is unchanged. On the write cycle the sequencer takes
its `!hop_needed` branch, where the lock write (dynamic) raises no
`STA_POLICY_TRN`, before or after fix 5.

The same step corrects the lock citation, "Section 3.3.4", to §3.4.3 where it
occurs:
- the RTL comments at `ppu_pkg.sv` 251 and `ppu_seq.sv` 327 and 530;
- `rtl/ppu/README.md`;
- `rtl/ppu/CONFORMANCE.md`;
- `tb/ppu/TEST_MATRIX.md`;
- `ppu_pd_tb.sv`.

Risk: low. The term is active only on the cycle after a `PPU_PWPR` write made
in a lockable mode.

### Fix 2 — request the PPU clock for an edge it has not yet seen (`ppu_top.sv`, `ppu_irq.sv`)

`ppu_irq` exports its registered copy of the input (`qactive_seen`, today's
`dev_qactive_d`; its only other instantiation, `ppu_irq_tb`, connects by name).
`ppu_top` adds one term to each of the two clock-request expressions, gated by
`PPU_IESR` selecting any edge:

```systemverilog
wire edge_armed = (iesr[1:0] != EDGE_NONE);
assign ppuclk_needed = ... | (edge_armed && (dev_qactive      != qactive_seen));  // raw pin -> QACTIVE
assign ppuclk_deny   = ... | (edge_armed && (sync_dev_qactive != qactive_seen));  // sampled copy
```

Any edge, not only the selected one: the detector must track a fall to see
the next rise. Once the detector has registered the new level both terms drop
and the clock gates again, so a `DEVQACTIVE` held steady costs nothing; with
`PPU_IESR` at its reset value of none, behaviour is exactly today's. Risk:
medium — this is the PPU's clock request; the check is that the clock still
gates when idle.

### Fix 3 — no logic save/restore where no logic state is kept (`ppu_pcsm.sv`)

Table 3-1 gives each power mode a Logic Mode and a RAM Mode, and either can
be RET. `ppu_pcsm` drives the two on separate paths:

- **Logic state:** `ret_n`, the save/restore of the UPF strategy
  `RET_DEV_LOGIC` on `u_ip/u_ret`, whose shadow cells run on `VDD_RET` from
  `SW_RET` (controlled by `logic_ret`). This is the retention machine.
- **RAM:** `ram_ret`, `ram_cfg`, `ram_sleep` and `ram_sd` (243–245, 553–564),
  decoded from the committed mode and the `PPU_FUNRR`/`PPU_FULRR`/`PPU_MEMRR`
  value carried on `PCSMPSTATE[15:8]`. These drive the SRAM macro pins and
  never read the retention machine.

| Mode | Logic Mode | RAM Mode | Logic path today | Logic path after fix 3 | RAM path, unchanged |
|---|---|---|---|---|---|
| `ON` | ON | ON | idle | idle | banks on |
| `FUNC_RET` | ON | RET | idle | idle | banks in `PPU_FUNRR` retained |
| `MEM_OFF` | ON | OFF | idle | idle | banks shut down |
| `FULL_RET` | RET | RET | save, `SW_RET` on, restore | **unchanged** | banks in `PPU_FULRR` retained |
| `LOGIC_RET` | RET | OFF | cannot exist here | — | — |
| `MEM_RET` | OFF | RET | save and restore with `SW_RET` off | none | banks in `PPU_MEMRR` retained |
| `OFF` | OFF | OFF | save and restore with `SW_RET` off | none | banks shut down |

`LOGIC_RET` is the only other mode whose Logic Mode is RET, and a Q-Channel
PPU cannot have it: `PPU_IDR0` defines its support bit as "Always set to 0b0
for a Q-Channel PPU".

The change: enter the retention machine (`RET_IDLE`, 479–485) only when the
requested mode's Logic Mode is RET. Write that as a Table 3-1 decode,
`FULL_RET` or `LOGIC_RET`, rather than a comparison with `FULL_RET`, and use
the same decode for `ret_rail` (463–465). The rule then reads as the spec
states it, and stays right in a P-Channel build.

`MEM_RET` keeps its RAM exactly as today. What stops is the logic save in
`MEM_RET` and `OFF` into shadow cells with no supply, and the restore from
them on the way up. Both modes have Logic Mode OFF, and `ppu_ip_ret` holds
`u_ret` in reset in both (`DEVPORESETn & DEVRETRESETn` = 0). So the domain
comes up from reset, as it does today.

`ret_keep` becomes constant and is removed, and so is `RET_ARM`'s
`!ret_keep` term. The comments that describe the old intent change with it:
`ppu_pcsm.sv` 360–363 and 504–507, and `ppu_power_model`'s PU9 note.

No testbench counts these strobes. `ppu_power_model` takes its shadow save
from `logic_ret` rising, which only `FULL_RET` does.

Risk: low. The checks are that the two checker counts go to zero and that
`FULL_RET` retention behaves as before.

### Fix 4 — tie the P-Channel to the retention machine in both directions (`ppu_pcsm.sv`)

One rule: the PCSM does not accept while its retention sequence still owes a
step. §4.1.6 then holds by construction, whatever time the switches take.

- **(a) Save.** Hold the accept while a `FULL_RET` request waits for its
  save:
  `hold_save = dev_req_valid && (req_mode == PM_FULL_RET) && (ret_state != RET_SAVED)`.
  `pchannel_device` holds a busy request in `D_REQUEST`, so `PACCEPT` cannot
  rise before the save. Neither can the commit that removes the logic
  supply.
- **(c) Restore.** `RET_DOWN` restores once the logic supply is confirmed:
  `logic_on && ack_logic_on_s` at `PGOOD_EN = 1`, and `logic_on` at
  `PGOOD_EN = 0`. The accept is held until the restore has happened:
  `hold_restore = req_wants_logic && (ret_state != RET_IDLE)`.
  - Restoring on the committed state, as the comments intended, would be
    too late: the commit is t4, so the restore would land a cycle after the
    PCSM had completed the handshake.
  - Holding the accept keeps the restore inside the handshake. It is then
    also ahead of the PPU's isolation release, which follows the accept.
- **(b) Superseding requests.** With both holds, the P-Channel is busy
  whenever `RET_ARM` or `RET_DOWN` owes a step. The LPI handshake admits no
  new request until `PACCEPT` has fallen. So `RET_ARM` can no longer be
  superseded, and `RET_SAVED`'s existing arm becomes unreachable too. Both
  get an assertion rather than more code.
- **Wiring.** `dev_busy` becomes `pgood_hold || hold_save || hold_restore`.
- **Cost.** At `PGOOD_EN = 0`, every `FULL_RET` entry takes two more cycles,
  and so does every exit; nothing else changes. At `PGOOD_EN = 1`, the entry
  now waits for the retention switch, as it always should have, and the exit
  takes one more cycle.
- **(d)** *Decision D2 below.* At `PGOOD_EN = 0` there is no acknowledge to
  wait for. Two parameters would close the gap, both used only when
  `PGOOD_EN = 0`:
  - `RET_SETTLE`: cycles `RET_ARM` waits after raising the retention rail.
  - `LOGIC_SETTLE`: cycles the restore, and the power-up accept, wait after
    the logic rail is raised.

  0 means no wait, and both default to 0, so no existing bench changes. With
  (a) and (c) in place, the counters only extend the two holds.
  `LOGIC_SETTLE` would also close the gap README rule 9 records: isolation
  release follows `PCSMPACCEPT` directly, so no `PPU_DCDR` value can protect
  it.

Fixes 3 and 4 change the same state machine and go in together.

Risk: medium. Every `FULL_RET` transition in every bench changes timing,
by two cycles at `PGOOD_EN = 0`. The SCP's 20-cycle rail-to-reset budget
only gains from it.

---

## 3. How each fix is proven

**Baseline, before any change, all under VCS W-2024.09-SP2 on plain RTL:**

| Suite | Result |
|---|---|
| The PPU's own regression, 15 suites (`ppu`, `ppuneg`, `ppurst`, `ppuratio`, `ppucfg`, `ppurstf`, `ppuirq`, `ppupm`, `ppuregdoc`, `ppube`, `ppudeny`, `ppudevif`, `ppuclkctrl`, `ppuclkq`, `ppuaxi`) | all PASS; `ppuaxi` only once its flags are spelled for VCS |
| P-Channel `pch`, `pchneg`, `pchpd`; LPD `lpdq`, `lpdpd` | all PASS |
| `acgpd` (the gate in a real PPU domain) | PASS once its flags are spelled for VCS |
| SCP `scphello`, `scppd`, `scppdpa`, `scpstress`, `scpstresspa` | PASS; stress 32 PASS, 3 DEVIATION |
| `ppupcsmpg` | FAIL, as in the table above |

So the statement in the README that the PPU regression needs Xcelium is true
only of its power-aware suites. `acg`, the gate's unit test, does not compile
under VCS (a testbench net with two kinds of driver) and holds no PPU, so it is
not part of this.

**For every fix:**

1. The reproducer flips: `ppu_lock_probe`, `ppu_edge_probe`, the stress
   feature (`LOCK.RACE`, `EVT.EDGE_OFF`, `EVT.PTRN1` from DEVIATION to PASS),
   `ppupcsmpg`, the low-power checker's `LP_SAVE_RETPWRDN` /
   `LP_RESTORE_RETPWRDN` counts to zero.
2. A regression check joins the PPU's own suite, so the PPU catches a
   regression without the SCP:
   - new `ppu_pd_tb` phases for fixes 1 and 5;
   - a `ppu_clkq_tb` phase for fix 2: the edge is seen with the clock gated,
     and the clock gates again afterwards;
   - `ppupcsmpg` becomes a PASS/FAIL suite for fixes 3 and 4. It must pass A,
     R, S and B at `PGOOD_EN = 1` on both channels over the delay matrix above,
     and at `PGOOD_EN = 0` with ideal switches. If D2 is taken, it must also
     pass with settle counts at least as long as the switches. A new check
     confirms that `OFF` and `MEM_RET` leave `ret_n` HIGH.
3. Everything in the baseline table is rerun and stays green.
4. The fix is reverted once and the new checks must fail — the same mutation
   discipline as `PPU_FW_CONFORMANCE.md` §6.

What stays unproven until Xcelium is back: the PPU's own power-aware suites.
`scppdpa` and `scpstresspa` cover `ppu_pd_top` under power intent through VCS;
`ppu_lpd_pd_top` at `PGOOD_EN = 1` under UPF has no VCS flow yet.

---

## 4. Order, and the decisions that are yours

Each step is self-contained, with the change, its regression check and its
documents, so each can be its own commit.

| Step | Change | Needs a decision |
|---:|---|---|
| 0 | Makefile: `ppuaxi` and `acgpd` under VCS, so one command runs the whole affected regression | no |
| 1 | Fix 5 | no |
| 2 | Fix 1 | no |
| 3 | Fix 2 | no |
| 4 | Fixes 3 and 4 (a)–(c) | D1 |
| 5 | Fix 4 (d) | D2 |
| 6 | Documents: README §10.2 (with 4(c), and without the claim that the PPU regression needs Xcelium), `PPU_FW_CONFORMANCE.md`, `rtl/ppu/CONFORMANCE.md` | no |

- **D1 — finding 3.** The PCSM's authors took the `OFF`/`MEM_RET` logic save
  on purpose. The plan removes it because it only ever lands on unpowered
  shadow cells. RAM retention in `MEM_RET` is not affected. The alternative
  is to keep the save and accept the checker's errors.
- **D2 — finding 4 (d).** Add `RET_SETTLE` and `LOGIC_SETTLE` to the PCSM,
  default 0, and choose the values the SoC sets from the switches' settling
  time; or keep the ideal-switch assumption, documented, until silicon
  numbers exist. If `LOGIC_SETTLE` is used, the firmware's `ISO_CLKEN_DLY`
  of 20 (README rule 9) is no longer needed for settling and could return to
  the default.
