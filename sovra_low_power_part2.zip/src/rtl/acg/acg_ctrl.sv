`timescale 1ns/1ps
// Access control gate -- the CONTROL half. PCSA (DEN 0050 D) Section 7.2.8.
//
// PCSA 7.2.8 defines access control as letting "part of the system be in a
// non-functional powered-off or retention mode even though a bus transaction
// might arrive from a part of the system that is powered-on", and gives it two
// capabilities:
//
//   "Any outstanding transactions are completed before entering the gated
//    state."
//   "Once in the gated state, transaction attempts are either stalled or
//    receive a response from the access control component according to the
//    implemented response model."
//
// and three response models -- stall-and-wake, error, accept-and-ignore.
//
// -----------------------------------------------------------------------------
// THIS MODULE IS AN ADAPTER, NOT A GATE
//
// The gating itself is vendor/opentitan/tlul/tlul_lc_gate.sv, UNMODIFIED. That
// module already implements capability 1 and the stall half of capability 2:
//
//   StActive --flush_req--> StOutstanding --outstanding==0--> StFlush
//                           block_cmd=1                       block_cmd=1
//                           (drain)                           flush_ack=1
//
// What it does not have is the WAKE. Nothing in it reports that a transaction
// is blocked at its input -- resp_pending_o reports transactions outstanding
// DOWNSTREAM, which is the opposite question. PCSA 7.2.8's first response model
// needs one:
//
//   "Stall and wake: A transaction arriving at a gated access control component
//    is initially stalled. A wake-up signal is asserted indicating that the
//    downstream power domain must be made available. Once available the access
//    control is un-gated and the transaction progresses as normal."
//
// So this module supplies three things and nothing else:
//
//   1. a Q-CHANNEL, because the PPU speaks Q-Channel and the gate speaks
//      flush_req/flush_ack
//   2. the WAKE, from a condition visible on the gate's own ports
//   3. the response-model select
//
// -----------------------------------------------------------------------------
// WHY THE WAKE IS A Q-CHANNEL QACTIVE AND NOT A NEW WIRE
//
// A stalled transaction means "this domain is needed again", which is what
// QACTIVE already means (IHI 0068C Section 2.1.3: a HIGH level while the
// interface is in Q_STOPPED "stimulates an exit from quiescence"). Routed to
// the PPU's DEVQACTIVE it wakes the domain autonomously, with PWR_DEVACTIVEEN
// set and no SCP round trip on the critical path.
//
// Inventing a separate wake signal would duplicate a mechanism the LPI already
// defines and would need its own path to the power controller.
//
// -----------------------------------------------------------------------------
// THE RUN-TIME MODE: DECISION D21 (Proposed_PMU/RPMI_STACK_DECISIONS.md)
//
// RESP_MODEL fixes a gate's behaviour at elaboration. D21 needs the SCP to
// change it per domain while the system runs, because what an access to a
// DSP or NPU means depends on what the AP voted:
//
//   mode_i = 0  DEFAULT      RESP_MODEL decides, exactly as before this input
//                            existed. 3 is reserved and behaves as 0.
//   mode_i = 1  VOTED OFF    every access is answered at once with a bus
//                            error, whether or not the domain has gone down
//                            yet: the vote is what makes the access a software
//                            bug. It is PCSA 7.2.8's error model -- no wake,
//                            "no request to change any power domain mode" --
//                            on the gate's lc_en path, which drains what is
//                            outstanding before it errors. The gate still
//                            accepts the PPU's quiescence request once
//                            drained, so the domain can power down under it.
//   mode_i = 2  POWERING UP  accesses are held, as the stall model holds them,
//                            until the domain is ON and the PPU has opened
//                            the gate. No wake is raised: the SCP is already
//                            powering the domain up, and D21 has the SCP never
//                            power a domain on for an access.
//
// The SCP writes mode_i in the same clock domain as clk (in this design one
// clock clocks both); the input is not synchronized here. The errored access
// is recorded by acg_tlul, which can see the address.
//
// LEAVING THE ERROR PATH WHILE THE GATE MUST STAY CLOSED
//
// The vendored gate has no way from StError to StFlush. Released from the
// error path (lc_en back On) it walks StError -> StErrorOutstanding ->
// StActive -> StOutstanding -> StFlush, and in StActive it neither blocks nor
// errors (tlul_lc_gate.sv:180-187, 215-221, 247-251). With the PPU still
// holding the gate closed -- VOTED OFF to POWERING UP, which is D21's
// power-up step, or VOTED OFF to DEFAULT, both with the domain down -- an
// access in that cycle is driven into a domain that is OFF. If the OFF
// device's clamped a_ready reads 1 it takes the access and never answers,
// and the gate waits in StOutstanding for good.
//
// So this module follows that walk and raises hold_o through it, and
// acg_tlul keeps the host's A channel off the gate while hold_o is HIGH: from
// the cycle the error path is released until the gate reaches StFlush
// (flush_ack_i), or until the PPU opens the gate. The access waits, as the
// stall path would make it wait anyway. For as long as the walk lasts
// gate_err_o stays LOW whatever mode_i says, so a change back to an error
// mode during it waits for StFlush and then goes StFlush -> StError, which
// has no open cycle.
//
// With mode_i held constant at DEFAULT the error path is released only
// together with flush_req_o, so hold_o never rises and gate_err_o is what it
// was before mode_i existed: DEFAULT is unchanged.

module acg_ctrl #(
  // PCSA 7.2.8's three models.
  //   ACG_STALL_WAKE   stall the transaction, raise QACTIVE, wake the domain
  //   ACG_ERROR        answer with a bus error; no power request
  //   ACG_ACCEPT_IGNORE accept and drop; no power request
  parameter int unsigned RESP_MODEL  = 0,   // 0=STALL_WAKE 1=ERROR 2=ACCEPT_IGNORE
  parameter int unsigned SYNC_STAGES = 2
) (
  input  logic clk,
  input  logic rst_n,

  // ---- Q-Channel, device side. The PROTECTED domain's PPU drives this. ----
  input  logic qreqn,
  output logic qacceptn,
  output logic qdeny,
  output logic qactive,

  // ---- To and from tlul_lc_gate ----
  output logic flush_req_o,      // ask the gate to drain and block
  input  logic flush_ack_i,      // drained; new commands are being blocked
  input  logic resp_pending_i,   // transactions still outstanding downstream

  // ---- From the gate's host-side ports ----
  // "A transaction is being stalled": the host is presenting a request and the
  // gate is not taking it. Sampled from tlul_lc_gate's own pins rather than
  // from anything inside it, which is what makes the wrapper possible without
  // forking the vendored module.
  input  logic host_blocked_i,

  // ---- D21: the SCP's run-time mode, see the header ----
  input  logic [1:0] mode_i,

  // ---- Response model, out to the gate ----
  output logic gate_err_o,       // 1 = drive lc_en_i Off, so the gate errors
  output logic hold_o,           // 1 = keep the host's requests off the gate
                                 //     (see the header)

  // ---- Observability ----
  output logic gated_o           // 1 = gated and drained; safe to power down
);

  localparam int unsigned M_STALL_WAKE    = 0;
  localparam int unsigned M_ERROR         = 1;
  localparam int unsigned M_ACCEPT_IGNORE = 2;

  initial begin
    if (RESP_MODEL > M_ACCEPT_IGNORE)
      $fatal(1, "acg_ctrl: RESP_MODEL must be 0-2 (PCSA 7.2.8), got %0d", RESP_MODEL);
  end

  // ---------------------------------------------------------------------------
  // The Q-Channel device
  // ---------------------------------------------------------------------------
  // dev_quiescent_busy is "not drained yet", which is capability 1 expressed as
  // a handshake: the interface cannot reach Q_STOPPED until tlul_lc_gate says
  // its outstanding count is zero and it is blocking. Nothing here counts
  // transactions -- the vendored gate does that, and duplicating it would be
  // the same mistake cdc_sync exists to have undone.
  //
  // dev_quiescent_deny is tied LOW, and that is a statement about what an
  // access control gate IS. It has no workload and no policy; refusing would
  // mean the domain it protects could never power down, which is the opposite
  // of why it exists. The denial path in qchannel_device is therefore
  // unreachable here by construction.
  // QUALIFIED BY flush_req_o, and it has to be. "Not drained yet" is only
  // meaningful while a quiescence request is actually in flight; ungated,
  // flush_ack_i is LOW simply because nothing has been asked of the gate.
  //
  // Unqualified, dev_quiescent_busy is therefore TRUE the whole time the gate
  // is transparent, and qchannel_device ORs it straight into QACTIVE
  // ("qactive <= dev_quiescent_busy | dev_wake"). Measured: QACTIVE stuck HIGH
  // forever, so the gate permanently told the PPU its domain was needed.
  //
  // WHAT "DRAINED" MEANS DIFFERS BY MODEL, because the two response models take
  // different paths through tlul_lc_gate's FSM:
  //
  //   stall   StActive -> StOutstanding -> StFlush     flush_ack_o is raised
  //   error   StActive -> StOutstanding -> StError     it is NOT
  //
  // flush_ack_o exists only in StFlush. The error path never goes there, so
  // waiting for it leaves the Q-Channel permanently busy and the domain can
  // never power down. In StError the gate HAS drained -- it reached that state
  // through StOutstanding, which waits for outstanding == 0 -- and reports so
  // by dropping resp_pending_o.
  //
  // With mode_i, the path is chosen at run time: VOTED OFF always takes the
  // error path, POWERING UP always the stall path, DEFAULT RESP_MODEL's.
  logic mode_off, mode_hold, err_path;
  assign mode_off  = (mode_i == 2'd1);
  assign mode_hold = (mode_i == 2'd2);
  assign err_path  = mode_off || (!mode_hold && (RESP_MODEL == M_ERROR));

  logic drained;
  assign drained = err_path ? !resp_pending_i : flush_ack_i;

  // Masked in Q_STOPPED (gated_o), where the handshake is over and "busy"
  // means nothing -- but qchannel_device still ORs it into QACTIVE. The two
  // RESP_MODEL paths are drained for as long as they stay in Q_STOPPED, so
  // this changes nothing for them. A D21 mode change while stopped is
  // different: from VOTED OFF to POWERING UP the gate walks StError ->
  // StErrorOutstanding -> StActive -> StOutstanding -> StFlush, and for those
  // few cycles neither drain indication holds. Unmasked, that raised QACTIVE,
  // a wake request the SCP never made (measured: 5 cycles, acg_tlul_tb D4).
  logic dev_busy;
  assign dev_busy = flush_req_o && !drained && !gated_o;

  // Declared here: u_q below consumes it and the generate that drives it is
  // further down.
  logic wake;

  qchannel_device #(.SYNC_STAGES(SYNC_STAGES)) u_q (
    .clk     (clk),
    .rst_n   (rst_n),
    .qreqn   (qreqn),
    .qacceptn(qacceptn),
    .qdeny   (qdeny),
    .qactive (qactive),

    .dev_quiescent_busy(dev_busy),
    .dev_quiescent_deny(1'b0),
    .dev_wake          (wake),
    .dev_quiescent_ok  (gated_o)
  );

  // ---------------------------------------------------------------------------
  // flush_req: ask the gate to close as soon as the controller asks us to
  // ---------------------------------------------------------------------------
  // Driven from the REQUEST, not from Q_STOPPED, and the difference is the
  // whole handshake. The gate needs time to drain; if flush_req only rose once
  // the interface had already reached Q_STOPPED then the accept would have been
  // given before anything drained, and dev_busy would never have held it back.
  //
  // qreqn LOW is the controller asking. Synchronized because it arrives from
  // the PPU's clock domain -- the same crossing qchannel_device handles for the
  // FSM, done separately here because this path does not go through the FSM.
  logic qreqn_s;
  cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b1))
    u_qreqn_sync (.clk(clk), .rst_n(rst_n), .d(qreqn), .q(qreqn_s));

  assign flush_req_o = !qreqn_s;

  // ---------------------------------------------------------------------------
  // The wake
  // ---------------------------------------------------------------------------
  // ONLY in stall-and-wake. The other two models answer the transaction
  // themselves -- an error, or an accepted-and-dropped write -- so there is
  // nothing waiting and nothing to wake for. PCSA 7.2.8 is explicit about the
  // error model: "There is no request to change any power domain mode."
  //
  // Registered, because host_blocked_i is a combinational function of the
  // gate's pins and QACTIVE must be a clean level rather than something that
  // glitches on every ready/valid wiggle.
  //
  // And only in DEFAULT: D21's two modes never ask for power (see the header).
  generate
    if (RESP_MODEL == M_STALL_WAKE) begin : g_wake
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) wake <= 1'b0;
        else        wake <= host_blocked_i && !mode_off && !mode_hold;
      end
    end else begin : g_no_wake
      assign wake = 1'b0;
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // Response model select
  // ---------------------------------------------------------------------------
  // tlul_lc_gate's lc_en_i is the error path and is independent of the flush
  // path. Off makes it answer with a bus error; On leaves it stalling on
  // flush_req alone.
  //
  // ACCEPT_IGNORE is NOT implemented, deliberately. PCSA 7.2.8 offers it for
  // "some types of broadcast, trace or monitoring traffic", none of which exist
  // on the memory path this gate is for, and the vendored gate's
  // ReturnBlankResp parameter is the closest upstream equivalent -- a blank
  // response, not a dropped one. Selecting it here is rejected at elaboration
  // rather than silently behaving as ERROR.
  generate
    if (RESP_MODEL == M_ACCEPT_IGNORE) begin : g_unsupported
      initial $fatal(1, "acg_ctrl: RESP_MODEL = ACCEPT_IGNORE is not implemented; see the header");
    end
  endgenerate

  // Driven from the REQUEST, not from flush_ack_i, and the first version made
  // that mistake. Conditioning lc_en on flush_ack sends the vendored FSM round
  // a loop: StFlush raises flush_ack, which drives lc_en Off, which moves it to
  // StError, where flush_ack drops, which drives lc_en back On, which returns
  // it to StActive -- and round again. It errored only because the oscillation
  // happened to be in StError when the read arrived.
  //
  // Asserting it with the request instead sends the gate straight down the
  // error path and holds it there: StActive -> StOutstanding -> StError, with
  // the drain still performed by StOutstanding on the way.
  //
  // VOTED OFF asserts it whatever the Q-Channel is doing, which is what makes
  // it answer even before the domain goes down; POWERING UP never does.
  //
  // err_req is what the mode and RESP_MODEL ask for. gate_err_o follows it
  // except during the walk back from the error path (the header, "Leaving the
  // error path while the gate must stay closed").
  logic err_req, err_q, err_drop, walk_q;
  assign err_req  = mode_off || (!mode_hold && (RESP_MODEL == M_ERROR) && flush_req_o);
  assign err_drop = err_q && !err_req;      // the error path is released this cycle

  // The walk: begins when the error path is released with flush_req_o HIGH,
  // lasts until the gate is in StFlush, and is abandoned if the PPU opens the
  // gate (the domain is then ON, and the gate may pass requests). hold_o
  // covers the release cycle too, when the gate is still in StError and its
  // error responder would take a request.
  assign hold_o = flush_req_o && (err_drop || (walk_q && !flush_ack_i));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_q  <= 1'b0;
      walk_q <= 1'b0;
    end else begin
      err_q  <= gate_err_o;
      walk_q <= hold_o;                     // hold_o is the walk's next state
    end
  end

  assign gate_err_o = err_req && !walk_q;

endmodule
