`timescale 1ns/1ps
// A minimal TL-UL responder, for testing an access control gate.
//
// NOT a general-purpose TL-UL device. It exists so acg_tlul has something to
// protect that (a) answers correctly enough for the gate's outstanding counter
// to work, and (b) has state whose loss is observable when the rail goes.
//
// The split into two register groups is the whole point, and it mirrors
// ppu_device_ip's u_core / u_ret:
//
//   mem_q   NON-retained. In PD_DEV under -simstate CORRUPT it goes X when the
//           supply is removed, which is how a testbench proves the domain
//           really lost power rather than merely being told it had.
//   ret_q   RETAINED. Named separately so upf/*.upf can put it, and only it, in
//           a set_retention strategy, so FULL_RET and OFF produce visibly
//           different outcomes.
//
// Single beat, one outstanding transaction at a time, no bursts. That is
// sufficient because the gate is the device under test and this is its load;
// anything more elaborate would be testing the responder.

module acg_resp_tlul
  import tlul_pkg::*;
#(
  parameter int unsigned DEPTH = 4      // words, addressed by a_address[3:2]
) (
  input  logic clk,
  input  logic rst_n,         // non-retained reset
  input  logic ret_rst_n,     // retained reset -- held through FULL_RET

  // Cycles to hold a response before returning it. Zero is the ordinary
  // single-cycle responder; non-zero is what lets a testbench keep a
  // transaction GENUINELY OUTSTANDING while it asks the gate to quiesce, which
  // is the only way PCSA 7.2.8's "any outstanding transactions are completed
  // before entering the gated state" can be tested rather than assumed.
  input  logic [7:0] rsp_delay,

  input  tl_h2d_t tl_h2d_i,
  output tl_d2h_t tl_d2h_o
);

  localparam int unsigned AW = $clog2(DEPTH);

  logic [31:0] mem_q [DEPTH];     // non-retained
  logic [31:0] ret_rdata;         // from u_ret, the retained instance

  logic       pend_q;      // a response is being held
  logic [7:0] delay_q;
  wire        delay_done = (delay_q == 8'd0);

  // ---- response registers ----
  logic        d_valid_q;
  tl_d_op_e    d_opcode_q;
  logic [31:0] d_data_q;
  logic [top_pkg::TL_AIW-1:0] d_source_q;
  logic [top_pkg::TL_SZW-1:0] d_size_q;

  // Ready whenever no response is waiting to be taken: one outstanding. Named
  // separately because a_hs needs it and tl_d2h_o is driven by a single
  // always_comb -- mixing an assign to one field with a procedural assignment
  // to the struct is illegal.
  wire a_ready_int = !pend_q && (!d_valid_q || tl_h2d_i.d_ready);

  wire            a_hs   = tl_h2d_i.a_valid && a_ready_int;
  wire            is_wr  = (tl_h2d_i.a_opcode == PutFullData) ||
                           (tl_h2d_i.a_opcode == PutPartialData);
  wire [AW-1:0]   widx   = tl_h2d_i.a_address[AW+1:2];
  // The top word of the map is the retained one, so a testbench can reach both
  // classes of state through the same port.
  wire            is_ret = (tl_h2d_i.a_address[AW+2] == 1'b1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      d_valid_q  <= 1'b0;
      pend_q     <= 1'b0;
      delay_q    <= 8'd0;
      d_opcode_q <= AccessAck;
      d_data_q   <= '0;
      d_source_q <= '0;
      d_size_q   <= '0;
      for (int i = 0; i < DEPTH; i++) mem_q[i] <= '0;
    end else begin
      if (d_valid_q && tl_h2d_i.d_ready) d_valid_q <= 1'b0;

      // Count the hold down, then release the response.
      if (pend_q) begin
        if (delay_done) begin
          pend_q    <= 1'b0;
          d_valid_q <= 1'b1;
        end else begin
          delay_q <= delay_q - 8'd1;
        end
      end

      if (a_hs) begin
        pend_q     <= (rsp_delay != 8'd0);
        delay_q    <= rsp_delay;
        d_valid_q  <= (rsp_delay == 8'd0);
        d_source_q <= tl_h2d_i.a_source;
        d_size_q   <= tl_h2d_i.a_size;
        d_opcode_q <= is_wr ? AccessAck : AccessAckData;
        if (is_wr) begin
          if (!is_ret) mem_q[widx] <= tl_h2d_i.a_data;
        end else begin
          d_data_q <= is_ret ? ret_rdata : mem_q[widx];
        end
      end
    end
  end

  // The retained register lives in its own instance so upf/*.upf can name it in
  // a set_retention strategy. See acg_resp_ret.
  acg_resp_ret u_ret (
    .clk      (clk),
    .ret_rst_n(ret_rst_n),
    .we       (a_hs && is_wr && is_ret),
    .wdata    (tl_h2d_i.a_data),
    .rdata    (ret_rdata)
  );

  always_comb begin
    tl_d2h_o          = TL_D2H_DEFAULT;
    tl_d2h_o.a_ready  = a_ready_int;
    tl_d2h_o.d_valid  = d_valid_q;
    tl_d2h_o.d_opcode = d_opcode_q;
    tl_d2h_o.d_size   = d_size_q;
    tl_d2h_o.d_source = d_source_q;
    tl_d2h_o.d_data   = d_data_q;
    tl_d2h_o.d_error  = 1'b0;
  end

endmodule
