`timescale 1ns/1ps
// The retained half of acg_resp_tlul, as a separate module.
//
// A SEPARATE MODULE FOR THE SAME REASON ppu_ip_ret is one: UPF's set_retention
// names INSTANCES, so the boundary between retained and non-retained state has
// to be a structural fact a reader can see in the hierarchy rather than a
// naming convention the element list has to track.
//
// Nothing else is different about it. One register, its own reset, written from
// the TL-UL write path when the retained address is targeted.

module acg_resp_ret (
  input  logic        clk,
  input  logic        ret_rst_n,   // held through FULL_RET, unlike rst_n
  input  logic        we,
  input  logic [31:0] wdata,
  output logic [31:0] rdata
);

  logic [31:0] ret_q;

  always_ff @(posedge clk or negedge ret_rst_n) begin
    if (!ret_rst_n) ret_q <= '0;
    else if (we)    ret_q <= wdata;
  end

  assign rdata = ret_q;

endmodule
