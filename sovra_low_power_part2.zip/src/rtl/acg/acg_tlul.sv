`timescale 1ns/1ps
// Access control gate for a TL-UL port. PCSA (DEN 0050 D) Section 7.2.8.
//
// Drop this between any TL-UL host and a device that can power down. The host
// side is unaware; the device side is protected. Control is a single Q-Channel,
// driven by the PPU of the domain being protected.
//
//      host (upstream, stays powered)        device (downstream, can power off)
//            tl_h2d_i  ----->  [ acg_tlul ]  ----->  tl_h2d_o
//            tl_d2h_o  <-----                <-----  tl_d2h_i
//                                  ^
//                              Q-Channel from the protected domain's PPU
//
// -----------------------------------------------------------------------------
// THE DATA PATH IS VENDORED AND UNMODIFIED
//
// vendor/opentitan/tlul/tlul_lc_gate.sv does the gating, the draining and the
// error responses. It is not forked, not edited, and not reimplemented, and
// vendor/opentitan/README.md records the revision.
//
// What this file adds is the wiring that turns it into a PCSA access control
// gate, and the one signal it lacks. From the vendored gate:
//
//   flush_req_i / flush_ack_o   drain, then block -- 7.2.8's capability 1
//   block_cmd (internal)        the STALL, with no error response
//   lc_en_i                     the independent ERROR path
//   resp_pending_o              transactions still outstanding downstream
//
// Missing, and supplied here: nothing reports a transaction BLOCKED AT THE
// INPUT. 7.2.8's stall-and-wake needs "a wake-up signal ... indicating that the
// downstream power domain must be made available", and the condition is
// visible on the gate's own pins:
//
//   host_blocked = tl_h2d_i.a_valid && !tl_d2h_o.a_ready
//
// which is why no fork was needed.
//
// -----------------------------------------------------------------------------
// D21: THE SCP'S MODE, AND THE RECORD OF AN ERRORED ACCESS
//
// mode_i is acg_ctrl's (its header): DEFAULT, VOTED OFF (error at once) or
// POWERING UP (hold). In VOTED OFF the SCP must learn who touched the domain
// (Proposed_PMU/RPMI_STACK_DECISIONS.md, Section 2.2), so this wrapper keeps
// the first access the gate answered with an error -- its address, its source
// ID and whether it was a write -- and raises err_valid_o, a level, until the
// SCP pulses err_clr_i. Any error the gate itself makes is recorded, in any
// mode: VOTED OFF's, RESP_MODEL = 1's in DEFAULT, and, with the gate open, one
// accepted in the very cycle the SCP moves the gate out of VOTED OFF.
// A second error while it is set raises err_overflow_o and changes nothing
// else.
//
// With the gate closed, leaving VOTED OFF makes the vendored gate walk back to
// StFlush through one cycle in which it neither blocks nor errors (acg_ctrl's
// header). acg_ctrl's hold_o covers that walk, and while it is HIGH this
// wrapper keeps the host's A channel off the gate: a_valid LOW into it,
// a_ready LOW to the host. The access waits, and nothing reaches the domain
// while it is down.
//
// The address comes from the A channel and the error from the D channel, so
// the last accepted request is held and committed when an error response
// leaves. That pairing is exact here because of how the vendored gate errors:
// it drains every outstanding transaction first (StOutstanding) and then
// answers one request at a time from tlul_err_resp. A device's own error
// response is not recorded: it can only arrive while a transaction is
// outstanding, when resp_pending_o is HIGH.
//
// -----------------------------------------------------------------------------
// PLACEMENT
//
// This module belongs in the UPSTREAM power domain, not the one it protects.
// PCSA 7.2.8: "any wake-up logic must always be implemented in the upstream
// power domain" -- a gate inside the domain it protects would lose power with
// it and could neither respond to a transaction nor ask for the domain back.

module acg_tlul
  import tlul_pkg::*;
  import lc_ctrl_pkg::*;
#(
  // PCSA 7.2.8's response models. See acg_ctrl.
  parameter int unsigned RESP_MODEL  = 0,   // 0=STALL_WAKE 1=ERROR
  parameter int unsigned SYNC_STAGES = 2,
  // tlul_lc_gate's outstanding-transaction capacity. ITS DEFAULT IS 3, which is
  // far too small for a memory path behind a NoC -- set it from the real
  // outstanding capability of the host. The vendored gate carries its own
  // assertion on overflow.
  parameter int unsigned Outstanding = 8
) (
  input  logic clk,
  input  logic rst_n,

  // ---- Q-Channel, from the protected domain's PPU ----
  input  logic qreqn,
  output logic qacceptn,
  output logic qdeny,
  output logic qactive,

  // ---- TL-UL, host side (upstream) ----
  input  tl_h2d_t tl_h2d_i,
  output tl_d2h_t tl_d2h_o,

  // ---- TL-UL, device side (downstream, protected) ----
  output tl_h2d_t tl_h2d_o,
  input  tl_d2h_t tl_d2h_i,

  // ---- D21: the SCP's mode, and the record of an errored access ----
  input  logic [1:0]                  mode_i,          // 0 default, 1 voted OFF, 2 powering up
  output logic                        err_valid_o,     // the gate answered an access with an error
  output logic [top_pkg::TL_AW-1:0]   err_addr_o,      // ...the first one's address
  output logic [top_pkg::TL_AIW-1:0]  err_source_o,    // ...its source ID
  output logic                        err_write_o,     // ...and whether it wrote
  output logic                        err_overflow_o,  // another errored while err_valid_o
  input  logic                        err_clr_i,       // one-cycle pulse: clear the record

  // ---- Observability ----
  output logic gated_o,          // gated and drained: safe to power down
  output logic gate_err_o        // the gate produced a bus error
);

  logic flush_req, flush_ack, resp_pending, err_sel, hold;

  // "A transaction is being stalled." Combinational, from the gate's own pins.
  // a_valid asserted with a_ready withheld IS the stall -- TL-UL has no other
  // way to express it, and it is exactly what the host sees.
  wire host_blocked = tl_h2d_i.a_valid && !tl_d2h_o.a_ready;

  acg_ctrl #(
    .RESP_MODEL (RESP_MODEL),
    .SYNC_STAGES(SYNC_STAGES)
  ) u_ctrl (
    .clk   (clk),
    .rst_n (rst_n),
    .qreqn (qreqn),
    .qacceptn(qacceptn),
    .qdeny   (qdeny),
    .qactive (qactive),

    .flush_req_o   (flush_req),
    .flush_ack_i   (flush_ack),
    .resp_pending_i(resp_pending),
    .host_blocked_i(host_blocked),
    .mode_i        (mode_i),
    .gate_err_o    (err_sel),
    .hold_o        (hold),
    .gated_o       (gated_o)
  );

  // The host's A channel, kept off the gate while acg_ctrl holds it (see the
  // header). Nothing else is touched: responses already owed still flow.
  tl_h2d_t h2d_gate;
  tl_d2h_t d2h_gate;
  always_comb begin
    h2d_gate = tl_h2d_i;
    tl_d2h_o = d2h_gate;
    if (hold) begin
      h2d_gate.a_valid = 1'b0;
      tl_d2h_o.a_ready = 1'b0;
    end
  end

  // lc_en_i: On means "pass through", Off means "answer with a bus error".
  // It is independent of flush_req, which is what lets one module serve both of
  // PCSA's response models -- stall comes from the flush path, error from this
  // one. Held at On for STALL_WAKE so the gate blocks silently.
  lc_tx_t lc_en;
  assign lc_en = err_sel ? Off : On;

  tlul_lc_gate #(
    .NumGatesPerDirection(2),
    .ReturnBlankResp     (1'b0),
    .Outstanding         (Outstanding)
  ) u_gate (
    .clk_i  (clk),
    .rst_ni (rst_n),
    .tl_h2d_i(h2d_gate),
    .tl_d2h_o(d2h_gate),
    .tl_h2d_o(tl_h2d_o),
    .tl_d2h_i(tl_d2h_i),
    .flush_req_i   (flush_req),
    .flush_ack_o   (flush_ack),
    .resp_pending_o(resp_pending),
    .lc_en_i (lc_en),
    .err_o   (gate_err_o)
  );

  // ---- D21: the record (see the header) ----
  logic [top_pkg::TL_AW-1:0]  last_addr_q;
  logic [top_pkg::TL_AIW-1:0] last_src_q;
  logic                       last_wr_q;
  logic                       a_ack, errored;

  assign a_ack   = tl_h2d_i.a_valid && tl_d2h_o.a_ready;
  assign errored = tl_d2h_o.d_valid && tl_h2d_i.d_ready && tl_d2h_o.d_error &&
                   !resp_pending;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      last_addr_q    <= '0;
      last_src_q     <= '0;
      last_wr_q      <= 1'b0;
      err_valid_o    <= 1'b0;
      err_addr_o     <= '0;
      err_source_o   <= '0;
      err_write_o    <= 1'b0;
      err_overflow_o <= 1'b0;
    end else begin
      if (a_ack) begin
        last_addr_q <= tl_h2d_i.a_address;
        last_src_q  <= tl_h2d_i.a_source;
        last_wr_q   <= (tl_h2d_i.a_opcode != Get);
      end
      if (err_clr_i) begin
        err_valid_o    <= 1'b0;
        err_overflow_o <= 1'b0;
      end else if (errored) begin
        if (!err_valid_o) begin
          err_valid_o  <= 1'b1;
          err_addr_o   <= last_addr_q;
          err_source_o <= last_src_q;
          err_write_o  <= last_wr_q;
        end else begin
          err_overflow_o <= 1'b1;
        end
      end
    end
  end

endmodule
