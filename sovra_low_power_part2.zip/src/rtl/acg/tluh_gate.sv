`timescale 1ns/1ps
// The TL-UH data path of an access control gate: drain, block, and answer
// with errors, a MESSAGE at a time. PCSA (DEN 0050D) Section 7.2.8.
//
// rtl/acg/acg_tlul.sv gates TL-UL with OpenTitan's tlul_lc_gate, unmodified.
// That gate cannot carry TL-UH: OpenTitan's TL-UL has one beat per message
// and no atomics, and its outstanding counter and error responder
// (tlul_err_resp) count and answer beats as messages. No open-source TL-UH
// gate exists in SystemVerilog (rocket-chip's TileLink widgets are Chisel
// and have no power gating), so this module is GLUE, written to present
// exactly tlul_lc_gate's control interface to the unmodified acg_ctrl:
//
//   flush_req_i / flush_ack_o   drain, then block new messages (stall path)
//   err_en_i                    the error path (tlul_lc_gate's lc_en_i Off)
//   resp_pending_o              messages still owed by the device
//
// THE THREE RULES, all at MESSAGE boundaries (tl_beat_cnt):
//
//   1. A burst in progress completes. Where a message goes -- the device or
//      the error responder -- is decided at its FIRST beat and held to its
//      last (route_q). A flush or an error request that arrives mid-burst
//      waits for the burst; the device never sees a partial message, and the
//      error responder never gets the tail of one the device got the head of.
//   2. Every beat of a denied message is answered. The error responder
//      accepts all the A beats of a message (a PutFullData, PutPartialData,
//      ArithmeticData or LogicalData burst), then sends the D message the
//      request is owed (tluh_pkg::a_resp_op) with every beat d_denied = 1:
//      one AccessAck for a Put, one HintAck for a Hint, and 2^(size - log2
//      beat bytes) beats of AccessAckData for a Get or an atomic, each with
//      d_corrupt = 1 as well (a denied AccessAckData carries no valid data).
//   3. Atomics are messages like any other: ArithmeticData and LogicalData
//      carry A data and are answered with AccessAckData (tl_pkg.sv:38-39,
//      vendor/sovra_tl), so both their request and their response may be
//      bursts, and they count as one outstanding message from the first A
//      beat to the last D beat. Their a_param (the atomic, tl_pkg.sv:95-103)
//      passes through untouched.
//
// THE DEVICE'S MESSAGES. dev_out_q counts device messages from the first A
// beat to the last D beat (each D message answers exactly one A message on a
// TL-UH link). A new message is routed to the device only while there is no
// flush or error request, the error responder is idle (so the two never share
// the D channel), and dev_out_q < OUTSTANDING. It is routed to the error
// responder only once err_en_i is HIGH and the device owes nothing.
//
// A-channel opcodes 6 and 7 (AcquireBlock, AcquirePerm; tl_pkg.sv:42-43) are
// TL-C, never TL-UH: a simulation assertion flags one, and if the error path
// meets one it answers a single denied AccessAck.
//
// Encodings: vendor/sovra_tl/tl_pkg.sv only (the SoC's rocket-chip
// Bundles.scala, lines given there).

module tluh_gate
  import tl_pkg::*;
  import tluh_pkg::*;
#(
  parameter int unsigned AW          = 32,
  parameter int unsigned DW          = 64,
  parameter int unsigned SRCW        = 8,
  parameter int unsigned SINKW       = 1,
  parameter int unsigned SZW         = 4,
  parameter int unsigned OUTSTANDING = 16,   // device messages in flight at most
  localparam int unsigned BW         = DW / 8
) (
  input  logic             clk_i,
  input  logic             rst_ni,

  // ---- Host side (upstream, stays powered) ----
  input  logic             a_valid_i,
  output logic             a_ready_o,
  input  logic [2:0]       a_opcode_i,
  input  logic [2:0]       a_param_i,
  input  logic [SZW-1:0]   a_size_i,
  input  logic [SRCW-1:0]  a_source_i,
  input  logic [AW-1:0]    a_address_i,
  input  logic [BW-1:0]    a_mask_i,
  input  logic [DW-1:0]    a_data_i,
  input  logic             a_corrupt_i,
  output logic             d_valid_o,
  input  logic             d_ready_i,
  output logic [2:0]       d_opcode_o,
  output logic [1:0]       d_param_o,
  output logic [SZW-1:0]   d_size_o,
  output logic [SRCW-1:0]  d_source_o,
  output logic [SINKW-1:0] d_sink_o,
  output logic             d_denied_o,
  output logic [DW-1:0]    d_data_o,
  output logic             d_corrupt_o,

  // ---- Device side (downstream, protected) ----
  output logic             dev_a_valid_o,
  input  logic             dev_a_ready_i,
  output logic [2:0]       dev_a_opcode_o,
  output logic [2:0]       dev_a_param_o,
  output logic [SZW-1:0]   dev_a_size_o,
  output logic [SRCW-1:0]  dev_a_source_o,
  output logic [AW-1:0]    dev_a_address_o,
  output logic [BW-1:0]    dev_a_mask_o,
  output logic [DW-1:0]    dev_a_data_o,
  output logic             dev_a_corrupt_o,
  input  logic             dev_d_valid_i,
  output logic             dev_d_ready_o,
  input  logic [2:0]       dev_d_opcode_i,
  input  logic [1:0]       dev_d_param_i,
  input  logic [SZW-1:0]   dev_d_size_i,
  input  logic [SRCW-1:0]  dev_d_source_i,
  input  logic [SINKW-1:0] dev_d_sink_i,
  input  logic             dev_d_denied_i,
  input  logic [DW-1:0]    dev_d_data_i,
  input  logic             dev_d_corrupt_i,

  // ---- Control: tlul_lc_gate's, as acg_ctrl drives it ----
  input  logic             flush_req_i,
  input  logic             err_en_i,
  output logic             flush_ack_o,
  output logic             resp_pending_o,

  // ---- Status ----
  output logic             a_busy_o,         // a host message is part-way through its A beats
  output logic             host_blocked_o,   // a NEW message is presented and not taken
  output logic             err_o,            // an error D beat is accepted this cycle
  output logic             err_msg_o,        // ...and it is the first beat of its message
  output logic [AW-1:0]    err_addr_o,       // the errored message's address, source, and
  output logic [SRCW-1:0]  err_source_o,     //   whether it writes (not Get, not Hint);
  output logic             err_write_o       //   held from its first A beat
);

  localparam int unsigned LOG2_BYTES = $clog2(BW);
  localparam int unsigned CNT_W      = 10;
  localparam int unsigned OUT_W      = $clog2(OUTSTANDING + 1);

  typedef enum logic [1:0] {R_NONE, R_DEV, R_ERR} route_e;
  typedef enum logic [1:0] {E_IDLE, E_ABSORB, E_RESP} er_e;

  // ---------------------------------------------------------------------------
  // The host's A channel: boundaries and the route
  // ---------------------------------------------------------------------------
  logic             a_fire, a_first, a_last, a_busy;
  logic [CNT_W-1:0] a_nb;
  route_e           route_q, route_now;
  er_e              er_q;
  logic [OUT_W-1:0] dev_out_q;
  logic             dev_drained, to_dev_ok, to_err_ok;

  assign a_nb = CNT_W'(beats(int'(a_size_i), a_has_data(a_opcode_i), LOG2_BYTES));

  tl_beat_cnt #(.CNT_W(CNT_W)) u_a (
    .clk_i(clk_i), .rst_ni(rst_ni), .fire_i(a_fire), .nbeats_i(a_nb),
    .first_o(a_first), .last_o(a_last), .busy_o(a_busy));

  assign dev_drained = (dev_out_q == '0) && !(a_busy && route_q == R_DEV);
  assign to_dev_ok   = !flush_req_i && !err_en_i && (er_q == E_IDLE) &&
                       (dev_out_q < OUT_W'(OUTSTANDING));
  assign to_err_ok   = err_en_i && dev_drained && (er_q == E_IDLE);

  // Rule 1: a message in progress keeps the route of its first beat.
  // NEGATIVE CONTROL (acgtluh, ACG_TLUH_MUT_SPLIT): the route is decided again
  // at every beat, so a flush or an error request splits a burst.
  always_comb begin
`ifdef ACG_TLUH_MUT_SPLIT
    if (to_err_ok)      route_now = R_ERR;
    else if (to_dev_ok) route_now = R_DEV;
    else                route_now = R_NONE;
`else
    if (a_busy)         route_now = route_q;
    else if (to_err_ok) route_now = R_ERR;
    else if (to_dev_ok) route_now = R_DEV;
    else                route_now = R_NONE;
`endif
  end

  logic er_a_ready;
  assign er_a_ready = (er_q == E_IDLE) || (er_q == E_ABSORB);

  assign a_ready_o = (route_now == R_DEV) ? dev_a_ready_i :
                     (route_now == R_ERR) ? er_a_ready    : 1'b0;
  assign a_fire    = a_valid_i && a_ready_o;

  assign dev_a_valid_o   = a_valid_i && (route_now == R_DEV);
  assign dev_a_opcode_o  = a_opcode_i;
  assign dev_a_param_o   = a_param_i;
  assign dev_a_size_o    = a_size_i;
  assign dev_a_source_o  = a_source_i;
  assign dev_a_address_o = a_address_i;
  assign dev_a_mask_o    = a_mask_i;
  assign dev_a_data_o    = a_data_i;
  assign dev_a_corrupt_o = a_corrupt_i;

  assign a_busy_o       = a_busy;
  assign host_blocked_o = a_valid_i && !a_ready_o && !a_busy;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)                    route_q <= R_NONE;
    else if (a_fire && a_first)     route_q <= a_last ? R_NONE : route_now;
    else if (a_fire && a_last)      route_q <= R_NONE;
  end

  // ---------------------------------------------------------------------------
  // The device's messages: first A beat to last D beat
  // ---------------------------------------------------------------------------
  logic             dd_fire, dd_first, dd_last, dd_busy, dev_a_first_fire;
  logic [CNT_W-1:0] dd_nb;
  logic             er_resp;

  assign er_resp       = (er_q == E_RESP);
  assign dev_d_ready_o = d_ready_i && !er_resp;
  assign dd_fire       = dev_d_valid_i && dev_d_ready_o;
  assign dd_nb         = CNT_W'(beats(int'(dev_d_size_i), d_has_data(dev_d_opcode_i), LOG2_BYTES));

  tl_beat_cnt #(.CNT_W(CNT_W)) u_dd (
    .clk_i(clk_i), .rst_ni(rst_ni), .fire_i(dd_fire), .nbeats_i(dd_nb),
    .first_o(dd_first), .last_o(dd_last), .busy_o(dd_busy));

  assign dev_a_first_fire = a_fire && a_first && (route_now == R_DEV);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) dev_out_q <= '0;
    else         dev_out_q <= dev_out_q + OUT_W'(dev_a_first_fire) - OUT_W'(dd_fire && dd_last);
  end

  assign resp_pending_o = !dev_drained;
  assign flush_ack_o    = flush_req_i && !err_en_i && dev_drained;

  // ---------------------------------------------------------------------------
  // The error responder (rule 2)
  // ---------------------------------------------------------------------------
  logic [2:0]       er_op_q;
  logic [SZW-1:0]   er_size_q;
  logic [SRCW-1:0]  er_src_q;
  logic [CNT_W-1:0] er_left_q, er_nb;
  logic             er_fire, er_d_fire, er_first_beat_q;
  logic [2:0]       er_rsp_op;

  assign er_fire   = a_fire && (route_now == R_ERR);
  assign er_rsp_op = a_resp_op(er_op_q);
  assign er_d_fire = er_resp && d_ready_i;

  // The response's beats, from the request's opcode and size. NEGATIVE
  // CONTROL (acgtluh, ACG_TLUH_MUT_ONEBEAT): one beat whatever the request.
`ifdef ACG_TLUH_MUT_ONEBEAT
  assign er_nb = CNT_W'(1);
`else
  assign er_nb = CNT_W'(beats(int'(a_size_i), d_has_data(a_resp_op(a_opcode_i)), LOG2_BYTES));
`endif

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      er_q            <= E_IDLE;
      er_op_q         <= '0;
      er_size_q       <= '0;
      er_src_q        <= '0;
      er_left_q       <= '0;
      er_first_beat_q <= 1'b0;
      err_addr_o      <= '0;
      err_source_o    <= '0;
      err_write_o     <= 1'b0;
    end else begin
      unique case (er_q)
        E_IDLE: if (er_fire) begin
          er_op_q         <= a_opcode_i;
          er_size_q       <= a_size_i;
          er_src_q        <= a_source_i;
          er_left_q       <= er_nb;
          er_first_beat_q <= 1'b1;
          err_addr_o      <= a_address_i;
          err_source_o    <= a_source_i;
          err_write_o     <= (a_opcode_i != TL_A_GET) && (a_opcode_i != TL_A_HINT);
          er_q            <= a_last ? E_RESP : E_ABSORB;
        end
        E_ABSORB: if (er_fire && a_last) er_q <= E_RESP;
        E_RESP: if (er_d_fire) begin
          er_first_beat_q <= 1'b0;
          er_left_q       <= er_left_q - CNT_W'(1);
          if (er_left_q == CNT_W'(1)) er_q <= E_IDLE;
        end
        default: er_q <= E_IDLE;
      endcase
    end
  end

  assign err_o     = er_d_fire;
  assign err_msg_o = er_d_fire && er_first_beat_q;

  // ---------------------------------------------------------------------------
  // The host's D channel: the error responder's beats, else the device's
  // ---------------------------------------------------------------------------
  always_comb begin
    if (er_resp) begin
      d_valid_o   = 1'b1;
      d_opcode_o  = er_rsp_op;
      d_param_o   = 2'b00;
      d_size_o    = er_size_q;
      d_source_o  = er_src_q;
      d_sink_o    = '0;
      d_denied_o  = 1'b1;
      d_data_o    = '0;
      d_corrupt_o = d_has_data(er_rsp_op);
    end else begin
      d_valid_o   = dev_d_valid_i;
      d_opcode_o  = dev_d_opcode_i;
      d_param_o   = dev_d_param_i;
      d_size_o    = dev_d_size_i;
      d_source_o  = dev_d_source_i;
      d_sink_o    = dev_d_sink_i;
      d_denied_o  = dev_d_denied_i;
      d_data_o    = dev_d_data_i;
      d_corrupt_o = dev_d_corrupt_i;
    end
  end

  // ---------------------------------------------------------------------------
  // Simulation checks: TL-C requests on a TL-UH link, and the counter
  // ---------------------------------------------------------------------------
`ifndef SYNTHESIS
  always @(posedge clk_i)
    if (rst_ni) begin
      if (a_valid_i && !is_tluh_a(a_opcode_i))
        $error("tluh_gate: A-channel opcode %0d is TL-C (Acquire), not TL-UH", a_opcode_i);
      if (dd_fire && dd_first && dev_out_q == '0)
        $error("tluh_gate: a D message from the device with no message outstanding");
    end
`endif

endmodule
