# Access control gate: the run-time mode of decision D21

`acg_tlul` (with `acg_ctrl`) is PCSA 7.2.8's access control gate around
OpenTitan's `tlul_lc_gate`, unmodified; the headers of the two files explain
the gate. This note covers only the mode added for decision D21 of
[`Proposed_PMU/RPMI_STACK_DECISIONS.md`](../../../Proposed_PMU/RPMI_STACK_DECISIONS.md),
which no open-source gate offers: an access to a DSP or NPU the AP voted OFF
is a software bug, answered at once with an error and reported to the SCP.

## The mode

`mode_i` is set by the SCP, per gate (one gate per domain), in the gate's
clock domain.

| `mode_i` | Name | An access | QACTIVE (wake) | The PPU's quiescence request |
|---|---|---|---|---|
| 0 (and 3) | DEFAULT | as `RESP_MODEL` says: stall and wake (0) or error when gated (1). Unchanged | as before | accepted once drained, as before |
| 1 | VOTED OFF | answered at once with a bus error, **whether or not the domain is down yet**: the vote is what makes it a bug | never | accepted once drained, so the domain can go down under the errors |
| 2 | POWERING UP | held until the domain is ON and the PPU opens the gate | never: the SCP is already powering the domain up, and it never does so for an access | as DEFAULT's stall path |

VOTED OFF uses the vendored gate's `lc_en` error path, so outstanding
transactions drain before the first error. With the gate open, a request
accepted in the very cycle the SCP moves the gate out of VOTED OFF may still be
answered by the error responder.

## Leaving VOTED OFF with the gate closed

The vendored gate has no way from its error state back to its closed one.
Released from the error path it walks `StError` → `StErrorOutstanding` →
`StActive` → `StOutstanding` → `StFlush`, and in `StActive` it neither blocks
nor errors for one cycle (`tlul_lc_gate.sv:180-187, 215-221, 247-251`). With
the domain down, that is D21's power-up step (VOTED OFF → POWERING UP), or
VOTED OFF → DEFAULT. An access in that cycle would reach the OFF domain, and
if the isolation clamp reads `a_ready = 1` it would be taken and never
answered, leaving the gate in `StOutstanding` for good.

So `acg_ctrl` follows the walk and raises `hold_o` from the cycle the error
path is released until the gate reaches `StFlush`, or the PPU opens it.
`acg_tlul` keeps the host's A channel off the gate while `hold_o` is HIGH:
`a_valid` LOW into it, `a_ready` LOW to the host. The access waits, as the
stall path makes it wait anyway. Until the walk ends `acg_ctrl` keeps the error
path off whatever the mode, so a change back to VOTED OFF during the walk
waits for `StFlush` and then goes straight to `StError`.

With the mode held at DEFAULT the error path is only ever released together
with the PPU's request, so none of this happens: DEFAULT is unchanged.

## The record

In any mode, the first access the gate itself answers with an error is kept:
`err_addr_o`, `err_source_o` (the TL-UL source ID, the requester's identity)
and `err_write_o`, with `err_valid_o` held HIGH as the event until the SCP
pulses `err_clr_i`. A second error while it is HIGH sets `err_overflow_o` and
changes nothing else. A device's own error response is not recorded.

Nothing reads these yet: the SCP's register block for them, and the policy
that sets `mode_i` from the AP's votes, belong to the wake aggregator (build
stage F6) and W4.1. `ppu_acg_pd_top` ties the mode to DEFAULT.

## Checks

`make acg SIM=vcs`, group D of `tb/acg/acg_tlul_tb.sv`: DEFAULT's stall and
wake; VOTED OFF with the domain still up and with it gated, the record,
overflow and clear; POWERING UP holding an access until ON with no wake, and
across a change from VOTED OFF while gated.

D6 and D7 switch the device OFF. It then answers nothing, and its A channel is
a clamp, tried at `a_ready = 1` and at 0. D6 leaves VOTED OFF for POWERING UP
and for DEFAULT with the access presented 0 to 4 cycles after the change. Each
access must be held, never reach the OFF domain, and complete once the domain
is ON, with a wake in DEFAULT only. D7 goes back to VOTED OFF 1 to 4 cycles
into the walk: the access must be answered with an error and recorded.

Checked every cycle: nothing new reaches the device in VOTED OFF; neither D21
mode raises QACTIVE; nothing reaches the domain while it is OFF; and the drain
invariant (gated with no traffic on the device side) holds for this gate in
every mode, as for the other two. Groups A and B, the gate's original checks,
run with the mode tied to DEFAULT.

## The TL-UH gate (platform plan H15, 2026-10-06)

`acg_tluh` is the same gate for a TL-UH port (the SOVRA mesh): the unmodified
`acg_ctrl` over `tluh_gate`, a data path written as glue because no
open-source TL-UH gate exists (OpenTitan's parts are TL-UL, one beat per
message). It decides at message boundaries, so a burst in progress completes
before the gate closes; its error responder answers every beat of a denied
message (one AccessAck for a Put, every beat of AccessAckData, denied and
corrupt, for a Get or an atomic); ArithmeticData and LogicalData are counted
as messages with data and data responses. Opcodes come from the SoC's own
`tl_pkg` (`vendor/sovra_tl`). Under PD5 its stall-and-wake request is the
level `wake_o` (`qactive && gated_o`) for an SCP interrupt input, not a PPU
DEVACTIVE. Checks: `make acgtluh SIM=vcs` (`tb/acg/acg_tluh_tb.sv`, four
mutants).

Files (added 2026-10-06): [`acg_tluh.sv`](acg_tluh.sv), the top (`acg_ctrl`
plus `tluh_gate`, and `wake_o`); [`tluh_gate.sv`](tluh_gate.sv), the TL-UH data
path, which finds message boundaries with `tl_beat_cnt` and `tluh_pkg`
([`../tluh`](../tluh/README.md)). The four mutants of `make acgtluh` are
`ACG_TLUH_MUT_SPLIT` (a burst split by a flush), `..._ONEBEAT` (one error beat
per message), `..._NOWAKE` (no wake line) and `..._ATOM` (atomics counted
without data). Formal: `src/formal/tluh_gate/tluh_gate_props.sv` (`make
vcformal`; 19 assertions proven, SPLIT, ONEBEAT and ATOM each falsify some).
Open sign-off findings (`src/signoff/SIGNOFF_REPORT.md` §6): **F-TLUH-1**,
`dev_a_valid_o` can be withdrawn before the device accepts a first beat when
`flush_req` or `err_en` rises, which TileLink may forbid; **F-TLUH-2**, no
message-size guard (a size of `LOG2_BYTES + 10` or more is truncated by
`tl_beat_cnt`).
