`timescale 1ns/1ps
// Access control gate for a TL-UH port (the SOVRA mesh: bursts and atomics).
// PCSA (DEN 0050D) Section 7.2.8; platform plan H15
// (Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Sections 14.2 and 14.7).
//
//      host (upstream, stays powered)          device (downstream, can power off)
//        a_* / d_*  ─────►  [ acg_tluh ]  ─────►  dev_a_* / dev_d_*
//                               ▲    │
//              Q-Channel from   │    └──► wake_o: the stall-and-wake request,
//              the domain's PPU            a level for an SCP interrupt input
//
// WHAT IS REUSED AND WHAT IS NEW
//
// The control half is acg_ctrl, UNMODIFIED: the same Q-Channel device, the
// same response models, the same D21 run-time mode (DEFAULT, VOTED OFF,
// POWERING UP) and the same walk-back hold as acg_tlul (see acg_ctrl's
// header and README.md). The data path is tluh_gate (glue: no open-source
// TL-UH gate exists), which presents tlul_lc_gate's control interface to it
// and does the TL-UH work: a burst completes before the gate closes, every
// beat of a denied message is answered, and atomics are messages like any
// other (tluh_gate's header). The record of the first errored access is
// acg_tlul's, unchanged in meaning.
//
// THE WAKE IS A LINE INTO THE SCP (PD5)
//
// The PPUs are static-only (PD5), so a DEVQACTIVE into the PPU wakes nothing:
// every power-up is an SCP decision taken on an interrupt. In stall-and-wake
// (RESP_MODEL = 0, mode DEFAULT) a message stalled at the closed gate raises
// wake_o, which goes to one input of the SCP's interrupt block (scp_irq,
// platform plan H9; soc4's acg_wake_i). The firmware's input table maps it to
// "power up this domain" (SCP_ACT_POWER_UP). wake_o is
//
//   wake_o = qactive && gated_o
//
// acg_ctrl's QACTIVE while its Q-Channel is in Q_STOPPED: there dev_busy is
// masked (acg_ctrl), so QACTIVE is exactly the registered "a message is
// stalled at the gate" term, and only in stall-and-wake DEFAULT. It falls
// when the PPU starts the power-up (QREQn HIGH leaves Q_STOPPED), and the
// stalled message proceeds once the gate opens. qactive is still brought out
// for a PPU that uses it.
//
// THE HOLD AT MESSAGE BOUNDARIES ONLY
//
// acg_ctrl's hold_o keeps the host off the gate while the vendored TL-UL gate
// walks back from its error state. tluh_gate has no such walk, so the hold is
// harmless but kept, and applied only between messages: holding a_valid in
// the middle of a burst the device has started could stop the burst that the
// drain is waiting for.
//
// PLACEMENT: in the upstream (always-on) domain, as acg_tlul.

module acg_tluh #(
  parameter int unsigned RESP_MODEL  = 0,   // 0 = STALL_WAKE, 1 = ERROR (acg_ctrl)
  parameter int unsigned SYNC_STAGES = 2,
  parameter int unsigned AW          = 32,
  parameter int unsigned DW          = 64,
  parameter int unsigned SRCW        = 8,
  parameter int unsigned SINKW       = 1,
  parameter int unsigned SZW         = 4,
  parameter int unsigned OUTSTANDING = 16,
  localparam int unsigned BW         = DW / 8
) (
  input  logic             clk,
  input  logic             rst_n,

  // ---- Q-Channel, from the protected domain's PPU ----
  input  logic             qreqn,
  output logic             qacceptn,
  output logic             qdeny,
  output logic             qactive,

  // ---- TL-UH, host side ----
  input  logic             a_valid_i,
  output logic             a_ready_o,
  input  logic [2:0]       a_opcode_i,
  input  logic [2:0]       a_param_i,
  input  logic [SZW-1:0]   a_size_i,
  input  logic [SRCW-1:0]  a_source_i,
  input  logic [AW-1:0]    a_address_i,
  input  logic [BW-1:0]    a_mask_i,
  input  logic [DW-1:0]    a_data_i,
  input  logic             a_corrupt_i,
  output logic             d_valid_o,
  input  logic             d_ready_i,
  output logic [2:0]       d_opcode_o,
  output logic [1:0]       d_param_o,
  output logic [SZW-1:0]   d_size_o,
  output logic [SRCW-1:0]  d_source_o,
  output logic [SINKW-1:0] d_sink_o,
  output logic             d_denied_o,
  output logic [DW-1:0]    d_data_o,
  output logic             d_corrupt_o,

  // ---- TL-UH, device side ----
  output logic             dev_a_valid_o,
  input  logic             dev_a_ready_i,
  output logic [2:0]       dev_a_opcode_o,
  output logic [2:0]       dev_a_param_o,
  output logic [SZW-1:0]   dev_a_size_o,
  output logic [SRCW-1:0]  dev_a_source_o,
  output logic [AW-1:0]    dev_a_address_o,
  output logic [BW-1:0]    dev_a_mask_o,
  output logic [DW-1:0]    dev_a_data_o,
  output logic             dev_a_corrupt_o,
  input  logic             dev_d_valid_i,
  output logic             dev_d_ready_o,
  input  logic [2:0]       dev_d_opcode_i,
  input  logic [1:0]       dev_d_param_i,
  input  logic [SZW-1:0]   dev_d_size_i,
  input  logic [SRCW-1:0]  dev_d_source_i,
  input  logic [SINKW-1:0] dev_d_sink_i,
  input  logic             dev_d_denied_i,
  input  logic [DW-1:0]    dev_d_data_i,
  input  logic             dev_d_corrupt_i,

  // ---- D21: the SCP's mode, and the record of an errored access ----
  input  logic [1:0]       mode_i,          // 0 default, 1 voted OFF, 2 powering up
  output logic             err_valid_o,
  output logic [AW-1:0]    err_addr_o,
  output logic [SRCW-1:0]  err_source_o,
  output logic             err_write_o,
  output logic             err_overflow_o,
  input  logic             err_clr_i,

  // ---- PD5: the stall-and-wake request, to an SCP interrupt input ----
  output logic             wake_o,

  // ---- Observability ----
  output logic             gated_o,
  output logic             gate_err_o       // an error D beat was accepted this cycle
);

  logic flush_req, flush_ack, resp_pending, err_sel, hold;
  logic a_busy, host_blocked, err_msg;
  logic [AW-1:0]   e_addr;
  logic [SRCW-1:0] e_src;
  logic            e_wr;

  acg_ctrl #(
    .RESP_MODEL (RESP_MODEL),
    .SYNC_STAGES(SYNC_STAGES)
  ) u_ctrl (
    .clk           (clk),
    .rst_n         (rst_n),
    .qreqn         (qreqn),
    .qacceptn      (qacceptn),
    .qdeny         (qdeny),
    .qactive       (qactive),
    .flush_req_o   (flush_req),
    .flush_ack_i   (flush_ack),
    .resp_pending_i(resp_pending),
    .host_blocked_i(host_blocked),
    .mode_i        (mode_i),
    .gate_err_o    (err_sel),
    .hold_o        (hold),
    .gated_o       (gated_o)
  );

  // The hold, between messages only (the header).
  logic g_a_valid, g_a_ready, hold_now;
  assign hold_now  = hold && !a_busy;
  assign g_a_valid = a_valid_i && !hold_now;
  assign a_ready_o = g_a_ready && !hold_now;

  tluh_gate #(
    .AW(AW), .DW(DW), .SRCW(SRCW), .SINKW(SINKW), .SZW(SZW), .OUTSTANDING(OUTSTANDING)
  ) u_gate (
    .clk_i          (clk),
    .rst_ni         (rst_n),
    .a_valid_i      (g_a_valid),
    .a_ready_o      (g_a_ready),
    .a_opcode_i     (a_opcode_i),
    .a_param_i      (a_param_i),
    .a_size_i       (a_size_i),
    .a_source_i     (a_source_i),
    .a_address_i    (a_address_i),
    .a_mask_i       (a_mask_i),
    .a_data_i       (a_data_i),
    .a_corrupt_i    (a_corrupt_i),
    .d_valid_o      (d_valid_o),
    .d_ready_i      (d_ready_i),
    .d_opcode_o     (d_opcode_o),
    .d_param_o      (d_param_o),
    .d_size_o       (d_size_o),
    .d_source_o     (d_source_o),
    .d_sink_o       (d_sink_o),
    .d_denied_o     (d_denied_o),
    .d_data_o       (d_data_o),
    .d_corrupt_o    (d_corrupt_o),
    .dev_a_valid_o  (dev_a_valid_o),
    .dev_a_ready_i  (dev_a_ready_i),
    .dev_a_opcode_o (dev_a_opcode_o),
    .dev_a_param_o  (dev_a_param_o),
    .dev_a_size_o   (dev_a_size_o),
    .dev_a_source_o (dev_a_source_o),
    .dev_a_address_o(dev_a_address_o),
    .dev_a_mask_o   (dev_a_mask_o),
    .dev_a_data_o   (dev_a_data_o),
    .dev_a_corrupt_o(dev_a_corrupt_o),
    .dev_d_valid_i  (dev_d_valid_i),
    .dev_d_ready_o  (dev_d_ready_o),
    .dev_d_opcode_i (dev_d_opcode_i),
    .dev_d_param_i  (dev_d_param_i),
    .dev_d_size_i   (dev_d_size_i),
    .dev_d_source_i (dev_d_source_i),
    .dev_d_sink_i   (dev_d_sink_i),
    .dev_d_denied_i (dev_d_denied_i),
    .dev_d_data_i   (dev_d_data_i),
    .dev_d_corrupt_i(dev_d_corrupt_i),
    .flush_req_i    (flush_req),
    .err_en_i       (err_sel),
    .flush_ack_o    (flush_ack),
    .resp_pending_o (resp_pending),
    .a_busy_o       (a_busy),
    .host_blocked_o (host_blocked),
    .err_o          (gate_err_o),
    .err_msg_o      (err_msg),
    .err_addr_o     (e_addr),
    .err_source_o   (e_src),
    .err_write_o    (e_wr)
  );

  // PD5's wake line (the header). NEGATIVE CONTROL (acgtluh,
  // ACG_TLUH_MUT_NOWAKE): no wake line, as if left on the PPU's DEVQACTIVE.
`ifdef ACG_TLUH_MUT_NOWAKE
  assign wake_o = 1'b0;
`else
  assign wake_o = qactive && gated_o;
`endif

  // ---- D21: the record (acg_tlul's, keyed on the first beat of an errored
  //      message rather than on a single-beat response) ----
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_valid_o    <= 1'b0;
      err_addr_o     <= '0;
      err_source_o   <= '0;
      err_write_o    <= 1'b0;
      err_overflow_o <= 1'b0;
    end else if (err_clr_i) begin
      err_valid_o    <= 1'b0;
      err_overflow_o <= 1'b0;
    end else if (err_msg) begin
      if (!err_valid_o) begin
        err_valid_o  <= 1'b1;
        err_addr_o   <= e_addr;
        err_source_o <= e_src;
        err_write_o  <= e_wr;
      end else begin
        err_overflow_o <= 1'b1;
      end
    end
  end

endmodule
