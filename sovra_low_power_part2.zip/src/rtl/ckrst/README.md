# `rtl/ckrst` — the clock/reset request bridge

In SOVRA the SoC's `clkgate` and `tilereset` blocks own each tile's clock and
reset (decision PD8). A PPU's device clock enable and device resets therefore
become **requests** to those blocks, and the blocks acknowledge. The PPU has no
acknowledgement input (DEN 0051E §4.1.5: the spacing between its device
controls is the device control delays, PPU_DCDR0/1, Table 4-5), so the bridge
cannot hold the PPU's sequence. Instead (platform plan H16, F11):

- the **firmware** programs each PPU's DCDR fields to cover the SoC blocks'
  worst-case acknowledgement latency (below);
- the **bridge** forwards every request unchanged and checks every
  acknowledgement. A late, missing or spurious one is a fault: a sticky status
  bit and a level for an SCP interrupt input.

No PPU change: the domain wrappers only bring DEVCLKEN out, resynchronised into
`dclk`, as `dev_clken_req`. One bridge per domain, always-on, beside its
`ppu_axi_dom_top`. Glue: a comparator and a counter per channel, for which no
open-source part exists.

```
 ppu_axi_dom_top                    ┌──── ckrst_bridge ────┐          SoC
   dev_clken_req   (DEVCLKEN) ─────►│ clk_req_o = clken_i  │──► clkgate   (request)
   dev_nret_rst_n, dev_ret_rst_n ──►│ rst_req_no = rst_n_i │──► tilereset (request)
   dev_isolaten    (a "step") ─────►│                      │◄── clk_ack_i, rst_ack_ni
                                    │ per channel: pending │
                                    │  = req != ack        │──► stat_o, fault_o ──► SCP
                                    └──────────────────────┘
```

## Files

| File | What it is |
|---|---|
| [`ckrst_bridge.sv`](ckrst_bridge.sv) | The bridge. Uses `cdc_sync` from [`../common`](../common/README.md) |
| `src/tb/ckrst/soc_ckrst_model.sv` | Testbench model of the SoC's `clkgate` / `tilereset`: configurable latency, a never-acknowledged channel, a spurious clock acknowledgement |
| `src/tb/ckrst/ckrst_bridge_tb.sv` | Unit testbench: the bridge on a real `ppu_dom_top` against the model |

## Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `NUM_RST` | 2 | reset channels, 1 to 3 (the status byte has room for three); anything else is an elaboration `$error` |
| `STEP_W` | 1 | width of `step_i` |
| `STEP_SYNC` | 2 | synchroniser flops on `step_i`. Keep it equal to the depth of DEVCLKEN's own resynchroniser in `ppu_dom_top`, so the spacing the PPU puts between them is kept |
| `ACK_SYNC` | 0 | synchroniser flops on the acknowledgements. 0 when the SoC blocks are on `clk_i`; set 2 when they acknowledge on another clock (sign-off requirement R2). The flops count in the latency the firmware must cover |
| `MAX_WAIT` | 300 | cycles a channel may stay pending before MISSING. Larger than the largest DCDR delay (256 PPU cycles) |

## Ports

| Port | Dir | Meaning |
|---|---|---|
| `clk_i`, `rst_ni` | in | the domain's ungated device clock (`dclk`) and an always-on reset |
| `clken_i` | in | `dev_clken_req`: DEVCLKEN in `dclk` |
| `rst_n_i[NUM_RST-1:0]` | in | the device resets. soc4 connects `{dev_ret_rst_n, dev_nret_rst_n}`, so reset 0 is `dev_nret_rst_n` and reset 1 is `dev_ret_rst_n` |
| `step_i[STEP_W-1:0]` | in | PPU steps the bridge does not forward but must see: `dev_isolaten` (in the PPU's clock; resynchronised here) |
| `clk_req_o` | out | `= clken_i`, combinationally. HIGH asks for the tile clock to run |
| `clk_ack_i` | in | HIGH: the tile clock runs |
| `rst_req_no[NUM_RST-1:0]` | out | `= rst_n_i`, combinationally. LOW asks for reset r asserted |
| `rst_ack_ni[NUM_RST-1:0]` | in | the reset as applied (LOW = asserted) |
| `stat_o[7:0]` | out | the status byte, below |
| `stat_clr_i[7:0]` | in | write-1-to-clear pulses for `stat_o` |
| `fault_o` | out | `|stat_o[2:0]`, a level for an SCP interrupt input |

## Behaviour

**Channels.** Channel 0 is the clock, channels 1 to `NUM_RST` the resets. Each
is a four-phase level handshake: the acknowledgement follows its request. A
channel is **pending** while its (synchronised) acknowledgement differs from
its request. The bridge keeps one-cycle-old copies of the requests, the
acknowledgements and the steps to see edges.

**Status byte** (`stat_o`, registered):

| Bit | Name | Set when |
|---|---|---|
| 0 | LATE | a channel that was already pending, whose request did not change this cycle, sees **another channel's request or a step input change**: the PPU moved on before the acknowledgement. That is a DCDR delay too short for the SoC block, e.g. a reset released before the clock is acknowledged running (CLKEN_RST_DLY), or isolation applied before the clock is acknowledged stopped (CLKEN_ISO_DLY) |
| 1 | MISSING | a channel stays pending, its request unchanged, for `MAX_WAIT` cycles: an acknowledgement that never came |
| 2 | SPURIOUS | an acknowledgement changes with no request change and is left differing from its request: the SoC block gated the clock or moved a reset on its own |
| 3 | — | reserved, 0 |
| 4 | CLK | the event (any of 0-2) was on the clock channel |
| 5 + r | RST r | the event was on reset channel r; bits above `4 + NUM_RST` read 0 |

- Bits [7:0] are sticky until written 1 in `stat_clr_i`. An event in the same
  cycle as its clear wins, so the bit stays set.
- An event is visible in `stat_o` the cycle after it occurs.
- Each channel's wait counter restarts on a request change or when the channel
  is no longer pending, and saturates at `MAX_WAIT`.
- LATE and MISSING share one "flagged" bit per channel, cleared on the next
  request edge: each is flagged at most once per request edge, and a MISSING
  after a LATE on the same edge is not reported (F-CKRST-1).

**Clocks.** All logic is on `clk_i`. `step_i` passes through `STEP_SYNC` flops,
the acknowledgements through `ACK_SYNC` flops (`cdc_sync`).

## The firmware side: DCDR from `.ckrst_lat`

The domain table (`src/pmu/fw/mod/pd.h`, `struct pd_cfg`) has a per-domain
`ckrst_lat`: the SoC blocks' worst-case acknowledgement latency in PPU cycles,
synchronisers included. `pd_dev_delays_of()` in `src/pmu/fw/mod/pd.c` takes
the build's device control delays and raises three of them to at least
`ckrst_lat`, one per step that follows a bridged control:

| DCDR field | Separates | So that |
|---|---|---|
| `CLKEN_RST_DLY` | DEVCLKEN on → resets released | the clock is acknowledged running |
| `CLKEN_ISO_DLY` | DEVCLKEN off → isolation applied | the clock is acknowledged stopped |
| `RST_HWSTAT_DLY` | resets released → PPUHWSTAT updated | the tile is out of reset when ON is reported |

DEN 0051E Table 4-5 gives the minimum separation as the field + 1, so a field
equal to the latency leaves a cycle to spare. `ISO_CLKEN_DLY` (the switch
settling) and `ISO_RST_DLY` pace nothing the bridge forwards and keep the
build's values. `pd_init` programs the result and `pd_dev_delays_ok()` checks
it is in force.

When a bridge faults, `fault_o` raises the SCP input whose action is
`SCP_ACT_CKRST`. The policy (`src/pmu/fw/mod/policy.c`, `in_ckrst`; contract in
`mod/policy.h`) reads every domain's status byte through
`SCP_PLAT_CKRST_STAT(d)`, clears what it read (W1C), logs `FLOG_CLKRST` with
the byte (`mod/flog.h`), drops every agent's vote and any wake vote for the
domain, and puts it in `S4_FAULT` with `PD_E_CLKRST`. The power-off retries
take the domain down and the next ON recovers it.

## In soc4

- One `u_ckrst` in each of `soc4_cpu_dom` and `soc4_acc_dom`, with
  `NUM_RST = 2`, `STEP_W = 1`, `STEP_SYNC = 2`, `ACK_SYNC = 0`, on `clk_i`.
- The requests go out on the `tile_*` ports to the testbench's model; the
  domain's clock and resets still come from its PPU wrapper (the bridges
  observe).
- Status: soc4_ctrl `CKRST_STAT` at 0x030, domain n in bits [8n+7:8n], W1C by
  byte lane. The OR of the four `fault_o` is SCP input 15 (`ckrst_irq`,
  level).
- `ckrst_lat` (`src/soc4/fw/soc4_plat.h`): 2 for CPU0, CPU1 and ACC0, which
  the build's delays already cover (CLKEN_RST_DLY 4, CLKEN_ISO_DLY 2,
  RST_HWSTAT_DLY 2); 6 for ACC1, so its three fields are programmed to 6.

## Tests

| Target | What it checks |
|---|---|
| `make ckrst` | `ckrst_bridge_tb` on a real `ppu_dom_top` against `soc_ckrst_model`, the testbench programming the DCDR fields as the firmware does. Tags: `FWD` (every request forwarded, every cycle), `COVER` (DCDR from L, the SoC within L: no fault over ON/OFF/ON/WARM_RST/ON/OFF), `LATE` (DCDR at defaults with L = 6; DCDR from L with the SoC at 3L; W1C and `fault_o`), `MISSING`, `SPURIOUS`, `DCDR` (read-back). Mutant `CKRST_MUT_NOLATE` (the LATE check removed) must fail `[chk:LATE]` |
| `make soc4ckrst` | The firmware side, step K1 of `soc4_tb`: ACC1's DCDR fields from `ckrst_lat` 6; the model then answers in 30, the bridge flags LATE, the firmware logs CLKRST and FAULT, drops the vote and recovers the domain; back at 6, ON and OFF raise no fault. Every soc4 run also checks the forwarding, and the product run checks the DCDR fields and that no bridge faulted |
| `make soc4neg` | M9 `SOC4_MUT_CKRST_IRQ`: the bridges' faults never reach the SCP; must fail `[chk:CKRST_LOG]` in soc4ckrst |
| `make vcformal` | `src/formal/ckrst_bridge/ckrst_bridge_props.sv` (script `src/signoff/formal/ckrst_bridge.tcl`), `MAX_WAIT = 12` for depth (also proven at 300 with `FV_MAX_WAIT=300`): 47 assertions fully proven, 17 covers hit. Forwarding (`a_fwd_clk`, `a_fwd_rst`); LATE, MISSING and SPURIOUS each flagged exactly when they occur, per channel (`a_late_flag`, `a_miss_seq`, `a_late_only`, ...); sticky, W1C, set wins (`a_sticky`, `a_clear`, `a_set_wins`); `a_fault_def`. `make vcformalneg`: NOLATE falsifies 7 |

## Integration notes and open findings

- Set `ACK_SYNC = 2` if the SoC's `clkgate` / `tilereset` acknowledge on a
  clock other than `clk_i` (requirement R2, `src/signoff/SIGNOFF_REPORT.md`
  §8), and add those flops to `ckrst_lat`.
- `ckrst_lat` must be the real worst case of the SoC blocks; the interface and
  latency are an external dependency owned by the SoC
  (`SOVRA_PCSA_ARCHITECTURE.md` §14.6).
- Sign-off waivers that rest on the bridge's design: LINT-W6 (STARC05-1.3.1.3
  at `u_ckrst/stat_o`: the device resets are sampled as data, by design) and
  RDC-W2 (the PPU's device resets into the bridge).
- **F-CKRST-1** (open): LATE and MISSING share one flagged bit, so a MISSING
  after a LATE on the same request edge is not reported separately.

## References

- ARM DEN 0051E §4.1.5 and Table 4-5 (device control delays), Tables 5-24 and
  5-25 (PPU_DCDR0/1); text in `build/spec_txt/`.
- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.1 (PD8), §14.2 (H16), §14.3
  (F11), §14.4 (V5), §14.7.
- `src/signoff/SIGNOFF_REPORT.md` §4, §5, §6, §8.
