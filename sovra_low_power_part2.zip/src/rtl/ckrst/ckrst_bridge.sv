`timescale 1ns/1ps
// The clock/reset request bridge: a PPU's device clock enable and resets
// forwarded as REQUESTS to the SoC's clkgate / tilereset, which are the
// authority (platform plan PD8, H16, F11; Proposed_PMU/
// SOVRA_PCSA_ARCHITECTURE.md Sections 14.1, 14.2 and 14.7). One per domain,
// always-on, beside its ppu_axi_dom_top. Glue: there is no open-source part
// for this; it is a comparator and a counter per channel.
//
//   ppu_axi_dom_top                 ┌──── ckrst_bridge ────┐          SoC
//     dev_clken_req (DEVCLKEN)  ───►│ clk_req_o = clken_i  │──► clkgate   (request)
//     dev_nret_rst_n, dev_ret_rst_n►│ rst_req_no = rst_n_i │──► tilereset (request)
//     dev_isolaten  (a "step")  ───►│                      │◄── clk_ack_i, rst_ack_ni
//                                   │ per channel: pending │
//                                   │  = req != ack        │──► stat_o, fault_o ──► SCP
//                                   └──────────────────────┘    (soc4_ctrl CKRST_STAT,
//                                                                 scp_irq input)
//
// NO PPU CHANGE. The PPU's device-control outputs have no acknowledgement
// input (DEN 0051E Section 4.1.5: the spacing between them is the device
// control delays, DCDR0/DCDR1, Table 4-5), so the bridge cannot hold the
// PPU's sequence. Instead (the user's choice, Section 14.7 H16/F11):
//
//   - the firmware programs each PPU's DCDR fields to cover the SoC blocks'
//     worst-case acknowledgement latency, a per-domain field of its domain
//     table (mod/pd.h .ckrst_lat; pd.c programs CLKEN_RST_DLY, CLKEN_ISO_DLY
//     and RST_HWSTAT_DLY to at least it);
//   - the bridge forwards every request unchanged, combinationally, and
//     CHECKS each acknowledgement. A late or missing one is a FAULT: a
//     sticky status bit, and fault_o, a level for an SCP interrupt input. The
//     firmware logs it (mod/flog.h FLOG_CLKRST) and puts the domain in FAULT.
//
// THE CHANNELS AND THE PROTOCOL. Channel 0 is the clock (clk_req_o HIGH asks
// for the tile clock to run; clk_ack_i HIGH says it runs), channels 1.. are
// the resets (rst_req_no[r] LOW asks for reset r asserted; rst_ack_ni[r]
// mirrors the reset as applied). Each is a four-phase level handshake: the
// SoC block's acknowledgement follows its request. A channel is PENDING while
// its acknowledgement differs from its request.
//
// WHAT IS A FAULT (the status bits, per bridge):
//
//   [0] LATE      the PPU moved on while a channel was pending: another
//                 channel's request changed, or a step input did (the
//                 isolation control, which follows the clock disable by
//                 CLKEN_ISO_DLY + 1). That is the DCDR delay found too short
//                 for the SoC block: e.g. the reset released before the clock
//                 is acknowledged running (CLKEN_RST_DLY), or isolation applied
//                 before the clock is acknowledged stopped (CLKEN_ISO_DLY)
//   [1] MISSING   a channel pending for MAX_WAIT cycles (larger than the
//                 largest DCDR delay, 256 PPU cycles): an acknowledgement that
//                 never came
//   [2] SPURIOUS  an acknowledgement changed with no request change: the SoC
//                 block gated the clock or moved a reset on its own
//   [3] reserved, 0
//   [4] CLK       ... on the clock channel
//   [5+r] RST r   ... on reset channel r (NUM_RST <= 3)
//
// Bits [7:0] are sticky until written 1 in stat_clr_i (W1C); a new event in
// the cycle of the clear wins. fault_o = |stat_o[2:0]. LATE and MISSING are
// flagged once per request edge.
//
// CLOCK. clk_i is the domain's ungated device clock, dclk (ppu_axi_dom_top's
// dev_clken_req, dev_nret_rst_n and dev_ret_rst_n are all in it). step_i comes
// from the PPU's clock and is resynchronised here with STEP_SYNC flops, the
// same depth as DEVCLKEN's own resynchroniser in ppu_dom_top, so the spacing
// the PPU puts between them is kept. The acknowledgements get ACK_SYNC flops
// (0 if the SoC block is on clk_i), which count in the latency the firmware
// must cover.

module ckrst_bridge #(
  parameter int unsigned NUM_RST   = 2,
  parameter int unsigned STEP_W    = 1,
  parameter int unsigned STEP_SYNC = 2,
  parameter int unsigned ACK_SYNC  = 0,
  parameter int unsigned MAX_WAIT  = 300
) (
  input  logic               clk_i,
  input  logic               rst_ni,

  // ---- The PPU's device controls, as ppu_axi_dom_top brings them out ----
  input  logic               clken_i,       // dev_clken_req: DEVCLKEN in clk_i
  input  logic [NUM_RST-1:0] rst_n_i,       // dev_nret_rst_n, dev_ret_rst_n
  input  logic [STEP_W-1:0]  step_i,        // dev_isolaten (the PPU's clock)

  // ---- The SoC's clkgate and tilereset ----
  output logic               clk_req_o,
  input  logic               clk_ack_i,
  output logic [NUM_RST-1:0] rst_req_no,
  input  logic [NUM_RST-1:0] rst_ack_ni,

  // ---- Status, to the SCP ----
  output logic [7:0]         stat_o,
  input  logic [7:0]         stat_clr_i,    // W1C
  output logic               fault_o
);

  localparam int unsigned NCH = NUM_RST + 1;
  localparam int unsigned WW  = $clog2(MAX_WAIT + 1);

  if (NUM_RST < 1 || NUM_RST > 3) begin : g_bad
    $error("ckrst_bridge: NUM_RST = %0d; the status byte has room for 1 to 3 resets", NUM_RST);
  end

  // Forwarded unchanged (the header).
  assign clk_req_o  = clken_i;
  assign rst_req_no = rst_n_i;

  logic [NCH-1:0]    req, ack, ack_s, req_q, ack_q, pend;
  logic [STEP_W-1:0] step_s, step_q;

  assign req = {rst_n_i, clken_i};
  assign ack = {rst_ack_ni, clk_ack_i};

  cdc_sync #(.WIDTH(NCH), .STAGES(ACK_SYNC), .RESET_VAL(1'b0))
    u_ack_sync (.clk(clk_i), .rst_n(rst_ni), .d(ack), .q(ack_s));
  cdc_sync #(.WIDTH(STEP_W), .STAGES(STEP_SYNC), .RESET_VAL(1'b0))
    u_step_sync (.clk(clk_i), .rst_n(rst_ni), .d(step_i), .q(step_s));

  assign pend = req ^ ack_s;

  logic [NCH-1:0] req_chg, ack_chg, late, miss, spur;
  logic           step_chg;
  assign req_chg  = req ^ req_q;
  assign ack_chg  = ack_s ^ ack_q;
  assign step_chg = |(step_s ^ step_q);

  logic [NCH-1:0][WW-1:0] wait_q;
  logic [NCH-1:0]         flagged_q;      // LATE or MISSING already flagged for this request

  for (genvar c = 0; c < NCH; c++) begin : g_ch
    logic others_moved;
    assign others_moved = step_chg || |(req_chg & ~(NCH'(1) << c));
    // A channel that was pending before this edge and still is.
    assign late[c] = pend[c] && !req_chg[c] && others_moved && !flagged_q[c];
    assign miss[c] = pend[c] && !req_chg[c] && (wait_q[c] == WW'(MAX_WAIT - 1)) && !flagged_q[c];
    // The acknowledgement moved away from an unchanged request.
    assign spur[c] = ack_chg[c] && !req_chg[c] && pend[c];

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        wait_q[c]    <= '0;
        flagged_q[c] <= 1'b0;
      end else if (req_chg[c] || !pend[c]) begin
        wait_q[c]    <= '0;
        flagged_q[c] <= 1'b0;
      end else begin
        if (wait_q[c] != WW'(MAX_WAIT)) wait_q[c] <= wait_q[c] + WW'(1);
        if (late[c] || miss[c])         flagged_q[c] <= 1'b1;
      end
    end
  end

  // The status byte (the header).
  logic [7:0] ev;
  always_comb begin
    ev = '0;
    // NEGATIVE CONTROL (make ckrst, CKRST_MUT_NOLATE): the LATE check removed,
    // so an acknowledgement that arrives after the PPU moved on passes.
`ifndef CKRST_MUT_NOLATE
    ev[0] = |late;
`endif
    ev[1] = |miss;
    ev[2] = |spur;
    for (int c = 0; c < NCH; c++)
      if (late[c] || miss[c] || spur[c]) ev[4 + c] = 1'b1;
`ifdef CKRST_MUT_NOLATE
    for (int c = 0; c < NCH; c++)
      if (late[c] && !miss[c] && !spur[c]) ev[4 + c] = 1'b0;
`endif
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      req_q  <= '0;
      ack_q  <= '0;
      step_q <= '0;
      stat_o <= '0;
    end else begin
      req_q  <= req;
      ack_q  <= ack_s;
      step_q <= step_s;
      stat_o <= (stat_o & ~stat_clr_i) | ev;
    end
  end

  assign fault_o = |stat_o[2:0];

endmodule
