`timescale 1ns/1ps
// TileLink message-shape helpers shared by the TL-UH access gate
// (rtl/acg/tluh_gate.sv) and the READY-bit device adapter
// (rtl/adp/hart_ready_adp.sv).
//
// Every opcode comes from the vendored SOVRA tl_pkg (vendor/sovra_tl/
// tl_pkg.sv, itself annotated with the lines of the SoC's rocket-chip
// tilelink/Bundles.scala it copies). Nothing here defines an encoding; these
// functions only say which messages carry data and how many beats a message
// has:
//
//   A channel  PutFullData, PutPartialData, ArithmeticData, LogicalData carry
//              data (tl_pkg.sv:36-39); Get, Hint (Intent) and the two Acquires
//              do not (tl_pkg.sv:40-43)
//   C channel  ProbeAckData and ReleaseData carry data (tl_pkg.sv:55, 57)
//   D channel  AccessAckData and GrantData carry data (tl_pkg.sv:63, 66)
//   B, E       no data in TL-UH or TL-C as used here (B: Probe only)
//
// A message with data whose size (2^size bytes) exceeds one beat (2^LOG2_BYTES
// bytes) is 2^(size - LOG2_BYTES) beats; every other message is one beat.
// That is the TileLink burst rule the SoC's own client uses (tlc_l1_node.sv
// lines 69-72 in the SoC's CVA6 release, not in this repository:
// /project/sovra/10_design/dsp/release/R02/srcs/cva6/core/cache_subsystem/;
// "A full-line transfer is LINE_W/DATA_W beats ... AcquireBlock places
// ONE A beat (Acquire carries no A data)").

package tluh_pkg;
  import tl_pkg::*;

  // NEGATIVE CONTROL (make acgtluh, ACG_TLUH_MUT_ATOM): the two atomics
  // counted as messages without A data, so a multi-beat atomic is split.
  function automatic bit a_has_data(input logic [2:0] op);
`ifdef ACG_TLUH_MUT_ATOM
    return op == TL_A_PUT_FULL || op == TL_A_PUT_PARTIAL;
`else
    return op == TL_A_PUT_FULL || op == TL_A_PUT_PARTIAL || op == TL_A_ARITH ||
           op == TL_A_LOGICAL;
`endif
  endfunction

  function automatic bit c_has_data(input logic [2:0] op);
    return op == TL_C_PROBE_ACKDATA || op == TL_C_RELEASE_DATA;
  endfunction

  function automatic bit d_has_data(input logic [2:0] op);
    return op == TL_D_ACCESS_ACKDATA || op == TL_D_GRANT_DATA;
  endfunction

  // Beats of a message of 2^size bytes on a channel of 2^log2_bytes bytes.
  function automatic int unsigned beats(input int unsigned size, input bit has_data,
                                        input int unsigned log2_bytes);
    if (!has_data || size <= log2_bytes) return 1;
    return 1 << (size - log2_bytes);
  endfunction

  // The D message a request is answered with, and whether that response
  // carries data: Put -> AccessAck, Get/Arithmetic/Logical -> AccessAckData,
  // Hint -> HintAck (tl_pkg.sv:36-41).
  function automatic logic [2:0] a_resp_op(input logic [2:0] op);
    case (op)
      TL_A_PUT_FULL, TL_A_PUT_PARTIAL:   return TL_D_ACCESS_ACK;
      TL_A_ARITH, TL_A_LOGICAL, TL_A_GET: return TL_D_ACCESS_ACKDATA;
      TL_A_HINT:                         return TL_D_HINT_ACK;
      default:                           return TL_D_ACCESS_ACK;   // not TL-UH: see tluh_gate
    endcase
  endfunction

  function automatic bit is_tluh_a(input logic [2:0] op);
    return op != TL_A_ACQUIRE_BLK && op != TL_A_ACQUIRE_PRM;
  endfunction
endpackage
