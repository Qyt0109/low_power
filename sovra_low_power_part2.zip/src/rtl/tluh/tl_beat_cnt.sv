`timescale 1ns/1ps
// Message boundaries on one TileLink channel: which accepted beat (valid &&
// ready, "fire") is the first of a message and which is the last.
//
// Glue (no open-source part does this for TileLink in SystemVerilog; the
// OpenTitan TL-UL parts vendored here have single-beat messages only). The
// caller says, for the beat on the wires, how many beats its message has
// (tluh_pkg::beats); the count is taken from the FIRST beat and held to the
// last, because TileLink keeps a message's beats contiguous on its channel
// and its size field constant across them. busy_o is HIGH between the first
// and the last beat: a message is in progress.
//
//   fire_i  ──►┌─ tl_beat_cnt ─┐──► first_o  (this fire is a message's first beat)
//   nbeats_i ─►│ left_q        │──► last_o   (this fire is its last beat)
//              └───────────────┘──► busy_o   (first seen, last not yet)

module tl_beat_cnt #(
  parameter int unsigned CNT_W = 10      // beats per message up to 2^CNT_W - 1
) (
  input  logic             clk_i,
  input  logic             rst_ni,
  input  logic             fire_i,
  input  logic [CNT_W-1:0] nbeats_i,     // the message's beats, valid on its first beat
  output logic             first_o,
  output logic             last_o,
  output logic             busy_o
);

  logic [CNT_W-1:0] left_q;              // beats still to come after the last fire; 0: idle

  assign busy_o  = (left_q != '0);
  assign first_o = fire_i && !busy_o;
  assign last_o  = fire_i && (busy_o ? (left_q == CNT_W'(1)) : (nbeats_i <= CNT_W'(1)));

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)        left_q <= '0;
    else if (fire_i) begin
      if (!busy_o)      left_q <= (nbeats_i > CNT_W'(1)) ? nbeats_i - CNT_W'(1) : '0;
      else              left_q <= left_q - CNT_W'(1);
    end
  end

endmodule
