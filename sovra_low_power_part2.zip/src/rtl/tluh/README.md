# `rtl/tluh` — TileLink message-shape helpers

Two small pieces shared by the platform's TileLink glue: the TL-UH access gate
([`../acg/tluh_gate.sv`](../acg/tluh_gate.sv), platform plan H15) and the
READY-bit device adapter ([`../adp/hart_ready_adp.sv`](../adp/README.md), H14).
Both must find where a TileLink message starts and ends, because SOVRA's links
carry multi-beat bursts, and OpenTitan's TL-UL parts (vendored in
`src/vendor/opentitan`) know only single-beat messages.

Nothing here defines an encoding. Every opcode comes from the SoC's own
`tl_pkg`, vendored verbatim in `src/vendor/sovra_tl/tl_pkg.sv` (README there),
which is annotated with the lines of the SoC's rocket-chip
`tilelink/Bundles.scala` it copies.

## Files

| File | Unit | What it is |
|---|---|---|
| [`tluh_pkg.sv`](tluh_pkg.sv) | package `tluh_pkg` | Which messages carry data, how many beats a message has, what a TL-UH request is answered with |
| [`tl_beat_cnt.sv`](tl_beat_cnt.sv) | module `tl_beat_cnt` | On one channel: which accepted beat is a message's first, which its last, and whether a message is in progress |

Compile order (`TLUH_SRCS` in `src/Makefile`):
`src/vendor/sovra_tl/tl_pkg.sv`, `tluh_pkg.sv`, `tl_beat_cnt.sv`.

## `tluh_pkg`

Imports `tl_pkg::*`. All functions are `automatic`.

| Function | Returns |
|---|---|
| `a_has_data(op)` | 1 for the A messages with data: `TL_A_PUT_FULL`, `TL_A_PUT_PARTIAL`, `TL_A_ARITH`, `TL_A_LOGICAL` (`tl_pkg.sv:36-39`). Get, Hint and the two Acquires carry none (`tl_pkg.sv:40-43`) |
| `c_has_data(op)` | 1 for `TL_C_PROBE_ACKDATA` and `TL_C_RELEASE_DATA` (`tl_pkg.sv:55, 57`) |
| `d_has_data(op)` | 1 for `TL_D_ACCESS_ACKDATA` and `TL_D_GRANT_DATA` (`tl_pkg.sv:63, 66`) |
| `beats(size, has_data, log2_bytes)` | the beats of a message of `2^size` bytes on a channel of `2^log2_bytes` bytes: `2^(size - log2_bytes)` for a message with data larger than one beat, otherwise 1 |
| `a_resp_op(op)` | the D opcode a TL-UH request is answered with: Put → `TL_D_ACCESS_ACK`; Get, Arithmetic, Logical → `TL_D_ACCESS_ACKDATA`; Hint → `TL_D_HINT_ACK`; anything else → `TL_D_ACCESS_ACK` (not TL-UH; `tluh_gate` handles it) |
| `is_tluh_a(op)` | 0 for `TL_A_ACQUIRE_BLK` and `TL_A_ACQUIRE_PRM`, 1 otherwise |

B and E carry no data as used here (B: Probe only). The burst rule is the one
the SoC's own client uses (`tlc_l1_node.sv` lines 69-72 in the VtDSP sources,
quoted in the package header; that file is not in this repository).

The encodings `tluh_pkg` and its users rely on, from `tl_pkg.sv`:

| Channel | Opcode | Name in `tl_pkg` |
|---|---|---|
| A | 0 PutFullData, 1 PutPartialData, 2 ArithmeticData, 3 LogicalData, 4 Get, 5 Hint, 6 AcquireBlock, 7 AcquirePerm | `TL_A_PUT_FULL`, `TL_A_PUT_PARTIAL`, `TL_A_ARITH`, `TL_A_LOGICAL`, `TL_A_GET`, `TL_A_HINT`, `TL_A_ACQUIRE_BLK`, `TL_A_ACQUIRE_PRM` |
| B | 6 Probe | `TL_B_PROBE` |
| C | 4 ProbeAck, 5 ProbeAckData, 6 Release, 7 ReleaseData | `TL_C_PROBE_ACK`, `TL_C_PROBE_ACKDATA`, `TL_C_RELEASE`, `TL_C_RELEASE_DATA` |
| D | 0 AccessAck, 1 AccessAckData, 2 HintAck, 4 Grant, 5 GrantData, 6 ReleaseAck | `TL_D_ACCESS_ACK`, `TL_D_ACCESS_ACKDATA`, `TL_D_HINT_ACK`, `TL_D_GRANT`, `TL_D_GRANT_DATA`, `TL_D_RELEASE_ACK` |
| E | no opcode | — |

### Mutant

`ACG_TLUH_MUT_ATOM` (a define, used by `make acgtluh` and `make vcformalneg`)
makes `a_has_data` count only the two Puts, so a multi-beat atomic is split
into one-beat messages. Because the define is in the package, it affects every
user compiled with it; the targets set it only for `tluh_gate`'s runs.

## `tl_beat_cnt`

```
  fire_i  ──►┌─ tl_beat_cnt ─┐──► first_o  (this fire is a message's first beat)
  nbeats_i ─►│ left_q        │──► last_o   (this fire is its last beat)
             └───────────────┘──► busy_o   (first seen, last not yet)
```

| Port / parameter | Meaning |
|---|---|
| `CNT_W` (default 10) | counter width: messages of up to `2^CNT_W - 1` beats |
| `clk_i`, `rst_ni` | the channel's clock and reset |
| `fire_i` | a beat accepted this cycle (`valid && ready`) |
| `nbeats_i` | the message's beats (`tluh_pkg::beats`), sampled on its first beat |
| `first_o` | `fire_i && !busy_o` |
| `last_o` | `fire_i` and either the counter is at its last remaining beat, or (on a first beat) `nbeats_i <= 1` |
| `busy_o` | a message has started and its last beat has not been seen |

The length is taken from the first beat and held to the last, because TileLink
keeps a message's beats contiguous on its channel and its size field constant
across them. `left_q` counts the beats still to come; 0 is idle. An `nbeats_i`
of 0 behaves as 1.

## Users

| User | Instances | Notes |
|---|---|---|
| `tluh_gate` (acg) | `u_a` on the host A channel, `u_dd` on the device D channel; the error responder's message length from `beats(…, d_has_data(a_resp_op(op)), …)`; `is_tluh_a` rejects Acquires | `CNT_W = 10`, `LOG2_BYTES = $clog2(DW/8)` (localparams) |
| `hart_ready_adp` (adp) | `u_a`, `u_d` per port, and `u_c` on a TL-C port | `CNT_W = 10` (`BC_W`); `LOG2_BYTES` a parameter |

## Tests

There is no unit test of this folder alone; it is exercised through its users:

- `make acgtluh` (`tluh_gate`, four mutants including `ACG_TLUH_MUT_ATOM`)
  and `make readyadp` (`hart_ready_adp`, two mutants).
- Formal (`make vcformal`): `src/formal/tluh_gate/tluh_gate_props.sv` checks
  the message boundaries against a reference model that writes every encoding
  out again from `tl_pkg.sv` rather than calling `tluh_pkg`, so a `tluh_pkg`
  mutant changes the design and not the model; `ACG_TLUH_MUT_ATOM` falsifies
  10 of its assertions (`src/signoff/SIGNOFF_REPORT.md` §6).
  `src/formal/hart_ready_adp/hart_ready_adp_props.sv` has its own beat
  counters but takes the message length from `tluh_pkg::beats` and the
  `*_has_data` functions; its helper invariants equate each
  `tl_beat_cnt.left_q` with the model's beats left.

## Integration notes and open findings

- Compile exactly one copy of `tl_pkg`. In a SOVRA build that also compiles
  the VtDSP sources the two are byte-identical; do not compile both
  (`src/vendor/sovra_tl/README.md`).
- **F-TLUH-2** and **F-ADP-1** (open, `SIGNOFF_REPORT.md` §6): neither user
  guards the message size. `beats()` returns `2^(size - log2_bytes)`, which a
  10-bit `nbeats_i` truncates once `size >= log2_bytes + 10`; such a message is
  then counted as one beat (on an 8-byte link: size 13, 8 KiB, or more).
  SOVRA's links carry at most a 64-byte block.
- **F-TLUH-1** (open) is about `tluh_gate`'s `dev_a_valid_o`, not this folder;
  see [`../acg/README.md`](../acg/README.md).

## References

- `src/vendor/sovra_tl/tl_pkg.sv` and README: the encodings, from rocket-chip
  `tilelink/Bundles.scala` (`TLMessages` lines 20-40).
- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.2 (H14, H15) and §14.7.
- `src/signoff/SIGNOFF_REPORT.md` §6.
