`timescale 1ns/1ps
// The READY-bit Q-Channel adapter: the device-side policy of a CPU whose
// core has no WFI output and no bus-drain handshake -- CVA6 (VtCPU, VtDSP)
// and Rocket (the NPU host). One adapter for both (platform plan H14, PD4;
// Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Section 14.7; decisions D17 and D18
// in Proposed_PMU/RPMI_STACK_DECISIONS.md, Section 2.5). Always-on.
//
//   per hart h:                                   ┌────── hart_ready_adp ──────┐
//     sw_set_i[h], sw_clr_i[h] (hart_ready_regs) ─►│ READY[h]  (clear wins)     │──► ready_o[h]
//     scp_clr_i[h]                               ─►│                            │
//     wake_i[h], dom_on_i[h]↑, !hart_rst_ni[h]   ─►│   clears                   │
//   per TileLink port p (observed, never driven): │                            │
//     A, D (and B, C, E on a TL-C port)          ─►│ pending[p], burst[p]       │──► port_idle_o[p]
//                                                 │                            │
//   per hart h, to ppu_axi_dom_top's device side: │ deny = !(READY && !wake && │──► dev_deny_o[h]
//                                                 │          every port idle)  │──► dev_busy_o[h] = 0
//                                                 └────────────────────────────┘
//
// NO CORE CHANGE (D17). CVA6 has no WFI output, and WFI commits while bus
// transactions may still be in flight (RPMI_STACK_DECISIONS.md Section 2.3).
// So the idle condition is software's word plus the bus's evidence:
//
//   READY[h]  set by hart h itself, through its READY register
//             (hart_ready_regs, TL-UL), as its last store before WFI, after
//             cleaning its data cache. Cleared by hardware on
//               - any enabled wake for hart h (wake_i[h], a level: the SoC
//                 PLIC's pending-and-enabled for the hart, its timer and
//                 software interrupts, a debug request -- the integrator ORs
//                 them);
//               - hart h's domain powering back to ON (the rising edge of
//                 dom_on_i[h], PPUHWSTAT's ON bit);
//               - a reset of hart h (hart_rst_ni[h] LOW, for as long as it
//                 lasts);
//               - software (sw_clr_i, a write of 0) and the SCP (scp_clr_i).
//             A clear and a set in the same cycle: the clear wins, so a wake
//             that races the hart's last store leaves READY clear, and the
//             hart's WFI returns at once because the wake is still pending.
//   idle[p]   port p has nothing in flight: no request on its A (or C) wires
//             this cycle, no message part-way through its beats on any
//             channel, and no response owed (below).
//
// THE DECISION (the Q-Channel device side, qchannel_device's contract inside
// ppu_axi_dom_top): a static power-down request is ACCEPTED only while
// READY[h] is set, no wake is pending, and every port of hart h is idle; it
// is DENIED otherwise. dev_busy_o is 0: the adapter never makes the PPU wait,
// it answers at once, and the SCP's policy retries a denial (mod/policy.h,
// deny -> retry -> force). The wake term is combinational, so a wake in the
// very cycle of the request denies it, not only one a cycle earlier.
//
// No hardware wake goes to the PPU (PD5: the PPUs are static-only; a hart's
// wake reaches the SCP as an interrupt input and the SCP powers the domain
// up), so the domain's dev_wake is tied 0 by the integrator.
//
// OUTSTANDING TRANSACTIONS, per port. Every TileLink request message is
// answered by exactly one D message on a TL-UH link; on a TL-C link a Release
// is answered on D too, a Grant must be acknowledged on E, and a Probe on B is
// answered on C. So, counting MESSAGES (tl_beat_cnt finds the first and last
// beat; tluh_pkg::beats the length):
//
//   owed  += first beat of an A message, and of a C Release/ReleaseData
//   owed  -= last beat of a D message
//   grant += last beat of a D Grant/GrantData;      grant -= an E beat
//   probe += a B beat (Probe, one beat);            probe -= last beat of a C
//                                                            ProbeAck/ProbeAckData
//
// and the port is idle when all three are 0, no channel is part-way through a
// message, and neither a_valid nor c_valid is HIGH. PORT_TLC[p] = 0 ties the
// B, C and E terms off. Opcodes: vendor/sovra_tl/tl_pkg.sv (the SoC's
// Bundles.scala, lines given there).
//
// PORT_HART[p] is the hart port p belongs to: a CVA6 VtDSP has two ports for
// one hart (the core's TL-C port and Ara's TL-UH port); a VtCPU cluster one
// per hart. A domain holding several harts ORs their dev_deny_o.
//
// CLOCK. One clock: the always-on clock of the ports' fabric, which in the
// SoC also clocks each domain's Q-Channel device wrapper (ppu_axi_dom_top's
// dclk). A different dclk needs a two-flop synchroniser on dev_deny_o; it is
// stable for the whole Q_REQUEST state anyway.

module hart_ready_adp
  import tl_pkg::*;
  import tluh_pkg::*;
#(
  parameter int unsigned NUM_HARTS = 1,
  parameter int unsigned NUM_PORTS = 1,
  parameter logic [NUM_PORTS-1:0][7:0] PORT_HART = '0,
  parameter logic [NUM_PORTS-1:0]      PORT_TLC  = '0,
  parameter int unsigned SZW       = 4,          // a_size/c_size/d_size width
  parameter int unsigned LOG2_BYTES = 3,         // log2 of the ports' beat bytes
  parameter int unsigned CNT_W     = 6           // outstanding messages per port, at most 2^CNT_W - 1
) (
  input  logic                           clk_i,
  input  logic                           rst_ni,

  // ---- READY: the register block's writes, the SCP's clear, the clears ----
  input  logic [NUM_HARTS-1:0]           sw_set_i,      // hart_ready_regs: a write of 1
  input  logic [NUM_HARTS-1:0]           sw_clr_i,      // hart_ready_regs: a write of 0
  input  logic [NUM_HARTS-1:0]           scp_clr_i,
  input  logic [NUM_HARTS-1:0]           wake_i,        // any enabled wake for the hart (level)
  input  logic [NUM_HARTS-1:0]           dom_on_i,      // the hart's domain is ON (PPUHWSTAT)
  input  logic [NUM_HARTS-1:0]           hart_rst_ni,   // the hart's reset, LOW = in reset
  output logic [NUM_HARTS-1:0]           ready_o,

  // ---- The harts' TileLink ports, observed ----
  input  logic [NUM_PORTS-1:0]           a_valid_i,
  input  logic [NUM_PORTS-1:0]           a_ready_i,
  input  logic [NUM_PORTS-1:0][2:0]      a_opcode_i,
  input  logic [NUM_PORTS-1:0][SZW-1:0]  a_size_i,
  input  logic [NUM_PORTS-1:0]           d_valid_i,
  input  logic [NUM_PORTS-1:0]           d_ready_i,
  input  logic [NUM_PORTS-1:0][2:0]      d_opcode_i,
  input  logic [NUM_PORTS-1:0][SZW-1:0]  d_size_i,
  input  logic [NUM_PORTS-1:0]           b_valid_i,     // TL-C ports only (PORT_TLC)
  input  logic [NUM_PORTS-1:0]           b_ready_i,
  input  logic [NUM_PORTS-1:0]           c_valid_i,
  input  logic [NUM_PORTS-1:0]           c_ready_i,
  input  logic [NUM_PORTS-1:0][2:0]      c_opcode_i,
  input  logic [NUM_PORTS-1:0][SZW-1:0]  c_size_i,
  input  logic [NUM_PORTS-1:0]           e_valid_i,
  input  logic [NUM_PORTS-1:0]           e_ready_i,
  output logic [NUM_PORTS-1:0]           port_idle_o,

  // ---- Per hart: the Q-Channel device side of its domain's PPU ----
  output logic [NUM_HARTS-1:0]           dev_busy_o,    // -> dev_quiescent_busy
  output logic [NUM_HARTS-1:0]           dev_deny_o     // -> dev_quiescent_deny
);

  localparam int unsigned BC_W = 10;

  // ---------------------------------------------------------------------------
  // READY, per hart
  // ---------------------------------------------------------------------------
  logic [NUM_HARTS-1:0] ready_q, on_q, clr, set;

  assign clr = wake_i | (dom_on_i & ~on_q) | ~hart_rst_ni | sw_clr_i | scp_clr_i;
  assign set = sw_set_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ready_q <= '0;
      on_q    <= '0;
    end else begin
      on_q <= dom_on_i;
      for (int h = 0; h < NUM_HARTS; h++) begin
        // A clear wins over a set. NEGATIVE CONTROL (make readyadp,
        // HART_READY_MUT_SETWINS): the set wins.
`ifdef HART_READY_MUT_SETWINS
        if (set[h])      ready_q[h] <= 1'b1;
        else if (clr[h]) ready_q[h] <= 1'b0;
`else
        if (clr[h])      ready_q[h] <= 1'b0;
        else if (set[h]) ready_q[h] <= 1'b1;
`endif
      end
    end
  end

  assign ready_o = ready_q;

  // ---------------------------------------------------------------------------
  // Outstanding messages, per port
  // ---------------------------------------------------------------------------
  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_port
    logic a_fire, a_first, a_last, a_busy;
    logic d_fire, d_first, d_last, d_busy;
    logic c_fire, c_first, c_last, c_busy, b_fire, e_fire;
    logic [CNT_W-1:0] owed_q, grant_q, probe_q;

    assign a_fire = a_valid_i[p] && a_ready_i[p];
    assign d_fire = d_valid_i[p] && d_ready_i[p];

    tl_beat_cnt #(.CNT_W(BC_W)) u_a (
      .clk_i(clk_i), .rst_ni(rst_ni), .fire_i(a_fire),
      .nbeats_i(BC_W'(beats(int'(a_size_i[p]), a_has_data(a_opcode_i[p]), LOG2_BYTES))),
      .first_o(a_first), .last_o(a_last), .busy_o(a_busy));

    tl_beat_cnt #(.CNT_W(BC_W)) u_d (
      .clk_i(clk_i), .rst_ni(rst_ni), .fire_i(d_fire),
      .nbeats_i(BC_W'(beats(int'(d_size_i[p]), d_has_data(d_opcode_i[p]), LOG2_BYTES))),
      .first_o(d_first), .last_o(d_last), .busy_o(d_busy));

    if (PORT_TLC[p]) begin : g_tlc
      assign b_fire = b_valid_i[p] && b_ready_i[p];
      assign c_fire = c_valid_i[p] && c_ready_i[p];
      assign e_fire = e_valid_i[p] && e_ready_i[p];
      tl_beat_cnt #(.CNT_W(BC_W)) u_c (
        .clk_i(clk_i), .rst_ni(rst_ni), .fire_i(c_fire),
        .nbeats_i(BC_W'(beats(int'(c_size_i[p]), c_has_data(c_opcode_i[p]), LOG2_BYTES))),
        .first_o(c_first), .last_o(c_last), .busy_o(c_busy));
    end else begin : g_tluh
      assign b_fire = 1'b0;
      assign c_fire = 1'b0;
      assign e_fire = 1'b0;
      assign c_first = 1'b0;
      assign c_last  = 1'b0;
      assign c_busy  = 1'b0;
    end

    logic c_is_rel, c_is_pack, d_is_grant;
    assign c_is_rel   = (c_opcode_i[p] == TL_C_RELEASE) || (c_opcode_i[p] == TL_C_RELEASE_DATA);
    assign c_is_pack  = (c_opcode_i[p] == TL_C_PROBE_ACK) || (c_opcode_i[p] == TL_C_PROBE_ACKDATA);
    assign d_is_grant = (d_opcode_i[p] == TL_D_GRANT) || (d_opcode_i[p] == TL_D_GRANT_DATA);

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        owed_q  <= '0;
        grant_q <= '0;
        probe_q <= '0;
      end else begin
        owed_q  <= owed_q + CNT_W'(a_fire && a_first) + CNT_W'(c_fire && c_first && c_is_rel)
                          - CNT_W'(d_fire && d_last);
        grant_q <= grant_q + CNT_W'(d_fire && d_last && d_is_grant) - CNT_W'(e_fire);
        probe_q <= probe_q + CNT_W'(b_fire) - CNT_W'(c_fire && c_last && c_is_pack);
      end
    end

    assign port_idle_o[p] = (owed_q == '0) && (grant_q == '0) && (probe_q == '0) &&
                            !a_busy && !d_busy && !c_busy && !a_valid_i[p] &&
                            !(PORT_TLC[p] && c_valid_i[p]);

`ifndef SYNTHESIS
    always @(posedge clk_i)
      if (rst_ni && d_fire && d_first && owed_q == '0 && !(a_fire && a_first))
        $error("hart_ready_adp: port %0d, a D message with nothing owed", p);
`endif
  end

  // ---------------------------------------------------------------------------
  // The decision, per hart
  // ---------------------------------------------------------------------------
  logic [NUM_HARTS-1:0] drained;
  always_comb begin
    drained = '1;
    for (int p = 0; p < NUM_PORTS; p++)
      if (PORT_HART[p] < NUM_HARTS && !port_idle_o[p]) drained[PORT_HART[p]] = 1'b0;
  end

  assign dev_busy_o = '0;
  // NEGATIVE CONTROL (make readyadp, HART_READY_MUT_NODRAIN): the ports'
  // outstanding transactions are not looked at.
`ifdef HART_READY_MUT_NODRAIN
  assign dev_deny_o = ~(ready_q & ~wake_i);
`else
  assign dev_deny_o = ~(ready_q & ~wake_i & drained);
`endif

endmodule
