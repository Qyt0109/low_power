# `rtl/adp` — the READY-bit Q-Channel adapter for CVA6 and Rocket

A PPU decides when a domain may power down by asking the device over a
Q-Channel; the device side of that channel (`qchannel_device` inside
`ppu_axi_dom_top`) needs someone to say "busy" or "deny". For Ibex (soc4) that
is the core's WFI output. CVA6 (VtCPU, VtDSP) and Rocket (the NPU host) have no
WFI output and no bus-drain handshake, and a WFI there can retire with
TileLink transactions still in flight. This folder is the device-side policy
for those cores, with no core change (decision D17): **the hart says it is
ready, and the bus proves it is idle**.

- Platform plan H14 and PD4 (`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14.2,
  §14.7); decisions D17 and D18 (`Proposed_PMU/RPMI_STACK_DECISIONS.md` §2.5).
- Always-on. One adapter serves any number of harts and ports.
- Glue: no open-source block does this. The TL-UL front end of the registers
  is OpenTitan's `tlul_adapter_reg`, vendored unmodified (`src/vendor/opentitan`).

```
 hart h ──TL-UL──► hart_ready_regs ──sw_set/sw_clr──► hart_ready_adp ──dev_deny_o[h]──► ppu_axi_dom_top
                          ▲                                ▲  ▲         dev_busy_o[h]=0     dev_quiescent_deny
                          └──────────── ready_o ───────────┘  │                             dev_quiescent_busy
   wake_i, dom_on_i, hart_rst_ni, scp_clr_i ──────────────────┤
   the harts' TileLink ports (A, D; B, C, E on TL-C), observed ┘──► port_idle_o
```

## Files

| File | Module | What it is |
|---|---|---|
| [`hart_ready_adp.sv`](hart_ready_adp.sv) | `hart_ready_adp` | The READY bits, the per-port drain tracking and the accept/deny decision |
| [`hart_ready_regs.sv`](hart_ready_regs.sv) | `hart_ready_regs` | The harts' READY registers: the register decode behind a vendored `tlul_adapter_reg` |

Both depend on [`../tluh`](../tluh/README.md) (`tluh_pkg`, `tl_beat_cnt`) and
the SoC's TileLink encodings, `src/vendor/sovra_tl/tl_pkg.sv`.
`hart_ready_regs` also needs OpenTitan's `tlul_pkg` and `prim_mubi_pkg`
(`READYADP_SRCS` in `src/Makefile` is the full list).

## `hart_ready_adp`

### Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `NUM_HARTS` | 1 | harts, one READY bit and one decision each |
| `NUM_PORTS` | 1 | observed TileLink ports |
| `PORT_HART[p]` | `'0` | 8 bits per port: the hart port `p` belongs to. A VtDSP has two ports for one hart (the core's TL-C port and Ara's TL-UH port); a VtCPU cluster one per hart. A value `>= NUM_HARTS` makes the port count for no hart |
| `PORT_TLC[p]` | `'0` | 1: port `p` is TL-C (B, C, E observed). 0: TL-UH; the B, C and E inputs are ignored |
| `SZW` | 4 | width of `a_size`, `c_size`, `d_size` |
| `LOG2_BYTES` | 3 | log2 of the ports' beat width in bytes (3 = 64-bit) |
| `CNT_W` | 6 | width of each outstanding-message counter: at most `2^CNT_W - 1` per port |

### Ports

| Group | Ports | Notes |
|---|---|---|
| Clock, reset | `clk_i`, `rst_ni` | one clock: the always-on clock of the ports' fabric |
| READY inputs, per hart | `sw_set_i`, `sw_clr_i` | one-cycle pulses from `hart_ready_regs` |
| | `scp_clr_i` | the SCP's clear |
| | `wake_i` | level: any enabled wake for the hart. The integrator ORs the PLIC's pending-and-enabled for the hart, its timer and software interrupts, and a debug request |
| | `dom_on_i` | the hart's domain is ON (PPUHWSTAT's ON bit) |
| | `hart_rst_ni` | the hart's reset, LOW = in reset |
| | `ready_o` | READY, to `hart_ready_regs.ready_i` |
| Ports, observed, per port | `a_valid_i`, `a_ready_i`, `a_opcode_i`, `a_size_i`; the same for `d_*`; `b_valid_i`, `b_ready_i`; `c_valid_i`, `c_ready_i`, `c_opcode_i`, `c_size_i`; `e_valid_i`, `e_ready_i` | never driven by the adapter |
| | `port_idle_o` | the port has nothing in flight |
| Decision, per hart | `dev_deny_o` | to the domain's `dev_quiescent_deny` |
| | `dev_busy_o` | constant 0, to `dev_quiescent_busy` |

### READY: set and clear rules

`READY[h]` is one flop per hart, reset to 0.

- **Set** by `sw_set_i[h]`: hart h writes 1 to its `READY_h` register as its
  last store before WFI, after cleaning its data cache.
- **Cleared** when any of these is true in a cycle:
  `wake_i[h]`; the rising edge of `dom_on_i[h]` (detected against a flop that
  resets to 0); `hart_rst_ni[h]` LOW, for as long as it lasts; `sw_clr_i[h]`
  (a write of 0); `scp_clr_i[h]`.
- **A clear wins** over a set in the same cycle. A wake that races the hart's
  last store therefore leaves READY clear, and the hart's WFI returns at once
  because the wake is still pending.

### Drain counting

Per port, `tl_beat_cnt` instances find the first and last beat of each message
on A and D (and C on a TL-C port), with the message length from
`tluh_pkg::beats` and the `*_has_data` functions. Three counters of `CNT_W`
bits count messages, not beats:

| Counter | Incremented by | Decremented by |
|---|---|---|
| `owed` (responses owed on D) | the first beat of an A message; the first beat of a C Release / ReleaseData | the last beat of any D message |
| `grant` (Grants not yet acknowledged) | the last beat of a D Grant / GrantData | an E beat |
| `probe` (Probes not yet answered) | a B beat (a Probe is one beat) | the last beat of a C ProbeAck / ProbeAckData |

The opcodes are `tl_pkg`'s (`TL_C_RELEASE`, `TL_C_RELEASE_DATA`,
`TL_C_PROBE_ACK`, `TL_C_PROBE_ACKDATA`, `TL_D_GRANT`, `TL_D_GRANT_DATA`).
With `PORT_TLC[p] = 0` the B, C and E terms are tied off.

`port_idle_o[p]` is HIGH when all three counters are 0, no channel is part-way
through a message (`busy_o` of each `tl_beat_cnt`), `a_valid_i[p]` is LOW and,
on a TL-C port, `c_valid_i[p]` is LOW. A request on the wires that has not been
accepted yet therefore already makes the port busy. In simulation (not
synthesis) the adapter reports `$error` for a D message that starts with
nothing owed.

### The decision

```
dev_deny_o[h] = !( READY[h] && !wake_i[h] && every port with PORT_HART == h idle )
dev_busy_o[h] = 0
```

A static power-down request is accepted only while READY is set, no wake is
pending and the hart's ports are drained; otherwise it is denied at once. The
adapter never makes the PPU wait, and the SCP policy retries a denial
(`mod/policy.h`: deny, retry, force). The wake term is combinational, so a wake
in the very cycle of the request denies it. A domain that holds several harts
ORs their `dev_deny_o`.

No hardware wake goes to the PPU: the PPUs are static-only (PD5), a hart's
wake reaches the SCP as an interrupt input and the SCP powers the domain up.
The integrator ties the domain's `dev_wake` to 0.

### Clock

One clock, `clk_i`. In the SoC it is the always-on fabric clock, which also
clocks the domain's Q-Channel device wrapper (`ppu_axi_dom_top`'s `dclk`). A
different `dclk` needs a two-flop synchroniser on `dev_deny_o`; the signal is
stable for the whole Q_REQUEST state.

## `hart_ready_regs`

A TL-UL register block that each hart writes through the SoC fabric. The
hart's TL-UH is converted to TL-UL with the standard Chipyard widgets (as for
the mailbox, H13); a host without OpenTitan's `a_user` goes through a boundary
adapter such as `soc4_tl_bound`.

| Parameter | Default | Meaning |
|---|---|---|
| `NUM_HARTS` | 1 | 1 to 32 (READY_ALL is 32 bits); anything else is an elaboration `$error` |

Ports: `clk_i`, `rst_ni`, `tl_i` / `tl_o` (OpenTitan `tl_h2d_t` / `tl_d2h_t`),
`ready_i` (from `hart_ready_adp.ready_o`), `sw_set_o` and `sw_clr_o` (one-cycle
pulses to the adapter).

The vendored `tlul_adapter_reg` is built with `RegAw = 12`, `RegDw = 32`,
`AccessLatency = 0`, `CmdIntgCheck = 0` and response and data integrity
generation on. Address bits [1:0] are ignored.

### Register map

| Offset | Name | Access | Fields |
|---|---|---|---|
| `0x000 + 4*h` | `READY_h` | RW | [0] write 1: set READY of hart h; write 0: clear it. Read: READY of hart h. The write takes effect only with byte lane 0 enabled; a write without it is accepted and does nothing. Other bits read 0 |
| `0x100` | `READY_ALL` | RO | [h] READY of hart h |
| `0x104` | `INFO` | RO | `NUM_HARTS` (the software contract documents [7:0]) |

Any other offset, including `4*NUM_HARTS` up to `0x0FC`, and any write to
`READY_ALL` or `INFO`, is answered with `d_error`. The block does not check
which hart writes which register: that is the page's PMP protection in each
hart's M-mode firmware.

### Software protocol

`docs/PMU_SOFTWARE_CONTRACT.md` §6 is the contract. In short, before a
power-down the hart's M-mode code (an OpenSBI platform hook): finishes its
device accesses; cleans its data cache and fences; leaves only its wake
sources enabled in `mie`; writes 1 to `READY_h` and fences (the last store);
then loops on `wfi`, and if `wfi` returns, writes 0 to `READY_h` and takes the
normal resume path. After a power-up `READY_h` reads 0. `READY_BASE` is in the
SoC address map and is not assigned yet.

## Tests

| What | Where |
|---|---|
| Unit test | `make readyadp` (`src/tb/adp/hart_ready_adp_tb.sv`): two harts, three ports (hart 0: a TL-C port and a TL-UH port, as a CVA6 with Ara; hart 1: a TL-UH port, as a Rocket), each hart's decision through a `qchannel_device`, the testbench as the PPU. Check tags `REG`, `ACCEPT`, `DRAIN`, `CLEAR`, `CLR_WINS` |
| Mutants (the run must end in `RESULT: FAIL` at its own tag) | `HART_READY_MUT_NODRAIN` (the ports not looked at) must fail `[chk:DRAIN]`; `HART_READY_MUT_SETWINS` (a set wins over a clear) must fail `[chk:CLR_WINS]` |
| Formal | `src/formal/hart_ready_adp/hart_ready_adp_props.sv`, run by `src/signoff/formal/hart_ready_adp.tcl` (`make vcformal`). Same configuration as the unit test, with a `qchannel_device` per hart. 63 assertions fully proven, 27 covers hit: `port_idle_o` against an independent message model (`a_idle_ref`), `a_clr_wins`, `a_set`, `a_rst_clears`, `a_decision`, `a_wake_denies`, `a_busy_zero`, and the LPI Table 2-1 / §2.1.2 device rules on QACCEPTn and QDENY. `make vcformalneg`: NODRAIN falsifies 6 assertions, SETWINS 4 |
| Lint | `make vclint` elaborates `hart_ready_adp` and `hart_ready_regs` as tops |

The formal environment assumes TileLink's rules on the observed port (a D
message answers a request already made, an E beat a Grant already received, a
ProbeAck a Probe already received), messages of at most 4 KiB, and at most
`2^CNT_W - 1` outstanding messages per port.

## Integration notes

- Not yet instantiated in a SoC: soc4's CPUs are Ibex and use `soc4_cpu_adp`.
  The SOVRA integration wires `wake_i` (the OR described above), `dom_on_i`
  from the domain's PPUHWSTAT ON bit, `hart_rst_ni`, `scp_clr_i` from an SCP
  register, every TileLink port of each hart, and `dev_deny_o` / `dev_busy_o`
  into the domain's `dev_quiescent_deny` / `dev_quiescent_busy`; `dev_wake` is
  tied 0.
- Size the counters: `CNT_W` must cover the most messages a port can have
  outstanding. An overflow is not detected.
- Open sign-off findings (`src/signoff/SIGNOFF_REPORT.md` §6):
  - **F-ADP-1**: `tl_beat_cnt` holds up to 1023 beats, so on an 8-byte link a
    message of size 13 or more (8 KiB) is counted as one beat. SOVRA's 64-byte
    transfers do not reach it.
  - **F-ADP-2**: a D Grant opcode on a TL-UH port increments `grant` and
    nothing decrements it; the port then stays busy for ever. It is illegal
    TileLink.
  - **F-ADP-3**: on a TL-C port, a Probe offered on B but not yet accepted
    (`b_valid && !b_ready`) does not make the port busy, because only fired B
    beats are counted. The core could be powered off with a Probe pending.

## References

- `docs/PMU_SOFTWARE_CONTRACT.md` §6, the READY-bit protocol.
- AMBA LPI, ARM IHI 0068C, §2.1.2 and Table 2-1
  (`build/spec_txt/arm-amba-low-power-interface-spec.txt`).
- ARM DEN 0051E (the PPU's device Q-Channel and static policy).
- `src/vendor/sovra_tl/tl_pkg.sv` and its README: the TileLink opcodes, from
  the SoC's rocket-chip `Bundles.scala`.
- `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14 (H14, PD4, PD5, §14.7);
  `Proposed_PMU/RPMI_STACK_DECISIONS.md` (D17, D18).
