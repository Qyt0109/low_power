`timescale 1ns/1ps
// The harts' READY registers on the AP side: a TL-UL register block that
// each hart writes through the SoC fabric (platform plan H14; D18). Always-on,
// beside hart_ready_adp, which holds the READY bits themselves.
//
// The TL-UL front end is OpenTitan's tlul_adapter_reg, vendored unmodified
// (vendor/opentitan; also soc4_mbx's doorbell). This module is only its
// register decode. The SoC converts the hart's TL-UH to TL-UL with standard
// Chipyard widgets, as for the mailbox (platform plan H13); a host without
// OpenTitan's a_user goes through a boundary adapter such as soc4_tl_bound.
//
//   off            name         access  fields
//   0x000 + 4*h    READY_h      RW      [0] write 1: set READY of hart h (the
//                                       hart's last store before WFI); write
//                                       0: clear it. Read: READY of hart h.
//                                       Byte lane 0 only; other bits read 0
//   0x100          READY_ALL    RO      [h] READY of hart h
//   0x104          INFO         RO      [7:0] NUM_HARTS
//
// Any other offset, and a write to READY_ALL or INFO, answers with d_error.
// The software contract (docs/PMU_SOFTWARE_CONTRACT.md, "READY-bit
// protocol") is how software uses it. Who may write which hart's register is
// the page's PMP protection in each hart's M-mode firmware, not this block.

module hart_ready_regs
  import tlul_pkg::*;
#(
  parameter int unsigned NUM_HARTS = 1
) (
  input  logic                 clk_i,
  input  logic                 rst_ni,
  input  tl_h2d_t              tl_i,
  output tl_d2h_t              tl_o,
  input  logic [NUM_HARTS-1:0] ready_i,     // hart_ready_adp.ready_o
  output logic [NUM_HARTS-1:0] sw_set_o,    // -> hart_ready_adp.sw_set_i (one cycle)
  output logic [NUM_HARTS-1:0] sw_clr_o     // -> hart_ready_adp.sw_clr_i (one cycle)
);

  if (NUM_HARTS < 1 || NUM_HARTS > 32) begin : g_bad
    $error("hart_ready_regs: NUM_HARTS = %0d; READY_ALL is 32 bits", NUM_HARTS);
  end

  logic        re, we, err;
  logic [11:0] addr;
  logic [31:0] wdata, rdata;
  logic [3:0]  be;

  tlul_adapter_reg #(
    .CmdIntgCheck     (0),
    .EnableRspIntgGen (1),
    .EnableDataIntgGen(1),
    .RegAw            (12),
    .RegDw            (32),
    .AccessLatency    (0)
  ) u_ad (
    .clk_i       (clk_i),
    .rst_ni      (rst_ni),
    .tl_i        (tl_i),
    .tl_o        (tl_o),
    .en_ifetch_i (prim_mubi_pkg::MuBi4False),
    .intg_error_o(),
    .re_o        (re),
    .we_o        (we),
    .addr_o      (addr),
    .wdata_o     (wdata),
    .be_o        (be),
    .busy_i      (1'b0),
    .rdata_i     (rdata),
    .error_i     (err)
  );

  logic        is_ready, is_all, is_info;
  logic [11:0] off;
  logic [6:0]  h;
  assign off      = {addr[11:2], 2'b00};
  assign h        = off[8:2];
  assign is_ready = (off < 12'(4 * NUM_HARTS));
  assign is_all   = (off == 12'h100);
  assign is_info  = (off == 12'h104);

  always_comb begin
    rdata = '0;
    err   = 1'b0;
    if (re || we) begin
      if (is_ready)                  rdata = {31'd0, ready_i[h[4:0]]};
      else if (is_all && !we)        rdata = 32'(ready_i);
      else if (is_info && !we)       rdata = 32'(NUM_HARTS);
      else                           err   = 1'b1;
    end
  end

  always_comb begin
    sw_set_o = '0;
    sw_clr_o = '0;
    if (we && is_ready && be[0]) begin
      if (wdata[0]) sw_set_o[h[4:0]] = 1'b1;
      else          sw_clr_o[h[4:0]] = 1'b1;
    end
  end

endmodule
