`timescale 1ns/1ps
// Q-Channel controller-side finite state machine (CDC-aware).
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section 2.1.
// This is the power/clock controller end of the interface. It owns QREQn, samples
// the device acknowledges (QACCEPTn, QDENY) and the activity indication (QACTIVE),
// and drives the handshake through the six states of Table 2-1 while obeying the
// signalling rules of Section 2.1.2.
//
// Clock-domain crossing:
//   * QACCEPTn, QDENY and QACTIVE arrive from the device's asynchronous domain and
//     are each passed through a multi-flop synchronizer before the FSM samples it.
//   * QREQn is driven from a dedicated output flip-flop (never combinational
//     decode), so the device always synchronizes a clean register output.
//
// System contract:
//   * req_dev_quiescence - request from the power-management policy to
//                          quiesce the device (already in this controller's
//                          clock domain).
//   * qactive            - device activity. Per Section 2.1.3, a HIGH level
//                          while the interface is in Q_STOPPED stimulates
//                          an exit from quiescence (required to avoid
//                          deadlock).
//   * dev_stopped        - interface in Q_STOPPED: safe to gate clock /
//                          remove power.
//
// Controller policy and QACTIVE (Section 2.1.3):
//   "A controller can make any policy decision concerning its management of
//   QREQn irrespective of any activity on QACTIVE" -- the spec gives two named
//   example policies (Figures 2-7 and 2-8) built from the same two ingredients:
//   whether QACTIVE participates in *entering* quiescence, and whether it
//   participates in *exiting* it. Those are independently gated by two
//   runtime inputs (not elaboration-time parameters, so the policy can be
//   switched on the fly by the same power-management logic driving req_dev_quiescence):
//
//     enb_qactive_led_quiescence_enter - when 1, Q_RUN -> Q_REQUEST also
//       fires the moment QACTIVE drops LOW (the device hinting it might
//       accept quiescence), in addition to req_dev_quiescence.
//     enb_qactive_led_quiescence_exit  - when 1, Q_STOPPED -> Q_EXIT also
//       fires on QACTIVE HIGH, in addition to req_dev_quiescence being withdrawn.
//
//   req_dev_quiescence always remains a valid entry/exit trigger on its own (the spec's
//   "at any time" clause) -- these two inputs only gate QACTIVE's *additional*
//   participation on top of it:
//
//     enter=0, exit=1 (typical) - Figure 2-8: controller-initiated entry,
//       device-led exit.
//     enter=1, exit=1           - Figure 2-7: fully device-led entry and exit.
//     enter=1, exit=0 / enter=0, exit=0 - other controller-defined policies
//       the spec explicitly permits (e.g. device-led entry but controller-only
//       exit, or QACTIVE ignored entirely).
//
//   Caveat when enter=1: req_dev_quiescence must be a genuinely driven, dynamic policy
//   signal, not tied to a constant. QREQn LOW->HIGH (R2) is legal only from
//   Q_STOPPED or Q_DENIED, so tying req_dev_quiescence to a constant 0 while relying on
//   QACTIVE alone for entry makes "!req_dev_quiescence" trivially true forever; combined
//   with exit=1 this means Q_STOPPED is left the cycle after every entry --
//   the interface thrashes Q_STOPPED<->Q_EXIT<->Q_RUN<->Q_REQUEST continuously
//   instead of settling. This isn't a bug in the FSM: req_dev_quiescence retaining an
//   unconditional role is what Figure 2-8's default policy depends on, and the
//   spec never says req_dev_quiescence stops mattering once QACTIVE also participates --
//   it's a real system integration responsibility to drive req_dev_quiescence
//   meaningfully whenever enter=1 is used.

import qchannel_pkg::*;

module qchannel_controller #(
  parameter int unsigned SYNC_STAGES = 2  // synchronizer depth for device signals
) (
  input  logic clk,        // controller clock domain
  input  logic rst_n,      // controller domain reset, async assert

  // Q-Channel, controller side
  output logic qreqn,      // request, active LOW (registered)
  input  logic qacceptn,   // accept, active LOW  (async)
  input  logic qdeny,      // deny, active HIGH   (async)
  input  logic qactive,    // activity indication, active HIGH (async)

  // System control
  input  logic req_dev_quiescence,                 // 1 = request device quiescence
  input  logic enb_qactive_led_quiescence_enter,    // 1 = QACTIVE LOW also triggers entry (Figure 2-7)
  input  logic enb_qactive_led_quiescence_exit,     // 1 = QACTIVE HIGH also triggers exit (Figures 2-7/2-8)
  output logic dev_stopped  // 1 = interface in Q_STOPPED (safe to gate)
);

  // ---------------------------------------------------------------------------
  // Synchronize the device-driven signals into the controller clock domain.
  // All reset LOW (Q_STOPPED / device-reset boundary).
  // ---------------------------------------------------------------------------
  logic qacceptn_sync, qdeny_sync, qactive_sync;
  cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_acc_sync (.clk(clk), .rst_n(rst_n), .d(qacceptn), .q(qacceptn_sync)),
  u_den_sync (.clk(clk), .rst_n(rst_n), .d(qdeny   ), .q(qdeny_sync   )),
  u_act_sync (.clk(clk), .rst_n(rst_n), .d(qactive ), .q(qactive_sync ));

  qch_state_e state;

  // ---------------------------------------------------------------------------
  // Single sequential Moore FSM: state and QREQn move together in the same
  // clock edge whenever a transition changes QREQn's required value, so QREQn
  // is always a direct registered output -- never combinational decode, per
  // Section 2.1.2. Every arm that changes state to one where QREQn must differ
  // from its current value assigns qreqn explicitly; arms that transition
  // between two states sharing the same QREQn value leave it untouched
  // (it already holds the correct level).
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state   <= Q_STOPPED;
      qreqn <= 1'b0;  // QREQn LOW: matches Q_STOPPED, the device-reset boundary
    end else begin
      unique case (state)
        // Operational. Drop QREQn to request quiescence: on req_dev_quiescence, or --
        // when enb_qactive_led_quiescence_enter -- also the moment QACTIVE
        // drops LOW.
        Q_RUN: begin
          if (req_dev_quiescence || (enb_qactive_led_quiescence_enter && !qactive_sync)) begin
            state   <= Q_REQUEST;
            qreqn <= 1'b0;
          end
        end
        // Requested. Wait for accept (QACCEPTn LOW) or deny (QDENY HIGH).
        Q_REQUEST: begin
          if (!qacceptn_sync) begin
            state <= Q_STOPPED;  // accepted; QREQn already LOW
          end else if (qdeny_sync) begin
            state <= Q_DENIED;   // denied; QREQn already LOW
          end
        end
        // Quiescent. Exit when the request is withdrawn, or -- when
        // enb_qactive_led_quiescence_exit -- also on QACTIVE HIGH (Section
        // 2.1.3; required to avoid deadlock if this is the only exit trigger
        // enabled).
        Q_STOPPED: begin
          if (!req_dev_quiescence || (enb_qactive_led_quiescence_exit && qactive_sync)) begin
            state   <= Q_EXIT;
            qreqn <= 1'b1;
          end
        end
        // Exit. Wait for the device to acknowledge with QACCEPTn HIGH.
        Q_EXIT: begin
          if (qacceptn_sync) begin
            state <= Q_RUN;  // QREQn already HIGH
          end
        end
        // Denied. Withdraw the request by raising QREQn -> Q_CONTINUE.
        Q_DENIED: begin
          state   <= Q_CONTINUE;
          qreqn <= 1'b1;
        end
        // Continue. Wait for the device to complete with QDENY LOW.
        Q_CONTINUE: begin
          if (!qdeny_sync) begin
            state <= Q_RUN;  // QREQn already HIGH
          end
        end
        default: state <= Q_STOPPED;
      endcase
    end
  end

  // Derived combinationally from state, rather than hand-tracked in each case
  // arm above: it's exactly true in Q_STOPPED and false everywhere else, and
  // computing it this way makes that invariant impossible to get out of sync.
  assign dev_stopped = (state == Q_STOPPED);

endmodule
