// Q-Channel protocol checker.
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section 2.1.2
// "Handshake rules", plus the illegal-state entry of Table 2-1. This is a passive
// monitor: it samples the three handshake wires and, on every transition, checks
// that the transition was legal given the accompanying signal values. It is the
// executable form of the spec's rules and is meant to be bound alongside any
// controller/device pair to prove protocol compliance.
//
// The six signalling rules (Section 2.1.2):
//   R1  QREQn    1->0  only when QACCEPTn HIGH and QDENY LOW.
//   R2  QREQn    0->1  only when (QACCEPTn LOW  and QDENY LOW)
//                              or (QACCEPTn HIGH and QDENY HIGH).
//   R3  QACCEPTn 1->0  only when QREQn LOW  and QDENY LOW.
//   R4  QACCEPTn 0->1  only when QREQn HIGH and QDENY LOW.
//   R5  QDENY    1->0  only when QREQn HIGH and QACCEPTn HIGH.
//   R6  QDENY    0->1  only when QREQn LOW  and QACCEPTn HIGH.
//   R7  (Table 2-1) QACCEPTn LOW with QDENY HIGH is an illegal combination.
//
// The companion-signal condition for each edge is evaluated on the "from" state
// (the values held immediately before the transition), which is what the rules
// describe.
//
// Reset-assertion precondition (Section 2.1.2 "Device reset"):
// - "A controller must only assert a device reset when the interface is in
//   the Q_STOPPED state." Checked on the falling edge of drst_n against the
//   monitor's last-sampled wire state (the device's own registers snap LOW
//   asynchronously the instant its reset asserts, so the pre-reset state has
//   to be captured from the monitor's own pipeline, not re-read off the wires).
// - Symmetric best-practice check for the controller's own reset: the spec
//   text only names "device reset", but a controller reset asserted
//   mid-handshake forces QREQn LOW without the device's agreement and can
//   desynchronize the device FSM just the same. Not a literal spec rule;
//   flagged for the same isolation-boundary rationale as R8.
//
// `crst_n`/`drst_n` are purely observed here (edge-detected), independent of
// this monitor's own `rst_n`. `rst_n` must be the monitor's own always-on
// operating reset and must NOT be gated by the domain resets being watched --
// otherwise the very domain-reset event R8/R9 need to see would also wipe the
// monitor's pipeline in the same instant, and the violation would go unseen.
//
// Clock-gate-assertion precondition (same principle as R8/R9, generalized
// from "device reset" to "any resource removal"): the clock (or other
// same-domain gated resource) tied to `clk_gated` must only actually be
// removed while the interface is in Q_STOPPED. Checked on the rising edge of
// `clk_gated` only -- like R8/R9, release is never checked, since leaving
// Q_STOPPED necessarily lags the wire-level state by the device's own QREQn
// synchronizer (the same "status-flag latency" documented for dev_stopped_o
// in qchannel_controller.sv), while entry into Q_STOPPED -- and therefore the
// gate assertion -- is zero-lag and same-domain with qacceptn dropping (see
// qchannel_device.sv's dev_clk_en). Tie `clk_gated` LOW on a channel that
// never gates a resource (e.g. the power-control channel, where the
// equivalent removal is the device reset already covered by R8).

import qchannel_pkg::*;

module qchannel_monitor (
  input  logic        clk,
  input  logic        rst_n,      // monitor's own operating reset (always-on)
  input  logic        crst_n,     // controller domain reset, observed for R9
  input  logic        drst_n,     // device domain reset, observed for R8
  input  logic        clk_gated,  // resource-gate status, observed for R10
  input  logic        qreqn,
  input  logic        qacceptn,
  input  logic        qdeny,
  output int unsigned violations
);

  // Two registered copies: p_* (from state) and c_* (to state). The checks below
  // run before the shift, so they compare the current p_* -> c_* transition and
  // evaluate each rule's companion condition on p_* (the "from" state).
  logic p_req, p_acc, p_den;
  logic c_req, c_acc, c_den;
  int unsigned viol;

  assign violations = viol;

  // Sim-only monitor: blocking assignments in a clocked block, checks first, then
  // shift. `flag` increments the violation count and logs the offending edge.
  task automatic flag(input string rule, input string msg);
    viol = viol + 1;
    $display("[%0t] QCH-VIOLATION %s: %s  (from {QREQn=%0b QACCEPTn=%0b QDENY=%0b} -> {%0b %0b %0b})",
             $time, rule, msg, p_req, p_acc, p_den, c_req, c_acc, c_den);
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      // At reset the interface is the all-LOW quiescent state (Q_STOPPED).
      p_req = 1'b0; p_acc = 1'b0; p_den = 1'b0;
      c_req = 1'b0; c_acc = 1'b0; c_den = 1'b0;
      viol  = 0;
    end else begin
      // R1: QREQn 1->0
      if (p_req && !c_req)
        if (!(p_acc && !p_den)) flag("R1", "QREQn fell outside Q_RUN");
      // R2: QREQn 0->1
      if (!p_req && c_req)
        if (!(((!p_acc) && (!p_den)) || (p_acc && p_den)))
          flag("R2", "QREQn rose outside Q_STOPPED/Q_DENIED");
      // R3: QACCEPTn 1->0
      if (p_acc && !c_acc)
        if (!((!p_req) && (!p_den))) flag("R3", "QACCEPTn fell outside Q_REQUEST");
      // R4: QACCEPTn 0->1
      if (!p_acc && c_acc)
        if (!(p_req && (!p_den))) flag("R4", "QACCEPTn rose outside Q_EXIT");
      // R5: QDENY 1->0
      if (p_den && !c_den)
        if (!(p_req && p_acc)) flag("R5", "QDENY fell outside Q_CONTINUE");
      // R6: QDENY 0->1
      if (!p_den && c_den)
        if (!((!p_req) && p_acc)) flag("R6", "QDENY rose outside Q_REQUEST");
      // R7: illegal combination present on the wires
      if (c_acc == 1'b0 && c_den == 1'b1)
        flag("R7", "illegal state QACCEPTn=0,QDENY=1");

      // Shift the two-deep pipeline of sampled values (after the checks).
      p_req = c_req; p_acc = c_acc; p_den = c_den;
      c_req = qreqn; c_acc = qacceptn; c_den = qdeny;
    end
  end

  // R8/R9: reset must only be asserted while the interface is Q_STOPPED, i.e.
  // {QREQn, QACCEPTn, QDENY} == {0,0,0}. `rst_n` gates out both simulation
  // start-up (before the monitor's own pipeline holds a real sample) and any
  // brief X->0 initializer edge on crst_n/drst_n at time zero.
  always @(negedge drst_n) begin
    if (rst_n && !(c_req == 1'b0 && c_acc == 1'b0 && c_den == 1'b0)) begin
      viol = viol + 1;
      $display("[%0t] QCH-VIOLATION R8: device reset asserted outside Q_STOPPED (state was {QREQn=%0b QACCEPTn=%0b QDENY=%0b})",
                $time, c_req, c_acc, c_den);
    end
  end

  always @(negedge crst_n) begin
    if (rst_n && !(c_req == 1'b0 && c_acc == 1'b0 && c_den == 1'b0)) begin
      viol = viol + 1;
      $display("[%0t] QCH-VIOLATION R9: controller reset asserted outside Q_STOPPED (state was {QREQn=%0b QACCEPTn=%0b QDENY=%0b})",
                $time, c_req, c_acc, c_den);
    end
  end

  // R10: mirrors R8/R9 but for a same-domain gated resource (e.g. the
  // clock-control channel's clock gate) instead of a cross-domain reset.
  always @(posedge clk_gated) begin
    if (rst_n && !(c_req == 1'b0 && c_acc == 1'b0 && c_den == 1'b0)) begin
      viol = viol + 1;
      $display("[%0t] QCH-VIOLATION R10: resource gated outside Q_STOPPED (state was {QREQn=%0b QACCEPTn=%0b QDENY=%0b})",
                $time, c_req, c_acc, c_den);
    end
  end

endmodule
