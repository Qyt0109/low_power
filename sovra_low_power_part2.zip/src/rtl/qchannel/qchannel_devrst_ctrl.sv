`timescale 1ns/1ps
// Q-Channel device-reset controller -- always-on domain.
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section
// 2.1.2 "Device reset": "A controller must only assert a device reset when
// the interface is in the Q_STOPPED state." This block is the structural
// enforcement of that rule: it will not drive the device's reset until the
// POWER-CONTROL Q-Channel controller confirms dev_stopped. Per PCSA
// (ARM DEN0050) Section 8.2.1, clock control and power control must be
// separate Q-Channel interfaces -- dev_stopped here is fed from the
// power-control channel's controller specifically, not the clock-control
// one (a clock quiescing tells you nothing about whether it's safe to
// reset the domain). This block does so safely across TWO independent
// asynchronous clock domains (per Section 2.1.1, "all Q-Channel signals
// are asynchronous"):
//
//   * aon_clk / aon_rst_n - the always-on domain. This block AND
//     qchannel_controller both run here, sharing the same clock/reset, since
//     a power controller has to be the one thing in the system guaranteed
//     alive to sequence everything else -- so dev_stopped arrives already
//     in this domain and needs no resynchronizing.
//   * dclk - the device's own clock domain. The reset this block produces
//     (drst_n) is asserted asynchronously (always safe, see below) but
//     RELEASED only after being resynchronized into dclk, using the
//     standard async-assert / sync-deassert reset-synchronizer pattern, so
//     the device never sees a reset-removal timing violation.
//
// Why assertion doesn't need synchronizing but release does:
//   Asserting a reset is inherently glitch-free: every downstream flop just
//   adopts its reset value, regardless of which clock edge it lands on. The
//   spec's hazard here is a *protocol* one (asserting reset while the
//   interface is mid-handshake desynchronizes the two Q-Channel FSMs), not a
//   metastability one -- that hazard is closed by the interlock below, not
//   by a synchronizer. Releasing a reset, by contrast, is a genuine CDC
//   hazard: if the release edge violates recovery/removal time on the flops
//   sampling it, some may see the release a cycle early and others a cycle
//   late. Hence: gate *assertion* on protocol state (Q_STOPPED), synchronize
//   *release* into the destination clock.
//
// Interlock behaviour:
//   dev_rst_req is the power-management policy's request to hold the
//   device in reset (1) or let it run (0). Requesting the hold does not, by
//   itself, assert drst_n -- it only takes effect once dev_stopped (the
//   controller's Q_STOPPED status) is also observed true. The policy is
//   expected to have already quiesced the device via
//   qchannel_controller's req_dev_quiescence/dev_stopped handshake before raising
//   dev_rst_req; this block is the safety net that enforces it structurally
//   even if that ordering is violated elsewhere. At cold power-up,
//   qchannel_controller resets directly into Q_STOPPED (dev_stopped is
//   1'b1 immediately), so the interlock is trivially satisfied and the
//   device still resets normally on first power-up.
//
//   De-asserting dev_rst_req unconditionally releases the hold -- bringing
//   a device out of reset is never the protocol hazard that asserting one
//   mid-handshake is, so no Q_STOPPED gating is needed on release.
//
// Power-up safety, and why the hold register is ACTIVE LOW:
//   The device must be held in reset from time zero, before anything has been
//   clocked. The obvious way to write the hold register is active HIGH
//   (1 = hold), but then it powers up 0 = "release", and the reset of the
//   dclk-side synchronizer has to be driven by (hold | ~aon_rst_n) to cover
//   the power-up case. That expression has two costs, and both are real:
//
//     * It puts COMBINATIONAL LOGIC on an asynchronous reset pin. Synthesis
//       builds it as a gate (on FPGA, a LUT2); a glitch on that gate asserts
//       the device reset spuriously, and no amount of timing closure prevents
//       it because the path is asynchronous by construction. Vivado flags this
//       directly as LUTAR-1 "LUT drives async reset alert", and report_cdc as
//       CDC-10 "combinational logic detected before a synchronizer".
//
//     * It opens a transient RELEASE window. With an active-HIGH hold, the OR
//       goes false the instant aon_rst_n rises -- before the hold register has
//       been clocked to 1 -- so for up to one aon_clk cycle the device reset is
//       released even though dev_rst_req is asserted. Whether that reaches
//       drst_n depends on how many dclk edges land in that window, i.e. on the
//       clock ratio. It is latent, not theoretical.
//
//   Making the register ACTIVE LOW removes both. rst_hold_n resets to 0, and 0
//   already means "hold the device in reset", so the power-up case is covered
//   by the register's own reset value rather than by an OR with aon_rst_n. A
//   single flop output then drives the synchronizer's async reset directly --
//   no gate, no glitch path, and no window in which the reset is momentarily
//   released while it is still being requested.
//
//   The trade is that release from aon_rst_n now costs one aon_clk edge, since
//   rst_hold_n must be clocked to 1 rather than tracking aon_rst_n
//   combinationally. That is the right direction: a reset release that is
//   registered in the always-on domain is exactly what you want, and the
//   immediacy it replaces was the hazard described above.

module qchannel_devrst_ctrl (
  // Always-on domain -- shared with qchannel_controller, so dev_stopped
  // below arrives already in this clock domain (no resync needed).
  input  logic aon_clk,
  input  logic aon_rst_n,     // async, ACTIVE LOW

  // Status from the POWER-control Q-Channel controller (same aon_clk/
  // aon_rst_n domain) -- NOT the clock-control channel (PCSA 8.2.1)
  input  logic dev_stopped,   // 1 = power-control interface is in Q_STOPPED

  // Power-management request
  input  logic dev_rst_req,   // 1 = hold the device in reset, 0 = release

  // Device clock domain: reset is asserted async, released sync to dclk
  input  logic dclk,
  output logic drst_n         // device reset, active LOW
);

  // ---------------------------------------------------------------------
  // Interlocked hold register (aon_clk domain), ACTIVE LOW: 0 = hold the
  // device in reset, 1 = let it run.
  //
  // The polarity is the point. Resetting to 0 means "held", so cold power-up
  // is covered by this register's own reset value and the synchronizer below
  // needs no OR with aon_rst_n -- see "Power-up safety" in the header. Falls
  // only when both the request and the Q_STOPPED confirmation are true; rises
  // as soon as the request is withdrawn.
  // ---------------------------------------------------------------------
  logic rst_hold_n;
  always_ff @(posedge aon_clk or negedge aon_rst_n) begin
    if (!aon_rst_n)                       rst_hold_n <= 1'b0;  // power-up: held
    else if (!dev_rst_req)                rst_hold_n <= 1'b1;  // release
    else if (dev_rst_req && dev_stopped)  rst_hold_n <= 1'b0;  // interlocked hold
  end

  // ---------------------------------------------------------------------
  // Async-assert / sync-deassert reset synchronizer into dclk.
  //
  // The async reset is driven by rst_hold_n ALONE -- a single flop output,
  // with no gate between it and the reset pin. That is what keeps a glitch
  // from ever asserting the device reset, and it is only possible because
  // rst_hold_n is active low and therefore already correct at power-up.
  // ---------------------------------------------------------------------
  // The release retiming is rtl/common/rst_sync, not a copy of it.
  //
  // This used to be two flops written out here, resetting HIGH and inverted on
  // the way out. That is the same circuit as rst_sync with the polarity folded
  // differently: rst_hold_n LOW forced the chain to 1 and drst_n to 0, which is
  // rst_sync's rst_out_n resetting LOW. Identical behaviour, one fewer copy of
  // a two-flop retimer, and the constraint files now see one register name
  // where they used to have to know about two shapes.
  rst_sync u_drst_sync (
    .clk      (dclk),
    .rst_in_n (rst_hold_n),
    .rst_out_n(drst_n)
  );

endmodule
