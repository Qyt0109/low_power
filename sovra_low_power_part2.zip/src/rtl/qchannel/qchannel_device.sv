`timescale 1ns/1ps
// Q-Channel device-side finite state machine (CDC-aware).
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C), Section 2.1.
// This is the block a peripheral wraps itself in to become Q-Channel compliant.
// It receives the controller's quiescence request (QREQn) and drives the two
// device-side acknowledge signals (QACCEPTn, QDENY) plus the activity indication
// (QACTIVE), sequencing through the six handshake states of Table 2-1 while
// obeying the signalling rules of Section 2.1.2 "Handshake rules".
//
// Clock-domain crossing:
//   * QREQn arrives from the controller's asynchronous domain and is passed
//     through a multi-flop synchronizer before the FSM samples it.
//   * QACCEPTn, QDENY and QACTIVE are driven from dedicated output flip-flops
//     (never combinational decode), so the far domain always synchronizes a
//     clean, glitch-free register output. This matches the spec requirement that
//     the handshake acknowledges be driven directly by registers.
//
// Device-internal contract:
//   * dev_quiescent_busy - the device cannot yet become quiescent (e.g. work in
//                          flight). While busy in Q_REQUEST it stays
//                          operational (QACCEPTn HIGH), matching "requested to
//                          become quiescent when idle".
//   * dev_quiescent_deny - the device wants to refuse a request outright (only
//                          meaningful when DENY_SUPPORTED). Produces the
//                          Q_DENIED / Q_CONTINUE path.
//   * dev_wake           - an activity/wake event to advertise on QACTIVE.
//   * dev_quiescent_ok   - 1 while the device is actually quiescent (Q_STOPPED);
//                          only then is the controller free to remove the
//                          clock/power. Note the polarity is inverted from the
//                          old dev_clk_en_o ("1 = clock needed"): this is
//                          "1 = safe to remove", matching the dev_quiescent_*
//                          naming of the other device-internal signals.

import qchannel_pkg::*;

module qchannel_device #(
  parameter int unsigned SYNC_STAGES    = 2     // synchronizer depth for QREQn
) (
  input  logic clk,        // device clock domain
  input  logic rst_n,      // device domain reset, async assert

  // Q-Channel, device side
  input  logic qreqn,     // request from controller, active LOW (async)
  output logic qacceptn,  // accept, active LOW  (registered)
  output logic qdeny,     // deny, active HIGH   (registered)
  output logic qactive,   // activity indication, active HIGH (registered)

  // Device-internal
  input  logic dev_quiescent_busy,  // 1 = cannot become quiescent yet
  input  logic dev_quiescent_deny,  // 1 = refuse the quiescence request
  input  logic dev_wake,            // 1 = advertise a wake event on QACTIVE
  output logic dev_quiescent_ok     // 1 = device is quiescent (Q_STOPPED)
);

  qch_state_e state;

  // ---------------------------------------------------------------------------
  // Synchronize the incoming QREQn into the device clock domain. QREQn is LOW at
  // the reset (Q_STOPPED) boundary, so the chain resets LOW.
  // ---------------------------------------------------------------------------
  logic qreqn_sync;
  cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
  u_qreqn_sync (.clk(clk), .rst_n(rst_n), .d(qreqn), .q(qreqn_sync));

  // ---------------------------------------------------------------------------
  // Single sequential Moore FSM: state and the handshake outputs move together
  // in the same clock edge whenever a transition changes an output's required
  // value, so QACCEPTn/QDENY are always direct registered outputs -- never
  // combinational decode, per Section 2.1.2. Every arm that changes state to
  // one where an output must differ from its current value assigns it
  // explicitly; arms that transition between two states sharing the same
  // output values leave them untouched (already holding the correct level).
  // QACTIVE is independent of the handshake (Section 2.1.3) so it is updated
  // unconditionally every cycle, outside the state case.
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state    <= Q_STOPPED;
      qacceptn <= 1'b0;   // QACCEPTn LOW at reset (Section 2.1.2 "Device reset")
      qdeny    <= 1'b0;   // QDENY LOW at reset
      qactive  <= 1'b0;
    end else begin
      unique case (state)
        // Operational. Wait for the controller to request quiescence (QREQn LOW).
        Q_RUN: begin
          if (!qreqn_sync) state <= Q_REQUEST;  // qacceptn/qdeny already {1,0}
        end
        // Requested. Deny, accept-when-idle, or stay operational while busy.
        Q_REQUEST: begin
          if (dev_quiescent_deny) begin
            state <= Q_DENIED;
            qdeny <= 1'b1;      // -> QDENY HIGH
          end else if (!dev_quiescent_busy) begin
            state    <= Q_STOPPED;
            qacceptn <= 1'b0;   // -> QACCEPTn LOW
          end
        end
        // Quiescent. Wait for the controller to begin exit (QREQn HIGH).
        Q_STOPPED: begin
          if (qreqn_sync) state <= Q_EXIT;  // qacceptn/qdeny already {0,0}
        end
        // Exit. Acknowledge by driving QACCEPTn HIGH -> Q_RUN.
        Q_EXIT: begin
          state    <= Q_RUN;
          qacceptn <= 1'b1;
        end
        // Denied. Wait for the controller to withdraw the request (QREQn HIGH).
        Q_DENIED: begin
          if (qreqn_sync) state <= Q_CONTINUE;  // qacceptn/qdeny already {1,1}
        end
        // Continue. Complete the denied handshake by driving QDENY LOW -> Q_RUN.
        Q_CONTINUE: begin
          state <= Q_RUN;
          qdeny <= 1'b0;
        end
        default: state <= Q_STOPPED;
      endcase

      // QACTIVE advertises device activity; independent of the handshake.
      qactive <= dev_quiescent_busy | dev_wake;
    end
  end

  // Derived combinationally from state, rather than hand-tracked in each case
  // arm above: it's exactly true in Q_STOPPED and false everywhere else, and
  // computing it this way makes that invariant impossible to get out of sync.
  assign dev_quiescent_ok = (state == Q_STOPPED);

endmodule
