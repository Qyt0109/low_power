`timescale 1ns/1ps
// Dummy workload — a gate-able running block behind a Q-Channel device.
//
// Models the *functional* logic that a Q-Channel device wraps: it runs on the
// gated clock, does some multi-cycle "work", and tells its Q-Channel device
// whether it is safe to be stopped:
//   * busy HIGH  → work is in flight; the clock must NOT be removed.
//   * busy LOW   → idle / done; the device may accept quiescence and the clock
//                    control block may gate the clock off.
// When its clock is gated the block simply freezes (holds all state), which is the
// whole point of clock gating.
//
// Work model: on a rising `start` while idle, it loads `work_len` and counts
// down one per (gated) clock; busy is HIGH until the count drains, then done
// pulses for one cycle. Held state survives clock gating unchanged.
//
// Light work mode: start with light_work=1 counts down without raising busy,
// allowing the controller to gate the clock anytime. Light work freezes on clock
// gate and resumes from the frozen state on wake, with done pulsing on completion.

module dummy_workload #(
  parameter int unsigned CNT_W = 8
) (
  input  logic             clk,        // gated clock from the clock-control block
  input  logic             rst_n,      // async-assert reset (independent of gating)
  input  logic             start,      // request to begin a work burst
  input  logic [CNT_W-1:0] work_len,   // number of clocks of work to perform
  input  logic             light_work, // 1 = no busy during work, just a done pulse when complete
  output logic             busy,       // 1 = processing (do not gate the clock)
  output logic             done,       // 1-cycle pulse when a burst completes
  output logic [CNT_W-1:0] work_count  // remaining work (observability)
);

  typedef enum {
    IDLE,
    WORK,
    LIGHT
  } fsm_t;
  fsm_t cstate;

  reg [CNT_W-1:0] cnt;
  wire last_cnt = (cnt == 'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cstate <= IDLE;

      busy <= 1'b0;
      done <= 1'b0;
    end else begin
      done <= 1'b0;
      case (cstate)
        IDLE: begin
          if (start) begin
            cnt <= work_len;
            if (light_work) begin
              cstate <= LIGHT;
            end else begin
              cstate <= WORK;
              busy <= 1'b1;
            end
          end
        end
        WORK, LIGHT: begin
          cnt <= (cnt - 1);
          if (last_cnt) begin
            cnt <= 0;

            cstate <= IDLE;
            busy <= 1'b0;
            done <= 1'b1;
          end
        end
      endcase
    end
  end

  assign work_count = cnt;

endmodule
