`timescale 1ns/1ps
// Q-Channel gate-able power domain — top-level integration.
//
// PCSA (ARM DEN0050) Section 8.2.1 requires clock control and power control
// to use SEPARATE Q-Channel interfaces: "Each clock requires a separate
// Q-Channel interface... The clock control Q-Channels must be separate from
// any power control LPIs." This top level wires up TWO independent Q-Channel
// pairs accordingly, both terminating in the always-on domain and both
// asynchronously crossing into the device's dclk domain:
//
//   pd_req ──► u_ctrl_clk ══CLK QREQn══► u_dev_clk ──► dev_clk_en
//                  ▲   │                    │                │
//         CLK QACCEPTn/QDENY/QACTIVE ═══════┘                ▼
//                                                    clk_gate (ICG)
//                                                              │ gated clock
//                                                              ▼
//                                                     dummy_workload ◄── rst_n
//                                                      │ busy   │ done      ▲
//   dev_rst_req ──► u_ctrl_pwr ══PWR QREQn══► u_dev_pwr ◄───────┘          │
//                       ▲   │                     │                        │
//           PWR QACCEPTn/QDENY/QACTIVE ═══════════┘                        │
//                       │ dev_stopped_pwr                                │
//                       ▼                                                  │
//              qchannel_devrst_ctrl ── drst_n ─────► u_dev_clk.rst_n ────┤
//                                                      u_dev_pwr.rst_n ───┘
//
// The CLOCK-control channel (u_ctrl_clk/u_dev_clk) behaves exactly as before:
// no reset semantics at all, its device-side wrapper stays on the ungated
// dclk and is what clk_gate's ICG uses to gate the workload's
// clock off once idle.
//
// The POWER-control channel (u_ctrl_pwr/u_dev_pwr) is the one whose Q_STOPPED
// status feeds qchannel_devrst_ctrl's interlock (Section 2.1.2 "Device
// reset": "A controller must only assert a device reset when the interface
// is in the Q_STOPPED state"): only once the power-control device wrapper
// has independently negotiated Q_STOPPED (denying/waiting on the same
// dev_quiescent_busy as the clock channel) does qchannel_devrst_ctrl assert drst_n,
// which is the ONE reset shared by u_dev_clk, u_dev_pwr and dummy_workload --
// once the domain is genuinely powered down, everything in it, wrapper logic
// included, goes down together (PCSA 8.3.4 "the reset state of the component
// should be equivalent to the quiescent state"); wake-up only afterwards
// comes from outside the domain (dev_rst_req), matching PCSA 8.3.4's
// "wake signaling must come from outside the power domain" for a domain that
// cannot generate or propagate its own signals while powered off.
//
// qchannel_controller (both instances) and qchannel_devrst_ctrl run in the
// always-on domain (aon_clk/aon_rst_n): a power controller has to be the
// one thing in the system guaranteed alive to sequence everything else
// (PCSA 7.2.3 "the PPU must be placed in a power domain that is relative
// always-on to the power domain it is controlling"), so dev_stopped_pwr
// reaches qchannel_devrst_ctrl already in-domain, with no resynchronizer
// needed. See qchannel_devrst_ctrl.sv for the reset CDC rationale.
//
// Clock domains: both controllers + reset control = aon_clk (always-on),
// both device wrappers + workload = dclk (the workload's clock is dclk
// gated). See rtl/qchannel/README.

// Only real, system-level ports are exposed here: clocks, resets, and the
// PM-policy control/stimulus inputs a real integrator would drive. Every
// internal handshake wire and status signal below (Q-Channel wires, drst_n,
// dev_clk_en, dummy_clk, busy, done, work_count) is a real internal signal of
// this module, not a port -- a testbench that needs to observe them reaches
// in via hierarchical reference (e.g. `u_top.clk__qreqn`, `u_top.u_dummy.
// work_count`, `~u_top.u_clkctrl.en_latch` for the gated status) rather
// than this module growing debug-only ports. dev_running and clk_gated
// were removed from qchannel_controller/clk_gate entirely: they
// had zero functional consumers anywhere in this design, unlike
// dev_stopped (kept -- qchannel_devrst_ctrl genuinely depends on it).
module qchannel_pd_top #(
  parameter int unsigned SYNC_STAGES = 2,
  parameter int unsigned CNT_W       = 8
) (
  // Always-on domain: runs both Q-Channel controllers and generates the
  // device's reset (see qchannel_devrst_ctrl)
  input  logic             aon_clk,
  input  logic             aon_rst_n,    // async, ACTIVE LOW

  // Clock-control Q-Channel request
  input  logic             pd_req,       // 1 = ask the domain to quiesce the clock

  // Power-control Q-Channel request + the resulting reset request
  input  logic             pwr_req,      // 1 = ask the domain to quiesce for power-down
  input  logic             dev_rst_req,  // 1 = hold device in reset, 0 = release

  // Device / workload clock domain
  input  logic             dclk,
  input  logic             start,        // kick a workload burst
  input  logic [CNT_W-1:0] work_len,     // burst length in clocks
  input  logic             light_work,   // 1 = light work (no busy), 0 = regular work
  input  logic             wake,         // external wake -> QACTIVE
  input  logic             deny_enb      // 1 = deny quiesce when busy, 0 = wait for completion
);

  // Interface wires (asynchronous between the two domains).
  logic clk__qreqn, clk__qacceptn, clk__qdeny, clk__qactive;
  logic pwr__qreqn, pwr__qacceptn, pwr__qdeny, pwr__qactive;
  logic dev_quiescent_ok, dev_clk_en, dummy_clk, busy;
  logic drst_n;
  logic dev_stopped_clk;  // clock-control Q_STOPPED status -- a real internal
  logic dev_stopped_pwr;  // power-control Q_STOPPED status -- a real internal
                           // dependency (feeds qchannel_devrst_ctrl below),
                           // not mere observability

  // ---- Clock-control controller (aon_clk domain, always-on) ----
  qchannel_controller #(.SYNC_STAGES(SYNC_STAGES)) u_ctrl_clk (
    .clk      (aon_clk),
    .rst_n    (aon_rst_n),
    .qreqn    (clk__qreqn),
    .qacceptn (clk__qacceptn),
    .qdeny    (clk__qdeny),
    .qactive  (clk__qactive),
    .req_dev_quiescence(pd_req),
    .enb_qactive_led_quiescence_enter(1'b0),  // Figure 2-8: controller-initiated entry
    .enb_qactive_led_quiescence_exit (1'b1),  // device-led exit
    .dev_stopped(dev_stopped_clk)
  );

  // ---- Power-control controller (aon_clk domain, always-on) ----
  qchannel_controller #(.SYNC_STAGES(SYNC_STAGES)) u_ctrl_pwr (
    .clk      (aon_clk),
    .rst_n    (aon_rst_n),
    .qreqn    (pwr__qreqn),
    .qacceptn (pwr__qacceptn),
    .qdeny    (pwr__qdeny),
    .qactive  (pwr__qactive),
    .req_dev_quiescence(pwr_req),
    .enb_qactive_led_quiescence_enter(1'b0),  // Figure 2-8: controller-initiated entry
    .enb_qactive_led_quiescence_exit (1'b1),  // device-led exit
    .dev_stopped(dev_stopped_pwr)
  );

  // ---- Device reset controller (aon_clk domain, always-on) ----
  // Only asserts drst_n once u_ctrl_pwr confirms Q_STOPPED on the
  // POWER-control channel (Section 2.1.2) -- not the clock-control channel,
  // which never implies it's safe to reset -- and releases it synchronized
  // into dclk. Same clock/reset as u_ctrl_pwr above, so dev_stopped_pwr
  // needs no resynchronizing. See qchannel_devrst_ctrl.sv.
  qchannel_devrst_ctrl u_devrst (
    .aon_clk    (aon_clk),
    .aon_rst_n  (aon_rst_n),
    .dev_stopped(dev_stopped_pwr),
    .dev_rst_req(dev_rst_req),
    .dclk       (dclk),
    .drst_n     (drst_n)
  );

  // ---- Clock-control device wrapper (dclk domain) ----
  // dev_quiescent_busy comes from the workload: the device will not accept
  // quiescence while busy. QACTIVE reflects an external wake or the workload
  // being active. Reset by drst_n like everything else in this domain: once
  // the POWER channel has actually granted power-down, the whole domain --
  // wrapper logic included -- goes down together (PCSA 8.3.4).
  qchannel_device #(.SYNC_STAGES(SYNC_STAGES)) u_dev_clk (
    .clk               (dclk),
    .rst_n             (drst_n),
    .qreqn             (clk__qreqn),
    .qacceptn          (clk__qacceptn),
    .qdeny             (clk__qdeny),
    .qactive           (clk__qactive),
    .dev_quiescent_busy(busy),
    .dev_quiescent_deny(deny_enb && busy),  // deny quiescence if workload is busy (enables Q_DENIED)
    .dev_wake          (wake | busy),       // advertise activity on QACTIVE
    .dev_quiescent_ok  (dev_quiescent_ok)
  );

  // clk_gate's clk_en input keeps the pre-existing "1 = clock
  // needed" polarity (Section 2.1.3 policy above is stated in those terms),
  // which is the logical inverse of dev_quiescent_ok's "1 = safe to remove".
  assign dev_clk_en = ~dev_quiescent_ok;

  // ---- Power-control device wrapper (dclk domain) ----
  // Own independent accept/deny against the same busy signal: the interlock
  // that gates qchannel_devrst_ctrl's drst_n assertion lives here, not on the
  // clock channel, so a busy workload blocks power-down exactly the same way
  // it blocks clock gating, but as a separate negotiated decision.
  qchannel_device #(.SYNC_STAGES(SYNC_STAGES)) u_dev_pwr (
    .clk               (dclk),
    .rst_n             (drst_n),
    .qreqn             (pwr__qreqn),
    .qacceptn          (pwr__qacceptn),
    .qdeny             (pwr__qdeny),
    .qactive           (pwr__qactive),
    .dev_quiescent_busy(busy),
    .dev_quiescent_deny(deny_enb && busy),
    .dev_wake          (wake | busy),
    .dev_quiescent_ok  ()  // unused: power-down actuation is drst_n, not a clock gate
  );

  // ---- Clock control (dclk domain) — gates the workload clock ----
  clk_gate u_clkctrl (
    .clk      (dclk),
    .clk_en   (dev_clk_en),
    .gated_clk(dummy_clk)
  );

  // ---- Workload (gated clock) ----
  dummy_workload #(.CNT_W(CNT_W)) u_dummy (
    .clk       (dummy_clk),
    .rst_n     (drst_n),
    .start     (start),
    .work_len  (work_len),
    .light_work(light_work),
    .busy      (busy),
    .done      (),
    .work_count()
  );

endmodule
