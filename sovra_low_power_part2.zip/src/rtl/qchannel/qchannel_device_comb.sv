`timescale 1ns/1ps
// Q-Channel device FSM for a CLOCK-control interface -- combinational QACTIVE.
//
// Reference: AMBA Low Power Interface Specification (ARM IHI 0068C) Sections
// 2.1.1-2.1.3 and 4.1.1; Arm CoreLink PCK-600 TRM (101150) Tables A-22, A-23,
// A-29 and Table 3-7.
//
// WHY THIS EXISTS AND qchannel_device DOES NOT SUFFICE
//
// This repository already has a Q-Channel device FSM, and every other block
// reuses it unmodified -- ppu_top instantiates qchannel_controller and
// pchannel_controller without touching either. So a second device FSM needs a
// reason, and there is exactly one:
//
//   qchannel_device drives QACTIVE from a FLIP-FLOP:
//       qactive <= dev_quiescent_busy | dev_wake;   (its line 121)
//
// That is correct for a POWER-control channel, where the clock keeps running in
// Q_STOPPED and only the supply goes away. It is a DEADLOCK on a CLOCK-control
// channel, because the clock that would register QACTIVE is the very clock the
// device is asking for. Once the interface reaches Q_STOPPED and the controller
// gates the clock, a registered QACTIVE can never rise again, and nothing can
// ever wake the device.
//
// Arm says so in three places, none of which is optional:
//
//   * LPI Section 4.1.1 works the dependency through for a device with both a
//     clock Q-Channel and a power P-Channel: "CLK must be active to perform the
//     management actions in the device that are required before the power state
//     transition... the dependency can be resolved... by a QACTIVE contribution
//     from the power control interface logic that is active whenever P-Channel
//     transitions require CLK to be active."
//
//   * PCK-600 Tables A-22/A-23/A-29 give the Clock column for every one of
//     hc_qactive_o, pwr_qactive_o and ppuclk_qactive_o as "Asynchronous", while
//     the QACCEPTn/QDENY of the same interfaces are "clk".
//
//   * PCK-600 Table 3-7, ACTIVE_DENY_EN: "The path from a device to the
//     controller QACTIVE is combinatorial, irrespective of whether
//     synchronizers are present."
//
// So QACTIVE here is a wire, straight from dev_active to the pin. QACCEPTn and
// QDENY stay registered, per Section 2.1.2 and for the same reason as in
// qchannel_device: the far domain must synchronize a clean register output.
// Freezing THOSE with the clock is not merely safe, it is required -- Q_STOPPED
// is the one state in which the device owes the controller no response.
//
// A combinational QACTIVE can glitch on a decode. That is inherent to the
// interface, not to this implementation: the receiving controller synchronizes
// QACTIVE (PCK-600's CLK_QACTIVE_SYNC parameter exists for exactly that) and
// LPI Section 2.1.1 already declares "All signals are assumed to be
// asynchronous". Drive dev_active from register outputs where possible.
//
// THE DENIAL POLICY
//
// One rule: if the device needs the clock when the request arrives, deny.
//
// LPI Section 2.1.1 says why that beats holding the handshake open: "The denial
// mechanism means a device can maintain an operational state while having a
// mechanism by which it can promptly complete the handshake of a quiescence
// request." A PPU power-mode transition can run for hundreds of cycles -- five
// device-control delays, an entry delay of up to 255, and the PCSM's tinit --
// and leaving a controller parked in Q_REQUEST for all of it is precisely what
// Q_DENIED exists to avoid.
//
// dev_busy is the other half, kept separate because the two are not the same
// question. dev_deny says "refuse this request"; dev_busy says "I will accept,
// but not yet". The CLK-CTRL's hierarchical channels need both: they deny when
// a downstream device denies, and they stall while the downstream channels are
// still walking into Q_STOPPED.
//
// RESET
//
// Section 2.1.2 "Device reset": "At reset assertion a device must drive both
// QACCEPTn and QDENY LOW", which is Q_STOPPED -- so that is the reset state.
// QACTIVE "can reset LOW or HIGH. If the device must perform start-up
// operations on exit from reset then it can reset QACTIVE HIGH". Being a wire,
// QACTIVE resets to whatever dev_active reads, which for the PPU is HIGH: it
// has a PCSM initialization handshake and a default power policy to reach
// before it is idle. That is the correct answer for free, rather than a
// parameter someone has to remember to set.

import qchannel_pkg::*;

module qchannel_device_comb #(
  // PCK-600 calls this QCLK_SYNC_EN on the PPU and HC_Q_CH_SYNC /
  // PWR_Q_CH_SYNC on the CLK-CTRL; all three select the same thing, so the
  // parameter is spelled once here and named by the instantiator.
  //   1 = QREQn arrives asynchronously and is synchronized (the safe default)
  //   0 = QREQn is already synchronous to clk and is used directly
  parameter bit          Q_CH_SYNC   = 1'b1,
  parameter int unsigned SYNC_STAGES = 2
) (
  input  logic clk,
  input  logic rst_n,     // async assert, deassert synchronous to clk

  // ---- Q-Channel, device side ----
  input  logic qreqn,     // from the controller (async when Q_CH_SYNC)
  output logic qacceptn,  // registered on clk
  output logic qdeny,     // registered on clk
  output logic qactive,   // COMBINATIONAL -- see the header

  // ---- Device-internal ----
  input  logic dev_active,        // 1 = this device needs the managed clock
  input  logic dev_deny,          // 1 = refuse a quiescence request outright
  input  logic dev_busy,          // 1 = will accept, but not yet
  output logic dev_quiescent_ok,  // 1 = interface in Q_STOPPED
  // 1 = the controller has asked for quiescence and this device has not
  // refused, i.e. Q_REQUEST or Q_STOPPED. The CLK-CTRL needs the pair rather
  // than just Q_STOPPED: it must start pushing its own devices down as soon as
  // a hierarchical controller ASKS, not only once it has already accepted.
  output logic q_requested
);

  // ---------------------------------------------------------------------------
  // QREQn into this clock domain. It resets LOW because Q_STOPPED is the reset
  // state of the interface and QREQn is LOW there -- the same reset value
  // qchannel_device uses, for the same reason.
  // ---------------------------------------------------------------------------
  logic qreqn_s;

  generate
    if (Q_CH_SYNC) begin : g_sync
      cdc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0))
      u_qreqn_sync (.clk(clk), .rst_n(rst_n), .d(qreqn), .q(qreqn_s));
    end else begin : g_nosync
      assign qreqn_s = qreqn;
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // The six-state Moore FSM of Table 2-1. Same shape as qchannel_device: state
  // and the handshake outputs move on the same edge, so QACCEPTn and QDENY are
  // always direct register outputs rather than a decode of state.
  // ---------------------------------------------------------------------------
  qch_state_e state;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state    <= Q_STOPPED;
      qacceptn <= 1'b0;   // Section 2.1.2 "Device reset"
      qdeny    <= 1'b0;
    end else begin
      unique case (state)
        // Operational. Wait for the controller to request quiescence.
        Q_RUN: begin
          if (!qreqn_s) state <= Q_REQUEST;
        end
        // Requested. Deny if the clock is still needed, accept once idle,
        // otherwise stay operational and keep the controller waiting.
        Q_REQUEST: begin
          if (dev_deny) begin
            state <= Q_DENIED;
            qdeny <= 1'b1;
          end else if (!dev_busy) begin
            state    <= Q_STOPPED;
            qacceptn <= 1'b0;
          end
        end
        // Quiescent. The clock may be gated here and this FSM stops with it;
        // nothing below this line runs again until the controller has restored
        // the clock, which Section 2.1.2 obliges it to do before Q_EXIT.
        Q_STOPPED: begin
          if (qreqn_s) state <= Q_EXIT;
        end
        // Exiting. Acknowledge with QACCEPTn HIGH.
        Q_EXIT: begin
          state    <= Q_RUN;
          qacceptn <= 1'b1;
        end
        // Denied. Wait for the controller to withdraw its request.
        Q_DENIED: begin
          if (qreqn_s) state <= Q_CONTINUE;
        end
        // Continuing. Complete the denied handshake with QDENY LOW.
        Q_CONTINUE: begin
          state <= Q_RUN;
          qdeny <= 1'b0;
        end
        default: state <= Q_STOPPED;
      endcase
    end
  end

  // Section 2.1.1: "The handshake signal states are independent of the state of
  // QACTIVE. Therefore, transitions on QACTIVE are not restricted by the values
  // on QREQn or on the QACCEPTn and QDENY output pair." Written as a wire off
  // the device-internal condition, so that independence is structural.
  assign qactive = dev_active;

  assign dev_quiescent_ok = (state == Q_STOPPED);
  assign q_requested      = (state == Q_REQUEST) || (state == Q_STOPPED);

endmodule
