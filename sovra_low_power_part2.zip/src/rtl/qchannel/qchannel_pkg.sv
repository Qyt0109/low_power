`timescale 1ns/1ps
// Q-Channel package: interface-state encoding and decode helper.
//
// Implements the handshake state definitions from the AMBA Low Power Interface
// Specification (ARM IHI 0068C), Section 2.1, Table 2-1 "Q-Channel handshake
// states". The interface state is a pure function of the three handshake wires
// {QREQn, QACCEPTn, QDENY}; QACTIVE is deliberately excluded because, per the
// spec, transitions on QACTIVE are independent of the handshake.
//
//   QREQn  QACCEPTn QDENY  State        Meaning
//   -----  -------- -----  -----------  ------------------------------------------
//     1       1       0    Q_RUN        Device operational
//     0       1       0    Q_REQUEST    Operational, requested to quiesce when idle
//     0       0       0    Q_STOPPED    Quiescent (no clock/power guarantee)
//     1       0       0    Q_EXIT       Supply guaranteed; device acks -> Q_RUN
//     0       1       1    Q_DENIED     Device denied; stays operational
//     1       1       1    Q_CONTINUE   Controller deasserted QREQn after a denial
//     x       0       1    (illegal)    Unused combination

package qchannel_pkg;

  typedef enum logic [2:0] {
    Q_RUN,
    Q_REQUEST,
    Q_STOPPED,
    Q_EXIT,
    Q_DENIED,
    Q_CONTINUE,
    Q_ILLEGAL
  } qch_state_e;

  // Decode the interface state from the three handshake signals.
  function automatic qch_state_e qch_decode(input logic qreqn,
                                            input logic qacceptn,
                                            input logic qdeny);
    // Table 2-1: any state with QACCEPTn LOW and QDENY HIGH is illegal.
    if (qacceptn == 1'b0 && qdeny == 1'b1) return Q_ILLEGAL;
    case ({qreqn, qacceptn, qdeny})
      3'b110:  return Q_RUN;
      3'b010:  return Q_REQUEST;
      3'b000:  return Q_STOPPED;
      3'b100:  return Q_EXIT;
      3'b011:  return Q_DENIED;
      3'b111:  return Q_CONTINUE;
      default: return Q_ILLEGAL;
    endcase
  endfunction

  // Human-readable name, for logging.
  function automatic string qch_name(input qch_state_e s);
    case (s)
      Q_RUN:      return "Q_RUN";
      Q_REQUEST:  return "Q_REQUEST";
      Q_STOPPED:  return "Q_STOPPED";
      Q_EXIT:     return "Q_EXIT";
      Q_DENIED:   return "Q_DENIED";
      Q_CONTINUE: return "Q_CONTINUE";
      default:    return "Q_ILLEGAL";
    endcase
  endfunction

endpackage
