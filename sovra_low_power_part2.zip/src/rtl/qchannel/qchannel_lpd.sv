`timescale 1ns/1ps
// LPD-Q -- Low Power Distributor, Q-Channel.
//
// Reference: Arm CoreLink PCK-600 TRM (101150 r0p5) Section 3.1 and Table A-1;
// Arm PCSA (DEN 0050 D) Section 6.5.3; AMBA Low Power Interface Specification
// (ARM IHI 0068C) Section 2.1.
//
// PCSA 6.5.3 states why it exists: "A PPU or Clock Controller are typically
// required to communicate with many components within a clock or power domain.
// A Low Power Distributor (LPD) distributes a single Q-Channel or P-Channel to
// multiple channels."
//
// This block is a DEVICE on its control side and N CONTROLLERS on its device
// side. One PPU's DEVQREQn goes in; 2 to 32 device Q-Channels come out.
//
//   PPU / CLK-CTRL          LPD-Q                     devices
//    (controller)     [device | controller]
//    QREQn      ----> ctrl_qreqn_i   dev_qreqn_o[0]  ----> device 0
//    QACCEPTn   <---- ctrl_qacceptn_o dev_qacceptn_i[0] <--
//    QDENY      <---- ctrl_qdeny_o   dev_qreqn_o[1]  ----> device 1
//    QACTIVE    <---- ctrl_qactive_o dev_qacceptn_i[1] <--
//
// -----------------------------------------------------------------------------
// WHY THIS AND NOT A MULTI-CHANNEL PPU
//
// DEN 0051E allows a PPU with 2-8 device Q-Channels, and this repository's
// CONFORMANCE.md calls that "the biggest architectural change on this list" --
// "the device accepted" becomes "all N accepted", denial becomes "any denied",
// and the denial path has to record WHICH.
//
// An LPD-Q gets the same capability with ppu_seq untouched, and it adds the one
// thing a multi-channel PPU does NOT give you: ORDER. A multi-channel PPU moves
// its channels together. SEQUENCER mode here moves them one at a time, which is
// what a domain containing a master and the port it transacts through needs.
//
// -----------------------------------------------------------------------------
// THE FOUR RULES, ALL FROM SECTION 3.1
//
//   ACCEPT   "The LPD-Q accepts a controller quiescence request, if all devices
//            indicate acceptance of the quiescence request by setting
//            dev_qacceptn_i<X> LOW."
//
//   DENY     "either when: A dev_qdeny_i<X> asserts, in response to the
//            assertion of dev_qreqn_o<X>. [or] A dev_qactive_i<X> goes HIGH,
//            between the assertion of all dev_qreqn_o<X> signals and the
//            assertion of the last dev_qacceptn_i<X>. This behavior only occurs
//            when the ACTIVE_DENY configuration parameter is set to 1."
//
//   ACTIVITY "The ctrl_qactive_o output is the logical OR of the multiple device
//            inputs, dev_qactive_i<X>. The path from the dev_qactive_i<X>
//            signals to the ctrl_qactive_o output is a combinatorial path."
//
//   CLOCK    clk_qactive_o is HIGH when any handshake is in flight -- the four
//            bullets of Section 3.1, implemented literally below.
//
// -----------------------------------------------------------------------------
// WHAT THE SPEC DOES NOT SAY, AND WHAT THIS DOES ABOUT IT
//
// INTERPRETATION 1 -- EXIT ORDER.
// Table 3-1 has five parameters (SEQUENCER, NUM_QCHL, CTRL_Q_CH_SYNC,
// DEV_Q_CH_SYNC, ACTIVE_DENY) and NONE of them selects a direction. Section
// 3.1.2 says only that a request is "passed sequentially to each device
// Q-Channel", for entry and exit alike. Read literally, exit walks the SAME
// order as entry -- so in a domain wired [0]=master, [1]=port, the master leaves
// quiescence before the port it transacts through.
//
// This block takes the literal reading and walks index 0..N-1 in both
// directions, because inventing a reversal the spec does not describe would
// make it silently incompatible with a real LPD-Q.
//
// The hazard is real but is normally masked: a PPU holds DEVRSTn asserted until
// the whole domain is up (DEN 0051E Section 4.1.5), so nothing inside is
// executing when the exit sequence runs. That is a property of the INTEGRATION,
// not of this block, and REVERSE_EXIT is provided for integrations that cannot
// rely on it. It defaults OFF -- spec behaviour is the default.
//
// INTERPRETATION 2 -- DENIAL DURING A SEQUENCE.
// Section 3.1 describes denial for the expander case, where all dev_qreqn_o are
// asserted together. In sequencer mode there is no such moment. This block
// denies as soon as any device denies, and does NOT continue down the chain --
// a denial means the transition is off, so asking the rest would be pointless
// work whose acceptances would then have to be undone.

import qchannel_pkg::*;

module qchannel_lpd #(
  // Table 3-1: 2-32 device Q-Channel interfaces.
  parameter int unsigned NUM_QCHL       = 2,
  // 0 = expander (broadcast, any completion order)
  // 1 = sequencer (one at a time, each completing before the next)
  parameter bit          SEQUENCER      = 1'b0,
  // 1 = a synchronizer is present on ctrl_qreqn_i
  parameter bit          CTRL_Q_CH_SYNC = 1'b1,
  // 1 = synchronizers are present on dev_qacceptn_i and dev_qdeny_i
  parameter bit          DEV_Q_CH_SYNC  = 1'b1,
  // 1 = activity arriving mid-entry denies the request (Section 3.1).
  // Table 3-1 also makes this the parameter that BRINGS IN the dev_qactive_i
  // synchronizers: "Synchronizers are included on the dev_qactive_i[N] inputs,
  // where these signals are used internally depending on the value of
  // DEV_QACTIVE_SYNC."
  parameter bit          ACTIVE_DENY      = 1'b0,
  // Table 3-1, sixth parameter: "0 = A synchronizer is not present on the || of
  // all the dev_qactive_i[N] inputs. 1 = A synchronizer is present on the || of
  // all the dev_qactive_i[N] inputs."
  //
  // On the OR, not per bit -- one flop pair, not NUM_QCHL of them. And only the
  // INTERNAL use is affected; Table 3-1's note is explicit that "The path from a
  // device to the controller QACTIVE is combinatorial, irrespective of whether
  // synchronizers are present."
  parameter bit          DEV_QACTIVE_SYNC = 1'b0,
  parameter int unsigned SYNC_STAGES    = 2,
  // NOT in Table 3-1. See INTERPRETATION 1. 0 = spec behaviour.
  parameter bit          REVERSE_EXIT   = 1'b0
) (
  input  logic clk,
  input  logic reset_n,       // async assert, deassert synchronous to clk

  // ---- Table A-1: control Q-Channel (device side) ----
  input  logic ctrl_qreqn_i,
  output logic ctrl_qacceptn_o,
  output logic ctrl_qdeny_o,
  output logic ctrl_qactive_o,

  // ---- Table A-1: device Q-Channels (controller side) ----
  output logic [NUM_QCHL-1:0] dev_qreqn_o,
  input  logic [NUM_QCHL-1:0] dev_qacceptn_i,
  input  logic [NUM_QCHL-1:0] dev_qdeny_i,
  input  logic [NUM_QCHL-1:0] dev_qactive_i,

  // ---- Table A-4: the LPD-Q's own clock request ----
  output logic clk_qactive_o,

  // ---- Table A-5: DFT ----
  // "enables the architectural clock gates, and ensures that the clk logic is
  // active during DFT shift mode." Clock column "clk", so it is synchronous by
  // contract and is deliberately not synchronized -- the same reasoning
  // ppu_clk_ctrl records for its own dftcgen.
  input  logic dftcgen
);

  // ---------------------------------------------------------------------------
  // Elaboration checks
  // ---------------------------------------------------------------------------
  initial begin
    if (NUM_QCHL < 2 || NUM_QCHL > 32)
      $fatal(1, "qchannel_lpd: NUM_QCHL must be 2-32 (PCK-600 Table 3-1), got %0d",
             NUM_QCHL);
    if (SYNC_STAGES < 2 && (CTRL_Q_CH_SYNC || DEV_Q_CH_SYNC))
      $fatal(1, "qchannel_lpd: SYNC_STAGES must be >= 2 when a synchronizer is enabled, got %0d",
             SYNC_STAGES);
  end

  // ---------------------------------------------------------------------------
  // Device-side input synchronization
  // ---------------------------------------------------------------------------
  // DEV_Q_CH_SYNC covers dev_qacceptn_i and dev_qdeny_i, exactly as Table 3-1
  // words it. dev_qactive_i is deliberately NOT in that list and is NOT
  // synchronized on the path to ctrl_qactive_o -- Section 3.1 requires that path
  // to be combinatorial. It IS synchronized on the path into this block's own
  // decisions, because a metastable bit there would corrupt the sequencer.
  logic [NUM_QCHL-1:0] acceptn_s, deny_s;

  cdc_sync #(.WIDTH(NUM_QCHL), .STAGES(DEV_Q_CH_SYNC ? SYNC_STAGES : 0),
             .RESET_VAL(1'b1))
    u_acc_sync (.clk(clk), .rst_n(reset_n), .d(dev_qacceptn_i), .q(acceptn_s));

  cdc_sync #(.WIDTH(NUM_QCHL), .STAGES(DEV_Q_CH_SYNC ? SYNC_STAGES : 0),
             .RESET_VAL(1'b0))
    u_dny_sync (.clk(clk), .rst_n(reset_n), .d(dev_qdeny_i), .q(deny_s));

  // Activity, INTERNAL view. One flop pair on the OR rather than NUM_QCHL of
  // them on the bits, because Table 3-1 words DEV_QACTIVE_SYNC as a
  // synchronizer "on the || of all the dev_qactive_i[N] inputs".
  //
  // Present only when ACTIVE_DENY brings it in -- with ACTIVE_DENY == 0 nothing
  // internal reads activity at all, so synchronizing it would be flops that no
  // logic consumes. The first version keyed this off DEV_Q_CH_SYNC, which
  // Table 3-1 scopes to dev_qacceptn_i and dev_qdeny_i only.
  wire any_active_comb = |dev_qactive_i;
  logic any_active_int;

  cdc_sync #(.WIDTH(1),
             .STAGES((ACTIVE_DENY && DEV_QACTIVE_SYNC) ? SYNC_STAGES : 0),
             .RESET_VAL(1'b0))
    u_act_sync (.clk(clk), .rst_n(reset_n),
                .d(any_active_comb), .q(any_active_int));

  // ---------------------------------------------------------------------------
  // The control-side device FSM
  // ---------------------------------------------------------------------------
  // qchannel_device_comb, not qchannel_device: Section 3.1 makes the
  // dev_qactive_i -> ctrl_qactive_o path combinatorial, and the registered
  // variant cannot express that. Its dev_busy input is what holds ctrl_qacceptn_o
  // HIGH while the devices below are still being walked.
  logic all_stopped, any_denied, ctrl_requested, ctrl_stopped;

  // ACCEPT: every channel has reached Q_STOPPED. Section 3.1. Taken from the
  // per-channel controllers rather than from the raw pins, so "accepted" means
  // the FSM agrees, not just that a level looks right.
  logic [NUM_QCHL-1:0] dev_stopped;
  assign all_stopped = (&dev_stopped);

  // DENY, first condition: a device denied in response to its request.
  // Latched, because a denial is a decision about a request rather than a level
  // -- by the time the controller has walked Q_DENIED -> Q_CONTINUE -> Q_RUN the
  // pin is LOW again. Same reasoning as ppu_clk_ctrl's deny_seen.
  logic deny_latched;
  always_ff @(posedge clk or negedge reset_n) begin
    if (!reset_n)              deny_latched <= 1'b0;
    else if (!ctrl_requested)  deny_latched <= 1'b0;   // request withdrawn: forget
    else if (|deny_s)          deny_latched <= 1'b1;
  end

  // DENY, second condition: ACTIVE_DENY. Section 3.1 scopes it to the window
  // "between the assertion of all dev_qreqn_o<X> signals and the assertion of
  // the last dev_qacceptn_i<X>" -- i.e. a request is outstanding and not yet
  // fully accepted.
  wire entry_in_flight = ctrl_requested && !all_stopped;
  wire active_deny     = ACTIVE_DENY && entry_in_flight && any_active_int;

  assign any_denied = deny_latched || active_deny;

  // ---- halting the walk needs the UNLATCHED denial ----
  //
  // any_denied is what the control side reports, and it is deliberately
  // registered -- a denial is a decision that must outlive the pin. The
  // sequencer cannot wait for it. deny_latched rises one cycle AFTER deny_s,
  // and in that cycle cur_done is already true (a denial counts as a response),
  // so the walk steps PAST the denier and asks the next device. Measured: two
  // ordering violations per denial, and L7 saw channel 2 asked after channel 1
  // had refused.
  //
  // walk_halt is the same condition without the register, used only to stop the
  // walk and clear the request vector in the cycle the denial appears.
  wire walk_halt = (|deny_s) || deny_latched || active_deny;

  qchannel_device_comb #(
    .Q_CH_SYNC  (CTRL_Q_CH_SYNC),
    .SYNC_STAGES(SYNC_STAGES)
  ) u_ctrl (
    .clk             (clk),
    .rst_n           (reset_n),
    .qreqn           (ctrl_qreqn_i),
    .qacceptn        (ctrl_qacceptn_o),
    .qdeny           (ctrl_qdeny_o),
    .qactive         (ctrl_qactive_o),
    // Section 3.1: "The ctrl_qactive_o output is the logical OR of the multiple
    // device inputs" -- RAW, not synchronized, because the path must be
    // combinatorial.
    .dev_active      (any_active_comb),
    .dev_deny        (any_denied),
    // Hold the accept until every device below has stopped. Without this the
    // LPD-Q would tell its controller "quiescent" with devices still running.
    .dev_busy        (!all_stopped),
    .dev_quiescent_ok(ctrl_stopped),
    .q_requested     (ctrl_requested)
  );

  // ---------------------------------------------------------------------------
  // Per-device request generation
  // ---------------------------------------------------------------------------
  // dev_req[i] is this block's REQUEST to device i, active HIGH, inverted onto
  // dev_qreqn_o at the port. Combinational in the expander (one broadcast),
  // registered in the sequencer (walked one channel per cycle).
  logic [NUM_QCHL-1:0] dev_req;

  generate
    if (!SEQUENCER) begin : g_expander
      // ---- Section 3.1.1: expander ----
      // "the LPD-Q ... sends the request to all the device Q-Channels. The LPD-Q
      // waits for all devices to accept or a denial to occur, before it
      // generates the response to the controller."
      //
      // Broadcast, and drop them all the moment a denial lands so the devices
      // that did accept are released rather than left stopped under a request
      // the controller has already been told was denied.
      always_comb begin
        dev_req = {NUM_QCHL{ctrl_requested && !any_denied}};
      end
    end else begin : g_sequencer
      // ---- Section 3.1.2: sequencer ----
      // "a controller Q-Channel transition request ... is passed sequentially to
      // each device Q-Channel. The LPD-Q waits for the response from each device
      // before sending a quiescence request to the next device."
      //
      // dev_req is REGISTERED STATE walked one position at a time, not a
      // function of the counter. Two earlier attempts made it a pure function
      // and both were wrong in ways the Q-Channel monitors caught:
      //
      //   * keyed off the combinational ctrl_requested, it broadcast to every
      //     channel for one cycle at each reversal -- 44 ordering violations
      //   * cleared in bulk on a denial, it withdrew QREQn from devices sitting
      //     in Q_REQUEST, which IHI 0068C Section 2.1.1 forbids: QREQn may only
      //     be withdrawn from Q_STOPPED or Q_DENIED -- 47 protocol violations
      //
      // Walking a register makes both unreachable: nothing ever changes more
      // than one channel per cycle, so there is no bulk transition to get wrong.
      localparam int unsigned CNT_W = $clog2(NUM_QCHL + 1);
      logic [CNT_W-1:0] done;

      logic ctrl_req_d;
      always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) ctrl_req_d <= 1'b0;
        else          ctrl_req_d <= ctrl_requested;
      end
      wire direction_changed = (ctrl_requested != ctrl_req_d);

      // Walk order. Entry always ascends. Exit descends only when REVERSE_EXIT
      // is set -- see INTERPRETATION 1 in the header.
      wire descending = REVERSE_EXIT && !ctrl_req_d;
      wire [CNT_W-1:0] pos = (done < CNT_W'(NUM_QCHL)) ? done : '0;
      wire [CNT_W-1:0] idx = descending ? (CNT_W'(NUM_QCHL) - 1'b1 - pos) : pos;

      wire walking = (done != CNT_W'(NUM_QCHL));

      // ENTRY: this position is finished when the device has responded --
      // accepted or denied.
      wire entry_responded = dev_stopped[idx] || deny_s[idx];

      // EXIT: finished when the device is back in Q_RUN. A device that was
      // never asked (an aborted entry left the walk short) already reads
      // QACCEPTn HIGH, so the walk steps over it in one cycle rather than
      // needing a separate "was it asked" record.
      wire exit_responded = acceptn_s[idx];

      always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
          done    <= '0;
          dev_req <= '0;
        end else if (direction_changed) begin
          // Restart the walk. dev_req is deliberately NOT touched: the walk
          // itself drives every channel, one per cycle, and a bulk change here
          // is exactly what the second attempt got wrong.
          done <= '0;
        end else if (walking) begin
          if (ctrl_req_d) begin
            // ---- entry ----
            // walk_halt freezes rather than clears. On a denial the devices
            // already asked stay asked until the controller withdraws, which
            // arrives as a direction change and runs the exit walk.
            if (walk_halt) begin
              // A denial ends the transition. Withdraw every request rather
              // than freezing them: with a qchannel_controller per channel this
              // is now safe -- each one finishes its own handshake before
              // raising QREQn, so no channel is withdrawn from Q_REQUEST.
              //
              // Freezing them was WORSE than unsafe, it looped: dev_req[i] left
              // asserted on a channel that has just denied sends its controller
              // Q_DENIED -> Q_CONTINUE -> Q_RUN and then straight back into
              // Q_REQUEST, re-asking a device that has already refused. The
              // same retry trap ppu_clk_ctrl's DENY_RETRY_DLY exists to avoid.
              dev_req <= '0;
            end else begin
              dev_req[idx] <= 1'b1;
              if (entry_responded) done <= done + 1'b1;
            end
          end else begin
            // ---- exit ----
            dev_req[idx] <= 1'b0;
            if (exit_responded) done <= done + 1'b1;
          end
        end
      end
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // One qchannel_controller per device channel
  // ---------------------------------------------------------------------------
  // dev_req is a REQUEST, not the pin. Driving dev_qreqn_o directly was wrong
  // and the monitors said so within 75ns of reset release: qchannel_controller
  // resets to Q_STOPPED with QREQn LOW, matching the device reset boundary of
  // IHI 0068C Section 2.1.2, and the interface must then be walked
  // Q_STOPPED -> Q_EXIT -> Q_RUN. A raw drive dropped QREQn while the channel
  // was still in Q_EXIT -- R1, "QREQn fell outside Q_RUN".
  //
  // Delegating each channel to the verified controller removes that whole class
  // of error: Q_EXIT, and the Q_DENIED -> Q_CONTINUE -> Q_RUN recovery after a
  // denial, are its job rather than this block's.
  //
  // The QACTIVE-led policies are tied OFF. Section 2.1.3 lets a controller use
  // QACTIVE to drive its own entry and exit, but here the policy comes from
  // above -- the LPD-Q distributes its controller's decision and must not
  // invent one per channel.
  generate
    for (genvar i = 0; i < NUM_QCHL; i++) begin : g_dev_ctrl
      qchannel_controller #(.SYNC_STAGES(DEV_Q_CH_SYNC ? SYNC_STAGES : 0)) u_c (
        .clk   (clk),
        .rst_n (reset_n),
        .qreqn   (dev_qreqn_o[i]),
        .qacceptn(dev_qacceptn_i[i]),
        .qdeny   (dev_qdeny_i[i]),
        .qactive (dev_qactive_i[i]),
        .req_dev_quiescence(dev_req[i]),
        .enb_qactive_led_quiescence_enter(1'b0),
        .enb_qactive_led_quiescence_exit (1'b0),
        .dev_stopped(dev_stopped[i])
      );
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // clk_qactive_o -- Section 3.1, four bullets, literally
  // ---------------------------------------------------------------------------
  // "The clk_qactive_o is a Q-Channel signal that is HIGH:
  //    * When a device has the dev_qreqn_o<X> and dev_qacceptn_i<X> signals in
  //      opposites states.
  //    * When any dev_qdeny_i<X> is HIGH.
  //    * When ctrl_qreqn_i and ctrl_qacceptn_o signals are in opposites states.
  //    * When ctrl_qdeny_o is HIGH."
  //
  // Combinational and on the RAW pins, not the synchronized copies: this output
  // exists so an upstream CLK-CTRL knows to keep THIS block's clock running, and
  // a registered version could not be produced without the clock it is asking
  // for -- the same trap qchannel_device_comb's header describes.
  wire dev_mismatch  = |(dev_qreqn_o ^ dev_qacceptn_i);
  wire ctrl_mismatch = ctrl_qreqn_i ^ ctrl_qacceptn_o;

  assign clk_qactive_o = dev_mismatch
                      || (|dev_qdeny_i)
                      || ctrl_mismatch
                      || ctrl_qdeny_o
                      // Table A-5: hold the clock on through DFT shift. Not one
                      // of the four bullets -- it overrides them.
                      || dftcgen;

  // Silence lint on a signal kept for readability at the instantiation site.
  wire _unused_ok = ctrl_stopped;

endmodule
