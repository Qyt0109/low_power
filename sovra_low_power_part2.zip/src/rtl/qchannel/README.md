# Q-Channel RTL — AMBA Low Power Interface

A synthesizable SystemVerilog implementation of the **Q-Channel** low-power
handshake from the **AMBA Low Power Interface Specification (ARM IHI 0068C,
Section 2.1)**, with self-checking testbenches and an executable protocol checker.
The controller and device sit in **independent, asynchronous clock domains** (as
the spec requires — §2.1.1 states all Q-Channel signals are asynchronous): every
interface output is a **registered flip-flop** and every cross-domain input passes
through a **multi-flop synchronizer**.

The integration top level follows **PCSA (ARM DEN0050) §8.2.1** and instantiates
**two independent Q-Channels** — one for clock control, one for power control —
with the power channel's `Q_STOPPED` status gating device-reset assertion
(IHI 0068C §2.1.2 "Device reset"). This is the concrete, runnable counterpart to
AMBA Low Power Interface specification,
[`references/standards/arm-amba-low-power-interface-spec.pdf`](../../../references/standards/arm-amba-low-power-interface-spec.pdf)
(IHI 0068C). (It was also the counterpart to notes 11 and 16 of the research
notes, removed 2026-10-06.)

> Verified with **Icarus Verilog 12.0**. `make pd` → **79 checks, PASS**, with
> **0 protocol violations** on both monitored channels. See §8.1 for the one
> verification gap this does not close.

## Contents

- [1. Background — what the Q-Channel is](#1-background--what-the-q-channel-is)
- [2. Architecture](#2-architecture)
- [3. Module reference](#3-module-reference)
- [4. The two FSMs in detail](#4-the-two-fsms-in-detail)
- [5. Handshake rules and how they are enforced](#5-handshake-rules-and-how-they-are-enforced)
- [6. Waveforms](#6-waveforms)
- [7. Clock-domain crossing and latency](#7-clock-domain-crossing-and-latency)
- [8. Verification](#8-verification)
- [9. Running](#9-running)
- [10. Integration guide](#10-integration-guide)
- [11. Scope and limitations](#11-scope-and-limitations)
- [12. References](#12-references)

---

## 1. Background — what the Q-Channel is

A four-signal handshake between a **controller** (a clock/power manager, e.g. an
Arm PPU or an SoC power-management unit) and a **device** (a peripheral, memory,
or CPU that can be quiesced). It lets the controller request the device enter a
single quiescent state — clock stopped or power removed — and, crucially, lets the
device **deny** the request if it is busy, preventing data loss. Signal polarities
are chosen so the quiescent boundary is **all-LOW**, which makes default isolation
(clamp-to-zero) trivially safe.

| Signal | Driver | Polarity | Meaning |
|---|---|---|---|
| `QREQn`    | controller | active LOW  | request the device become quiescent |
| `QACCEPTn` | device     | active LOW  | accept the quiescence request |
| `QDENY`    | device     | active HIGH | deny the quiescence request |
| `QACTIVE`  | device     | active HIGH | device activity / wake indication |

The interface occupies one of **six legal states**, decoded purely from the vector
`{QREQn, QACCEPTn, QDENY}` (Table 2-1). `QACTIVE` is deliberately *not* part of the
state — the spec says transitions on `QACTIVE` are independent of the handshake.

| `QREQn` | `QACCEPTn` | `QDENY` | State | Device availability |
|:---:|:---:|:---:|---|---|
| 1 | 1 | 0 | **Q_RUN** | Operational |
| 0 | 1 | 0 | **Q_REQUEST** | Operational, asked to quiesce when idle |
| 0 | 0 | 0 | **Q_STOPPED** | Quiescent — **no** clock/power guarantee |
| 1 | 0 | 0 | **Q_EXIT** | Supply guaranteed again; device will ack |
| 0 | 1 | 1 | **Q_DENIED** | Denied; stays operational |
| 1 | 1 | 1 | **Q_CONTINUE** | Controller withdrew request after a denial |
| x | 0 | 1 | *(illegal)* | Unused combination |

```
        QACCEPTn HIGH                 QREQn LOW
   Q_EXIT ─────────────► Q_RUN ──────────────────► Q_REQUEST
     ▲   [1,0,0]        [1,1,0]                     [0,1,0]  │
     │ QREQn HIGH          ▲                                │ │
     │                     │ QDENY LOW           QACCEPTn LOW│ │ QDENY HIGH
     │                  Q_CONTINUE ◄── QREQn HIGH ── Q_DENIED│ │
  Q_STOPPED             [1,1,1]                     [0,1,1]  │ │
   [0,0,0] ◄───────────────────────────────────────────────┘◄┘
                          (state vector = [QREQn, QACCEPTn, QDENY])
```

* **Accepted quiescence:** `Q_RUN → Q_REQUEST → Q_STOPPED → Q_EXIT → Q_RUN` (Figure 2-2).
* **Denied quiescence:** `Q_RUN → Q_REQUEST → Q_DENIED → Q_CONTINUE → Q_RUN` (Figure 2-3).

---

## 2. Architecture

### 2.1 One channel

The controller and device are separate modules on **unrelated clocks**. Each drives
its interface outputs from flip-flops and synchronizes the far side's outputs before
using them. The passive monitor observes the raw interface wires.

```
        controller clock domain                     device clock domain
  ┌──────────────────────────────────────┐   ┌──────────────────────────────────────┐
  │           qchannel_controller         │   │             qchannel_device           │
  │                                       │   │                                       │
  │ req_dev_quiescence ─►┌─────┐          │   │  ┌────────┐   ┌─────┐                 │
  │ enb_qactive_..._enter│     │  QREQn   │   │  │  2-FF  │   │     │◄ dev_quiescent_busy
  │ enb_qactive_..._exit ┤ FSM ├─(reg)────┼───┼─►│  sync  ├──►│ FSM │◄ dev_quiescent_deny
  │                   ┌─►│     │          │   │  └────────┘   │     │◄ dev_wake       │
  │                   │  └─────┘          │   │               └──┬──┘                 │
  │              ┌────┴─────┐   QACCEPTn  │◄──┼──────────────────┤ QACCEPTn (reg)     │
  │              │  2-FF    │◄─ QDENY ────┼◄──┼──────────────────┤ QDENY    (reg)     │
  │              │  sync ×3 │◄─ QACTIVE ──┼◄──┼──────────────────┤ QACTIVE  (reg)     │
  │              └──────────┘             │   │                                       │
  │  dev_stopped ◄─ (state == Q_STOPPED)  │   │  dev_quiescent_ok ◄─ (state==Q_STOPPED)
  └──────────────────────────────────────┘   └──────────────────────────────────────┘
             ▲          ▲          ▲
      QREQn  │  QACCEPTn│    QDENY │            (raw interface wires)
          ┌──┴──────────┴──────────┴──┐
          │      qchannel_monitor      │  oversampled on its own clock,
          │  (R1–R7 wire rules, plus   │  reports `violations`
          │   R8/R9 reset, R10 gate)   │
          └────────────────────────────┘
```

Key structural properties:

* **`QREQn`** is a register output of the controller; **`QACCEPTn`, `QDENY`,
  `QACTIVE`** are register outputs of the device. No interface signal is a raw
  combinational decode, so the far domain always synchronizes a clean level.
* The device 2-FF-synchronizes the one input it receives (`QREQn`); the controller
  2-FF-synchronizes the three it receives (`QACCEPTn`, `QDENY`, `QACTIVE`).
* Both FSMs reset into **`Q_STOPPED`** with all three wires LOW — the legal
  quiescent boundary required by §2.1.2 "Device reset".

### 2.2 Two channels — the integration top level

`qchannel_pd_top` wires up **two independent Q-Channel pairs**, because PCSA
§8.2.1 requires it: *"Each clock requires a separate Q-Channel interface… The
clock control Q-Channels must be separate from any power control LPIs."* A clock
quiescing tells you nothing about whether it is safe to reset or power down the
domain, so the two decisions are negotiated separately.

```
  always-on domain (aon_clk / aon_rst_n)          device domain (dclk)
 ┌────────────────────────────────────┐  ┌───────────────────────────────────────┐
 │                                     │  │                                       │
 │ pd_req ─► u_ctrl_clk ══ CLK channel ═══► u_dev_clk ─► dev_quiescent_ok         │
 │                ▲                    │  │      ▲                │               │
 │                └── QACCEPTn/QDENY/QACTIVE ─────┘                ▼ (inverted)    │
 │                                     │  │              clk_gate (ICG) │
 │                                     │  │                       │ gated clock   │
 │                                     │  │                       ▼               │
 │ pwr_req ─► u_ctrl_pwr ══ PWR channel ═══► u_dev_pwr    dummy_workload           │
 │                ▲   │                │  │      ▲  ▲            │ busy           │
 │                └── QACCEPTn/QDENY/QACTIVE ─────┘  └────────────┘               │
 │                    │ dev_stopped_pwr │  │      │                                │
 │                    ▼                 │  │      │ rst_n                          │
 │ dev_rst_req ─► qchannel_devrst_ctrl ─── drst_n ┴──► u_dev_clk, u_dev_pwr,       │
 │                                     │  │            dummy_workload              │
 └────────────────────────────────────┘  └───────────────────────────────────────┘
```

* Both **controllers and the reset controller live in the always-on domain**
  (PCSA §7.2.3: *"the PPU must be placed in a power domain that is relative
  always-on to the power domain it is controlling"*). Because they share
  `aon_clk`, `dev_stopped_pwr` reaches `qchannel_devrst_ctrl` already in-domain
  and needs no resynchronizer.
* The **clock channel** actuates through the ICG: `dev_quiescent_ok` (true only
  in `Q_STOPPED`) is inverted into the ICG's active-HIGH `clk_en`.
* The **power channel** actuates through `drst_n`. That reset is shared by
  *both* device wrappers and the workload — once the domain is genuinely powered
  down, everything in it goes down together (PCSA §8.3.4: *"the reset state of
  the component should be equivalent to the quiescent state"*), and wake-up comes
  from outside the domain via `dev_rst_req`.
* `qchannel_pd_top` exposes **only real system-level ports** — clocks, resets and
  PM-policy inputs. Internal handshake wires and status signals are read by the
  testbench through hierarchical reference (e.g. `u_top.clk__qreqn`,
  `~u_top.u_clkctrl.en_latch`) rather than through debug-only ports.

---

## 3. Module reference

> Port names carry **no `_i`/`_o` suffixes** — direction is in the port
> declaration, not the identifier.

### `qchannel_pkg` — [`qchannel_pkg.sv`](qchannel_pkg.sv)
Interface-state enum `qch_state_e` `{Q_RUN, Q_REQUEST, Q_STOPPED, Q_EXIT, Q_DENIED,
Q_CONTINUE, Q_ILLEGAL}`, plus `qch_decode(qreqn, qacceptn, qdeny)` (Table 2-1) and
`qch_name()` for logging. Both FSMs use this enum directly as their state type.

### `cdc_sync` — [`cdc_sync.sv`](../common/cdc_sync.sv)
Parameterizable multi-flop synchronizer for one level signal.

| Parameter | Default | Meaning |
|---|---|---|
| `STAGES` | `2` | number of cascaded flops; **`0` = combinational passthrough** for a controller and device that genuinely share a clock (no metastability to resolve, no clock-to-q latency added) |
| `RESET_VAL` | `1'b0` | reset level (quiescent = LOW for all Q-Channel signals) |

| Port | Dir | Description |
|---|---|---|
| `clk`, `rst_n` | in | destination-domain clock and async-assert reset |
| `d` | in | asynchronous input from the far domain |
| `q` | out | synchronized output in this domain |

### `qchannel_device` — [`qchannel_device.sv`](qchannel_device.sv)
Device-side FSM: the wrapper that makes a peripheral Q-Channel compliant.

| Parameter | Default | Meaning |
|---|---|---|
| `SYNC_STAGES` | `2` | synchronizer depth for `QREQn` (`0` = same-domain) |

| Port | Dir | Domain | Description |
|---|---|---|---|
| `clk`, `rst_n` | in | device | clock, async-assert reset |
| `qreqn` | in | async | request from controller |
| `qacceptn` | out | device (reg) | accept, active LOW |
| `qdeny` | out | device (reg) | deny, active HIGH |
| `qactive` | out | device (reg) | activity indication, active HIGH |
| `dev_quiescent_busy` | in | device | 1 = cannot become quiescent yet |
| `dev_quiescent_deny` | in | device | 1 = refuse the request outright |
| `dev_wake` | in | device | 1 = advertise a wake event on `QACTIVE` |
| `dev_quiescent_ok` | out | device | **1 = device is quiescent (`Q_STOPPED`), safe to remove clock/power** |

Two notes on the device-internal contract:

* `dev_quiescent_ok` is the **logical inverse** of the older `dev_clk_en_o`
  ("1 = clock needed"). The polarity was flipped to match the `dev_quiescent_*`
  naming of the other device-internal signals: it now reads "1 = safe to remove".
  Consumers that want an active-HIGH clock enable invert it (as
  `qchannel_pd_top` does).
* `QACTIVE` is driven as `dev_quiescent_busy | dev_wake`, updated every cycle
  outside the state machine — per §2.1.3 it is independent of the handshake.
* There is **no `DENY_SUPPORTED` parameter**. To build the no-denial subset
  (§2.1.4, AXI-LP compatible) simply tie `dev_quiescent_deny` LOW; the
  `Q_DENIED`/`Q_CONTINUE` states then become unreachable and synthesis prunes them.

### `qchannel_controller` — [`qchannel_controller.sv`](qchannel_controller.sv)
Controller-side FSM: drives the request and implements the §2.1.3 policy.

| Parameter | Default | Meaning |
|---|---|---|
| `SYNC_STAGES` | `2` | synchronizer depth for `QACCEPTn`/`QDENY`/`QACTIVE` |

| Port | Dir | Domain | Description |
|---|---|---|---|
| `clk`, `rst_n` | in | controller | clock, async-assert reset |
| `qreqn` | out | controller (reg) | request, active LOW |
| `qacceptn`, `qdeny`, `qactive` | in | async | device outputs |
| `req_dev_quiescence` | in | controller | 1 = request device quiescence |
| `enb_qactive_led_quiescence_enter` | in | controller | 1 = `QACTIVE` LOW *also* triggers entry |
| `enb_qactive_led_quiescence_exit` | in | controller | 1 = `QACTIVE` HIGH *also* triggers exit |
| `dev_stopped` | out | controller | 1 = interface in `Q_STOPPED` (safe to gate clock / remove power) |

**Controller policy and `QACTIVE` (§2.1.3).** The spec says *"a controller can
make any policy decision concerning its management of QREQn irrespective of any
activity on QACTIVE"*, and gives two named example policies (Figures 2-7 and 2-8)
built from the same two ingredients: whether `QACTIVE` participates in *entering*
quiescence, and whether it participates in *exiting* it. Those are gated by the
two runtime inputs above — **runtime, not elaboration-time parameters**, so the
same power-management logic driving `req_dev_quiescence` can switch policy on the
fly.

| `enter` | `exit` | Policy |
|:---:|:---:|---|
| 0 | 1 | **Figure 2-8** — controller-initiated entry, device-led exit. The usual choice, and what `qchannel_pd_top` hardwires. |
| 1 | 1 | **Figure 2-7** — fully device-led entry and exit. |
| 1 | 0 | Device-led entry, controller-only exit — permitted by the spec's "any policy" clause. |
| 0 | 0 | `QACTIVE` ignored entirely; pure `req_dev_quiescence` policy. |

`req_dev_quiescence` always remains a valid entry/exit trigger on its own (the
spec's "at any time" clause); these two inputs only gate `QACTIVE`'s *additional*
participation on top of it.

> **Integration caveat when `enter=1`.** `req_dev_quiescence` must be a genuinely
> driven, dynamic policy signal, not tied to a constant. `QREQn` LOW→HIGH (R2) is
> legal only from `Q_STOPPED` or `Q_DENIED`, so tying `req_dev_quiescence` to
> constant 0 while relying on `QACTIVE` alone for entry makes
> `!req_dev_quiescence` trivially true forever; combined with `exit=1` the
> interface leaves `Q_STOPPED` the cycle after every entry and thrashes
> `Q_STOPPED ↔ Q_EXIT ↔ Q_RUN ↔ Q_REQUEST` instead of settling. This is not an
> FSM bug — Figure 2-8's default policy depends on `req_dev_quiescence` retaining
> an unconditional role. The supported usage pattern is `enter=1, exit=1` with
> `req_dev_quiescence` actively managed. Note this combination is **not currently
> covered by any testbench**: `qchannel_pd_top` hardwires `enter=0`, and the
> controller-only testbench that used to exercise it has been retired (§8.1).

### `qchannel_monitor` — [`qchannel_monitor.sv`](qchannel_monitor.sv)
Passive protocol checker. Oversamples `{QREQn, QACCEPTn, QDENY}` on `clk` and
raises `violations` (a running count) on any illegal transition. Bind one per
Q-Channel.

| Port | Dir | Description |
|---|---|---|
| `clk` | in | oversampling clock (faster than either domain) |
| `rst_n` | in | the monitor's **own always-on** reset — must *not* be gated by the domain resets it watches |
| `crst_n` | in | controller-domain reset, observed (edge-detected) for **R9** |
| `drst_n` | in | device-domain reset, observed for **R8** |
| `clk_gated` | in | resource-gate status, observed for **R10**; tie LOW on a channel that gates no resource |
| `qreqn`, `qacceptn`, `qdeny` | in | the raw interface wires |
| `violations` | out | running violation count |

The `rst_n` caveat is load-bearing: if the monitor's reset were gated by
`crst_n`/`drst_n`, the very domain-reset event R8/R9 exist to catch would also
wipe the monitor's sample pipeline in the same instant, and the violation would
go unseen.

### `clk_gate` — [`clk_gate.sv`](../common/clk_gate.sv)
The clock-gating actuator: a glitch-free latch-based integrated clock gate (ICG).
The enable is captured on the LOW phase of `clk`, so the gated clock never
truncates a high pulse. Same clock domain as the gated clock — no synchronizer
needed. In a real flow you would swap in the library ICG cell (e.g.
`prim_clock_gating`); this behavioural model matches its semantics.

| Port | Dir | Description |
|---|---|---|
| `clk` | in | free-running clock to be gated |
| `clk_en` | in | enable, active HIGH; 1 = pass, 0 = gate |
| `gated_clk` | out | gated clock to the load |

The internal `en_latch` is the gating status (`~en_latch` = "currently gated
off"). It is not exposed as a port because nothing in the design consumes it
functionally; the testbench reads it hierarchically.

### `qchannel_devrst_ctrl` — [`qchannel_devrst_ctrl.sv`](qchannel_devrst_ctrl.sv)
Device-reset controller, always-on domain. **Structural enforcement of §2.1.2
"Device reset"**: *"a controller must only assert a device reset when the
interface is in the Q_STOPPED state."* It refuses to drive the device's reset
until the **power-control** channel's controller confirms `dev_stopped` — not the
clock-control channel, per PCSA §8.2.1.

| Port | Dir | Description |
|---|---|---|
| `aon_clk`, `aon_rst_n` | in | always-on domain clock and async ACTIVE-LOW root reset |
| `dev_stopped` | in | `Q_STOPPED` status from the **power-control** controller (same domain, no resync) |
| `dev_rst_req` | in | PM policy: 1 = hold the device in reset, 0 = release |
| `dclk` | in | device clock, for synchronized release |
| `drst_n` | out | device reset, active LOW |

Three properties worth understanding:

* **Assertion is gated on protocol state; release is synchronized.** Asserting a
  reset is inherently glitch-free — every downstream flop just adopts its reset
  value regardless of which edge it lands on. The hazard the spec names is a
  *protocol* one (resetting mid-handshake desynchronizes the two FSMs), closed by
  the `Q_STOPPED` interlock. Releasing a reset is a genuine CDC hazard
  (recovery/removal timing), closed by the async-assert / sync-deassert
  synchronizer into `dclk`.
* **The interlock is a safety net, not the primary sequencing.** The PM policy is
  expected to have already quiesced the device before raising `dev_rst_req`; this
  block enforces the ordering structurally even if that is violated elsewhere.
  Deasserting `dev_rst_req` releases the hold unconditionally — bringing a device
  *out* of reset is never the hazard that asserting one mid-handshake is.
* **Power-up safety, and why the hold register is active LOW.** `rst_hold_n`
  resets to `0`, and `0` already means "device held in reset", so cold power-up
  is covered by the register's own reset value. A **single flop output** then
  drives the `dclk` synchronizer's asynchronous reset — no gate in that path.

  The alternative, an active-HIGH hold, forces the async reset to be driven by
  `(hold | ~aon_rst_n)` so that power-up is covered. That costs twice over, and
  both costs are real rather than theoretical:

  - It puts **combinational logic on an asynchronous reset pin**. Synthesis
    builds a gate there (a LUT2 on FPGA); a glitch on it asserts the device reset
    spuriously, and no amount of timing closure prevents it, because the path is
    asynchronous by construction. Vivado reports this as `LUTAR-1` *"LUT drives
    async reset alert"* and `report_cdc` as `CDC-10`.
  - It opens a **transient release window**. The OR goes false the instant
    `aon_rst_n` rises — before the hold register has been clocked — so for up to
    one `aon_clk` cycle the device reset is released while it is still being
    requested. Whether that reaches `drst_n` depends on the clock ratio.

  The cost of the active-LOW form is that release from `aon_rst_n` takes one
  `aon_clk` edge instead of being combinational. That is the right direction: a
  registered release in the always-on domain is what you want, and the immediacy
  it replaces was the hazard above. At cold power-up `qchannel_controller` resets
  straight into `Q_STOPPED`, so `dev_stopped` is immediately true and the
  interlock is trivially satisfied — the device still resets normally on boot.

### `dummy_workload` — [`dummy_workload.sv`](dummy_workload.sv)
The running block behind the device — a stand-in for real functional logic. On a
rising `start` it loads `work_len` and counts down one per (gated) clock, then
pulses `done`. Freezes cleanly when its clock is removed, and resumes from the
frozen count rather than restarting.

| Port | Dir | Description |
|---|---|---|
| `clk`, `rst_n` | in | gated clock; async-assert reset (independent of gating) |
| `start` | in | launches a work burst while idle |
| `work_len` | in | burst length in clocks (`CNT_W` wide) |
| `light_work` | in | 1 = count down **without** raising `busy` |
| `busy` | out | 1 = processing → **do not gate the clock** |
| `done` | out | 1-cycle pulse when a burst completes |
| `work_count` | out | remaining work units (observability) |

`light_work` models work that is interruptible: the countdown proceeds but `busy`
stays LOW, so the controller may gate the clock at any time. The burst simply
freezes and resumes on wake. Test **P5** proves it resumes rather than restarts.

### `qchannel_pd_top` — [`qchannel_pd_top.sv`](qchannel_pd_top.sv)
Top-level integration of the gate-able power domain — two Q-Channels, the ICG,
the reset controller and the workload (see §2.2).

| Parameter | Default | Meaning |
|---|---|---|
| `SYNC_STAGES` | `2` | synchronizer depth on both channels |
| `CNT_W` | `8` | workload counter width |

| Port | Dir | Domain | Description |
|---|---|---|---|
| `aon_clk`, `aon_rst_n` | in | always-on | clock and async ACTIVE-LOW root reset for both controllers and the reset controller |
| `pd_req` | in | always-on | clock-control channel: 1 = ask the domain to quiesce its clock |
| `pwr_req` | in | always-on | power-control channel: 1 = ask the domain to quiesce for power-down |
| `dev_rst_req` | in | always-on | 1 = hold the device in reset (takes effect only once the power channel is `Q_STOPPED`) |
| `dclk` | in | device | device / workload clock (the workload's copy is gated) |
| `start`, `work_len`, `light_work` | in | device | workload stimulus |
| `wake` | in | device | external wake → `QACTIVE` on both channels |
| `deny_enb` | in | device | 1 = deny quiescence while busy (`Q_DENIED` path), 0 = accept and let work freeze |

Both controllers are hardwired to the Figure 2-8 policy
(`enter=0, exit=1`). `deny_enb && busy` drives `dev_quiescent_deny` on both device
wrappers, and `wake | busy` drives `dev_wake`.

### Two more files in this folder (note of 2026-10-06)

This reference predates them; each file's header is its documentation.

| File | What it is | Used by |
|---|---|---|
| [`qchannel_device_comb.sv`](qchannel_device_comb.sv) | Q-Channel device FSM for a **clock-control** interface: registered QACCEPTn/QDENY, combinational QACTIVE (PCK-600 Table 3-7) | `ppu_top` (the PPU clock channel), `ppu_clk_ctrl` (its hierarchical channels) |
| [`qchannel_lpd.sv`](qchannel_lpd.sv) | LPD-Q, the Q-Channel low power distributor (PCK-600 §3.1): one upstream channel fanned out to N devices | `ppu_lpd_pd_top` |

`qchannel_device` is also the device agent inside every PPU domain
(`ppu_dom_top`), where a device adapter such as `../adp/hart_ready_adp` drives
its `dev_quiescent_busy` / `dev_quiescent_deny`.

---

## 4. The two FSMs in detail

Both are Moore machines implemented as a **single sequential `always_ff` block**:
state and the interface outputs move together on the same clock edge whenever a
transition changes an output's required value, so `QREQn`/`QACCEPTn`/`QDENY` are
always direct registered outputs — never combinational decode, per §2.1.2. Arms
that transition between two states sharing the same output value leave it
untouched (it already holds the correct level). Both use `qch_state_e` directly as
the state type.

### Device FSM (`qchannel_device`)

| State | `QACCEPTn`, `QDENY` | Next-state condition (on synchronized `QREQn`) |
|---|---|---|
| `Q_RUN` | 1, 0 | `QREQn` LOW → `Q_REQUEST` |
| `Q_REQUEST` | 1, 0 | `dev_quiescent_deny` → `Q_DENIED` (drive `QDENY` HIGH); else `!dev_quiescent_busy` → `Q_STOPPED` (drive `QACCEPTn` LOW); else stay |
| `Q_STOPPED` | 0, 0 | `QREQn` HIGH → `Q_EXIT` |
| `Q_EXIT` | 0, 0 | → `Q_RUN` (drive `QACCEPTn` HIGH) |
| `Q_DENIED` | 1, 1 | `QREQn` HIGH → `Q_CONTINUE` |
| `Q_CONTINUE` | 1, 1 | → `Q_RUN` (drive `QDENY` LOW) |

Reset → `Q_STOPPED` with `QACCEPTn`/`QDENY` LOW (satisfies the §2.1.2 device-reset
requirement). `dev_quiescent_busy` HIGH keeps the device operational in
`Q_REQUEST` until it goes idle — the literal meaning of "requested to become
quiescent when idle". `dev_quiescent_ok` is derived combinationally as
`state == Q_STOPPED` rather than hand-tracked per arm, which makes that invariant
impossible to get out of sync.

### Controller FSM (`qchannel_controller`)

| State | `QREQn` | Next-state condition (on synchronized device signals) |
|---|---|---|
| `Q_RUN` | 1 | `req_dev_quiescence \|\| (enb_..._enter && !QACTIVE)` → `Q_REQUEST` (drive `QREQn` LOW) |
| `Q_REQUEST` | 0 | `!QACCEPTn` → `Q_STOPPED`; else `QDENY` → `Q_DENIED` |
| `Q_STOPPED` | 0 | `!req_dev_quiescence \|\| (enb_..._exit && QACTIVE)` → `Q_EXIT` (drive `QREQn` HIGH) |
| `Q_EXIT` | 1 | `QACCEPTn` HIGH → `Q_RUN`; else wait |
| `Q_DENIED` | 0 | → `Q_CONTINUE` (drive `QREQn` HIGH) |
| `Q_CONTINUE` | 1 | `!QDENY` → `Q_RUN` |

Reset → `Q_STOPPED` with `QREQn` LOW; with `req_dev_quiescence` LOW the controller
then brings the device up (`Q_STOPPED → Q_EXIT → Q_RUN`). The `Q_STOPPED`
exit-on-`QACTIVE` term is the §2.1.3 policy that prevents a device that needs to
run from being stuck off — required to avoid deadlock when it is the only exit
trigger enabled. `dev_stopped` is likewise derived as `state == Q_STOPPED`.

---

## 5. Handshake rules and how they are enforced

The spec's six signalling rules (§2.1.2) govern *when* each wire may change. They
are enforced two ways: **structurally** (each FSM only changes its output from the
states where the rule permits) and **observationally** (the monitor flags any
violation on the wires).

| Rule | Constraint | Enforced by |
|---|---|---|
| R1 | `QREQn` 1→0 only from Q_RUN (`QACCEPTn` HIGH, `QDENY` LOW) | controller only drops `QREQn` in `Q_RUN` |
| R2 | `QREQn` 0→1 only from Q_STOPPED or Q_DENIED | controller only raises `QREQn` in `Q_STOPPED`/`Q_DENIED` |
| R3 | `QACCEPTn` 1→0 only from Q_REQUEST (`QREQn` LOW, `QDENY` LOW) | device only drops `QACCEPTn` entering `Q_STOPPED` |
| R4 | `QACCEPTn` 0→1 only from Q_EXIT (`QREQn` HIGH, `QDENY` LOW) | device only raises `QACCEPTn` leaving `Q_EXIT` |
| R5 | `QDENY` 1→0 only from Q_CONTINUE (`QREQn` HIGH, `QACCEPTn` HIGH) | device only drops `QDENY` leaving `Q_CONTINUE` |
| R6 | `QDENY` 0→1 only from Q_REQUEST (`QREQn` LOW, `QACCEPTn` HIGH) | device only raises `QDENY` entering `Q_DENIED` |
| R7 | `{x,0,1}` (`QACCEPTn` LOW & `QDENY` HIGH) never occurs | no FSM state produces it |

The monitor keeps a two-deep sample pipeline and, on each transition, checks the
companion-signal condition against the *from* state — the values held immediately
before the transition, which is what the rules describe.

### Beyond the wire rules: R8, R9, R10

The monitor adds three **precondition** checks that are about *when a resource may
be removed*, not about wire edges. All three fire on assertion only; release is
never checked, because leaving `Q_STOPPED` necessarily lags the wire-level state
by the device's own `QREQn` synchronizer, whereas entering it is zero-lag and
same-domain with `QACCEPTn` dropping.

| Rule | Constraint | Status |
|---|---|---|
| **R8** | device reset (`drst_n`) may only be asserted while the interface is in `Q_STOPPED` | literal §2.1.2 "Device reset" rule |
| **R9** | controller reset (`crst_n`) may only be asserted in `Q_STOPPED` | **not a literal spec rule** — symmetric best practice. The spec text only names device reset, but a controller reset asserted mid-handshake forces `QREQn` LOW without the device's agreement and desynchronizes the device FSM just the same |
| **R10** | the gated resource (`clk_gated`) may only actually be removed in `Q_STOPPED` | generalization of R8 from "device reset" to "any resource removal", for a same-domain gated resource |

R8 is checked on the falling edge of `drst_n` against the monitor's own
last-sampled wire state, not by re-reading the wires: the device's registers snap
LOW asynchronously the instant its reset asserts, so the pre-reset state has to
come from the monitor's pipeline.

`qchannel_devrst_ctrl` is the structural counterpart to R8 — the monitor observes
the rule, that block makes it impossible to break.

---

## 6. Waveforms

Interface-level view (synchronizer latency between an edge and the other side's
response is omitted for clarity — see §7).

**Accepted quiescence (Figure 2-2):**
```
 state    | Q_RUN | Q_REQUEST | Q_STOPPED | Q_EXIT | Q_RUN
 QREQn    ‾‾‾‾‾‾‾‾\___________________________/‾‾‾‾‾‾‾‾‾‾‾
 QACCEPTn ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\____________________/‾‾‾‾‾‾
 QDENY    ______________________________________________
          controller       device        controller  device
          drops QREQn      accepts       raises QREQn acks
```

**Denied quiescence (Figure 2-3):**
```
 state    | Q_RUN | Q_REQUEST | Q_DENIED | Q_CONTINUE | Q_RUN
 QREQn    ‾‾‾‾‾‾‾‾\_________________________/‾‾‾‾‾‾‾‾‾‾‾‾‾
 QACCEPTn ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾  (stays HIGH)
 QDENY    ____________________/‾‾‾‾‾‾‾‾‾‾‾‾‾\______________
          controller        device        controller  device
          drops QREQn       denies        raises QREQn drops QDENY
```

**Busy-then-idle (P2/P3):** `QREQn` falls, the device denies (or holds in
`Q_REQUEST`, depending on `deny_enb`) until `dev_quiescent_busy` clears, then
accepts and the clock gates off.

**QACTIVE-led wake (P4, C3):** while in `Q_STOPPED` with the request still HIGH,
the device raises `QACTIVE`; the controller responds by raising `QREQn`
(`Q_EXIT`) and the device returns to `Q_RUN`.

---

## 7. Clock-domain crossing and latency

Per §2.1.1 all Q-Channel signals are asynchronous. This design makes the interface
CDC-safe structurally:

* **Registered outputs** on both sides → the far domain samples clean levels only.
* **2-FF synchronizers** on every crossing resolve metastability.
* **Why 2-FF per bit is sufficient (not just plausible):** the Q-Channel is a fully
  interlocked four-phase handshake — only one wire changes per step and each side
  waits for the other's acknowledge before proceeding. There is no multi-bit
  coherency hazard, so no gray-coding or handshake FIFO is needed. Synchronizer
  latency only *slows* the handshake; it cannot break it.
* **`SYNC_STAGES = 0`** collapses `cdc_sync` to a wire, for the case where
  controller and device genuinely share a clock. Do not use it across real
  asynchronous domains.

**Latency.** Each interface edge is observed by the far side after `SYNC_STAGES`
(=2) destination-clock cycles plus the FSM's own cycle to react. An accepted
handshake is four such edges (drop `QREQn` → accept → raise `QREQn` → ack), so a
full `Q_RUN → … → Q_RUN` round trip is roughly 8–12 destination-clock cycles.
Concretely, in the power-domain testbench (AON 4.3 ns, device 13.7 ns), the
idle-path quiesce in **P6** takes ~55 ns from `pd_req` rising to `Q_STOPPED`, and
the reset controller adds no latency of its own on the assert path. Increasing
`SYNC_STAGES` adds proportional latency for deeper metastability margin.

---

## 8. Verification

**One** self-checking testbench,
[`../../tb/qchannel/qchannel_pd_tb.sv`](../../tb/qchannel/qchannel_pd_tb.sv). It
drives the fully integrated `qchannel_pd_top` — both controllers, both device
wrappers, the clock gate, the reset controller and the workload — so it covers
the controller and device FSMs in the arrangement they actually ship in. Earlier
standalone controller, functional and negative testbenches were retired rather
than maintained alongside it; §8.1 records what that costs.

A per-phase breakdown of which control-signal combination each test drives —
and in particular how `deny_enb` and `light_work` interact with the workload's
`busy` to select between denial, waiting and immediate gating — is in
[`../../tb/qchannel/TEST_MATRIX.md`](../../tb/qchannel/TEST_MATRIX.md).

### Reading the test phase in the waveform

The testbench drives a `test_phase` signal carrying the name of the test
currently running, so a waveform can be read against the test list below without
cross-referencing timestamps in the log.

VCD has no string type, so the name lives in a packed byte vector (`reg
[8*56-1:0]`) written via `$sformat`. To see it as text in GTKWave, add
`test_phase` to the trace list, then right-click it and choose **Data Format →
ASCII**. Without that it renders as a very wide hex number. A SystemVerilog
`string` would not work here — it is not dumped to VCD at all, and Icarus will
not even cast one into a packed vector.

### Stimulus timing convention

Every DUT input is driven on the **negedge** of the clock that samples it, so the
sampling posedge lands in the middle of the data eye. Driving on the posedge puts
the input transition and the sampling edge at the same simulation time, which
leaves the result dependent on event ordering inside the simulator, makes
waveforms impossible to read cause-from-effect, and masks exactly the setup/hold
problems a testbench exists to expose. The single exception is the gated-clock
edge counter, which must stay on the posedge because counting clock edges is its
entire purpose.

### Power-domain testbench — [`../../tb/qchannel/qchannel_pd_tb.sv`](../../tb/qchannel/qchannel_pd_tb.sv)

Drives `qchannel_pd_top` and proves the workload's clock is *physically* gated by
the handshake. An edge counter on the gated clock is the key evidence: it must
advance while running and stay frozen while gated. Clocks are AON 4.3 ns, device
13.7 ns, monitor 1 ns. **Two** monitors are bound — one per channel; the power
channel ties `clk_gated` LOW since its equivalent resource removal is the device
reset already covered by R8.

| Test | Scenario |
|---|---|
| **P0** | Reset & bring-up: AON released first, then power request and device-reset request withdrawn together; reaches `Q_RUN`, workload clock toggling |
| **P1** | Start a burst; `busy` HIGH, `work_count` decrements, then drain |
| **P2** | Idle-path: quiesce while already idle → immediate gate off, zero edges, exit by **withdrawing `pd_req`** |
| **P3** | Sustained gating: hold `Q_STOPPED` for 20 device cycles, 0 edges, no state drift, then exit via **`QACTIVE` with `pd_req` still asserted** and confirm the clock resumes |
| **P4** | Full `Q_DENIED → Q_CONTINUE` recovery: denied mid-burst with the **clock still running**, then auto-recovers to `Q_STOPPED` once work drains |
| **P5** | `light_work` freezes mid-countdown when gated (`work_count` captured and re-checked after 10 gated cycles) and **resumes rather than restarts**, reaching 0 after wake |
| **P6** | `deny_enb=0`: device does not deny, but holds in `Q_REQUEST` until the burst drains, then accepts and gates |
| **P7** | Power shutoff and restore — the only phase that drives the **power-control** channel. `dev_rst_req` asserted mid-burst is refused by the interlock; the supply/reset drops only once *both* channels reach `Q_STOPPED`; the device outputs hold the `Q_STOPPED` encoding while down; **`wake` held high for 10 device cycles cannot revive the domain** (contrast P3/P5, where it revives a merely clock-gated one); a fresh burst runs from reset after restore. Exercises the UPF power intent in [`../../upf/`](../../upf/) |

Result: **79 checks, 0 testbench errors, 0 violations on either channel — PASS.**

A per-phase breakdown of the driving signal values, and of the four phases that
were removed as redundant, is in
[`../../tb/qchannel/TEST_MATRIX.md`](../../tb/qchannel/TEST_MATRIX.md).

The chain proven end-to-end: `pd_req → QREQn → device (waits for busy to clear) →
dev_quiescent_ok → clock_ctrl → workload clock removed`, with both protocol
monitors clean throughout.

### Sample output (trimmed)
```
[131000]  ok  P0.bringup: reached Q_RUN
[499000]  ok  P2: idle domain gated off on request
[982000]  ok  P3: clock edges during 20-cycle hold = 0
[982000]  ok  P3: stayed in Q_STOPPED (no drift)
[1490000] ok  P4.denied: reached Q_DENIED
[1490000] ok  P4: clock still ON (device refused gating)
[2081000] ok  P5: work_count stayed frozen
[3672000] ok  P7: power-down refused by the interlock before Q_STOPPED
[4010000] ok  P7: supply/reset removed once the power channel reached Q_STOPPED
[4060000] ok  P7: clock-channel device outputs at the Q_STOPPED clamp while powered down
[4343000] ok  P7: wake cannot raise QACTIVE from a powered-down domain
[4343000] ok  P7: wake does not revive the domain -- still held down
[4729000] ok  MONITOR: zero clock-control protocol-rule violations
[4729000] ok  MONITOR: zero power-control protocol-rule violations
==================== PD SUMMARY ====================
 checks run        : 79
 testbench errors  : 0
 monitor violations (clock): 0
 monitor violations (power): 0
 RESULT: PASS
===================================================
```

### 8.1 Known gap — no negative test for this monitor

`qchannel_monitor` has **no negative test**. Nothing currently proves it is
capable of firing, so its zero-violation result is weaker evidence than it looks:
a checker that never fires reports zero on everything.

This is the highest-value verification gap in the Q-Channel work. The
[P-Channel monitor negative test](../pchannel/README.md#9-verification) is a
direct template — it drives illegal transitions on the wires with no DUT,
confirms every rule fires, and confirms the monitor stays silent on legal traffic
before and after. Porting that pattern here should cover R1–R7 plus the R8/R9/R10
reset and clock-gate preconditions.

---

## 9. Running

From [`../../Makefile`](../../Makefile) (run with `make -C src`, or from `src/`):

```sh
make pd       # power-domain TB  (writes build/qchannel_pd_tb.vcd)
make lint     # compile-only elaboration check
make wave-pd  # open the power-domain waveform (needs gtkwave)
make all      # every testbench in the repo, Q-Channel and P-Channel
make clean
```

Requires Icarus Verilog (`iverilog`/`vvp`). Override the tools with e.g.
`make IVERILOG=... VVP=...`. Build artifacts land in `build/` (git-ignored).

Targets that need a vendor tool, each guarded so it says what is missing rather
than failing obscurely:

```sh
make pa         # same TB with the src/upf power intent applied (needs xrun)
```

The Vivado targets (`xsim-pd`, `xsim-diff`, `synth`, `impl`) were removed on
2026-10-06 with `src/constraints`; see step 8 of §10.

---

## 10. Integration guide

To make a real peripheral Q-Channel compliant:

1. **Instantiate `qchannel_device`** in the peripheral's clock domain. Connect
   `qreqn`/`qacceptn`/`qdeny`/`qactive` to the interface pins.
2. **Drive the device-internal inputs from the peripheral:**
   * `dev_quiescent_busy` — HIGH while the peripheral has outstanding work (bus
     transaction in flight, FIFO non-empty, …). Keeps it operational in
     `Q_REQUEST` until safe.
   * `dev_quiescent_deny` — HIGH to refuse a request outright (e.g. a mode where
     it must not be quiesced). Tie LOW if denial is never needed — that gives you
     the §2.1.4 no-denial subset.
   * `dev_wake` — pulse/level from any wake source (interrupt pending, external
     event) to raise `QACTIVE`.
3. **Actuate on `dev_quiescent_ok`** (or the controller's `dev_stopped`): it is
   safe to remove the functional clock/power only when the interface is in
   `Q_STOPPED`. Remember the polarity — it is "1 = safe to remove", so an
   active-HIGH clock enable is its inverse. Keep the FSM's own clock always-on
   (it must run to handshake the exit).
4. **Use separate channels for clock and power** (PCSA §8.2.1). Do not reuse a
   clock channel's `Q_STOPPED` as permission to reset or power down — negotiate
   that on its own channel, as `qchannel_pd_top` does.
5. **Gate device reset with `qchannel_devrst_ctrl`**, fed from the *power*
   channel's `dev_stopped`. This is what makes §2.1.2's "only assert device reset
   in Q_STOPPED" structurally true rather than a convention the integrator has to
   remember.
6. **On the controller side**, drive `req_dev_quiescence` from your
   power-management policy (idle timer, OS/SCMI request, thermal governor), and
   pick the `QACTIVE` policy with `enb_qactive_led_quiescence_enter`/`_exit`.
   Figure 2-8 (`0, 1`) is the safe default. If you set `enter=1`, read the
   integration caveat in §3.
7. **Place the controllers in an always-on domain** relative to the domain they
   control (PCSA §7.2.3) — they must stay alive to sequence the exit.
8. **Timing constraints (production).** *Removed 2026-10-06:* `src/constraints`
   and the Vivado targets were deleted; the files are in the git history. This
   step is kept as the record of what they did. `src/constraints/` was a
   Vivado flow, read in this order:

   | File | Role |
   |---|---|
   | `qchannel_pd_top.xdc` | Top level — clocks (AON 200 MHz, device 300 MHz), port timing, reset |
   | `qchannel_lpi.xdc` | Module CDC exceptions, hierarchy-agnostic |
   | `qchannel_lpi_check.tcl` | Coverage check, run after implementation |
   | `qchannel_pd_top_synth_keep.xdc` | `DONT_TOUCH` harness — **standalone synthesis only**, see below |
   | `synth_check.tcl` | Drives the whole flow; invoked by `make synth` |

   Order matters: the top-level file defines the clocks whose periods the module
   file's budgets are matched to. The module file is hierarchy-agnostic — it
   reaches every `cdc_sync` and `qchannel_devrst_ctrl` instance wherever it
   sits, via `get_cells -hier -regexp`.

   **Both XDC files are pure XDC** — only constraint commands, no `if` / `proc` /
   `foreach` / `expr`. Tcl control flow in an XDC does not survive `write_xdc`,
   is rejected inside IP and `SCOPED_TO_REF` files, and defeats static constraint
   linting. Nothing is lost by dropping the loops, because XDC commands take
   collections. What *is* lost is the self-check, which needs conditionals —
   hence the separate `qchannel_lpi_check.tcl`, which verifies the constraints
   actually applied, that the reset release path was *not* excepted, and that the
   hard-coded budgets still match the clock periods. Pair it with
   `report_cdc -details`, which catches the different failure of a *missing*
   synchronizer.

   `clk_gate` is deliberately left unconstrained: Vivado has no
   `set_clock_gating_check`, and on FPGA a latch-and-LUT clock gate should be
   replaced with `BUFGCE` or a plain clock enable rather than constrained around.

   > **`qchannel_pd_top` has no output ports**, so a standalone synthesis run
   > optimizes the entire design away — measured: **0 cells**, with no error and
   > no warning. `qchannel_pd_top_synth_keep.xdc` pins the sub-instances with
   > `DONT_TOUCH` so the netlist survives (141 primitives) for constraint
   > validation. It is a harness for that experiment, **not** part of a real
   > build; a real integration consumes the block's status and needs none of it.

   Verified on **Vivado 2025.2, xczu9eg-ffvb1156-2-e (ZCU102)**, OOC synthesis
   through place and route: `report_cdc` gives **CDC-3 ×8** and **CDC-9 ×1** with
   no Critical findings, setup passes (WNS +0.600 ns), and every cross-domain
   path is covered by `Max Delay Datapath Only`. (It was reproduced with `make synth`,
   removed 2026-10-06.)
   Two known items remain, both from the behavioural clock gate rather than the
   constraints: `TIMING-14` (LUT on the clock tree) and the hold violations it
   causes on port paths into the gated domain.

   > **Do not add `set_clock_groups -asynchronous` between the two clocks.**
   > `set_clock_groups` is a false path, and false paths outrank `set_max_delay`
   > in SDC precedence — so it silently overrides every `-datapath_only` budget
   > on the synchronizer inputs, leaving the crossings unbounded while the
   > constraints still appear to be applied. The top-level file explains the
   > trade-off and leaves the clocks ungrouped on purpose.

   `qchannel_controller` and `qchannel_device` need **no** constraints of their
   own: every crossing they participate in is already excepted at the
   `cdc_sync` instance on the receiving end.

   Not covered by that file, because it cannot be written generically: chip
   boundary `set_input_delay`/`set_output_delay` if the channel leaves the die.
   Also swap the behavioural ICG in `clk_gate` for a library cell —
   that removes the need for the clock-gating-check section entirely.

9. **Power intent (production):** [`../../upf/`](../../upf/) — IEEE 1801 UPF for
   the *power*-control channel only. Timing constraints cannot express which
   supply a block runs on, when it is removed, or what its outputs read while it
   is gone; that is UPF's job, and here every value in it is derived from the
   protocol rather than chosen:

   | File | Role |
   |---|---|
   | [`qchannel_pd_top.upf`](../../upf/qchannel_pd_top.upf) | The power intent — domains, switch, power states, isolation. Scope-relative, so it serves synthesis, P&R and simulation unchanged |
   | [`qchannel_pd_tb.upf`](../../upf/qchannel_pd_tb.upf) | Power-aware simulation wrapper — energises the rails, binds the above to the DUT |

   `PD_AON` holds both controllers, `qchannel_devrst_ctrl`, **and both device
   wrappers** (PCSA §7.2.3); `PD_DEV` holds only the clock gate and the
   workload. The switch is controlled by `qchannel_devrst_ctrl`'s `rst_hold_n`,
   which makes §2.1.2 — remove power only in `Q_STOPPED` — a register rather
   than a convention.

   **The interface is deliberately not in the switched domain.** A Q-Channel
   wrapper is a protocol agent, not payload: powering it off and clamping its
   outputs does not preserve the protocol, it replaces a live participant with
   six constants that imitate one — and that imitation is only safe while every
   clamp value happens to equal the RTL's reset value. Keeping the wrappers
   powered means the `Q_STOPPED` encoding of Table 2-1 is *held* by real flops
   rather than duplicated in a constraint file. It also cuts isolation from six
   signals to one (the workload's `busy`, clamped to 0), for the leakage of two
   small FSMs. ARM's own model assumes this — the PPU negotiates a component
   back up over a live LPI, so the interface cannot be what goes down.

   **No retention**, deliberately: PCSA §8.3.4 makes the reset state equal the
   quiescent state, so there is nothing to save. That is also the line between
   the two channels — P5 proves *clock* gating freezes and resumes a burst, P7
   proves *power* gating loses it and re-initialises from reset.

   > **Open item — the wrappers are powered but still reset by `drst_n`.** The
   > partition puts them in `PD_AON`, but [`qchannel_pd_top.sv`](qchannel_pd_top.sv)
   > still wires their `rst_n` to `drst_n`, so they go down with the workload
   > anyway and `QACTIVE` stays low. P7 measures the consequence: `wake` held
   > high for ten device cycles while the domain is down revives nothing.
   >
   > Giving them `aon_rst_n` resynchronised into `dclk` instead would make the
   > interface genuinely live and restore LPI §2.1.3's anti-deadlock mechanism.
   > The cost is a sequencing obligation, not area: once `QACTIVE` can rise from
   > an unpowered domain, the interface can leave `Q_STOPPED` before the supply
   > is back, which §2.1.2 forbids. The always-on policy would then have to treat
   > `QACTIVE` as a wake *request* and restore power before letting the handshake
   > complete — the PPU sequencer. The two changes belong together.
   >
   > **Integration hazard meanwhile:** an always-on PM policy on top of this
   > needs its own wake input; wiring the power domain's exit to `QACTIVE` alone
   > (which `enb_qactive_led_quiescence_exit=1'b1` invites, being correct for
   > *clock* gating) yields a domain that can never be revived.

   The clock-control channel gets no UPF at all. A clock gate is not a power
   domain, and modelling it as one would destroy the property P5 exists to show.

   > **Not executed.** UPF power-aware simulation needs Xcelium, VCS or Questa;
   > neither Icarus nor Vivado xsim reads UPF, so this intent has been written
   > against IEEE 1801 and verified against the design, but not run. `make pa`
   > invokes it if `xrun` is available. Testbench P7 checks the interlock and
   > the clamp values under plain simulation in the meantime — they hold there
   > for a different mechanism but the same reason.

For a device with **multiple** power states (not just one quiescent state), use the
**P-Channel** instead — see [`../pchannel/`](../pchannel/).

---

## 11. Scope and limitations

* **No negative test.** The monitor's zero-violation result is only as strong as
  the proof that it *can* fire, and nothing currently provides that proof (§8.1).
  Treat monitor-clean results accordingly until one is written.
* **Single testbench.** Everything is verified through the integrated
  `qchannel_pd_top`. That is the configuration that ships, but it means a
  controller-only policy corner unreachable from the integration — an
  `enb_qactive_led_quiescence_enter=1` policy, say, which `qchannel_pd_top`
  hardwires off — has no coverage.
* **Metastability in simulation.** A 4-state event simulator (Icarus) does not inject
  real metastability; it validates *functional* correctness across the unrelated
  clocks. Proving metastability *tolerance* is the job of the synchronizer
  structure (present here) plus CDC-aware tooling / formal in a production flow.
* **Status-flag latency.** `dev_stopped` lags the wire-level state, inherent to a
  synchronous controller that must synchronize and sample `QACCEPTn` before it
  knows the state changed; the testbenches poll for it rather than assuming a
  fixed latency. The same asymmetry is why R8/R9/R10 check assertion only.
* **No assertions library.** The monitor is written as a portable procedural checker
  (runs under plain Icarus) rather than SVA `property` blocks; a production
  environment would typically add bound SVA and formal coverage.
  *2026-10-06:* the controller and device FSMs now have bound SVA,
  `src/formal/qchannel/` (LPI §2.1.2 rules R1-R7 on the pins, plus liveness),
  fully proven by `make vcformal` (`src/signoff/SIGNOFF_REPORT.md` §6). The
  monitor itself still has no negative test.
* **Behavioural ICG.** `clk_gate` models the latch-based integrated
  clock gate rather than instantiating a library cell.
* **Power sequencing collapsed.** [`../../upf/`](../../upf/) now runs under
  Xcelium — `make pa` elaborates the intent and passes — so the clamp values and
  the interlock are confirmed by the UPF rather than only by P7 under plain
  simulation. What remains is structural: isolation-enable and switch-off share
  one control signal, because the RTL has no PPU sequencer to stagger them. The
  PPU domain closes exactly that gap; see [`upf/README.md`](../../upf/README.md).
* **P-Channel (multi-state negotiation, §2.2)** is implemented separately in
  [`../pchannel/`](../pchannel/); it has no power intent of its own yet.

---

## 12. References

* **AMBA Low Power Interface Specification, ARM IHI 0068C** — the source spec;
  local copy at
  [`../../../references/standards/arm-amba-low-power-interface-spec.pdf`](../../../references/standards/arm-amba-low-power-interface-spec.pdf).
  Section 2.1 (Q-Channel), Table 2-1 (states), §2.1.2 (handshake rules & device
  reset), §2.1.3 (controller policy & QACTIVE), §2.1.4 (signal subsets).
* **Power Control System Architecture (PCSA), ARM DEN0050** — local copy at
  [`../../../references/standards/arm-power-control-system-architecture-pcsa-den0050.pdf`](../../../references/standards/arm-power-control-system-architecture-pcsa-den0050.pdf).
  §7.2.3 (always-on placement of the power controller), §8.2.1 (separate clock and
  power Q-Channels), §8.3.4 (reset state equivalent to quiescent state; wake
  signalling from outside the domain).
* [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md) — the SoC power architecture these channels serve (§5: which protocol on which interface).
* Note 11 (Arm IP and SoC power architecture) and note 16 (open-source RTL implementations): research notes removed 2026-10-06.


## Mutation campaign — the Q-Channel suite (wave five)

The PPU suites had four waves; `qchannel_pd_tb` had none. Twelve mutations, each
a deliberate violation of an AMBA LPI Section 2.1.2 rule or of the power-domain
plumbing around it. **Every kill was scored by `pd` itself**, run first, so the
Q-Channel suite is self-sufficient rather than leaning on the PPU suites that
reuse the same RTL.

| | Rule broken | Killed by |
|---|---|---|
| Q1 | `Q_REQUEST`: deny leads to `Q_DENIED` | `pd` |
| Q2 | exit raises `QREQn` | `pd` |
| Q3 | `Q_EXIT` waits for `QACCEPTn` HIGH | `pd` (**P8, new**) |
| Q4 | denial withdraws via `Q_CONTINUE` | `pd` |
| Q5 | `Q_CONTINUE` waits for `QDENY` LOW | `pd` |
| Q6 | `QREQn` drops only on request | `pd` |
| Q7 | device reset asserted only in `Q_STOPPED` | `pd` |
| Q8 | device reset release is unconditional | *equivalent — see below* |
| Q9 | clock gate latches on the LOW phase | `pd` |
| Q10 | the clock gate actually gates | `pd` |
| Q11 | synchronizer is `STAGES` deep | *not observable in simulation* |
| Q12 | `dev_stopped` means exactly `Q_STOPPED` | `pd` |

### Q3 — the one real gap, and a test that had to be fixed twice

A controller that returns to `Q_RUN` without waiting for the device to
acknowledge an exit moves no pin: `QREQn` is already HIGH in `Q_EXIT`. It only
becomes visible if a **new request arrives inside the device's acknowledge
latency**, and every earlier phase lets an exit finish before asking for anything
else.

P8 creates that window — and its first two versions did not.

- The first waited on `cur_state()`, which decodes the **clock** channel, while
  driving `pwr_req` on the **power** channel. It waited on something it never
  touched.
- The second withdrew and re-asserted one `aon_clk` apart. That pulse never
  reached `Q_EXIT` at all, so the wait under test was never entered and the
  phase passed against the mutant.

It now waits for `Q_EXIT` explicitly, asserts that the device has *not* yet
acknowledged, and only then re-requests. Applying Q3 raises exactly the predicted
violation: `R1: QREQn fell outside Q_RUN (from {QREQn=1 QACCEPTn=0 QDENY=0})`.

### Q8 and Q11 — equivalent, for two different reasons

**Q8** gates the device-reset *release* on `dev_stopped`. `drst_n` drives the
`rst_n` of both device ends, so while the reset is held neither can complete a
handshake and the interface cannot leave `Q_STOPPED`. The release therefore
always happens *in* `Q_STOPPED`, where the added condition is already true.
Equivalent by topology.

**Q11** shortens the synchronizer. Functional simulation does not model
metastability, so depth only shifts arrival by a cycle — the property is
structural, and its checker is `qchannel_lpi_check.tcl`'s `ASYNC_REG` count
against the synthesized netlist. Not a testbench gap; coverage that lives in a
different tool, and one that has never been run here.
