`timescale 1ns/1ps
// Integrated clock gate: enable in, glitch-free gated clock out.
//
// Nothing in this module knows what a Q-Channel is. It was called
// qchannel_clock_ctrl and lived in rtl/qchannel because that is where it was
// first needed -- to turn a Q-Channel handshake into the physical removal of a
// clock -- but the block itself is the standard latch-based ICG and has three
// ports and no protocol. It is now used by four different things:
//
//   qchannel_pd_top   gates a workload's clock off the Q-Channel handshake
//   ppu_pd_top        gates the device domain's clock off DEVCLKEN
//   ppu_clkq_top      gates a PPU's own clock off ppu_clk_ctrl's clken_o
//   ppu_axi_pd_top    the same, in the AXI4-Lite integration
//
// The enable must be in the SAME clock domain as the clock being gated. There
// is no synchronizer here and there must not be one: a gated clock's enable
// arriving from another domain is a glitch waiting to happen, and the caller is
// the only one who can know whether a crossing exists. ppu_pd_top's u_clken_sync
// is an example of a caller doing that resynchronization itself.
//
// Implementation is the classic latch-based ICG: the enable is captured on the
// LOW phase of the clock so it can never change while the clock is HIGH, which
// is what makes the gated clock glitch-free. In a real flow this is the library
// ICG cell (e.g. prim_clock_gating); this behavioural model matches its
// semantics for simulation.
//
// en_latch KEEPS ITS NAME. Several testbenches read it hierarchically to answer
// "is the clock actually gated right now" -- compared against 1 rather than
// inverted, because an X inverts to X and x->1 is a posedge in Verilog. See
// ppu_pd_tb and qchannel_monitor's R10.

module clk_gate (
  input  logic clk,        // free-running clock to be gated
  input  logic clk_en,     // enable, active HIGH (drive from device dev_clk_en)
  output logic gated_clk   // gated clock to the load
);

  // en_latch's inverse is the "currently gated OFF" status; no separate port
  // for it since nothing in this design consumes that status functionally --
  // a testbench that needs it reads en_latch hierarchically.
  logic en_latch;

  // Level-sensitive latch: transparent while clk is LOW, holds while HIGH.
  always @(*) begin
    if (!clk) en_latch = clk_en;
  end

  assign gated_clk = clk & en_latch;

endmodule
