# `rtl/common` — infrastructure with no protocol in it

Three modules that every other directory needs and none of them owns. The test
for belonging here is narrow and worth stating, because "shared" and "generic"
are not the same thing:

> **Nothing in the module refers to a Q-Channel, a P-Channel, a PPU or a power
> mode — not in its ports, not in its logic, and not in the reason it behaves
> the way it does.**

| Module | Was | Ports |
|---|---|---|
| [`clk_gate`](clk_gate.sv) | `qchannel_clock_ctrl` | `clk`, `clk_en`, `gated_clk` |
| [`cdc_sync`](cdc_sync.sv) | `qchannel_sync` **and** `pchannel_sync` | `clk`, `rst_n`, `d`, `q` |
| [`rst_sync`](rst_sync.sv) | `ppu_rst_sync`, plus a copy inlined in `qchannel_devrst_ctrl` | `clk`, `rst_in_n`, `rst_out_n` |

Each was named after the first thing that needed it, not after what it is.
`clk_gate` is a latch-based ICG with three ports; it now gates four different
clocks in three different designs, only one of which is a Q-Channel. `rst_sync`
is two flops.

## `cdc_sync` was two modules

`qchannel_sync` (1 bit) and `pchannel_sync` (`WIDTH` bits) were the same design
written twice. The P-Channel one was the more general, so it is the one that
survived. Every call site passes `clk`/`rst_n`/`d`/`q` and the 1-bit sites take
`WIDTH`'s default, so merging them was a module-name substitution and nothing
else.

`STAGES = 0` is a supported configuration, not a degenerate one: it collapses to
a combinational passthrough for callers whose source is provably in the same
clock domain. `ppu_clk_ctrl`'s `CLK_Q_CH_SYNC` uses it to honour PCK-600 Table
3-7's *"Synchronizers are not present"*.

### One change that is not cosmetic

`sync_q` is now a **packed** array. `pchannel_sync` declared it unpacked, which
synthesizes to `sync_q_reg[stage][bit]`.

That matters because `constraints/ppu_lpi.xdc` and `qchannel_lpi.xdc` find these
flops by name and use the *shape* of `sync_q` to tell a CDC synchronizer apart
from a reset synchronizer:

```tcl
set_property ASYNC_REG TRUE [get_cells -quiet -hier -regexp {.*sync_q_reg\[[0-9]+\]$}]
```

That regexp is anchored after **one** index, so on the unpacked shape it most
likely matched no `pchannel_sync` register at all — meaning the P-Channel
synchronizers in the PPU were probably never getting `ASYNC_REG` or their false
paths. Packing puts every element on a single flattened index, so the existing
regexps match at `WIDTH = 1` exactly as they did for `qchannel_sync`, and now
match the P-Channel instances too.

**That is unverified.** Vivado is not installed here and neither XDC has ever
been executed, so "most likely" is as strong as this claim gets. It is recorded
because the alternative — merging the modules and silently changing what the
constraints match — is worse.

> **2026-10-06:** `src/constraints` (`ppu_lpi.xdc`, `qchannel_lpi.xdc` and the
> synthesis scripts) was removed with the Vivado flow; the files are in the git
> history. The packed shape is kept. This section and the next are the record
> of why.

## `rst_sync` is deliberately not parameterized

A `STAGES` parameter is the obvious generalization and it is the one thing this
module must not have. The same XDC files discriminate by shape in the other
direction: `meta_q`/`sync_q` are **scalars** here and a vector in `cdc_sync`, and
the two need opposite treatment — both want `ASYNC_REG`, but a CDC chain's first
flop is false-pathed while a reset synchronizer's release path stays timed.
`ppu_lpi.xdc` says so and warns that a depth parameter here would force it onto
hierarchy matching instead.

Two flops is also simply the right number for a reset.

## What did *not* move, and why

| Module | Why it stayed |
|---|---|
| `qchannel_devrst_ctrl` | It carries LPI §2.1.2 policy — a device reset may only be asserted in `Q_STOPPED` — which is the opposite of protocol-free. Its inlined release retimer is now a `rst_sync` instance. |
| `qchannel_device_comb`, `ppu_clk_ctrl` | Genuinely reusable, but they are **LPI protocol blocks**, not infrastructure. They belong in a Q-Channel or clock-control directory rather than here, and arguably not under `ppu/` either — a separate question from this one. |
| `ppu_ip_sram` | A device-IP bank model with technology-specific `sleep`/`shutdown` pins. |
| `dummy_workload`, `pchannel_workload` | Stimulus loads for one design each. |

## Consuming it

`Makefile` exports `$(COMMON)`, and both synthesis scripts take it as
`PPU_RTL_C` / `QCH_RTL_C`. `lint/ppu_srclist_check.py` asserts that **every**
file in this directory appears in both the simulation and synthesis lists — it
had to be taught about `$(COMMON)`, and until it was it silently stopped seeing
three files on both sides at once while still reporting PASS.

> **2026-10-06:** the paragraph above is history. `src/lint`, and with it
> `ppu_srclist_check.py` and its `ppusrc` target, was removed on 2026-10-05,
> and the synthesis scripts with `src/constraints` on 2026-10-06, so that
> cross-check of the simulation and synthesis lists no longer runs. Lint is
> `make vclint` (VC SpyGlass Lint, `src/signoff/lint/`), which reads the
> Makefile's own source lists. These modules are also used by the phase-5
> blocks: `cdc_sync` by `ckrst_bridge` and `ppu_dom_top`'s DEVCLKEN
> resynchroniser.
