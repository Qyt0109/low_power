`timescale 1ns/1ps
// Multi-flop CDC synchronizer for level signals.
//
// This is one module that used to be two. qchannel_sync (1 bit) and
// pchannel_sync (WIDTH bits) were the same design written twice, neither of
// them containing anything about a Q-Channel or a P-Channel: a chain of flops,
// a reset value and a depth. The P-Channel one was the more general, so it is
// the one that survived, under a name that says what it is.
//
// WHY A PER-BIT SYNCHRONIZER IS SUFFICIENT HERE
//
// AMBA LPI (ARM IHI 0068C) Section 2.1.1 states that the controller and device
// domains are asynchronous, and both protocols are fully interlocked four-phase
// handshakes: only one wire changes per step and each side waits for the
// other's acknowledge. So a per-bit multi-flop synchronizer is both necessary
// and sufficient -- no gray coding and no handshake FIFO.
//
// That reasoning is about the CALLERS, not about this module. Used on a bus
// whose bits can change together, a per-bit chain admits a transient mix of old
// and new values, and it is the caller's job to know that is acceptable. See
// ppu_clk_ctrl's entry_delay_i, which argues the case explicitly.
//
// STAGES = 0 is a special case for when the source and destination are actually
// the SAME clock domain -- a controller and device integrated close enough to
// share a clock, or a configuration parameter declaring the input synchronous.
// It degenerates to a pure combinational passthrough: no registers, no
// clock-to-q latency added to the handshake at all. ppu_clk_ctrl's
// CLK_Q_CH_SYNC uses it for exactly that.
//
// THE ARRAY IS PACKED, AND THAT IS A CONSTRAINT DECISION
//
// constraints/ppu_lpi.xdc and qchannel_lpi.xdc find these flops by name --
// {.*sync_q_reg\[[0-9]+\]$} -- and use the SHAPE of sync_q to tell a CDC
// synchronizer apart from a reset synchronizer, whose sync_q is a scalar.
//
// pchannel_sync declared sync_q as an UNPACKED array, which synthesizes to
// sync_q_reg[stage][bit] and does not match a regexp anchored after one index.
// Packing it keeps every element on a single flattened index, so the existing
// regexps match at WIDTH = 1 exactly as they did for qchannel_sync, and now
// match the P-Channel instances too -- which, on the old shape, they most
// likely never did. That is unverified: Vivado is not installed here and
// neither XDC has ever been executed. See rtl/common/README.md.
//
// 2026-10-06: src/constraints and the Vivado flow were removed, so those XDC
// files no longer exist (they are in the git history). The packed shape is
// kept, and the paragraphs above are the record of why.

module cdc_sync #(
  parameter int unsigned WIDTH     = 1,
  parameter int unsigned STAGES    = 2,
  parameter logic        RESET_VAL = 1'b0
) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic [WIDTH-1:0] d,   // asynchronous input(s) from the far domain
  output logic [WIDTH-1:0] q    // synchronized output(s) in this domain
);

  if (STAGES == 0) begin : gen_same_domain
    // Same clock domain as the source: nothing to synchronize.
    assign q = d;
  end else begin : gen_sync
    // synthesis note: mark this chain as an ASYNC_REG / false-path in real flows.
    // Indexed as [stage] of WIDTH-wide vectors so that STAGES == 1 needs no
    // special case (the shift loop below simply does not execute).
    // PACKED, not unpacked -- see the header on why the constraint files care.
    logic [STAGES-1:0][WIDTH-1:0] sync_q;

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        sync_q <= {(STAGES*WIDTH){RESET_VAL}};
      end else begin
        sync_q[0] <= d;
        for (int unsigned s = 1; s < STAGES; s++)
          sync_q[s] <= sync_q[s-1];
      end
    end

    assign q = sync_q[STAGES-1];
  end

endmodule
