`timescale 1ns/1ps
// Reset synchronizer: asynchronous assert, synchronous release.
//
// Nothing in it is PPU-specific -- it was called ppu_rst_sync only because the
// PPU needed it first. The same two flops appear inline inside
// qchannel_devrst_ctrl, which now instantiates this instead of carrying its own
// copy.
//
// The reset arrives asynchronously and is applied immediately, which is what
// PCSA (DEN 0050) Section 7.2.9 asks for: "Reset assertion is asynchronous to
// ensure all registers are correctly reset regardless of the availability of
// system clocks." Release is retimed onto clk so no flop in the destination
// domain sees it change near an edge.
//
// DELIBERATELY NOT PARAMETERIZED
//
// A STAGES parameter would be the obvious generalization and it is the one
// thing this module must not have. constraints/ppu_lpi.xdc tells a RESET
// synchronizer apart from a CDC synchronizer by shape -- meta_q/sync_q are
// SCALARS here and a vector in cdc_sync -- and the two need opposite treatment:
// both want ASYNC_REG, but a CDC chain's first flop is false-pathed while a
// reset synchronizer's release path stays timed. That file says so in as many
// words, and warns that a depth parameter here would force it onto hierarchy
// matching instead. (2026-10-06: src/constraints, ppu_lpi.xdc with it, was
// removed with the Vivado flow; it is in the git history.)
//
// Two flops is also the right number: this is a reset, not a data path, and
// depth beyond two buys nothing that MTBF analysis on the destination clock
// would not already have settled.

module rst_sync (
  input  logic clk,       // destination clock domain
  input  logic rst_in_n,  // reset from the PPU, active LOW, async to clk
  output logic rst_out_n  // synchronized reset, active LOW
);

  logic meta_q, sync_q;

  always_ff @(posedge clk or negedge rst_in_n) begin
    if (!rst_in_n) begin
      meta_q <= 1'b0;
      sync_q <= 1'b0;
    end else begin
      meta_q <= 1'b1;
      sync_q <= meta_q;
    end
  end

  assign rst_out_n = sync_q;

endmodule
