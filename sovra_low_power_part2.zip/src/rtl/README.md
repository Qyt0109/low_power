# `src/rtl` — the shared power-control RTL

This directory holds the blocks every power domain of the platform is built
from: the PPU and its PCSM, the two AMBA LPI channels, the clock and reset
infrastructure, and the phase-5 device-side glue for SOVRA (the READY-bit
adapter, the TL-UH access gate and the clock/reset request bridge). The SCP
subsystem is in `src/pmu`, the four-domain reference platform in `src/soc4`,
and vendored third-party code in `src/vendor`.

Each folder has its own README; this page is the index and shows how the
blocks compose into one domain.

## The folders

| Folder | Purpose | Main modules |
|---|---|---|
| [`acg/`](acg/README.md) | Access control gates (PCSA 7.2.8): hold, error or wake on a bus access to a domain that is down. TL-UL around OpenTitan's `tlul_lc_gate`, and TL-UH (platform plan H15) | `acg_ctrl`, `acg_tlul`, `acg_tluh`, `tluh_gate` |
| [`adp/`](adp/README.md) | The READY-bit Q-Channel device adapter for CVA6 and Rocket harts (H14), and its TL-UL READY registers | `hart_ready_adp`, `hart_ready_regs` |
| [`ckrst/`](ckrst/README.md) | The clock/reset request bridge (H16, F11): a PPU's DEVCLKEN and device resets forwarded to the SoC's `clkgate` / `tilereset`, with the acknowledgements checked | `ckrst_bridge` |
| [`common/`](common/README.md) | Protocol-free infrastructure: the clock gate and the two synchronisers | `clk_gate`, `cdc_sync`, `rst_sync` |
| [`pchannel/`](pchannel/README.md) | AMBA LPI P-Channel (IHI 0068C §2.2): controller, device, monitor, and an example domain | `pchannel_controller`, `pchannel_device` |
| [`ppu/`](ppu/README.md) | The Power Policy Unit (DEN 0051E, one device Q-Channel), the PCSM, the PPU clock controller, the AXI4-Lite bridge and the domain wrappers | `ppu_top`, `ppu_pcsm`, `ppu_dom_top`, `ppu_axi_dom_top` |
| [`qchannel/`](qchannel/README.md) | AMBA LPI Q-Channel (IHI 0068C §2.1): controller, device, the clock-control device variant, the LPD-Q distributor, a monitor | `qchannel_controller`, `qchannel_device`, `qchannel_device_comb`, `qchannel_lpd` |
| [`tluh/`](tluh/README.md) | TileLink message-shape helpers shared by `tluh_gate` and `hart_ready_adp`: which messages carry data, how many beats, where a message starts and ends | `tluh_pkg`, `tl_beat_cnt` |

## How a domain is put together

`ppu_axi_dom_top` (in `ppu/`) is the unit a SoC instantiates per domain; soc4
has four of them (`u_dom` in `soc4_cpu_dom` and `soc4_acc_dom`). It is:

```
 ppu_axi_dom_top
 ├── u_axi      ppu_axi_lite_adapter   AXI4-Lite to the PPU's register strobe, PWAKEUP     (ppu/)
 ├── u_clkctrl  ppu_clk_ctrl           the PPU's own clock controller (PCK-600 CLK-CTRL)    (ppu/)
 ├── u_gate     clk_gate               gates the PPU clock                                  (common/)
 └── u_pd       ppu_dom_top                                                                 (ppu/)
     ├── u_ppu      ppu_top            the PPU: ppu_regs, ppu_irq, ppu_seq, plus
     │                                 qchannel_controller (DEVQ*), pchannel_controller
     │                                 (PCSMP*) and qchannel_device_comb (PPUCLKQ*)
     ├── u_pcsm     ppu_pcsm           the PCSM: pchannel_device and the Table 3-1 decode
     ├── u_dev      qchannel_device    the always-on device Q-Channel agent (dclk)        (qchannel/)
     ├── u_clkctrl  clk_gate           the device clock gate (DEVCLKEN, resynchronised)    (common/)
     └── rst_sync ×3                   the wrapper's reset and the two device resets       (common/)
```

The clocks: `aclk` (free-running) for the bridge and the clock controller, the
gated PPU clock for `ppu_dom_top`'s PPU and PCSM, and `dclk` for the device
side. CDC finding CDC-1 (`src/signoff/SIGNOFF_REPORT.md` §3.2, requirement R3)
applies here: with a `dclk` asynchronous to `aclk`, set
`CLK_QACTIVE_SYNC = 1` so the clock controller synchronises the raw
DEVQACTIVE. The default 0 is right only while `dclk` is `aclk`, as in soc4.

Around the wrapper, outside it, sit the per-domain blocks that depend on the
device:

| Block | Folder | Connects to `ppu_axi_dom_top` through | In soc4 |
|---|---|---|---|
| Device Q-Channel adapter: drives `dev_quiescent_busy`, `dev_quiescent_deny` (and `dev_wake`) from the device's state | `adp/` (`hart_ready_adp` for CVA6 / Rocket); soc4 uses its own Ibex adapter, `soc4_cpu_adp` | the device side, `dclk` | Ibex adapter only; `hart_ready_adp` is unit-tested (`make readyadp`), not yet in a SoC |
| Access control gate on the domain's bus port | `acg/` (`acg_tlul`, `acg_tluh`) | its own Q-Channel, driven like a device by the PPU; under PD5 the stall-and-wake request is a line into the SCP (`wake_o`) | not instantiated; soc4 has the wake inputs (`acg_wake_i`) only |
| Clock/reset request bridge | `ckrst/` | `dev_clken_req`, `dev_nret_rst_n`, `dev_ret_rst_n`, `dev_isolaten` | one `u_ckrst` per domain, observing; status in soc4_ctrl `CKRST_STAT`, SCP input 15 |

Isolation, power switching and retention are power intent, not RTL: see
`src/upf/` (`ppu_pd_top.upf` for one domain, `soc4_top.upf` for the platform)
and the header of `ppu/ppu_dom_top.sv`, "WHAT A DEVICE ATTACHED HERE NEEDS
FROM THE POWER INTENT".

## Tests and sign-off

Every functional target is in `src/Makefile` (`make -C src <target>`); the
README of each folder lists its own. The phase-5 blocks each have a unit test
with planted mutants that must fail at their own tagged check: `acgtluh`
(4 mutants), `readyadp` (2), `ckrst` (1), and `soc4ckrst` for the bridge's
firmware side. Static and formal sign-off (`make signoff`: VC LP, CDC, RDC,
Lint and Formal) is described in `src/signoff/SIGNOFF_REPORT.md`; the formal
properties are in `src/formal/<block>/`.

Retired targets, for readers of older notes: the `pmu_top` / `pmu_tb` / `scp*`
targets of the twelve-domain system went on 2026-10-02 (soc4 replaces them),
the lint targets `ppulatch`, `ppusrc`, `ppudecl`, `ppuupf` and `ppuspec`
on 2026-10-05 with `src/lint`, and the Vivado targets (`synth`, `impl`,
`xsim-pd`, `xsim-diff`, `ppusynth`) on 2026-10-06 with `src/constraints`.

## References

- Arm Power Policy Unit Architecture Specification v1.1, ARM DEN 0051E.
- AMBA Low Power Interface Specification, ARM IHI 0068C (text:
  `build/spec_txt/arm-amba-low-power-interface-spec.txt`).
- Arm CoreLink PCK-600 TRM 101150, and PCSA DEN 0050 (text in
  `build/spec_txt/`).
- The TileLink encodings: `src/vendor/sovra_tl/tl_pkg.sv` (README there).
- The platform plan: `Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md` §14 (decisions
  PD1-PD10, hardware items H1-H22, implementation choices §14.7).
