`timescale 1ns/1ps
// The SCP's processor: lowRISC Ibex, configured and tied off for this role.
//
// References: Arm Power Control System Architecture (ARM DEN 0050D) Sections
// 3.2, 3.2.2, 6.4 and 6.4.1; lowRISC Ibex at the revision recorded in
// src/pmu/ibex/README.md, whose ibex_configs.yaml names the configuration used.
//
//            ┌─────────────────── scp_core ────────────────────┐
//   instr ◄──┼── ibex_top ("small": RV32IMC, 2-stage, RegFileFF)│
//   data  ◄──┼──   no ICache, no PMP, no SecureIbex, no debug   ├──► core_sleep
//   irq   ──►│     CHERIoT / TRVK / scramble / lockstep tied off │
//            └─────────────────────────────────────────────────┘
//
// WHY A WRAPPER AND NOT ibex_top DIRECTLY
//
// Two reasons, and neither is convenience.
//
// 1. The configuration is a design decision, so it lives in RTL. ibex_top has
//    twenty-odd parameters and the SoC integration must not depend on a
//    Makefile remembering to override the right ones. This module freezes the
//    set below; every instantiation of the SCP gets the same core.
//
// 2. Ibex master carries interfaces this SCP does not use -- CHERIoT
//    capabilities, the TRVK revocation-bitmap port, ICache scrambling, the
//    lockstep shadow ports, the security alerts. Each is tied to its inactive
//    value HERE, once, with the reason next to it, instead of in every
//    testbench and top level that instantiates the SCP.
//
// THE CONFIGURATION, AGAINST PCSA 6.4.1 "SCP Processor Core Selection"
//
// PCSA lists what to weigh: processing capacity, interrupt types, interrupt
// priority and latency, area and power, debug and trace, trusted operation.
//
//   Processing capacity   "Tasks that scale with AP core count, such as idle
//                         management ... will typically dominate utilization."
//                         When this was chosen, idle management was to be
//                         hardware-autonomous (dynamic PPU policy; the
//                         flat-domain design document, removed 2026-10-05),
//                         so the SCP would handle tier-3 requests only. Since
//                         2026-10-04 every PPU is static-only and every power
//                         transition is an SCP decision taken on an interrupt
//                         (Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Section
//                         14.1, PD5); soc4's firmware does that on this core.
//                         Ibex's "small" configuration -- two-stage
//                         pipeline, 3-cycle multiplier -- is the smallest
//                         supported one.
//
//   Interrupt types       "Some processors have vectored interrupts that can
//                         ease the connection, handling, and latency of
//                         interrupts ... the number of interrupt inputs
//                         available should also be considered. If this is too
//                         low and an additional interrupt controller is
//                         required within the SCP this adds latency."
//                         Ibex vectors 15 fast interrupts (mcause 16-30) plus
//                         timer, external, software and an NMI. Until
//                         2026-10-05 the PPU interrupts took irq_fast_i one
//                         each. The platform needs more sources than 15 (every
//                         PPU, the doorbells, the wake lines, the SoC PLIC's
//                         outputs), so scp_top now puts every source behind one
//                         status/enable block (scp_irq.sv) on irq_external_i,
//                         and ties the fast lines LOW (platform plan H7). The
//                         firmware reads one register to find the source. See
//                         the map below.
//
//   Area and power        "The SCP will typically be always-on." No ICache:
//                         the SCP runs from private single-cycle RAM (PCSA
//                         6.4.1, "The SCP firmware code and data spaces are
//                         entirely within its private RAM"), so a cache would
//                         add area and buy nothing. core_sleep_o is exported
//                         so a clock controller can gate the SCP's own clock
//                         root while it waits in WFI.
//
//   Debug and trace       DbgTriggerEn = 0 and no Debug Module: debug_req_i is
//                         tied LOW and the Dm* parameters are left at their
//                         defaults, unused. Simulation tracing is available by
//                         instantiating ibex_top_tracing in a testbench
//                         instead; the RISC-V Debug Module is a later
//                         addition if FPGA bring-up wants it.
//
//   Trusted operation     PCSA 3.2.2: the SCP's "resources, including its
//                         memory and peripherals, are not accessible to the
//                         rest of the system." That boundary is the ADDRESS
//                         MAP -- SCP RAM and the PPU windows are reachable only
//                         from this core's bus -- not a feature of the core.
//                         So PMPEnable = 0: the firmware is one trust domain
//                         and PMP would only partition it against itself.
//                         SecureIbex = 0 for the same reason: lockstep, dummy
//                         instructions and bus ECC defend against fault
//                         injection, which is outside this study's scope.
//                         Both are one parameter away if that changes.
//
// INTERRUPT MAP (fixed here; the firmware's vector table depends on it)
//
//   Ibex line        mcause   vector offset   source
//   irq_software_i   3        0x0C            unused, tied LOW
//   irq_timer_i      7        0x1C            SCP timer (mtimecmp)
//   irq_external_i   11       0x2C            scp_irq's line: every PPU, the
//                                             doorbells, the wake lines, the
//                                             SoC PLIC's outputs (scp_top)
//   irq_fast_i[0..14] 16..30  0x40..0x78      tied LOW by scp_top, unused
//   irq_nm_i         31       0x7C            tied LOW by scp_top, unused: the
//                                             watchdog (scp_wdog) resets the SCP
//                                             on expiry and has no pre-timeout
//                                             interrupt
//   reset            --       0x80            first instruction fetched
//
// Vector offsets are relative to boot_addr_i, which Ibex loads into mtvec at
// reset; each entry is one 32-bit jump. Every source is LEVEL-SENSITIVE and
// stays asserted until the firmware clears it at the peripheral, which is
// what PCSA 7.2.1 requires of wake stimulus and what the PPU's IRQ output
// already is ("IRQ is level-sensitive and HIGH while any PPU_ISR or PPU_AISR
// bit is set", src/rtl/ppu/REGISTERS.md Section 4.4).
//
// MEMORY INTERFACES
//
// Both are Ibex's request/grant/rvalid protocol: req_o is held until gnt_i,
// the response arrives on a later cycle with rvalid_i, and err_i alongside
// rvalid_i makes the access fault -- a load/store access fault exception (or
// instruction access fault for fetches) that the firmware sees in mcause. An
// AXI4-Lite SLVERR from a PPU bridge therefore reaches the firmware as an
// exception, not as a silently wrong value; see src/pmu/README.md.
//
// The integrity sidebands (*_intg) belong to SecureIbex and are tied to zero
// on the inputs and left unconnected on the outputs.

module scp_core #(
  parameter logic [31:0] HART_ID   = 32'h0000_0000
) (
  input  logic        clk_i,
  input  logic        rst_ni,

  // ---- Where the core boots ----
  // A port, not a parameter, so that a core whose boot address is set at run
  // time (soc4's CPU domains, SOC4_DESIGN.md Section 6.2) is the same module.
  // Sampled at reset release (ibex_controller.sv:580-593): Ibex fetches its
  // first instruction from {boot_addr_i[31:8], 8'h80} (ibex_if_stage.sv:243,
  // 250-251) and takes traps through the vector table at boot_addr_i (the
  // reset value of mtvec). [7:0] must be 0 (ibex_if_stage.sv:932).
  input  logic [31:0] boot_addr_i,

  // ---- Instruction fetch ----
  output logic        instr_req_o,
  input  logic        instr_gnt_i,
  input  logic        instr_rvalid_i,
  output logic [31:0] instr_addr_o,
  input  logic [31:0] instr_rdata_i,
  input  logic        instr_err_i,

  // ---- Loads and stores ----
  output logic        data_req_o,
  input  logic        data_gnt_i,
  input  logic        data_rvalid_i,
  output logic        data_we_o,
  output logic [3:0]  data_be_o,
  output logic [31:0] data_addr_o,
  output logic [31:0] data_wdata_o,
  input  logic [31:0] data_rdata_i,
  input  logic        data_err_i,

  // ---- Interrupts, per the map above. All level-sensitive ----
  input  logic        irq_timer_i,
  input  logic        irq_external_i,
  input  logic [14:0] irq_fast_i,
  input  logic        irq_nm_i,

  // ---- Hold the core before its RAM is loaded; release to boot ----
  input  logic        fetch_enable_i,

  // ---- HIGH while the core sleeps in WFI: the SCP's own activity indicator ----
  output logic        core_sleep_o
);

  // Ibex's fetch enable is a multi-bit value so that SecureIbex can detect a
  // glitched one; with SecureIbex off only the encoding matters.
  ibex_pkg::ibex_mubi_t fetch_enable_mubi;
  assign fetch_enable_mubi = fetch_enable_i ? ibex_pkg::IbexMuBiOn
                                            : ibex_pkg::IbexMuBiOff;

  ibex_top #(
    // ---- ibex_configs.yaml "small", except RV32ZC (see below) ----
    .BaseIsa          (ibex_pkg::BaseIsaRV32I),
    .RV32E            (1'b0),
    .RV32M            (ibex_pkg::RV32MFast),
    .RV32B            (ibex_pkg::RV32BNone),
    // Zca only: the compiler is invoked with -march=rv32imc, which emits the
    // standard C extension and nothing from Zcb or Zcmp. The decoders for
    // those would be dead logic.
    .RV32ZC           (ibex_pkg::RV32Zca),
    .RegFile          (ibex_pkg::RegFileFF),
    .BranchTargetALU  (1'b0),
    .WritebackStage   (1'b0),
    .ICache           (1'b0),
    .ICacheECC        (1'b0),
    .ICacheScramble   (1'b0),
    .BranchPredictor  (1'b0),
    .DbgTriggerEn     (1'b0),
    .SecureIbex       (1'b0),
    .PMPEnable        (1'b0),
    .PMPGranularity   (0),
    .PMPNumRegions    (4),
    .MHPMCounterNum   (0),
    .MHPMCounterWidth (40)
  ) u_ibex (
    .clk_i                   (clk_i),
    .rst_ni                  (rst_ni),

    .test_en_i               (1'b0),
    .scan_rst_ni             (1'b1),
    .ram_cfg_icache_tag_i    ('{default: prim_ram_1p_pkg::RAM_1P_CFG_REQ_DEFAULT}),
    .ram_cfg_icache_tag_o    (),
    .ram_cfg_icache_data_i   ('{default: prim_ram_1p_pkg::RAM_1P_CFG_REQ_DEFAULT}),
    .ram_cfg_icache_data_o   (),

    // ---- CHERIoT: not enabled (BaseIsaRV32I), so its ports are inert ----
    .cheriot_enable_i        (ibex_pkg::IbexMuBiOff),
    .trvk_heap_base_addr_i   (32'h0000_0000),
    .trvk_revbm_req_o        (),
    .trvk_revbm_gnt_i        (1'b0),
    .trvk_revbm_rvalid_i     (1'b0),
    .trvk_revbm_addr_o       (),
    .trvk_revbm_rdata_i      (32'h0000_0000),
    .trvk_revbm_rdata_intg_i (7'h00),
    .trvk_revbm_err_i        (1'b0),

    .hart_id_i               (HART_ID),
    .boot_addr_i             (boot_addr_i),

    // ---- Instruction fetch ----
    .instr_req_o             (instr_req_o),
    .instr_gnt_i             (instr_gnt_i),
    .instr_rvalid_i          (instr_rvalid_i),
    .instr_addr_o            (instr_addr_o),
    .instr_rdata_i           (instr_rdata_i),
    .instr_rdata_intg_i      (7'h00),
    .instr_err_i             (instr_err_i),

    // ---- Loads and stores ----
    .data_req_o              (data_req_o),
    .data_gnt_i              (data_gnt_i),
    .data_rvalid_i           (data_rvalid_i),
    .data_we_o               (data_we_o),
    .data_be_o               (data_be_o),
    .data_addr_o             (data_addr_o),
    .data_wdata_o            (data_wdata_o),
    .data_wdata_intg_o       (),
    .data_tag_o              (),
    .data_rdata_i            (data_rdata_i),
    .data_rdata_intg_i       (7'h00),
    .data_tag_i              (1'b0),
    .data_err_i              (data_err_i),

    // ---- Interrupts ----
    .irq_software_i          (1'b0),
    .irq_timer_i             (irq_timer_i),
    .irq_external_i          (irq_external_i),
    .irq_fast_i              (irq_fast_i),
    .irq_nm_i                (irq_nm_i),

    // ---- ICache scrambling: no ICache ----
    .scramble_key_valid_i    (1'b0),
    .scramble_key_i          ('0),
    .scramble_nonce_i        ('0),
    .scramble_req_o          (),

    // ---- No Debug Module ----
    .debug_req_i             (1'b0),
    .crash_dump_o            (),
    .double_fault_seen_o     (),

    .fetch_enable_i          (fetch_enable_mubi),
    .mcounteren_writable_i   (ibex_pkg::IbexMuBiOn),

    // ---- SecureIbex outputs: constant with SecureIbex = 0 ----
    .alert_minor_o           (),
    .alert_major_internal_o  (),
    .alert_major_bus_o       (),
    .core_sleep_o            (core_sleep_o),

    // ---- Lockstep shadow ports: no lockstep ----
    .lockstep_cmp_en_o       (),
    .data_req_shadow_o       (),
    .data_we_shadow_o        (),
    .data_be_shadow_o        (),
    .data_addr_shadow_o      (),
    .data_wdata_shadow_o     (),
    .data_wdata_intg_shadow_o(),
    .instr_req_shadow_o      (),
    .instr_addr_shadow_o     ()
  );

endmodule
