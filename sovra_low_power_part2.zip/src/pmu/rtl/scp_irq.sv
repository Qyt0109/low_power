`timescale 1ns/1ps
// The SCP's interrupt status/enable block: one generic bank of NUM_IN inputs
// onto ONE line, the core's irq_external_i.
//
// References: Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md Sections 14.1 (PD1, PD5,
// PD7), 14.7 (H7, H8/H9, F10) and 15.2 phase 2; src/pmu/README.md Section 2.1
// (the map) and 2.3; src/pmu/fw/hal/scp_irq.h (the firmware's side, which must
// agree with the register map below).
//
//   in_i[i] ──► sync (ASYNC[i]: cdc_sync, 2 flops) ──► in_s[i] ──► RAW
//                                          │
//              EDGE[i] ? rising edge : level ──► & ENABLE[i] ──► PENDING[i] (W1C)
//                                                                   │
//                                  irq_o = | (PENDING & ENABLE) ◄──┘ ──► irq_external_i
//
// WHAT THIS IS, AND WHAT IT IS NOT. Glue, not an interrupt controller: no
// priorities, no claim/complete, no vectors, no targets. The SoC's PLIC stays
// the SoC's (PD1); its output and its per-hart pending signals are just inputs
// here, like the PPU interrupts, the mailbox doorbell and the raw wake lines
// (RTC, GPIO wake, BBRX detect, the debug power request, the access gates'
// wake requests; PD7). What an input MEANS is in the firmware's input table
// (the platform header's SCP_PLAT_INPUTS), not in this hardware. With every
// source behind one line, Ibex's fast interrupts are no longer used, and the
// 15-line limit on sources is gone; NUM_IN is bounded by the 32-bit registers.
//
// THE INPUT BANK. Per input, three bits of state and one of configuration:
//
//   synchroniser  ASYNC[i] = 1: two flops (rtl/common/cdc_sync, reused as it
//                 is), for a source on another clock -- every wake line and the
//                 PLIC's outputs. ASYNC[i] = 0: the source is already on clk_i
//                 (soc4: the PPUs and the mailbox, always-on with the SCP,
//                 PCSA 7.2.3), and is taken as it is, with no added latency.
//                 An asynchronous input must be held for at least two clk_i
//                 cycles (one synchroniser sample plus margin) to be seen.
//   EDGE[i]       1: a rising edge of the synchronised input is the event.
//                 0: the input HIGH is the event (level).
//   ENABLE[i]     the mask. 0: the input does NOTHING -- it sets no pending
//                 bit and raises no interrupt; RAW still shows it.
//   PENDING[i]    sticky. Set at the clock edge after the event while
//                 ENABLE[i] = 1; cleared by writing 1 (W1C); a new event in
//                 the cycle of the clear wins. A level input still HIGH sets
//                 it again in the next cycle, so the firmware clears a level
//                 source first and the pending bit second -- or masks it.
//
// The edge detector's history flop runs whatever ENABLE is, so unmasking an
// edge input that is already HIGH does not invent an edge.
//
// THE REGISTERS. A bus.sv device: it answers exactly one cycle after the
// request and cannot stall. Byte enables are honoured on writes. Bits at and
// above NUM_IN read 0 and ignore writes. Any other offset answers err.
//
//   off   name     access  reset  fields
//   0x00  PENDING  R/W1C   0      [i] input i's event happened while enabled
//   0x04  ENABLE   RW      0      [i] 1 = input i may set PENDING and interrupt
//   0x08  EDGE     RW      0      [i] 1 = rising edge, 0 = level
//   0x0C  RAW      RO             [i] input i after its synchroniser
//   0x10  ACTIVE   RO             PENDING & ENABLE: what drives irq_o
//   0x14  INFO     RO             [7:0] NUM_IN, so the firmware can check its
//                                 table against the build
//
// Everything resets to 0: every input masked and level, nothing pending, so
// the line is LOW until the firmware has programmed the bank.

module scp_irq #(
  parameter int unsigned NUM_IN      = 1,
  parameter logic [31:0] ASYNC       = '0,  // bit i: input i is asynchronous to clk_i
  parameter int unsigned SYNC_STAGES = 2
) (
  input  logic              clk_i,
  input  logic              rst_ni,

  // ---- bus.sv device port ----
  input  logic              req_i,
  input  logic              we_i,
  input  logic [3:0]        be_i,
  input  logic [31:0]       addr_i,
  input  logic [31:0]       wdata_i,
  output logic              rvalid_o,
  output logic [31:0]       rdata_o,
  output logic              err_o,

  // ---- The inputs, and the one line to the core ----
  input  logic [NUM_IN-1:0] in_i,
  output logic              irq_o
);

  if (NUM_IN < 1 || NUM_IN > 32) begin : g_bad_num_in
    $error("scp_irq: NUM_IN = %0d; the registers are 32 bits wide", NUM_IN);
  end

  localparam logic [11:0] R_PENDING = 12'h000;
  localparam logic [11:0] R_ENABLE  = 12'h004;
  localparam logic [11:0] R_EDGE    = 12'h008;
  localparam logic [11:0] R_RAW     = 12'h00C;
  localparam logic [11:0] R_ACTIVE  = 12'h010;
  localparam logic [11:0] R_INFO    = 12'h014;

  logic [11:0] off;
  assign off = {addr_i[11:2], 2'b00};

  // ===========================================================================
  // The input bank
  // ===========================================================================
  logic [NUM_IN-1:0] in_s;     // after the synchroniser
  logic [NUM_IN-1:0] in_q;     // ...one cycle later: the edge detector's history
  logic [NUM_IN-1:0] pend_q, en_q, edge_q;
  logic [NUM_IN-1:0] event_d, w1c;

  for (genvar i = 0; i < NUM_IN; i++) begin : g_in
    if (ASYNC[i]) begin : g_async
`ifdef SOC4_MUT_IRQ_SYNC0
      // NEGATIVE CONTROL (soc4neg M4): the synchroniser's output tied LOW, so
      // no asynchronous input is ever seen. soc4bfm's B12 must fail.
      logic unused_q;
      cdc_sync #(.WIDTH(1), .STAGES(SYNC_STAGES), .RESET_VAL(1'b0)) u_sync (
        .clk(clk_i), .rst_n(rst_ni), .d(in_i[i]), .q(unused_q));
      assign in_s[i] = 1'b0;
`else
      cdc_sync #(.WIDTH(1), .STAGES(SYNC_STAGES), .RESET_VAL(1'b0)) u_sync (
        .clk(clk_i), .rst_n(rst_ni), .d(in_i[i]), .q(in_s[i]));
`endif
    end else begin : g_sync
      assign in_s[i] = in_i[i];
    end
  end

  // Level: the input HIGH. Edge: HIGH now and LOW the cycle before.
  assign event_d = in_s & ~(edge_q & in_q);

  // The byte enables as a bit mask, cut to the inputs that exist.
  logic [31:0] bmask;
  assign bmask = {{8{be_i[3]}}, {8{be_i[2]}}, {8{be_i[1]}}, {8{be_i[0]}}};

  assign w1c = (req_i && we_i && off == R_PENDING) ? NUM_IN'(wdata_i & bmask) : '0;

  // The only writer of in_q and pend_q.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      in_q   <= '0;
      pend_q <= '0;
    end else begin
      in_q   <= in_s;
      pend_q <= (pend_q & ~w1c) | (event_d & en_q);
    end
  end

  assign irq_o = |(pend_q & en_q);

  // ===========================================================================
  // The registers: the only writer of en_q, edge_q and the read port
  // ===========================================================================
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      en_q     <= '0;
      edge_q   <= '0;
      rvalid_o <= 1'b0;
      rdata_o  <= '0;
      err_o    <= 1'b0;
    end else begin
      rvalid_o <= req_i;
      err_o    <= 1'b0;
      rdata_o  <= '0;
      if (req_i) begin
        unique case (off)
          R_PENDING: if (!we_i) rdata_o <= 32'(pend_q);
          R_ENABLE: begin
            if (we_i) en_q <= (en_q & ~NUM_IN'(bmask)) | NUM_IN'(wdata_i & bmask);
            else      rdata_o <= 32'(en_q);
          end
          R_EDGE: begin
            if (we_i) edge_q <= (edge_q & ~NUM_IN'(bmask)) | NUM_IN'(wdata_i & bmask);
            else      rdata_o <= 32'(edge_q);
          end
          R_RAW:    if (!we_i) rdata_o <= 32'(in_s);
          R_ACTIVE: if (!we_i) rdata_o <= 32'(pend_q & en_q);
          R_INFO:   if (!we_i) rdata_o <= 32'(NUM_IN);
          default:  err_o <= 1'b1;
        endcase
      end
    end
  end

  // scp_top's bus.sv has already matched [31:12] (base 0x0001_1000, mask
  // 0xFFFF_F000); [1:0] are the byte lanes, which be_i carries.
  logic unused_addr;
  assign unused_addr = ^{addr_i[31:12], addr_i[1:0]};

endmodule
