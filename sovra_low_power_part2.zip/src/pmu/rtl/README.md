# pmu/rtl: the SCP hardware

The System Control Processor subsystem: `scp_top` and every block it
instantiates besides Ibex. It is always-on, runs on one clock, and holds the
core, its private RAM, timer, interrupt block and watchdog, a private bus, and
an AXI4-Lite path with one manager port per PPU. It also has the `ext_*`
window, a port on which the top level hangs its own devices. In soc4,
`soc4_top` instantiates `scp_top` with four PPU slots and puts the RPMI mailbox,
`soc4_ctrl` and the CPU load ports on `ext_*`. The design rationale is in
[`../README.md`](../README.md) §2–3; the firmware that runs on it is
[`../fw/`](../fw/README.md).

```
 ┌──────────────────────────────── scp_top ─────────────────────────────────┐
 │  scp_core ──instr──────────────────────────────► scp_ram port B          │
 │  (Ibex)   ──data──► scp_data_split ──local──► bus ──┬─► scp_ram port A   │
 │     ▲                  │                            ├─► timer            │
 │     │ irq_timer ◄──────┼────────────────────────────┤   ext_*  (port)    │
 │     │                  │                            ├─► scp_irq          │
 │     │                  │                            └─► scp_wdog ──┐     │
 │     │ irq_external ◄───┼────────────────────── scp_irq ◄── irq_i[] │     │
 │     │                  │   rst_sub_n = rst_ni & ~wdog reset ◄──────┘     │
 │     │                  └──axi──► scp_axi_lite_master                     │
 │     │                                     │                              │
 │     │                              scp_axi_lite_demux ──► m_axi[NUM_PPU] │
 │     └── irq_fast, irq_nm: tied LOW                                       │
 └──────────────────────────────────────────────────────────────────────────┘
```

## Files

| File | What it is |
|---|---|
| `scp_top.sv` | The subsystem: the memory map, the two resets, and the wiring above |
| `scp_core.sv` | lowRISC Ibex (`ibex_top`) frozen in the `small` configuration: RV32IMC (`RV32ZC = RV32Zca`), fast multiplier, flop register file, no ICache, no PMP, no SecureIbex, no debug. Every unused Ibex interface (CHERIoT, TRVK, scrambling, lockstep, alerts) is tied off here once |
| `scp_ram.sv` | The private RAM, `DEPTH` = 16384 words (64 KB): port A for loads and stores behind `bus.sv`, port B for instruction fetch. One-cycle response on both ports |
| `scp_data_split.sv` | Splits the core's load/store port: the AXI window to the bridge, everything else to `bus.sv`, keeping responses in order |
| `scp_axi_lite_master.sv` | The core's data port as one AXI4-Lite manager, one transaction at a time |
| `scp_axi_lite_demux.sv` | One AXI4-Lite manager to `NUM_M` subordinates on address bits `[SEL_LSB +: SEL_W]`; unused selects answer DECERR |
| `scp_irq.sv` | The interrupt status/enable block: `NUM_IN` inputs onto the core's one external interrupt |
| `scp_wdog.sv` | The watchdog: a counter, a kick register, and a reset of the SCP subsystem alone |

Dependencies from elsewhere: `../ibex/rtl/` (the core), `../ibex/shared/bus.sv`
and `../ibex/shared/timer.sv` (the private bus and the timer, unmodified),
`src/rtl/common/cdc_sync.sv` (`scp_irq`'s synchroniser), and the OpenTitan
`prim_generic` cells Ibex needs (`src/vendor/opentitan`).

## `scp_top`

**Parameters.**

| Parameter | Default | Meaning |
|---|---|---|
| `NUM_PPU` | 12 | PPU manager ports, 1 to 16 (`$error` otherwise). soc4 sets 4 |
| `NUM_IRQ` | `NUM_PPU + 1` | inputs of `scp_irq`, 1 to 32. soc4 sets 16 |
| `IRQ_ASYNC` | `'0` | bit `i`: `irq_i[i]` comes from another clock and gets a two-flop synchroniser. soc4 sets `32'h0000_3FE0` (inputs 5–13) |
| `BOOT_ADDR` | `32'h0000_0000` | the core's boot address: vectors at `BOOT_ADDR`, first fetch at `BOOT_ADDR + 0x80`. `[7:0]` must be 0 |

**Ports.**

| Port | Direction | Meaning |
|---|---|---|
| `clk_i` | in | the one clock |
| `por_ni` | in | power-on reset: only `scp_wdog`'s `CAUSE`, reset count and reset sequencer |
| `rst_ni` | in | the SCP subsystem's reset from outside |
| `fetch_enable_i` | in | lets a testbench hold the core until the RAM is loaded |
| `rst_sub_no` | out | `rst_ni` and the watchdog's reset, as applied inside, for the top level's SCP-side logic (soc4: its `ext` window's `bus.sv`) |
| `wdog_rst_o` | out | the watchdog's reset request alone |
| `ext_req_o`, `ext_we_o`, `ext_be_o`, `ext_addr_o`, `ext_wdata_o` / `ext_rvalid_i`, `ext_rdata_i`, `ext_err_i` | out / in | the `0x0002_0000` window, `bus.sv` protocol: the device must answer with `rvalid` exactly one cycle after `req` |
| `m_axi_*[NUM_PPU]` | out / in | one AXI4-Lite manager port per PPU (AW, W, B, AR, R; 32-bit address and data, `prot`) |
| `irq_i[NUM_IRQ]` | in | every interrupt source but the timer, one input each of `scp_irq` |
| `core_sleep_o` | out | HIGH while the core waits in WFI |

**The memory map** (localparams in `scp_top.sv`; the same map is in
`../fw/hal/scp_regs.h` and [`../README.md`](../README.md) §2.1, and all three
must agree):

| Base | Size | Block | Path |
|---|---|---|---|
| `0x0000_0000` | 64 KB | `scp_ram`: vector table at `0x0`, reset vector at `0x80` | `bus.sv` |
| `0x0001_0000` | 1 KB | `timer`: `MTIME` `+0x0`, `MTIMEH` `+0x4`, `MTIMECMP` `+0x8`, `MTIMECMPH` `+0xC` | `bus.sv` |
| `0x0001_1000` | 4 KB | `scp_irq` (registers below) | `bus.sv` |
| `0x0001_2000` | 4 KB | `scp_wdog` (registers below) | `bus.sv` |
| `0x0002_0000` | 64 KB | `ext_*`, the top level's devices | `bus.sv`, out through the port |
| `0x4000_0000` | 64 KB | PPU `n` at `0x4000_0000 + n * 0x1000`, DEN 0051E offsets in `[11:0]`; selects `NUM_PPU` to 15 answer DECERR | AXI4-Lite |

Everything else is unmapped: `bus.sv` answers with an error, and the core takes
a load or store access fault. An instruction fetch outside the RAM array is an
instruction access fault (`scp_ram`'s `b_err_o`), not an alias of address 0.
In soc4 the `ext_*` window holds the testbench's simulation control at
`0x0002_0000`, `soc4_ctrl` at `0x0002_1000`, the mailbox's SCP registers at
`0x0002_2000`, the queue memory at `0x0002_4000` (1 KB per agent), and the CPU
load ports at `0x0002_8000 + n * 0x1000` (`src/soc4/fw/hal/soc4_regs.h`).

**The interrupt map** (fixed by `scp_core.sv`; `../fw/crt0.S` depends on it):

| Ibex line | `mcause` | Vector | Source |
|---|---|---|---|
| `irq_software_i` | 3 | `0x0C` | tied LOW |
| `irq_timer_i` | 7 | `0x1C` | the timer |
| `irq_external_i` | 11 | `0x2C` | `scp_irq`: every PPU, the doorbells, the SoC PLIC's outputs, the wake lines |
| `irq_fast_i[14:0]` | 16–30 | `0x40`–`0x78` | tied LOW by `scp_top` |
| `irq_nm_i` | 31 | `0x7C` | tied LOW by `scp_top`: the watchdog has no pre-timeout interrupt |

**The two resets.** Every block runs on `rst_sub_n = rst_ni & ~(the watchdog's
reset request)`. On expiry the watchdog first holds off new AXI transactions
(`hold_o`, gating the bridge's request) until the manager is idle, at most
`DRAIN_MAX` cycles, then resets the subsystem for `RST_CYCLES` cycles: the core,
the RAM ports, the timer, `scp_irq`, the bus, the bridge and the demux. The RAM
array keeps its contents and is not reloaded. The PPUs, PCSMs and power domains
are on the top level's own reset and are untouched. The drain exists because
the PPUs' AXI4-Lite subordinates would otherwise keep a half-finished
transaction and answer the rebooted manager with a stale response.

## `scp_irq`

Per input: an optional two-flop synchroniser (`ASYNC[i]`; an asynchronous input
must be held for at least two `clk_i` cycles), level or rising edge (`EDGE[i]`),
a mask (`ENABLE[i]`) and a sticky `PENDING[i]`. `irq_o = |(PENDING & ENABLE)`.
Glue, not a PLIC: no priorities, no claim, no vectors. What an input means is
the firmware's input table. Parameters: `NUM_IN` (1 to 32), `ASYNC`,
`SYNC_STAGES` (2).

| Offset | Name | Access | Reset | Fields |
|---|---|---|---|---|
| `0x00` | `PENDING` | R/W1C | 0 | `[i]` input `i`'s event happened while enabled. A new event in the cycle of the clear wins |
| `0x04` | `ENABLE` | RW | 0 | `[i]` 1 = input `i` may set `PENDING` and interrupt |
| `0x08` | `EDGE` | RW | 0 | `[i]` 1 = rising edge, 0 = level |
| `0x0C` | `RAW` | RO | | `[i]` input `i` after its synchroniser |
| `0x10` | `ACTIVE` | RO | | `PENDING & ENABLE` |
| `0x14` | `INFO` | RO | | `[7:0]` `NUM_IN` |

A `bus.sv` device: it answers one cycle after the request and cannot stall.
Byte enables are honoured on writes, bits at and above `NUM_IN` read 0, and any
other offset answers `err`. A level input still HIGH sets `PENDING` again in the
next cycle, so the firmware masks a level source before clearing it. The edge
detector's history flop runs whatever `ENABLE` is, so unmasking an input that is
already HIGH does not create an edge.

## `scp_wdog`

Parameters: `KEY` = `32'h4B49_434B` ("KICK"), `RST_CYCLES` = 16 (2 to 255),
`DRAIN_MAX` = 1024 (1 to 65535).

| Offset | Name | Access | Reset | Fields |
|---|---|---|---|---|
| `0x00` | `CTRL` | RW | 0 (`rst_ni`) | `[0]` EN: count, and expire at 0. `[1]` LOCK: write 1 to set, cleared only by a reset; while set, writes to `CTRL` and `TIMEOUT` are ignored |
| `0x04` | `TIMEOUT` | RW | all ones (`rst_ni`) | the value `COUNT` is loaded with |
| `0x08` | `KICK` | WO | | `KEY` as a full-word write reloads `COUNT`. Any other value or a partial write while EN is set resets the SCP at once (`CAUSE.BADKICK`). Reads 0 |
| `0x0C` | `COUNT` | RO | 0 (`rst_ni`) | cycles left |
| `0x10` | `CAUSE` | R/W1C | `por_ni` | `[0]` POR, `[1]` WDOG, `[2]` BADKICK, `[3]` DRAINTO (the drain timed out); `[15:8]` RESETS (RO), watchdog resets since power-on, saturating at 255. A trigger in the cycle of a clear wins |

Setting EN loads `COUNT`, as a kick does. `TIMEOUT` = 0 expires at once. Other
offsets answer `err`; writes to read-only registers are ignored.

## The other blocks

- **`scp_core`**: `boot_addr_i` is a port, not a parameter, so that a core
  whose boot address is set at run time is the same module. soc4 also uses
  `scp_core` for its CPU domains (`soc4_cpu_dom`, `HART_ID` per CPU) and for
  the AP (`soc4_ap`, `HART_ID` `0x10`).
- **`scp_ram`**: zeroed at time 0, then loaded with `$readmemh` from the plusarg
  named by `IMAGE_PLUSARG` (default `firmware`, so `+firmware=<file.vmem>`).
  soc4's AP instantiates a second copy with `IMAGE_PLUSARG = "ap_firmware"`.
  Zeroing matters: Ibex prefetches past the end of the code and asserts that
  fetched data is known.
- **`scp_data_split`**: a request is not forwarded while responses are
  outstanding on the other side, so the core, which pairs responses with
  requests by order, never gets a fast local response ahead of a slow AXI one.
  Same-side requests pipeline.
- **`scp_axi_lite_master`**: grants a request when idle and holds the next one
  until the response returns. AWVALID and WVALID are raised together (the PPU
  adapter accepts AW only with W present). Every access is marked
  privileged, secure, data (`AxPROT` = `3'b001`). `SLVERR` or `DECERR` becomes
  `err`, which Ibex takes as a load or store access fault: this is how a PPU
  whose clock never arrives (the adapter's `WAKE_TIMEOUT` SLVERR) reaches the
  firmware.
- **`scp_axi_lite_demux`**: parameters `NUM_M` (default 12), `AW`, `SEL_LSB`
  (12), `SEL_W` (4). One transaction per direction. W is forwarded without
  waiting for AWREADY, which `ppu_axi_lite_adapter` requires.

## Build and use

| Where | How |
|---|---|
| `make soc4elab`, `soc4`, `soc4bfm`, `soc4stress`, `soc4wdog`, `soc4ckrst`, `soc4neg` and the `...pa` forms | `soc4_top` instantiates `scp_top`; the source list is `SOC4_DUT_SRCS` in `src/Makefile`. SIM=vcs only |
| `make acgtluh` | uses `scp_irq` on the access gate's wake line |
| `make vcformal`, `vcformalneg` | `scp_irq` and `scp_wdog` are two of the formal blocks (properties in `src/formal/scp_irq/` and `src/formal/scp_wdog/`; mutants `SOC4_MUT_IRQ_SYNC0` and `SOC4_MUT_WDOG_CAUSE_SUB`) |
| `make vclp`, `vccdc`, `vcrdc`, `vclint` | run on `soc4_top`, so they cover `scp_top` (results in [`src/signoff/SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md)) |

`src/tb/pmu/scp_sim_ctrl.sv` is the testbench-only simulation-control device
that `soc4_tb` hangs on the `ext_*` window at `0x0002_0000` (console, halt,
checks, stimulus; firmware side `../fw/hal/sim.h`).

## Extending

- **An interrupt input:** raise the top level's `NUM_IRQ`, wire the source to
  `irq_i[i]`, set `IRQ_ASYNC[i]` if it is on another clock, and add one
  `I(...)` entry at index `i` in the platform header's `SCP_PLAT_INPUTS`
  ([`../fw/README.md`](../fw/README.md#extending)). The firmware checks
  `INFO` against the table at boot. 32 inputs at most.
- **A PPU:** raise `NUM_PPU` (16 at most), connect the new `m_axi_*` port and
  the PPU's interrupt to an `irq_i` input, and add the domain to the platform
  header. `SOVRA_PCSA_ARCHITECTURE.md` §15.3 lists the hardware steps.
- **A private peripheral:** a new device index in `scp_top` (`NrDevices`,
  `cfg_base`, `cfg_mask`, its `bus.sv` device port), the same base in
  `../fw/hal/scp_regs.h`, and the table in [`../README.md`](../README.md) §2.1.
  A device on `bus.sv` must answer in the next cycle.

## Known issues

- Sign-off finding F-WDOG-1 (open): a wrong kick during the watchdog's drain or
  reset phase is not recorded in `CAUSE.BADKICK`
  ([`SIGNOFF_REPORT.md`](../../signoff/SIGNOFF_REPORT.md)).
- The defaults `NUM_PPU = 12` (`scp_top`) and `NUM_M = 12` (`scp_axi_lite_demux`,
  whose header diagram still names `PPU_CPU0` to `PPU_NPU3`) come from the
  retired twelve-domain `pmu_top`. Every instantiation sets its own value.

## References

- Arm PCSA (DEN 0050D) §3.2, §3.2.2 (the SCP's private resources: the trust
  boundary is this address map) and §6.4.1 (SCP core selection, memory,
  watchdog, messaging); Figure 6.2 is the shape of `scp_top`.
- AMBA AXI and ACE (IHI 0022) A3.2.1, A3.3.1 and Part B (AXI4-Lite), not in
  `references/standards/`, so paraphrased in the headers.
- Ibex documentation, `doc/03_reference/` (`exception_interrupts.rst`,
  `load_store_unit.rst`, `instruction_fetch.rst`); revision in
  [`../ibex/README.md`](../ibex/README.md).
- [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)
  §14.1 (PD1, PD5, PD7) and §14.7 (H7–H9 the interrupt block, H18 the watchdog).
