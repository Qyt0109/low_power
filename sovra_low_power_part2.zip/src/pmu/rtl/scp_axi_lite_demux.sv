`timescale 1ns/1ps
// One AXI4-Lite manager to NUM_M subordinates: the SCP's path to its PPUs.
//
// References: AMBA AXI and ACE Protocol Specification (ARM IHI 0022) Sections
// A3.2.1 and A3.3.1, paraphrased (it is not in references/standards). PULP's
// axi_lite_demux is the shape this follows, reduced to what the SCP needs.
//
//   s_axi ──► decode addr[SEL_LSB +: SEL_W] ──┬──► m_axi[0]        PPU 0
//                                             ├──► ...
//                                             ├──► m_axi[NUM_M-1]  PPU NUM_M-1
//                                             └──► DECERR          NUM_M..15
//
// ONE TRANSACTION PER DIRECTION
//
// A write is selected when AWVALID is first seen and stays selected until its
// B handshake; a read likewise from ARVALID to its R handshake. A second write
// is not forwarded until the first has been answered. That is the whole of the
// ordering story: AXI4-Lite has no IDs, so with one transaction per direction
// there is nothing to reorder. scp_axi_lite_master issues one at a time anyway.
//
// W IS FORWARDED WITHOUT WAITING FOR AWREADY
//
// As the manager of each downstream port, this block must not make VALID wait
// for READY (IHI 0022 A3.3.1). And it matters concretely here:
// ppu_axi_lite_adapter asserts AWREADY only when AWVALID and WVALID are BOTH
// high, so a demux that held W back until AW had been accepted would deadlock
// against it. W is forwarded to the selected port as soon as the write is live
// -- AWVALID seen this cycle or earlier. Upstream, the one wait this block
// imposes is the one the protocol permits a subordinate: WREADY is not given
// before AWVALID has been seen, because until then there is no port to send W
// to.
//
// THE UNMAPPED WINDOWS ANSWER DECERR
//
// Selects NUM_M..2^SEL_W-1 have no subordinate. The request is accepted here and
// answered with DECERR (2'b11), which scp_axi_lite_master reports as a bus
// error and Ibex as an access fault. Silently completing it would let a driver
// that probes the wrong index believe it had found a PPU that reads as zero.

module scp_axi_lite_demux #(
  parameter int unsigned NUM_M   = 1,    // subordinates; scp_top passes NUM_PPU
  parameter int unsigned AW      = 32,
  parameter int unsigned SEL_LSB = 12,
  parameter int unsigned SEL_W   = 4
) (
  input  logic                        clk_i,
  input  logic                        rst_ni,

  // ---- Upstream: one subordinate port ----
  input  logic [AW-1:0]               s_axi_awaddr,
  input  logic [2:0]                  s_axi_awprot,
  input  logic                        s_axi_awvalid,
  output logic                        s_axi_awready,
  input  logic [31:0]                 s_axi_wdata,
  input  logic [3:0]                  s_axi_wstrb,
  input  logic                        s_axi_wvalid,
  output logic                        s_axi_wready,
  output logic [1:0]                  s_axi_bresp,
  output logic                        s_axi_bvalid,
  input  logic                        s_axi_bready,
  input  logic [AW-1:0]               s_axi_araddr,
  input  logic [2:0]                  s_axi_arprot,
  input  logic                        s_axi_arvalid,
  output logic                        s_axi_arready,
  output logic [31:0]                 s_axi_rdata,
  output logic [1:0]                  s_axi_rresp,
  output logic                        s_axi_rvalid,
  input  logic                        s_axi_rready,

  // ---- Downstream: NUM_M manager ports ----
  output logic [NUM_M-1:0][AW-1:0]    m_axi_awaddr,
  output logic [NUM_M-1:0][2:0]       m_axi_awprot,
  output logic [NUM_M-1:0]            m_axi_awvalid,
  input  logic [NUM_M-1:0]            m_axi_awready,
  output logic [NUM_M-1:0][31:0]      m_axi_wdata,
  output logic [NUM_M-1:0][3:0]       m_axi_wstrb,
  output logic [NUM_M-1:0]            m_axi_wvalid,
  input  logic [NUM_M-1:0]            m_axi_wready,
  input  logic [NUM_M-1:0][1:0]       m_axi_bresp,
  input  logic [NUM_M-1:0]            m_axi_bvalid,
  output logic [NUM_M-1:0]            m_axi_bready,
  output logic [NUM_M-1:0][AW-1:0]    m_axi_araddr,
  output logic [NUM_M-1:0][2:0]       m_axi_arprot,
  output logic [NUM_M-1:0]            m_axi_arvalid,
  input  logic [NUM_M-1:0]            m_axi_arready,
  input  logic [NUM_M-1:0][31:0]      m_axi_rdata,
  input  logic [NUM_M-1:0][1:0]       m_axi_rresp,
  input  logic [NUM_M-1:0]            m_axi_rvalid,
  output logic [NUM_M-1:0]            m_axi_rready
);

  localparam logic [1:0] RESP_DECERR = 2'b11;

  if (NUM_M < 1 || NUM_M > (1 << SEL_W)) begin : g_bad_num_m
    $error("scp_axi_lite_demux: NUM_M = %0d does not fit in %0d select bits",
           NUM_M, SEL_W);
  end

  // Payload is broadcast; only VALID is steered.
  for (genvar i = 0; i < NUM_M; i++) begin : g_payload
    assign m_axi_awaddr[i] = s_axi_awaddr;
    assign m_axi_awprot[i] = s_axi_awprot;
    assign m_axi_wdata[i]  = s_axi_wdata;
    assign m_axi_wstrb[i]  = s_axi_wstrb;
    assign m_axi_araddr[i] = s_axi_araddr;
    assign m_axi_arprot[i] = s_axi_arprot;
  end

  // ===========================================================================
  // Write
  // ===========================================================================
  logic             w_act_q;            // a write is live, from AWVALID to B
  logic [SEL_W-1:0] w_sel_q;
  logic             aw_done_q, w_done_q;
  logic             w_err_q;            // DECERR response being offered

  logic [SEL_W-1:0] w_sel;
  logic             w_hit, aw_fwd, w_fwd;

  assign w_sel  = w_act_q ? w_sel_q : s_axi_awaddr[SEL_LSB +: SEL_W];
  assign w_hit  = (int'(w_sel) < NUM_M);
  assign aw_fwd = s_axi_awvalid && !aw_done_q;
  assign w_fwd  = s_axi_wvalid  && !w_done_q && (w_act_q || s_axi_awvalid);

  always_comb begin
    m_axi_awvalid = '0;
    m_axi_wvalid  = '0;
    m_axi_bready  = '0;
    if (w_hit) begin
      m_axi_awvalid[w_sel] = aw_fwd;
      m_axi_wvalid[w_sel]  = w_fwd;
      m_axi_bready[w_sel]  = w_act_q && s_axi_bready;
      s_axi_awready        = aw_fwd && m_axi_awready[w_sel];
      s_axi_wready         = w_fwd  && m_axi_wready[w_sel];
      s_axi_bvalid         = w_act_q && m_axi_bvalid[w_sel];
      s_axi_bresp          = m_axi_bresp[w_sel];
    end else begin
      s_axi_awready        = aw_fwd;
      s_axi_wready         = w_fwd;
      s_axi_bvalid         = w_err_q;
      s_axi_bresp          = RESP_DECERR;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      w_act_q   <= 1'b0;
      w_sel_q   <= '0;
      aw_done_q <= 1'b0;
      w_done_q  <= 1'b0;
      w_err_q   <= 1'b0;
    end else begin
      if (!w_act_q && s_axi_awvalid) begin
        w_act_q <= 1'b1;
        w_sel_q <= s_axi_awaddr[SEL_LSB +: SEL_W];
      end
      if (s_axi_awvalid && s_axi_awready) aw_done_q <= 1'b1;
      if (s_axi_wvalid  && s_axi_wready ) w_done_q  <= 1'b1;
      // An unmapped write is answered once both halves have been taken.
      if (w_act_q && !w_hit && aw_done_q && w_done_q) w_err_q <= 1'b1;
      if (s_axi_bvalid && s_axi_bready) begin
        w_act_q   <= 1'b0;
        aw_done_q <= 1'b0;
        w_done_q  <= 1'b0;
        w_err_q   <= 1'b0;
      end
    end
  end

  // ===========================================================================
  // Read
  // ===========================================================================
  logic             r_act_q;
  logic [SEL_W-1:0] r_sel_q;
  logic             ar_done_q;
  logic             r_err_q;

  logic [SEL_W-1:0] r_sel;
  logic             r_hit, ar_fwd;

  assign r_sel  = r_act_q ? r_sel_q : s_axi_araddr[SEL_LSB +: SEL_W];
  assign r_hit  = (int'(r_sel) < NUM_M);
  assign ar_fwd = s_axi_arvalid && !ar_done_q;

  always_comb begin
    m_axi_arvalid = '0;
    m_axi_rready  = '0;
    if (r_hit) begin
      m_axi_arvalid[r_sel] = ar_fwd;
      m_axi_rready[r_sel]  = r_act_q && s_axi_rready;
      s_axi_arready        = ar_fwd && m_axi_arready[r_sel];
      s_axi_rvalid         = r_act_q && m_axi_rvalid[r_sel];
      s_axi_rdata          = m_axi_rdata[r_sel];
      s_axi_rresp          = m_axi_rresp[r_sel];
    end else begin
      s_axi_arready        = ar_fwd;
      s_axi_rvalid         = r_err_q;
      s_axi_rdata          = 32'h0000_0000;
      s_axi_rresp          = RESP_DECERR;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      r_act_q   <= 1'b0;
      r_sel_q   <= '0;
      ar_done_q <= 1'b0;
      r_err_q   <= 1'b0;
    end else begin
      if (!r_act_q && s_axi_arvalid) begin
        r_act_q <= 1'b1;
        r_sel_q <= s_axi_araddr[SEL_LSB +: SEL_W];
      end
      if (s_axi_arvalid && s_axi_arready) ar_done_q <= 1'b1;
      if (r_act_q && !r_hit && ar_done_q) r_err_q <= 1'b1;
      if (s_axi_rvalid && s_axi_rready) begin
        r_act_q   <= 1'b0;
        ar_done_q <= 1'b0;
        r_err_q   <= 1'b0;
      end
    end
  end

endmodule
