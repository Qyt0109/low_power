`timescale 1ns/1ps
// The SCP's watchdog: a counter, a kick register and a reset request for the
// SCP subsystem alone. Glue, written here: no open-source watchdog fits Ibex's
// bus.sv protocol (platform plan H18; Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md
// Sections 14.7 and 15.2 phase 4).
//
// References: src/pmu/README.md Section 2.1 (the map) and 2.3; scp_top.sv,
// which applies the reset; src/pmu/fw/hal/scp_wdog.h (the firmware's side,
// which must agree with the register map below).
//
//   EN ──► COUNT: loaded with TIMEOUT on enable and on a good kick, then down
//          by one a cycle; 0 while EN ──┐
//   KICK write != KEY while EN ─────────┤ trigger
//                                       ▼
//   ┌─ por_ni domain ────────────────────────────────────────────────────┐
//   │ CAUSE |= WDOG (+ BADKICK); RESETS++                                │
//   │ DRAIN: hold_o = 1 (no new AXI transaction), until axi_idle_i or    │
//   │        DRAIN_MAX cycles (then CAUSE |= DRAINTO)                    │
//   │ RESET: rst_req_o = 1 for RST_CYCLES cycles                         │
//   └────────────────────────────────────────────────────────────────────┘
//
// TWO RESETS. rst_ni is the SCP subsystem's reset -- which includes this
// block's own rst_req_o, through scp_top -- and clears CTRL, TIMEOUT and
// COUNT: after a watchdog reset the watchdog is off until the firmware arms it
// again. por_ni is the power-on reset alone and clears what must outlive a
// watchdog reset: CAUSE, the reset count and the reset sequencer. So the
// firmware that boots after the reset can read why it did.
//
// WHY THE DRAIN. The PPUs are always-on and are not reset (scp_top.sv). Their
// AXI4-Lite subordinates keep any transaction the SCP's manager had begun: a
// reset in the middle of one would leave a response that the rebooted manager
// takes for the answer to its first new request (an AW without its W, a B or
// R nobody waits for). So the reset waits until the manager is idle, with new
// requests held off. A PPU that never answers would stop the drain for ever,
// so it gives up after DRAIN_MAX cycles and says so in CAUSE.DRAINTO.
//
// THE REGISTERS. A bus.sv device: it answers exactly one cycle after the
// request and cannot stall. Any other offset answers err. Writes to read-only
// registers are ignored.
//
//   off   name     access  reset         fields
//   0x00  CTRL     RW      0 (rst_ni)    [0] EN: count, and expire at 0.
//                                        [1] LOCK: write 1 to set; cleared
//                                        only by a reset. While LOCK is 1,
//                                        writes to CTRL and TIMEOUT are
//                                        ignored, so EN cannot be cleared
//   0x04  TIMEOUT  RW      '1 (rst_ni)   the value COUNT is loaded with
//   0x08  KICK     WO                    KEY (a full-word write) loads COUNT
//                                        with TIMEOUT. Any other value or a
//                                        partial write, while EN, is a fault:
//                                        an immediate reset, CAUSE.BADKICK.
//                                        While EN = 0, writes do nothing.
//                                        Reads 0
//   0x0C  COUNT    RO      0 (rst_ni)    cycles left
//   0x10  CAUSE    R/W1C   (por_ni)      [0] POR: set by the power-on reset
//                                        [1] WDOG: the watchdog reset the SCP
//                                        [2] BADKICK: ...for a wrong kick
//                                        [3] DRAINTO: ...with an AXI transaction
//                                            still outstanding
//                                        [15:8] RESETS (RO): watchdog resets
//                                            since power-on, saturating at 255
//                                        Writing 1 clears a bit of [3:0]; a
//                                        trigger in the same cycle wins
//
// Enabling (EN 0 -> 1) loads COUNT, as a kick does. Clearing EN (unlocked)
// stops COUNT where it is. TIMEOUT = 0 expires at once.

module scp_wdog #(
  parameter logic [31:0] KEY        = 32'h4B49_434B,   // "KICK"
  parameter int unsigned RST_CYCLES = 16,              // length of the reset
  parameter int unsigned DRAIN_MAX  = 1024             // longest wait for the AXI manager
) (
  input  logic        clk_i,
  input  logic        por_ni,       // power-on reset only
  input  logic        rst_ni,       // the SCP subsystem's reset

  // ---- bus.sv device port ----
  input  logic        req_i,
  input  logic        we_i,
  input  logic [3:0]  be_i,
  input  logic [31:0] addr_i,
  input  logic [31:0] wdata_i,
  output logic        rvalid_o,
  output logic [31:0] rdata_o,
  output logic        err_o,

  // ---- The reset ----
  input  logic        axi_idle_i,   // the SCP's AXI manager has nothing outstanding
  output logic        hold_o,       // hold off new AXI transactions
  output logic        rst_req_o     // reset the SCP subsystem (registered)
);

  if (RST_CYCLES < 2 || RST_CYCLES > 255) begin : g_bad_rst
    $error("scp_wdog: RST_CYCLES = %0d; 2..255", RST_CYCLES);
  end
  if (DRAIN_MAX < 1 || DRAIN_MAX > 65535) begin : g_bad_drain
    $error("scp_wdog: DRAIN_MAX = %0d; 1..65535", DRAIN_MAX);
  end

  localparam logic [11:0] R_CTRL    = 12'h000;
  localparam logic [11:0] R_TIMEOUT = 12'h004;
  localparam logic [11:0] R_KICK    = 12'h008;
  localparam logic [11:0] R_COUNT   = 12'h00C;
  localparam logic [11:0] R_CAUSE   = 12'h010;

  logic [11:0] off;
  assign off = {addr_i[11:2], 2'b00};

  logic wr, rd;
  assign wr = req_i &&  we_i;
  assign rd = req_i && !we_i;

  // ===========================================================================
  // The counter (rst_ni): the only writer of en_q, lock_q, tmo_q, cnt_q and the
  // read port
  // ===========================================================================
  logic        en_q, lock_q;
  logic [31:0] tmo_q, cnt_q;
  logic        kick_wr, kick_ok, bad_kick, expire;

  assign kick_wr  = wr && off == R_KICK;
  assign kick_ok  = kick_wr && be_i == 4'hF && wdata_i == KEY;
  assign bad_kick = kick_wr && en_q && !kick_ok;
  assign expire   = en_q && cnt_q == '0;

  logic [31:0] bmask;
  assign bmask = {{8{be_i[3]}}, {8{be_i[2]}}, {8{be_i[1]}}, {8{be_i[0]}}};

  logic [7:0]  resets_q;
  logic [3:0]  cause_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      en_q     <= 1'b0;
      lock_q   <= 1'b0;
      tmo_q    <= '1;
      cnt_q    <= '0;
      rvalid_o <= 1'b0;
      rdata_o  <= '0;
      err_o    <= 1'b0;
    end else begin
      // The count: down while enabled; reloaded on enable and on a good kick
      if (en_q && cnt_q != '0) cnt_q <= cnt_q - 32'd1;
      if (en_q && kick_ok)     cnt_q <= tmo_q;

      rvalid_o <= req_i;
      err_o    <= 1'b0;
      rdata_o  <= '0;
      if (req_i) begin
        unique case (off)
          R_CTRL: begin
            if (we_i) begin
              if (!lock_q && be_i[0]) begin
                en_q <= wdata_i[0];
                if (wdata_i[0] && !en_q) cnt_q <= tmo_q;
                if (wdata_i[1]) lock_q <= 1'b1;
              end
            end else begin
              rdata_o <= {30'd0, lock_q, en_q};
            end
          end
          R_TIMEOUT: begin
            if (we_i) begin
              if (!lock_q) tmo_q <= (tmo_q & ~bmask) | (wdata_i & bmask);
            end else begin
              rdata_o <= tmo_q;
            end
          end
          R_KICK:  ;                                  // reads 0; the write is above
          R_COUNT: if (!we_i) rdata_o <= cnt_q;
          R_CAUSE: if (!we_i) rdata_o <= {16'd0, resets_q, 4'd0, cause_q};
          default: err_o <= 1'b1;
        endcase
      end
    end
  end

  // ===========================================================================
  // The cause and the reset sequencer (por_ni): the only writer of cause_q,
  // resets_q, the sequencer, hold_o and rst_req_o
  // ===========================================================================
  typedef enum logic [1:0] {S_IDLE, S_DRAIN, S_RESET} seq_e;
  seq_e        seq_q;
  logic [15:0] seq_cnt_q;
  logic        trig;
  logic [3:0]  w1c;

  assign trig = (seq_q == S_IDLE) && (expire || bad_kick);
  assign w1c  = (wr && off == R_CAUSE && be_i[0]) ? wdata_i[3:0] : 4'd0;

`ifdef SOC4_MUT_WDOG_CAUSE_SUB
  // NEGATIVE CONTROL (soc4neg M8): CAUSE and the reset count on the SCP
  // subsystem's reset, so the watchdog's own reset clears them and the
  // firmware cannot tell why it restarted. soc4bfm's W1 must fail.
  logic cause_rst_n;
  assign cause_rst_n = rst_ni;
`else
  logic cause_rst_n;
  assign cause_rst_n = por_ni;
`endif

  always_ff @(posedge clk_i or negedge cause_rst_n) begin
    if (!cause_rst_n) begin
      cause_q  <= 4'b0001;                          // POR
      resets_q <= '0;
    end else begin
      cause_q <= cause_q & ~w1c;
      if (trig) begin
        cause_q[1] <= 1'b1;                         // WDOG
        if (bad_kick) cause_q[2] <= 1'b1;           // BADKICK
        if (resets_q != 8'hFF) resets_q <= resets_q + 8'd1;
      end
      if (seq_q == S_DRAIN && !axi_idle_i && seq_cnt_q == 16'(DRAIN_MAX - 1))
        cause_q[3] <= 1'b1;                         // DRAINTO
    end
  end

  always_ff @(posedge clk_i or negedge por_ni) begin
    if (!por_ni) begin
      seq_q     <= S_IDLE;
      seq_cnt_q <= '0;
      hold_o    <= 1'b0;
      rst_req_o <= 1'b0;
    end else begin
      unique case (seq_q)
        S_IDLE: if (trig) begin
          seq_q     <= S_DRAIN;
          seq_cnt_q <= '0;
          hold_o    <= 1'b1;
        end
        S_DRAIN: begin
          if (axi_idle_i || seq_cnt_q == 16'(DRAIN_MAX - 1)) begin
            seq_q     <= S_RESET;
            seq_cnt_q <= 16'(RST_CYCLES - 1);
            rst_req_o <= 1'b1;
          end else begin
            seq_cnt_q <= seq_cnt_q + 16'd1;
          end
        end
        S_RESET: begin
          if (seq_cnt_q == '0) begin
            seq_q     <= S_IDLE;
            hold_o    <= 1'b0;
            rst_req_o <= 1'b0;
          end else begin
            seq_cnt_q <= seq_cnt_q - 16'd1;
          end
        end
        default: seq_q <= S_IDLE;
      endcase
    end
  end

  // scp_top's bus.sv has already matched [31:12]; [1:0] are the byte lanes.
  logic unused_addr;
  assign unused_addr = ^{addr_i[31:12], addr_i[1:0]};

endmodule
