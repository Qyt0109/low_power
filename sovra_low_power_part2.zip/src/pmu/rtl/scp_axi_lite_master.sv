`timescale 1ns/1ps
// The SCP core's load/store port, as an AXI4-Lite manager.
//
// References: Ibex doc/03_reference/load_store_unit.rst for the upstream side;
// AMBA AXI and ACE Protocol Specification (ARM IHI 0022) Sections A3.2.1 and
// A3.3.1, and Chapter B for AXI4-Lite. IHI 0022 is not in references/standards,
// so as in tb/ppu/ppu_axi_lite_tb.sv its clauses are paraphrased, not quoted.
//
// ONE TRANSACTION AT A TIME
//
// The request is granted in the cycle it arrives, if the bridge is idle, and the
// core then waits for the response like any other. The next request is not
// granted until that response has been returned. Ibex allows a second access
// in flight (the other half of a misaligned one), but the PPU register file is
// word-aligned and serialising costs nothing a firmware driver would notice,
// while keeping the bridge trivially in order.
//
// THE THREE AXI RULES THIS FOLLOWS
//
//   1. VALID never waits for READY. AWVALID and WVALID are both raised in the
//      cycle after the grant and each is held, with its payload, until its own
//      handshake. The PPU's adapter accepts AW only when AWVALID and WVALID are
//      both high (ppu_axi_lite_adapter.sv), so presenting them together is not
//      a nicety -- withholding W until AW completed would deadlock.
//   2. Payload is registered. Nothing on the AXI side is a combinational
//      function of the core's port, which may change the cycle after the grant.
//   3. Every response is honoured. OKAY completes the access; SLVERR or DECERR
//      completes it with data_err_o, which Ibex turns into a load or store
//      access fault (mcause 5 or 7). The PPU adapter's own SLVERR -- its clock
//      never arrived -- therefore reaches the firmware as an exception.
//
// PROT
//
// Ibex runs everything in M-mode, and the SCP is the system's trusted agent
// (PCSA 3.2.2), so every access is marked privileged, secure, data: 3'b001.
// The PPU ignores AxPROT (ppu_axi_lite_adapter.sv, "NO PROT FILTERING"); a
// firewall in front of it would not.

module scp_axi_lite_master #(
  parameter int unsigned AW = 32
) (
  input  logic          clk_i,
  input  logic          rst_ni,

  // ---- Ibex-protocol device port ----
  input  logic          req_i,
  output logic          gnt_o,
  input  logic          we_i,
  input  logic [3:0]    be_i,
  input  logic [31:0]   addr_i,
  input  logic [31:0]   wdata_i,
  output logic          rvalid_o,
  output logic [31:0]   rdata_o,
  output logic          err_o,

  // ---- AXI4-Lite manager ----
  output logic [AW-1:0] m_axi_awaddr,
  output logic [2:0]    m_axi_awprot,
  output logic          m_axi_awvalid,
  input  logic          m_axi_awready,
  output logic [31:0]   m_axi_wdata,
  output logic [3:0]    m_axi_wstrb,
  output logic          m_axi_wvalid,
  input  logic          m_axi_wready,
  input  logic [1:0]    m_axi_bresp,
  input  logic          m_axi_bvalid,
  output logic          m_axi_bready,
  output logic [AW-1:0] m_axi_araddr,
  output logic [2:0]    m_axi_arprot,
  output logic          m_axi_arvalid,
  input  logic          m_axi_arready,
  input  logic [31:0]   m_axi_rdata,
  input  logic [1:0]    m_axi_rresp,
  input  logic          m_axi_rvalid,
  output logic          m_axi_rready
);

  localparam logic [2:0] PROT = 3'b001;   // privileged, secure, data

  typedef enum logic [1:0] {IDLE, WRITE, READ} state_e;
  state_e state_q;

  logic [AW-1:0] addr_q;
  logic [31:0]   wdata_q;
  logic [3:0]    be_q;
  logic          aw_pend_q, w_pend_q, ar_pend_q;
  logic          rvalid_q, err_q;
  logic [31:0]   rdata_q;

  assign gnt_o = req_i && (state_q == IDLE);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q   <= IDLE;
      addr_q    <= '0;
      wdata_q   <= '0;
      be_q      <= '0;
      aw_pend_q <= 1'b0;
      w_pend_q  <= 1'b0;
      ar_pend_q <= 1'b0;
      rvalid_q  <= 1'b0;
      err_q     <= 1'b0;
      rdata_q   <= '0;
    end else begin
      rvalid_q <= 1'b0;
      unique case (state_q)
        IDLE: begin
          if (req_i) begin
            addr_q  <= addr_i[AW-1:0];
            wdata_q <= wdata_i;
            be_q    <= be_i;
            if (we_i) begin
              state_q   <= WRITE;
              aw_pend_q <= 1'b1;
              w_pend_q  <= 1'b1;
            end else begin
              state_q   <= READ;
              ar_pend_q <= 1'b1;
            end
          end
        end

        WRITE: begin
          if (m_axi_awvalid && m_axi_awready) aw_pend_q <= 1'b0;
          if (m_axi_wvalid  && m_axi_wready ) w_pend_q  <= 1'b0;
          if (m_axi_bvalid  && m_axi_bready ) begin
            state_q  <= IDLE;
            rvalid_q <= 1'b1;
            err_q    <= (m_axi_bresp != 2'b00);
            rdata_q  <= '0;
          end
        end

        READ: begin
          if (m_axi_arvalid && m_axi_arready) ar_pend_q <= 1'b0;
          if (m_axi_rvalid  && m_axi_rready ) begin
            state_q  <= IDLE;
            rvalid_q <= 1'b1;
            err_q    <= (m_axi_rresp != 2'b00);
            rdata_q  <= m_axi_rdata;
          end
        end

        default: state_q <= IDLE;
      endcase
    end
  end

  assign m_axi_awaddr  = addr_q;
  assign m_axi_awprot  = PROT;
  assign m_axi_awvalid = (state_q == WRITE) && aw_pend_q;
  assign m_axi_wdata   = wdata_q;
  assign m_axi_wstrb   = be_q;
  assign m_axi_wvalid  = (state_q == WRITE) && w_pend_q;
  assign m_axi_bready  = (state_q == WRITE);

  assign m_axi_araddr  = addr_q;
  assign m_axi_arprot  = PROT;
  assign m_axi_arvalid = (state_q == READ) && ar_pend_q;
  assign m_axi_rready  = (state_q == READ);

  // rvalid is a register, so the response is never in the cycle of the grant --
  // Ibex requires "one or more cycles after the grant".
  assign rvalid_o = rvalid_q;
  assign rdata_o  = rdata_q;
  assign err_o    = err_q;

endmodule
