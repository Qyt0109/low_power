`timescale 1ns/1ps
// The SCP's private RAM: code and data in one array, with two ports.
//
// References: Arm Power Control System Architecture (ARM DEN 0050D) Section
// 6.4.1, "SCP Processor Core Memory": "The SCP firmware code and data spaces
// are entirely within its private RAM." Ibex doc/03_reference
// load_store_unit.rst and instruction_fetch.rst for the port protocol.
//
//   port A  loads and stores, behind Ibex's bus.sv (scp_top)
//   port B  instruction fetch, straight from the core
//
// Both ports use the simplest timing Ibex's protocol allows: a request is
// granted in the cycle it is made and answered exactly one cycle later. That is
// also the only timing bus.sv supports ("All devices (slaves) must respond in
// the next cycle after the request"), so port A could not do otherwise.
//
// A FETCH OUTSIDE THE ARRAY IS AN ERROR, NOT AN ALIAS
//
// Port B indexes the array with the low address bits. Without a range check, a
// jump to 0x4000_0000 would execute whatever sits at 0x0000_0000 -- the vector
// table -- and the firmware would appear to reset. b_err_o turns that into an
// instruction access fault the trap handler reports. Port A needs no such check:
// bus.sv only routes addresses inside this array's window to it.
//
// SIMULATION IMAGE
//
// The array is zeroed at time 0 and then loaded from +firmware=<file.vmem>, a
// $readmemh image of 32-bit words (src/pmu/fw/bin2vmem.py). IMAGE_PLUSARG
// names the plusarg, so that two instances in one simulation (soc4's SCP and
// AP, SOC4_DESIGN.md Section 6.3) load two images. Zeroing is not
// cosmetic: Ibex prefetches past the end of the code, and an X fetched there
// trips Ibex's own known-value assertions even though the word is never
// executed. Silicon RAM has random contents; the firmware never reads a word it
// has not written or loaded, and .bss is cleared by crt0.S.

module scp_ram #(
  parameter int unsigned DEPTH         = 16384,       // 32-bit words: 64 KB
  parameter string       IMAGE_PLUSARG = "firmware"   // +<IMAGE_PLUSARG>=<file.vmem>
) (
  input  logic        clk_i,
  input  logic        rst_ni,

  // ---- Port A: loads and stores. bus.sv grants on its own side ----
  input  logic        a_req_i,
  input  logic        a_we_i,
  input  logic [3:0]  a_be_i,
  input  logic [31:0] a_addr_i,
  input  logic [31:0] a_wdata_i,
  output logic        a_rvalid_o,
  output logic [31:0] a_rdata_o,

  // ---- Port B: instruction fetch ----
  input  logic        b_req_i,
  output logic        b_gnt_o,
  input  logic [31:0] b_addr_i,
  output logic        b_rvalid_o,
  output logic [31:0] b_rdata_o,
  output logic        b_err_o
);

  localparam int unsigned IW = $clog2(DEPTH);

  logic [31:0] mem [DEPTH];

  logic [IW-1:0] a_idx, b_idx;
  assign a_idx = a_addr_i[IW+1:2];
  assign b_idx = b_addr_i[IW+1:2];

  // Any address bit above the array is a fetch from somewhere else.
  logic b_outside;
  assign b_outside = |b_addr_i[31:IW+2];

  assign b_gnt_o = b_req_i;

  // The array. A plain always, not always_ff: the initial block below also
  // writes it, and always_ff forbids a second writer.
  always @(posedge clk_i) begin
    if (a_req_i && a_we_i) begin
      for (int i = 0; i < 4; i++)
        if (a_be_i[i]) mem[a_idx][8*i +: 8] <= a_wdata_i[8*i +: 8];
    end
    // Read-before-write on a store; Ibex ignores rdata for stores.
    if (a_req_i) a_rdata_o <= mem[a_idx];
    if (b_req_i) b_rdata_o <= mem[b_idx];
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      a_rvalid_o <= 1'b0;
      b_rvalid_o <= 1'b0;
      b_err_o    <= 1'b0;
    end else begin
      a_rvalid_o <= a_req_i;
      b_rvalid_o <= b_req_i;
      b_err_o    <= b_req_i && b_outside;
    end
  end

`ifndef SYNTHESIS
  initial begin : load
    string path;
    for (int i = 0; i < DEPTH; i++) mem[i] = 32'h0000_0000;
    if ($value$plusargs({IMAGE_PLUSARG, "=%s"}, path)) begin
      $readmemh(path, mem);
      $display("[scp_ram] loaded %s", path);
    end else begin
      $display("[scp_ram] WARNING: no +%s=<image.vmem>; the RAM is all zero", IMAGE_PLUSARG);
    end
  end
`endif

endmodule
