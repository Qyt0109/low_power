`timescale 1ns/1ps
// The System Control Processor subsystem: core, private memory, private bus,
// and the AXI4-Lite path to the PPUs.
//
// References: Arm Power Control System Architecture (ARM DEN 0050D) Sections
// 3.2, 3.2.2 and 6.4 (Figure 6.2 is the shape of this module); src/pmu/README.md
// Section 2 for the memory map and the interrupt map, which this file and
// src/pmu/fw/hal/scp_regs.h must agree on.
//
//  ┌──────────────────────────────── scp_top ─────────────────────────────────┐
//  │                                                                          │
//  │  scp_core ──instr──────────────────────────────► scp_ram port B          │
//  │  (Ibex)   ──data──► u_split ──local──► bus ──┬─► scp_ram port A          │
//  │     ▲                  │                     ├─► timer                   │
//  │     │ irq_timer ◄──────┼─────────────────────┤   ext_*  (port)           │
//  │     │                  │                     ├─► u_irq (scp_irq)         │
//  │     │                  │                     └─► u_wdog (scp_wdog) ──┐   │
//  │     │ irq_external ◄───┼───────────────────────── u_irq ◄── irq_i[]  │   │
//  │     │                  │   rst_sub_n = rst_ni & ~u_wdog.rst_req ◄────┘   │
//  │     │                  │   (every block here but u_wdog's POR half)      │
//  │     │                  └──axi──► scp_axi_lite_master                     │
//  │     │                                     │                              │
//  │     │                              scp_axi_lite_demux ──► m_axi[NUM_PPU] │
//  │     └── irq_fast: tied LOW, unused                                       │
//  └──────────────────────────────────────────────────────────────────────────┘
//
// MEMORY MAP (src/pmu/README.md Section 2.1)
//
//   0x0000_0000  64 KB   scp_ram      vector table at 0, reset vector at 0x80
//   0x0001_0000   1 KB   timer        mtime / mtimecmp
//   0x0001_1000   4 KB   u_irq        the interrupt status/enable block
//                                     (scp_irq.sv has the registers)
//   0x0001_2000   4 KB   u_wdog       the watchdog (scp_wdog.sv has the
//                                     registers)
//   0x0002_0000  64 KB   ext_*        a port, for devices outside this module:
//                                     in soc4 the top level's window (the
//                                     RPMI mailbox, soc4_ctrl, the CPU load
//                                     ports and the testbench's simulation
//                                     control; SOC4_DESIGN.md Section 4.2)
//   0x4000_0000  64 KB   PPUs         PPU n at 0x4000_0000 + n * 0x1000
//
// Everything else is unmapped: bus.sv answers it with an error, the core takes
// a load or store access fault. Inside the PPU window, indices NUM_PPU..15 are
// answered DECERR by the demux, with the same result.
//
// PCSA 3.2.2's trust boundary is this map. Nothing outside this module can
// address the RAM, the timer, the interrupt block, the watchdog or the PPU
// windows. ext_* is
// a port this module drives, not one it answers. The AP's RPMI mailbox is not
// in this module: the top level hangs it on ext_* (soc4_mbx, TL-UL, with its
// own firewall), and its doorbell comes back as one of the irq_i inputs.
//
// THE ext_* PORT
//
// bus.sv's protocol, unchanged: req/we/be/addr/wdata out, and the device must
// answer with rvalid (and rdata/err) exactly one cycle after req. It exists so
// that the top level can hang its devices -- the RPMI mailbox, the CPU load
// ports, a testbench's simulation-control device -- on the SCP's bus without
// this module containing anything that is not synthesizable.
//
// INTERRUPTS (platform plan H7, Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md
// Section 14.7)
//
//   irq_timer_i      the timer
//   irq_external_i   u_irq's line: EVERY other source, through the generic
//                    input bank (scp_irq.sv) -- each PPU's interrupt, the
//                    mailbox doorbell, the SoC PLIC's output and per-hart
//                    pending signals, the raw wake lines. Not a PLIC (PD1)
//   irq_fast_i       tied LOW: no source uses a fast line any more, so the
//                    number of sources is not bounded by Ibex's 15
//   irq_nm_i         tied LOW: the watchdog has no pre-timeout interrupt
//
// irq_i[i] is the block's input i. The top level wires the list, in the order
// the firmware's input table (the platform header's SCP_PLAT_INPUTS) gives it:
// adding a source is one wire here and one table entry there. IRQ_ASYNC[i]
// says whether input i comes from another clock and must be synchronised.
//
// THE WATCHDOG AND THE TWO RESETS (platform plan H18; scp_wdog.sv)
//
//   por_ni   the power-on reset: u_wdog's CAUSE, its reset count and its reset
//            sequencer, and nothing else
//   rst_ni   the SCP subsystem's reset from outside (soc4: the system reset
//            AND the testbench's SCP hold)
//
// Every block of this module runs on rst_sub_n = rst_ni & ~(the watchdog's
// reset request), and rst_sub_no hands the same reset to the SCP-side logic
// of the top level (soc4: its ext window's bus.sv). On expiry the watchdog
// first holds off new AXI transactions and waits for the AXI4-Lite manager
// to go idle, then resets the subsystem for RST_CYCLES cycles: the core, its
// RAM ports, the timer, the interrupt block, the bus, the bridge and the demux.
// The RAM array keeps its contents (it is not reloaded; the firmware's crt0
// re-initialises .data from its load copy). The PPUs, the PCSMs, the power
// domains and everything else on the top level's own reset are untouched.
//
// Until 2026-10-02 this module could also hold an AXI4-Lite RPMI mailbox of
// its own (parameter RPMI_MBOX, for the retired 12-domain top); that path was
// removed with it (SOC4_DESIGN.md Section 12).
module scp_top #(
  parameter int unsigned NUM_PPU   = 1,    // PPU slots, 1..16; the platform sets it (soc4_top: 4)
  parameter int unsigned NUM_IRQ   = NUM_PPU + 1,   // inputs of the interrupt block
  parameter logic [31:0] IRQ_ASYNC = '0,            // bit i: irq_i[i] is asynchronous
  parameter logic [31:0] BOOT_ADDR = 32'h0000_0000
) (
  input  logic clk_i,
  input  logic por_ni,              // power-on reset: the watchdog's CAUSE only
  input  logic rst_ni,              // the SCP subsystem's reset
  input  logic fetch_enable_i,
  output logic rst_sub_no,          // rst_ni and the watchdog's reset, as applied here
  output logic wdog_rst_o,          // the watchdog's reset request alone (for the SoC to see)

  // ---- 0x0002_0000: devices outside the subsystem, bus.sv protocol ----
  output logic        ext_req_o,
  output logic        ext_we_o,
  output logic [3:0]  ext_be_o,
  output logic [31:0] ext_addr_o,
  output logic [31:0] ext_wdata_o,
  input  logic        ext_rvalid_i,
  input  logic [31:0] ext_rdata_i,
  input  logic        ext_err_i,

  // ---- 0x4000_0000: one AXI4-Lite manager port per PPU ----
  output logic [NUM_PPU-1:0][31:0] m_axi_awaddr,
  output logic [NUM_PPU-1:0][2:0]  m_axi_awprot,
  output logic [NUM_PPU-1:0]       m_axi_awvalid,
  input  logic [NUM_PPU-1:0]       m_axi_awready,
  output logic [NUM_PPU-1:0][31:0] m_axi_wdata,
  output logic [NUM_PPU-1:0][3:0]  m_axi_wstrb,
  output logic [NUM_PPU-1:0]       m_axi_wvalid,
  input  logic [NUM_PPU-1:0]       m_axi_wready,
  input  logic [NUM_PPU-1:0][1:0]  m_axi_bresp,
  input  logic [NUM_PPU-1:0]       m_axi_bvalid,
  output logic [NUM_PPU-1:0]       m_axi_bready,
  output logic [NUM_PPU-1:0][31:0] m_axi_araddr,
  output logic [NUM_PPU-1:0][2:0]  m_axi_arprot,
  output logic [NUM_PPU-1:0]       m_axi_arvalid,
  input  logic [NUM_PPU-1:0]       m_axi_arready,
  input  logic [NUM_PPU-1:0][31:0] m_axi_rdata,
  input  logic [NUM_PPU-1:0][1:0]  m_axi_rresp,
  input  logic [NUM_PPU-1:0]       m_axi_rvalid,
  output logic [NUM_PPU-1:0]       m_axi_rready,

  // ---- Every interrupt source, one input each of u_irq (scp_irq.sv) ----
  input  logic [NUM_IRQ-1:0] irq_i,

  // ---- HIGH while the core waits in WFI ----
  output logic core_sleep_o
);

  if (NUM_PPU < 1 || NUM_PPU > 16) begin : g_bad_num_ppu
    $error("scp_top: NUM_PPU = %0d; the demux decodes 16 PPU slots", NUM_PPU);
  end

  // ---- The map, once ----
  localparam logic [31:0] RAM_BASE   = 32'h0000_0000;
  localparam logic [31:0] RAM_MASK   = 32'hFFFF_0000;
  localparam logic [31:0] TIMER_BASE = 32'h0001_0000;
  localparam logic [31:0] TIMER_MASK = 32'hFFFF_FC00;
  localparam logic [31:0] IRQ_BASE   = 32'h0001_1000;
  localparam logic [31:0] IRQ_MASK   = 32'hFFFF_F000;
  localparam logic [31:0] WDOG_BASE  = 32'h0001_2000;
  localparam logic [31:0] WDOG_MASK  = 32'hFFFF_F000;
  localparam logic [31:0] EXT_BASE   = 32'h0002_0000;
  localparam logic [31:0] EXT_MASK   = 32'hFFFF_0000;
  localparam logic [31:0] AXI_BASE   = 32'h4000_0000;
  localparam logic [31:0] AXI_MASK   = 32'hFFFF_0000;

  localparam int unsigned NrDevices  = 5;
  localparam int unsigned DevRam     = 0;
  localparam int unsigned DevTimer   = 1;
  localparam int unsigned DevExt     = 2;
  localparam int unsigned DevIrq     = 3;
  localparam int unsigned DevWdog    = 4;

  // ===========================================================================
  // The subsystem's reset: the outside's, and the watchdog's
  // ===========================================================================
  logic wd_rst_req, wd_hold, axi_idle, rst_sub_n;
  assign rst_sub_n  = rst_ni & ~wd_rst_req;
  assign rst_sub_no = rst_sub_n;
  assign wdog_rst_o = wd_rst_req;

  // ===========================================================================
  // Core
  // ===========================================================================
  logic        instr_req, instr_gnt, instr_rvalid, instr_err;
  logic [31:0] instr_addr, instr_rdata;

  logic        core_req, core_gnt, core_rvalid, core_we, core_err;
  logic [3:0]  core_be;
  logic [31:0] core_addr, core_wdata, core_rdata;

  logic        irq_timer, irq_ext;
  logic [14:0] irq_fast;

  assign irq_fast = '0;

  scp_core u_core (
    .clk_i         (clk_i),
    .rst_ni        (rst_sub_n),

    .boot_addr_i   (BOOT_ADDR),

    .instr_req_o   (instr_req),
    .instr_gnt_i   (instr_gnt),
    .instr_rvalid_i(instr_rvalid),
    .instr_addr_o  (instr_addr),
    .instr_rdata_i (instr_rdata),
    .instr_err_i   (instr_err),

    .data_req_o    (core_req),
    .data_gnt_i    (core_gnt),
    .data_rvalid_i (core_rvalid),
    .data_we_o     (core_we),
    .data_be_o     (core_be),
    .data_addr_o   (core_addr),
    .data_wdata_o  (core_wdata),
    .data_rdata_i  (core_rdata),
    .data_err_i    (core_err),

    .irq_timer_i   (irq_timer),
    .irq_external_i(irq_ext),
    .irq_fast_i    (irq_fast),
    .irq_nm_i      (1'b0),

    .fetch_enable_i(fetch_enable_i),
    .core_sleep_o  (core_sleep_o)
  );

  // ===========================================================================
  // Split: the PPUs' AXI window off, the rest to bus.sv
  // ===========================================================================
  logic        bus_req, bus_gnt, bus_rvalid, bus_we, bus_err;
  logic [3:0]  bus_be;
  logic [31:0] bus_addr, bus_wdata, bus_rdata;

  logic        axi_req, axi_gnt, axi_rvalid, axi_we, axi_err;
  logic [3:0]  axi_be;
  logic [31:0] axi_addr, axi_wdata, axi_rdata;

  scp_data_split #(.AXI_BASE(AXI_BASE), .AXI_MASK(AXI_MASK)) u_split (
    .clk_i        (clk_i),
    .rst_ni       (rst_sub_n),

    .data_req_i   (core_req),
    .data_gnt_o   (core_gnt),
    .data_rvalid_o(core_rvalid),
    .data_we_i    (core_we),
    .data_be_i    (core_be),
    .data_addr_i  (core_addr),
    .data_wdata_i (core_wdata),
    .data_rdata_o (core_rdata),
    .data_err_o   (core_err),

    .loc_req_o    (bus_req),
    .loc_gnt_i    (bus_gnt),
    .loc_rvalid_i (bus_rvalid),
    .loc_we_o     (bus_we),
    .loc_be_o     (bus_be),
    .loc_addr_o   (bus_addr),
    .loc_wdata_o  (bus_wdata),
    .loc_rdata_i  (bus_rdata),
    .loc_err_i    (bus_err),

    .axi_req_o    (axi_req),
    .axi_gnt_i    (axi_gnt),
    .axi_rvalid_i (axi_rvalid),
    .axi_we_o     (axi_we),
    .axi_be_o     (axi_be),
    .axi_addr_o   (axi_addr),
    .axi_wdata_o  (axi_wdata),
    .axi_rdata_i  (axi_rdata),
    .axi_err_i    (axi_err)
  );

  // ===========================================================================
  // The private bus: Ibex's bus.sv, one host, five devices
  // ===========================================================================
  logic        host_req    [1];
  logic        host_gnt    [1];
  logic [31:0] host_addr   [1];
  logic        host_we     [1];
  logic [3:0]  host_be     [1];
  logic [31:0] host_wdata  [1];
  logic        host_rvalid [1];
  logic [31:0] host_rdata  [1];
  logic        host_err    [1];

  logic        dev_req    [NrDevices];
  logic [31:0] dev_addr   [NrDevices];
  logic        dev_we     [NrDevices];
  logic [3:0]  dev_be     [NrDevices];
  logic [31:0] dev_wdata  [NrDevices];
  logic        dev_rvalid [NrDevices];
  logic [31:0] dev_rdata  [NrDevices];
  logic        dev_err    [NrDevices];

  logic [31:0] cfg_base [NrDevices];
  logic [31:0] cfg_mask [NrDevices];

  assign cfg_base[DevRam]   = RAM_BASE;
  assign cfg_mask[DevRam]   = RAM_MASK;
  assign cfg_base[DevTimer] = TIMER_BASE;
  assign cfg_mask[DevTimer] = TIMER_MASK;
  assign cfg_base[DevExt]   = EXT_BASE;
  assign cfg_mask[DevExt]   = EXT_MASK;
  assign cfg_base[DevIrq]   = IRQ_BASE;
  assign cfg_mask[DevIrq]   = IRQ_MASK;
  assign cfg_base[DevWdog]  = WDOG_BASE;
  assign cfg_mask[DevWdog]  = WDOG_MASK;

  assign host_req[0]   = bus_req;
  assign host_addr[0]  = bus_addr;
  assign host_we[0]    = bus_we;
  assign host_be[0]    = bus_be;
  assign host_wdata[0] = bus_wdata;
  assign bus_gnt       = host_gnt[0];
  assign bus_rvalid    = host_rvalid[0];
  assign bus_rdata     = host_rdata[0];
  assign bus_err       = host_err[0];

  bus #(
    .NrDevices   (NrDevices),
    .NrHosts     (1),
    .DataWidth   (32),
    .AddressWidth(32)
  ) u_bus (
    .clk_i               (clk_i),
    .rst_ni              (rst_sub_n),

    .host_req_i          (host_req),
    .host_gnt_o          (host_gnt),
    .host_addr_i         (host_addr),
    .host_we_i           (host_we),
    .host_be_i           (host_be),
    .host_wdata_i        (host_wdata),
    .host_rvalid_o       (host_rvalid),
    .host_rdata_o        (host_rdata),
    .host_err_o          (host_err),

    .device_req_o        (dev_req),
    .device_addr_o       (dev_addr),
    .device_we_o         (dev_we),
    .device_be_o         (dev_be),
    .device_wdata_o      (dev_wdata),
    .device_rvalid_i     (dev_rvalid),
    .device_rdata_i      (dev_rdata),
    .device_err_i        (dev_err),

    .cfg_device_addr_base(cfg_base),
    .cfg_device_addr_mask(cfg_mask)
  );

  // ---- RAM: port A here, port B on the fetch path ----
  scp_ram u_ram (
    .clk_i     (clk_i),
    .rst_ni    (rst_sub_n),

    .a_req_i   (dev_req[DevRam]),
    .a_we_i    (dev_we[DevRam]),
    .a_be_i    (dev_be[DevRam]),
    .a_addr_i  (dev_addr[DevRam]),
    .a_wdata_i (dev_wdata[DevRam]),
    .a_rvalid_o(dev_rvalid[DevRam]),
    .a_rdata_o (dev_rdata[DevRam]),

    .b_req_i   (instr_req),
    .b_gnt_o   (instr_gnt),
    .b_addr_i  (instr_addr),
    .b_rvalid_o(instr_rvalid),
    .b_rdata_o (instr_rdata),
    .b_err_o   (instr_err)
  );
  assign dev_err[DevRam] = 1'b0;

  // ---- Timer: Ibex's, unmodified ----
  timer #(
    .DataWidth   (32),
    .AddressWidth(32)
  ) u_timer (
    .clk_i         (clk_i),
    .rst_ni        (rst_sub_n),
    .timer_req_i   (dev_req[DevTimer]),
    .timer_addr_i  (dev_addr[DevTimer]),
    .timer_we_i    (dev_we[DevTimer]),
    .timer_be_i    (dev_be[DevTimer]),
    .timer_wdata_i (dev_wdata[DevTimer]),
    .timer_rvalid_o(dev_rvalid[DevTimer]),
    .timer_rdata_o (dev_rdata[DevTimer]),
    .timer_err_o   (dev_err[DevTimer]),
    .timer_intr_o  (irq_timer)
  );

  // ---- ext: straight out ----
  assign ext_req_o           = dev_req[DevExt];
  assign ext_we_o            = dev_we[DevExt];
  assign ext_be_o            = dev_be[DevExt];
  assign ext_addr_o          = dev_addr[DevExt];
  assign ext_wdata_o         = dev_wdata[DevExt];
  assign dev_rvalid[DevExt]  = ext_rvalid_i;
  assign dev_rdata[DevExt]   = ext_rdata_i;
  assign dev_err[DevExt]     = ext_err_i;

  // ---- The interrupt status/enable block: every source onto irq_external ----
  scp_irq #(
    .NUM_IN(NUM_IRQ),
    .ASYNC (IRQ_ASYNC)
  ) u_irq (
    .clk_i   (clk_i),
    .rst_ni  (rst_sub_n),
    .req_i   (dev_req[DevIrq]),
    .we_i    (dev_we[DevIrq]),
    .be_i    (dev_be[DevIrq]),
    .addr_i  (dev_addr[DevIrq]),
    .wdata_i (dev_wdata[DevIrq]),
    .rvalid_o(dev_rvalid[DevIrq]),
    .rdata_o (dev_rdata[DevIrq]),
    .err_o   (dev_err[DevIrq]),
    .in_i    (irq_i),
    .irq_o   (irq_ext)
  );

  // ---- The watchdog: its reset request resets everything above but itself ----
  scp_wdog u_wdog (
    .clk_i     (clk_i),
    .por_ni    (por_ni),
    .rst_ni    (rst_sub_n),
    .req_i     (dev_req[DevWdog]),
    .we_i      (dev_we[DevWdog]),
    .be_i      (dev_be[DevWdog]),
    .addr_i    (dev_addr[DevWdog]),
    .wdata_i   (dev_wdata[DevWdog]),
    .rvalid_o  (dev_rvalid[DevWdog]),
    .rdata_o   (dev_rdata[DevWdog]),
    .err_o     (dev_err[DevWdog]),
    .axi_idle_i(axi_idle),
    .hold_o    (wd_hold),
    .rst_req_o (wd_rst_req)
  );

  // ===========================================================================
  // AXI4-Lite: bridge, then demux
  // ===========================================================================
  logic [31:0] b_awaddr, b_wdata, b_araddr, b_rdata;
  logic [2:0]  b_awprot, b_arprot;
  logic [3:0]  b_wstrb;
  logic [1:0]  b_bresp, b_rresp;
  logic        b_awvalid, b_awready, b_wvalid, b_wready, b_bvalid, b_bready;
  logic        b_arvalid, b_arready, b_rvalid, b_rready;

  scp_axi_lite_master #(.AW(32)) u_axi_m (
    .clk_i        (clk_i),
    .rst_ni       (rst_sub_n),

    .req_i        (axi_req & ~wd_hold),   // no new transaction while the watchdog drains
    .gnt_o        (axi_gnt),
    .we_i         (axi_we),
    .be_i         (axi_be),
    .addr_i       (axi_addr),
    .wdata_i      (axi_wdata),
    .rvalid_o     (axi_rvalid),
    .rdata_o      (axi_rdata),
    .err_o        (axi_err),

    .m_axi_awaddr (b_awaddr),
    .m_axi_awprot (b_awprot),
    .m_axi_awvalid(b_awvalid),
    .m_axi_awready(b_awready),
    .m_axi_wdata  (b_wdata),
    .m_axi_wstrb  (b_wstrb),
    .m_axi_wvalid (b_wvalid),
    .m_axi_wready (b_wready),
    .m_axi_bresp  (b_bresp),
    .m_axi_bvalid (b_bvalid),
    .m_axi_bready (b_bready),
    .m_axi_araddr (b_araddr),
    .m_axi_arprot (b_arprot),
    .m_axi_arvalid(b_arvalid),
    .m_axi_arready(b_arready),
    .m_axi_rdata  (b_rdata),
    .m_axi_rresp  (b_rresp),
    .m_axi_rvalid (b_rvalid),
    .m_axi_rready (b_rready)
  );

  // The manager is idle (state IDLE) when it is ready for neither B nor R.
  assign axi_idle = !b_bready && !b_rready;

  scp_axi_lite_demux #(
    .NUM_M  (NUM_PPU),
    .AW     (32),
    .SEL_LSB(12),
    .SEL_W  (4)
  ) u_demux (
    .clk_i        (clk_i),
    .rst_ni       (rst_sub_n),

    .s_axi_awaddr (b_awaddr),
    .s_axi_awprot (b_awprot),
    .s_axi_awvalid(b_awvalid),
    .s_axi_awready(b_awready),
    .s_axi_wdata  (b_wdata),
    .s_axi_wstrb  (b_wstrb),
    .s_axi_wvalid (b_wvalid),
    .s_axi_wready (b_wready),
    .s_axi_bresp  (b_bresp),
    .s_axi_bvalid (b_bvalid),
    .s_axi_bready (b_bready),
    .s_axi_araddr (b_araddr),
    .s_axi_arprot (b_arprot),
    .s_axi_arvalid(b_arvalid),
    .s_axi_arready(b_arready),
    .s_axi_rdata  (b_rdata),
    .s_axi_rresp  (b_rresp),
    .s_axi_rvalid (b_rvalid),
    .s_axi_rready (b_rready),

    .m_axi_awaddr (m_axi_awaddr),
    .m_axi_awprot (m_axi_awprot),
    .m_axi_awvalid(m_axi_awvalid),
    .m_axi_awready(m_axi_awready),
    .m_axi_wdata  (m_axi_wdata),
    .m_axi_wstrb  (m_axi_wstrb),
    .m_axi_wvalid (m_axi_wvalid),
    .m_axi_wready (m_axi_wready),
    .m_axi_bresp  (m_axi_bresp),
    .m_axi_bvalid (m_axi_bvalid),
    .m_axi_bready (m_axi_bready),
    .m_axi_araddr (m_axi_araddr),
    .m_axi_arprot (m_axi_arprot),
    .m_axi_arvalid(m_axi_arvalid),
    .m_axi_arready(m_axi_arready),
    .m_axi_rdata  (m_axi_rdata),
    .m_axi_rresp  (m_axi_rresp),
    .m_axi_rvalid (m_axi_rvalid),
    .m_axi_rready (m_axi_rready)
  );

endmodule
