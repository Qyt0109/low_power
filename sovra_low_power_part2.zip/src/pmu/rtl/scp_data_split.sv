`timescale 1ns/1ps
// Split the SCP core's load/store port between the private bus and AXI4-Lite.
//
// References: Ibex doc/03_reference/load_store_unit.rst, "When multiple granted
// requests are outstanding, it is assumed that the memory requests will be kept
// in-order and one data_rvalid_i will be signalled for each of them, in the
// order they were issued."
//
//                      ┌──── local ──► bus.sv ──► RAM, timer, ext   (1 cycle)
//   Ibex data port ────┤
//                      └──── axi ────► scp_axi_lite_master ──► PPUs (many cycles)
//
// WHY THIS EXISTS
//
// bus.sv assumes every device answers on the cycle after the request. A bridge
// to AXI4-Lite cannot: a PPU access takes a handshake on each channel, and a
// PPU whose clock is gated takes a wake on top. So the AXI window is taken off
// the core's port before bus.sv sees it.
//
// THE ONE RULE: RESPONSES STAY IN ORDER
//
// Ibex can have two data accesses outstanding -- the two halves of a misaligned
// access -- and matches responses to requests purely by order. The local side
// answers in one cycle and the AXI side in many, so a local request granted
// behind an AXI one would be answered FIRST and the core would pair each
// response with the wrong request. The rule that prevents it is the whole of
// this module's state: a request is not forwarded while responses are
// outstanding on the OTHER side. Same-side requests pipeline freely.
//
// In practice the rule never fires. It needs a misaligned access that straddles
// the AXI window's edge, which no driver issues. It is here because the
// alternative is a silent mis-pairing if one ever does.

module scp_data_split #(
  parameter logic [31:0] AXI_BASE = 32'h4000_0000,
  parameter logic [31:0] AXI_MASK = 32'hFFFF_0000    // a 64 KB window
) (
  input  logic        clk_i,
  input  logic        rst_ni,

  // ---- From the core ----
  input  logic        data_req_i,
  output logic        data_gnt_o,
  output logic        data_rvalid_o,
  input  logic        data_we_i,
  input  logic [3:0]  data_be_i,
  input  logic [31:0] data_addr_i,
  input  logic [31:0] data_wdata_i,
  output logic [31:0] data_rdata_o,
  output logic        data_err_o,

  // ---- To bus.sv's host port ----
  output logic        loc_req_o,
  input  logic        loc_gnt_i,
  input  logic        loc_rvalid_i,
  output logic        loc_we_o,
  output logic [3:0]  loc_be_o,
  output logic [31:0] loc_addr_o,
  output logic [31:0] loc_wdata_o,
  input  logic [31:0] loc_rdata_i,
  input  logic        loc_err_i,

  // ---- To the AXI4-Lite bridge ----
  output logic        axi_req_o,
  input  logic        axi_gnt_i,
  input  logic        axi_rvalid_i,
  output logic        axi_we_o,
  output logic [3:0]  axi_be_o,
  output logic [31:0] axi_addr_o,
  output logic [31:0] axi_wdata_o,
  input  logic [31:0] axi_rdata_i,
  input  logic        axi_err_i
);

  logic sel_axi;
  assign sel_axi = ((data_addr_i & AXI_MASK) == AXI_BASE);

  // Outstanding responses, and which side owes them. At most two, per Ibex.
  logic [1:0] pend_q;
  logic       pend_axi_q;

  logic block;
  assign block = (pend_q != 2'd0) && (pend_axi_q != sel_axi);

  assign loc_req_o = data_req_i && !sel_axi && !block;
  assign axi_req_o = data_req_i &&  sel_axi && !block;

  // The payload goes to both; only the side whose req is high looks at it.
  assign loc_we_o    = data_we_i;
  assign loc_be_o    = data_be_i;
  assign loc_addr_o  = data_addr_i;
  assign loc_wdata_o = data_wdata_i;
  assign axi_we_o    = data_we_i;
  assign axi_be_o    = data_be_i;
  assign axi_addr_o  = data_addr_i;
  assign axi_wdata_o = data_wdata_i;

  assign data_gnt_o = (loc_req_o && loc_gnt_i) || (axi_req_o && axi_gnt_i);

  // Only one side can be answering in any cycle -- that is what the rule above
  // buys -- so the response mux needs no priority.
  //
  // Each side's rvalid is also qualified by that side OWING a response. bus.sv
  // derives its response select from the core's address every cycle, request or
  // not, and its timer's error flop has no reset; neither matters while nothing
  // is outstanding, and the qualification makes sure it cannot matter at all.
  logic loc_owed, axi_owed, loc_resp, axi_resp;
  assign loc_owed = (pend_q != 2'd0) && !pend_axi_q;
  assign axi_owed = (pend_q != 2'd0) &&  pend_axi_q;
  assign loc_resp = loc_rvalid_i && loc_owed;
  assign axi_resp = axi_rvalid_i && axi_owed;

  assign data_rvalid_o = loc_resp || axi_resp;
  assign data_rdata_o  = axi_resp ? axi_rdata_i : loc_rdata_i;
  assign data_err_o    = axi_resp ? axi_err_i   : (loc_resp && loc_err_i);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pend_q     <= 2'd0;
      pend_axi_q <= 1'b0;
    end else begin
      pend_q <= pend_q + {1'b0, data_gnt_o} - {1'b0, data_rvalid_o};
      if (data_gnt_o) pend_axi_q <= sel_axi;
    end
  end

`ifndef SYNTHESIS
  // The rule above makes all three impossible; a failure is a bug here or in a
  // device, and is reported rather than silently dropped by the qualification.
  always @(posedge clk_i)
    if (rst_ni) begin
      if (loc_rvalid_i === 1'b1 && axi_rvalid_i === 1'b1)
        $error("[scp_data_split] both sides answered in the same cycle");
      if (loc_rvalid_i === 1'b1 && !loc_owed)
        $error("[scp_data_split] a local response nobody asked for");
      if (axi_rvalid_i === 1'b1 && !axi_owed)
        $error("[scp_data_split] an AXI response nobody asked for");
    end
`endif

endmodule
