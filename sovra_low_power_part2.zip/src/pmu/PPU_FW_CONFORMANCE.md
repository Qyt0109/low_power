# PPU conformance, as the SCP firmware drives it

This is the cross-check of every PPU function, mode, transition and feature the
SCP firmware can control against the **Arm Power Policy Unit Architecture
Specification v1.1 (ARM DEN 0051E)**. The current run is **soc4stress**:
[`soc4/fw/test/soc4_stress.c`](../soc4/fw/test/soc4_stress.c) on the SCP of
soc4, over its four static-only PPUs ([`docs/SOC4_DESIGN.md`](../../docs/SOC4_DESIGN.md)
Section 11.3), under Synopsys VCS W-2024.09-SP2:

```
make soc4stress   SIM=vcs     # plain RTL
make soc4stresspa SIM=vcs     # under UPF (VCS native low power)
```

It keeps the check IDs of Section 3, so the two reports compare row for row.
What the soc4 PPUs are built without is left to the PPU unit testbenches
(Section C). Sections 1 to 9 are the earlier report, kept as the record: the
same cross-check on all twelve PPUs of `pmu_top`, by `fw/test/ppu_stress.c`
(`make scpstress`), on 2026-09-29. `pmu_top`, that program and its targets
were removed on 2026-10-02 (SOC4_DESIGN.md Section 12); the findings of
Section 4 and their fixes stand.

Section references are to DEN 0051E. The RTL's own conformance record, from
unit and domain testbenches, is [`rtl/ppu/CONFORMANCE.md`](../rtl/ppu/CONFORMANCE.md).
This document is the system-level view: the SCP firmware, over AXI4-Lite, on
several PPUs at once. The findings are also in
[README §10.2](README.md#102-findings-in-the-ppu-and-pcsm-hardware).

---

## A. soc4stress: result (2026-10-05)

| Run | Features | PASS | DEVIATION | FAIL | Firmware checks | Testbench checks | Testbench errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| `make soc4stress SIM=vcs` | 34 | 34 | 0 | 0 | 1,812 | 7,619 | 0 |
| `make soc4stresspa SIM=vcs` | 34 | 34 | 0 | 0 | 1,812 | 7,873 | 0 |

Under UPF the low-power checker reports no ERROR and no FATAL, and each
domain's logic switch turns its supply off and on again (96, 59, 104 and 77
times for domains 0 to 3). Until 2026-10-05 `S.DYNREQ` was a DEVIATION, a
driver finding, not a PPU one; the driver fix made it PASS (Section B). The PPUs (SOC4_DESIGN.md Section 3.3):

| Domain | PPU | Static modes | RAM retention register |
|---|---|---|---|
| 0 CPU0 (Ibex) | 0 | `OFF`, `FULL_RET`, `ON`, `WARM_RST` | `PPU_FULRR` |
| 1 CPU1 (Ibex) | 1 | `OFF`, `ON`, `WARM_RST` | none |
| 2 ACC0 (`ppu_device_ip`) | 2 | `OFF`, `MEM_RET`, `ON`, `WARM_RST` | `PPU_MEMRR` |
| 3 ACC1 (`ppu_device_ip`) | 3 | `OFF`, `ON`, `WARM_RST` | none |

None has a dynamic mode, the lock, `MEM_OFF`, `FUNC_RET` or the direct
`OFF → MEM_RET` hop. The checks are the three views of Section 2: the
registers, the pins (`soc4_tb`'s observation window) and the spec tables at
every committed hop, with `ppu_monitor`, `ppu_power_model`, the AXI4-Lite
rules and the 20-cycle settling budget running throughout. A feature fails if
the testbench records a single error while it runs.

## B. Row by row on soc4

"Section 3" is the row of the earlier report this one answers. Checks are the
firmware's, per `RESULT` line of `make soc4stress`.

| Check | Section 3 row | What soc4stress does | Checks | Status |
|---|---|---|---:|---|
| `RST` | 3.1 reset values | every offset on 4 PPUs, values derived per configuration | 101 | PASS |
| `ID` | 3.1 identification | `AIDR`, `IDR0`/`IDR1` per domain, `DEVCHAN`, `IIDR`; the driver's decoded sets | 83 | PASS |
| `REG.RW` | 3.1 writable fields | 5 patterns per RW register; the absent retention registers and `LOCK_EN`/`PWR_DYN_EN` reserved | 251 | PASS |
| `REG.RO` | 3.1 read-only, reserved | RO registers with ones and zeros; `PMER`, `STSR`, `OPSR`, `UNLK`, unmapped offsets | 141 | PASS |
| `REG.BYTE` | 3.1 byte lanes, admission | lane writes; an unsupported policy refused whole; `PWR_DYN_EN` reserved | 33 | PASS |
| `REG.W1C` | 3.1 W1C, the IRQ level | on 4 PPUs, the line at the SCP interrupt block (`RAW`, since 2026-10-05; `mip` before) and at the pin | 37 | PASS |
| `STA.MATRIX` | 3.2, 3.3 modes and pairs | all ordered pairs of each domain's modes: 12 + 6 + 12 + 6 = 36 | 216 | PASS |
| `EVT.PTRN1` | 3.3 `STA_POLICY_TRN` condition 1 | each domain, each mode | 36 | PASS |
| `STA.QACT` | 3.3 `DEVQACTIVE` gating | routes through `ON`, `PWR_DEVACTIVEEN` 0 and 1 | 21 | PASS |
| `STA.MIDWRITE` | 3.3 a write does not interrupt a hop | ACC0's down-hop held, `PWPR` rewritten | 10 | PASS |
| `DENY` | 3.6 denial reverts the policy | including the second hop of a route through `ON`; condition 3 | 13 | PASS |
| `EVT.MASK` | 3.7 masks | | 28 | PASS |
| `EVT.EDGE` | 3.7 edge events | ACC wake toggles | 22 | PASS |
| `EVT.EDGE_OFF` | 3.7 edges with the input disarmed | | 7 | PASS |
| `EVT.UNSPT` | 3.2, 3.7 unsupported modes refused | every mode a domain lacks | 209 | PASS |
| `EVT.LINES` | 3.7 PPU n on line 16 + n | since 2026-10-05: PPU n on input n of `scp_irq` and no other, no fast line raised; the handler path one line-11 interrupt per event | 17 | PASS |
| `DEV.REQEN` | 3.8 `DEVREQEN` | | 22 | PASS |
| `DEV.WARM` | 3.8 `WARM_RST_DEVREQEN` | `PTCR` 0 and 1 on ACC0 | 21 | PASS |
| `DEV.STATUS` | 3.8 `DISR`, `MISR` | the `MISR` deny and PCSM bits added | 18 | PASS |
| `DLY` | 3.9 device control delays | three settings; each spacing exactly value + 1 | 116 | PASS |
| `EDT.STATIC` | 3.10 static entry delays | the `OFF`, `MEM_RET` and `FULL_RET` fields | 24 | PASS |
| `EDT.SCOPE` | 3.10 not upward, not `ON ↔ WARM_RST` | | 15 | PASS |
| `EDT.RESTART` | 3.10 restart, reprogramming | | 14 | PASS |
| `PCSM.RR` | 3.11 `PCSMPSTATE` | `FULL_RET` on CPU0, `MEM_RET` on ACC0 | 24 | PASS |
| `PCSM.RAM` | 3.11 the retention byte reaches the RAM | CPU0 `FULRR` keeps or loses the CPU RAM; ACC0 `MEMRR` = 0xA5 keeps banks 0, 2, 5, 7 | 38 | PASS |
| `CLK` | 3.12 the PPU's own clock | | 7 | PASS |
| `FW.STATES` | 3.12 every mode of every domain through the interrupt path | `pd_request_static` and `pd_poll` | 78 | PASS |
| `pd_multi` | 3.12 refused and reverted writes reported as such | REFUSED for unsupported policies, REVERTED for denials | 10 | PASS |
| `S.CPUQ` | soc4 only | the CPU Q-Channel adapter: accept in WFI only | 21 | PASS |
| `S.LOAD` | soc4 only | the CPU load port in `WARM_RST` and `ON` only | 19 | PASS |
| `S.CPUBOOT` | soc4 only | cold boot at `CPUn_BOOT`, `FETCH_EN`, `WARM_RST` restart | 17 | PASS |
| `S.LOCKREQ` | soc4 only | a `LOCK_EN` request on a PPU without the lock: refused without a write | 8 | PASS |
| `S.DYNREQ` | soc4 only | `{m, PWR_DYN_EN}` with `m` static: the PPU takes static `m` (`PWR_DYN_EN` reserved with no dynamic mode, Table 5-2, WI/RAZ §5.2), and the driver's `ppu_set_policy(m, dyn)` refuses before writing, `PPU_E_UNSUPPORTED`, the PPU untouched | 6 | PASS (was a DEVIATION, SOC4_DESIGN.md 15.2-21, until the driver fix of 2026-10-05) |
| `SOAK` | 3.12 everything at once | the four domains on seeded random static sequences, 2,000 requests | 129 | PASS |
| (continuous) | 3.2 device controls, PPUHWSTAT; 3.9 spacings, order; settling | `soc4_tb`, every hop | — | PASS |
| `soc4stresspa` | 3.2 supply removed in `OFF`, `MEM_RET`, `FULL_RET` logic | the supply-net checks at every `CHECK` | — | PASS |

## C. Left to the PPU unit testbenches

The soc4 PPUs are built without these, so no firmware can reach them there.
Each was PASS in the earlier report (Section 3) and is covered by the PPU's
own suite: `ppu` (`ppu_pd_tb`, 617 checks), `ppuneg`, `ppudeny`, `ppudevif`,
`ppucfg`, `ppuirq`, `ppuclkq`, `ppupcsmpg` and `ppurstf`.

- Dynamic transitions: `DYN.FLOORS`, `DYN.ROUTE`, `DYN.STATUS`, `EDT.DYNAMIC`;
  `STA_POLICY_TRN` condition 4; `DYN_ACCEPT` / `DYN_DENY`; the dynamic-denial
  and `PWR_DYN_EN`-during-denial cases of `DENY`; the driver's second
  `PWR_DYN_EN` change. All need `DYN_*_SPT_CFG` = 1.
- The lock: `LOCK.SET`, `LOCK.CLEAR`, `LOCK.RACE`. All need `LOCK_CFG` = 1.
- `MEM_OFF` and `FUNC_RET`: the modes, their pairs, their `EDTR` fields,
  `PPU_FUNRR`.
- The direct `OFF → MEM_RET` hop (`OFF_MEM_RET_TRANS_CFG` = 0 on soc4).
- `PCSMMODESTAT` reporting `MEM_RET` at reset.

Section 5's "real, but out of firmware's reach" list is unchanged.

---

# The 2026-09-29 record on `pmu_top` (retired 2026-10-02)

What follows is the earlier report as it was written, on all twelve domains of
`pmu_top`, by `fw/test/ppu_stress.c` (`make scpstress`, `make scpstresspa`).
Files it links to under `fw/test/` and `tb/pmu/pmu_tb.sv`, and those targets,
no longer exist; they are in the history at commit `e978f0d`.

## 1. Result

| Run | Features | PASS | DEVIATION | FAIL | Firmware checks | Testbench checks | Testbench errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| `make scpstress SIM=vcs` | 35 | 35 | 0 | 0 | 7,028 | 22,692 | 0 |
| `make scpstresspa SIM=vcs` | 35 | 35 | 0 | 0 | 7,028 | 23,694 | 0 |

The two runs give identical results for every feature. Each run is about 2.2
million cycles: about 41 s of CPU time under power intent, 33 s without. The
first run, before the fixes, gave 32 PASS and 3 DEVIATION (Section 4).

| Activity in one run | Count |
|---|---:|
| Mode changes committed, twelve domains | 2,855 |
| Device Q-Channel handshakes | 1,432 |
| PCSM P-Channel handshakes | 2,561 |
| Table 4-5 spacings measured and checked | 4,252 |
| Power-ups held to the 20-cycle settling budget (shortest 21) | 821 |
| AXI4-Lite writes / reads to the PPUs | 12,834 / 13,020 |
| PPU interrupts | 1,212 |

**The status words:**

- **PASS.** The PPU did what the specification says, and every check passed.
- **DEVIATION.** The PPU did not do what the specification says, and did exactly what a documented finding predicts. These do not fail the run. They are not passes.
- **N/A.** The function cannot exist in this build. The reason is given.
- **RTL.** The function is real, but firmware cannot provoke or observe it. The named RTL testbench covers it.

**What the run established:**

1. **Every function the firmware can drive behaves as DEN 0051E says.** This
   holds on all twelve PPUs, concurrently, with and without the power intent.
   The first run found three deviations (Section 4); all three are fixed in the
   RTL, and their features now PASS.
2. **One new PPU finding (finding 5), since fixed.** The first `STA_POLICY_TRN`
   condition was decided on `PWR_DYN_STATUS` instead of `PPU_PWPR.PWR_DYN_EN`. As a result a
   same-mode write that switched between static and dynamic raised the event
   when it should not, and missed it when it should have raised it.
3. **Finding 1 was wider than recorded, and is fixed.** A lock written in
   `MEM_RET` was not the only trigger. Any `PPU_PWPR` write with `LOCK_EN` and
   `PWR_DYN_EN` set, made in a lockable mode with a different target, moved the
   domain instead of locking it. All three variants now hold.
4. **One firmware gap is closed.** §4.1.1 makes it UNPREDICTABLE to change
   `PWR_DYN_EN` again before `PWR_DYN_STATUS` reflects the last change. The
   driver did not enforce this. It now refuses such a write, and the manager
   waits for the status first. Section 8 has the details.
5. **The checks catch real defects.** Five defects were planted in the PPU RTL,
   one at a time, and all five were caught (Section 6).

---

## 2. How a feature is checked

Every feature compares three views of the same event.

| View | Where | What it sees |
|---|---|---|
| **Registers** | the firmware, through `hal/ppu_v1` over AXI4-Lite | what software can know: `PPU_PWSR`, `PPU_PWPR`, `PPU_ISR`/`AISR`, `DISR`, `MISR`, ... |
| **Pins** | `pmu_tb`'s observation window, read by the firmware through `SIM_OBS` ([`fw/hal/sim.h`](fw/hal/sim.h)) | what the PPU did at its boundary: device and PCSM handshakes, the event pulses before masking, the spacing between device-control changes, and the latency from policy write or `DEVQACTIVE` fall to the device request |
| **Spec tables** | `pmu_tb`, at every hop any domain commits (`tb/pmu/pmu_tb.sv`, removed 2026-10-02) | the hop rule (§3.3.2); the device-control row of Tables 4-7, 4-9 and 4-11; PPUHWSTAT per Table 3-2; PCSMPSTATE per Table 4-12; every Table 4-5 spacing at least its value + 1 |

The spec-table checks use their own transcription of the tables, taken from the
specification text rather than from `ppu_pkg`. The RTL's copy is therefore
checked against an independent one. Four checkers from the earlier bring-up
also run throughout:

- `ppu_monitor`, rules U1 to U12
- `ppu_power_model`, rules PU1 to PU10
- the AXI4-Lite VALID/payload rules on the SCP's manager port
- the 20-cycle settling budget

**A feature FAILs if the testbench records a single error or violation while it
runs**, whatever the firmware concluded. That is how a mode reported correctly
in `PPU_PWSR` but entered with a wrong device-control row fails the feature
that caused it. Every `CHECK` the firmware issues is additionally compared with
the PPU's committed mode, the PCSM's mode and rails, PPUHWSTAT, the device
controls and PCSMPSTATE[7:0]. Under UPF it is also compared with whether the
domain's logic has actually lost its supply.

Event counts that must be exact come from the pins. A status bit set twice
before software services it is one event in `PPU_ISR` (§4.1.2), so software
alone cannot count the per-hop events of a two-hop transition. The status bits
are checked too, as software sees them.

---

## 3. Features

The **Check** column names the `RESULT` line in the run's output.

### 3.1 Identification and the programmer's model

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| Reset value of every register | Tables 5-2 to 5-29; §7 defaults | 26 offsets on 12 PPUs, read before anything writes a PPU, against values derived from the tables and this build's configuration. Includes `PWCR` 0x101, `IMR` 0x22, `AIMR` 0x06, `DCDR0/1` 0x020202/0x0202 | `RST` | PASS |
| Identification: architecture v1.1, mode support, optional features, implementation | §5.2.23–5.2.26 | `AIDR` 0x11, `IDR0` 0x1E53E501, `IDR1` 0x1077, `IIDR` 0x50C01000. The driver's decoded support sets are 0x03E5 static and 0x01E5 dynamic, and its per-policy answer is checked for all 16 encodings. The Q-Channel hard zeros are 0: `DYN_WRM_RST`, `LGC_RET`, `DBG_RECOV`, the EMU bits, `NUM_OPMODE` and `IDR1[10:8]` | `ID` | PASS |
| Writable fields hold what is written; reserved bits WI/RAZ | §5.2 | 12 RW registers, 5 patterns, 12 PPUs, each PPU a different value, all checked against the exact writable mask. This also shows that each PPU decodes only its own window. `PPU_PWPR` written with every reserved bit set | `REG.RW` | PASS |
| Read-only registers ignore writes; reserved registers read zero | §5.2, §5.2.6 | `PWSR`, `DISR`, `MISR` and the four ID registers written with ones and zeros, unchanged. `PMER`, `STSR`, `OPSR`, `UNLK` and 22 unmapped offsets read 0 and take writes without a bus fault or a side effect | `REG.RO` | PASS |
| Byte-lane writes (AXI `WSTRB`) | §6.2.1 (bus IMPLEMENTATION DEFINED) | `sb`/`sh` to `EDTR0`, `DCDR0`, `PWCR`, `PWPR` and `ISR` change only their lanes. A reserved lane is ignored | `REG.BYTE` | PASS |
| `PPU_PWPR` admission judges policy and dynamic enable together | §4.1.1 | A lane-0 write of `WARM_RST` while lane 1 holds `PWR_DYN_EN` is refused whole: dynamic `WARM_RST` is unsupported | `REG.BYTE` | PASS |
| `ISR`/`AISR` write-one-to-clear; a 0 changes nothing; `OTHER_IRQ` mirrors `AISR` and is not cleared through `ISR`; IRQ is the OR of both, as a level | §4.1.2, §5.2.12–5.2.13 | Checked on 12 PPUs, with the line watched in `mip` and at the pin | `REG.W1C` | PASS |

### 3.2 Power modes

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| All seven modes: `OFF`, `MEM_RET`, `FULL_RET`, `MEM_OFF`, `FUNC_RET`, `ON`, `WARM_RST` | Tables 3-1, 3-2 | Each mode entered 72 times across the twelve domains in the matrix, with a `CHECK` after every step | `STA.MATRIX` | PASS |
| Device controls per mode (`CLKEN`, `ISOLATEn`, `PORESETn`, `WARMRESETn`, `RETRESETn`) | Tables 4-7, 4-9, 4-11 | Testbench, at all 2,856 committed hops and at every `CHECK`, against its own transcription. The `FULL_RET` row (only `DEVWARMRESETn` asserted) and the `WARM_RST` row (`DEVWARMRESETn` and `DEVRETRESETn` asserted) are the ones most easily transcribed into each other | continuous | PASS |
| PPUHWSTAT one-hot | §4.1.4, Table 3-2 | Testbench at every hop, and at every `CHECK` | continuous | PASS |
| Supply actually removed in `OFF`, `MEM_RET` and `FULL_RET` logic; kept elsewhere | Table 3-1 | Under UPF only: `CHECK` requires the device's non-retained logic to read X exactly when the mode removes its supply | `scpstresspa` | PASS |
| Modes this build does not have are refused: `OFF_EMU`, `MEM_RET_EMU`, `LOGIC_RET`, `DBG_RECOV` and 11–15 | §3.1, §4.1.1, Table 5-26 | See `EVT.UNSPT` | `EVT.UNSPT` | PASS |

### 3.3 Static transitions

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| All 42 ordered pairs of the seven modes, on every domain | §3.3.2, §3.4.2 | One Eulerian circuit over the complete graph of the modes. Each domain starts at a different point on it, so the twelve always perform different transitions at the same time: 504 transitions and 852 hops. For each transition and domain the test checks: <br>• the final mode <br>• the number of hops, 1 if either end is `ON` or it is `OFF → MEM_RET`, else 2 through `ON` <br>• the device handshakes, one per departure from `ON` <br>• the PCSM handshakes, one per hop except `ON ↔ WARM_RST` <br>• one `STA_POLICY_TRN` <br>• one `STA_ACCEPT` per hop <br>• no other event <br>• both status bits set | `STA.MATRIX` | PASS |
| A hop has `ON` at one end, except `OFF → MEM_RET` | §3.3.2 | Testbench at every committed hop, and `ppu_monitor` U9 | continuous | PASS |
| `OFF → MEM_RET` is direct and PCSM-only; `MEM_RET → OFF` goes through `ON` | §3.3.2, §4.2.6, Table 4-14 | The direct hop makes no device handshake, one PCSM handshake and no device-control change. The reverse makes two hops | `STA.MATRIX` | PASS |
| `ON ↔ WARM_RST` makes no PCSM handshake; `WARM_RST` is `ON` to the PCSM | Table 3-2 note a | PCSM handshake count 0; PCSMPSTATE shows `ON` in `WARM_RST` | `STA.MATRIX`, `DEV.WARM` | PASS |
| A static write of the mode the PPU is already in makes no transition | §3.3.2, §4.1.2 | All seven modes: no hop, no handshake | `EVT.PTRN1` | PASS |
| A static lower-priority transition waits for `DEVQACTIVE` LOW, including an intermediate hop through `ON` | §3.4.2 | From `ON` with policy `OFF`, the PPU is held in `ON` for 1,500 cycles and the policy is not reverted. From `FULL_RET` with policy `OFF`, it is held in `FULL_RET` and does not climb to `ON`: this is the §3.4.2 example. Both proceed once `DEVQACTIVE` falls | `STA.QACT` | PASS |
| A higher-priority transition is not delayed; `ON ↔ WARM_RST` never waits for `DEVQACTIVE` | §3.4.2 | `OFF → ON`, `ON → WARM_RST` and `WARM_RST → ON` complete with `DEVQACTIVE` HIGH | `STA.QACT` | PASS |
| A transition from `ON` waits even when it is the second hop of a route upward | §3.4.2: "For transitions from ON, other than to WARM_RST, all DEVQACTIVE inputs must be LOW to begin a transition." Page 3-19, *Intermediate Power Mode Transitions*: "upon reaching an intermediate power mode the PPU must consider the current power mode, programmed policy, and DEVACTIVE inputs before making further transitions." | From `FULL_RET` with policy `FUNC_RET` and `DEVQACTIVE` HIGH, the PPU climbs to `ON` and holds there until `DEVQACTIVE` falls | `STA.QACT` | PASS |
| A disabled `DEVACTIVE` input is assumed LOW | §3.4.1, §4.1.3 | With `PWR_DEVACTIVEEN` = 0, `ON → OFF` proceeds with `DEVQACTIVE` HIGH | `STA.QACT` | PASS |
| Writing `PPU_PWPR` does not interrupt a transition | §4.1.1 | Policy `FUNC_RET` is written while `ON → OFF` waits on a busy device. The PPU finishes the hop to `OFF`, then goes `OFF → ON → FUNC_RET`: 3 hops, 3 `STA_ACCEPT`, 1 `STA_POLICY_TRN`, 2 device handshakes | `STA.MIDWRITE` | PASS |
| Twelve PPUs transitioning at once, independently | — | The matrix, the dynamic floors and the soak all run on every domain at the same time. One PPU's events never appear on another's line or counters | `STA.MATRIX`, `DYN.FLOORS`, `SOAK` | PASS |

### 3.4 Dynamic transitions

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| Each dynamic floor: `OFF`, `MEM_RET`, `FULL_RET`, `MEM_OFF`, `FUNC_RET`, `ON`. `DEVQACTIVE` LOW takes the domain to the floor, HIGH brings it to `ON` | §3.4.3 | Two domains per floor, three rounds. In the third round only the even domains are woken and the others must stay. Each hop gives one `DYN_ACCEPT` and no static event. `PWR_DYN_STATUS` is set and the policy never moves | `DYN.FLOORS` | PASS |
| Dynamic routes through intermediate modes | §3.4.3 | `FULL_RET` to dynamic `OFF` goes through `ON`: 2 hops, 2 `DYN_ACCEPT`. `OFF` to dynamic `FUNC_RET`: 2 hops. A wake at dynamic `OFF` brings the domain up, and it goes back down | `DYN.ROUTE` | PASS |
| `PWR_DYN_STATUS` changes only once the transition in flight completes | §3.4.3, Table 5-4 | `PWR_DYN_EN` is cleared while a dynamic hop waits on a busy device. The status stays 1 until the hop commits, then drops | `DYN.STATUS` | PASS |
| Dynamic `WARM_RST` is unsupported | §3.4.3 | Refused in every form | `EVT.UNSPT`, `REG.BYTE` | PASS |

### 3.5 Lock

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| Locks on arriving in `OFF` or `MEM_RET` with `LOCK_EN` and `PWR_DYN_EN`; `LOCKED` event | §3.4.3 "Locking the PPU" | `LOCK_STATUS` set, one `LOCKED` pulse, `ISR[5]` set | `LOCK.SET` | PASS |
| Locks when `PPU_PWPR` is written in a lockable mode with no transition, even straight after an unlock | §3.4.3 | Written in `OFF`: locked, no hop. Written again after `PPU_UNLK`: locked again | `LOCK.SET` | PASS |
| A locked PPU ignores `DEVQACTIVE` and a higher policy | §3.4.3 | Held in `OFF` or `MEM_RET` for 800 cycles against a wake, and against `{ON, DYN, LOCK}` | `LOCK.SET` | PASS |
| Unlock by `PPU_UNLK`, re-locking on re-entry; unlock by clearing `LOCK_EN` or `PWR_DYN_EN` | §3.4.3 "Unlocking the PPU" | All three. After each, the domain follows its policy and wake | `LOCK.SET`, `LOCK.CLEAR` | PASS |
| No lock without `PWR_DYN_EN`; no lock in a mode that is not lockable | §3.4.3 | Static `{OFF, LOCK_EN}` does not lock. Dynamic `FULL_RET`, `MEM_OFF` and `FUNC_RET` with `LOCK_EN` do not lock | `LOCK.CLEAR` | PASS |
| A lock written in a lockable mode with a different target holds the domain where it is | §3.4.3 | Three variants: `{OFF}` written in `MEM_RET`, `{ON}` in `OFF`, `{MEM_RET}` in `OFF`, each with `DYN` and `LOCK` | `LOCK.RACE` | PASS. Before finding 1 was fixed: DEVIATION, the PPU launched the hop and ended up locked in `ON`, or in `MEM_RET` |
| Locks when a transition from a lockable mode is denied | §3.4.3 | — | — | N/A. On a Q-Channel PPU such a transition cannot be denied: every exit from `OFF` or `MEM_RET` climbs to `ON`, and AMBA LPI has no denial on the exit path. `OFF → MEM_RET` has no handshake |

### 3.6 Denial

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| A denied static transition reverts the policy to the current mode and touches nothing | §4.1.1, §4.2.9, Table 4-1 | A busy device refuses `ON → OFF`. The checks: <br>• `PPU_PWPR` reads `ON` <br>• one `STA_DENY` <br>• zero device-control changes <br>• zero PCSM handshakes <br>• zero hops <br>• exactly one request, withdrawn <br>• no retry once the device is idle | `DENY` | PASS |
| A `PWR_DYN_EN` set during the denied transition reverts too | §4.1.1, Table 4-1 | `{OFF, DYN}` is written mid-handshake, then the device refuses. The result is `PPU_PWPR` = static `ON` | `DENY` | PASS |
| Denial of the second hop of a route through `ON` | §4.1.2 "Static Transition Denial" | `FULL_RET` with policy `OFF`: the `ON → OFF` hop is refused. The policy reverts to `ON`, with one accept and one deny | `DENY` | PASS |
| A dynamic denial reverts nothing | Table 4-1 | `DYN_DENY` raised (16 times while the device stays busy). The policy is still dynamic `OFF`, and the domain reaches `OFF` once the device is idle | `DENY` | PASS |

### 3.7 Interrupt events

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| `STA_POLICY_TRN`, condition 1: a supported write, not in transition, mode already matching, with `PWR_DYN_EN` = 0 | §4.1.2 | The event fires in all seven modes. Two further cases switch between static and dynamic at the same mode | `EVT.PTRN1` | PASS. Before finding 5 was fixed: DEVIATION, static to dynamic raised one event (spec: none) and dynamic to static none (spec: one) |
| Condition 2: an accepted static transition, one event per policy, at the final hop | §4.1.2 | 504 transitions, exactly one each, and none at the intermediate `ON` | `STA.MATRIX` | PASS |
| Condition 3: a denied transition whose last mid-flight write equals the current mode | §4.1.2 | `ON` is written during a refused `ON → OFF`: one `STA_DENY` and one `STA_POLICY_TRN`. With `OFF` written instead, none | `DENY` | PASS |
| Condition 4: a transition completing with `PWR_DYN_STATUS` = 1 after `PWR_DYN_EN` was cleared | §4.1.2 | One `DYN_ACCEPT`, one `STA_POLICY_TRN`, no `STA_ACCEPT` | `DYN.STATUS` | PASS |
| `STA_ACCEPT` per completed hop, intermediates included, only with `PWR_DYN_STATUS` = 0 | §4.1.2, Table 4-2 | Hop count equals accept count on 504 transitions; zero static accepts on dynamic hops | `STA.MATRIX`, `DYN.*` | PASS |
| `DYN_ACCEPT` per dynamic hop | Table 4-3 | See the dynamic features | `DYN.*` | PASS |
| `UNSPT_POLICY`: the whole write is refused, one event each | §4.1.1, §4.1.2 | 19 unsupported or reserved encodings (static 1, 3, 4, 10–15; dynamic 1, 3, 4, 9–15), with and without `LOCK_EN`, on 12 PPUs: 456 writes. For each: `PPU_PWPR` unchanged, `LOCK_EN` and `PWR_DYN_EN` included; exactly one event; `AISR[0]` set; `OTHER_IRQ` set | `EVT.UNSPT` | PASS |
| A masked event does not set its status bit, and unmasking does not resurrect it | §5.2.10–5.2.11 | Each of the seven maskable events, on its own mask bit. Masked, the event pulse occurs and the status stays clear. Unmasking leaves it clear. The next occurrence sets it | `EVT.MASK` | PASS |
| Default masks | Tables 5-13, 5-14 | `IMR` 0x22, `AIMR` 0x06 | `RST` | PASS |
| Input edge event: none, rise, fall, both | §4.1.2, §5.2.14 | All four `PPU_IESR` settings, one event per selected edge, `ISR[8]` accordingly | `EVT.EDGE` | PASS |
| The edge event does not depend on `PWR_DEVACTIVEEN` | §4.1.3 | Input disarmed, PPU idle, edge raised | `EVT.EDGE_OFF` | PASS. Before finding 2 was fixed: DEVIATION, no event or IRQ for 600 cycles, then the event at the next register access |
| PPU n's interrupt is SCP line 16 + n, and only that line | integration | An event on each PPU in turn sets exactly one `mip` bit, and clearing it drops the line. The same with the handler: `trap_fast` → `pd_poll`, one fast interrupt per event, nothing spurious | `EVT.LINES` | PASS |
| An event set and cleared in the same cycle stays set | §4.1.2 | — | — | RTL. A single-ported bus cannot land a clear and an event on one edge; [`tb/ppu/ppu_irq_tb.sv`](../tb/ppu/ppu_irq_tb.sv) covers it |

### 3.8 Device interface

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| `DEVREQEN` = 0: `DEVQREQn` held HIGH, no handshake, the device's answer ignored, the transition still sequenced | §4.1.3 | `ON → OFF` makes no handshake but does move the device controls and make one PCSM handshake. A busy, refusing device is powered down anyway, with no denial | `DEV.REQEN` | PASS |
| `DEVREQEN` changes only static with the target reached; re-enabled only from `ON` | §4.1.3 | The driver refuses all three misuses: <br>• re-enabling in `OFF` <br>• changing it under a dynamic policy <br>• changing it mid-transition <br>It allows the legal changes, and the handshake returns | `DEV.REQEN` | PASS |
| `WARM_RST_DEVREQEN` | Table 4-4 | All four combinations of (`DEVREQEN`, `WARM_RST_DEVREQEN`): a handshake only for (1,1), never a PCSM handshake | `DEV.WARM` | PASS |
| `PPU_DISR` shows `DEVQACTIVE` | §5.2.4 | Armed and disarmed; also on the first read after the PPU clock was gated; during a device burst | `DEV.STATUS`, `EVT.EDGE` | PASS |
| `PPU_MISR` shows the `DEVQACCEPTn` pin | §5.2.5 | HIGH in `ON`, LOW when quiesced, still HIGH while a request waits on a busy device | `DEV.STATUS` | PASS |
| `PPU_MISR` `DEVDENY_STATUS` and `PCSMPACCEPT_STATUS` | §5.2.5 | — | — | RTL. Each is HIGH for a few cycles, and polling cannot catch it; [`tb/ppu/ppu_regdoc_tb.sv`](../tb/ppu/ppu_regdoc_tb.sv) pins their positions |

### 3.9 Device control delays and ordering

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| `PPU_DCDR0/1` programmable, read back | §5.2.21–5.2.22 | A different set on each of the twelve domains, with fields from 0 to 255 | `DLY` | PASS |
| Each spacing is at least value + 1 PPU cycles | Table 4-5 | Measured at the pins on every hop of the run (4,252 spacings), in the testbench | continuous | PASS |
| ...and is exactly value + 1 | Table 4-5 | `OFF → ON`, `ON → OFF`, `ON → FULL_RET` and `FULL_RET → ON` on all twelve sets (Section 7) | `DLY` | PASS |
| `RST_HWSTAT_DLY` also waits for the device handshake | Table 4-5 | For small values the measured gap is 8 cycles, the exit handshake. For large values it is exactly value + 1. `ppu_monitor` U12 holds the handshake rule throughout | `DLY` | PASS |
| Power-up order (PCSM, isolation, clock, reset, handshake) and power-down order (handshake, clock, isolation, reset, PCSM) | §4.1.5, Figs 4-22, 4-24 | `ppu_power_model` PU1–PU10 and `ppu_monitor` U4–U7 on every transition of the run | continuous | PASS |
| Switch settling: rail on to reset release at least 20 cycles | project decision (`PGOOD_EN` = 0) | Testbench on all 821 power-ups; shortest 21 | continuous | PASS |

### 3.10 Power mode entry delays

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| Each of the five delay fields delays entry to its own mode by value + 1, static | §4.1.3, Fig 4-10 | Latency from the `PPU_PWPR` write to `DEVQREQn` falling, with the mode's field at 0 and every other field at 200, then with its field at D. The difference is exactly D + 1 for all five modes | `EDT.STATIC` | PASS |
| ...and dynamic | §4.1.3 | The same, measured from `DEVQACTIVE` falling | `EDT.DYNAMIC` | PASS |
| Not applied to a higher-priority transition, `ON → WARM_RST` or `WARM_RST → ON` | §4.1.3 | With every field at 200: `OFF → ON` and `WARM_RST → ON` take no longer, and `ON → WARM_RST` starts at the same latency | `EDT.SCOPE` | PASS |
| The count restarts when the conditions go away mid-count | §4.1.3 | `DEVQACTIVE` rises for 15 cycles, 45 cycles into a 101-cycle count. The request then comes a full count after the last fall, and exactly one request is made | `EDT.RESTART` | PASS |
| A value reprogrammed mid-count takes effect only from the next count | §4.1.3 | `OFF_DEL` changed from 100 to 5 during a count: that count stays at 101, and the next is 6 | `EDT.RESTART` | PASS |

### 3.11 PCSM interface

| Feature | DEN 0051E | How it is checked | Check | Status |
|---|---|---|---|---|
| PCSMPSTATE: `[15:8]` the retention byte of the mode entered, `[7:4]` 0, `[3:0]` the mode with `WARM_RST` as `ON` | Table 4-12 | Testbench at every hop. The firmware checks the value at each request, with `FUNRR`, `FULRR` and `MEMRR` distinct on every domain, including the direct `OFF → MEM_RET` | `PCSM.RR` | PASS |
| The retention byte reaches the RAM | §5.2.16–5.2.18 | End to end on 12 domains × 7 modes: <br>• the device fills its 8 RAM banks, visits the mode, returns to `ON` and verifies <br>• the surviving banks are exactly the byte programmed for that mode <br>• all 8 banks survive `ON` and `WARM_RST`, none survive `MEM_OFF` and `OFF` | `PCSM.RAM` | PASS |
| One PCSM handshake per hop, none for `ON ↔ WARM_RST` | §4.1.6 | Counted at the pins | `STA.MATRIX`, `DEV.WARM` | PASS |
| PCSMPSTATE stable while PCSMPREQ is HIGH; `[15:8]` only for the three retention modes | §4.1.6; AMBA LPI | `ppu_monitor` U8, U10, U11 throughout | continuous | PASS |
| PCSMMODESTAT reporting `MEM_RET` at reset | §4.1.6, Table 4-13 | — | — | N/A here: every domain of this SoC is built with `PCSM_RESET_MODESTAT = OFF`. RTL: [`tb/ppu/ppu_reset_tb.sv`](../tb/ppu/ppu_reset_tb.sv) runs all four rows of Table 4-13 |

### 3.12 Reset, clock, and the firmware itself

| Feature | Reference | How it is checked | Check | Status |
|---|---|---|---|---|
| Default policy `OFF`: no transition and no interrupt out of reset | §4.2.1, Table 4-13 | `PWSR` `OFF`, `ISR`/`AISR` 0 at first read | `RST` | PASS |
| The PPU's own clock gates when idle, and every access still completes | PCK-600 clock Q-Channel (not DEN 0051E) | 23,340 gatings over the run, and every AXI access completed | `CLK` | PASS |
| The driver refuses a second `PWR_DYN_EN` change before `PWR_DYN_STATUS` shows the first | §4.1.1 note (new, Section 8) | `ppu_set_policy` returns `PPU_E_STATE` and writes nothing | `DYN.STATUS` | PASS |
| The manager drives every power state of every domain, through the interrupt path | README §5.2 | `pd_boot`, then 85 state changes on eleven domains. The tuple each state programs is checked (policy, dynamic enable, lock, `PWR_DEVACTIVEEN`), along with the mode reached, the lock where the state has one, and zero spurious interrupts | `FW.STATES` | PASS |
| Refused and reverted writes reported as such by the driver | README §6 rules 1–2 | `make scppd` phases P8 and P9 | `pd_multi` | PASS |
| Everything at once | — | Seeded random, 1,500 operations over all twelve domains: static and dynamic policies, wakes, busy and denying devices, refused writes, locks, unlocks, entry delays. Every 75 operations the stimulus stops, and each domain must settle: <br>• where its registers say, or in a lockable mode if locked <br>• with exactly one `UNSPT_POLICY` per refused write <br>• passing its `CHECK` <br>1,053 hops, 20 checkpoints | `SOAK` | PASS |

---

## 4. Deviations, and their fixes

The first run reproduced three deviations, and the low-power checker reported
a fourth. All four are fixed in the RTL (2026-09-29); root causes, fixes and
proofs are in [`rtl/ppu/FIX_PLAN.md`](../rtl/ppu/FIX_PLAN.md), and each fix has
a regression check in the PPU's own suite that fails without it. The rows keep
what the unfixed PPU did, because the firmware's defences were written against
it and remain correct against the fixed PPU. Every row was cross-checked
against the specification text on 2026-09-29; the quotations below are
verbatim, with list bullets dropped.

| # | Finding | Spec | What the unfixed PPU did | Fix | Check now |
|---|---|---|---|---|---|
| 1 | A write-time lock launched the hop it should prevent (`ppu_seq.sv`) | §3.4.3, *Locking the PPU*: locked when "The PPU_PWPR is written with LOCK_EN and PWR_DYN_EN set to 0b1 and: The PPU is in a lockable power mode"; and "When locked the PPU can transition: From OFF_EMU to OFF. From MEM_RET_EMU to MEM_RET." | `locked_q` was set on the same edge that `S_IDLE` launched the first hop toward the new policy, because `hop_needed` read the old `locked_q`. `{OFF}` in `MEM_RET` and `{ON}` in `OFF` ended locked in `ON`, which is not lockable. `{MEM_RET}` in `OFF` ended locked in `MEM_RET` | `lock_on_write`: the lock condition's write branch, combinational, holds `final_tgt` on the write's own cycle. Firmware still writes `LOCK_EN` only in the mode to be held (README §6 rule 7) | `LOCK.RACE` PASS; `ppu_pd_tb` P36; `ppu_lock_probe` CONFORMANT |
| 2 | A disarmed PPU's edge event waited for a bus access (`ppu_top.sv`) | §4.1.3, *DEVACTIVE Enables*: "These enables have no effect on the generation of interrupts. If an interrupt for a DEVACTIVE is unmasked it still generates an interrupt event when the input changes." | `ppuclk_needed` gated `DEVQACTIVE` with `PWR_DEVACTIVEEN`. With the input disarmed, an edge did not restart the gated PPU clock, and the edge detector runs on that clock | While `PPU_IESR` selects an edge, the PPU requests its clock whenever the input differs from what the detector last saw | `EVT.EDGE_OFF` PASS; `ppu_clkq_tb` G9; `ppu_edge_probe` TIMELY |
| 3 | Retention strobes on every power cycle (`ppu_pcsm.sv`) | — (PCSM model, not the PPU; Table 3-1 gives `OFF` and `MEM_RET` Logic Mode OFF) | `ret_n` pulsed on `OFF` and `MEM_RET` entries while the retention rail was off: 606 `LP_SAVE_RETPWRDN` and 594 `LP_RESTORE_RETPWRDN` in the power-aware run | The logic retention machine runs only for Logic Mode RET; RAM retention is untouched | none of either message in `scpstresspa`; `ppu_power_model` PU9; `ppupcsmpg` check M |
| 5 | `STA_POLICY_TRN` condition 1 tested the status, not the register (`ppu_seq.sv`) | §4.1.2, *Full Policy Transition Completion*: "Following the write of a supported policy to PPU_PWPR when the PPU is not in transition, and both PPU_PWPR.PWR_DYN_EN and the PPU_PWPR.OP_DYN_EN are set to 0b0." The fourth condition in the same list names `PPU_PWSR.PWR_DYN_STATUS` where it means the status | `S_IDLE` fired the event when `!dyn_status_q`, which on that cycle still held the enable from before the write. `{m, DYN}` in static `m` raised an event the spec excludes; static `{m}` at dynamic `m` raised none | `!pwr_dyn_en` for `!dyn_status_q` in that one condition | `EVT.PTRN1` PASS; `ppu_pd_tb` P35 |

Finding 4 is in the PCSM model and showed only at `PGOOD_EN = 1`, which this
test cannot reach: a `FULL_RET` handshake completed before the retention save,
a superseded power-down left the retention machine stuck, and at
`PGOOD_EN = 0` nothing waited for either switch. The PCSM now holds
`PCSMPACCEPT` until every step of a transition is done, and has settle-time
parameters for `PGOOD_EN = 0`. `make ppupcsmpg SIM=vcs` is its regression;
README §10.2 item 4 has the details. In this test, the only visible cost is
two cycles on each `FULL_RET` entry and exit.

The low-power checker's other messages in `scpstresspa` are expected:

- 215 `LP_RET_PWR_OFF` warnings: the retention rail drops after each `FULL_RET` restore and discards the shadow copy.
- 12 `LP_ISOEN_INIT_INVALID` and 12 `LP_ISO_SEQFAIL1` warnings at time zero: the isolation enable is X before reset while each `PD_DEV` starts unpowered.

None of them reaches the verdict.

---

## 5. Not applicable, and not reachable from firmware

**Not in this PPU.** The specification makes these unavailable to a
single-Q-Channel PPU without operating modes. Where firmware can ask for one,
it is refused, and `EVT.UNSPT` checks the refusal.

| Function | Why |
|---|---|
| Operating modes: `OP_POLICY`, `OP_DYN_EN`, `OP_STATUS`, `PPU_OPSR`, the power- and operating-policy completion events | P-Channel only (§3.1.2); `IDR1[10:8]` = 0 |
| Emulation modes `OFF_EMU`, `MEM_RET_EMU`: `PPU_PMER`, `EMU_ACCEPT`/`EMU_DENY` | Optional, not built (§7) |
| `LOGIC_RET`, `DBG_RECOV`, `DBG_RECOV_PORST_EN` | Always 0 for a Q-Channel PPU (Table 5-26) |
| Multiple device channels; `PPU_STSR` | One channel (§5.2.6: "reserved" for a single Q-Channel) |
| P-Channel device interface; `DEV_PREQ_DLY` | This is a Q-Channel PPU |
| Dynamic `WARM_RST` | Excluded for a Q-Channel PPU (§3.4.3) |
| Lock on a denied exit from a lockable mode | Unreachable on a Q-Channel PPU; see Section 3.5 |
| PCSMMODESTAT = `MEM_RET` at reset | Not in this SoC's configuration; see Section 3.11 |

**Real, but out of firmware's reach.** Each is covered by the RTL suite and
recorded in [`rtl/ppu/CONFORMANCE.md`](../rtl/ppu/CONFORMANCE.md):

- Set beats clear in the same cycle: [`ppu_irq_tb`](../tb/ppu/ppu_irq_tb.sv).
- `MISR` `DEVDENY`/`PCSMPACCEPT` status bits: [`ppu_regdoc_tb`](../tb/ppu/ppu_regdoc_tb.sv).
- Simultaneous read and write of one register: one outstanding access from a single-issue core cannot produce it.
- Reset asserted mid-transition: [`ppu_rstflight_tb`](../tb/ppu/ppu_rstflight_tb.sv).
- Reduced build configurations: [`ppu_minconfig_tb`](../tb/ppu/ppu_minconfig_tb.sv).

---

## 6. Do the checks see anything?

Five defects were planted in the PPU RTL one at a time, and the full stress
test was run on each. Every file was restored byte-for-byte afterwards and
confirmed clean with `git diff`.

| Planted defect | File | Caught by | Testbench errors |
|---|---|---|---:|
| `FULL_RET` drives `DEVRETRESETn` LOW (Table 4-9) | `ppu_pkg.sv` | 14 features, through the device-control row checks at every hop | 344 |
| Static `DEVQACTIVE` gate only in `ON` (the old F9) | `ppu_seq.sv` | `STA.QACT` alone | 0 |
| `STA_ACCEPT` only on the final hop | `ppu_seq.sv` | `STA.MATRIX`, `STA.MIDWRITE`, `DENY` | 0 |
| `STA_DENY` status ignores its mask | `ppu_irq.sv` | `EVT.MASK` alone | 0 |
| `ISO_RST_DLY` counted at half its value | `ppu_seq.sv` | 31 features, through the Table 4-5 spacing checks | 812 |

All five were caught. The defects in behaviour that only a firmware check can
see were each caught by exactly the feature written for them.

---

## 7. Measurements

**Device control delays.** Measured at the pins with a different `PPU_DCDR0/1`
on each domain, in cycles. The spacings are 8 bits wide in the observation
window, so 255 means "at least 255". `rst>hw` includes the device's exit
handshake, which takes 8 cycles.

| Domain | `DCDR0` | `DCDR1` | iso>clk | clk>rst | rst>hw | clk>iso | iso>rst |
|---|---|---|---:|---:|---:|---:|---:|
| CPU0 | 0x001400 | 0x0000 | 21 | 1 | 8 | 1 | 1 |
| CPU1 | 0x010e01 | 0x0101 | 15 | 2 | 8 | 2 | 2 |
| CPU2 | 0x021404 | 0x0202 | 21 | 5 | 8 | 3 | 3 |
| CPU3 | 0x070907 | 0x0707 | 10 | 8 | 8 | 8 | 8 |
| DSP0 | 0x1f0f1f | 0x1f1f | 16 | 32 | 32 | 32 | 32 |
| DSP1 | 0x3f013f | 0x003f | 2 | 64 | 64 | 1 | 64 |
| DSP2 | 0x643200 | 0x6400 | 51 | 1 | 101 | 101 | 1 |
| DSP3 | 0xffffff | 0xffff | 255 | 255 | 255 | 255 | 255 |
| NPU0 | 0x0c1e02 | 0x0509 | 31 | 3 | 13 | 6 | 10 |
| NPU1 | 0x001000 | 0xc800 | 17 | 1 | 8 | 201 | 1 |
| NPU2 | 0xc80311 | 0x03c8 | 4 | 18 | 201 | 4 | 201 |
| NPU3 | 0x096309 | 0x0963 | 100 | 10 | 10 | 10 | 100 |

**Entry delays.** The start latency is from the trigger to `DEVQREQn` falling.

| Transition | Delay D | Latency with D | Latency with 0 | Difference |
|---|---:|---:|---:|---:|
| static `ON → OFF` | 30 | 34 | 3 | 31 |
| static `ON → MEM_RET` | 50 | 54 | 3 | 51 |
| static `ON → FULL_RET` | 70 | 74 | 3 | 71 |
| static `ON → MEM_OFF` | 90 | 94 | 3 | 91 |
| static `ON → FUNC_RET` | 110 | 114 | 3 | 111 |
| dynamic `ON → OFF` | 25 | 30 | 4 | 26 |
| dynamic `ON → MEM_RET` | 40 | 45 | 4 | 41 |
| dynamic `ON → FULL_RET` | 55 | 60 | 4 | 56 |
| dynamic `ON → MEM_OFF` | 70 | 75 | 4 | 71 |
| dynamic `ON → FUNC_RET` | 85 | 90 | 4 | 86 |

For the restart and reprogramming cases, `OFF_DEL` = 100 gives 105 cycles with
a blip or without one. Reprogramming to 5 mid-count still gives 105, and the
next count gives 10.

---

## 8. What was added to make this possible

**Testbench** (`tb/pmu/pmu_tb.sv`, removed 2026-10-02; [`tb/pmu/scp_sim_ctrl.sv`](../tb/pmu/scp_sim_ctrl.sv)):

- the observation window: 32 words per domain
- the spec-table checks at every committed hop
- the Table 4-5 spacing checks
- `TB_ERRORS`, which now includes every monitor, power-model, AXI and settle violation, so each feature can be failed by what the hardware did during it
- control of the device IP's RAM fill and verify
- a 12-bit device burst counter, set by a `CNT_W` override on `pmu_top`; no RTL changed

**Firmware:**

- **Rule 10, `PWR_DYN_EN` changes wait for `PWR_DYN_STATUS`** (README §6).
  `ppu_set_policy` returns `PPU_E_STATE` for a write that would change the
  enable before the last change shows. `ppu_dyn_settled()` reports whether it
  has. `pd_set_state` and `pd_request_mode` wait for it before writing, and a
  refusal reaching the caller is `PD_E_BUSY`. Before this, nothing stopped two
  quick state changes from breaking the rule. §4.1.1 calls the result
  UNPREDICTABLE.
- `pd_events.sta_accept` is now counted when a caller unmasks the event.
- `make scpstress` and `make scpstresspa`. `make scppdpa` now takes
  `PA_PROG=`/`PA_ARGS=`.

`make scppd`, `make scphello` and the two deviation probes were rerun after
these changes and behave as before.

---

## 9. Limits

- **One PPU configuration**, the one this SoC builds. What changes with the
  build parameters is covered by `ppu_minconfig_tb`, not here.
- **VCS only.** The Xcelium forms of these targets elaborate but cannot run
  until the licence is renewed.
- **One apparent ambiguity is settled by the text.** From `FULL_RET` with a
  static policy of `FUNC_RET` and `DEVQACTIVE` HIGH, the PPU climbs to `ON` and
  holds there. §3.4.2 says "The power mode DEVACTIVE inputs do not delay
  transitions to higher priority power modes", which could read as forbidding
  the hold. But page 3-19, *Intermediate Power Mode Transitions*, requires that
  "upon reaching an intermediate power mode the PPU must consider the current
  power mode, programmed policy, and DEVACTIVE inputs before making further
  transitions". At the intermediate `ON` the next hop is a transition from
  `ON`, and "For transitions from ON, other than to WARM_RST, all DEVQACTIVE
  inputs must be LOW to begin a transition." The hold is what the spec
  requires.
- **Denial is reachable only with the input disarmed.** With
  `PWR_DEVACTIVEEN` = 1, a busy device holds `DEVQACTIVE` HIGH and the PPU
  never asks it to quiesce. The denial features therefore clear the enable
  first. `ppu_pd_tb` P5, P18 and P27 do the same.
- **The vendored Ibex draws 182 VCS warnings** of the form
  `RT-MTOCMUCS: More than one condition match` on `ibex_alu.sv:91`. That is a
  `unique case (1'b1)` over "multiply/divide owns the adder" and "negate
  operand B". The decoder gives every RV32M instruction `ALU_ADD`, so the two
  cannot both hold for one settled instruction. The warnings fall on clock
  edges, and only while the soak's random-number modulo and the byte-lane
  test's table indexing run. That points to a zero-time glitch as the next
  instruction's operator arrives, not a wrong result, and every arithmetic
  check in the run passed. `pd_multi` does not trigger it.
