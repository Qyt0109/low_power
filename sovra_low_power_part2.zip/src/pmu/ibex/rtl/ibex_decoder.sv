// Copyright lowRISC contributors.
// Copyright 2018 ETH Zurich and University of Bologna, see also CREDITS.md.
// Copyright Microsoft Corporation
// Licensed under the Apache License, Version 2.0, see LICENSE for details.
// SPDX-License-Identifier: Apache-2.0


/**
 * Instruction decoder
 */

module ibex_decoder import ibex_cheriot_pkg::*; #(
  parameter bit RV32E               = 0,
  parameter ibex_pkg::rv32m_e RV32M = ibex_pkg::RV32MFast,
  parameter ibex_pkg::rv32b_e RV32B = ibex_pkg::RV32BNone,
  parameter bit BranchTargetALU     = 0,
  parameter ibex_pkg::base_isa_e BaseIsa        = ibex_pkg::BaseIsaRV32IorCHERIoT
) (
  input  ibex_pkg::ibex_mubi_t cheriot_enable_i,

  // to/from controller
  output logic                 illegal_insn_o,        // illegal instr encountered
  output logic                 ebrk_insn_o,           // trap instr encountered
  output logic                 mret_insn_o,           // return from exception instr
                                                      // encountered
  output logic                 dret_insn_o,           // return from debug instr encountered
  output logic                 ecall_insn_o,          // syscall instr encountered
  output logic                 wfi_insn_o,            // wait for interrupt instr encountered
  output logic                 jump_set_o,            // jump taken set signal
  input  logic                 branch_taken_i,        // registered branch decision
  output logic                 icache_inval_o,

  // from IF-ID pipeline register
  input  logic                 instr_first_cycle_i,   // instruction read is in its first cycle
  input  logic [31:0]          instr_rdata_i,         // instruction read from memory/cache
  input  logic [31:0]          instr_rdata_alu_i,     // instruction read from memory/cache
                                                      // replicated to ease fan-out)

  input  logic                 illegal_c_insn_i,      // compressed instruction decode failed

  // immediates
  output ibex_pkg::imm_a_sel_e  imm_a_mux_sel_o,       // immediate selection for operand a
  output ibex_pkg::imm_b_sel_e  imm_b_mux_sel_o,       // immediate selection for operand b
  output ibex_pkg::op_a_sel_e   bt_a_mux_sel_o,        // branch target selection operand a
  output ibex_pkg::imm_b_sel_e  bt_b_mux_sel_o,        // branch target selection operand b
  output logic [31:0]           imm_i_type_o,
  output logic [31:0]           imm_s_type_o,
  output logic [31:0]           imm_b_type_o,
  output logic [31:0]           imm_u_type_o,
  output logic [31:0]           imm_j_type_o,
  output logic [31:0]           zimm_rs1_type_o,

  // register file
  output ibex_pkg::rf_wd_sel_e rf_wdata_sel_o,   // RF write data selection
  output logic                 rf_we_o,          // write enable for regfile
  output logic                 rf_we_or_load_o,
  output logic [4:0]           rf_raddr_a_o,
  output logic [4:0]           rf_raddr_b_o,
  output logic [4:0]           rf_waddr_o,
  output logic                 rf_ren_a_o,          // Instruction reads from RF addr A
  output logic                 rf_ren_b_o,          // Instruction reads from RF addr B

  // ALU
  output ibex_pkg::alu_op_e    alu_operator_o,        // ALU operation selection
  output ibex_pkg::op_a_sel_e  alu_op_a_mux_sel_o,    // operand a selection: reg value, PC,
                                                      // immediate or zero
  output ibex_pkg::op_b_sel_e  alu_op_b_mux_sel_o,    // operand b selection: reg value or
                                                      // immediate

  // MULT & DIV
  output logic                 mult_en_o,             // perform integer multiplication
  output logic                 div_en_o,              // perform integer division or remainder
  output logic                 mult_sel_o,            // as above but static, for data muxes
  output logic                 div_sel_o,             // as above but static, for data muxes

  output ibex_pkg::md_op_e     multdiv_operator_o,
  output logic [1:0]           multdiv_signed_mode_o,

  // CSRs
  output logic                 csr_access_o,          // access to CSR
  output ibex_pkg::csr_op_e    csr_op_o,              // operation to perform on CSR
  output ibex_pkg::csr_num_e   csr_addr_o,            // CSR address
  output logic                 csr_cheriot_always_ok_o, // CHERIoT safe-listed (no ASR needed) CSRs

  // LSU
  output logic                 data_req_o,            // start transaction to data memory
  output logic                 cheriot_data_req_o,      // cheriot lsu transaction
  output logic                 data_we_o,             // write enable
  output logic [1:0]           data_type_o,           // size of transaction: byte, half
                                                      // word or word
  output logic                 data_sign_extension_o, // sign extension for data read from
                                                      // memory

  // jump/branches
  output logic                 jump_in_dec_o,         // jump is being calculated in ALU
  output logic                 branch_in_dec_o,

  // output to cheriot EX
  output logic                   instr_is_cheriot_o,
  output logic                   instr_is_legal_cheriot_o,
  output logic [11:0]            cheriot_imm12_o,
  output logic [19:0]            cheriot_imm20_o,
  output logic [20:0]            cheriot_imm21_o,
  output cheriot_op_t            cheriot_operator_o,
  output logic [4:0]             cheriot_cs2_dec_o,
  output cheriot_cap_field_e     cheriot_cap_field_sel_o,
  output cheriot_adder_a_sel_e   cheriot_adder_a_sel_o,
  output cheriot_adder_b_sel_e   cheriot_adder_b_sel_o,
  output cheriot_setaddr_sel_e   cheriot_setaddr_sel_o,
  output cheriot_setbounds_sel_e cheriot_setbounds_sel_o
);

  import ibex_pkg::*;

  localparam bit CheriLimit16Regs = (BaseIsa == BaseIsaRV32IorCHERIoT);

  logic        illegal_insn;
  logic        illegal_reg_16;
  logic        csr_illegal;
  logic        rf_we;

  logic [31:0] instr;
  logic [31:0] instr_alu;
  logic [9:0]  unused_instr_alu;
  // Source/Destination register instruction index
  logic [4:0] instr_rs1;
  logic [4:0] instr_rs2;
  logic [4:0] instr_rd;

  csr_op_e     csr_op;

  opcode_e     opcode;
  opcode_e     opcode_alu;

  logic        instr_is_legal_cheriot;

  // To help timing the flops containing the current instruction are replicated to reduce fan-out.
  // instr_alu is used to determine the ALU control logic and associated operand/imm select signals
  // as the ALU is often on the more critical timing paths. instr is used for everything else.
  assign instr     = instr_rdata_i;
  assign instr_alu = instr_rdata_alu_i;

  //////////////////////////////////////
  // Register and immediate selection //
  //////////////////////////////////////

  // immediate extraction and sign extension
  assign imm_i_type_o = { {20{instr[31]}}, instr[31:20] };
  assign imm_s_type_o = { {20{instr[31]}}, instr[31:25], instr[11:7] };
  assign imm_b_type_o = { {19{instr[31]}}, instr[31], instr[7], instr[30:25], instr[11:8], 1'b0 };
  assign imm_u_type_o = { instr[31:12], 12'b0 };
  assign imm_j_type_o = { {12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0 };

  assign csr_addr_o = csr_num_e'(instr[31:20]);

  // immediate for CSR manipulation (zero extended)
  assign zimm_rs1_type_o = { 27'b0, instr_rs1 }; // rs1

  // source registers
  assign instr_rs1 = instr[19:15];
  assign instr_rs2 = instr[24:20];

  // read cx3 if AUICGP
  // note for GDC (c3) we want to use the regular scheme to resovel data hazards, instead of using
  // sideband signals to export CX3 from register file directly
  logic [4:0] raddr_a, raddr_b;
  assign raddr_a = cheriot_operator_o.CAUICGP ? 5'h3 : instr_rs1; // c3 / rs1
  assign raddr_b = instr_rs2; // rs2

  // cheriot only uses 16 registers and repurposes the MSB addr bits
  // destination register
  assign instr_rd = instr[11:7];
  // In CHERIoT mode all instructions (both CHERIoT-specific and standard RV32I) are limited to
  // x0-x15.
  if (CheriLimit16Regs) begin : gen_16_regs
    assign rf_raddr_a_o = (cheriot_enable_i == IbexMuBiOn) ?
                          {1'b0,  raddr_a[3:0]} : raddr_a;
    assign rf_raddr_b_o = (cheriot_enable_i == IbexMuBiOn) ?
                          {1'b0,  raddr_b[3:0]} : raddr_b;
    assign rf_waddr_o   = (cheriot_enable_i == IbexMuBiOn) ?
                          {1'b0, instr_rd[3:0]} : instr_rd;
  end else begin : gen_regs
    assign rf_raddr_a_o = raddr_a;
    assign rf_raddr_b_o = raddr_b;
    assign rf_waddr_o   = instr_rd;
  end

  ////////////////////
  // Register check //
  ////////////////////

  // rf_we from decoder doesn't cover memory load case (where regfile write signal
  // comes from LSU response)
  logic rf_we_or_load;
  assign rf_we_or_load = rf_we | (opcode == OPCODE_LOAD);

  assign rf_we_or_load_o = rf_we_or_load;

  // RV32E and CHERIoT both enforce a 16-register address space (CheriLimit16Regs implies RV32E).
  // RV32E is a static build choice (unconditional); CHERIoT is runtime-gated on cheriot_enable_i.
  if (RV32E || CheriLimit16Regs) begin : gen_16reg_check_active
    assign illegal_reg_16 = (RV32E || (cheriot_enable_i == IbexMuBiOn)) &&
                            ((raddr_a[4]   && rf_ren_a_o) ||
                             (raddr_b[4]   && rf_ren_b_o) ||
                             (instr_rd[4]  && rf_we_or_load));
  end else begin : gen_16reg_check_inactive
    assign illegal_reg_16 = 1'b0;
  end

  ///////////////////////
  // CSR operand check //
  ///////////////////////
  always_comb begin : csr_operand_check
    csr_op_o = csr_op;

    // CSRRSI/CSRRCI must not write 0 to CSRs (uimm[4:0]=='0)
    // CSRRS/CSRRC must not write from x0 to CSRs (rs1=='0)
    if ((csr_op == CSR_OP_SET || csr_op == CSR_OP_CLEAR) &&
        instr_rs1 == '0) begin
      csr_op_o = CSR_OP_READ;
    end
  end

  /////////////
  // Decoder //
  /////////////

  always_comb begin
    jump_in_dec_o           = 1'b0;
    jump_set_o              = 1'b0;
    branch_in_dec_o         = 1'b0;
    icache_inval_o          = 1'b0;

    multdiv_operator_o      = MD_OP_MULL;
    multdiv_signed_mode_o   = 2'b00;

    rf_wdata_sel_o          = RF_WD_EX;
    rf_we                   = 1'b0;
    rf_ren_a_o              = 1'b0;
    rf_ren_b_o              = 1'b0;

    csr_access_o            = 1'b0;
    csr_illegal             = 1'b0;
    csr_op                  = CSR_OP_READ;
    csr_cheriot_always_ok_o = 1'b0;

    data_we_o               = 1'b0;
    data_type_o             = 2'b00;
    data_sign_extension_o   = 1'b0;
    data_req_o              = 1'b0;
    cheriot_data_req_o      = 1'b0;

    illegal_insn            = 1'b0;
    ebrk_insn_o             = 1'b0;
    mret_insn_o             = 1'b0;
    dret_insn_o             = 1'b0;
    ecall_insn_o            = 1'b0;
    wfi_insn_o              = 1'b0;

    cheriot_operator_o      = '0;
    instr_is_cheriot_o      = 1'b0;
    cheriot_cap_field_sel_o = CFIELD_PERM;
    cheriot_adder_a_sel_o   = CHERIOT_ADDER_A_ZERO;
    cheriot_adder_b_sel_o   = CHERIOT_ADDER_B_ZERO;
    cheriot_setaddr_sel_o   = SETADDR_NONE;
    cheriot_setbounds_sel_o = SETBOUNDS_NONE;

    opcode                  = opcode_e'(instr[6:0]);

    unique case (opcode)

      ///////////
      // Jumps //
      ///////////

      OPCODE_JAL: begin   // Jump and Link
        if ((BaseIsa == BaseIsaRV32IorCHERIoT) & (cheriot_enable_i == IbexMuBiOn) &
            ~illegal_c_insn_i) begin
          // cheriot_ex takes over JAL now as a single-cycle jump
          cheriot_operator_o.CJAL = 1'b1;
          instr_is_cheriot_o      = 1'b1;
          illegal_insn            = 1'b0;
          rf_we                   = 1'b1;
          cheriot_adder_a_sel_o   = CHERIOT_ADDER_A_IMM21;
          cheriot_adder_b_sel_o   = CHERIOT_ADDER_B_PC;
          cheriot_setaddr_sel_o   = SETADDR_PCC_PCNXT;
        end else begin
          jump_in_dec_o     = 1'b1;

          if (instr_first_cycle_i) begin
            // Calculate jump target (and store PC + 4 if BranchTargetALU is configured)
            rf_we            = BranchTargetALU;
            jump_set_o       = 1'b1;
          end else begin
            // Calculate and store PC+4
            rf_we            = 1'b1;
          end
        end
      end

      OPCODE_JALR: begin  // Jump and Link Register
        if ((BaseIsa == BaseIsaRV32IorCHERIoT) & (cheriot_enable_i == IbexMuBiOn) &
            ~illegal_c_insn_i) begin
          // cheriot_ex takes over JALR now as a single-cycle jump
          if (instr[14:12] == 3'b0) cheriot_operator_o.CJALR = 1'b1;
          instr_is_cheriot_o    = 1'b1;
          rf_ren_a_o            = 1'b1;
          rf_we                 = 1'b1;
          cheriot_adder_a_sel_o = CHERIOT_ADDER_A_IMM12;
          cheriot_adder_b_sel_o = CHERIOT_ADDER_B_RS1;
          cheriot_setaddr_sel_o = SETADDR_PCC_PCNXT;

          if (instr[14:12] != 3'b0) begin
            illegal_insn    = 1'b1;
          end
        end else begin
          jump_in_dec_o      = 1'b1;

          if (instr_first_cycle_i) begin
            // Calculate jump target (and store PC + 4 if BranchTargetALU is configured)
            rf_we            = BranchTargetALU;
            jump_set_o       = 1'b1;
          end else begin
            // Calculate and store PC+4
            rf_we            = 1'b1;
          end
          if (instr[14:12] != 3'b0) begin
            illegal_insn = 1'b1;
          end

          rf_ren_a_o = 1'b1;
        end
      end

      OPCODE_BRANCH: begin // Branch
        branch_in_dec_o       = 1'b1;
        // Check branch condition selection
        unique case (instr[14:12])
          3'b000,
          3'b001,
          3'b100,
          3'b101,
          3'b110,
          3'b111:  illegal_insn = 1'b0;
          default: illegal_insn = 1'b1;
        endcase

        rf_ren_a_o = 1'b1;
        rf_ren_b_o = 1'b1;
      end

      ////////////////
      // Load/store //
      ////////////////

      OPCODE_STORE: begin
        rf_ren_a_o         = 1'b1;
        rf_ren_b_o         = 1'b1;
        data_req_o         = 1'b1;  // keep this to pass LEC w/ ibex
        data_we_o          = 1'b1;

        if (instr[14]) begin
          illegal_insn     = 1'b1;
        end else if (instr[13:12] == 2'b11) begin
          if ((BaseIsa == BaseIsaRV32IorCHERIoT) & (cheriot_enable_i == IbexMuBiOn)) begin
            cheriot_operator_o.CSTORE_CAP = ~illegal_c_insn_i;
            instr_is_cheriot_o            = ~illegal_c_insn_i;
            cheriot_data_req_o            = ~illegal_c_insn_i;
            data_req_o                    = 1'b0;
            illegal_insn                  = 1'b0;
          end else begin
            cheriot_data_req_o = 1'b0;
            illegal_insn       = 1'b1;
          end
        end

        // store size
        unique case (instr[13:12])
          2'b00:   data_type_o  = 2'b10; // sb
          2'b01:   data_type_o  = 2'b01; // sh
          2'b10:   data_type_o  = 2'b00; // sw
          default: data_type_o  = 2'b00;
        endcase

      end

      OPCODE_LOAD: begin
        rf_ren_a_o          = 1'b1;
        data_req_o          = 1'b1;
        data_type_o         = 2'b00;

        // sign/zero extension
        data_sign_extension_o = ~instr[14];

        // load size
        unique case (instr[13:12])
          2'b00: data_type_o = 2'b10; // lb(u)
          2'b01: data_type_o = 2'b01; // lh(u)
          2'b10: begin
            data_type_o = 2'b00;      // lw
            if (instr[14]) begin
              illegal_insn = 1'b1;    // lwu does not exist
            end
          end
          2'b11: begin
            // illegal_c_insn_i is added to fix the c.clcsp case
            //   (compressed decoder translate to cheriot instruction but could still
            //   assert illegal_c_insn
            //   if rd == 0
            if ((BaseIsa == BaseIsaRV32IorCHERIoT) & (cheriot_enable_i == IbexMuBiOn) &&
                ~instr[14] && ~illegal_c_insn_i) begin
              cheriot_operator_o.CLOAD_CAP = 1'b1;
              instr_is_cheriot_o           = 1'b1;
              cheriot_data_req_o           = 1'b1;
              data_req_o                   = 1'b0;    // req generated by cheriot_ex
              illegal_insn                 = 1'b0;
            end else begin                // CHERIoT consider instr[14]=1 illegal
              cheriot_data_req_o = 1'b0;
              illegal_insn       = 1'b1;
            end
          end
          default: begin
            illegal_insn = 1'b1;
          end
        endcase
      end

      /////////
      // ALU //
      /////////

      OPCODE_LUI: begin  // Load Upper Immediate
        rf_we            = 1'b1;
      end

      OPCODE_AUIPC: begin
        if ((BaseIsa == BaseIsaRV32IorCHERIoT) & (cheriot_enable_i == IbexMuBiOn) &
            ~illegal_c_insn_i) begin
          cheriot_operator_o.CAUIPCC = 1'b1;
          instr_is_cheriot_o         = 1'b1;
          illegal_insn               = 1'b0;
          rf_we                      = 1'b1;
          cheriot_adder_a_sel_o      = CHERIOT_ADDER_A_IMM20;
          cheriot_adder_b_sel_o      = CHERIOT_ADDER_B_PC;
          cheriot_setaddr_sel_o      = SETADDR_PCC_ARITH;
        end else begin
          rf_we = 1'b1;
        end
      end

      OPCODE_OP_IMM: begin // Register-Immediate ALU Operations
        rf_ren_a_o       = 1'b1;
        rf_we            = 1'b1;

        unique case (instr[14:12])
          3'b000,
          3'b010,
          3'b011,
          3'b100,
          3'b110,
          3'b111: illegal_insn = 1'b0;

          3'b001: begin
            unique case (instr[31:27])
              5'b0_0000: illegal_insn = (instr[26:25] == 2'b00) ? 1'b0 : 1'b1;        // slli
              5'b0_1001,                                                              // bclri
              5'b0_0101,                                                              // bseti
              5'b0_1101: illegal_insn = (RV32B != RV32BNone) ?                        // binvi
                         (instr[26:25] != 2'b00) : 1'b1;
              5'b0_0001: begin
                // zip (Zbkb): shfli with shamt fixed to 0x0F
                if (instr[26:20] == 7'b000_1111) begin                                // zip
                  illegal_insn = (RV32B == RV32BFull) ? 1'b0 : 1'b1;
                end else begin
                  illegal_insn = 1'b1;
                end
              end
              5'b0_1100: begin
                unique case(instr[26:20])
                  7'b000_0000,                                                         // clz
                  7'b000_0001,                                                         // ctz
                  7'b000_0010,                                                         // cpop
                  7'b000_0100,                                                         // sext.b
                  7'b000_0101: illegal_insn = (RV32B != RV32BNone) ? 1'b0 : 1'b1;      // sext.h
                  default: illegal_insn = 1'b1;
                endcase
              end
              default : illegal_insn = 1'b1;
            endcase
          end

          3'b101: begin
            if (instr[26]) begin
              illegal_insn = 1'b1;
            end else begin
              unique case (instr[31:27])
                5'b0_0000,                                                             // srli
                5'b0_1000: illegal_insn = (instr[26:25] == 2'b00) ? 1'b0 : 1'b1;       // srai

                5'b0_1100,                                                             // rori
                5'b0_1001: illegal_insn = (RV32B != RV32BNone) ?                       // bexti
                           (instr[26:25] != 2'b00) : 1'b1;

                5'b0_1101: begin
                  // rev8 (Zbb, shamt 0x18) and brev8 (Zbkb, shamt 0x07)
                  if (instr[25:20] == 6'b01_1000) begin
                    illegal_insn = (RV32B != RV32BNone) ? 1'b0 : 1'b1;                // rev8
                  end else if (instr[25:20] == 6'b00_0111) begin
                    illegal_insn = (RV32B == RV32BFull) ? 1'b0 : 1'b1;                // brev8
                  end else begin
                    illegal_insn = 1'b1;
                  end
                end
                5'b0_0101: begin
                  // orc.b (Zbb): gorci restricted to shamt 0x07
                  illegal_insn = (instr[25:20] == 6'b00_0111 && RV32B != RV32BNone) ?
                                 1'b0 : 1'b1;                                         // orc.b
                end
                5'b0_0001: begin
                  // unzip (Zbkb): unshfli with shamt fixed to 0x0F
                  illegal_insn = (instr[26:20] == 7'b000_1111 && RV32B == RV32BFull) ?
                                 1'b0 : 1'b1;
                end

                default: illegal_insn = 1'b1;
              endcase
            end
          end

          default: illegal_insn = 1'b1;
        endcase
      end

      OPCODE_OP: begin  // Register-Register ALU operation
        rf_ren_a_o      = 1'b1;
        rf_ren_b_o      = 1'b1;
        rf_we           = 1'b1;
        unique case ({instr[31:25], instr[14:12]})
          // RV32I ALU operations
          {7'b000_0000, 3'b000},
          {7'b010_0000, 3'b000},
          {7'b000_0000, 3'b010},
          {7'b000_0000, 3'b011},
          {7'b000_0000, 3'b100},
          {7'b000_0000, 3'b110},
          {7'b000_0000, 3'b111},
          {7'b000_0000, 3'b001},
          {7'b000_0000, 3'b101},
          {7'b010_0000, 3'b101}: illegal_insn = 1'b0;

          // RV32B zba
          {7'b001_0000, 3'b010}, // sh1add
          {7'b001_0000, 3'b100}, // sh2add
          {7'b001_0000, 3'b110}, // sh3add
          // RV32B zbb
          {7'b010_0000, 3'b111}, // andn
          {7'b010_0000, 3'b110}, // orn
          {7'b010_0000, 3'b100}, // xnor
          {7'b011_0000, 3'b001}, // rol
          {7'b011_0000, 3'b101}, // ror
          {7'b000_0101, 3'b100}, // min
          {7'b000_0101, 3'b110}, // max
          {7'b000_0101, 3'b101}, // minu
          {7'b000_0101, 3'b111}, // maxu
          // RV32B zbs
          {7'b010_0100, 3'b001}, // bclr
          {7'b001_0100, 3'b001}, // bset
          {7'b011_0100, 3'b001}, // binv
          {7'b010_0100, 3'b101}: illegal_insn = (RV32B != RV32BNone) ? 1'b0 : 1'b1; // bext
          // RV32B zbb / zbkb
          {7'b000_0100, 3'b100}: begin // pack / zext.h
            // zext.h (Zbb) = pack rd, rs1, x0; general pack is Zbkb (RV32BFull only).
            if (instr[24:20] == 5'b0_0000) begin
              illegal_insn = (RV32B != RV32BNone) ? 1'b0 : 1'b1;                    // zext.h
            end else begin
              illegal_insn = (RV32B == RV32BFull) ? 1'b0 : 1'b1;                    // pack
            end
          end
          {7'b000_0100, 3'b111}: illegal_insn = (RV32B == RV32BFull) ? 1'b0 : 1'b1; // packh
          // RV32B zbkx
          {7'b001_0100, 3'b010}, // xperm4
          {7'b001_0100, 3'b100}, // xperm8
          // RV32B zbc
          {7'b000_0101, 3'b001}, // clmul
          {7'b000_0101, 3'b010}, // clmulr
          {7'b000_0101, 3'b011}: begin // clmulh
            illegal_insn = (RV32B == RV32BFull) ? 1'b0 : 1'b1;
          end

          // RV32M instructions
          {7'b000_0001, 3'b000}: begin // mul
            multdiv_operator_o    = MD_OP_MULL;
            multdiv_signed_mode_o = 2'b00;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          {7'b000_0001, 3'b001}: begin // mulh
            multdiv_operator_o    = MD_OP_MULH;
            multdiv_signed_mode_o = 2'b11;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          {7'b000_0001, 3'b010}: begin // mulhsu
            multdiv_operator_o    = MD_OP_MULH;
            multdiv_signed_mode_o = 2'b01;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          {7'b000_0001, 3'b011}: begin // mulhu
            multdiv_operator_o    = MD_OP_MULH;
            multdiv_signed_mode_o = 2'b00;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          {7'b000_0001, 3'b100}: begin // div
            multdiv_operator_o    = MD_OP_DIV;
            multdiv_signed_mode_o = 2'b11;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          {7'b000_0001, 3'b101}: begin // divu
            multdiv_operator_o    = MD_OP_DIV;
            multdiv_signed_mode_o = 2'b00;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          {7'b000_0001, 3'b110}: begin // rem
            multdiv_operator_o    = MD_OP_REM;
            multdiv_signed_mode_o = 2'b11;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          {7'b000_0001, 3'b111}: begin // remu
            multdiv_operator_o    = MD_OP_REM;
            multdiv_signed_mode_o = 2'b00;
            illegal_insn          = (RV32M == RV32MNone) ? 1'b1 : 1'b0;
          end
          default: begin
            illegal_insn = 1'b1;
          end
        endcase
      end

      /////////////
      // Special //
      /////////////

      OPCODE_MISC_MEM: begin
        unique case (instr[14:12])
          3'b000: begin
            // FENCE is treated as a NOP since all memory operations are already strictly ordered.
            rf_we           = 1'b0;
          end
          3'b001: begin
            // FENCE.I is implemented as a jump to the next PC, this gives the required flushing
            // behaviour (iside prefetch buffer flushed and response to any outstanding iside
            // requests will be ignored).
            // If present, the ICache will also be flushed.
            jump_in_dec_o   = 1'b1;

            rf_we           = 1'b0;

            if (instr_first_cycle_i) begin
              jump_set_o       = 1'b1;
              icache_inval_o   = 1'b1;
            end
          end
          default: begin
            illegal_insn       = 1'b1;
          end
        endcase
      end

      OPCODE_SYSTEM: begin
        if (instr[14:12] == 3'b000) begin
          // non CSR related SYSTEM instructions
          unique case (instr[31:20])
            12'h000:  // ECALL
              // environment (system) call
              ecall_insn_o = 1'b1;

            12'h001:  // ebreak
              // debugger trap
              ebrk_insn_o = 1'b1;

            12'h302:  // mret
              mret_insn_o = 1'b1;

            12'h7b2:  // dret
              dret_insn_o = 1'b1;

            12'h105:  // wfi
              wfi_insn_o = 1'b1;

            default:
              illegal_insn = 1'b1;
          endcase

          // rs1 and rd must be 0
          if (instr_rs1 != 5'b0 || instr_rd != 5'b0) begin
            illegal_insn = 1'b1;
          end
        end else begin
          // instruction to read/modify CSR
          csr_access_o     = 1'b1;
          rf_wdata_sel_o   = RF_WD_CSR;
          rf_we            = 1'b1;

          if (~instr[14]) begin
            rf_ren_a_o         = 1'b1;
          end

          unique case (instr[13:12])
            2'b01:   csr_op = CSR_OP_WRITE;
            2'b10:   csr_op = CSR_OP_SET;
            2'b11:   csr_op = CSR_OP_CLEAR;
            default: csr_illegal = 1'b1;
          endcase

          // always allow access to the following CSRs even without ASR permission
          //   -- 0xC00-0xC9F (unprivileged read-only counters, per CHERIoT spec Table 7.1)
          csr_cheriot_always_ok_o = (BaseIsa == BaseIsaRV32IorCHERIoT) &
                                    (cheriot_enable_i == IbexMuBiOn) &
                                    ((instr[31:28] == 4'hc) &&
                                     ((instr[27] == 1'b0) || (instr[26:25] == 2'b00)));

          illegal_insn = csr_illegal;
        end
      end

      /////////////
      // CHERIoT //
      /////////////

      OPCODE_CHERI: begin
        if ((BaseIsa == BaseIsaRV32IorCHERIoT) & (cheriot_enable_i == IbexMuBiOn) &
            ~illegal_c_insn_i) begin
          instr_is_cheriot_o = 1'b1;
          rf_ren_a_o       = 1'b1;
          rf_we            = 1'b1;

          if (instr[14:12] == 3'b000) begin
            if (instr[31:25] == 7'h7f) begin
              // fmt3: single-source instructions (rd = op(cs1))
              unique case (instr[24:20])
                5'h00: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_PERM; end
                5'h01: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_TYPE; end
                5'h02: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_BASE; end
                5'h03: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_LEN;  end
                5'h04: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_TAG;  end
                5'h08: begin cheriot_operator_o.CRRL = 1'b1;
                             cheriot_setbounds_sel_o = SETBOUNDS_CRRL; end
                5'h09: begin cheriot_operator_o.CRAM = 1'b1;
                             cheriot_setbounds_sel_o = SETBOUNDS_CRAM; end
                5'h0a: cheriot_operator_o.CMOVE_CAP  = 1'b1; // CMove
                5'h0b: cheriot_operator_o.CCLEAR_TAG = 1'b1; // CClearTag
                5'h0f: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_ADDR; end
                5'h17: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_HIGH; end
                5'h18: begin cheriot_operator_o.CGET_FIELD = 1'b1;
                             cheriot_cap_field_sel_o = CFIELD_TOP;  end
                default: illegal_insn = 1'b1;
              endcase

            end else if (instr[31:25] == 7'h01) begin
              // CCSR_RW (CSpecialRW): imm5 selects the special register, not rs2
              cheriot_operator_o.CCSR_RW = 1'b1;
              cheriot_setaddr_sel_o = SETADDR_SCR;

            end else begin
              // fmt2: two-source instructions (rd = op(cs1, cs2))
              rf_ren_b_o = 1'b1;
              unique case (instr[31:25])
                7'h08: begin cheriot_operator_o.CSET_BOUNDS      = 1'b1;
                             cheriot_setbounds_sel_o = SETBOUNDS_RS2;    end
                7'h09: begin cheriot_operator_o.CSET_BOUNDS_EX   = 1'b1;
                             cheriot_setbounds_sel_o = SETBOUNDS_RS2_EX; end
                7'h0a: begin cheriot_operator_o.CSET_BOUNDS_RNDN = 1'b1;
                             cheriot_setbounds_sel_o = SETBOUNDS_RNDN;   end
                7'h0b: cheriot_operator_o.CSEAL            = 1'b1; // CSeal
                7'h0c: cheriot_operator_o.CUNSEAL          = 1'b1; // CUnseal
                7'h0d: cheriot_operator_o.CAND_PERM        = 1'b1; // CAndPerm
                7'h10: begin cheriot_operator_o.CSET_ADDR = 1'b1;
                             cheriot_adder_a_sel_o = CHERIOT_ADDER_A_RS2;
                             cheriot_setaddr_sel_o = SETADDR_RFA_ARITH; end
                7'h11: begin cheriot_operator_o.CINC_ADDR = 1'b1;
                             cheriot_adder_a_sel_o = CHERIOT_ADDER_A_RS2;
                             cheriot_adder_b_sel_o = CHERIOT_ADDER_B_RS1;
                             cheriot_setaddr_sel_o = SETADDR_RFA_ARITH; end
                7'h14: cheriot_operator_o.CSUB_CAP         = 1'b1; // CSub
                7'h16: cheriot_operator_o.CSET_HIGH        = 1'b1; // CSetHigh
                7'h20: cheriot_operator_o.CIS_SUBSET       = 1'b1; // CTestSubset
                7'h21: cheriot_operator_o.CIS_EQUAL        = 1'b1; // CIsEqual
                default: illegal_insn = 1'b1;
              endcase
            end

          end else if (instr[14:12] == 3'b001) begin
            // fmt1: CIncAddrImm
            cheriot_operator_o.CINC_ADDR_IMM = 1'b1;
            cheriot_adder_a_sel_o = CHERIOT_ADDER_A_IMM12;
            cheriot_adder_b_sel_o = CHERIOT_ADDER_B_RS1;
            cheriot_setaddr_sel_o = SETADDR_RFA_ARITH;

          end else if (instr[14:12] == 3'b010) begin
            // fmt1: CSetBoundsImm
            cheriot_operator_o.CSET_BOUNDS_IMM = 1'b1;
            cheriot_setbounds_sel_o = SETBOUNDS_IMM;

          end else begin
            illegal_insn = 1'b1;
          end

        end else begin
          illegal_insn = 1'b1;
        end
      end

      OPCODE_AUICGP: begin
        if ((BaseIsa == BaseIsaRV32IorCHERIoT) & (cheriot_enable_i == IbexMuBiOn) &
            ~illegal_c_insn_i) begin
          cheriot_operator_o.CAUICGP = 1'b1;
          instr_is_cheriot_o          = 1'b1;
          rf_ren_a_o                = 1'b1;
          rf_we                     = 1'b1;
          illegal_insn              = 1'b0;
          cheriot_adder_a_sel_o       = CHERIOT_ADDER_A_IMM20;
          cheriot_adder_b_sel_o       = CHERIOT_ADDER_B_RS1;
          cheriot_setaddr_sel_o       = SETADDR_RFA_ARITH;
        end else begin
          illegal_insn = 1'b1;
        end
      end

      default: begin
        illegal_insn = 1'b1;
      end
    endcase

    // make sure illegal compressed instructions cause illegal instruction exceptions
    if (illegal_c_insn_i) begin
      illegal_insn = 1'b1;
    end

    // make sure illegal instructions detected in the decoder do not propagate from decoder
    // into register file, LSU, EX, WB, CSRs, PC
    // NOTE: instructions can also be detected to be illegal inside the CSRs (upon accesses with
    // insufficient privileges), or when accessing non-available registers in RV32E,
    // these cases are not handled here
    if (illegal_insn) begin
      rf_we           = 1'b0;
      data_req_o      = 1'b0;
      data_we_o       = 1'b0;
      jump_in_dec_o   = 1'b0;
      jump_set_o      = 1'b0;
      branch_in_dec_o = 1'b0;
      csr_access_o    = 1'b0;
    end
  end

  /////////////////////////////
  // Decoder for ALU control //
  /////////////////////////////

  always_comb begin
    alu_operator_o     = ALU_SLTU;
    alu_op_a_mux_sel_o = OP_A_IMM;
    alu_op_b_mux_sel_o = OP_B_IMM;

    imm_a_mux_sel_o    = IMM_A_ZERO;
    imm_b_mux_sel_o    = IMM_B_I;

    bt_a_mux_sel_o     = OP_A_CURRPC;
    bt_b_mux_sel_o     = IMM_B_I;


    opcode_alu         = opcode_e'(instr_alu[6:0]);

    mult_sel_o         = 1'b0;
    div_sel_o          = 1'b0;

    unique case (opcode_alu)

      ///////////
      // Jumps //
      ///////////

      OPCODE_JAL: begin // Jump and Link
        if (BranchTargetALU) begin
          bt_a_mux_sel_o = OP_A_CURRPC;
          bt_b_mux_sel_o = IMM_B_J;
        end

        // Jumps take two cycles without the BTALU
        if (instr_first_cycle_i && !BranchTargetALU) begin
          // Calculate jump target
          alu_op_a_mux_sel_o  = OP_A_CURRPC;
          alu_op_b_mux_sel_o  = OP_B_IMM;
          imm_b_mux_sel_o     = IMM_B_J;
          alu_operator_o      = ALU_ADD;
        end else begin
          // Calculate and store PC+4
          alu_op_a_mux_sel_o  = OP_A_CURRPC;
          alu_op_b_mux_sel_o  = OP_B_IMM;
          imm_b_mux_sel_o     = IMM_B_INCR_PC;
          alu_operator_o      = ALU_ADD;
        end
      end

      OPCODE_JALR: begin // Jump and Link Register
        if (BranchTargetALU) begin
          bt_a_mux_sel_o = OP_A_REG_A;
          bt_b_mux_sel_o = IMM_B_I;
        end

        // Jumps take two cycles without the BTALU
        if (instr_first_cycle_i && !BranchTargetALU) begin
          // Calculate jump target
          alu_op_a_mux_sel_o  = OP_A_REG_A;
          alu_op_b_mux_sel_o  = OP_B_IMM;
          imm_b_mux_sel_o     = IMM_B_I;
          alu_operator_o      = ALU_ADD;
        end else begin
          // Calculate and store PC+4
          alu_op_a_mux_sel_o  = OP_A_CURRPC;
          alu_op_b_mux_sel_o  = OP_B_IMM;
          imm_b_mux_sel_o     = IMM_B_INCR_PC;
          alu_operator_o      = ALU_ADD;
        end
      end

      OPCODE_BRANCH: begin // Branch
        // Check branch condition selection
        unique case (instr_alu[14:12])
          3'b000:  alu_operator_o = ALU_EQ;
          3'b001:  alu_operator_o = ALU_NE;
          3'b100:  alu_operator_o = ALU_LT;
          3'b101:  alu_operator_o = ALU_GE;
          3'b110:  alu_operator_o = ALU_LTU;
          3'b111:  alu_operator_o = ALU_GEU;
          default: ;
        endcase

        if (BranchTargetALU) begin
          bt_a_mux_sel_o = OP_A_CURRPC;
          // Not-taken branch will jump to next instruction (used in secure mode)
          bt_b_mux_sel_o = branch_taken_i ? IMM_B_B : IMM_B_INCR_PC;
        end

        // Without branch target ALU, a branch is a two-stage operation using the Main ALU in both
        // stages
        if (instr_first_cycle_i) begin
          // First evaluate the branch condition
          alu_op_a_mux_sel_o  = OP_A_REG_A;
          alu_op_b_mux_sel_o  = OP_B_REG_B;
        end else if (!BranchTargetALU) begin
          // Then calculate jump target
          alu_op_a_mux_sel_o  = OP_A_CURRPC;
          alu_op_b_mux_sel_o  = OP_B_IMM;
          // Not-taken branch will jump to next instruction (used in secure mode)
          imm_b_mux_sel_o     = branch_taken_i ? IMM_B_B : IMM_B_INCR_PC;
          alu_operator_o      = ALU_ADD;
        end
      end

      ////////////////
      // Load/store //
      ////////////////

      OPCODE_STORE: begin
        alu_op_a_mux_sel_o = OP_A_REG_A;
        alu_op_b_mux_sel_o = OP_B_REG_B;
        alu_operator_o     = ALU_ADD;

        if (!instr_alu[14]) begin
          // offset from immediate
          imm_b_mux_sel_o     = IMM_B_S;
          alu_op_b_mux_sel_o  = OP_B_IMM;
        end
      end

      OPCODE_LOAD: begin
        alu_op_a_mux_sel_o  = OP_A_REG_A;

        // offset from immediate
        alu_operator_o      = ALU_ADD;
        alu_op_b_mux_sel_o  = OP_B_IMM;
        imm_b_mux_sel_o     = IMM_B_I;
      end

      /////////
      // ALU //
      /////////

      OPCODE_LUI: begin  // Load Upper Immediate
        alu_op_a_mux_sel_o  = OP_A_IMM;
        alu_op_b_mux_sel_o  = OP_B_IMM;
        imm_a_mux_sel_o     = IMM_A_ZERO;
        imm_b_mux_sel_o     = IMM_B_U;
        alu_operator_o      = ALU_ADD;
      end

      // use CHERIoT version of AUIPCC when pmode == 1
      OPCODE_AUIPC: begin  // Add Upper Immediate to PC
        alu_op_a_mux_sel_o  = OP_A_CURRPC;
        alu_op_b_mux_sel_o  = OP_B_IMM;
        imm_b_mux_sel_o     = IMM_B_U;
        alu_operator_o      = ALU_ADD;
      end

      OPCODE_OP_IMM: begin // Register-Immediate ALU Operations
        alu_op_a_mux_sel_o  = OP_A_REG_A;
        alu_op_b_mux_sel_o  = OP_B_IMM;
        imm_b_mux_sel_o     = IMM_B_I;

        unique case (instr_alu[14:12])
          3'b000: alu_operator_o = ALU_ADD;  // Add Immediate
          3'b010: alu_operator_o = ALU_SLT;  // Set to one if Lower Than Immediate
          3'b011: alu_operator_o = ALU_SLTU; // Set to one if Lower Than Immediate Unsigned
          3'b100: alu_operator_o = ALU_XOR;  // Exclusive Or with Immediate
          3'b110: alu_operator_o = ALU_OR;   // Or with Immediate
          3'b111: alu_operator_o = ALU_AND;  // And with Immediate

          3'b001: begin
            if (RV32B != RV32BNone) begin
              unique case (instr_alu[31:27])
                5'b0_0000: alu_operator_o = ALU_SLL;    // Shift Left Logical by Immediate
                5'b0_1001: alu_operator_o = ALU_BCLR; // Clear bit specified by immediate
                5'b0_0101: alu_operator_o = ALU_BSET; // Set bit specified by immediate
                5'b0_1101: alu_operator_o = ALU_BINV; // Invert bit specified by immediate.
                // zip (Zbkb): shfli with shamt fixed to 0x0F
                5'b0_0001: if (instr_alu[26:20] == 7'b000_1111) alu_operator_o = ALU_ZIP;
                5'b0_1100: begin
                  unique case (instr_alu[26:20])
                    7'b000_0000: alu_operator_o = ALU_CLZ;   // clz
                    7'b000_0001: alu_operator_o = ALU_CTZ;   // ctz
                    7'b000_0010: alu_operator_o = ALU_CPOP;  // cpop
                    7'b000_0100: alu_operator_o = ALU_SEXTB; // sext.b
                    7'b000_0101: alu_operator_o = ALU_SEXTH; // sext.h
                    default: ;
                  endcase
                end

                default: ;
              endcase
            end else begin
              alu_operator_o = ALU_SLL; // Shift Left Logical by Immediate
            end
          end

          3'b101: begin
            if (RV32B != RV32BNone) begin
              unique case (instr_alu[31:27])
                5'b0_0000: alu_operator_o = ALU_SRL;   // Shift Right Logical by Immediate
                5'b0_1000: alu_operator_o = ALU_SRA;   // Shift Right Arithmetically by Immediate
                5'b0_1001: alu_operator_o = ALU_BEXT;  // Extract bit specified by immediate.
                // rori (Zbb, also imported by Zbkb): rotate right by immediate
                5'b0_1100: alu_operator_o = ALU_ROR;
                // rev8 (Zbb, shamt 0x18) and brev8 (Zbkb, shamt 0x07)
                5'b0_1101: begin
                  if (instr_alu[24:20] == 5'b1_1000) begin
                    alu_operator_o = ALU_REV8;
                  end else if (instr_alu[24:20] == 5'b0_0111 && RV32B == RV32BFull) begin
                    alu_operator_o = ALU_BREV8;
                  end
                end
                // orc.b (Zbb): gorci with shamt fixed to 0x07
                5'b0_0101: if (instr_alu[24:20] == 5'b0_0111) alu_operator_o = ALU_ORCB;
                // unzip (Zbkb): unshfli with shamt fixed to 0x0F
                5'b0_0001: begin
                  if (RV32B == RV32BFull) begin
                    if (instr_alu[26:20] == 7'b000_1111) alu_operator_o = ALU_UNZIP;
                  end
                end
                default: ;
              endcase

            end else begin
              if (instr_alu[31:27] == 5'b0_0000) begin
                alu_operator_o = ALU_SRL;               // Shift Right Logical by Immediate
              end else if (instr_alu[31:27] == 5'b0_1000) begin
                alu_operator_o = ALU_SRA;               // Shift Right Arithmetically by Immediate
              end
            end
          end

          default: ;
        endcase
      end

      OPCODE_OP: begin  // Register-Register ALU operation
        alu_op_a_mux_sel_o = OP_A_REG_A;
        alu_op_b_mux_sel_o = OP_B_REG_B;

        unique case ({instr_alu[31:25], instr_alu[14:12]})
          // RV32I ALU operations
          {7'b000_0000, 3'b000}: alu_operator_o = ALU_ADD;   // Add
          {7'b010_0000, 3'b000}: alu_operator_o = ALU_SUB;   // Sub
          {7'b000_0000, 3'b010}: alu_operator_o = ALU_SLT;   // Set Lower Than
          {7'b000_0000, 3'b011}: alu_operator_o = ALU_SLTU;  // Set Lower Than Unsigned
          {7'b000_0000, 3'b100}: alu_operator_o = ALU_XOR;   // Xor
          {7'b000_0000, 3'b110}: alu_operator_o = ALU_OR;    // Or
          {7'b000_0000, 3'b111}: alu_operator_o = ALU_AND;   // And
          {7'b000_0000, 3'b001}: alu_operator_o = ALU_SLL;   // Shift Left Logical
          {7'b000_0000, 3'b101}: alu_operator_o = ALU_SRL;   // Shift Right Logical
          {7'b010_0000, 3'b101}: alu_operator_o = ALU_SRA;   // Shift Right Arithmetic

          // RV32B ALU Operations
          // rol / ror (Zbb, also imported by Zbkb): rotate by register amount
          {7'b011_0000, 3'b001}: if (RV32B != RV32BNone) alu_operator_o = ALU_ROL;
          {7'b011_0000, 3'b101}: if (RV32B != RV32BNone) alu_operator_o = ALU_ROR;

          {7'b000_0101, 3'b100}: if (RV32B != RV32BNone) alu_operator_o = ALU_MIN;
          {7'b000_0101, 3'b110}: if (RV32B != RV32BNone) alu_operator_o = ALU_MAX;
          {7'b000_0101, 3'b101}: if (RV32B != RV32BNone) alu_operator_o = ALU_MINU;
          {7'b000_0101, 3'b111}: if (RV32B != RV32BNone) alu_operator_o = ALU_MAXU;

          {7'b000_0100, 3'b100}: begin
            // zext.h (Zbb, rs2=x0) reuses the pack datapath; general pack is Zbkb.
            if (instr_alu[24:20] == 5'b0_0000) begin
              if (RV32B != RV32BNone) alu_operator_o = ALU_PACK; // zext.h
            end else begin
              if (RV32B == RV32BFull) alu_operator_o = ALU_PACK; // pack
            end
          end
          {7'b000_0100, 3'b111}: if (RV32B == RV32BFull) alu_operator_o = ALU_PACKH;

          {7'b010_0000, 3'b100}: if (RV32B != RV32BNone) alu_operator_o = ALU_XNOR;
          {7'b010_0000, 3'b110}: if (RV32B != RV32BNone) alu_operator_o = ALU_ORN;
          {7'b010_0000, 3'b111}: if (RV32B != RV32BNone) alu_operator_o = ALU_ANDN;

          // RV32B zba
          {7'b001_0000, 3'b010}: if (RV32B != RV32BNone) alu_operator_o = ALU_SH1ADD;
          {7'b001_0000, 3'b100}: if (RV32B != RV32BNone) alu_operator_o = ALU_SH2ADD;
          {7'b001_0000, 3'b110}: if (RV32B != RV32BNone) alu_operator_o = ALU_SH3ADD;

          // RV32B zbs
          {7'b010_0100, 3'b001}: if (RV32B != RV32BNone) alu_operator_o = ALU_BCLR;
          {7'b001_0100, 3'b001}: if (RV32B != RV32BNone) alu_operator_o = ALU_BSET;
          {7'b011_0100, 3'b001}: if (RV32B != RV32BNone) alu_operator_o = ALU_BINV;
          {7'b010_0100, 3'b101}: if (RV32B != RV32BNone) alu_operator_o = ALU_BEXT;

          // RV32B zbkx
          {7'b001_0100, 3'b010}: begin
            if (RV32B == RV32BFull) alu_operator_o = ALU_XPERM4;
          end
          {7'b001_0100, 3'b100}: begin
            if (RV32B == RV32BFull) alu_operator_o = ALU_XPERM8;
          end

          // RV32B zbc
          {7'b000_0101, 3'b001}: begin
            if (RV32B == RV32BFull) alu_operator_o = ALU_CLMUL;
          end
          {7'b000_0101, 3'b010}: begin
            if (RV32B == RV32BFull) alu_operator_o = ALU_CLMULR;
          end
          {7'b000_0101, 3'b011}: begin
            if (RV32B == RV32BFull) alu_operator_o = ALU_CLMULH;
          end

          // RV32M instructions, all use the same ALU operation
          {7'b000_0001, 3'b000}: begin // mul
            alu_operator_o = ALU_ADD;
            mult_sel_o     = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end
          {7'b000_0001, 3'b001}: begin // mulh
            alu_operator_o = ALU_ADD;
            mult_sel_o     = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end
          {7'b000_0001, 3'b010}: begin // mulhsu
            alu_operator_o = ALU_ADD;
            mult_sel_o     = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end
          {7'b000_0001, 3'b011}: begin // mulhu
            alu_operator_o = ALU_ADD;
            mult_sel_o     = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end
          {7'b000_0001, 3'b100}: begin // div
            alu_operator_o = ALU_ADD;
            div_sel_o      = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end
          {7'b000_0001, 3'b101}: begin // divu
            alu_operator_o = ALU_ADD;
            div_sel_o      = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end
          {7'b000_0001, 3'b110}: begin // rem
            alu_operator_o = ALU_ADD;
            div_sel_o      = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end
          {7'b000_0001, 3'b111}: begin // remu
            alu_operator_o = ALU_ADD;
            div_sel_o      = (RV32M == RV32MNone) ? 1'b0 : 1'b1;
          end

          default: ;
        endcase
      end

      /////////////
      // Special //
      /////////////

      OPCODE_MISC_MEM: begin
        unique case (instr_alu[14:12])
          3'b000: begin
            // FENCE is treated as a NOP since all memory operations are already strictly ordered.
            alu_operator_o     = ALU_ADD; // nop
            alu_op_a_mux_sel_o = OP_A_REG_A;
            alu_op_b_mux_sel_o = OP_B_IMM;
          end
          3'b001: begin
            // FENCE.I will flush the IF stage, prefetch buffer and ICache if present.
            if (BranchTargetALU) begin
              bt_a_mux_sel_o     = OP_A_CURRPC;
              bt_b_mux_sel_o     = IMM_B_INCR_PC;
            end else begin
              alu_op_a_mux_sel_o = OP_A_CURRPC;
              alu_op_b_mux_sel_o = OP_B_IMM;
              imm_b_mux_sel_o    = IMM_B_INCR_PC;
              alu_operator_o     = ALU_ADD;
            end
          end
          default: ;
        endcase
      end

      OPCODE_SYSTEM: begin
        if (instr_alu[14:12] == 3'b000) begin
          // non CSR related SYSTEM instructions
          alu_op_a_mux_sel_o = OP_A_REG_A;
          alu_op_b_mux_sel_o = OP_B_IMM;
        end else begin
          // instruction to read/modify CSR
          imm_a_mux_sel_o    = IMM_A_Z;

          // No need for operand/immediate B mux selection. The CSR address is fed out as csr_addr_o
          // as the CSR address always comes from the same field in the instruction.

          if (instr_alu[14]) begin
            // rs1 field is used as immediate
            alu_op_a_mux_sel_o = OP_A_IMM;
          end else begin
            alu_op_a_mux_sel_o = OP_A_REG_A;
          end
        end

      end
      default: ;
    endcase
  end

  // do not enable multdiv in case of illegal instruction exceptions
  assign mult_en_o = illegal_insn_o ? 1'b0 : mult_sel_o;
  assign div_en_o  = illegal_insn_o ? 1'b0 : div_sel_o;

  // Trap on illegal register addresses (x16-x31 in RV32E or CHERIoT mode).
  assign illegal_insn_o = illegal_insn | illegal_reg_16;

  // Suppress regfile write enable when an illegal register is addressed.
  assign rf_we_o = rf_we & ~illegal_reg_16;

  // Not all bits are used
  assign unused_instr_alu = {instr_alu[19:15], instr_alu[11:7]};

  assign instr_is_legal_cheriot   = |cheriot_operator_o;
  assign instr_is_legal_cheriot_o = instr_is_legal_cheriot & ~illegal_reg_16;


  assign cheriot_cs2_dec_o = cheriot_operator_o.CCSR_RW ? instr[24:20] : 5'h0;

  assign cheriot_imm12_o = (cheriot_operator_o.CJALR           |
                            cheriot_operator_o.CSET_BOUNDS_IMM  |
                            cheriot_operator_o.CINC_ADDR_IMM    |
                            cheriot_operator_o.CLOAD_CAP) ?
                           {instr[31:25], instr[24:20]} :
                           (cheriot_operator_o.CSTORE_CAP ? {instr[31:25], instr[11:7]} : 12'h0);

  assign cheriot_imm20_o = (cheriot_operator_o.CAUIPCC | cheriot_operator_o.CAUICGP) ?
                            instr[31:12] : 20'h0;

  assign cheriot_imm21_o = cheriot_operator_o.CJAL ?
                           {instr[31], instr[19:12], instr[20], instr[30:21], 1'b0} : 21'h0;

  if (BaseIsa != BaseIsaRV32IorCHERIoT) begin : gen_no_cheriot_decoder
    logic unused_cheriot_enable;
    assign unused_cheriot_enable = ^cheriot_enable_i;
  end

endmodule // controller
