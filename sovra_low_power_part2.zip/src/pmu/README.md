# SCP on Ibex: the System Control Processor and its firmware plan

The System Control Processor of
`Proposed_PMU/PCSA_FLAT_DOMAIN_SOC.md` (the "design doc" cited below; removed
on 2026-10-05, commit 2edfabe, and superseded by
[`SOVRA_PCSA_ARCHITECTURE.md`](../../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md))
— one always-on core that owns the power policy of twelve component domains —
built on a real processor running real firmware, instead of the testbench-only
behavioural SCP that document's stage S4 originally proposed.

**Status (2026-10-02).** [`ibex/`](ibex/README.md) holds lowRISC Ibex
verbatim and [`rtl/scp_core.sv`](rtl/scp_core.sv) freezes its configuration;
`scp_top` adds the RAM, timer, private bus, the AXI4-Lite path to the PPUs and
the `ext_*` window for the devices of the top level. The platform that runs it
is **soc4** (`src/soc4`, design in [`docs/SOC4_DESIGN.md`](../../docs/SOC4_DESIGN.md)): the
SCP with four PPU domains (two Ibex CPUs, two stand-in accelerators), an
always-on AP as the RPMI agent, and a TL-UL RPMI mailbox with a source
firewall on the `ext_*` window. The firmware in [`fw/`](fw/) — a PPU driver, a
power domain manager, the RPMI server on librpmi v1.0.0 and the DEVICE_POWER
policy — is shared by soc4's images, which `src/soc4/fw/Makefile` builds.
`make soc4` / `soc4bfm` run the product path with the AP program and with a
TL-UL bus-functional model, `make soc4stress` drives every PPU function the
soc4 PPUs are built with from the firmware (its feature-by-feature cross-check
against DEN 0051E is [`PPU_FW_CONFORMANCE.md`](PPU_FW_CONFORMANCE.md)), and
the `...pa` forms repeat them under UPF.

Until 2026-10-02 the platform was `pmu_top`, twelve PPU domains behind
`scp_top` with an AXI4-Lite RPMI mailbox inside it, run by `pmu_tb` and the
`scphello`, `scppd`, `scpstress`, `scprpmi`, `scprpmihw` and `scpdpwr` targets.
soc4 replaced it and it was removed (SOC4_DESIGN.md Section 12). Sections 2–9
remain the plan for the full twelve-domain SoC, with dated notes where soc4
already differs; [Section 10](#10-bring-up-results-and-findings) is the
bring-up record on `pmu_top`, including the PPU and PCSM deviations found and
then fixed. The functions the firmware must implement, cross-checked against
PCSA, the PPU specification and RPMI, are in [`FUNCTIONS.md`](FUNCTIONS.md).

**Simulators.** Everything here runs under Synopsys VCS, power intent
included (VCS native low power); the choice was made when Xcelium's licence
lapsed on 2026-09-15:
`make soc4 SIM=vcs`, `make soc4bfm SIM=vcs`, `make soc4stress SIM=vcs`,
`make soc4neg SIM=vcs` and `make soc4pa` / `soc4bfmpa` / `soc4stresspa`. The
soc4 targets refuse any other simulator. (`make ibexlint`, the one
Xcelium-only target here, was removed on 2026-10-06.)

**Citation convention** follows the design document: bare `§x.y` is **PCSA
(DEN 0050D)**; `PPU §x.y` is the **PPU Architecture Specification v1.1
(DEN 0051E)**. Both are in `references/standards/`. RPMI names follow the
**RPMI v1.0** specification (§7), which is not in that directory.

---

## Contents

1. [What the SCP is here, and what it is not](#1-what-the-scp-is-here-and-what-it-is-not)
2. [The hardware: `scp_top`](#2-the-hardware-scp_top)
3. [The processor](#3-the-processor)
4. [Toolchain, and three constraints it imposes](#4-toolchain-and-three-constraints-it-imposes)
5. [The firmware](#5-the-firmware)
6. [The PPU driver contract](#6-the-ppu-driver-contract)
7. [RPMI over shared-memory queues](#7-rpmi-over-shared-memory-queues)
8. [Build stages F0–F7](#8-build-stages-f0f7)
9. [Decisions taken, and what is worth confirming](#9-decisions-taken-and-what-is-worth-confirming)
10. [Bring-up results and findings](#10-bring-up-results-and-findings)

---

## 1. What the SCP is here, and what it is not

§3.2: *"the SCP is a processor-based system running dedicated firmware
controlling a set of hardware resources ... the SCP has a minimum set of
resources, including local private memory, timers, interrupt control, and
registers for system configuration, control and status."* §3.3 gives the one
rule that shapes everything: *"all hardware power management actions are taken
by the SCP on behalf of these requestors."*

In this design that translates to a short list, because the flat single-rail
partition has already removed most of what an SCP usually does:

| SCP responsibility (§3.2.1, §3.3.3) | Here |
|---|---|
| Power states of cores, clusters, devices, SoC | **cores and devices only** — no clusters, and the SoC has one state (`RUN`; design doc §5.3) |
| DVFS, voltage supply, clock supply | **none** — one rail, one frequency (design doc §3) |
| Always-on wake timers for AP cores | **none** — the per-CPU private timers are in `PD_AON` already (design doc §2.3) |
| System initialization through to AP boot | **yes** — release `PD_AON`, bring up `PD_CPU0`–`PD_CPU3` and release all four harts, leave the other eight `OFF` (§7.7; the design doc §10 brought up `PD_CPU0` alone) |
| Events: GIC wake, timer, always-on wake, debug, watchdog | **timer, always-on wake (access gates), watchdog**. GIC wake requests go to the PPU's `DEVQACTIVE` in hardware and the SCP is only *notified* (design doc §5.1.1); no debug power domain |
| Consistency: no races, dependencies honoured | **yes** — reference counts with one requestor, the AP (§7.1), and the invariant that no gated domain depends on another |
| Thermal/electrical protection, overriding OSPM | **one actuator only**: how many domains are on (design doc §5.4.3) |

What it must **not** do is equally fixed. §6.4.1, *Clock Control*: *"The SCP
does not control run time dynamic gating of clocks at component activity
level. This is managed by clock controllers with hardware autonomous Q-Channel
management."* And the design document's tier table (§5.4): tiers 1 and 2 —
clock gating and the PPU's dynamic policy — run with no firmware in the loop.
The SCP acts at tier 3, on a mailbox request or a PPU interrupt, and its
contribution to the fast path is one register write per domain, up front.

That is why the smallest supported Ibex configuration is enough (§3), and why
the firmware is an event loop rather than an RTOS (§5).

---

## 2. The hardware: `scp_top`

Everything in `PD_AON`, on the one system clock. The SCP's private bus is
Ibex's own one-cycle `bus` from [`ibex/shared/`](ibex/README.md); the PPUs sit
behind AXI4-Lite because that is the interface the PPU already has
(`src/rtl/ppu/ppu_top_axi_lite.sv`, `ppu_axi_pd_top.sv`) and because it is
the interface the SoC's interconnect will present.

The picture below is the plan for the full SoC. What `scp_top` holds today is
the core, `scp_ram`, the timer, the interrupt status/enable block `scp_irq`,
`scp_data_split`, the AXI4-Lite bridge and demux (`NUM_PPU` ports, four in
soc4), and the `ext_*` window; the RPMI mailbox (doorbell and queue memory)
sits outside it, on that window, as soc4's `soc4_mbx`, and its doorbell comes
back as one of `scp_irq`'s inputs. Since 2026-10-05 (platform plan H7-H9)
`scp_irq` replaces the planned wake aggregator and the per-PPU fast lines of
the picture: every source but the timer — each PPU, the doorbells, the SoC
PLIC's output and per-hart pending, the raw wake lines — is one input of one
generic bank on `irq_external`, and the fast lines are tied LOW. Since
2026-10-05 (platform plan H18) `scp_top` also holds the watchdog `scp_wdog`,
at `0x0001_2000` rather than the picture's `scp_wdt`: no pre-warning
interrupt and no NMI; on expiry it resets the SCP subsystem alone (§2.3).

```
 ┌──────────────────────────────── scp_top (PD_AON) ─────────────────────────────────┐
 │                                                                                    │
 │   scp_core ──instr──► scp_ram (64 KB, 2 ports, $readmemh)                          │
 │   (Ibex)   ──data───► scp_data_split ──local──► bus ──┬─► scp_ram                   │
 │      ▲                       │                        ├─► timer      (mtime/cmp)    │
 │      │ irq_timer             │                        ├─► scp_mailbox (doorbells)   │
 │      │ irq_external ◄────────┼────────────────────────┤                             │
 │      │ irq_fast[12] ◄────────┼────────────────────────┼─► scp_wake_aggr             │
 │      │ irq_fast[11:0]        │                        ├─► scp_wdt (+ syndrome)      │
 │      │ irq_nm ◄──────────────┼────────────────────────┤                             │
 │      │                       │                        ├─► RPMI queue SRAM (T0a/T0b) │
 │      │                       │                        └─► sim control (TB only)     │
 │      │                       └──axi──► scp_axi_lite_master ──► scp_axi_lite_demux   │
 │      │                                                            │ 1 → 12          │
 │      └────────────────── irq ×12 ◄────────────────────────────────┼─► PPU_CPU0..3   │
 │                                                                   ├─► PPU_DSP0..3   │
 │                                                                   └─► PPU_NPU0..3   │
 └────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.1 Memory map

SCP-private (§3.2.2, §6.4.1 *Peripheral Access*: *"In general, SCP peripherals
are privately mapped for security reasons"*), with the two shared exceptions
§6.4.1 names — the messaging interface, and (later) the system counter.

| Base | Size | Block | Bus | Stage |
|---|---|---|---|---|
| `0x0000_0000` | 64 KB | `scp_ram` — code and data. Vector table at `0x0`, reset vector at `0x80` | local | F0 |
| `0x0001_0000` | 1 KB | `timer` — `MTIME` `+0`, `MTIMEH` `+4`, `MTIMECMP` `+8`, `MTIMECMPH` `+C` | local | F0 |
| `0x0001_1000` | 4 KB | `scp_irq` — the interrupt status/enable block (`NUM_IRQ` inputs, ≤ 32, onto `irq_external`): `PENDING` `+0` (R/W1C), `ENABLE` `+4`, `EDGE` `+8` (1 = rising edge, 0 = level), `RAW` `+C` (RO, synchronised inputs), `ACTIVE` `+10` (RO, `PENDING & ENABLE`), `INFO` `+14` (RO, `[7:0]` input count). Registers in `rtl/scp_irq.sv`; inputs and actions in the platform's input table (`fw/hal/scp_irq.h`) | local | H7 |
| `0x0002_0000` | 64 KB | `ext_*` — the top level's devices, one cycle on `bus`. In soc4 (SOC4_DESIGN.md §4.2): the testbench's sim control (`+0` character out, `+8` halt with status; **testbench only**), `soc4_ctrl`, the RPMI mailbox's registers (the AP-to-SCP doorbell, the firewall) and its queue memory, and the two CPU load ports | local | F0, F4 |
| `0x0001_2000` | 4 KB | `scp_wdog` — the watchdog: `CTRL` `+0` (`[0]` EN, `[1]` LOCK, sticky until reset), `TIMEOUT` `+4`, `KICK` `+8` (WO, key `0x4B49434B`; any other value while EN resets at once), `COUNT` `+C` (RO), `CAUSE` `+10` (R/W1C `[3:0]` POR, WDOG, BADKICK, DRAINTO; RO `[15:8]` resets since power-on; cleared by power-on reset only). Registers in `rtl/scp_wdog.sv`, driver `fw/hal/scp_wdog.h` | local | H18 |
| `0x4000_0000` + n·`0x1000` | 12 × 4 KB | PPU n registers. `n` = 0–3 `CPU0..3`, 4–7 `DSP0..3`, 8–11 `NPU0..3`. Bits `[11:0]` are the DEN 0051E offsets; `ppu_axi_lite_adapter` ignores the rest, so the demux decodes `[15:12]`. 2026-10-06: `scp_top` has `NUM_PPU` PPU ports, four in soc4 (CPU0, CPU1, ACC0, ACC1), and selects `NUM_PPU` to 15 answer `DECERR` | AXI4-Lite | F1 |

Everything else is unmapped. On the local bus an unmapped address returns
`err` (Ibex's `bus` does this itself); on AXI4-Lite the demux answers `DECERR`.
Either becomes a load/store access fault in the firmware (§3).

Until 2026-10-02 `scp_top` also mapped the RPMI doorbells at `0x0003_0000` and
the queue memory at `0x1000_0000`, an AXI4-Lite mailbox (`scp_rpmi_mbox`, on
PULP `mailbox_unit`) that the AP reached through its own AXI4-Lite port
(`s_ap_axi_*`). Both windows went with `pmu_top`; the AP now reaches soc4's
mailbox over TL-UL, and the SCP reaches it through `ext_*`.

One index, two uses: PPU number `n` is also the domain's input `n` of
`scp_irq` (until 2026-10-05, its `irq_fast_i[n]` line). That is deliberate and
worth keeping. RPMI numbers its own way: DEVICE_POWER
counts its `DOMAIN_ID`s from 0, so DSP0–3 and NPU0–3 are proposed as IDs 0–7,
PPU `n − 4`; and HSM names a CPU domain by its hart, hart `h` on PPU `h` (§7).

### 2.2 The AXI4-Lite side

Two small new blocks, both plain RTL with flat ports like the rest of `src/rtl`:

- **`scp_axi_lite_master`** — Ibex data interface to one AXI4-Lite manager.
  One transaction outstanding: `data_gnt` is raised when AW+W (or AR) have
  been accepted, `data_rvalid` when B (or R) returns, `data_err` on any
  response other than `OKAY`. Ibex allows more outstanding accesses than
  this; serialising them costs nothing here and keeps the bridge trivially
  correct.
- **`scp_axi_lite_demux`** — one manager to `NUM_M` subordinates on address
  bits `[15:12]`, `DECERR` from `NUM_M` up (twelve and above `0xB` on
  `pmu_top`; four in soc4). AXI4-Lite has no IDs and no bursts,
  so this is a mux with a pending-select register per direction.

Ibex's `bus` assumes every device answers on the next cycle, which a bridge
cannot, so **`scp_data_split`** sits in front of it: addresses in the AXI
window go to the bridge, everything else to `bus`, and the split steers the
one `rvalid`/`err` pair back. A pending-side register is all it holds.

The PPU end is unchanged. In the plain testbenches the twelve subordinates
are `ppu_top_axi_lite`; under UPF they are `ppu_axi_pd_top`, whose
`PD_AON`/`PD_DEV` pairs are what the power intent binds to — the same
substitution `make ppuaxi` / `make ppuaxipa` already makes. (That was
`pmu_top`. In soc4 each subordinate is the `ppu_axi_dom_top` inside
`soc4_cpu_dom` or `soc4_acc_dom`.)

**The bridge's `SLVERR` is a real event, not an exception to suppress.**
`ppu_axi_lite_adapter` answers `SLVERR` when the PPU's own clock does not
arrive within `WAKE_TIMEOUT` (its header, *why not just wait*). Through
`data_err` that is an Ibex load/store access fault, so the firmware's trap
handler is where "the PPU is unreachable" is diagnosed — distinct from "the
PPU refused" (`UNSPT_POLICY_IRQ`) and "the PPU is stuck" (the PCSM deadline of
§6). Three failures, three signals, none of them a silent wrong value.

### 2.3 The private peripherals

| Block | What it is | Why it exists |
|---|---|---|
| `scp_ram` | 64 KB, two read ports (instruction, data), one write port, one-cycle, `$readmemh` from a `+firmware=` plusarg | §6.4.1: *"The SCP firmware code and data spaces are entirely within its private RAM."* A boot ROM is stage F5's option, not F0's requirement |
| `timer` | Ibex's `mtime`/`mtimecmp` | the transition deadlines and hysteresis timers of §6 and the design doc §9.3, and §6.4.1's *"local timer resources ... for the triggering of system wakes and any periodic actions"* |
| `scp_irq` | one generic bank of `NUM_IRQ` inputs; per input a two-flop synchroniser (`rtl/common/cdc_sync`, when the input is asynchronous: `IRQ_ASYNC`), level or edge (`EDGE`), a mask (`ENABLE`) and a sticky W1C `PENDING`; `irq_external_i` = any enabled pending bit. Glue, not a PLIC: no priorities, no claim. What an input means is the firmware's input table | platform plan H7-H9 (PD1, PD7): more sources than Ibex's 15 fast lines, and the SoC PLIC's output and the wake lines as plain inputs |
| RPMI mailbox (soc4: `soc4_mbx`, outside `scp_top`) | since 2026-10-05 (platform plan H11-H13) an N-agent mailbox: per agent (soc4: the AP and an RPU stand-in, each on its own TL-UL port) a 1 KiB queue window of one shared memory, a doorbell bit `RING[k]` (`DB_STATUS` RO, `DB_CLEAR` W1C for the SCP; any accepted write by agent k to its doorbell sets it), and a firewall entry (`FW_EN[k]`, `FW_VAL[k]`, `FW_MASK[k]` on the TL-UL `a_source`, deny-all at reset); a boundary adapter (`soc4_tl_bound`) on each port. No SCP-to-agent side, because agents poll (§7.1). `RING[0]` and `RING[1]` are inputs 4 and 14 of `scp_irq` in soc4 | §6.4.1 *Messaging Interface*: *"Schemes using shared memory mailboxes and doorbell interrupts are typical"*, and *"The messaging interface must be usable by any AP core in the system"* — every hart reaches both transports through OpenSBI |
| `scp_wdog` | since 2026-10-05 (platform plan H18): a down-counter loaded from `TIMEOUT` on enable and on a kick with the key; `LOCK` makes `CTRL` and `TIMEOUT` read-only until reset; a wrong key while armed is a fault. On expiry it holds off new AXI4-Lite transactions until the manager is idle (bounded), then resets the SCP subsystem alone for 16 cycles — core, RAM ports, timer, `scp_irq`, bus, bridge — while the PPUs, PCSMs and domains, always-on, keep their state and the RAM keeps its contents. `CAUSE` (the syndrome) is on the power-on reset only. The firmware kicks once per completed main-loop pass, takes the domains over after a watchdog reset (`mod/pd` `pd_adopt`, `mod/policy` `policy_adopt`), and keeps a fault log and the agents' votes in a RAM block crt0 does not touch (`mod/flog.h`). No pre-warning interrupt (`irq_nm_i` stays LOW) | §6.4.1 *Watchdog*: *"If the watchdog is not written to on a regular basis by the SCP then the watchdog will produce an interrupt, and this will ultimately lead to a reset of the system. A syndrome register must be available to inform the SCP processor of the last reset cause"* |

---

## 3. The processor

[`rtl/scp_core.sv`](rtl/scp_core.sv) is `ibex_top` in the `small`
configuration of Ibex's `ibex_configs.yaml` — RV32IMC, two-stage pipeline,
flop register file, no cache, no PMP, no SecureIbex, no debug module — with
`RV32ZC = RV32Zca` so the hardware matches what `-march=rv32imc` emits. Its
header argues each choice against §6.4.1's *SCP Processor Core Selection*
criteria; the two that decide the shape are:

- **Interrupts.** Ibex vectors fifteen fast interrupts plus timer, external and
  an NMI. Until 2026-10-05 twelve PPUs took `irq_fast_i[11:0]` one each, the
  situation §6.4.1 describes as preferable to *"an additional interrupt
  controller ... within the SCP"*. The platform needs more sources than fifteen
  (every PPU, the doorbells, the wake lines, the SoC PLIC's outputs), so every
  source now goes through `scp_irq` onto `irq_external_i`, at the cost of one
  register read to find it, and the fast lines are tied LOW. The interrupt map
  is fixed in the wrapper's header and the firmware's vector table depends on
  it.
- **Trust.** §3.2.2's boundary is the address map, not a core feature: SCP RAM
  and the PPU windows are reachable only from this core. So PMP is off; it
  would only partition the firmware against itself.

The port list is Ibex's memory protocol on two interfaces, the interrupts, a
`fetch_enable_i` so a testbench can hold the core until the RAM is loaded,
and `core_sleep_o`, which is HIGH while the core waits in WFI — the SCP's own
activity indicator, for a clock controller in front of its clock root later.

Boot: Ibex fetches its first instruction from `BOOT_ADDR + 0x80` and takes
every trap through a 32-entry jump table at `BOOT_ADDR` (`mtvec`'s reset
value). With `BOOT_ADDR = 0` that is the first 0x84 bytes of `scp_ram`.

---

## 4. Toolchain, and three constraints it imposes

The firmware's compiler is the bare-metal
`/system/software/riscv/newlib/bin/riscv64-unknown-elf-gcc` (GCC 16.1.0). The
machine also has a Linux-targeting one, `riscv64-unknown-linux-gnu-gcc`
(GCC 16.1.0) in `/system/software/riscv/linux/bin`.
Checked on 2026-09-25:

```
riscv64-unknown-elf-gcc -march=rv32imc_zicsr_zifencei -mabi=ilp32 -mcmodel=medany \
    -Os -ffreestanding -nostdlib -nostartfiles -Wall -T link.ld ...
```

compiles and links an ELF32 RISC-V RVC soft-float binary. But
`-print-multi-lib` lists only `rv32imafdc.../ilp32d` and `rv64.../lp64d`
targets: **there is no rv32 soft-float multilib**, so the ilp32 build has no
libc and its `libgcc` resolves to the rv64 default. Three rules follow, each
verified by a link attempt:

1. **Freestanding, `-nostdlib`.** No newlib. `lib/` carries `memcpy`, `memset`,
   `memmove`, `memcmp`, `strlen` and a small `con_printf` console over the
   sim-control register — a struct copy already makes GCC emit a `memcpy` call
   (measured: undefined reference without one). The build adds
   `-fno-tree-loop-distribute-patterns`, without which GCC compiles `memset`'s
   own loop into a call to `memset`.
2. **No 64-bit division, no variable 64-bit shifts.** `uint64_t / uint64_t`
   emits `__udivdi3`, which is not linkable (measured). `mtime` arithmetic is
   add, subtract and compare, all inlined; deadlines are computed as
   `now + ticks`, never `elapsed / rate`.
3. **The vmem is produced by a script, not by `srec_cat`.** Ibex's `common.mk`
   uses `srec_cat`, which is not installed. `objcopy -O binary` is, and a
   short `fw/bin2vmem.py` (run by the default `python3`, which is 3.6;
   `python3.12` is also installed) emits one 32-bit word per
   line from `@00000000` for `$readmemh`, which sidesteps the question of
   whether `objcopy -O verilog` addresses in bytes or words on this binutils.

`crt0.S` and `link.ld` follow Ibex's `examples/sw/simple_system/common/`
shape — zero the registers, set `sp`, clear `.bss`, call `main`, halt via the
sim-control register, and a `.vectors` section with `.option norvc` so every
table entry is exactly four bytes — with the SCP's map: RAM at 0, vectors at
0, reset at `0x80`, stack at the top of the 64 KB. Since 2026-10-05 (platform
plan H18) the stack starts below a 1 KB `.persist` block at `0xFC00`, which
`crt0.S` neither loads nor clears, and `crt0.S` copies `.data` from a load copy
at every reset ([`fw/README.md`](fw/README.md)).

---

## 5. The firmware

Structured after Arm's open-source SCP-firmware — a HAL of register drivers
under a power-domain module under protocol handlers — but written here, small
and bare-metal, because that project's framework (modules, bindings, an
event scheduler, notifications) is far more than twelve domains and one
protocol need.

```
src/pmu/fw/                      * = exists (2026-10-06: all do; each folder has a README)
  link.ld  crt0.S  bin2vmem.py *  Section 4 (no Makefile here: src/soc4/fw/Makefile
                                  builds every image, with the flags of Section 4)
  lib/     lib.h string.c console.[ch]  *
  hal/     scp_regs.h       *    the memory map of Section 2.1
           csr.h            *    CSRs, interrupt enable, WFI
           trap.[ch]        *    handlers: record only; expected-fault support
           timer.[ch]       *    mtime read, deadlines, mtimecmp
           ppu_v1.[ch]      *    PPU register driver (Section 6)
           sim.h            *    the testbench's simulation-control device
           rpmi_db.[ch]     *    the RPMI doorbells: soc4_mbx's RING[k]     F4
           scp_irq.[ch]     *    the interrupt block and the input table    H7
           scp_wdog.h       *    the watchdog: arm, kick, CAUSE             H18
  mod/     pd.[ch]          *    the power domain manager, non-blocking
           agents.h         *    the RPMI agents' indices (SCP_PLAT_AGENTS)
           policy.[ch]      *    the DEVICE_POWER policy (SOC4_DESIGN.md 9.4)
           flog.[ch]        *    the fault log, kept across a watchdog reset
  port/    rpmi_env.[ch]    *    librpmi's environment functions
  rpmi/    scp_rpmi.[ch]    *    the RPMI server: one transport per agent, BASE + DEVICE_POWER
           scp_loop.[ch]    *    the event loop (5.1)
  vendor/librpmi            *    librpmi v1.0.0, unmodified
```

The platform's parts are in `src/soc4/fw`: `soc4_plat.h` (the PPU count and
the domain table `SCP_PLAT_DOMAINS`, every per-domain setting the firmware
keeps, written by hand and force-included into every compile; `mod/pd.h`
defines its fields), the boot (`scp/main.c`, ending in `scp_loop_run()`), the CPU loader
(`mod/soc4_cpu`), the stress test (`test/soc4_stress.c`) and the AP's program.
A test program returns its verdict, which `crt0.S` writes to the testbench's
HALT register; the product image never returns.

Until 2026-10-02 this tree also had `pmu_top`'s test programs under `test/`
(`hello`, `pd_multi`, `ppu_stress`, `ppu_lock_probe`, `ppu_edge_probe`,
`rpmi_loopback`, `rpmi_hw`, `rpmi_dpwr` and its two variants), their doorbell
backends (`hal/rpmi_db_hw.c` for `mailbox_unit`, `hal/rpmi_db_poll.c`, a
loopback), W4.1's dynamic eight-domain policy and its access-gate stub, and its
own `Makefile`. The present `mod/policy.[ch]` and `hal/rpmi_db.c` moved here
from `src/soc4/fw` then. The soc4-only retention-RAM helper `mod/soc4_ret.[ch]`
that came with them was retired on 2026-10-05, when `ppu_set_ret_ram` learned
to write each register `PPU_IDR1` reports present (platform plan F1).

### 5.1 The event loop

Single-threaded, interrupt-driven, no scheduler. Interrupt handlers only
record: which doorbell rang, which PPU raised its line, that the timer
expired. `main` loops on WFI and drains three queues in a fixed order —
PPU events first (they complete transitions and release waiting requests),
then timer expiries (deadlines, hysteresis), then the RPMI transports, T0a
before T0b. librpmi is called only from here: on every pass each transport's
context processes its A2P requests (`rpmi_context_process_a2p_request()`) and
its service groups' events (`rpmi_context_process_all_events()`). A request
that waits on a PPU carries its own deadline and ends in its target state or
in `FAULT` (§7.2), and no handler ever polls.

**As built (2026-10-06).** `rpmi/scp_loop.c` orders a pass differently: the
doorbells first, draining each agent's transport in transport order (one
transport per agent, not T0a and T0b), then `rpmi_context_process_all_events()`,
then the policy's work (`pd_poll()` for the PPU interrupts, completions, the
policy's steps, the wake inputs) and its deadlines, then WFI, then the watchdog
kick. The external interrupt handler only masks `mie.MEIE` and sets a flag;
`scp_irq_collect()` finds the source in thread context. See
[`fw/rpmi/README.md`](fw/rpmi/README.md).

§3.3.3's third system service, *"Consistency: The SCP must ensure that there
are no races between requests"*, is met structurally: one thread, one
domain FSM per domain, and every request goes through it.

### 5.2 The power domain manager (`mod/pd`)

**Built (2026-10-02).** `mod/pd` has one entry per PPU, and its settings come
from the platform's domain table (`pd_cfg[]`, from `SCP_PLAT_DOMAINS`; four
entries in soc4: name, kind, the low-power mode RPMI OFF maps to, the
retention RAM bytes, the expected `PPU_IDR0/1`, and a CPU's boot details;
2026-10-05, platform plan F5). It drives static modes only:
`pd_request_static()` starts a request with a deadline, `pd_poll()` services
the PPU interrupts, `pd_advance()` / `pd_tick()` move requests on and expire
them, `pd_complete()` and `pd_wait_mode()` wait asleep. Reference counts,
hysteresis and the deny/retry/force sequence are in the policy
(`mod/policy.c`). The design doc's state layer (`pd_set_state`, the dynamic
and locked tuples, `pd_boot`) ran on `pmu_top` and was removed with it. The
plan for the full SoC follows.

One table of twelve entries, indexed by the domain number of §2.1:

```c
struct pd {
    enum pd_kind     kind;            /* CPU or DEVICE: which state table applies      */
    struct ppu       ppu;             /* base address, capabilities from PPU_IDR0/1    */
    uint8_t          refcount[NUM_AGENTS];   /* per requestor, design doc §9.3         */
    enum pd_state    state, target;   /* design doc §5.5.1 rows                        */
    struct ppu_tuple tuple;           /* {policy, dyn_en, devactive_en, lock_en}       */
    enum pd_phase    phase;           /* IDLE, AGREEING, TRANSITIONING, FAULT          */
    uint64_t         deadline;        /* PCSM timeout (design doc §5.6.8)              */
    uint64_t         hysteresis_at;   /* when a zero refcount actually powers off      */
    uint8_t          retries;         /* denial back-off                               */
    struct pd_waiter waiter;          /* the RPMI request to answer on completion      */
};
```

Its operations, each traced to the specification in `FUNCTIONS.md`:

| Function | Does |
|---|---|
| `pd_init()` | probe all twelve PPUs (`PPU_IDR0/1`, `PPU_IIDR`, `PPU_AIDR`); **read `PPU_PWPR` back rather than assuming its reset value** (`REGISTERS.md` §2: `PCSMMODESTAT` can make it `MEM_RET`); program masks, retention RAM words, entry delays, device control delays |
| `pd_set_state(dom, state, agent)` | the state → tuple mapping of design doc §5.5.1, then the ordering rule of §5.6.1: **component first when deepening, register first when shallowing** |
| `pd_request_on(dom, agent)` / `pd_release(dom, agent)` | reference counts; `0 → 1` powers on, `1 → 0` arms the hysteresis timer; admission check on the way up |
| `pd_admission(dom)` | the concurrency cap — the design's only thermal actuator (design doc §5.4.3) |
| `pd_on_ppu_irq(dom)` | `STA_POLICY_TRN` completes the phase; `STA_DENY` means *the policy was erased* — re-issue with back-off (design doc §5.6.4b); `UNSPT_POLICY` is a firmware bug, fault; `LOCKED` and `PWR_ACTIVE_EDGE` are bookkeeping |
| `pd_on_timer()` | deadline expiry → `FAULT` (the PPU has no PCSM watchdog, design doc §5.6.8); hysteresis expiry → `OFF` |
| `pd_agent_reset(agent)` | drop every claim an agent held. With the AP the only agent (§7.1), that matters only if the AP ever restarts under a running SCP, and with no warm reset offered (D20, §7.3) nothing does that today; RPMI BASE has no agent-reset service |
| `pd_check_invariants()` | the two §5.5.3 obligations as assertions: the tuple carries the state's context and wake properties, and its exit latency fits; plus the design doc §10 property that no gated domain's readiness gates another's transition |

### 5.3 What "the component agrees" means here

PPU §3.3.2 requires a policy change with functional consequences to be
*"agreed between the controller and the component using a method other than
the device interface Q-Channel"*.

For a device that method is Linux's driver. It stops the accelerator, with its
cores held in reset, before it votes the domain OFF through DEVICE_POWER
(§7.4): the vote is the agreement, and the design doc's §5.6.6 step 4 is that
message. The SCP only powers the domain; the accelerator's run control is
Linux's. A device that is still busy, its `DEVQACTIVE` HIGH, can refuse all
the same, because the SCP's request is static: its Q-Channel adapter denies it
(PPU Table 4-1, `STA_DENY`), and the SCP returns the domain to ON and retries
up to a cap before it forces the power-down.

For a CPU the method is SBI HSM, which OpenSBI carries to the SCP as RPMI HSM
from M2 (§7.5), and the Q-Channel does the rest. The SCP writes the CPU's
policy and reads it back before it answers. CVA6 has no WFI output and is used
unmodified (D17), so the hart declares itself idle instead: as its last store
before WFI, after cleaning its cache, OpenSBI sets the hart's READY bit in
always-on logic (D18). That drops `DEVQACTIVE`, and once the core's bus port
has drained, a PPU whose policy is already `OFF` with `PWR_DYN_EN = 1`
sequences the domain down with no further SCP action. The SCP answers the request as soon as the
policy is programmed and read back; the *transition* completes later,
asynchronously, on `DEVQACTIVE`. In M1 there is no HSM, and the CPU domains
stay ON from boot until a shutdown or reset (§7.3, §7.7).

---

## 6. The PPU driver contract

`hal/ppu_v1` is a register driver for DEN 0051E as
[`src/rtl/ppu/REGISTERS.md`](../rtl/ppu/REGISTERS.md) documents it, and the
firmware checklist of the design doc §5.6.9 is its specification. Six rules
the driver enforces so that no caller has to:

1. **Every `PPU_PWPR` write is read back.** An unsupported policy leaves the
   register unchanged and raises `UNSPT_POLICY_IRQ` (PPU §4.1.1); `ppu_set_policy`
   returns an error rather than reporting success. `REGISTERS.md` §4.1 adds the
   sharper point: the *whole* write is discarded, `LOCK_EN` and `PWR_DYN_EN`
   included. A `LOCK_EN` or `PWR_DYN_EN` request on a build without the lock or
   without any dynamic mode is refused *before* the write (`PPU_E_UNSUPPORTED`):
   there the bit is reserved, WI/RAZ (Table 5-2, §5.2), so the PPU would take
   the write as a static policy (fixed 2026-10-05; `hal/ppu_v1.h` lists every
   return).
2. **Denial is erasure.** On `STA_DENY_IRQ` the policy has been reverted to the
   current mode (PPU §4.1.1, Table 4-1). The driver reports *denied* and the
   manager re-issues; nobody assumes the value it wrote is still there.
3. **Every transition has a deadline.** The PPU waits for `PCSMPACCEPT` forever
   and has no power-good input. The driver does not wait:
   `mod/pd`'s `pd_request_static` and `pd_wait_mode` take a deadline; expiry
   is a fault, not a retry.
4. **Leaving a locked mode is one write.** `{LOCK_EN=0, PWR_DYN_EN=1,
   PWR_POLICY=ON}` in a single `PPU_PWPR` write; `PPU_UNLK` followed by a policy
   write re-locks (design doc §5.6.7, *the subtle bug*). `ppu_unlock` exists for
   the case where automatic re-locking is wanted, and its comment says so.
5. **`PWR_DEVACTIVEEN` is restored after every power-up**, or the domain can
   never idle again with no functional symptom (design doc §5.6.9 item 5).
6. **`DEVREQEN` changes only in static mode with the target reached, and a
   channel is re-enabled only from `ON`** (PPU §4.1.3; `REGISTERS.md` §5,
   *Disable the device channel*).

Four more rules were found or confirmed in bring-up. The manager keeps 7–9;
rule 10 is enforced in both the driver and the manager:

7. **`LOCK_EN` is written last, and only in the mode it is meant to hold.**
   PPU §3.4.3 (*Locking the PPU*) locks the PPU when `PPU_PWPR` is written with `LOCK_EN` and
   `PWR_DYN_EN` while it sits in *any* lockable mode, so a one-write
   `{OFF, LOCK_EN}` from `MEM_RET` pins the domain in `MEM_RET` (design doc
   §5.6.9 item 4). Before finding 1 of Section 10 was fixed, this PPU
   stranded it in `ON` instead. The floor goes in unlocked; the lock follows
   once the mode is reached.
8. **Nothing is rewritten that is already in force — but "in force" means the
   hardware is there, not just that the registers say so.** A domain whose
   registers match the target but whose mode does not is re-driven, and the
   first write, `LOCK_EN` clear, is what releases it.
9. **The device control delays cover switch settling.** The switches
   acknowledge nothing (`PGOOD_EN = 0`, no `-ack_port` in
   `upf/ppu_pd_top.upf`), so `pd_init` programs `PPU_DCDR0/1` before any domain
   comes up: `ISO_CLKEN_DLY` = `PD_SWITCH_SETTLE` (20 cycles, 200 ns), then
   `CLKEN_RST_DLY` = 4 for `DEVCLKEN`'s resynchronization (since 2026-10-05,
   platform plan F11, raised per domain to the domain table's `ckrst_lat` where
   larger, with `CLKEN_ISO_DLY` and `RST_HWSTAT_DLY`; soc4: 6 on ACC1). Reset
   is therefore released no sooner than ~26 cycles after the PCSM accepts; `soc4_tb`
   measures every power-up against the 20-cycle budget. What no PPU delay can
   cover is isolation release, which follows `PCSMPACCEPT` directly — a switch
   slower than a cycle or two needs its PCSM to hold the accept. `ppu_pcsm`
   can, since finding 4 was fixed: `ppu_pd_top`'s `PCSM_LOGIC_SETTLE` (and
   `PCSM_RET_SETTLE` for the retention save). Both are 0 here, which is right
   for the UPF's ideal switches; silicon values would come from the switches.
10. **`PWR_DYN_EN` changes one at a time.** PPU §4.1.1, *Power Policy
    Programming*: after changing `PWR_DYN_EN`, software "must wait until the
    value is reflected in ... `PPU_PWSR.PWR_DYN_STATUS` before making further
    modifications to the dynamic transition enables. Otherwise the PPU behavior
    is UNPREDICTABLE." The status catches up only when a transition in flight
    finishes. `ppu_set_policy` refuses a write that would break this
    (`PPU_E_STATE`, `ppu_dyn_settled()` says whether it would), and
    `pd_request_static` / `pd_request_mode` wait for the status before writing
    (`PD_E_BUSY` from `pd_request_mode` if it never comes). Added 2026-09-29, when the stress test
    showed nothing had been stopping two quick state changes from breaking it.

The sequences themselves are `REGISTERS.md` §5 verbatim — static change,
dynamic enable, lock, delays, interrupt service — and the design doc §5.6.6
and §5.6.7 tables are the manager's deepening and shallowing scripts. Timing
of the driver is not on the critical path: tier-2 transitions happen without
it.

---

## 7. RPMI over shared-memory queues

The AP asks the SCP for power through **RPMI v1.0**, the RISC-V Platform
Management Interface, over its shared-memory transport
(`riscv,rpmi-shmem-mbox`), and the SCP answers with **librpmi v1.0.0** as its
RPMI server. The AP's own firmware interface is SBI, served by OpenSBI v1.9:
there is no PSCI, and no SCMI. SCMI v3.0 was the earlier plan for this
section, superseded on 2026-09-30 by the decisions in
[`RPMI_STACK_DECISIONS.md`](../../Proposed_PMU/RPMI_STACK_DECISIONS.md), which
also records the alternatives not taken and defines the decisions (D…),
assumptions (A…), work items (W…) and milestones (M1, M2) cited below.

Service-group, service and queue names are those of the RPMI v1.0
specification (`riscv-non-isa/riscv-rpmi`, tag `v1.0`), which is not in
`references/standards/`; no message, service-group or state encoding is
restated here. The design doc §3 predicted that *"Only the power domain
management protocol is needed"*. RPMI splits that protocol by what is being
powered, and five of its service groups cover it:

| Service group | Transport | From | Here |
|---|---|---|---|
| BASE | T0a, T0b | M1 | discovery; built into every librpmi context |
| SYSTEM_RESET | T0a | M1 | cold reset and shutdown; no warm reset (§7.3) |
| DEVICE_POWER | T0b | M1 | the eight DSP and NPU domains (§7.4) |
| HSM | T0a | M2 | one CPU domain per hart (§7.5) |
| SYSTEM_SUSPEND | T0a | M2 | the CPU domains off, DDR powered (§7.6) |

The rest are not implemented. No DVFS, one clock and one rail leave nothing
for CPPC, PERFORMANCE, CLOCK or VOLTAGE (A12); SYSTEM_MSI is not used
(decision record §2.3; there is no IMSIC, D7); MANAGEMENT_MODE, RAS_AGENT and
REQUEST_FORWARD are not in the plan. The item-by-item checklist is
`FUNCTIONS.md` §8–9.

**soc4 (2026-10-01, built).** soc4 narrows this to what its scope needs
(SOC4_DESIGN.md Sections 9.1 and 9.7): **one transport, T0a, carrying BASE
and DEVICE_POWER**, over soc4's TL-UL mailbox, with the AP's test program
(on librpmi's transport layer) or a TL-UL bus-functional model as the agent.
DEVICE_POWER has four domains, `DOMAIN_ID` = PPU index (CPU0, CPU1, ACC0,
ACC1), the votes held by `rpmi/scp_rpmi.c` (until 2026-10-05, the AP's vote
in `mod/policy.c`). SYSTEM_RESET is not registered. Since 2026-10-05 (platform
plan H11–H13, F6) there is one transport and one context per agent, the AP's
and the RPU's, and the policy sees the agents' votes combined.
The two-transport plan below, with T0b and SYSTEM_RESET, was built on
`pmu_top` (W2.1–W4.1) and retired with it on 2026-10-02.

### 7.1 One agent, two transports

The AP is the only agent (D3): DSP and NPU firmware never talk to the SCP.
OpenSBI owns both transports, and both are M-mode contexts:

| Transport | Carries | How Linux gets there |
|---|---|---|
| **T0a** | BASE and SYSTEM_RESET in M1; HSM and SYSTEM_SUSPEND from M2 | SBI SRST, and from M2 SBI HSM and SUSP; OpenSBI makes the RPMI requests |
| **T0b** | BASE and DEVICE_POWER | SBI MPXY: OpenSBI exposes DEVICE_POWER to Linux as an MPXY channel |

- **Queues.** Each transport has at least the A2P REQ and P2A ACK queues of
  RPMI's shared-memory transport, in the queue SRAM (§2.1), with 64-byte
  slots. OpenSBI enqueues a request and rings the transport's doorbell; the
  event loop dequeues it, acts, and — unless the request is posted — enqueues
  the acknowledgement.
- **Doorbells.** One 32-bit AP-to-SCP doorbell per transport, in
  `scp_mailbox` (§2.3). OpenSBI polls for the acknowledgement, so there is no
  SCP-to-AP doorbell.
- **Protection.** The queue SRAM and the doorbells are new always-on hardware
  (W2.1), behind a firewall that admits only the CVA6 cores. Linux never
  touches the queues, and M-mode versus S-mode separation on them comes from
  the AP's PMP (A14).
- **To confirm.** Whether OpenSBI v1.9 accepts two `riscv,rpmi-shmem-mbox`
  nodes, one per transport, is unverified (decision record §5).

### 7.2 The SCP's side

- **Runtime.** A bare-metal event loop (§5.1), with librpmi v1.0.0 as the RPMI
  server and one librpmi context per transport. Interrupt handlers only set
  flags, librpmi is called only from the loop, and T0a is serviced before T0b.
  Zephyr is re-evaluated at M2 against a measured image (D14).
- **Layers.** Under librpmi's platform callbacks sits a new policy layer
  (W4.1), and under that the `pd` manager and the `ppu_v1` driver, which stay.
- **`pd` becomes non-blocking** (done: `pd_request_static`, §5.2). Before,
  its waits slept in WFI until the mode was reached (`pd_wait_mode`). For
  RPMI each request carries its own deadline — §6 rule 3, per request — and ends either in its target state or in `FAULT`.

### 7.3 SYSTEM_RESET (T0a, M1)

`SYSRST_RESET` is a posted request, so the AP expects no reply, and its reset
types are SBI SRST's. librpmi's platform reset operation is not expected to
return.

| Reset | What the SCP does |
|---|---|
| Cold reset | Asserts the cold-reset request port of `scp_rstctl`, a new SCP reset controller (W3.1; decision record §2.4). The board-side hardware is not defined yet (D10); until it is, a cold reset is a chip reset (A5) |
| Shutdown | Takes every domain to `OFF`, forcing it if needed, then asserts `scp_rstctl`'s PMIC-off request port |
| Warm reset | Not offered (D20): every reboot is a cold reset. The SCP lists only shutdown and cold reboot, and Linux reboots cold by default |

The testbench watches both request ports, and M1.3 passes on that
bus-functional model; the board side comes later. The SCP has no path to reset
itself today.

### 7.4 DEVICE_POWER (T0b, M1)

Eight domains, DSP0–3 and NPU0–3. RPMI keeps CPUs out of this service group —
*"system and CPU power management is handled by already defined service groups
such as SYSTEM_RESET, SYSTEM_SUSPEND and HART_STATE_MANAGEMENT"* — and numbers
its domains by a `DOMAIN_ID` counted from 0. The proposed IDs are 0–3 for
DSP0–3 and 4–7 for NPU0–3 (decision record §2.1).

With one agent, DEVICE_POWER keeps one vote per domain, and `pd`'s
per-requestor reference counts (§5.2) have a single requestor. The policy is
two rules: a domain is ON if and only if the AP voted ON, and power-off waits
out a hysteresis window.

| Request | What the SCP does |
|---|---|
| `DPWR_SET_STATE` to ON | Powers the domain up and replies only once it is up, within a deadline. An expired deadline is `FAULT`, and the reply is an error |
| `DPWR_SET_STATE` to OFF | Records the vote and powers the domain off after the hysteresis window. The request is static, so a busy device's Q-Channel adapter can refuse it (PPU Table 4-1, `STA_DENY`): the SCP returns the domain to ON and retries, up to a cap, and then forces the power-down. A negative test drives a busy device |
| `DPWR_GET_STATE` | The agent's own last vote, never the physical state |

**Why the vote.** librpmi v1.0.0 calls the platform's `set_state` only when its
`get_state` differs from the request. If `get_state` reported the physical
state, an ON cast during an OFF's hysteresis window would find the domain still
ON and never reach the SCP, and the domain would go off anyway. The
specification describes `DPWR_GET_STATE` as returning *"the current power
state"*; reporting the vote is the decision record's choice (§2.2).

**Synchronous replies.** librpmi's DEVICE_POWER platform operations are
synchronous (`struct rpmi_dpwr_platform_ops`), so a reply leaves when the
operation returns. How an ON's wait sits with a non-blocking `pd` and with
T0a's priority is for W2.2–W2.3 to settle.

**Linux's part.** Linux quiesces an accelerator, with its cores held in reset,
before voting it OFF (§5.3). The SCP only powers domains. Linux owns each
accelerator's run control: it releases the core reset and sets the boot
address through a per-instance control block in the AP's address space, and a
newly powered accelerator's cores stay in reset until it does.

The device rows of design doc §5.5.1, and what reaches each:

| Device state (design doc §5.2) | PPU tuple | Reached by |
|---|---|---|
| `RUN` | `ON`, dyn, wake armed | an ON vote |
| `RUN`, weights retained | floor `FUNC_RET` | not decided |
| `RUN`, buffers dropped | floor `MEM_OFF` | not decided |
| deep idle | floor `MEM_RET`, wake armed | not decided |
| `OFF` | `OFF`, `PWR_DEVACTIVEEN = 0`, `LOCK_EN = 1` | an OFF vote, after the hysteresis window |

RPMI allows vendor-specific DEVICE_POWER states besides ON and OFF (*Power
State Format*), but librpmi v1.0.0 reports only ON and OFF, so which request,
if any, reaches the three interior rows is open.

### 7.5 HSM (T0a, M2)

There is one power domain per CPU (D1), so each hart's `HSM_HART_START`,
`HSM_HART_STOP` and `HSM_HART_SUSPEND` drives its own CPU's PPU — hart `h`,
`PD_CPUh` — and there is no last-hart rule.

A per-hart **READY** bit in always-on logic (D18, which amends D4; W5.1) keeps
deep idle race-free without changing the core. OpenSBI sets it as the hart's
last store before WFI, after cleaning the cache; hardware clears it on any
enabled wake for that hart; and the CPU's Q-Channel adapter also waits for the
core's bus port to drain before it accepts. So only a hart that asked to
suspend can count as idle, and HSM reports a hart SUSPENDED only while its
READY bit is set. The core may still be finishing its last fence and WFI when
power-down starts: harmless for `OFF`, whose state is already saved, and for
`FULL_RET`, whose frozen pipeline resumes. The activity equation and the full
list of clear conditions are in the decision record, §2.5.

| CPU state (design doc §5.1) | PPU tuple | Reached by |
|---|---|---|
| `RUN` (and `IDLE_STANDBY`: clock gating, no SCP action) | `ON`, dyn | boot (§7.7); `HSM_HART_START`: the one-write unlock, then `PWR_DEVACTIVEEN` restored. The start address is OpenSBI's business |
| `IDLE_RETENTION` | floor `FULL_RET` | a retentive `HSM_HART_SUSPEND`: nothing, or the floor programmed once, with the PPU's dynamic policy doing the rest (design doc §5.4.1, tiers 1–2) |
| `SLEEP` | `OFF`, wake armed | a non-retentive `HSM_HART_SUSPEND` |
| `OFF` | `OFF`, wake disarmed, locked | `HSM_HART_STOP` |

Before a non-retentive `OFF` — a stop, a non-retentive suspend or system
suspend — an OpenSBI platform override cleans the departing core's D-cache,
since there is no hardware clean (decision record §2.3).

### 7.6 SYSTEM_SUSPEND (T0a, M2)

The CPU domains go off; DDR stays powered, with its controller and PHY
always-on (D8). The suspend is RPMI's default `SUSPEND_TO_RAM`, for which RPMI
presumes that every hart but the requesting one is already STOPPED.

### 7.7 Boot in M1

The SCP powers `PD_CPU0`–`PD_CPU3` ON and releases all four harts at the AP
ROM vector. M1 does not use RPMI HSM, and without it OpenSBI v1.9 starts the
secondary harts by IPI, so all four must enter at cold boot; U-Boot SPL is
built with `SPL_SMP`. soc4's SCP boots no domain on its own: the CPUs come up
when the AP votes them ON (`soc4/fw/scp/main.c`; `pmu_top`'s `pd_boot`, which
powered CPU0 alone, was removed with it). W2.5 changes that for the SoC.

---

## 8. Build stages F0–F7

Each stage is a testbench, a firmware program and a `make` target, following
`src/Makefile`'s pattern; the power-aware variants (`...pa`) re-run the same
testbench with `ppu_axi_pd_top` under `src/upf`, the way `ppuaxi`/`ppuaxipa`
do. Testbenches go in `src/tb/`, UPF in `src/upf/`, test programs with their
platform (soc4: `src/soc4/fw/test/`).

**2026-10-02.** The F0–F4 targets in the table (`scphello`, `scppd`,
`scppdpa`, `scprpmi`, and the `scpstress`, `scprpmihw` and `scpdpwr` targets
that followed) ran on `pmu_top` and were removed with it. Their functions run
on soc4 now: boot, traps, the console and access faults in every soc4 run;
the driver and the manager in `soc4stress` / `soc4stresspa` (36 mode pairs on
four PPUs) and in `soc4` / `soc4bfm`; RPMI BASE and DEVICE_POWER over the real
TL-UL mailbox in `soc4` and `soc4bfm`, with the firewall, deny/force, deadline
faults and recovery in `soc4bfm` and the negative controls in `soc4neg`
(SOC4_DESIGN.md Section 11). The table is kept as the plan's record.

| Stage | Target | Builds | Proves |
|---|---|---|---|
| **F0** ✅ | `ibexlint` · `scpfw` · `scphello` | `scp_top` with `scp_ram`, `timer`, sim control and `scp_data_split` over Ibex's `bus`; `fw/` skeleton (`crt0.S`, `link.ld`, `lib/`, `bin2vmem.py`); `test/hello.c` | the toolchain rules of §4 end to end: boot at `0x80`, vector table, a timer interrupt taken through `mtvec`, WFI and wake, console output, halt with status |
| **F1** ✅ | `scppd` · `scppdpa` | `scp_axi_lite_master`, `scp_axi_lite_demux`; built straight onto twelve `ppu_axi_pd_top` rather than one `ppu_top_axi_lite` | ID registers over AXI4-Lite, policy writes and status polls, `STA_POLICY_TRN` on each PPU's own fast line, `DECERR` to an access fault. Still to do: a forced `WAKE_TIMEOUT` `SLVERR` |
| **F2** ◐ | `scppd` · `scppdpa` | `hal/ppu_v1`; the device's own `deny_enb` for denial | refused write detected, denial re-issued, deadlines, one-write unlock, `PWR_DEVACTIVEEN` restored, the device control delays. Still to do: `DEVREQEN` ordering, and a PCSM that withholds `PCSMPACCEPT` for the deadline to fire on |
| **F3** ◐ | `scppd` · `scppdpa` | twelve `ppu_axi_pd_top`; `mod/pd` | the §5.5.1 mapping for every state, **independence** (all twelve checked after every step), concurrent transitions in opposite directions, tier-2 wakes with no firmware in the loop. Still to do: requestors, reference counts, hysteresis, the concurrency cap — they arrive with the mailbox (F4) |
| **F4** | `scprpmi` · `scprpmipa` | `scp_mailbox` with two AP-to-SCP doorbells, the queue SRAM and its firewall (W2.1); librpmi v1.0.0, its environment port and `main.c` (W2.2–W2.3); the DEVICE_POWER policy (W4.1); `scp_rstctl`'s two request ports (W3.1); an AP BFM standing in for OpenSBI on T0a and T0b | BASE discovery on both transports; on each of the eight DEVICE_POWER domains, ON answered only once the domain is up, OFF acted on only after the hysteresis window, `DPWR_GET_STATE` returning the vote, and a busy device's refusal retried to the cap and then forced; cold reset and shutdown reaching the request ports (M1.3); T0a serviced before T0b |
| **F5** | `scpboot` | `mod/boot`, `scp_wdt`; optionally a boot ROM | §3.3.3 *System initialization*: reset release, twelve PPUs defaulted, `PD_CPU0`–`PD_CPU3` up and all four harts released at the AP ROM vector (§7.7), eight `OFF`; watchdog expiry to NMI to reset with the syndrome read back; `WARM_RST` of one domain as a recovery action (PCSA §7.3.3) |
| **F6** | `scpwake` · `scpwakepa` | `scp_wake_aggr`; `rtl/acg`'s gate on one device port, with an error mode | an access to an accelerator the AP voted `OFF` is answered at once with an error, and the SCP logs the master and address (D21, a departure from §7.2.8's stall-and-wake: the SCP never powers a domain on for an access); an access that arrives while a power-up the AP asked for is in progress is held until `ON`; and the `SLEEP`/`OFF` distinction — a wake at a disarmed, locked PPU changes nothing and the SCP sees only the edge interrupt |
| **F7** | M2 | RPMI HSM and SYSTEM_SUSPEND on T0a (§7.5, §7.6); the READY bits and CPU wake logic (W5.1); HSM and cpuidle (W5.2). Conditional, only if F3–F6 measurement asks for it: the P-Channel PPU of design doc S7 | each hart started, stopped and suspended on its own CPU's PPU, with no last-hart rule; a hart counted as idle only while its READY bit is set and its bus has drained; system suspend with DDR powered throughout |

F0 is where the surprises are cheapest — every toolchain assumption in §4 is
tested by a program that prints one line — so it comes first even though it
touches no PPU. F1 and F2 are the driver, on one domain, under UPF before
there are twelve. F3 is the manager and the scale-out; F4 is the interface;
F5 and F6 are the two system services §3.3.3 lists that F3 does not already
cover.

Two rules carried over from the rest of the repository apply throughout:
**VCS** (`SIM=vcs`; the targets also accept `SIM=xcelium`, whose licence
expired on 2026-09-15, and refuse Icarus, which cannot compile Ibex), and **testbench probes never read inside a switched domain** — the
SCP observes its twelve domains through their PPUs' registers, which is also
what makes the firmware's view of the system the thing under test.

---

## 9. Decisions taken, and what is worth confirming

1. **A real core instead of a behavioural SCP.** The design doc's S4 chose
   TB-only; this supersedes it because the questions worth answering — does
   the tier-3 latency fit, does the event loop keep up with twelve domains
   and four requestors, does the driver survive denials and timeouts — are
   questions about firmware on a core, not about a model.
2. **Ibex `small`, no PMP, no SecureIbex.** §3 gives the argument; both are one
   parameter away in `scp_core.sv`. Revisit if the SCP ever hosts code from a
   second trust domain, or if fault-injection resistance enters scope.
3. **Bare-metal event loop, not an RTOS and not SCP-firmware's framework.** The
   load is one protocol and twelve FSMs. If notifications, delayed responses
   and a second protocol arrive together, an event queue with priorities is
   the first thing to add, not a scheduler.
4. **One AP BFM plays OpenSBI on both transports.** On the chip both are
   M-mode contexts of the one agent, and Linux reaches DEVICE_POWER only
   through SBI MPXY, so M-mode versus S-mode separation is the AP's PMP, and
   the firewall keeps DMA out (A14, W2.1).
5. **The DEVICE_POWER numbering and the PPU tuples of §7.4–7.5 are this
   design's.** RPMI fixes only ON, OFF and a `DOMAIN_ID` counted from 0. The
   IDs, the tuples, and what reaches the interior device rows are proposed
   here; confirm them before the AP side is written against them.
6. **DEVICE_POWER ON replies only once the domain is up**, within a deadline,
   while OFF replies at once and acts after the hysteresis window. librpmi's
   DEVICE_POWER operations are synchronous, so W2.2–W2.3 settles how that wait
   sits with a non-blocking `pd` and with T0a's priority.
7. **No system counter shared with the APs yet.** §6.4.1 wants one mapped in
   both address spaces; the design's APs have their own always-on timers and
   nothing in F0–F6 needs a common time base. It is a 4 KB window when it does.
8. **No boot ROM in F0–F4.** The RAM is preloaded by the testbench. §6.4.1's
   ROM-then-load flow is F5's option and matters for silicon, not for proving
   the firmware.
9. **`PGOOD_EN = 0`, no acknowledge ports, delays instead (2026-09-29).** The
   power switches in `upf/ppu_pd_top.upf` are control-only, the PCSMs do not
   wait for a power-good, and switch settling is covered by the PPU device
   control delays the firmware programs (Section 6, rule 9).
10. **VCS for now, power intent included**, because Xcelium's licence expired on
    2026-09-15. The Xcelium targets are kept.

---

## 10. Bring-up results and findings

This section is the bring-up record on `pmu_top`, twelve domains, as of
2026-09-29. `pmu_top`, `pmu_tb` and the targets and programs below were
removed on 2026-10-02; the findings and their fixes stand. The current
results are soc4's: `make soc4stress` reports all 34 features PASS on four
static-only PPUs (`S.DYNREQ` was a DEVIATION, a driver finding, until the
driver fix of 2026-10-05),
and [`PPU_FW_CONFORMANCE.md`](PPU_FW_CONFORMANCE.md) maps every row.

### 10.1 What ran

All under VCS W-2024.09-SP2 (`SIM=vcs`), 2026-09-29.

| Target | Program | Firmware checks | Testbench checks | Result |
|---|---|---:|---:|---|
| `make scphello SIM=vcs` | `hello` | 8 | 6 | PASS |
| `make scppd SIM=vcs` | `pd_multi` | 1208 | 7070 | PASS |
| `make scppdpa SIM=vcs` | `pd_multi` under UPF | 1208 | 7959 | PASS |
| `make scpstress SIM=vcs` | `ppu_stress`: 35 features | 7028 | 22692 | PASS: 35 features PASS, 0 DEVIATION |
| `make scpstresspa SIM=vcs` | `ppu_stress` under UPF | 7028 | 23694 | the same |

The testbench counts rose with the stress test's additions to `pmu_tb`: the
spec tables checked at every committed hop, and the Table 4-5 spacing checks.
[`PPU_FW_CONFORMANCE.md`](PPU_FW_CONFORMANCE.md) is the stress test's report:
every feature, the clause it covers, how it is checked, and its status.

`pd_multi` (header of `fw/test/pd_multi.c`) walks the whole manager: probe
and ID checks on twelve PPUs; bus errors as access faults; boot (CPU0 up,
eleven locked OFF); each domain up and down with all twelve checked after
every step; eleven transitions in flight at once and opposite directions at
once; every power mode, including the direct `OFF → MEM_RET` hop and
`WARM_RST`, on a CPU, a DSP and an NPU; `SLEEP` wakes with no firmware in the
loop; a wake bouncing off a locked, disarmed `OFF`; a busy device's denial and
the re-issue; refused policies; and the device states' autonomous floors.

The testbench's checks are independent of the firmware's: every `CHECK` the
firmware issues is compared with the PPU's committed mode, the PCSM's committed
mode and rail controls, and `PPUHWSTAT`; under UPF also with whether the
domain's logic has really lost its supply. `ppu_monitor` and `ppu_power_model`
run on all twelve domains, the AXI4-Lite VALID/payload rules on the SCP's
manager port, and every power-up is held to the 20-cycle settling budget
(shortest seen: 30 cycles, over 56 power-ups). Removing the delay programming
from `pd_init` fails all 56 and the run.

Under UPF, VCS's low-power checker also reports, outside the verdict: no
errors (there were 50 `LP_SAVE_RETPWRDN` and 39 `LP_RESTORE_RETPWRDN` before
finding 3 below was fixed), 5 `LP_RET_PWR_OFF` warnings (the retention rail dropping after each `FULL_RET`
restore, discarding the shadow copy — expected) and 24 isolation warnings at
time zero (the isolation enable is X before reset while each `PD_DEV` starts
unpowered).

### 10.2 Findings in the PPU and PCSM hardware

Bring-up and the stress test found five things below the firmware. On
2026-09-29 each was cross-checked against the text of DEN 0051E, the PCK-600
TRM and AMBA LPI (IHI 0068C), and each held. Findings 1, 2 and 5 were
deviations of the PPU from DEN 0051E. Findings 3 and 4 were in `ppu_pcsm`, the
PCSM model, which DEN 0051E constrains only through its P-Channel (§4.1.6).

**All five are fixed (2026-09-29).** The root causes, the fixes and how each was
proven are in [`rtl/ppu/FIX_PLAN.md`](../rtl/ppu/FIX_PLAN.md). Each fix has a
regression check in the PPU's own suite that fails without it, and the PPU's
plain-RTL regression runs under VCS (`make ppuall SIM=vcs`). `make scpstress`
now gives 35 features PASS, 0 DEVIATION, and under UPF the retention
checker messages of finding 3 are gone. The firmware's workarounds stay: they
are correct against the fixed PPU as well (rules 7 and 8).

1. **A write-time lock launched the hop it should have prevented**
   (`rtl/ppu/ppu_seq.sv`). PPU §3.4.3, *Locking the PPU*: the PPU is locked
   when "The PPU_PWPR is written with LOCK_EN and PWR_DYN_EN set to 0b1 and:"
   ... "The PPU is in a lockable power mode." — and a locked PPU makes only the
   two `_EMU` transitions the section lists. `locked_q` was set on the same edge
   that `S_IDLE` launched the first hop toward the new policy, because
   `hop_needed` read its old value: `{OFF, PWR_DYN_EN, LOCK_EN}` written in
   `MEM_RET` ended locked in `ON`, and so did `{ON}` written in `OFF`.
   **Fix:** `lock_on_write`, the write branch of the lock condition available
   combinationally, holds `final_tgt` on the write's own cycle. **Proof:**
   `ppu_pd_tb` P36 (three variants, fails without the fix);
   `make scprun FW_PROG=ppu_lock_probe SIM=vcs` now reports `CONFORMANT`;
   `LOCK.RACE` PASS. The RTL's "Section 3.3.4" lock citations are now §3.4.3.
2. **A disarmed PPU's edge interrupt waited for a bus access**
   (`rtl/ppu/ppu_top.sv`). PPU §4.1.3, *DEVACTIVE Enables*: "These enables have
   no effect on the generation of interrupts. If an interrupt for a DEVACTIVE
   is unmasked it still generates an interrupt event when the input changes."
   The PPU asked for its gated clock on `DEVQACTIVE` only with
   `PWR_DEVACTIVEEN` set, so `ppu_irq`'s edge detector, clocked by it, could not
   see an edge until an unrelated register access ran the clock — 4,950 cycles
   later in the stress test. **Fix:** while `PPU_IESR` selects an edge, the PPU
   requests its clock whenever the input differs from the level the detector
   last saw (`qactive_seen`), in either direction; with `PPU_IESR` at none
   nothing changes. **Proof:** `ppu_clkq_tb` G9, on a real clock controller:
   the interrupt with no access, the clock gating again afterwards, a fall
   tracked while gated, and zero clock edges with `PPU_IESR` at none;
   `make scprun FW_PROG=ppu_edge_probe SIM=vcs` reports `TIMELY`;
   `EVT.EDGE_OFF` PASS.
3. **Retention save/restore strobed on every power cycle**
   (`rtl/ppu/ppu_pcsm.sv`; PCSM model). `ret_n` fell on every logic power-down
   and rose on every power-up, `OFF` and `MEM_RET` included, while the
   retention rail was only on for `FULL_RET`: a save into, and a restore from,
   unpowered shadow cells each time, 50 `LP_SAVE_RETPWRDN` and 39
   `LP_RESTORE_RETPWRDN` errors in one `pd_multi` run under UPF. **Fix:** the
   logic retention machine runs only for modes whose Table 3-1 Logic Mode is
   RET (`FULL_RET`; `LOGIC_RET` does not exist on a Q-Channel PPU). RAM
   retention, which `MEM_RET` and `FUNC_RET` use, is a separate path and is
   unchanged. **Proof:** zero `*_RETPWRDN` messages in `scppdpa` and
   `scpstresspa`; `ppu_pcsm_pgood_tb` check M; `ppu_power_model` PU9 is the
   full rule again ("a save with no retention supply") and fires 54 times in
   `ppu_pd_tb` against the unfixed PCSM.
4. **The PCSM's retention sequencing rested on a timing margin**
   (`rtl/ppu/ppu_pcsm.sv`; PCSM model). DEN 0051E §4.1.6: "The power
   transition in the PCSM must happen between t1 and t4 in Figure 4-15, before
   the P-Channel transition is completed by the PCSM" — t4 being
   `PCSMPACCEPT` falling. The handshake was left free to complete without the
   retention machine, on the argument that the save always leads the supply
   removal by a cycle. At `PGOOD_EN = 1` the save waited for the retention
   switch and that margin went: the save landed 1 to 31 cycles after the
   logic supply was removed, a power-up during the wait stranded the machine
   with `ret_n` LOW and the retention rail on, and the restore, which followed
   the logic rail's control rather than its supply, ran ahead of any logic
   switch of two cycles or more. At `PGOOD_EN = 0`, this SoC's setting,
   nothing waited for either switch. **Fix:** `PCSMPACCEPT` is held until
   every step of the transition is done — the save, the restore, the logic
   rail up, and at `PGOOD_EN = 1` the logic rail and the retention rail
   confirmed down, so no later power-up can go by a stale acknowledge -- nor
   the first one after a reset with the domain ON (`ack_on_fresh`). New
   `RET_SETTLE` and `LOGIC_SETTLE` parameters give the settling times at
   `PGOOD_EN = 0`; both default to 0, right for the UPF's ideal switches, and
   `ppu_pd_top` passes them through as `PCSM_RET_SETTLE` and
   `PCSM_LOGIC_SETTLE`. The cost at the defaults is two cycles on each
   `FULL_RET` entry and each exit. **Proof:** `make ppupcsmpg SIM=vcs`, now a
   regression: 15 configurations (both P-Channel configurations at
   `PGOOD_EN = 1` with switches of 0 to 30 cycles, `PGOOD_EN = 0` ideal, and
   `PGOOD_EN = 0` with settle times), each with directed checks, eight
   continuous checks and a random walk of the PPU's hops, all PASS; each of
   twelve mutations of the fix fails it.
5. **`STA_POLICY_TRN`'s first condition tested the status, not the register**
   (`rtl/ppu/ppu_seq.sv`). PPU §4.1.2, *Full Policy Transition Completion*,
   first condition: "Following the write of a supported policy to PPU_PWPR
   when the PPU is not in transition, and both PPU_PWPR.PWR_DYN_EN and the
   PPU_PWPR.OP_DYN_EN are set to 0b0." The sequencer tested `dyn_status_q`,
   which on that cycle still held the enable from before the write, so the
   answer was wrong exactly when the write changed `PWR_DYN_EN`: 50 of 50 and
   49 of 49 such writes in the stress test. **Fix:** `!pwr_dyn_en` for
   `!dyn_status_q`. **Proof:** `ppu_pd_tb` P35 (fails without the fix);
   `EVT.PTRN1` PASS.

### 10.3 Simulator notes

- **VCS is stricter than Xcelium in one place the PPU RTL hit:**
  `ppu_ip_sram.sv` wrote its array from an `always_ff` and a second process,
  which IEEE 1800 §9.2.2.4 forbids (VCS `Error-[ICPD]`). It is a plain `always`
  now; behaviour is unchanged.
- **VCS native low power** takes the design top as an instance path
  (`set_design_top soc4_tb/u_dut` today, `pmu_tb/u_dut` then; no
  `-testbench` form), energises rails with the IEEE 1801 `UPF::supply_on()`
  from a second top (now `tb/soc4/soc4_pa_supply_vcs.sv`), rejects a UPF
  `-ack_port` on a net the RTL also drives (`UPF_ACK_CC`), and reads
  `-ack_delay` in nanoseconds. Generate scopes resolved as
  `g_pd[i].u_dom/u_pd`. See `upf/soc4_tb_vcs.upf`.
- **Xcelium elaborates without a licence** on this machine; only simulation
  checks one out. `make scppdpa SIM=xcelium` built all twelve domain pairs from
  `upf/pmu_tb.upf` (both since removed) and stopped at `NOLICN`.
- **VCS warns 182 times on the vendored Ibex under `ppu_stress`**:
  `RT-MTOCMUCS`, "more than one condition match" on the `unique case (1'b1)` at
  `ibex/rtl/ibex_alu.sv:91` ("multiply/divide owns the adder" against "negate
  operand B"). The decoder gives every RV32M instruction `ALU_ADD`, so both
  cannot hold for one settled instruction. The warnings land on clock edges
  while multiplies and divides are in flight, which points to a zero-time
  glitch as the next instruction's operator arrives rather than a wrong result.
  Every arithmetic-dependent check in the run passes, and `pd_multi` does not
  trigger it. Left alone: Ibex is vendored verbatim.
