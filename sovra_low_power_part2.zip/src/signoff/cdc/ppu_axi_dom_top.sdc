# ppu_axi_dom_top.sdc -- the PPU domain wrapper with its device clock
# ASYNCHRONOUS to the PPU's (make vccdc, configuration "ppudom";
# SIGNOFF_REPORT.md Section 3.2). soc4 ties dclk to clk_i, so its run sees one
# clock; a SOVRA tile clocks its device side from its own clock. This run
# checks the wrapper's synchronisers (cdc_sync, SYNC_STAGES = 2) as that
# integration will use them. Clock columns from the wrapper headers:
# ppu_dom_top.sv lines 31-40 (device side: dclk), ppu_axi_dom_top.sv (aclk:
# the AXI bridge and the clock controller; HC_Q_CH_SYNC/PWR_Q_CH_SYNC = 1: the
# hierarchical clock controller's channel is asynchronous; CLK_QACTIVE_SYNC
# = 0: qactive_only_i is synchronous to aclk), ppu_clk_ctrl.sv (PCK-600 Table
# A-25: clk_force_i and entry_delay_i are asynchronous).

create_clock -name aclk -period 10 [get_ports aclk]
create_clock -name dclk -period 7  [get_ports dclk]
create_clock -name hc_vclk  -period 13
create_clock -name cfg_vclk -period 17
set_clock_groups -asynchronous -group {aclk} -group {dclk} -group {hc_vclk} -group {cfg_vclk}

create_reset [get_ports aresetn] -sense low
set_input_delay -clock aclk 0 [get_ports aresetn]

set_input_delay -clock aclk 0 [get_ports {s_axi_awaddr s_axi_awprot s_axi_awvalid s_axi_wdata \
  s_axi_wstrb s_axi_wvalid s_axi_bready s_axi_araddr s_axi_arprot s_axi_arvalid s_axi_rready \
  qactive_only_i}]
set_output_delay -clock aclk 0 [get_ports {s_axi_awready s_axi_wready s_axi_bresp s_axi_bvalid \
  s_axi_arready s_axi_rdata s_axi_rresp s_axi_rvalid irq ppuhwstat}]

set_input_delay  -clock hc_vclk  0 [get_ports hc_qreqn_i]
set_output_delay -clock hc_vclk  0 [get_ports {hc_qacceptn_o hc_qdeny_o hc_qactive_o}]
set_input_delay  -clock cfg_vclk 0 [get_ports {clk_force_i entry_delay_i}]

set_input_delay  -clock dclk 0 [get_ports {dev_quiescent_busy dev_quiescent_deny dev_wake}]
set_output_delay -clock dclk 0 [get_ports {dev_quiescent_ok dev_clken_req dev_nret_rst_n \
  dev_ret_rst_n}]
