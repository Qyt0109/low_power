# src: the power-control platform

This tree holds the RTL, firmware, verification and sign-off of a power-control
platform built to the Arm Power Control System Architecture (PCSA, DEN 0050D).
A System Control Processor (SCP), a lowRISC Ibex core with private RAM, runs
bare-metal firmware that owns every power domain. It drives each domain through
a Power Policy Unit (PPU) built to the Arm PPU Architecture v1.1 (DEN 0051E). The
PPU sequences a Q-Channel to its device and a P-Channel to its power-control
state machine (PCSM). Software agents ask the SCP for power over RPMI v1.0, and
the SCP answers with librpmi v1.0.0 as its RPMI server. Requests and replies go
through a TL-UL mailbox for N agents: each agent has its own queue window, its
own doorbell and a firewall entry on its TL-UL source ID. **soc4** is the
reference system that puts all of this together: the SCP, four PPU domains (two
Ibex CPUs and two stand-in accelerators), an always-on AP and the mailbox, with
an AP port and an RPU port. The target SoC is SOVRA (Chipyard/TileLink). Its
power architecture and the platform plan are in
[`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)
§14–15. What software on the agents sees is in
[`docs/PMU_SOFTWARE_CONTRACT.md`](../docs/PMU_SOFTWARE_CONTRACT.md).

## Folders

| Folder | Purpose | README |
|---|---|---|
| `formal/` | SVA property modules for VC Formal, one folder per block: `scp_irq`, `scp_wdog`, `ckrst_bridge`, `hart_ready_adp`, `soc4_mbx`, `tluh_gate`, `qchannel` | [formal/README.md](formal/README.md) |
| `pmu/` | The SCP: vendored Ibex (`ibex/`), the SCP RTL (`rtl/`, `scp_top` and its blocks), the shared SCP firmware (`fw/`), and the firmware's DEN 0051E conformance report | [pmu/README.md](pmu/README.md) |
| `rtl/` | The low-power IP: Q-Channel and P-Channel controllers, the PPU, access gates (`acg`), the READY-bit adapter (`adp`), the clock/reset request bridge (`ckrst`), TL-UH helpers (`tluh`) and shared cells (`common`) | [rtl/README.md](rtl/README.md) |
| `signoff/` | Synopsys VC suite scripts (VC LP, CDC, RDC, lint, formal), waivers, open findings, and [`SIGNOFF_REPORT.md`](signoff/SIGNOFF_REPORT.md) | [signoff/README.md](signoff/README.md) |
| `soc4/` | The reference system: `soc4_top` and its domains (`rtl/`), and the firmware build (`fw/`), which is the only firmware build in the repository | [soc4/README.md](soc4/README.md) |
| `tb/` | Testbenches, one folder per IP: `acg`, `adp`, `ckrst`, `pchannel`, `pmu`, `ppu`, `qchannel`, `soc4` | [tb/README.md](tb/README.md) |
| `upf/` | IEEE 1801 power intent for the power-aware (`...pa`) runs | [upf/README.md](upf/README.md) |
| `vendor/` | Third-party RTL copied verbatim: OpenTitan TL-UL, PULP, SOVRA `tl_pkg` | [vendor/README.md](vendor/README.md) |

Third-party code is also vendored in two other places, both verbatim:
`pmu/ibex/` (lowRISC Ibex) and `pmu/fw/vendor/librpmi/` (librpmi v1.0.0).

## Building and running

Everything is driven from [`Makefile`](Makefile) in this folder. Its header
lists every target with a one-line description (`make help` prints it). The
main groups are:

| Group | Targets |
|---|---|
| Q-Channel | `pd`, `lint`, `wave-pd`; under UPF `pa` |
| LPD-Q | `lpdq`, `lpdpd`; under UPF `lpdpdpa` |
| P-Channel | `pch`, `pchneg`, `pchpd`, `pchall`, `pchlint` |
| PPU | `ppu`, `ppudemo`, `ppuneg`, `ppurst`, `ppuratio`, `ppucfg`, `ppuirq`, `ppuregdoc`, `ppupm`, `ppurstf`, `ppube`, `ppudeny`, `ppudevif`, `ppuclkctrl`, `ppuclkq`, `ppuaxi`, `ppupcsmpg`, `ppuall`, `ppuvlint`; under UPF `ppupaall` and the `ppu...pa` forms |
| Access gate | `acg`, `acgpd`; under UPF `acgpdpa` |
| soc4 | `soc4fw` (firmware images), `soc4elab`, `soc4`, `soc4bfm`, `soc4stress`, `soc4wdog`, `soc4ckrst`, `soc4neg`; under UPF `soc4pa`, `soc4bfmpa`, `soc4stresspa` |
| SOVRA device side | `acgtluh`, `readyadp`, `ckrst` |
| Sign-off | `vclp`, `vccdc`, `vcrdc`, `vclint`, `vcformal`, `vcformalneg`, or `signoff` for all six |
| Housekeeping | `help`, `clean` (removes the whole build directory) |

**Simulators.** `SIM=` selects the simulator for the plain simulation
targets: `vcs` (the default), `xcelium` or `icarus`; the Makefile header says
which targets each can run. The soc4 targets, power-aware ones included, need
`SIM=vcs` (`soc4simcheck`). The other power-aware targets (`pa`, `ppu*pa`,
`lpdpdpa`, `acgpdpa`, `ppudemopa`) call Xcelium directly (Xcelium 25.09,
`/system/EDA/Cadence/xcelium/25.09.001`). The sign-off targets run
the Synopsys VC suite (`VC_STATIC_HOME`) and ignore `SIM`. The Vivado flow
(`synth`, `impl`, `xsim-pd`, `xsim-diff`, `ppusynth`, `SIM=vivado`) and
`constraints/` were removed on 2026-10-06.

**Regression.** [`scripts/run_regress.sh`](../scripts/run_regress.sh) runs
the 31 VCS targets of the phase 6 regression and the 13 Xcelium power-aware
targets; the target lists and the baselines are in [`tb/README.md`](tb/README.md) §3.

**Build output.** The Makefile writes to `$(SRC)/../build`. In this checkout,
`build` at the repository root is a symlink to `/sim/sovra/quyetdv/pmu/build`,
so nothing is written into the source tree. The layout:

| Path under `build/` | What |
|---|---|
| `build/` itself | Icarus executables, logs and VCDs (one directory is shared) |
| `build/<sim>/<top>/` | the compiled database, the run's log and VCD of one testbench under VCS or Xcelium (for example `build/vcs/soc4_tb/`) |
| `build/vcs_pa/soc4_tb/` | the soc4 power-aware build (VCS native low power) |
| `build/pa/<top>/` | the Xcelium power-aware runs (`pa`, `ppu*pa`, `lpdpdpa`, `acgpdpa`) |
| `build/fw/soc4/` | firmware images: `<name>.elf`, `.bin`, `.vmem`, `.dis`, `.map` |
| `build/signoff/` | VC suite runs; formal runs go in `build/signoff/formal/<block>/` |

The soc4 design document that many headers cite by section,
[`docs/SOC4_DESIGN.md`](../docs/SOC4_DESIGN.md), was copied into the
repository on 2026-10-06 from `build/soc4_design/`. It describes soc4 as
designed before phases 1–6; the READMEs describe it as built.

## Where to start

- The SCP and its firmware: [`pmu/README.md`](pmu/README.md), then
  [`pmu/rtl/README.md`](pmu/rtl/README.md) and
  [`pmu/fw/README.md`](pmu/fw/README.md).
- The PPU: [`rtl/ppu/README.md`](rtl/ppu/README.md) and its register reference
  `rtl/ppu/REGISTERS.md`.
- The platform plan and its decisions:
  [`Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md`](../Proposed_PMU/SOVRA_PCSA_ARCHITECTURE.md)
  §14 (checklist and decisions) and §15 (status, plan, and how to add or remove
  a domain or an agent).
- The sign-off results: [`signoff/SIGNOFF_REPORT.md`](signoff/SIGNOFF_REPORT.md).
